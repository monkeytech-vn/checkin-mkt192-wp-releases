<?php
// Chạy độc lập bằng PHP CLI, dữ liệu trong bộ nhớ, không nối WordPress hay DB thật.
$source = file_get_contents($argv[1] ?? dirname(__DIR__) . '/includes/rest-api/salary-api.php');
$start = strpos($source, 'function checkin_mkt192_sync_auto_penalties(');
$end = strpos($source, '/** Tương thích tên cũ.', $start);
eval(substr($source, $start, $end - $start));
function checkin_mkt192_adjustments_table() { return 'test_adjustments'; }
function checkin_mkt192_salary_settings() { return $GLOBALS['cfg']; }
function checkin_mkt192_salary_locked_for() { return true; }
function checkin_mkt192_staff_period_invoice_ids() { return ['no-image']; }
function checkin_mkt192_invoice_has_images($raw) { return !empty($raw); }
function checkin_mkt192_invoice_not_image_reasons($raw) { return []; }
// Các test chỉ dùng chuỗi ASCII ở phần xử lý không ảnh.
if (!function_exists('mb_strtolower')) { function mb_strtolower($s) { return strtolower($s); } }
if (!function_exists('mb_substr')) { function mb_substr($s, $start, $length) { return substr($s, $start, $length); } }
class MemoryDB {
    public $prefix = 'test_';
    public $rows = [];
    public $reviews = [];
    public $dates = [];
    public $inserts = [];
    public function prepare($sql, ...$params) { return $sql; }
    public function get_col($sql) { return array_column(array_filter($this->rows, fn($r) => $r['category'] === 'ignored'), 'ref_id'); }
    public function get_results($sql) {
        if (strpos($sql, "kind = 'marker'") !== false) return [];
        if (strpos($sql, 'customer_reviews_online') !== false) return $this->reviews;
        if (strpos($sql, 'SELECT invoice_id, created_at') !== false) return $this->dates;
        if (strpos($sql, 'SELECT invoice_id, images') !== false) return [(object)[
            'invoice_id' => 'no-image', 'images' => '', 'not_image' => '',
            'customer_name' => 'CUSTOMER', 'created_at' => '2026-10-08 12:00:00'
        ]];
        if (strpos($sql, 'SUM(total)') !== false) return [(object)['service_type' => 'service', 'total' => 100000]];
        throw new RuntimeException('Unexpected query: ' . $sql);
    }
    public function query($sql) {
        if (strpos($sql, 'DELETE FROM test_adjustments') !== 0) throw new RuntimeException('Unexpected mutation');
        $this->rows = array_values(array_filter($this->rows, fn($r) => !in_array($r['source'], ['review','no_image']) || $r['category'] === 'ignored'));
    }
    public function insert($table, $row) { $this->inserts[] = $row; $this->rows[] = $row; return 1; }
    public function update(...$args) { throw new RuntimeException('Unexpected marker update'); }
    public function get_var($sql) { return null; }
    public function get_row($sql) { return (object)['service_total'=>100000, 'penalty_service'=>0, 'service_salary'=>30000, 'chemical_total'=>0, 'penalty_chemical'=>0, 'chemical_salary'=>0]; }
}
function check($ok, $label) {
    if (!$ok) throw new RuntimeException('FAIL: ' . $label);
    echo 'PASS: ' . $label . "\n";
}
function reset_case($mode = 'percent') {
    $GLOBALS['wpdb'] = new MemoryDB();
    $GLOBALS['cfg'] = [
        'review_penalty' => ['enabled' => true, 'threshold' => 3, 'mode' => $mode, 'value' => $mode === 'percent' ? 100 : 25000],
        'no_image_penalty' => ['enabled' => false, 'valid_reasons' => [], 'skip_guest' => true, 'mode' => 'fixed', 'value' => 15000],
    ];
    return $GLOBALS['wpdb'];
}
function add_review($db, $id, $invoice_at, $review_at = '2026-10-15 12:00:00') {
    $db->reviews[] = (object)['invoice_id'=>$id, 'service_rating'=>3, 'staff_rating'=>2, 'review_at'=>$review_at];
    if ($invoice_at !== null) $db->dates[] = (object)['invoice_id'=>$id, 'created_at'=>$invoice_at];
}
foreach (['percent', 'fixed'] as $mode) {
    $db = reset_case($mode);
    // Các bill Kent báo, tháng cũ đã khoá, kể cả đánh giá trong tháng đang tính.
    foreach (['HD25061029751'=>'2025-06-10', 'HD260308045'=>'2026-03-08', 'HD260308050'=>'2026-03-08', 'HD260419002'=>'2026-04-19', 'HD260602013'=>'2026-06-02', 'HD260614024'=>'2026-06-14', 'HD260626031'=>'2026-06-26', 'HD260712003'=>'2026-07-12', 'HD260721021'=>'2026-07-21', 'HD260912031'=>'2026-09-12', 'HD25071331385'=>'2025-07-13', 'HD250819031'=>'2025-08-19', 'HD260214043'=>'2026-02-14'] as $id=>$date) add_review($db, $id, $date.' 12:00:00', $date.' 12:00:00');
    add_review($db, 'old-reviewed-now', '2026-09-30 23:59:59');
    add_review($db, 'current-first', '2026-10-01 00:00:00');
    add_review($db, 'current-last', '2026-10-31 23:59:59', '2026-11-05 12:00:00');
    add_review($db, 'current-last', '2026-10-31 23:59:59');
    add_review($db, 'future', '2026-11-01 00:00:00');
    add_review($db, 'missing-invoice', null);
    add_review($db, 'ignored-current', '2026-10-02 12:00:00');
    $db->rows = [
        ['source'=>'review','category'=>'review_late','ref_id'=>'HD260308045','amount'=>52500],
        ['source'=>'manual','category'=>'uniform','ref_id'=>'','amount'=>280000],
        ['source'=>'review','kind'=>'marker','category'=>'ignored','ref_id'=>'ignored-current','amount'=>0],
    ];
    $counts = checkin_mkt192_sync_auto_penalties('Test Staff', '2026-10');
    check(array_column($db->inserts, 'ref_id') === ['current-first','current-last'], $mode . ': chi truy thu bill dung ky, khong trung, giu bo qua');
    check($counts['review'] === 2 && $counts['review_late'] === 0, $mode . ': khong gom bill cu da tra luong');
    check(count(array_filter($db->rows, fn($r) => $r['category'] === 'review_late')) === 0, $mode . ': tinh lai loai khoan bu cu');
    check(count(array_filter($db->rows, fn($r) => $r['source'] === 'manual')) === 1, $mode . ': giu khoan thu cong');
    check((int)$db->inserts[0]['amount'] === ($mode === 'percent' ? 100000 : 25000), $mode . ': dung so tien va cach tru');
    check($db->inserts[0]['kind'] === ($mode === 'percent' ? 'base_penalty' : 'deduction'), $mode . ': dung loai khoan tru');
    checkin_mkt192_sync_auto_penalties('Test Staff', '2026-10');
    check(count(array_filter($db->rows, fn($r) => ($r['kind'] ?? '') !== 'marker' && $r['source'] === 'review')) === 2, $mode . ': tinh lai khong nhan doi');
}
$db = reset_case();
$GLOBALS['cfg']['review_penalty']['enabled'] = false;
add_review($db, 'current', '2026-10-01 00:00:00');
checkin_mkt192_sync_auto_penalties('Test Staff', '2026-10');
check(!$db->inserts, 'tat danh gia thi khong truy thu');
$db = reset_case();
$GLOBALS['cfg']['no_image_penalty']['enabled'] = true;
checkin_mkt192_sync_auto_penalties('Test Staff', '2026-10');
check(count($db->inserts) === 1 && $db->inserts[0]['source'] === 'no_image' && (int)$db->inserts[0]['amount'] === 15000, 'truy thu khong anh van hoat dong');
$db = reset_case();
checkin_mkt192_sync_auto_penalties('Test Staff', 'invalid');
check(!$db->inserts, 'ky khong hop le khong ghi');
echo "OK: 17 checks\n";
