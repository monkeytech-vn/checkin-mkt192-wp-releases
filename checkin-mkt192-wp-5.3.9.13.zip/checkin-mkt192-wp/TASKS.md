# TASKS - checkin-mkt192-wp

## Đang dở

### leader
- Người giữ: (chưa ai nhận)
- Nhánh/commit: `main` (không có việc dở)
- Đã làm: chưa có
- Bước tiếp theo: xem backlog bên dưới
- Lệnh test: xem CLAUDE.md
- Quyết định đã chốt: xem CHANGELOG.md và CLAUDE.md

### dev1
- Người giữ: (chưa ai nhận)
- Nhánh/commit: `lane/dev1`
- Đã làm: chưa có
- Bước tiếp theo: chưa có

### dev2 (hàng việc leader giao 04/11 tối: PL-07, trang đặt lịch 390px, liệt kê chỗ gọi API đặt lịch/đăng ký)
- Người giữ: dev2 (tk A) từ 05/11/2026 01:10. Nhánh `lane/dev2` (đã gộp `main` v5.3.9.11). Không phát hành, không deploy
- PL-07 XONG (`8beb545`): `includes/helpers/legal.php` thêm `checkin_mkt192_staff_consent_ok/needed`, REST `POST vg/v1/staff-consent` (đăng nhập, kiểm `agree` + `legal_version`, ghi `terms`, `privacy`, `staff_data` cho `user:<id>`), `checkin_mkt192_staff_consent_screen()`. Bốn shortcode trang làm việc (Quản lý, Điểm danh, App Thợ, Dashboard) trả màn đồng ý thay cho trang khi nhân viên chưa đồng ý bản hiện hành, nên trang Điểm danh chưa xin vị trí trước khi đồng ý; quản trị WordPress (chủ) bỏ qua. Màn nêu: cửa hàng quản lý chấm công, ca, vị trí lúc điểm danh, lương, thưởng, phạt; trang Điểm danh lấy vị trí khi mở trang và khi điểm danh, toạ độ ghi vào nhật ký điểm danh (`checkin_debug.log`); MonkeyTech là bên cung cấp phần mềm. Thử WordPress cục bộ 8099 với người dùng vai `staff`: 390 + 1366 không tràn, nút khoá tới khi tích, đồng ý xong vào được App Thợ và Điểm danh, có 3 dòng nhật ký
- Trang đặt lịch 407px ở 390px XONG (`8c4b259`): nguyên nhân KHÔNG phải menu di động (`position: fixed`, không gây cuộn) mà khối Liên hệ `.contact-container` lưới `1fr` nở theo chữ dài. `home.css`: `minmax(0, 1fr)` + chữ trong thẻ liên hệ xuống dòng. Đo lại 390px: 390, 1366: 1366, email dài xuống dòng
- Danh sách chỗ gọi `POST /wp-json/vg/v1/customer-registration` và `POST /wp-json/vg/v1/bookings` (đã quét repo này + mọi repo trong `~/Project`, `~/openclaw-setup`, `~/Project/asa-support`, vault; leader hỏi Kent trước khi phát hành):
  1. Trong plugin, ĐÃ gửi `agree` + `legal_version`: `frontend/assets/js/pages/home.js:2455` (form đặt lịch, ô ở bước Xác nhận); `frontend/assets/js/pages/customer-registration.js:126` (form đăng ký thành viên, trang `[checkin_customer_registration]`, menu Zalo OA mở trang này)
  2. App Thợ (`app-tho.js`) chỉ gọi `bookings/{id}` (xem, sửa, huỷ, gửi lại tin), KHÔNG gọi `POST /bookings`: không bị ảnh hưởng
  3. n8n mẫu (`n8n-workflows/*.json`: gửi, nhắc, huỷ lịch hẹn cho khách và nhóm): không gọi hai đường này (n8n nhận webhook từ plugin)
  4. Tài liệu: `docs/PUBLIC_APIS.md` (đã thêm đoạn bắt buộc `agree` + `legal_version`), `docs/IMPLEMENTATION_SUMMARY.md` (mô tả cũ của `/customer-registration`, có ví dụ `curl` dòng 273 không có `agree`, chưa sửa)
  5. Repo khác: `monkeysalon` (app mới) chỉ nhắc trong đặc tả `docs/tinh-nang/bu-app-cu/dac-ta.md` và chú thích `profile-form.tsx`, không gọi; `monkeyagent-core` chỉ có URL mẫu `vg/v1/bookings` trong test (`systools.test.ts`, `app.test.mjs`), không gọi thật
  6. Leader đã kiểm 05/11: bot MonkeyAgent project VG trên `vps_mkt` chỉ GET (skill `tra-du-lieu-salon` + cron `all-checkin-logs`), không tạo lịch/khách; 4 bot khách trên `win_kha` `D:\bot` không có chuỗi `vg/v1`, `wp-json`, `customer-registration`, `vangroupbarbershop`. Kết luận: không vướng phía bot, sẵn sàng gộp khi Kent duyệt. (Ghi chú cũ: bot MonkeyAgent project VG (Zalo `troly`, `vps_mkt`) hoặc bot khách trên `win_kha` có cấu hình công cụ HTTP gọi `POST /wp-json/vg/v1/bookings` hay không; nếu có thì sau khi phát hành bot nhận 400 `consent` và KHÔNG được tự gửi `agree: true` thay khách)
- Bước tiếp theo: dev2 TẠM DỪNG (leader 05/11); chờ leader gộp khi Kent duyệt phát hành; nội dung Điều khoản + Chính sách cửa hàng cần Kent duyệt (việc cũ)
- Lệnh test: `docker run --rm -v "$PWD":/app -w /app php:8.2-cli php -l <tệp>`; WordPress cục bộ `docker start wp-dev2-db wp-dev2` (cổng 8099)

### dev2 (xin đồng ý đúng luật, phiếu chuan/docs/giao-viec-dong-y.md, leader giao 04/11)
- Người giữ: dev2 (tk A) 04/11/2026 tối. Nhánh `lane/dev2` (đã gộp `main`). XONG, chờ leader gộp; không phát hành
- Đã làm: `includes/helpers/legal.php` (`CHECKIN_MKT192_LEGAL_VERSION` 2026-11-04, bảng `{prefix}checkin_mkt192_consent_log` chỉ thêm, tạo lúc kích hoạt và khi DB lên 8.11.0; `checkin_mkt192_has_agreed`, `log_consent`, link trang có shortcode `[checkin_policy]`/`[checkin_terms_and_service]`, đè được bằng option `checkin_policy_url`/`checkin_terms_url`). Đăng ký thành viên: ô bắt buộc nêu mục đích (đăng ký thành viên, tích điểm) + link Điều khoản, Chính sách mở tab mới, ô nhận ưu đãi riêng không bắt buộc, nút khoá tới khi tích; REST `/customer-registration` thiếu `agree` hoặc sai `legal_version` trả 400 `consent`, có thì ghi `terms`, `privacy`, `member_points` (+ `marketing` khi tích). Đặt lịch: ô ở bước Xác nhận, nút khoá tới khi tích; REST `/bookings` kiểm như trên, ghi `terms`, `privacy`, `booking`. Google/Facebook ở màn nhân viên tạo tài khoản mới (`force_create`) phải qua màn "Tạo tài khoản mới" có ô, máy chủ kiểm `agree`. Bỏ câu "Bằng việc sử dụng/đăng nhập ... đồng ý" ở `terms-and-service.html`, `policy.html`, `user-profile.html`; hai trang pháp lý in phiên bản
- Thử: `php -l` các tệp sửa (Docker php:8.2), `node --check` JS; WordPress Docker cục bộ (`wp-dev2`, cổng 8099): REST thiếu agree trả 400 không tạo khách; trình duyệt phiên mới 390px + 1440px: nút đăng ký thành viên khoá tới khi tích, tích rồi tạo khách và 3 dòng nhật ký; ô đặt lịch khoá/mở nút Xác nhận đúng, REST đặt lịch có agree ghi 3 dòng. KC-09 sạch
- Còn lại: màn "Tạo tài khoản mới" bằng Google/Facebook chưa thử trên trình duyệt (cần khoá Google/Facebook thật); bên ngoài gọi thẳng `/customer-registration` hay `/bookings` (Zalo OA, n8n nếu có) phải gửi thêm `agree` + `legal_version`, không thì nhận 400; nhân viên được mời (PL-07) chưa có màn đồng ý lần đầu; trang đặt lịch tràn ngang 407px ở 390px do menu di động (có sẵn)
- Lệnh test: `docker run --rm -v "$PWD":/app -w /app php:8.2-cli php -l <tệp>`; `~/Project/chuan/master/bin/kiem-chuan .`

### dev2 (chuẩn đợt 2)
- Người giữ: dev2 (tk C) từ 03/11/2026
- Nhánh/commit: `lane/dev2` (chuan dot 2 uu tien 1)
- Đã làm: nền chuẩn đợt 2 ưu tiên 1: .gitignore (`secrets/`, `*.pem`, `*.key`), `.env.example` đủ biến, tệp bắt buộc (CLAUDE.md, TASKS.md)
- Bước tiếp theo: chờ leader gộp; đợt sau đổi tên biến lệch chuẩn khi Kent duyệt
- Lệnh test: `~/Project/chuan/bin/kiem-chuan .`

## Backlog
- Chưa có


## Codex - 07/11/2026: truy thu đánh giá đúng kỳ lương
- Người giữ: Codex theo yêu cầu Kent sửa truy thu chéo kỳ.
- Worktree: `~/Project/checkin-mkt192-wp/codex`, nhánh `lane/codex`, nền `731d8b5` (v5.3.9.12). Chưa commit, chưa phát hành, chưa cập nhật VG.
- Nguyên nhân: nhánh review_late gom mọi bill kỳ cũ đã khoá sang kỳ đang tính, không kiểm ngày đánh giá có sau ngày trả lương hay không.
- Đã sửa: chỉ nhận ngày tạo hoá đơn trong khoảng đầu/cuối kỳ; thiếu hoá đơn/ngày thì bỏ qua; bỏ tạo khoản review_late; cập nhật hướng dẫn giao diện và CHANGELOG.
- Tính lại phiếu chưa chốt vẫn dùng bước đồng bộ cũ để loại khoản tự động sai và dựng lại đúng kỳ, giữ khoản thủ công và marker ignored. Phiếu đã chốt được guard có sẵn giữ nguyên.
- Kiểm chứng: `tests/review-penalty-period.php` chạy PHP CLI với DB trong bộ nhớ: 17 kiểm tra qua; mã trước sửa lỗi ngay ca truy thu chéo kỳ. Có 13 bill Kent gửi, biên tháng, đánh giá tháng sau, thiếu hoá đơn, trùng đánh giá, miễn truy thu, tính lại không nhân đôi, hai chế độ phần trăm/cố định và không ảnh. PHP syntax, JS syntax, diff-check qua.
- Bước tiếp theo: Kent duyệt phát hành và cập nhật VG trước khi đưa bản sửa lên site, sau đó tính lại T10 chưa chốt. Không gọi tính lại trên VG trong phiên này.

- Kent duyệt phát hành, cập nhật VG và tính lại T10 chưa chốt trong chat 07/11/2026. Bản v5.3.9.13 gồm sửa truy thu đúng kỳ và quy trình phát hành chỉ thêm, không xoá hoặc force push.
