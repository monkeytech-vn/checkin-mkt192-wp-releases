# Public APIs - Không yêu cầu đăng nhập

## Trang chủ (Home Page)

Các API này **PHẢI public** để khách hàng có thể xem và đặt lịch:

### 1. Services, Products & Images

- ✅ `GET /vg/v1/services` - Danh sách dịch vụ (giá, tên, nhóm)
- ✅ `GET /vg/v1/service-images` - Hình ảnh dịch vụ
- ✅ `GET /vg/v1/products` - Danh sách sản phẩm (cho nhân viên xem khi tạo hóa đơn)
- ✅ `GET /vg/v1/product-groups` - Nhóm sản phẩm (Wax, Tinh Dầu, Gôm, Khác)

### 2. Gallery

- ✅ `GET /vg/v1/gallery` - Hình ảnh gallery salon

### 3. Booking System

- ✅ `GET /vg/v1/hairdressers` - Danh sách thợ + lịch nghỉ phép
- ✅ `POST /vg/v1/hairdresser-availability` - Check khung giờ trống
- ✅ `GET /vg/v1/check-customer` - Kiểm tra khách hàng cũ/mới
- ✅ `GET /vg/v1/last-booking-number` - Tạo mã booking
- ✅ `POST /vg/v1/bookings` - Tạo booking mới

### 4. Customer Member Page

- ✅ `POST /vg/v1/customer-booking` - Xem booking theo SĐT
- ✅ `GET /vg/v1/invoices/(?P<invoice_id>[a-zA-Z0-9_-]+)/payment-for-page-review` - Xem hóa đơn để review

### 5. Customer Review (Offline/Online)

- ✅ Các trang đánh giá không yêu cầu login

### 6. Settings for Review Pages

- ✅ `GET /vg/v1/settings/ctkm` - Danh sách chương trình khuyến mãi (cho trang review khách hàng)
- ✅ `DELETE /vg/v1/notify-review` - Xóa thông báo review (workflow hoàn tất)

## Tóm tắt

| API Endpoint                | Method | Permission      | Mục đích                                 |
| --------------------------- | ------ | --------------- | ---------------------------------------- |
| `/services`                 | GET    | `__return_true` | Hiển thị giá dịch vụ trang chủ           |
| `/service-images`           | GET    | `__return_true` | Hiển thị hình ảnh dịch vụ                |
| `/products`                 | GET    | `__return_true` | Danh sách sản phẩm (cho thu ngân tạo HĐ) |
| `/product-groups`           | GET    | `__return_true` | Nhóm sản phẩm (Wax, Tinh Dầu, Gôm, Khác) |
| `/gallery`                  | GET    | `__return_true` | Gallery salon                            |
| `/hairdressers`             | GET    | `__return_true` | Danh sách thợ                            |
| `/hairdresher-availability` | POST   | `__return_true` | Check khung giờ trống                    |
| `/check-customer`           | GET    | `__return_true` | Check khách hàng                         |
| `/last-booking-number`      | GET    | `__return_true` | Tạo mã booking                           |
| `/bookings`                 | POST   | `__return_true` | Đặt lịch                                 |
| `/customer-booking`         | POST   | `__return_true` | Xem booking                              |
| `/settings/ctkm`            | GET    | `__return_true` | Danh sách CTKM (cho trang review)        |
| `/notify-review`            | DELETE | `__return_true` | Xóa thông báo review (workflow hoàn tất) |

**Bắt buộc từ bản có ô đồng ý (LEGAL_VERSION 2026-11-04):** `POST /bookings` và `POST /customer-registration` phải gửi kèm `"agree": true` và `"legal_version": "<phiên bản hiện hành>"` (lấy ở `checkinData.legalVersion` trên trang, hằng `CHECKIN_MKT192_LEGAL_VERSION` trong `includes/helpers/legal.php`). Thiếu hoặc sai phiên bản thì trả 400 `{"code":"consent"}` và không lưu gì. Chỉ gửi `agree: true` khi khách vừa tự tích ô đồng ý (chuan/PHAP-LY.md PL-02, PL-05); `/customer-registration` nhận thêm ô tuỳ chọn nhận ưu đãi (ghi `marketing`).

**Lưu ý:** GET `/products`, `/product-groups`, `/settings/ctkm` và DELETE `/notify-review` được chuyển từ `login + scope` sang `public` trong phiên bản mới nhất để hỗ trợ workflow thu ngân tạo hóa đơn và trang review khách hàng.
