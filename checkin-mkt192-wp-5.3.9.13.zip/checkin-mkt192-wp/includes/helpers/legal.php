<?php
/**
 * Đồng ý đúng luật (chuan/PHAP-LY.md PL-02, PL-04, PL-05) cho form công khai: đăng ký thành viên, đặt lịch.
 *
 * - Cửa hàng (brand) là bên kiểm soát dữ liệu khách của mình; plugin chỉ ghi nhận đồng ý thay cửa hàng.
 * - Phiên bản Điều khoản + Chính sách đặt một chỗ (CHECKIN_MKT192_LEGAL_VERSION), JS nhận qua checkinData.legalVersion.
 * - Chỉ ghi nhật ký khi khách vừa tích ô; bảng chỉ thêm, không có câu UPDATE/DELETE nào trên bảng này.
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!defined('CHECKIN_MKT192_LEGAL_VERSION')) {
    define('CHECKIN_MKT192_LEGAL_VERSION', '2026-11-04');
}

function checkin_mkt192_consent_table() {
    global $wpdb;
    return $wpdb->prefix . 'checkin_mkt192_consent_log';
}

/** Tạo bảng nhật ký đồng ý (gọi lúc kích hoạt và khi nâng phiên bản DB). */
function checkin_mkt192_create_consent_table() {
    global $wpdb;
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    $table   = checkin_mkt192_consent_table();
    $charset = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE $table (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        subject VARCHAR(100) NOT NULL,
        purpose VARCHAR(32) NOT NULL,
        granted TINYINT(1) NOT NULL,
        doc_version VARCHAR(32) NOT NULL,
        channel VARCHAR(16) NOT NULL DEFAULT 'web',
        ip VARCHAR(64) DEFAULT '',
        user_agent VARCHAR(512) DEFAULT '',
        at DATETIME NOT NULL,
        PRIMARY KEY  (id),
        KEY subject_purpose (subject, purpose, at)
    ) $charset;";
    dbDelta($sql);
}

/** Khách vừa tích ô đồng ý đúng bản hiện hành (máy chủ không tin gì khác). */
function checkin_mkt192_has_agreed($data) {
    if (!is_array($data)) {
        return false;
    }
    $agree = $data['agree'] ?? null;
    $ok    = $agree === true || $agree === 'true' || $agree === '1' || $agree === 1;
    return $ok && ($data['legal_version'] ?? '') === CHECKIN_MKT192_LEGAL_VERSION;
}

/** Ô tuỳ chọn (nhận ưu đãi) có được tích không. */
function checkin_mkt192_flag($data, $key) {
    $v = is_array($data) ? ($data[$key] ?? null) : null;
    return $v === true || $v === 'true' || $v === '1' || $v === 1;
}

/** Mã người đồng ý theo số điện thoại đã chuẩn hoá (bỏ số 0 đầu, như bảng khách). */
function checkin_mkt192_consent_subject_phone($phone) {
    return 'phone:' . ltrim(preg_replace('/\D+/', '', (string) $phone), '0');
}

/** Ghi các dòng đồng ý cho một người. $purposes: ['terms', 'privacy', 'marketing'...]. */
function checkin_mkt192_log_consent($subject, array $purposes, $channel = 'web') {
    global $wpdb;
    $ip = isset($_SERVER['HTTP_CF_CONNECTING_IP']) ? $_SERVER['HTTP_CF_CONNECTING_IP'] : ($_SERVER['REMOTE_ADDR'] ?? '');
    $ua = $_SERVER['HTTP_USER_AGENT'] ?? '';
    foreach ($purposes as $purpose) {
        $wpdb->insert(checkin_mkt192_consent_table(), [
            'subject'     => substr((string) $subject, 0, 100),
            'purpose'     => $purpose,
            'granted'     => 1,
            'doc_version' => CHECKIN_MKT192_LEGAL_VERSION,
            'channel'     => $channel,
            'ip'          => substr(sanitize_text_field($ip), 0, 64),
            'user_agent'  => substr(sanitize_text_field($ua), 0, 512),
            'at'          => current_time('mysql', false),
        ], ['%s', '%s', '%d', '%s', '%s', '%s', '%s', '%s']);
    }
}

/**
 * Link trang Chính sách / Điều khoản của cửa hàng: trang đã đăng có shortcode [checkin_policy] /
 * [checkin_terms_and_service]. Cho phép đè bằng option checkin_policy_url / checkin_terms_url.
 */
function checkin_mkt192_legal_url($kind) {
    $opt = $kind === 'terms' ? 'checkin_terms_url' : 'checkin_policy_url';
    $set = get_option($opt, '');
    if ($set) {
        return esc_url($set);
    }
    $key    = 'checkin_mkt192_legal_url_' . $kind;
    $cached = get_transient($key);
    if ($cached !== false) {
        return $cached;
    }
    global $wpdb;
    $code = $kind === 'terms' ? '[checkin_terms_and_service' : '[checkin_policy';
    $id   = $wpdb->get_var($wpdb->prepare(
        "SELECT ID FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_type IN ('page', 'post') AND post_content LIKE %s ORDER BY ID ASC LIMIT 1",
        '%' . $wpdb->esc_like($code) . '%'
    ));
    $url = $id ? get_permalink((int) $id) : '';
    set_transient($key, $url, DAY_IN_SECONDS);
    return $url;
}

/** Câu đồng ý dùng chung: "Tôi đã đọc và đồng ý với Điều khoản sử dụng và Chính sách quyền riêng tư của <brand>." */
function checkin_mkt192_agree_text_html() {
    $brand  = esc_html(get_option('checkin_brand_name', 'Shop'));
    $terms  = checkin_mkt192_legal_url('terms');
    $policy = checkin_mkt192_legal_url('policy');
    $t = $terms ? '<a href="' . esc_url($terms) . '" target="_blank" rel="noopener">Điều khoản sử dụng</a>' : 'Điều khoản sử dụng';
    $p = $policy ? '<a href="' . esc_url($policy) . '" target="_blank" rel="noopener">Chính sách quyền riêng tư</a>' : 'Chính sách quyền riêng tư';
    return 'Tôi đã đọc và đồng ý với ' . $t . ' và ' . $p . ' của <strong>' . $brand . '</strong>.';
}

/*
 * PL-07: nhân viên do cửa hàng tạo tài khoản. Cửa hàng là bên kiểm soát dữ liệu chấm công, vị trí, lương của nhân
 * viên; MonkeyTech cung cấp phần mềm. Lần đầu vào trang làm việc (App Thợ, Điểm danh, Dashboard, Quản lý) nhân viên
 * thấy màn đồng ý có ô chưa tích, chưa tích thì trang không chạy (chưa xin vị trí). Chủ cửa hàng (quản trị
 * WordPress) không qua màn này. Đổi phiên bản thì hỏi lại một lần (PL-06).
 */

/** Nhân viên đã đồng ý bản hiện hành (dòng mới nhất của terms và privacy là đồng ý, đúng phiên bản). */
function checkin_mkt192_staff_consent_ok($user_id) {
    global $wpdb;
    $rows = $wpdb->get_results($wpdb->prepare(
        'SELECT purpose, granted, doc_version FROM ' . checkin_mkt192_consent_table() . " WHERE subject = %s AND purpose IN ('terms', 'privacy') ORDER BY at DESC, id DESC",
        'user:' . (int) $user_id
    ));
    $latest = [];
    foreach ((array) $rows as $r) {
        if (!isset($latest[$r->purpose])) {
            $latest[$r->purpose] = $r;
        }
    }
    foreach (['terms', 'privacy'] as $p) {
        if (empty($latest[$p]) || (int) $latest[$p]->granted !== 1 || $latest[$p]->doc_version !== CHECKIN_MKT192_LEGAL_VERSION) {
            return false;
        }
    }
    return true;
}

/** Người đang đăng nhập phải qua màn đồng ý nhân viên không. */
function checkin_mkt192_staff_consent_needed() {
    if (!is_user_logged_in() || current_user_can('manage_options')) {
        return false;
    }
    return !checkin_mkt192_staff_consent_ok(get_current_user_id());
}

add_action('rest_api_init', function () {
    register_rest_route('vg/v1', '/staff-consent', [
        'methods'             => 'POST',
        'permission_callback' => function () {
            return is_user_logged_in();
        },
        'callback'            => function (WP_REST_Request $request) {
            if (!checkin_mkt192_has_agreed($request->get_json_params() ?: $request->get_params())) {
                return new WP_REST_Response(['success' => false, 'code' => 'consent', 'message' => 'Vui lòng tích ô đồng ý để tiếp tục.'], 400);
            }
            checkin_mkt192_log_consent('user:' . get_current_user_id(), ['terms', 'privacy', 'staff_data'], 'web');
            return new WP_REST_Response(['success' => true], 200);
        },
    ]);
});

/** Màn đồng ý thay cho trang làm việc khi nhân viên chưa đồng ý; '' khi không cần. */
function checkin_mkt192_staff_consent_screen() {
    if (!checkin_mkt192_staff_consent_needed()) {
        return '';
    }
    $brand   = esc_html(get_option('checkin_brand_name', 'Shop'));
    $user    = wp_get_current_user();
    $name    = esc_html($user->display_name ?: $user->user_login);
    $agree   = checkin_mkt192_agree_text_html();
    $rest    = esc_url_raw(rest_url('vg/v1/staff-consent'));
    $nonce   = wp_create_nonce('wp_rest');
    $version = esc_js(CHECKIN_MKT192_LEGAL_VERSION);
    $logout  = esc_url(wp_logout_url(home_url('/')));
    ob_start();
    ?>
<div class="ck-staff-consent">
  <style>
    .ck-staff-consent{box-sizing:border-box;min-height:70vh;display:flex;align-items:center;justify-content:center;padding:24px 16px;font-family:inherit}
    .ck-staff-consent *{box-sizing:border-box}
    .ck-sc-card{width:100%;max-width:520px;background:#fff;color:#1f2328;border:1px solid #e5e7eb;border-radius:16px;padding:24px;box-shadow:0 8px 24px rgba(0,0,0,.06)}
    .ck-sc-card h2{margin:0 0 6px;font-size:20px;line-height:1.3}
    .ck-sc-card p{margin:0 0 12px;font-size:14px;line-height:1.6;color:#4b5563;overflow-wrap:anywhere}
    .ck-sc-card ul{margin:0 0 14px;padding-left:20px;font-size:14px;line-height:1.6;color:#374151}
    .ck-sc-agree{display:flex;gap:10px;align-items:flex-start;margin:16px 0;font-size:14px;line-height:1.5;color:#1f2328;cursor:pointer}
    .ck-sc-agree input{width:18px;height:18px;margin-top:2px;flex:none}
    .ck-sc-agree a{color:inherit;text-decoration:underline}
    .ck-sc-btn{width:100%;min-height:46px;border:0;border-radius:10px;background:#111827;color:#fff;font-size:15px;font-weight:600;cursor:pointer}
    .ck-sc-btn:disabled{opacity:.45;cursor:not-allowed}
    .ck-sc-err{display:none;margin:10px 0 0;color:#b91c1c;font-size:14px}
    .ck-sc-foot{margin-top:14px;text-align:center;font-size:13px}
    .ck-sc-foot a{color:#6b7280}
  </style>
  <div class="ck-sc-card" role="dialog" aria-labelledby="ck-sc-title">
    <h2 id="ck-sc-title">Xác nhận trước khi bắt đầu</h2>
    <p>Chào <?php echo $name; ?>, tài khoản này do <strong><?php echo $brand; ?></strong> tạo để bạn làm việc trên ứng dụng.</p>
    <ul>
      <li><?php echo $brand; ?> quản lý dữ liệu làm việc của bạn: chấm công, ca làm, vị trí lúc điểm danh, dịch vụ đã làm, lương, thưởng, phạt.</li>
      <li>Trang Điểm danh lấy vị trí của bạn khi mở trang và khi điểm danh, để xác nhận bạn đang ở chi nhánh. Toạ độ được ghi vào nhật ký điểm danh.</li>
      <li>MonkeyTech cung cấp phần mềm và xử lý dữ liệu theo yêu cầu của <?php echo $brand; ?>. Câu hỏi về dữ liệu của bạn, vui lòng liên hệ <?php echo $brand; ?>.</li>
    </ul>
    <label class="ck-sc-agree"><input type="checkbox" id="ck-sc-check"><span><?php echo wp_kses_post($agree); ?></span></label>
    <button type="button" class="ck-sc-btn" id="ck-sc-go" disabled>Tiếp tục</button>
    <p class="ck-sc-err" id="ck-sc-err" role="alert"></p>
    <div class="ck-sc-foot"><a href="<?php echo $logout; ?>">Đăng xuất</a></div>
  </div>
  <script>
  (function () {
    var box = document.getElementById('ck-sc-check'), btn = document.getElementById('ck-sc-go'), err = document.getElementById('ck-sc-err');
    box.addEventListener('change', function () { btn.disabled = !box.checked; });
    btn.addEventListener('click', function () {
      if (!box.checked) return;
      btn.disabled = true; err.style.display = 'none';
      fetch(<?php echo wp_json_encode($rest); ?>, {
        method: 'POST', credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': <?php echo wp_json_encode($nonce); ?> },
        body: JSON.stringify({ agree: true, legal_version: '<?php echo $version; ?>' })
      }).then(function (r) { return r.json().then(function (j) { return { ok: r.ok, j: j }; }); })
        .then(function (x) {
          if (x.ok && x.j && x.j.success) { window.location.reload(); return; }
          throw new Error((x.j && x.j.message) || 'Không lưu được, vui lòng thử lại.');
        })
        .catch(function (e) { err.textContent = e.message; err.style.display = 'block'; btn.disabled = !box.checked; });
    });
  })();
  </script>
</div>
    <?php
    return ob_get_clean();
}
