# CLAUDE.md - checkin-mkt192-wp

Bối cảnh gốc: `~/SecondBrain/CONTEXT.md`. Bộ chuẩn dự án: `~/Project/chuan/master/README.md` (hành văn, cấu trúc, bí mật, kiểm bằng `kiem-chuan`).

- Là gì: plugin WordPress quản lý salon và dịch vụ (chấm công, lương, đặt lịch, app thợ), chạy trên site của khách.
- Phát hành: GitHub release qua `.github/workflows/release.yml` (không deploy vào một thư mục `vps_mkt`, theo `~/Project/chuan/master/CAU-TRUC.md`). Không phát hành khi Kent chưa đồng ý.
- Bí mật: không dùng `.env`. Khoá nằm ở `wp-config.php` (hằng `CHECKIN_*`) và option trong DB của từng site. Không đưa giá trị vào git.
- Mỗi bản phát hành một mục trong `CHANGELOG.md`; lịch sử `main` chỉ có commit `release: vX.Y.Z`.
- Việc dở và bàn giao giữa các làn: `TASKS.md`. Chỉ ký tự `-`, không dùng gạch dài.
