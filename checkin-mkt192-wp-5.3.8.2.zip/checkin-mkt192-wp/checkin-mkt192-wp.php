<?php

/*
Plugin Name: Checkin MKT192 WP
Plugin URI: https://monkeytech192.vn/
Description: Plugin điểm danh cho nhân viên
Version: 5.3.8.2
Author: Monkey Tech 192
Author URI: https://monkeytech192.vn/
Text Domain: checkin-mkt192-wp
*/

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Main plugin class for Checkin MKT192 WP.
 */
class Checkin_MKT192_WP {
    /**
     * Instance of the class (Singleton pattern).
     *
     * @var Checkin_MKT192_WP
     */
    private static $instance = null;

    /**
     * Get instance of the class.
     *
     * @return Checkin_MKT192_WP
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor.
     */
    private function __construct() {
        $this->define_constants();
        $this->load_dependencies();
        $this->init_hooks();
    }

    /**
     * Define plugin constants.
     */
    private function define_constants() {
        define('CHECKIN_PLUGIN_DIR', plugin_dir_path(__FILE__));
        define('CHECKIN_PLUGIN_URL', plugin_dir_url(__FILE__));

        // Get plugin version from header
        $plugin_file = __FILE__;
        $plugin_data = get_file_data($plugin_file, ['Version' => 'Version']);
        define('CHECKIN_MKT192_WP_VERSION', $plugin_data['Version']);

        // Legacy constant for backward compatibility
        if (!defined('CHECKIN_MKT192_VERSION')) {
            define('CHECKIN_MKT192_VERSION', $plugin_data['Version']);
        }

        define('CACHE_PREFIX_SALARY', 'salary_transaction');
        define('CACHE_PREFIX_INVENTORY', 'inventory_transaction');

        // Manifest cập nhật plugin — host trên GitHub (repo public chỉ chứa manifest + zip release).
        // Đổi kênh phát hành: sửa file manifest.json trong repo checkin-mkt192-wp-releases.
        define('CHECKIN_UPDATE_API', 'https://raw.githubusercontent.com/monkeytech-vn/checkin-mkt192-wp-releases/main/manifest.json');
    }

    /**
     * Load plugin dependencies.
     */
    private function load_dependencies() {
        require_once CHECKIN_PLUGIN_DIR . 'includes/class-checkin-mkt192-activation.php';
        require_once CHECKIN_PLUGIN_DIR . 'includes/class-checkin-mkt192-shortcodes.php';
        require_once CHECKIN_PLUGIN_DIR . 'includes/class-checkin-mkt192-assets.php';
        require_once CHECKIN_PLUGIN_DIR . 'includes/helpers/class-checkin-mkt192-invoice-images.php';
        require_once CHECKIN_PLUGIN_DIR . 'includes/rest-api/rest-api-init.php';
        require_once CHECKIN_PLUGIN_DIR . 'includes/automation/class-checkin-mkt192-cron.php';
        require_once CHECKIN_PLUGIN_DIR . 'includes/security-headers.php';
        require_once CHECKIN_PLUGIN_DIR . 'includes/lark/lark-utils.php';
        require_once CHECKIN_PLUGIN_DIR . 'includes/lark/cache-utils.php';
        require_once CHECKIN_PLUGIN_DIR . 'includes/lark/class-checkin-mkt192-lark-helper.php';
        require_once CHECKIN_PLUGIN_DIR . 'includes/lark/class-checkin-mkt192-message-bot-manager.php';
        require_once CHECKIN_PLUGIN_DIR . 'includes/lark/class-checkin-mkt192-message-bot-admin.php';
        require_once CHECKIN_PLUGIN_DIR . 'includes/license-manager.php';

        // Load helper functions
        require_once CHECKIN_PLUGIN_DIR . 'includes/helpers/branch-helpers.php';

        // Load new admin system (v5.1.0)
        if (is_admin()) {
            $this->load_admin_system();
        }
    }

    /**
     * Load admin system files
     */
    private function load_admin_system() {
        // Admin menu and pages
        require_once CHECKIN_PLUGIN_DIR . 'admin/class-admin-menu.php';
        require_once CHECKIN_PLUGIN_DIR . 'admin/pages/class-dashboard-page.php';
        require_once CHECKIN_PLUGIN_DIR . 'admin/pages/class-brand-settings-page.php';
        require_once CHECKIN_PLUGIN_DIR . 'admin/pages/class-connections-page.php';
        require_once CHECKIN_PLUGIN_DIR . 'admin/pages/class-payments-page.php';
        require_once CHECKIN_PLUGIN_DIR . 'admin/pages/class-platforms-page.php';
        require_once CHECKIN_PLUGIN_DIR . 'admin/pages/class-shortcodes-page.php';
        require_once CHECKIN_PLUGIN_DIR . 'admin/pages/class-tools-page.php';
        require_once CHECKIN_PLUGIN_DIR . 'admin/pages/class-license-page.php';
        require_once CHECKIN_PLUGIN_DIR . 'admin/pages/class-push-notifications-page.php';

        // Admin assets loader
        require_once CHECKIN_PLUGIN_DIR . 'includes/admin/class-admin-assets.php';

        // Settings migration
        require_once CHECKIN_PLUGIN_DIR . 'includes/admin/class-settings-migration.php';

        // Seed test salary data (admin only)
        require_once CHECKIN_PLUGIN_DIR . 'includes/admin/seed-test-salary-2025.php';

        // Initialize admin components after plugins are loaded
        add_action('plugins_loaded', function() {
            Checkin_MKT192_WP_Admin_Menu::get_instance();
            Checkin_MKT192_WP_Admin_Assets::get_instance();
            Checkin_MKT192_WP_Settings_Migration::get_instance();
            Checkin_MKT192_WP_Platforms_Page::get_instance(); // Initialize to register AJAX handlers
        });
    }

    /**
     * Initialize WordPress hooks.
     */
    private function init_hooks() {
        // =============================================================================
        // ACTIVATION HOOKS - Chỉ chạy 1 lần khi activate plugin
        // =============================================================================
        register_activation_hook(__FILE__, ['Checkin_MKT192_Activation', 'create_tables']);
        register_activation_hook(__FILE__, ['Checkin_MKT192_Activation', 'schedule_cron']);

        // =============================================================================
        // LEGACY MIGRATIONS - KHÔNG CẦN THIẾT NỮA (tắt từ v5.3.0.1.5)
        // Tất cả các cột đã được định nghĩa trong CREATE TABLE của create_tables().
        // Các hàm migration dưới đây chỉ dùng cho sites CŨ chưa có cột, sites mới không cần.
        // =============================================================================
        // register_activation_hook(__FILE__, ['Checkin_MKT192_Activation', 'add_branch_id_column_to_tables']);
        // register_activation_hook(__FILE__, ['Checkin_MKT192_Activation', 'add_uniform_fee_column']);
        // register_activation_hook(__FILE__, ['Checkin_MKT192_Activation', 'add_branch_column_to_tables']);
        // register_activation_hook(__FILE__, ['Checkin_MKT192_Activation', 'add_branch_indexes']);
        // register_activation_hook(__FILE__, ['Checkin_MKT192_Activation', 'populate_branch_data']);
        // register_activation_hook(__FILE__, ['Checkin_MKT192_Activation', 'add_branch_management_fields']);

        // LEGACY wp_loaded MIGRATIONS - Đã tắt vì spam log và tốn tài nguyên
        // add_action('wp_loaded', ['Checkin_MKT192_Activation', 'add_branch_id_column_to_tables'], 11);
        // add_action('wp_loaded', ['Checkin_MKT192_Activation', 'add_uniform_fee_column'], 12);
        // add_action('wp_loaded', ['Checkin_MKT192_Activation', 'add_branch_ids_column_to_salary_levels'], 12);
        // add_action('wp_loaded', ['Checkin_MKT192_Activation', 'run_inventory_transaction_migration'], 13);
        add_action('wp_loaded', ['Checkin_MKT192_Activation', 'run_migrations_on_update'], 14);

        // Register deactivation hooks
        register_deactivation_hook(__FILE__, [$this, 'deactivate_plugin']);

        // Add custom cron intervals
        add_filter('cron_schedules', [$this, 'add_custom_cron_intervals']);

        // Disable admin bar
        add_filter('show_admin_bar', '__return_false');

        // Load text domain
        add_action('plugins_loaded', [$this, 'load_textdomain']);

        // Ensure OneSignal Service Worker exists
        add_action('init', [$this, 'ensure_onesignal_worker']);

        // Thêm filter chuyển hướng sau khi đăng nhập
        add_filter('login_redirect', [$this, 'custom_login_redirect'], 10, 3);

        // Cập nhật plugin qua GitHub Releases
        add_filter('pre_set_site_transient_update_plugins', [$this, 'check_plugin_update'], 10, 1);
        add_filter('plugins_api', [$this, 'plugin_update_details'], 20, 3);
        add_action('upgrader_process_complete', [$this, 'purge_update_cache'], 10, 2);
    }

    /**
     * Custom login redirect after login.
     *
     * @param string $redirect_to The redirect destination.
     * @param string $requested_redirect_to The requested redirect destination.
     * @param WP_User $user Logged-in user.
     * @return string
     */
    public function custom_login_redirect($redirect_to, $requested_redirect_to, $user) {
        // Nếu user là WP_Error (login failed), giữ nguyên
        if (!($user instanceof WP_User)) {
            return $redirect_to;
        }

        // Nếu có redirect_to cụ thể (đăng nhập từ trang nào → quay lại trang đó)
        if (!empty($requested_redirect_to)) {
            return $requested_redirect_to;
        }

        // Không có redirect_to cụ thể (truy cập wp-login.php trực tiếp)
        // → Admin về wp-admin, staff về user-profile
        if (in_array('administrator', $user->roles, true)) {
            return admin_url();
        }

        return home_url('/user-profile');
    }

    /**
     * Add custom cron intervals.
     *
     * @param array $schedules Existing cron schedules.
     * @return array Modified cron schedules.
     */
    public function add_custom_cron_intervals($schedules) {
        $schedules['every_5_minutes'] = [
            'interval' => 300, // 5 minutes
            'display'  => __('Every 5 Minutes', 'checkin-mkt192'),
        ];
        return $schedules;
    }

    /**
     * Load plugin text domain for translations.
     */
    public function load_textdomain() {
        load_plugin_textdomain('checkin-mkt192', false, dirname(plugin_basename(__FILE__)) . '/languages/');
    }

    /**
     * Ensure OneSignal Service Worker file exists at WordPress root.
     * Based on: https://documentation.onesignal.com/docs/en/web-sdk-reference
     */
    public function ensure_onesignal_worker() {
        // Only check if push notifications are enabled
        if (get_option('checkin_push_enabled', '0') !== '1') {
            return;
        }

        $worker_content = "/**\n * OneSignal Service Worker - Web SDK v16\n * https://documentation.onesignal.com/docs/en/web-sdk-reference\n */\nimportScripts('https://cdn.onesignal.com/sdks/web/v16/OneSignalSDK.sw.js');\n";
        $worker_path    = ABSPATH . 'OneSignalSDKWorker.js';

        // Create file if it doesn't exist or content is different
        if (!file_exists($worker_path) || file_get_contents($worker_path) !== $worker_content) {
            @file_put_contents($worker_path, $worker_content);
        }
    }

    /**
     * Deactivate plugin - cleanup scheduled cron jobs.
     */
    public function deactivate_plugin() {
        // Cleanup log cleanup cron
        require_once CHECKIN_PLUGIN_DIR . 'includes/automation/class-checkin-mkt192-log-cleanup.php';
        Checkin_MKT192_LogCleanup::deactivate();
    }

    /**
     * Lấy manifest cập nhật từ GitHub (cache 6 giờ bằng transient).
     *
     * @param bool $force Bỏ qua cache, fetch mới.
     * @return object|null Manifest object hoặc null nếu lỗi.
     */
    private function get_update_manifest($force = false) {
        $cache_key = 'checkin_mkt192_update_manifest';

        if (!$force) {
            $cached = get_transient($cache_key);
            if (false !== $cached) {
                // Cache lưu chuỗi JSON để tránh lỗi serialize object
                return json_decode($cached);
            }
        }

        $remote = wp_remote_get(
            CHECKIN_UPDATE_API,
            [
                'timeout' => 10,
                'headers' => ['Accept' => 'application/json'],
            ]
        );

        if (is_wp_error($remote) || 200 !== wp_remote_retrieve_response_code($remote) || empty(wp_remote_retrieve_body($remote))) {
            // Cache lỗi trong 30 phút để không dội request khi GitHub trục trặc
            set_transient($cache_key, 'null', 30 * MINUTE_IN_SECONDS);
            return null;
        }

        $body = wp_remote_retrieve_body($remote);
        $data = json_decode($body);

        if (!$data || !isset($data->version) || !isset($data->package)) {
            set_transient($cache_key, 'null', 30 * MINUTE_IN_SECONDS);
            return null;
        }

        set_transient($cache_key, $body, 6 * HOUR_IN_SECONDS);
        return $data;
    }

    /**
     * WordPress gửi ?force-check=1 khi bấm "Kiểm tra lại" ở Dashboard → Cập nhật.
     * Lúc đó bỏ qua cache manifest 6 giờ để site thấy bản mới ngay, không phải chờ.
     * Chỉ đọc cờ, không đổi dữ liệu nên không cần nonce.
     *
     * @return bool
     */
    private function is_force_check() {
        return !empty($_GET['force-check']); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    }

    /**
     * Check for plugin updates from the release channel manifest (manifest.json).
     *
     * @param object $transient The update_plugins transient object.
     * @return object
     */
    public function check_plugin_update($transient) {
        if (empty($transient->checked)) {
            return $transient;
        }

        $remote_data = $this->get_update_manifest($this->is_force_check());
        if (!$remote_data) {
            return $transient;
        }

        $plugin_slug = plugin_basename(__FILE__);
        if (version_compare(CHECKIN_MKT192_VERSION, $remote_data->version, '<')) {
            $update = [
                'slug'         => 'checkin-mkt192-wp',
                'plugin'       => $plugin_slug,
                'new_version'  => $remote_data->version,
                'url'          => $remote_data->homepage ?? 'https://monkeytech192.vn/',
                'package'      => $remote_data->package,
                'tested'       => $remote_data->tested             ?? '',
                'requires'     => $remote_data->requires           ?? '',
                'requires_php' => $remote_data->requires_php       ?? '',
            ];
            $transient->response[$plugin_slug] = (object) $update;
        } else {
            // Báo WP là plugin đã ở bản mới nhất (ẩn thông báo update cũ còn cache)
            $transient->no_update[$plugin_slug] = (object) [
                'slug'        => 'checkin-mkt192-wp',
                'plugin'      => $plugin_slug,
                'new_version' => CHECKIN_MKT192_VERSION,
                'url'         => $remote_data->homepage ?? 'https://monkeytech192.vn/',
                'package'     => '',
            ];
        }

        return $transient;
    }

    /**
     * Cung cấp thông tin cho popup "View details" ở trang Plugins.
     *
     * @param false|object|array $result Kết quả hiện tại.
     * @param string             $action Loại request.
     * @param object             $args   Tham số (chứa slug).
     * @return false|object
     */
    public function plugin_update_details($result, $action, $args) {
        if ('plugin_information' !== $action || empty($args->slug) || 'checkin-mkt192-wp' !== $args->slug) {
            return $result;
        }

        $remote_data = $this->get_update_manifest();
        if (!$remote_data) {
            return $result;
        }

        return (object) [
            'name'           => $remote_data->name ?? 'Checkin MKT192 WP',
            'slug'           => 'checkin-mkt192-wp',
            'version'        => $remote_data->version,
            'author'         => '<a href="https://monkeytech192.vn/">Monkey Tech 192</a>',
            'homepage'       => $remote_data->homepage ?? 'https://monkeytech192.vn/',
            'requires'       => $remote_data->requires     ?? '',
            'tested'         => $remote_data->tested       ?? '',
            'requires_php'   => $remote_data->requires_php ?? '',
            'last_updated'   => $remote_data->last_updated ?? '',
            'download_link'  => $remote_data->package,
            'sections'       => [
                'description' => $remote_data->description ?? 'Plugin điểm danh cho nhân viên',
                'changelog'   => $remote_data->changelog   ?? '',
            ],
        ];
    }

    /**
     * Xoá cache manifest sau khi update plugin xong (lần check sau lấy data mới).
     *
     * @param WP_Upgrader $upgrader Đối tượng upgrader.
     * @param array       $options  Thông tin quá trình update.
     */
    public function purge_update_cache($upgrader, $options) {
        if (($options['action'] ?? '') === 'update'
            && ($options['type'] ?? '') === 'plugin'
            && in_array(plugin_basename(__FILE__), $options['plugins'] ?? [], true)
        ) {
            delete_transient('checkin_mkt192_update_manifest');
        }
    }
}

// Initialize the plugin
Checkin_MKT192_WP::get_instance();
?>
