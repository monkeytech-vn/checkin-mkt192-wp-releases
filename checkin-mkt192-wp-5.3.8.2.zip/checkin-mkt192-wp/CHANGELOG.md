# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [5.3.8.2] - 2026-09-18
### Tính năng mới
- 👥 **Chọn vai trò bị áp phạt đi trễ** (Cài đặt lương → *Phạt đi trễ / về sớm* → *Áp dụng cho vai trò*): pill chọn nhiều vai trò, không chọn gì = áp cho tất cả như trước. Vai trò không được chọn thì **không bị trừ tiền lúc chấm công** và **không xuất hiện trong báo cáo chấm công cuối ngày** (cả ba nhóm: đi trễ, chưa chấm công vào, quên chấm công ra). Chủ VG dùng để loại quản lý và thu ngân ra khỏi danh sách nộp heo. Cột `apply_roles` của bảng `penalty_settings`, tự thêm khi cập nhật plugin.

### Thay đổi
- 🎨 **Modal cài đặt phạt thiết kế lại**: ba khối rõ ràng (*Phạt tiền đi trễ*, *Áp dụng cho vai trò*, *Phạt biên bản*), công tắc kiểu mới có mô tả ngắn, hai nút chọn cách tính tiền phạt (*Một mức cố định* / *Theo số phút trễ*) thay cho công tắc khó hiểu, ô nhập có đơn vị đ / % / lần ngay bên trong.
- 💰 **Số tiền hiển thị theo kiểu Việt Nam**: gõ tới đâu tự chấm phần nghìn tới đó (`50.000` thay cho `50000,00`), bỏ hai số 0 thập phân thừa. Bảng mức phạt theo phút cũng đổi sang định dạng này.

## [5.3.8.1] - 2026-09-18
### Sửa lỗi
- 📅 **Báo cáo cuối ngày chạy trễ sẽ báo nhầm sang ngày mới**: WordPress kích cron bằng lượt truy cập, mà 23:00 tiệm đã đóng nên hook có thể nổ sau nửa đêm; khi đó báo cáo lấy ngày hiện tại (rỗng) thay vì ngày vừa qua. Nay ngày báo cáo tính theo **giờ gửi đã đặt**: chạy trễ qua nửa đêm thì tự lùi về ngày hôm trước, đặt giờ gửi vào buổi sáng thì luôn báo cáo cho ngày hôm trước. Áp dụng cho cả báo cáo chấm công và báo cáo truy thu không ảnh.

## [5.3.8.0] - 2026-09-18
### Tính năng mới
- ⏰ **Báo cáo chấm công cuối ngày qua Lark** (chủ VG yêu cầu), mặc định 23:00 mỗi ngày, ba nhóm: **đi trễ phải nộp heo** (@mention thợ, giờ vào, số phút trễ, tiền phạt), **chưa chấm công vào**, **quên chấm công ra** (giờ vào và ca). Thợ có đơn *Đi trễ/Về sớm* đã duyệt không bị tính nộp heo (duyệt đơn đã đưa tiền phạt về 0); danh sách chưa chấm công vào đã trừ người có đơn nghỉ được duyệt. Ngày sạch vẫn gửi card xanh.
- 🤖 Loại thông báo Lark mới **"Báo cáo chấm công cuối ngày - đi trễ, nộp heo"** (`late_checkin_report`, webhook) và nhóm **Chấm công** trên trang Push Notifications, đủ tiêu đề / nội dung / bảng 4 chỉ số / vai trò nhận push như báo cáo truy thu. Biến: `{date} {late_count} {late_total} {no_checkin_count} {no_checkout_count} {on_duty_count} {penalty_rule} {late_list}`.
- 🕘 **Giờ gửi đổi được ngay trong Push Notifications** cho cả hai báo cáo cuối ngày (ô *Giờ gửi hằng ngày*, giờ Việt Nam). Lưu xong lịch cron tự đặt lại, không cần kích hoạt lại plugin.

### Thay đổi
- 🧾 Báo cáo truy thu hoá đơn không ảnh dời sang **23:05** để không chạy trùng báo cáo chấm công 23:00.

## [5.3.7.6] - 2026-09-18
### Sửa lỗi
- 🧮 **Khối "Bảng chỉ số" không hiện trong modal chỉnh sửa thông báo** (5.3.7.5): hàm dựng 4 ô quên bật lại khối vốn ẩn mặc định, nên sửa nhãn / biến của bảng chỉ số trên card Lark là bất khả. Nay khối hiện đúng với loại thông báo có bảng chỉ số và vẫn ẩn với các loại khác.
- ➕ Mỗi ô có số thứ tự (Ô 1 đến Ô 4) và chú thích khi rê chuột. Bấm một biến ở mục *Biến có thể sử dụng* nay chèn vào **ô vừa bấm** (tiêu đề, nội dung hoặc ô bảng chỉ số) thay vì luôn chèn vào nội dung.

## [5.3.7.5] - 2026-09-18
### Thay đổi
- 🧮 **Bảng chỉ số trên card báo cáo truy thu không ảnh nay chỉnh được** trong Checkin → Push Notifications → thẻ *Báo cáo truy thu không ảnh 23:00*: 4 ô, mỗi ô sửa được **nhãn** và **giá trị** (dùng biến), nhãn để trống thì ẩn ô đó. Mặc định đổi thành **Hoá đơn vi phạm** `{violations}` · **Thợ vi phạm** `{staff_count}` · **Mức truy thu** `{penalty_rule}` · **Dự kiến truy thu** `{total_penalty}đ` (trước là "Hoá đơn trong ngày" và ô vi phạm gộp). Thêm biến `{penalty_rule}` (ví dụ *100% giá trị DV/HC*). Modal chỉnh sửa giờ khớp đúng những gì card gửi đi.
- 🎨 Ghi chú luật cuối card in đậm phần nhãn, in nghiêng phần nội dung, thêm icon cân ⚖️. Mã hoá đơn trong danh sách in đậm thay cho nền code.

## [5.3.7.4] - 2026-09-18
### Thay đổi
- 🧾 **Báo cáo truy thu không ảnh 23:00 có template chỉnh được** ở Checkin → Push Notifications → Hoá đơn (thẻ *Báo cáo truy thu không ảnh 23:00*): công tắc bật/tắt là công tắc chung của báo cáo; tiêu đề + nội dung (biến `{date} {total_invoices} {violations} {staff_count} {total_penalty} {staff_list}`) dùng làm header và dòng tóm tắt của card Lark, đồng thời **push tóm tắt lên điện thoại** cho vai trò đã chọn (mặc định Quản trị viên). Nút Test của trang gửi push mẫu như các thẻ khác.
- 🎨 **Card Lark thiết kế lại gọn hơn**: dòng tóm tắt theo template, 4 chỉ số 2 cột (hoá đơn trong ngày · vi phạm · mức truy thu · dự kiến truy thu), mỗi thợ một khối `@thợ · n HĐ · truy thu X`, từng hoá đơn một dòng mã · giờ · khách · giá trị (mức 100% không lặp lại số tiền). **Bỏ câu "bổ sung ảnh hoặc chọn lý do trước khi chốt lương thì không bị trừ"** theo yêu cầu chủ VG: không du di.

## [5.3.7.3] - 2026-09-18
### Tính năng mới
- 🧾 **Báo cáo truy thu hoá đơn không ảnh lúc 23:00 mỗi ngày qua Lark** (chủ VG yêu cầu): liệt kê hoá đơn trong ngày không có ảnh khách, không chọn lý do và không phải khách vãng lai, **gom theo thợ làm dịch vụ** trên hoá đơn (@mention), mỗi dòng mã HĐ · tên khách · giờ · giá trị · tiền dự kiến truy thu theo Cài đặt lương (VG đang 100% giá trị dịch vụ / hoá chất), có tổng cuối card. Ngày sạch vẫn gửi card xanh ngắn để biết cron còn sống. Bộ lọc dùng đúng luật truy thu không ảnh của module lương (bỏ ghi chú *Hệ thống bù*, lý do hợp lệ, khách vãng lai không phân biệt hoa thường) nên danh sách báo trùng với danh sách sẽ bị trừ khi tính lương.
- 🤖 Loại thông báo Lark mới **"Báo cáo truy thu hoá đơn không ảnh 23:00"** (`no_image_penalty_report`, webhook) trong Cài đặt → Bot Lark. Chưa gán bot thì tự dùng bot *Feedback & Truy thu*, rồi bot *Nhắc nhở upload hình*.
- ⏰ Cron `daily_no_image_penalty_report` chạy 23:00 theo múi giờ WordPress, **tự đăng ký lịch khi chưa có** (site cập nhật plugin không cần kích hoạt lại). Bảng lịch trong activation ghi rõ giờ là giờ server (UTC trên VG), trước đây comment ghi giờ sai lệch.

## [5.3.7.2] - 2026-09-18
### Sửa lỗi
- 🔄 **Nút "Kiểm tra lại" (Dashboard → Cập nhật) nay thấy bản plugin mới ngay**: trước đây plugin cache manifest 6 giờ và nút này không phá được cache, nên sau mỗi lần phát hành phải vào hosting xoá transient thì site mới thấy. Nay khi WordPress gửi `force-check` plugin bỏ qua cache và tải manifest mới. Lịch kiểm tự động vẫn giữ cache 6 giờ như cũ.

## [5.3.7.1] - 2026-09-18
### Thay đổi
- ⏱ **Trang Hoá đơn (app thợ) hiện đủ 2 mốc: giờ TẠO và giờ THANH TOÁN** (chủ VG yêu cầu). Giờ thanh toán lấy từ `paid_at` (set đúng một lần khi hoá đơn chuyển sang đã thanh toán), KHÔNG phải giờ sửa gần nhất. Bảng desktop: cột *Thời gian* tách thành 2 cột **Tạo lúc** và **Thanh toán lúc** (giờ đậm, ngày nhỏ bên dưới; cột thanh toán ghi thêm số phút *17/9/26 · 13 phút*, còn phục vụ ghi *Chưa* vàng). Cột này có trong Cài đặt hiển thị cột (khoá, luôn hiện). Card mobile: bố cục mới, thêm dải timeline riêng dưới dòng dịch vụ - mốc *Tạo* bên trái nối sang mốc *Thanh toán* bên phải; đã thu thì đường nối liền + chấm xanh, còn phục vụ thì gạch đứt + chữ *Chưa* vàng; hoá đơn cũ đã thu nhưng thiếu `paid_at` hiện *Không rõ*. Giữa hai mốc ghim **số phút từ lúc tạo đến lúc thanh toán** (mobile: nhãn tròn cắt ngang đường nối). Modal chi tiết hoá đơn thêm dòng *Thanh toán lúc*.
- 🖼️ **Bảng hoá đơn desktop gọn mắt hơn**: cột Ảnh nới 64px, avatar vuông 38px bo góc (trước bị `.invoice-image` 112px của gallery bóp thành dải dọc trong ô 50px); cột Thao tác nới 150px để 4 nút Mời đánh giá / Gửi lại Zalo / Xoá / Truy thu nằm cùng một hàng thay vì mỗi nút một dòng.
- 🏷️ **Giảm giá trên card mobile bỏ con dấu đè mép card**: đổi sang kiểu giá e-commerce - tạm tính gạch ngang mờ ngay trên tổng tiền, kèm chip *Giảm 10.000 đ* đỏ nhạt nằm cùng hàng chip Tiền mặt / ZNS / Tips. Bảng desktop giữ cột Giảm giá như cũ.

## [5.3.7.0] - 2026-09-10
### Thay đổi
- 🧾 **Khối "Truy thu kỳ này" bố cục mới**: tiêu đề và tổng tiền cùng dòng (canh phải, cùng cỡ chữ); mỗi hoá đơn một hàng 2 cột × 2 dòng - trái: *mã hoá đơn - tên khách* và badge lý do (nền đỏ nhạt, chữ đỏ đậm: *Hoá đơn không ảnh* / *Khách đánh giá thấp* / *Admin truy thu* / *Đã bỏ qua*); phải: ngày và tổng tiền hoá đơn kèm icon **mắt** (mở modal chi tiết hoá đơn: khách, SĐT, ảnh, lý do không ảnh, từng dòng dịch vụ - sản phẩm, dòng đã truy thu) và icon **xoá** (bỏ qua truy thu, admin) hoặc **hoàn** (khôi phục). Bỏ chữ "Bỏ qua" và chữ "Dịch vụ - 840.000". Phiếu trả thêm `invoice_briefs`.
- ✏️ Toàn bộ dấu gạch dài "—" trong giao diện lương / cài đặt / KPI / đồng bộ FB đổi thành "-".

## [5.3.6.9] - 2026-09-10
### Sửa lỗi
- 🚨 **Truy thu không ảnh bắt oan khách vãng lai**: VG lưu tên khách chữ in *"KHÁCH VÃNG LAI"*, code so đúng chữ *"Khách vãng lai"* nên không bỏ qua → Thế Giáp 08/2026 bị trừ 40 hoá đơn (đúng phải 9), Nguyễn Phát 37 (đúng 1). Nay so sánh không phân biệt hoa thường; đã tính lại các phiếu 08 chưa chốt trên VG.

## [5.3.6.8] - 2026-09-10
### Sửa lỗi
- 🧾 **Truy thu tự động không chạy trên VG** (bật cài đặt, làm mới phiếu vẫn không thấy): câu gom hoá đơn không ảnh và đánh giá thấp dùng JOIN `invoices_data` ↔ `invoices_data_detail` / `customer_reviews` theo `invoice_id` — đúng kiểu JOIN trả rỗng trên VG đã gặp ở KPI Google Maps (5.3.6.2). Nay cả hai nhánh lấy mã hoá đơn trước rồi truy `IN (...)`, không JOIN. Thế Giáp 08/2026 có 9 hoá đơn không ảnh vi phạm thật (6 hoá đơn khác mang ghi chú *Hệ thống bù* được bỏ qua).

## [5.3.6.7] - 2026-09-10
### Thay đổi
- ⏳ **Kỳ đang chạy (phiếu tạm tính) KHÔNG áp KPI vào lương**: vẫn đánh giá và hiện thanh tiến trình để thợ theo dõi (gắn nhãn *tạm tính · chưa áp vào lương*), nhưng không trừ % hoa hồng, không cắt thưởng sản phẩm; KPI chỉ áp khi kỳ đã hết (tháng trước trở về). Phiếu tháng 9 trên VG tự trả lại phần −5% đã trừ khi mở lại.
- 💸 **Truy thu kiểu % = trừ khỏi doanh số dịch vụ / hoá chất của hoá đơn trước khi nhân hoa hồng** (Kent chốt): 100% = bỏ hẳn hoá đơn khỏi doanh số như admin truy thu tay, **sản phẩm trên hoá đơn vẫn tính**; dòng admin đã truy thu tay không trừ lần hai. Ví dụ hoá đơn cắt 100k + hoá chất 100k: doanh số cắt 2.100k → 2.000k, hoá chất 1.100k → 1.000k rồi mới nhân %. Lưu dạng `salary_adjustments.kind='base_penalty'` (category service|chemical), không vào Tổng trừ. Kiểu *số tiền cố định* vẫn là phiếu trừ. Hoá đơn kỳ đã trả lương → phiếu trừ = hoa hồng đã trả × %. `kind` mở rộng VARCHAR(20) (db **8.8.0**).
- 🧾 Khối *Truy thu kỳ này* gom theo hoá đơn: *HĐ … · lý do · DV −a · HC −b*, nút **Bỏ qua** gom cả hai dòng của hoá đơn về một dấu bỏ qua; **Khôi phục** tạo lại.
- 🏷️ KPI admin ghi đè tay hiện **"Admin duyệt đạt" / "Admin duyệt không đạt"** thay cho icon bút; nhãn *Đăng bài Facebook* → **Content Fb** trên phiếu và modal KPI.

## [5.3.6.6] - 2026-09-10
### Tính năng mới
- 🧾 **Khối "Truy thu kỳ này" trên phiếu lương ghi rõ từng hoá đơn** (thợ và admin cùng thấy): hoá đơn admin đánh dấu truy thu tay (mã HĐ, ngày, dịch vụ/hoá chất, doanh số bị trừ) và phiếu trừ tự động theo Cài đặt lương (mã HĐ · lý do *khách đánh giá thấp* / *hoá đơn không ảnh* · số tiền, tổng ở tiêu đề). Admin có nút **Bỏ qua** từng hoá đơn (không truy thu, tính lại lương ngay) và **Khôi phục**; hoá đơn đã bỏ qua hiện gạch mờ. API `DELETE vg/v1/salary-adjustments` với phiếu trừ tự động nay đổi thành dấu *bỏ qua* (không mọc lại khi tính lại), gọi lần nữa trên dấu đó = khôi phục. Phiếu trả `penalty_invoices`.

### Sửa lỗi
- 🛡️ Truy thu hoá đơn không ảnh **bỏ qua hoá đơn có ghi chú hệ thống** *"Hệ thống bù: thợ đã tích nhưng bug v5.3.4.3 không lưu"* (thợ đã chọn lý do, hệ thống mất dữ liệu) — VG tháng 8 có hàng chục hoá đơn dạng này, nếu không sẽ bị truy thu oan.
- 🪟 Modal **Xem lịch sử** và **Lương TB** mở từ phiếu lương bị phiếu lương che → nay nổi lên trên.
- ℹ️ Cài đặt truy thu ghi rõ: *100% = trừ toàn bộ giá trị hoá đơn; muốn thu lại đúng hoa hồng thì nhập bằng % hoa hồng dịch vụ của thợ (VD 45)*.

## [5.3.6.5] - 2026-09-10
### Sửa lỗi
- 📘 **Đồng bộ Facebook: popup mở nhưng không hiện đăng nhập** (bản 5.3.6.3 gọi `FB.login` trong callback `getLoginStatus`, không còn là thao tác bấm → trình duyệt chặn cửa sổ đăng nhập). Nay `FB.login` chạy **đồng bộ ngay trong click**; token hết hạn → hỏi SDK lấy phiên mới không cần bấm, không có phiên thì nút đổi thành *"Đăng nhập Facebook để đồng bộ"* để thợ bấm; khi SDK sẵn sàng tự làm mới token nền cho thợ đã kết nối.

## [5.3.6.4] - 2026-09-10
### Thay đổi
- ✂️ Chú thích KPI đăng bài theo ngày công gọn lại: *26 bài / 27 ngày công (KPI theo ngày công)* — bỏ đoạn lặp "· 27 ngày công".

## [5.3.6.3] - 2026-09-10
### Sửa lỗi
- 🔁 **Trang cài đặt admin tự reload về "Ngày OFF đặc biệt" khi bấm tab Thợ ở Lương Nhân Viên** (hiện hộp *Confirm Form Resubmission* khi tải lại). Nguyên nhân: các mục nằm trong `<form method="post">`, còn bộ chặn submit chỉ được gắn **sau khi cả chuỗi fetch khởi tạo xong** (vài giây trên hosting; một fetch lỗi là không bao giờ gắn) — nút tab không có `type="button"` nên bấm là POST cả form. Nay gắn bộ chặn ngay khi trang tải, nút tab và nút sửa/xoá KPI thêm `type="button"`, bỏ qua submit không có nút phát sinh.
- 📘 **Đồng bộ Facebook với user đã từng đồng bộ**: trước luôn gọi `FB.login` kèm `auth_type: 'reauthenticate'` → Facebook bắt nhập lại mật khẩu, trên iPhone nhảy sang web trắng rồi sang app FB, quay về không có phiên → "Bạn cần cấp quyền để đồng bộ Facebook!" (user chưa từng cấp quyền thấy hộp đồng ý bình thường nên vẫn chạy). Nay: token còn dùng → dùng ngay; token hết hạn (lỗi 190/OAuth) → xoá và **tự kết nối lại một lần**; hỏi `FB.getLoginStatus` trước, chỉ `FB.login` thường khi chưa kết nối, `rerequest` chỉ khi thiếu quyền `user_posts`. Bốn đoạn lặp gộp thành một luồng; tab Hôm nay/Tháng này trong popup cũng tự kết nối thay vì chỉ báo lỗi.

## [5.3.6.2] - 2026-09-10
### Sửa lỗi
- ⭐ **KPI Google Maps đếm ra 0 dù thợ có ảnh đánh giá** (Hoàng Huy 08/2026: 30 hoá đơn có ảnh → hiện 0/30 Chưa đạt). Câu đếm JOIN `invoices_data` ↔ `invoices_data_detail` theo `invoice_id` trả rỗng trên VG (hai bảng tạo khác thời điểm, khả năng lệch collation); nay đếm **2 bước** (lấy mã hoá đơn của thợ trong kỳ → đếm hoá đơn có `image_feedback`), không JOIN. Áp cả khi đánh giá và khi hiển thị.
- 🔄 **Tự tính lương kỳ chưa chốt nay đánh giá lại KPI trước** (`maybe_autocompute_salary` → `evaluate_kpi` → tính lương): số KPI trên phiếu tự đúng theo dữ liệu mới, không cần bấm *Xem KPI → Làm mới*; thưởng sản phẩm / trừ % KPI trượt cũng theo kết quả mới. Kỳ đã chốt không đụng.
- 📦 KPI sản phẩm khi đánh giá đếm theo **số lượng** bán (`SUM(quantity)`), khớp với số hiển thị (trước đếm số dòng).
- 🖥️ Ô *Mức* ở cài đặt truy thu bị `display:flex` đè mất `[hidden]` → thêm luật ẩn tường minh cho `.ps-field[hidden]`.
- 🧹 Bỏ cảnh báo PHP `Undefined property: stdClass::$ID` khi tính lương thợ không có `ID`.

### Thay đổi
- 📣 **KPI Đăng bài Facebook có "Cách tính"** (Cài đặt KPI → Sửa/Thêm KPI): **Theo ngày công của thợ** (mục tiêu = N bài mỗi ngày công thực tế; làm 7 ngày, KPI 1 bài/ngày → phải có 7 bài; phiếu lương ghi *7 bài / 7 ngày công (KPI theo ngày công · 7 ngày công)*) hoặc **Số bài cố định trong kỳ** (phải đạt đúng số bài dù làm bao nhiêu ngày). Cột *Cách tính* trong bảng KPI Post FB. `kpi_settings.post_fb_mode` (`count|workdays`), `kpi_results.post_fb_mode` + `working_days` (db **8.7.0**).
  - **Chuyển dữ liệu cũ một lần**: KPI FB đang chạy theo luật cũ "KPI/tháng quy theo ngày công/30" (30 bài/tháng ≈ 1 bài/ngày công) → chuyển sang *Theo ngày công* với mục tiêu = round(KPI/30) bài/ngày công (tối thiểu 1), nên **kết quả đánh giá không đổi** (VG: 30 bài/tháng → 1 bài/ngày công). Kết quả cũ chưa có cách tính hiển thị chú thích *(KPI 30/tháng, quy theo ngày công)*.
- 💸 **Truy thu đánh giá thấp / hoá đơn không ảnh chỉ còn 2 cách tính**: **% giá trị hoá đơn** (phần của thợ trên hoá đơn) hoặc **số tiền cố định / hoá đơn**. Bỏ kiểu *"Truy thu hoa hồng hoá đơn"* (Kent: thừa, và ô mức "100 đ" gây hiểu nhầm). Cài đặt cũ kiểu này → về *% giá trị* với mức 0; **bật mà chưa nhập mức → báo lỗi**, không lưu. Truy thu bù hoá đơn kỳ đã trả cũng theo 2 cách này.
- 🔍 `GET vg/v1/kpi-result?live=1` (admin) trả thêm `live` = số KPI tính trực tiếp từ dữ liệu để đối soát với số đã lưu.

## [5.3.6.1] - 2026-09-10
### Sửa lỗi
- 📊 **KPI hiện đúng số ngay cả với kết quả đánh giá cũ**: kết quả trước 5.3.6.0 chưa lưu số thực tế nên thanh tiến trình rỗng ("—") dù trạng thái Đạt (Hoàng Huy 6 SP / KPI 3). Nay số thực tế tính tại chỗ khi hiển thị nếu chưa lưu.
- ⭐ **KPI Google Maps đếm theo cột `image_feedback` của hoá đơn** (số hoá đơn trong kỳ của thợ có ảnh đánh giá), thay cho bảng `image_feedback` cũ — áp cả khi đánh giá lẫn khi hiển thị.
- 🧾 **Truy thu đánh giá tính theo kỳ của hoá đơn**, không theo ngày đánh giá. Hoá đơn kỳ này → truy thu tại kỳ. Hoá đơn thuộc **kỳ đã trả lương** mà khách đánh giá muộn → **không sửa số liệu kỳ cũ**, tạo khoản *Truy thu bù HĐ … (kỳ MM/YYYY đã trả)* ở kỳ đang chưa thanh toán, giá trị = **hoa hồng đã trả trên hoá đơn đó** (theo % kỳ cũ; hoặc % giá trị / cố định theo kiểu đã chọn). Không nhân đôi khi tính lại; kỳ trước chưa trả thì tính lại kỳ đó sẽ tự truy thu.

### Thay đổi
- 🏷️ Nhãn KPI không đặt mục tiêu: *"Không đặt"* → **"Không yêu cầu"**.
- ⏳ **Hiệu ứng loading nút mới**: giữ nguyên nút và chữ, thêm icon xoay tại chỗ (Làm mới, Lưu thẻ, Thêm phiếu, Lưu cài đặt, Làm mới KPI); bỏ kiểu spinner đè chữ cũ.

## [5.3.6.0] - 2026-09-10
### Tính năng mới
- 🧾 **Truy thu tự động theo cài đặt lương** (chạy mỗi lần tính lương, có dấu vết để gỡ):
  - **Đánh giá thấp** (≤ N★, online + offline theo ngày đánh giá trong kỳ) và **hoá đơn không ảnh** (bỏ qua khách vãng lai; bỏ qua hoá đơn thợ đã chọn lý do *Not Image* nằm trong danh sách lý do hợp lệ admin tick — mặc định mọi lý do trừ "Em quên chụp hình").
  - 3 kiểu áp: **truy thu hoa hồng hoá đơn** (mặc định — đánh dấu truy thu trên dòng dịch vụ/hoá chất của thợ đúng như admin làm tay, đi thẳng vào *Doanh số − Truy thu*), % giá trị hoá đơn, hoặc phạt cố định.
  - Hệ thống chỉ nhận sở hữu hoá đơn nó tự đánh dấu (ghi *marker*); tắt cài đặt hay đổi kiểu → tự gỡ dấu của mình, **không đụng hoá đơn admin truy thu tay**. Phiếu lương liệt kê từng hoá đơn bị truy thu tự động trong callout *Truy thu kỳ này*.
- 📊 **KPI hiện trên phiếu lương + modal Xem KPI**: khối *KPI kỳ này* (4 thanh tiến trình: doanh số dịch vụ, sản phẩm, đăng bài FB quy theo ngày công, đánh giá Google Maps; số thực tế / mục tiêu; Đạt / Chưa đạt). Nút *Đánh giá KPI* → **Xem KPI**: modal thanh tiến trình lớn kèm thưởng/phạt, **Làm mới** (đánh giá lại + tính lại lương), **Sửa** (admin ghi đè Đạt / Không đạt / Tự động từng KPI + ghi chú; phiếu đã chốt không sửa), Đóng. `kpi_results` lưu thêm số thực tế và ghi đè tay (db 8.6.0). API `GET vg/v1/kpi-result` (nhân viên xem của mình), `POST vg/v1/kpi-result/manual`.
- 🔍 Kiểm tra lại số liệu theo cấu hình: phí đồng phục, thẻ hoa hồng kỳ, KPI trừ %, ngưỡng SP, truy thu tự động, phiếu thưởng/trừ đều đã vào công thức; **truy thu đánh giá thấp và không ảnh mặc định TẮT** — admin bật trong *Cài đặt lương*.

## [5.3.5.6] - 2026-09-10
### Sửa lỗi
- 🐛 **Phí đồng phục không được cộng vào Tổng trừ khi tính lại lương** (Xuân Tiến 08/2026: đồng phục 274.000 nhưng Tổng trừ chỉ có 1.000.000 ứng lương). Hàm tính lương thợ và thu ngân nay đọc `uniform_fee` đã có của kỳ và cộng vào Tổng trừ; API cập nhật đồng phục cũng cộng cả phiếu trừ. Đã tính lại các phiếu chưa chốt trên VG (Nguyễn Phát 08/2026: Tổng trừ 0 → 274.000).

### Thay đổi
- 🔒 **Chính sách quyền riêng tư: thêm mục "Yêu cầu xoá dữ liệu cá nhân"** (Meta Platform Terms 4.b): 3 cách yêu cầu (email, gọi/nhắn tiệm, gỡ ứng dụng trên Facebook → callback `vg/v1/fb-deletion-status`), thời hạn 7 ngày làm việc, liệt kê dữ liệu xoá / giữ lại theo luật kế toán, đường dẫn cố định `/privacy-policy#xoa-du-lieu`; bổ sung mô tả dữ liệu nhận từ Facebook (tên, ảnh, email, số bài đăng công khai để đếm KPI).

## [5.3.5.5] - 2026-09-10
### Sửa lỗi
- 🚨 **Kỳ chưa có thẻ hoa hồng (trước khi gom hạng) bị tính theo % tham chiếu của hạng mới** — VG: Hoàng Huy 08/2026 rớt từ 45% xuống 40% (11.172.000 thay vì 12.568.500), Minh Phương 40% thay 45%, Vũ Phương hoá chất 20% thay 45%. Nay khi kỳ không có thẻ, lấy % của **bậc cũ đang áp** (`legacy_level_name` → bảng bậc cũ hoặc đọc mã trong tên). Đã tính lại 5 phiếu 08/2026 chưa chốt trên VG, số về đúng như trước migration; 2 phiếu đã chốt (Xuân Tiến, Bảo Trung) không bị đụng.

## [5.3.5.4] - 2026-09-10
### Sửa lỗi
- 🧾 **Hàng nút modal phiếu lương là footer cố định** của modal (lớp trên, đứng yên), phần phiếu cuộn bên dưới trong khung riêng; bản 5.3.5.3 dùng sticky nên hàng nút trôi theo và đè lên nội dung. Modal giới hạn 92vh (mobile 94vh, bo góc trên, chừa safe-area), nút đóng cố định góc phải trên.

## [5.3.5.3] - 2026-09-10
### Thay đổi
- 🧾 **Modal phiếu lương (admin) = chính cái phiếu**: bỏ khung trắng bên ngoài, nút đóng nhỏ ở góc phải trên của phiếu, **hàng nút thao tác dính đáy** khi cuộn phiếu dài. Đóng modal **không tải lại danh sách** nữa: nếu trong lúc mở có thao tác (làm mới, đồng ý, thanh toán, thẻ hoa hồng, thưởng/trừ) thì chỉ **card của thợ đó** được cập nhật tại chỗ (nháy viền nhẹ) cùng khối tổng quan; không thao tác thì không đụng gì.
- 🪪 Hồ sơ → bấm dòng phiếu lương → **mở modal phiếu ngay** (không đổi kỳ / vẽ lại danh sách).
- 🃏 Danh sách lương admin **3 card / hàng** (2 ở màn vừa, 1 ở mobile), **avatar ảnh thật** của thợ (API lương trả thêm `avatar`); phiếu lương cũng dùng ảnh thật.
- 🎯 **Modal Cài đặt KPI làm lại** theo hệ giao diện phiếu lương: tiêu đề theo loại KPI (dịch vụ / sản phẩm / đăng bài / đánh giá), ô mục tiêu có đơn vị, "Đạt → thưởng" / "Không đạt → phạt", nhân viên chọn bằng **chip** (Chọn tất cả / Bỏ chọn, đếm số đã chọn), khoảng thời gian 2 ô ngày; giữ nguyên id/class nên lưu/sửa/xoá như cũ.

## [5.3.5.2] - 2026-09-10
### Sửa lỗi
- 🐛 Hồ sơ: "tên bậc cũ" của hạng hiện tại ưu tiên **dòng bậc đang active** (lương thật tính theo dòng này) thay vì dòng có ngày mới nhất — VG có thợ được set active ở dòng cũ hơn (Minh Phương: active `Cao cấp 3 (C45_20)` 2023, dòng `Chuyên gia 2 (C50_20)` 2025 không active).

## [5.3.5.1] - 2026-09-10
### Sửa lỗi
- 🐛 **Migration 4 hạng Barber không chạy trên bản deploy ghi file thẳng (VG)**: `run_migrations_on_update` bump db 8.5.0 nhưng lúc đó OPcache còn giữ `salary-api.php` cũ nên `function_exists()` = false → bỏ qua im lặng. Nay migration kiểm tra cờ `checkin_mkt192_barber_tiers_migrated` mỗi lần tải (option autoload) và chạy độc lập với version; thêm `GET vg/v1/salary-diagnostics` (db_version, cờ/nhật ký migration, bảng/cột) và `POST vg/v1/salary-tiers-migrate` (chạy có kiểm soát, `force=1` để chạy lại). Đã chạy trên VG: 8 thẻ hoa hồng giữ nguyên %, 41 dòng lịch sử đổi tên.
- 🐛 Bậc cũ **không có trong bảng cài đặt** (VG: `Cao cấp 8 (C45_45)`, `Sơ cấp 1 (C25_0)`, `Cao cấp 2.5 (45-15)`, bậc thợ phụ `P0_40`) bị migration bỏ sót — nay đọc % thẳng từ mã trong ngoặc.
- 🐛 Hồ sơ: khi gộp các dòng liên tiếp cùng hạng, "tên bậc cũ" lấy dòng đầu thay vì dòng đang active — đã sửa lấy dòng mới nhất.

### Thay đổi
- ⚙️ **Cài đặt phạt gộp vào Cài đặt lương**: mục sidebar riêng bỏ, thay bằng khối *Phạt đi trễ / về sớm* (tóm tắt đang bật/tắt, mức phạt) + nút *Sửa cấu hình* mở modal chứa nguyên form cũ (mọi thao tác/lưu giữ nguyên).
- ⭐ Ngưỡng sao truy thu chọn bằng **dàn 5 huy hiệu sao** (bấm 3★ = truy thu hoá đơn ≤ 3★) thay ô select.
- 🪪 **Nhân viên tự xem hồ sơ & lịch sử của mình**: nút *Lịch sử công việc* trên trang phiếu lương mở cùng modal hồ sơ (hạng, hoa hồng, lịch sử cấp bậc/hoa hồng, 12 phiếu lương); API `staff-profile` cho phép xem hồ sơ chính mình (`staff_name=me`), hồ sơ người khác vẫn cần quyền tính lương.
- 🔗 Bấm một dòng phiếu lương trong hồ sơ → **mở thẳng phiếu lương** đó (admin: modal phiếu; nhân viên: chuyển kỳ trên trang phiếu lương).

## [5.3.5.0] - 2026-09-10
### Tính năng mới
- 🏷️ **4 hạng Barber thay cho bậc lương** (db 8.5.0): *Barber Thử Việc → Barber Chính Thức → Barber Chuyên Nghiệp → Barber Master*. Hạng là danh hiệu ghi vào hồ sơ; **hoa hồng không còn phụ thuộc hạng** mà theo thẻ từng kỳ. Migration một lần: mỗi thợ đang hoạt động chưa có thẻ được tạo **thẻ hoa hồng kỳ hiện tại với đúng % bậc cũ** (lương không đổi), toàn bộ lịch sử bậc đổi tên theo % dịch vụ cũ (0% → Thử Việc · <40% → Chính Thức · ≥40% → Chuyên Nghiệp; **Vũ Phương → Master**), tên bậc cũ giữ ở `legacy_level_name`; bảng bậc thợ thay bằng 4 hạng, bậc lương giờ thu ngân giữ nguyên. Nhật ký migration lưu ở option `checkin_mkt192_barber_tiers_migration_log`.
- ⚙️ **Trang "Cài đặt lương" toàn salon** (thay "Setting lương theo cấp bậc"): kỳ thanh toán (theo tháng; theo tuần đánh dấu *sắp có*), **nhân viên xem tạm tính ngay hay ẩn đến ngày N tháng sau** (admin luôn xem được), **truy thu đánh giá thấp** (chuyển từ modal Thưởng/Trừ ra đây, áp mọi kỳ), **mặc định thẻ hoa hồng mới** (% SP, ngưỡng SP, % tăng ca, KPI bắt buộc, mức/phạm vi/cách trừ), công tắc *KPI tự đổi cấp bậc* (mặc định tắt). API `GET/POST vg/v1/salary-settings`. Mục sidebar "Bậc lương giờ" (thu ngân) mở từ trang Cài đặt cấp bậc.
- 🪪 **Hồ sơ nhân viên kiểu HRM** (nút 🪪 ở danh sách Nhân viên và trên card lương): thông tin công việc (mã NV, ngày gia nhập, hạng hiện tại, đổi hạng lần cuối, hoa hồng kỳ này, chấm công tháng), **timeline lịch sử cấp bậc** (kèm tên bậc cũ), **timeline lịch sử hoa hồng** (mỗi lần đổi thẻ: DV 45% → 50%, ngưỡng SP…, ai sửa, khi nào), 12 phiếu lương gần nhất bấm mở. API `GET vg/v1/staff-profile`.
- 🃏 **Bảng lương admin → card từng nhân viên** chuẩn mobile: tổng thực nhận toàn salon + số phiếu theo trạng thái ở đầu; mỗi card có tên, hạng, % hoa hồng đang áp, badge trạng thái, thực nhận, tổng lương/khấu trừ/ứng, số phiếu thưởng-trừ, chấm công (công · trễ · phép · tăng ca); bấm card mở phiếu lương, nút 🪪 mở hồ sơ. Kỳ chưa có dữ liệu hiện nút *Tính lương kỳ này*.

### Sửa lỗi
- 🐛 **Đánh giá KPI làm nhân viên mất bậc**: hàm đánh giá KPI reset `is_active` của mọi bậc rồi mới kiểm tra cài đặt KPI — thợ không có cài đặt KPI hợp lệ bị `continue` ngay sau đó và **mất bậc đang active**. Nay toàn bộ cơ chế KPI đổi bậc chỉ chạy khi bật công tắc trong Cài đặt lương (mặc định tắt); kết quả KPI vẫn được ghi.
- 🐛 Nút đóng dính trên modal phiếu lương kéo theo **thanh kính full chiều ngang** che nội dung khi cuộn — nay chỉ còn nút đóng nổi, thanh trong suốt, không bắt sự kiện.
- 📱 App thợ: "Lương tạm tính" lấy **% từ phiếu lương kỳ hiện tại** (thẻ hoa hồng, đã trừ KPI) thay vì đọc % của bậc; hết cảnh sai số khi bậc đổi tên.

## [5.3.4.8] - 2026-09-10
### Tính năng mới
- 🎁 **Phiếu thưởng / phiếu trừ theo kỳ lương** (bảng `salary_adjustments`, db 8.4.0) — admin bấm chip *Thưởng / Trừ* trên phiếu thợ hoặc thu ngân: chọn loại (*Thưởng nóng · Thưởng lễ/Tết · Thưởng KPI* | *Đồng phục · Phạt vi phạm · Bồi thường*), nhập đơn giá × số lượng (thành tiền tự tính, sửa tay được), ghi chú. Thưởng cộng vào **Tổng lương**, trừ cộng vào **Tổng trừ**; phiếu lương liệt kê từng phiếu với đơn giá × số lượng. Ảnh chụp lưu ở `adjustments_json`, phiếu đã chốt không thêm/xoá được (409). API `GET/POST/DELETE vg/v1/salary-adjustments`.
- ⭐ **Truy thu tự động khi khách đánh giá thấp** — cài đặt toàn salon trong cùng modal (thợ): bật/tắt, ngưỡng sao (mặc định ≤ 3★), tính theo **% giá trị hoá đơn** hoặc **phạt số tiền cố định**. Mỗi lần tính lương, hệ thống sinh lại phiếu trừ `review` cho từng hoá đơn bị chấm thấp trong kỳ (review online + offline), ghi rõ *Đánh giá 2★ · HĐ … · truy thu 50%*. API `GET/POST vg/v1/salary-review-penalty`.
- 🔁 **Trượt nhiều KPI: chọn trừ một lần hay cộng dồn** — thẻ hoa hồng thêm *Trượt nhiều KPI → Trừ một lần (mặc định) / Cộng dồn theo số KPI trượt* (`kpi_penalty_mode`).

### Thay đổi
- 🧴 **Ngưỡng sản phẩm đếm theo số sản phẩm**, không đếm dòng hoá đơn: một dòng bán 3 chai = 3 (`product_count_total` nay là tổng `quantity`). Kent chốt 09/2026.
- 🔒 **Kỳ đã trả lương: thẻ hoa hồng chỉ xem**, modal nói rõ "thay đổi chỉ áp từ kỳ sau" và có nút *Mở thẻ kỳ sau*.

## [5.3.4.7] - 2026-09-08
### Sửa lỗi
- 🐛 **Phiếu lương thợ hiện "Hoa hồng dịch vụ 0% · hoá chất 0%" dù tiền lương tính đúng** — bảng lương chỉ lưu số tiền, không lưu % đã áp; phiếu lương đoán % bằng cách đọc mã trong tên bậc theo mẫu `C45_15`. Bậc đặt tên tự do kiểu `Cao cấp 2.5 (45-15)` không khớp mẫu nên ra 0%, trong khi backend vẫn lấy đúng 45%/15% từ cài đặt bậc. Nay API `hairdresser-salary-data` trả thêm `service_commission_percent`, `chemical_commission_percent`, `product_commission_percent`, `overtime_commission_percent` (suy từ tiền đã trả / doanh số của chính kỳ đó — đúng với số thợ thực nhận kể cả khi cài đặt bậc đổi sau này; doanh số 0 thì lấy cài đặt bậc), kèm `level_service_percent`/`level_chemical_percent` (cài đặt bậc hiện tại), `product_bonus_source` (`kpi` / `kpi_failed` / `default`) và `penalty_amount`. Phiếu lương không còn đoán từ tên bậc.

### Thay đổi
- 🎨 **Thiết kế lại phiếu lương thợ và thu ngân** — bố cục đọc từ trên xuống theo đúng cách thợ hỏi: *tháng nào · ai · trạng thái* → **Thực nhận** thật to kèm phép trừ *Tổng lương − Khấu trừ* → **Thu nhập** từng khoản có công thức ngay dưới (`27.930.000 đ × 45%`, có truy thu thì hiện `(doanh số − truy thu) × %`) → **Khấu trừ** → callout **Truy thu** chỉ hiện khi có. Khoản 0 đ làm mờ để mắt tập trung vào khoản có tiền; ghi chú KPI sản phẩm (áp % KPI / không đạt) hiện ngay dưới dòng bán sản phẩm. Nút thao tác đổi sang phẳng, một hệ màu (chính = xanh đậm, nhận đủ = xanh lá, xét lại = vàng). Chứng từ thanh toán xếp lưới, bấm mở ảnh gốc. Class cũ (`.salary-section`, `.card-field`…) giữ nguyên cho modal lịch sử.
- 🧹 Bỏ log `=== SALARY DATA DEBUG ===` in ra console mỗi lần mở phiếu lương.
- 🔘 **Nút trên phiếu lương: cái cần bấm mới là nút, trạng thái thành badge** — bỏ hẳn các "nút" bị khoá kiểu *Chờ xác nhận / Đã thanh toán / Thanh toán xong*; trạng thái là badge ngắn cạnh tên nhân viên (*Chờ xác nhận · Xin xét lại · Đã xác nhận* — phía nhân viên hiện *Chờ thanh toán* · *Đã thanh toán · Đã nhận đủ*). Header phiếu xếp 2 hàng thẳng nhau: "PHIẾU LƯƠNG" ⟷ kỳ lương, tên ⟷ badge; dòng bậc bên dưới chạy hết chiều ngang. Nút chỉ hiện đúng thời điểm: nhân viên thấy **Đồng ý phiếu lương** + *Xin xét lại* khi chưa phản hồi, còn **Đã nhận đủ lương** chỉ hiện sau khi admin đã tải chứng từ thanh toán (trước đây hiện ngay khi vừa đồng ý). Admin thấy *Làm mới / Đánh giá KPI* khi phiếu chưa được đồng ý (kể cả đang xin xét lại — trước đây bị khoá, không tính lại được), **Thanh toán lương** khi nhân viên đã đồng ý. Hai nút tra cứu *Xem lịch sử / Lương TB* thành chip nhỏ.
- 📄 **Trang phiếu lương riêng cho nhân viên** — bấm "Xem lương" ở trang cá nhân (hoặc thẻ *Lương tạm tính* trong App Thợ, hoặc link `/user-profile?view=salary`) mở thẳng trang phiếu lương, không còn popup + 2 ô chọn năm/tháng + nút "Xem lương" lần hai. Dải chip 12 kỳ gần nhất, **mặc định kỳ hiện tại**, chạm là tải; URL nhớ kỳ đang xem, nút Back của điện thoại quay về hồ sơ.
- ⚙️ **Lương tự nhảy, không đợi admin bấm "Tính lương"** — khi nhân viên mở phiếu **kỳ hiện tại hoặc kỳ liền trước** mà phiếu chưa chốt (chưa Đồng ý, chưa có chứng từ), server tự tính lại theo hoá đơn/chấm công mới nhất rồi mới trả về (giới hạn 1 lần/2 phút mỗi người mỗi kỳ; chỉ chính nhân viên đó hoặc người có quyền tính lương mới kích được). Phiếu đã chốt không bao giờ bị tính lại. API `cashier-salary-data` trả thêm `period`; `update-cashier-salary` nhận `staff_name` để tính riêng một người.
- 🗓️ **Chọn kỳ lương bất kỳ** — bộ chọn *Tháng ▾ · Năm ▾* nằm ngay dưới tiêu đề "PHIẾU LƯƠNG" của phiếu (thay dòng "Tháng 09/2026" tĩnh), năm lùi được 5 năm, đổi là tải ngay; kỳ không có phiếu thì bộ chọn đậu ở thanh trên để vẫn đổi được. Thanh trên chỉ còn nút *← Hồ sơ*, không lặp tiêu đề + tên thợ hai lần. Header logo và thanh điều hướng của trang cá nhân giữ nguyên.
- 📊 **Đầu phiếu kiểu app native** — 4 ô *Ngày công · Nghỉ phép · Đi trễ (kèm tổng phút) · Tăng ca* (API trả thêm `attendance` từ chấm công, đơn nghỉ phép đã duyệt, hoá đơn/đơn tăng ca) và hàng chip hoa hồng đủ loại *DV · HC · SP (≥N SP) · TC*, có ghi *−5% KPI* ngay trên chip khi bị trừ. Bậc + ngày lên bậc gom vào dòng dưới tên thợ.

### Tính năng mới
- 🎫 **Thẻ hoa hồng theo kỳ lương — không còn phụ thuộc cấp bậc** (bảng `salary_period_rates`, db 8.3.0). Mỗi thợ mỗi kỳ có một thẻ: % dịch vụ, % hoá chất, % sản phẩm + **ngưỡng bán từ N sản phẩm mới hưởng**, % tăng ca, **KPI bắt buộc** (đánh giá Google Maps / đăng bài FB / dịch vụ / sản phẩm) và **mức trừ khi trượt KPI** (trừ 1 lần dù trượt nhiều KPI, chọn trừ trên dịch vụ / hoá chất / cả hai — chỉ áp khi kỳ đã "Đánh giá KPI"). Kỳ sau **không có thẻ riêng thì kế thừa** thẻ kỳ trước (hệ thống ghi bản sao `carried` để lịch sử đóng băng); thợ chưa có thẻ nào vẫn tính **theo bậc như cũ**, kết quả các site hiện tại không đổi cho tới khi admin tạo thẻ đầu tiên.
- 🧾 **Admin sửa hoa hồng ngay trên phiếu lương** — chip *Hoa hồng kỳ* trên phiếu thợ mở modal thẻ: form điền sẵn từ thẻ kỳ trước hoặc bậc, tick *Áp cho tất cả thợ kỳ này*, *Lưu & tính lại lương* — lương kỳ đó tính lại ngay. *Xoá thẻ kỳ này* để quay về kế thừa. Phiếu đã chốt (thợ đã đồng ý / đã thanh toán) → thẻ chỉ xem, API trả `409 salary_locked`. API: `GET/POST/DELETE vg/v1/salary-period-rates` (scope `salary.calculate`).
- 🔍 **Phiếu lương nói rõ vì sao ra số đó** — bảng lương thợ lưu ảnh chụp thẻ đã áp (`hairdresser_salary.rates_json`), phiếu hiện `27.930.000 đ × 40% (45% − 5% KPI đăng bài)`, callout *Không đạt KPI kỳ này*, và *Cần bán từ 3 sản phẩm mới hưởng 10%* khi chưa đủ ngưỡng. Meta đầu phiếu đổi thành *Hoa hồng kỳ này* kèm *(kế thừa 07/2026)* nếu là thẻ thừa kế.

## [5.3.4.6] - 2026-09-08

### Thay đổi

- 🔗 **Kênh cập nhật trỏ thẳng tên tổ chức GitHub mới** — tổ chức đã đổi tên `monkeytechvn` → `monkeytech-vn`; trước đó plugin vẫn gọi địa chỉ cũ và chỉ chạy được nhờ chuyển hướng tự động của GitHub. Nay `CHECKIN_UPDATE_API`, `bin/release.sh` và workflow phát hành đều dùng địa chỉ mới, không còn phụ thuộc chuyển hướng.
- 🤖 **Phát hành tự động chạy lại được** — deploy key của kênh phát hành đã chết sau khi tổ chức đổi tên, khiến hai bản 5.3.4.4 và 5.3.4.5 phải đóng gói và đẩy tay. Đã thay khoá mới nên từ bản này, đẩy tag `v*` là GitHub Actions tự đóng gói zip, cập nhật `manifest.json` và tự kiểm tra lại gói mà khách sẽ tải.

## [5.3.4.5] - 2026-09-07

### Thay đổi

- 🗂️ **Giữ lại `update_invoice.log`, không xoá theo chu kỳ nữa** — cron dọn log 2 ngày/lần trước đây xoá sạch mọi file `.log` (chỉ chừa `cleanup_history.log`), nên mất luôn nhật ký sửa hoá đơn — đúng thứ cần để đối chất khi thợ báo "em có tích lý do rồi". Nay `update_invoice.log` nằm trong danh sách giữ lại; để không phình vô hạn, file quá 20MB sẽ bị cắt bỏ nửa cũ và ghi dấu mốc cắt, giữ nguyên các bản ghi mới.

## [5.3.4.4] - 2026-09-07

### Sửa lỗi

- 🐛 **Thợ tích "Not Image" trên hoá đơn đã thanh toán thì lý do không được lưu, mà app vẫn báo thành công** — API cập nhật hoá đơn chỉ cho sửa `payment_method`, `combined_payment_details`, `tips`, `total` khi hoá đơn ở trạng thái `paid`; `not_image` nằm ngoài danh sách nên bị bỏ qua **im lặng** rồi vẫn trả về `success`. Trong khi đó nút "Not Image" ở màn chi tiết hoá đơn **chỉ hiện với hoá đơn đã thanh toán** — tức mọi lần thợ tích bù sau ca đều mất trắng, app vẫn hiện "Đã gửi lý do thành công!". Nay `not_image` được phép ghi cả khi hoá đơn đã thanh toán.
- 🚨 **Không còn "nuốt" dữ liệu trong im lặng** — nếu mọi trường client gửi lên đều bị từ chối vì hoá đơn đã thanh toán, API trả lỗi `409 invoice_locked_paid` kèm tên trường bị chặn thay vì báo thành công; các trường bị từ chối cũng được ghi vào `update_invoice.log` để còn truy vết. App thợ hiện đúng thông báo lỗi của server thay vì câu chung chung.
- 🎯 **Nút "Not Image" trong modal chi tiết ghi nhầm hoá đơn** — nút này đọc hoá đơn đang active ở màn thanh toán (`invoices[currentInvoiceIndex]`) chứ không phải hoá đơn đang mở trong modal, nên lý do có thể rơi sang hoá đơn khác. Nay hoá đơn được chốt ngay lúc mở hộp thoại và truyền thẳng vào.
- 🧹 **Hộp thoại chọn lý do không xoá lựa chọn cũ** — mở lại cho hoá đơn khác vẫn còn tick của lần trước, dễ gửi nhầm lý do. Nay reset toàn bộ mỗi lần mở, và khoá nút "Gửi" trong lúc đang gửi để tránh bấm hai lần.

## [5.3.4.3] - 2026-08-02

### Sửa lỗi

- 🐛 **Thanh nút ở form đặt lịch để nền trong suốt nên nội dung lòi lên đè vào nút** — `.button-container` dính đáy (`position: sticky`) nhưng `background: transparent`, nên khi nội dung dài hơn khung modal thì chữ phía sau hiện xuyên qua và chồng lên nút. Nay đổi sang nền mờ dần về màu modal để nội dung cuộn chui gọn xuống dưới. Lỗi có sẵn từ trước, lộ ra rõ khi thông báo thợ tạm dừng dài 3 dòng.

## [5.3.4.2] - 2026-08-02

### Thay đổi

- 🚫 **Thợ tạm dừng: chặn đặt lịch ngay trong form, kèm SĐT liên hệ riêng** — Bỏ nhãn "Tạm dừng" và nút gọi ở thẻ thợ ngoài trang chủ. Thay vào đó, khi khách chọn thợ tạm dừng trong form Đặt Lịch, dòng trạng thái đổi thành *"Thợ … hiện không còn hoạt động tại Shop. Quý khách vui lòng liên hệ … để đặt lịch riêng. Xin cảm ơn."* và **nút "Tiếp Theo" bị khoá**. Chọn thợ khác thì mọi thứ hoạt động như cũ. Nếu thợ chưa nhập SĐT, thông báo mời khách liên hệ Shop.

## [5.3.4.1] - 2026-08-02

### Thay đổi

- 🧑‍🔧 **Làm rõ ý nghĩa các trạng thái thợ, không thêm trạng thái mới** — Nhãn trong ô chọn ở trang Cài đặt nhân viên nay ghi rõ: `PAUSE — tạm dừng (vẫn nhận đặt lịch, hiện SĐT)`, `ARCHIVED — nghỉ việc (ẩn khỏi trang chủ)`, `DELETED — xoá khỏi danh sách`, kèm `ON/OFF/BUSY`. Giá trị lưu trong CSDL giữ nguyên nên dữ liệu cũ không bị ảnh hưởng.
- 📞 **Thợ tạm dừng hiện lại ở trang chủ kèm số điện thoại** — Trước đây `PAUSE` bị ẩn khỏi trang chủ. Nay thợ tạm dừng vẫn nằm trong lưới giới thiệu và vẫn đặt lịch được, có nhãn "Tạm dừng" và nút gọi nhanh để khách trao đổi trước. Khi chuyển thợ sang tạm dừng, hệ thống hỏi số điện thoại (không bắt buộc).
- 🗄️ **Thợ nghỉ việc (`ARCHIVED`) ẩn hoàn toàn khỏi trang chủ** — Giữ nguyên như trước, phù hợp cả với tài khoản quản trị không có ảnh đại diện.

### Sửa lỗi

- 🐛 **App thợ vẫn hiện thợ đã nghỉ việc khi chọn thợ cho dịch vụ** — Bộ lọc chỉ loại `OFF` và `DELETED` nên thợ `ARCHIVED` vẫn nằm trong danh sách. Nay gom về một hàm dùng chung loại `OFF`, `ARCHIVED`, `DELETED`; áp dụng cho modal chọn thợ, danh sách thợ ở dịch vụ và ô bàn giao ca. `PAUSE` vẫn chọn được vì thợ tạm dừng còn nhận việc.
- 🐛 **Đơn nghỉ phép cũ ghi đè mất trạng thái tạm dừng** — Trang chủ có đoạn tự ép trạng thái về `OFF`/`ON` theo đơn nghỉ phép; nay bỏ qua thợ đang tạm dừng.

### Ghi chú kỹ thuật

- Thêm cột `phone` vào bảng nhân viên (migration tự chạy khi cập nhật, `db_version` 8.2.0). Bản 5.3.4.0 phát hành nhầm theo thiết kế cũ (thêm trạng thái `RESIGNED`) đã bị thay thế bằng bản này; nếu site nào lỡ cài 5.3.4.0 thì các cột thừa để lại không gây ảnh hưởng.

## [5.3.3.2] - 2026-08-02

### Sửa lỗi

- 🐛 **Nút "Xác nhận đã thanh toán" bị thanh điều hướng dưới của app thợ che mất** — Modal thanh toán để `z-index: 100` trong khi `.bottom-nav` là `950`, nên phần cuối modal luôn nằm dưới thanh bar và không bấm được, cuộn cũng không tới. Nâng modal lên `z-index: 999` (đúng mức các modal khác trong app) để nó nằm trên thanh bar; kèm chừa `env(safe-area-inset-bottom)` để nút không dính vạch home trên iPhone. Modal vẫn cuộn được bên trong như bản trước.
- 🐛 **Modal thêm/sửa khách hàng cũng bị che tương tự** — Cùng nguyên nhân (`z-index: 100`), đã nâng lên `999`.

## [5.3.3.1] - 2026-08-02

### Cải tiến

- 🔄 **Kênh cập nhật chuyển sang tài khoản GitHub mới (`monkeytechvn`)** — Hằng `CHECKIN_UPDATE_API` trỏ thẳng vào repo phát hành ở chủ mới thay vì dựa vào redirect của GitHub. Site đang chạy bản cũ vẫn nhận được bản này bình thường (URL cũ được GitHub chuyển hướng), cập nhật xong là dùng URL mới.
- ⚙️ **Phát hành tự động bằng GitHub Actions** — Đẩy tag `v*` là tự đóng gói zip, đẩy lên kênh phát hành và sửa `manifest.json` (version, link tải, ngày, changelog). Có bước kiểm tra cuối: tải thử đúng file zip mà site khách sẽ tải và mở ra đối chiếu version, sai là workflow báo đỏ chứ không để kênh update hỏng âm thầm.

## [5.3.3.0] - 2026-08-02

### Cải tiến

- 🔍 **Mã QR thanh toán trong app thợ to hơn ~2,1 lần, khách dễ quét hơn** — Ảnh QR trước đây bị ép vào khung vuông `150×150` kèm `object-fit: contain`, trong khi ảnh VietQR có tỉ lệ dọc (540×640, có logo trên và thông tin tài khoản dưới) nên ô QR thật chỉ còn ~87px. Nay ảnh co giãn theo bề ngang modal (tối đa 300px desktop / 320px mobile), chiều cao tự động theo đúng tỉ lệ và có trần theo chiều cao màn hình để máy nhỏ tự thu vừa: ô QR thật đạt ~186px trên máy 812px, ~155px trên iPhone SE.
- 🔧 **Bỏ `!important` khoá kích thước ảnh QR** — Rule responsive cho mobile (`max-width: 640px`) trước đây không bao giờ có tác dụng vì bị `!important` của rule gốc đè lên, nên mọi máy đều hiển thị 150px.

### Sửa lỗi

- 🐛 **Modal thanh toán bị cắt mất nút "Xác nhận đã thanh toán"** — Modal để `overflow: hidden` và không giới hạn chiều cao nên khi nội dung dài hơn màn hình (QR + nội dung CK + khối tự động kiểm tra MonkeyPay) phần cuối bị cắt, thợ không bấm được nút xác nhận. Nay modal giới hạn chiều cao theo màn hình (`100dvh`, fallback `100vh`) và cuộn được bên trong (`overscroll-behavior: contain` để không kéo trôi trang nền). Lỗi này đã tiềm ẩn từ trước trên máy nhỏ (iPhone SE) khi bật MonkeyPay.

## [5.3.2.9] - 2026-07-09

### Cải tiến

- 📐 **Các section trang home vừa khít 1 màn hình (desktop ≥769px)** — Mỗi section `min-height: 100dvh` + flex căn giữa dọc; token spacing/typography fluid bằng `clamp()` (khoảng cách section, tiêu đề, mô tả, grid gap co giãn theo viewport). Ảnh About ghìm `max-height: min(72vh, 620px)`, ảnh service card cố định tỉ lệ 16:9 tối đa 22vh, bản đồ liên hệ cao theo `clamp(320px, 48vh, 560px)`; gỡ các override px cũ trong media query. About/Features/Gallery/Team hiển thị trọn 1 màn hình; Services/Contact giữ cuộn nhẹ có chủ ý để ảnh/bản đồ đẹp.
- ❓ **Section FAQ mới trên trang home** — 6 câu hỏi–đáp phù hợp barbershop (đặt lịch, thời gian cắt, chọn thợ, chỉnh lại kiểu, giá, chuyển khoản) dạng accordion: mở 1 câu tự đóng câu khác, mũi tên xoay + viền đổi màu accent, animation mở/đóng mượt theo `scrollHeight` (không giật), tôn trọng `prefers-reduced-motion`, đồng bộ dark theme + màu thương hiệu động.
- 🔁 **Hero loop-replay** — Cuộn hết trang rồi cuộn tiếp sẽ quay về đầu trang và replay hero ngược (nhân vật zoom-out về vị trí ban đầu, chữ/nút fade vào) nối liền header, hỗ trợ cả wheel và chạm (mobile); tắt hẳn khi `prefers-reduced-motion`.
- 🎨 **Nút "Đặt lịch ngay!" ở card thợ đồng bộ với nút hero** — Nền accent đặc chữ tối, bo góc 14px, đổ bóng theo màu thương hiệu, hover nâng nhẹ + sáng màu, active nén lại.

### Sửa lỗi

- 🐛 **Bottom bar app thợ trôi lên giữa màn hình khi cuộn (iOS)** — Khi focus ô nhập có chữ <16px (vd. tìm kiếm hoá đơn), iOS Safari tự phóng to trang và giữ mức zoom sau khi tắt bàn phím → mọi phần tử `position: fixed` (header, bottom bar) neo theo layout viewport và trôi theo nội dung khi cuộn. Fix: trên iOS tự đặt `maximum-scale=1` cho mọi thẻ meta viewport ngay khi script load (chặn auto-zoom; vẫn cho pinch-zoom thủ công, Android không ảnh hưởng); ép bar lên compositing layer riêng (`translateZ(0)`) tránh vẽ trễ khi cuộn quán tính.
- 🐛 **Nút "Dịch vụ" ở header trang home không cuộn tới section** — Link bị typo `#ervices-widget-menu` (thiếu chữ `s`) → sửa thành `#services-widget-menu`.
- 🐛 **Icon 2 card thống kê (1000+/100+) lệch hàng nhau** — Card nén chiều cao dùng `justify-content: center` làm card ít dòng chữ đẩy icon lệch; đổi về `flex-start` để icon luôn thẳng hàng trên cùng.
- 🖼️ **Ảnh hero tự bust cache theo `filemtime`** — Đổi ảnh trong `uploads/checkin-mkt192-wp/home/hero/` là hiển thị ảnh mới ngay, không cần xoá cache trình duyệt.

## [5.3.2.8] - 2026-07-08

### Cải tiến

- ✨ **Hero trang home mới — showcase kiểu tóc theo cuộn (kiểu editorial/cinematic)** — Vào trang có hiệu ứng tách lớp + fade nhân vật nam ngồi ghế (nền trong suốt); tên shop chữ lớn bên trái canh ngang đầu nhân vật, tagline `💈 Tóc Đẹp Cho Quý Ông 💈`. Cuộn chia **3 nhịp**: nhịp 1 nhân vật phóng to + trôi vào giữa, nhịp 2 & 3 tự đổi sang kiểu tóc 2 và 3; cuộn đủ 3 nhịp mới rời hero, cuộn ngược lên trả về đúng thứ tự. Bám cuộn liên tục bằng transform (GPU) nên mượt, có `prefers-reduced-motion`. Dãy 3 thumbnail kiểu tóc: desktop nằm dọc bên phải; mobile nằm dọc bên trái lúc nghỉ và **dồn thành hàng ngang trên đầu nhân vật khi phóng to**.
- 🖼️ **Ảnh hero tách khỏi plugin** — 3 ảnh nhân vật + 3 ảnh mẫu tóc đọc từ `wp-content/uploads/checkin-mkt192-wp/home/hero/` (không đóng gói vào plugin để zip nhẹ, đổi ảnh không cần cập nhật code).
- 📐 **Header thu gọn + full-width** — Header cao ~63px, dính sát đỉnh; chống theme block-editor ép `max-width`/khoảng trống lên header/menu/preloader của plugin.

### Sửa lỗi

- 🐛 **Nút gradient bị fix cứng màu (đen→vàng gold)** — `.btn-primary` trong `home-booking-modern.css` hard-code `linear-gradient(#000→#ffd700)` đè lên màu động, load sau nên thắng. Đã trả về `var(--gradient-primary)` = màu **primary/secondary lấy từ trang Cài đặt thương hiệu** (đổi màu trong wp-admin là nút đổi theo, không còn fix cứng).

## [5.3.2.7] - 2026-07-07

### Cải tiến

- 🎨 **Redesign toàn bộ trang admin WordPress (9 trang)** — Bỏ header tím gradient → header trắng flat, logo tile xanh, tab active dạng pill; palette phẳng đồng bộ với app (`#0071E3`/`#34C759`/`#FF9500`/`#FF3B30`), flatten toàn bộ gradient. Định nghĩa 17 CSS token bị thiếu từ trước (`--checkin-border-color`, `--checkin-spacing-*`, bo góc...) khiến card mất viền, layout dính nhau; thêm bộ nút `.checkin-btn-primary/secondary/link` global (trước chưa từng được định nghĩa). Header thu gọn 1 dòng không vỡ chữ; tiêu đề trang có icon tile, nút hành động cùng hàng.
- 📊 **Dashboard admin WP dùng dữ liệu thật 100%** (bỏ số liệu giả) — 4 thẻ: lịch hẹn hôm nay, doanh thu tháng (so **cùng kỳ** tháng trước), hóa đơn tháng, khách hàng + khách mới; dải "Cần chú ý" (đơn xin phép chờ duyệt, hóa đơn chưa thanh toán, giao dịch kho 30 ngày); biểu đồ doanh thu 7 ngày CSS thuần; đánh giá 30 ngày (gộp offline+online); **Top 5 thợ theo doanh thu tháng** (fix lỗi `Illegal mix of collations` khi join 2 bảng hóa đơn làm query chết êm); hoạt động gần đây thật (lịch hẹn/thanh toán/đánh giá/đơn xin phép); trạng thái kết nối thật — Lark đọc từ bảng message bot (trước đọc nhầm wp_options nên báo "Thiếu cấu hình" dù đang chạy).
- ⚡ **Trang home hết giật/rung khi cuộn** — Hero slider, 6 carousel ảnh dịch vụ và gallery auto-scroll chỉ chạy khi đang trong viewport (IntersectionObserver) thay vì chạy ngầm vĩnh viễn; gallery mobile bỏ `filter: blur` động + `will-change` tràn lan (thay bằng opacity/scale), chỉ cập nhật ảnh active khi cuộn dừng (hết đo layout từng frame); ảnh gallery mobile cố định tỉ lệ 4:5 → hết nhảy layout khi lazy-load; blur header 20→12px, bottom nav 20→10px; section lớn chỉ fade không trượt; hỗ trợ `prefers-reduced-motion`.
- 🎨 **Modal xác nhận hết màu tím** — Nút modal dùng gradient preset của WordPress core (cyan-blue-to-vivid-purple) nên đợt redesign trước không quét trúng; thay cả 7 chỗ dùng preset WP (nút modal, popup xem ảnh, nút lọc, icon két tiền, nền modal dark-mode) về palette phẳng.

### Sửa lỗi

- 🐛 **Thêm sản phẩm vào hóa đơn đã tạo không được cộng vào tổng thanh toán** — `addProductToInvoice` gọi `calculateInvoiceTotals()` thiếu `await` → lưu DB chạy trước khi tính xong, đẩy tổng cũ lên server (thêm dịch vụ thì có await nên không sao). Đã await đúng thứ tự: cộng sản phẩm → tính tổng → lưu.
- 🐛 **Từ chối đơn xin phép luôn báo "chưa được cấp quyền" kể cả admin/quản lý** — Hệ thống chưa từng tồn tại quyền `reject`: trang /admin không có ô cấp quyền, JS lưu quyền cũng không thu thập action này. Fix: quyền "Duyệt đơn" bao hàm cả từ chối (role cũ chạy ngay không cần cấu hình lại); Administrator WP luôn full quyền mọi scope; thêm ô "Từ chối đơn" riêng ở /admin.
- 🐛 **Card "Lịch hẹn sắp đến" tràn ngang màn hình mobile** — Grid dashboard dùng `1fr` (= `minmax(auto,1fr)`) nên tên khách/dịch vụ dài đẩy cột rộng hơn viewport → đổi `minmax(0,1fr)` + `min-width: 0` toàn chuỗi, mobile nén card gọn lại.
- 🐛 **Branch selector tràn màn hình khi tên chi nhánh dài** — Bỏ chữ "Chi nhánh:" chỉ giữ 📍, nút "Tìm tự động" chỉ còn 🔍 trên mobile, tên chi nhánh dài tự cắt "…"; đổi nốt màu xanh cũ `#3b82f6` còn sót về palette mới.

### Dọn dẹp dữ liệu (thủ công trên VG)

- 🧹 Xóa ảnh thợ up nhầm vào KHÁCH VÃNG LAI (KH1010): 15 hóa đơn trong DB + 23 file trên disk (có backup tại `wp-content/cc-bak-kh1010/`).

## [5.3.2.6] - 2026-07-06

### Cải tiến — Redesign giao diện flat native (hết màu "AI")

- 🎨 **Bảng màu mới toàn app** — Bỏ toàn bộ gradient tím (`#667eea/#764ba2`), về 1 màu accent duy nhất `#0071E3` kiểu Apple; semantic chuẩn SF: tiền xanh lá `#34C759`, cảnh báo/tips cam `#FF9500`, chi/huỷ đỏ `#FF3B30`; nền `#F5F5F7`, chữ `#1D1D1F`/`#6E6E73`, shadow mềm + viền hairline. Áp dụng: toàn bộ app-tho, trang cá nhân, trang điểm danh. Badge pastel PTTT/zbs/Tips và branding đen-vàng kiosk điểm danh giữ nguyên.
- 🎨 **Dashboard app-tho đổi bố cục** — Bộ lọc thời gian thành segmented control kiểu iOS; stat cards bỏ thanh cầu vồng, icon tint phẳng, số to hơn trên mobile; status/alert cards phẳng; dark mode đồng bộ tông xanh đen của app; màu biểu đồ remap theo palette mới.

### Tính năng mới

- ✨ **Modal chi tiết lịch hẹn** — Bấm vào card lịch hẹn mở bottom sheet như hoá đơn: thông tin khách + SĐT, ngày giờ, thợ, trạng thái dạng chip màu, trạng thái gửi/nhắc hẹn, dịch vụ, ghi chú, ảnh (bấm xem lớn), nút huỷ lịch.
- ✨ **Chip ID booking + copy trên card lịch hẹn** — Bỏ SĐT trên card mobile (đã có trong modal chi tiết), thay bằng chip `#ID` bấm để sao chép, icon copy đổi thành tick xanh khi xong.
- ✨ **Tab "Thêm" mobile có Phiên bản + xoá bộ nhớ đệm** — giống bấm version ở sidebar desktop.
- ✨ **Footer mới** — hiện cả trên mobile (nằm trên native bar), thêm dòng credit design by tuanminhhole & monkeytech.io.vn (bấm được, kèm tim đập).

### Sửa lỗi

- 🐛 **Header desktop app-tho bị đè nội dung** — 2 rule mobile của thanh Chi nhánh (`width: stretch`, `justify-content: space-between`) bị áp global làm header desktop cao thêm ~110px che phần chào mừng → scope về mobile-only.
- 🐛 **Admin login xong không thấy tab Admin (phải reload)** — API login trả thêm `wp_role`, JS cập nhật navbar ngay khi login thành công (Google/Facebook/thường).
- 🐛 **Lỗi quyền khi sửa hồ sơ ngay sau login** — Nonce trả về từ API login gắn với session cũ (cookie mới chưa vào `$_COOKIE`) → hook `set_logged_in_cookie` đồng bộ ngay trong request, nonce hợp lệ tức thì, hết `rest_cookie_invalid_nonce`.
- 🐛 **Không login Google được trong app PWA** — PWA standalone không dùng được popup → tự chuyển `ux_mode: redirect` với endpoint mới `/google-login-redirect` (kiểm CSRF `g_csrf_token`, redirect về trang cá nhân kèm kết quả). Cần thêm URI này vào Authorized redirect URIs ở Google Console.
- 🐛 **Upload avatar/CCCD chậm, ảnh iPhone lỗi hiển thị** — Nén phía client ngay khi chọn file (avatar 512px, CCCD 1600px), hỗ trợ HEIC → JPEG, server convert webp lưu trực tiếp một phát ăn ngay; preview lấy từ ảnh đã nén.
- 🐛 **Khoảng trống thừa cuối trang mobile** — footer nhận nhiệm vụ chừa chỗ cho native bar, hết dải trống đen.

## [5.3.2.5] - 2026-07-06

### Sửa lỗi

- 🐛 **Upload ảnh chậm/mất trên mạng yếu** — Nén MỌI loại ảnh kể cả HEIC iPhone (trước bị bỏ qua → upload nguyên gốc 5-10MB); decode qua `createImageBitmap` ngoài main-thread; pipeline tuần tự kiểu app native (vừa upload ảnh N vừa nén sẵn ảnh N+1); timeout 90s + tự retry 3 lần; banner tiến trình theo từng ảnh "Đang tải ảnh 2/3 — đừng đóng app!" trên đầu màn hình.
- 🐛 **Dịch vụ/thợ không cập nhật thật sau khi sửa (lost-update)** — Fetch đang chạy dở không còn trả dữ liệu cũ đè lên thao tác vừa lưu; reload không đè hoá đơn đang sửa dở (isDirty); saveInvoiceToDB nhận đúng object đang sửa; xoá hết dịch vụ không còn "thành công ảo"; thanh toán bắt buộc lưu thay đổi thành công trước khi chốt.
- 🐛 **Kẹt cache modals.css/js** — enqueue theo filemtime, mọi cập nhật giao diện tự tới trình duyệt.

### Cải tiến — Giao diện mobile chuẩn app native

- 📱 **Bottom navigation bar** thay sidebar trên mobile: 5 tab (Trang chủ, Lịch hẹn, FAB Dịch vụ nổi giữa, Hóa đơn, Thêm), tab Thêm mở bottom sheet (Báo cáo, Quản lý Ca theo quyền, Cài đặt, tài khoản); blur translucency, safe-area, hiệu ứng nhún.
- 📱 **Hoá đơn & Lịch hẹn dạng card** thay bảng: phân cấp thông tin (ảnh/tên/tiền/trạng thái), tem "GIẢM -XXđ" đóng dấu trên mép card, hệ badge pastel (PTTT theo loại, tin nhắn zbs_uid/zbs_phone khi gửi thành công, Tips khi >0) gộp cụm canh trái; tên khách hiển thị đầy đủ; desktop giữ nguyên bảng.
- 📱 **Filter bar gọn**: 1 hàng [kỳ lọc][Lọc][Đối soát], bộ lọc chi tiết trượt xuống; ẩn "Hiển thị mục" + "Cài đặt hiển thị" trên mobile; nút Đối soát đổi đỏ nhạt.
- 📱 **Modal chi tiết hoá đơn = bottom sheet**: trượt từ đáy phủ nav, drag handle, nhãn-giá trị từng dòng, nút hành động phân màu, 1 thanh cuộn ẩn kiểu native.
- 📱 **Viewer ảnh gesture**: kéo xuống đóng (ảnh theo ngón tay), double-tap zoom + pan, vuốt ngang chuyển ảnh, counter + nút đóng trong lòng ảnh, bỏ mũi tên.
- 🎨 **Giảm giá thủ công khi CTKM "Không có"**: nhập theo % hoặc đ ngay ô giảm giá, tự lưu khi rời ô; CTKM luôn ưu tiên hơn.
- 🎨 **Hết chớp trang + không tự cuộn**: bỏ render toàn trang thừa sau mỗi thao tác dịch vụ; không cuộn lên đầu sau cập nhật/thanh toán; tab hoá đơn chỉ cuộn ngang trong thanh tab.

---

## [5.3.2.4] - 2026-07-04

### Sửa lỗi

- 🐛 **Thay ảnh thợ nhưng trang home vẫn hiện ảnh cũ (kẹt cache 7 ngày)** — URL ảnh thợ không đổi khi thay file nên trình duyệt khách giữ bản cache cũ theo `max-age` của hosting. Nay API `/hairdressers` gắn `?v=filemtime` vào URL ảnh: thay ảnh là URL đổi theo, khách thấy bản mới ngay lập tức.

---

## [5.3.2.3] - 2026-07-04

### Sửa lỗi

- 🐛 **Sửa lỗi ảnh thợ không hiển thị trên trang home khi tên file bị Unicode NFD** — File ảnh up từ macOS thường mang tên dạng NFD (dấu tách rời), nhìn giống hệt `display_name` trong DB (NFC) nhưng khác byte → API `/hairdressers` so sánh chính xác trượt và thợ rơi về ảnh mặc định. Nay chuẩn hoá cả hai vế về NFC bằng `Normalizer` (có guard `class_exists`, cần bật extension `intl`; thiếu intl thì hành vi như cũ).
- 🚀 **Hỗ trợ thêm định dạng ảnh thợ `.jpeg` / `.webp`** trong thư mục `home/staff/` (trước chỉ nhận jpg/png/gif).
- 🧹 **Bỏ log debug spam trong `get_hairdressers`** — không còn ghi error_log đường dẫn/danh sách file/từng thợ trên mỗi lượt tải trang home.

---

## [5.3.2.2] - 2026-07-04

### Sửa lỗi

- 🐛 **Auto-confirm thanh toán không chạy sau khi MonkeyPay server chuyển sang VPS** — Plugin giữ URL server riêng (`CHECKIN_MONKEYPAY_SERVER_URL` + option `monkeypay_api_url`) vẫn trỏ về Cloud Run cũ đã ngừng. Vì option chỉ tự set khi rỗng nên nó đóng băng ở URL chết → `app-tho` tạo giao dịch thất bại → server không có giao dịch pending để khớp BDSD → chỉ bắn Lark, không auto-confirm ở modal.

### Thay đổi

- ♻️ **URL server MonkeyPay: một nguồn duy nhất** — Bỏ hẳn hằng `CHECKIN_MONKEYPAY_SERVER_URL` và option `monkeypay_api_url` trùng lặp. `checkin_mkt192_get_monkeypay_url()` giờ đọc thẳng từ plugin MonkeyPay (`MonkeyPay_Settings` / `MONKEYPAY_API_URL`). Chế độ thanh toán tự động chỉ áp dụng khi plugin MonkeyPay đang kết nối — không còn hai nơi cấu hình lệch nhau.

---

## [5.3.2.1] - 2026-07-04

### Sửa lỗi

- 🐛 **Sửa regression 5.3.2.0: ảnh biến mất trên UI sau khi lưu hoá đơn** — Từ 5.3.2.0, payload update không còn gửi `images`, nhưng `saveInvoiceToDB` vẫn ghi `invoiceData.images || []` vào state local `invoicesData` làm mirror bị wipe thành rỗng; lần sync tiếp theo kéo mảng rỗng ngược vào `invoice.images` → ảnh mất trên UI, modal "Tất cả hóa đơn" báo "Chưa up" dù đã upload thành công. Nay giữ ảnh từ local/mirror khi cập nhật.
- 🚀 **Modal "Tất cả hóa đơn" cập nhật trạng thái up hình realtime** — Upload xong (hoặc vừa chọn ảnh preview) là trạng thái "Chưa up" → ✓ đổi ngay, không cần đóng mở lại modal (event `checkin:invoice-images-updated`, giữ nguyên trang và từ khoá đang tìm).
- 🔄 **Đồng bộ mirror `invoicesData` ngay khi upload xong** — Tránh các luồng sync (renderCurrentInvoice, syncInvoiceWithDB) lấy dữ liệu ảnh cũ từ mirror đè lên ảnh mới upload.

---

## [5.3.2.0] - 2026-07-04

### Sửa lỗi

- 🐛 **Khắc phục triệt để lỗi mất ảnh khách sau khi upload** — Trường `images` của hoá đơn bị API cập nhật hoá đơn (PUT) ghi đè bằng dữ liệu cũ từ app (temp URL đã bị cron xoá file), làm mất link ảnh WebP mà cron vừa lưu. Nay:
  - API cập nhật hoá đơn không còn nhận trường `images` từ client — ảnh chỉ được ghi qua upload API và cron.
  - App thợ không gửi `images` khi lưu/cập nhật hoá đơn (chỉ gửi khi tạo mới).
  - Thêm helper `Checkin_MKT192_Invoice_Images` — mọi thao tác ghi ảnh vào hoá đơn đi qua một nơi duy nhất, atomic bằng `SELECT ... FOR UPDATE` (hết lost-update giữa upload song song và cron).
  - Cron convert WebP và cron reprocess chuyển sang dùng helper; khi cập nhật DB thất bại sẽ giữ lại metadata JSON để tự re-link cuối ngày thay vì mất vĩnh viễn.

### Cải tiến

- 🚀 **Chuyển kênh cập nhật plugin sang GitHub Releases** — Manifest + gói zip phát hành trên repo `monkeytech192/checkin-mkt192-wp-releases`; chủ site bấm Update ngay tại trang Plugins của WP Admin. Cache manifest 6 giờ, popup "View details" hiển thị changelog, tự xoá cache sau khi update.

---

## [5.3.0.8] - 2026-06-01

### Sửa lỗi

- 🐛 **Sửa lỗi so sánh kiểu dữ liệu auto_mode và auto_amount** — Sử dụng so sánh lỏng `== '1'` khi nạp cấu hình `auto_mode` và `auto_amount` từ WordPress options trong `Checkin_MKT192_Assets::get_payment_qr_data()`, đảm bảo tương thích hoàn hảo kể cả khi tuỳ chọn được lưu dưới dạng số nguyên hay chuỗi từ MonkeyPay.

---

## [5.3.0.7] - 2026-06-01

### Sửa lỗi

- 🐛 **Sửa lỗi mất ảnh khi tải lên song song (Race Condition)** — Triển khai cơ chế giao dịch SQL (Transaction) và khóa dòng cấp cơ sở dữ liệu (`SELECT ... FOR UPDATE`) khi cập nhật danh sách ảnh trong bảng hóa đơn, giúp đồng bộ hóa các yêu cầu song song hoàn hảo.
- 🐛 **Đánh số thứ tự ảnh liên tục (`_1`, `_2`, `_3`...)** — Tự động tính toán số thứ tự tăng dần chuẩn xác bắt đầu từ 1 dựa trên số lượng ảnh hiện có trong database tại thời điểm lock dòng, khắc phục triệt để hiện tượng toàn bộ ảnh tải lên cùng lúc bị gán hậu tố `_0` giống nhau.
- 🐛 **Tự động khôi phục ảnh mồ côi (Orphan Image Recovery)** — Cải tiến cronjob xử lý tệp tạm để tự động phân tích cả timestamp dạng giây và dạng mili-giây (13 chữ số) từ tên ảnh mồ côi trong `/temp/`, tìm kiếm hóa đơn tương ứng trong ngày hoặc khoảng ngày, tự động nén/chuyển sang WebP tối ưu (giảm dung lượng đến 97%), đồng bộ DB và dọn dẹp thư mục tạm.
- 🐛 **Khắc phục lỗi ghi thư mục thợ (Staff Custom Upload Path)** — Thay đổi logic `checkin_mkt_custom_upload_dir` để ưu tiên sử dụng `$user_id` truyền vào giúp các yêu cầu API không có session vẫn được tải ảnh chuẩn vào thư mục `/staff/`.
- 🐛 **Khắc phục lỗi tràn bộ nhớ (GD Memory Limit)** — Thêm cấu hình tự động tăng `memory_limit` lên `512M` và `set_time_limit(0)` cho cronjob tải ảnh khách hàng hàng ngày để tránh lỗi OOM (Out Of Memory) khi xử lý ảnh độ phân giải cao bằng thư viện GD.

---

## [5.3.0.6] - 2026-03-24

### Cải tiến

- 🚀 **Tự động xác nhận thanh toán (BDSD Matching)** — Khắc phục hoàn toàn luồng tự động xác nhận hóa đơn khi khách chuyển khoản
  - Retroactive BDSD matching: nếu BDSD đã đến trước khi mở hóa đơn, giao dịch tự động khớp ngay lập tức
  - Hỗ trợ cả QR tĩnh và QR động: miễn nội dung chuyển khoản chứa đúng mã ghi chú
  - Phát hiện thay đổi số tiền hóa đơn: khi dịch vụ thay đổi sau khi tạo mã QR, tự động tạo lại giao dịch mới với số tiền đúng

### Sửa lỗi

- 🐛 **Sửa lỗi ghi chú thanh toán rỗng** — Polling response lấy `payment_note` sai key từ server response (`data.payment_note` → `payment_note`)
- 🐛 **Sửa lỗi Docker cURL error 7** — Thay self-referencing REST API call bằng gọi trực tiếp MonkeyPay Server API
- 🐛 **Sửa lỗi ghi chú `{prefix}` không được thay thế** — Token `{prefix}` trong cú pháp ghi chú giờ được replace đúng khi sinh mã thanh toán
- 🐛 **Sửa lỗi cổng thanh toán bị reset config** — Ngăn sync ghi đè `note_prefix`, `note_syntax` do user cấu hình bằng giá trị mặc định từ server
- 🐛 **Sửa lỗi timeout vô hạn khi tạo giao dịch** — Reuse giao dịch pending cùng mã ghi chú thay vì retry vô hạn
- 🐛 **Sửa 6 race conditions trong UI thanh toán** — Xử lý lỗi 500, nút xác nhận, closure capture, payment method tracking

---

## [5.3.0.5] - 2026-03-23

### Cải tiến

- 🚀 **Kết nối Plugin MonkeyPay — Thanh toán tự động** — Tích hợp MonkeyPay Plugin để xử lý thanh toán chuyển khoản tự động
  - Tự động kiểm tra biến động số dư (BDSD) và xác nhận hóa đơn khi thanh toán thành công
  - Thông báo BDSD tự động qua Lark khi phát hiện giao dịch mới
  - Polling realtime kiểm tra trạng thái thanh toán

### Sửa lỗi

- 🐛 **Sửa lỗi phương thức thanh toán bank/momo bị trống** — Race condition khi MonkeyPay auto-confirm: backend đã set `payment_method = 'bank'` đúng, nhưng frontend `onPaymentConfirmed()` gọi `completePayment()` sau 4 giây ghi đè bằng chuỗi rỗng
  - Thay `completePayment()` bằng local state update trong flow auto-confirm (không gọi PUT API nữa)
  - Lưu `savedIsDBInvoice` trước khi `stopPaymentPolling()` reset biến
  - Thêm fallback `invoice.paymentMethod || invoice.payment_method || 'cash'` trong `completePayment` cho flow thủ công

- 🐛 **Sửa lỗi loading vô hạn khi chọn ngày OFF đặc biệt** — Form booking trang Home: khi khách chọn ngày OFF đặc biệt, popup cảnh báo hiện đúng nhưng sau khi bấm "Đóng", loading overlay không tắt
  - Thêm `hidePageLoading()` vào block `if (!data.success)` trong cả `generateTodayTimeButtons()` và `generateNormalDateSlots()`

---

## [5.3.0.4] - 2026-03-19

### Cải tiến

- 🚀 **Tích hợp Plugin MonkeyPay** — Kết nối trực tiếp với Plugin MonkeyPay WP để xử lý thanh toán
  - **Luồng tự động**: Tạo giao dịch trên MonkeyPay → polling kiểm tra trạng thái → tự động xác nhận hóa đơn khi thanh toán thành công
  - **Luồng thủ công**: Hỗ trợ xác nhận thanh toán thủ công bởi nhân viên khi không sử dụng chế độ tự động
  - Kết nối/ngắt kết nối MonkeyPay từ giao diện quản trị (đăng nhập/đăng ký tổ chức)

- 🔔 **Template thông báo Lark cho giao dịch** — Tự động gửi card thông báo đến nhóm Lark khi thanh toán thành công, bao gồm thông tin hóa đơn, số tiền, phương thức và chi nhánh

### Sửa lỗi

- 🐛 **Sửa lỗi modal thanh toán giữ trạng thái cũ** — Sau khi thanh toán hóa đơn A thành công, mở modal cho hóa đơn B không còn hiển thị trạng thái thành công của hóa đơn trước
  - Áp dụng cho cả **App Thợ** và **Customer Review Offline**
  - Reset toàn bộ animation, QR code, bank info khi mở modal mới

- 🐛 **Sửa lỗi Reset trang không tự động lấy hóa đơn tiếp theo** — Trang đánh giá (Customer Review Offline) sau khi bấm Reset trang giờ tự động hiển thị hóa đơn tiếp theo trong hàng đợi mà không cần bấm mời lại

- 🐛 **Sửa lỗi trạng thái Card thanh toán** — Card "Chuyển khoản ngân hàng" hiển thị đúng "Đã cấu hình" khi đã kết nối MonkeyPay ở chế độ tự động

### Bảo mật

- 🔒 Tất cả giao tiếp thanh toán đi qua lớp xác thực API Key của Plugin MonkeyPay
- 🔒 Không lưu trữ hoặc truyền thông tin nhạy cảm qua các endpoint công khai
- 🔒 Kiểm tra quyền truy cập và validate dữ liệu đầu vào cho mọi thao tác thanh toán

---

## [5.3.0.3.7] - 2026-03-01

### Thay đổi

- ✨ **Chuyển đổi gửi tin Zalo OA sang ZBS Template** — Thay thế Zalo OA Transaction API bằng ZBS Template API
  - Ưu tiên gửi qua UID (nếu khách có id_zalo), fallback qua SĐT nếu thất bại
  - Áp dụng cho 4 loại tin: xác nhận booking, nhắc lịch, hủy booking, hóa đơn

### Sửa lỗi

- 🐛 **Sửa lỗi gửi ZBS qua UID** — Cấu trúc payload không đúng tài liệu API (user_id phải ở root level thay vì trong recipient)
- 🐛 **Link đăng ký thành viên dynamic** — Thay link hardcoded bằng link tự động theo OA ID của từng site

---

## [5.3.0.3.6] - 2026-02-15

### Thêm mới

- ✨ **Lương trung bình 12 tháng** — Xem tổng hợp lương thực nhận 12 tháng gần nhất và tính trung bình
  - Nút "Lương TB" trên card lương admin (chỉ hiển thị cho quản trị viên)
  - Modal hiển thị bảng chi tiết: tổng lương, khấu trừ, thực nhận theo từng tháng
  - Phép tính và kết quả lương trung bình nổi bật
  - Giao diện glassmorphism, animations mượt, responsive mobile

---

## [5.3.0.3.5] - 2026-02-13

### Thêm mới

- ✨ **Thông báo Lark khi thanh toán thành công** — Tự động gửi thông báo đến nhóm Lark khi hóa đơn được xác nhận thanh toán
  - Card thông báo hiển thị đầy đủ: mã hóa đơn, tên khách, số tiền, phương thức, chi nhánh
  - Hỗ trợ cấu hình bot webhook riêng cho loại thông báo `payment_success`

### Sửa lỗi

- 🐛 **Sửa lỗi không xác nhận được thanh toán sau 0h** — Hệ thống kiểm tra giao dịch sai ngày do sử dụng giờ UTC thay vì giờ Việt Nam (UTC+7)
- 🐛 Sửa lỗi tải class mã hóa khi lưu cấu hình thanh toán ngân hàng

---

## [5.3.0.3.4] - 2026-02-12

### Thêm mới

- 🚀 **Tích hợp Cổng Thanh Toán Tự Động** — Cổng đầu tiên: **MB Bank**
  - Tự động kiểm tra giao dịch ngân hàng và xác nhận hóa đơn theo thời gian thực
  - Polling thông minh với tần suất tùy chỉnh (1-5 phút)
  - Đối soát tự động: khớp số tiền + mã ghi chú chuyển khoản
  - Hỗ trợ cron job chạy nền, không cần thao tác thủ công
  - Giao diện cấu hình trực quan trên WP Admin

- ✨ **Hiệu ứng âm thanh thanh toán** — Phát âm thanh "ting-ting" khi xác nhận thanh toán thành công
  - Sử dụng Web Audio API — không cần file âm thanh, hoạt động offline
  - Tương thích PWA, hỗ trợ cả desktop và mobile

### Bảo mật

- 🔒 Mã hóa toàn bộ thông tin nhạy cảm (tài khoản, mật khẩu, API key) trong cấu hình thanh toán

---

## [5.3.0.3.3] - 2026-02-10

### Thêm mới

- ✨ **Đăng nhập bằng Zalo (Social Login)** — Khách hàng đăng nhập qua Zalo OAuth PKCE, tự động liên kết tài khoản
- ✨ **Lịch sử đặt lịch** — Hiển thị danh sách booking gần nhất trong tab Đặt lịch (tối đa 10 booking)
- ✨ **Điều hướng bằng hash URL** — Hỗ trợ `#booking`, `#promo`, `#history` để mở đúng tab khi chia sẻ link
  - Tự động chuyển tab khi thay đổi hash (không cần reload)
  - Bottom nav đồng bộ hash URL

### Thay đổi

- 🎨 **Giao diện lịch sử đặt lịch** — Card layout mới: header (mã booking + badge trạng thái), chi tiết từng dòng riêng (ngày/giờ, dịch vụ, nhân viên)
- 🎨 **Tối ưu responsive** — Giảm placeholder text, button padding, fix input styling trên Safari
- 🎨 **Section title** — Thêm margin và border-bottom dashed cho tiêu đề section
- 🎨 **Empty state** — Đổi màu text sang trắng cho dễ đọc

### Sửa lỗi

- 🐛 Sửa auto-login từ session luôn mở tab Khuyến mãi, bỏ qua hash URL

---

## [5.3.0.3.0] - 2026-02-09

### Thêm mới

- **Tách luồng gửi tin nhắn Zalo** — Hỗ trợ gửi riêng biệt đến khách hàng và nhóm nhân viên
  - 2 toggle mới: "Gửi đến khách" và "Gửi đến group"
  - Áp dụng cho booking, hủy booking, và nhắc lịch hẹn
  - N8N workflows tương ứng cho từng luồng

- **Nút Thu gọn / Mở rộng** — Danh sách template ZBS có thể thu gọn để modal không bị kéo dài

### Thay đổi

- **Đổi tên ZNS → ZBS** — Cập nhật giao diện và nhãn hiển thị
- **Cho phép bật đồng thời Zalo OA và Zalo Cá nhân** — Không còn loại trừ nhau
- **Tự động cập nhật dữ liệu cũ** — Các site đã cài trước đó sẽ tự động chuyển đổi khi update

---

## [5.3.0.2.2] - 2026-02-08

### Thay đổi

- **Trang chủ - Hiển thị Quản Lý** - Thêm vai trò "Quản Lý" vào danh sách đội ngũ trên trang home
  - Cập nhật SQL query trong `booking-api.php` để include thêm role "Quản Lý" bên cạnh "Thợ Chính" và "Thợ Phụ"

- **Header Menu Hover** - Đổi màu hover danh mục menu từ `--primary-color` sang `--secondary-color`
  - Màu hover giờ đồng bộ với màu gạch dưới (underline) khi hover

### Sửa lỗi

- **Lark Callback Timeout (Error 200341)** - Sửa lỗi Lark card callback bị timeout
  - Xóa `ob_start()` + `register_shutdown_function()` trong `send_salary_notification.php` đang intercept và đè response callback
  - Block này capture output của callback handler rồi thay bằng HTTP 500 + error JSON, khiến Lark nhận sai response

---

## [5.3.0.2.1] - 2026-02-07

### Thêm mới

- **README Chuyên Nghiệp** - Tài liệu đầy đủ theo chuẩn quốc tế
  - README.md (English) với 400+ dòng
  - README_VI.md (Tiếng Việt) đầy đủ
  - Language switcher giữa 2 ngôn ngữ
  - Badges, features, installation, troubleshooting
  - Security best practices

### Thay đổi

- **Salary Period Selector** - Mặc định tháng trước thay vì tháng hiện tại
  - Admin page: Tự động chọn tháng trước
  - User profile page: Tự động chọn tháng trước
  - Xử lý rollback năm khi sang tháng 1

- **User Profile HTML** - Cập nhật year selector
  - Thêm năm 2027, 2026
  - Xóa năm 2024, 2023 (cũ)

- **Salary Card UI** - Tối ưu giao diện mobile
  - Giảm padding và font size trên mobile
  - Cải thiện button spacing
  - Tối ưu icon size

---

## [5.3.0.1.8] - 2026-01-22

### Thêm mới

- **Liên kết tài khoản Google** - Kết nối acc Google mới với acc cũ bị mất
  - Nhân viên có thể liên kết lại tài khoản khi đổi email Google

- **Multi-Branch QR Payment** - Hỗ trợ thanh toán QR theo từng chi nhánh
  - Liên kết QR với chi nhánh cụ thể
  - Lọc QR theo chi nhánh đang chọn

- **Dashboard Stock Transfer** - Quản lý phiếu xuất/nhập kho từ Dashboard
  - Modal hiển thị danh sách phiếu với tabs: Tất cả, Chờ duyệt, Đã duyệt
  - Hiển thị ảnh đính kèm nếu có
  - Duyệt/Từ chối phiếu trực tiếp

- **Branch Filter cho Stock Transfer** - Lọc phiếu theo chi nhánh đang chọn

### Thay đổi

- **Giao diện Modal** - Thống nhất UI giữa Dashboard và Inventory tab
- **Confirm Dialog** - Sử dụng modal xác nhận thay vì alert mặc định
- **Mobile Responsive** - Nút Duyệt/Từ chối nằm cùng hàng trên điện thoại
- **Cleanup** - Xóa CSS không dùng

### Sửa lỗi

- Fix lỗi không gửi chi nhánh khi tạo phiếu xuất/nhập kho
- Fix Dashboard không tự động refresh sau khi tạo phiếu mới
- Fix Dashboard hiển thị phiếu của tất cả chi nhánh thay vì chỉ chi nhánh đang chọn

### Bảo mật

- Kiểm tra đầu vào và quyền truy cập đúng cách

---

## [5.3.0.1.5] - 2026-01-14

### Thêm mới

- **Thông tin Mã Khuyến Mãi Thành Viên** - Hiển thị chi tiết điều kiện sử dụng mã KMTV
  - Cập nhật tin nhắn Zalo chúc mừng đăng ký thành viên với thông tin mã khuyến mãi
  - Thêm promo info box trong modal đăng ký thành viên thành công
  - Thông tin: giá trị mã, cách sử dụng
  - Lưu ý: điều kiện áp dụng, hạn sử dụng 30 ngày

### Thay đổi

- **Nút Ưu đãi Thành Viên** - Đổi thành "MÃ KMTV" với icon ticket

---

## [5.3.0.1.4] - 2026-01-14

### Thêm mới

- **Booking Slot Lock cho Đi Trễ/Về Sớm** - Tự động khóa slot booking khi thợ có đơn xin đi trễ/về sớm đã duyệt
  - Query bảng `approval_requests` với `request_type = 'late_early'` và `status = 'approved'`
  - Đi trễ: khóa slots từ 08:30 đến (08:30 + số phút đi trễ)
  - Về sớm: khóa slots từ (20:30 - số phút về sớm) đến 20:30
  - Trả về thông báo giải thích cho khách hàng

### Thay đổi

- **Response Booking API** - Thêm `late_blocked_until` và `early_blocked_from` trong response

---

## [5.3.0.1.3] - 2026-01-14

### Thêm mới

- **HTML Formatting cho Notifications** - Giữ định dạng (bold, italic, underline) từ editor
  - Hàm `convert_html_to_lark_md()` chuyển HTML sang Lark Markdown
  - Hàm `formatContent()` JS sanitize và giữ thẻ HTML an toàn
  - Tiêu đề luôn in đậm trong popup chi tiết

### Thay đổi

- **Lark Notification** - Sử dụng `lark_md` tag thay vì `plain_text` để hỗ trợ formatting
- **Staff Notifications CSS** - Thêm style cho `.notification-detail-body h2` (font-weight: 700)

### Sửa lỗi

- **Xuống dòng không hoạt động** - Chuyển `<br>` thành `\n` cho Lark, giữ `<br>` cho frontend

---

## [5.3.0.1.2] - 2026-01-14

### Thêm mới

- **Lark Integration cho Staff Notifications** - Gửi thông báo nhân viên qua Lark Group
  - Hàm `build_staff_notification_card()` tạo card thông báo đẹp
  - Tự động gửi khi tạo/cập nhật thông báo với status active
  - Sử dụng Bot Manager với notification type "general"

### Thay đổi

- **Push Notification URLs** - Cập nhật URL từ `/customer-member` sang `/app-tho?view=bookings`
- **Auto-navigation** - Mở popup chi tiết thông báo khi click push notification

### Sửa lỗi

- **Lark Webhook Check** - Loại bỏ check `is_configured()` cho webhook bots (không cần App ID/Secret)
- **Booking Cancelled Notification** - Sửa syntax error missing comma

---

## [5.3.0.1.1] - 2026-01-13

### Thêm mới

- **Review Detail View** - Xem chi tiết đánh giá khi click từ push notification
  - Giao diện responsive với layout 2 cột (desktop) / 1 cột (mobile)
  - Hiển thị feedback dạng pill badges
  - Phân chia sections: thông tin khách hàng, thông tin dịch vụ

### Thay đổi

- **Notification Card Drag-Drop** - Cải thiện UX kéo thả
  - Handle ở giữa phía trên với style embossed dots
  - Hiển thị STT badge xanh ở giữa card
  - Dim media khi hover
  - Card min-width 360px, button flex-wrap tránh overflow

---

## [5.3.0.0.0] - 2026-01-13

### Thêm mới

- **Hệ thống Quản lý Thông báo (Notifications Management)**
  - Trang quản lý thông báo mới trong Admin Settings với đầy đủ CRUD
  - REST API endpoints cho notifications
  - Hỗ trợ 2 loại thông báo: Homepage (popup trang chủ) và Staff (App Thợ)
  - Upload media (ảnh/video) với preview và lựa chọn aspect ratio
  - Trình soạn thảo WYSIWYG với formatting
  - Lên lịch thông báo với start_date và end_date
  - Lọc theo loại, trạng thái, chi nhánh
  - Gửi Push Notification tích hợp OneSignal

- **Homepage Notification Popup** - Popup thông báo khuyến mãi trên trang chủ
  - Hiển thị popup đẹp với media, title, content, CTA button
  - Hỗ trợ nhiều thông báo với navigation
  - Tracking lượt xem với localStorage
  - Responsive design

- **Staff Notification Bell** - Chuông thông báo cho nhân viên trong App Thợ
  - Badge đếm thông báo chưa đọc
  - Panel slide-in hiển thị danh sách thông báo
  - Mark as read/Mark all as read
  - Chi tiết thông báo với modal fullscreen
  - Auto-refresh và đồng bộ trạng thái qua localStorage

- **Viewer Tracking** - Theo dõi ai đã xem thông báo

- **Database Tables Consolidation** - Migration tự động khi update

- **Modern Image Loader** - Lazy loading tối ưu hiệu suất

### Thay đổi

- **Assets Enqueue** - Đăng ký thêm CSS/JS cho notifications

## [5.2.2.1.6] - 2026-01-11

### Thêm mới

- **Image Popup cho Customer Member** - Thêm tính năng phóng to avatar khi click
  - Thêm imagePopup modal vào modals-common.html (dùng chung cho tất cả trang)
  - Thêm modals.css vào dependencies của customer-member page
  - Tương tự tính năng xem ảnh phóng to ở trang app-tho

### Thay đổi

- **Tối ưu hiệu ứng Rating (Touch Screen)** - Giảm lag khi chọn cảm xúc đánh giá trên màn hình cảm ứng
  - Đơn giản hóa CSS transitions từ `all var(--transition-bounce)` thành `background, border-color, opacity 0.15s ease`
  - Loại bỏ animation `iconPop` và `will-change` properties
  - Thay gradient backgrounds thành solid colors
  - Đơn giản hóa box-shadow từ multi-layer thành single `0 0 0 3px`
  - Loại bỏ các transform effects (scale, translateY) khi chọn rating

### Sửa lỗi

- **Invoice Total không cập nhật sau xóa dịch vụ** - Sửa lỗi total_invoice trong DB vẫn giữ giá trị cũ sau khi xóa dịch vụ
  - Thêm `await` trước `calculateInvoiceTotals()` trong hàm `removeService()` để đảm bảo total được tính lại trước khi save
  - Thêm `await` trước `calculateInvoiceTotals()` trong hàm `updateServiceStaff()` để đồng bộ
  - Luôn gọi `saveInvoicesToLocalStorage()` khi xóa dịch vụ (tương tự logic addServiceToInvoice)
  - Đồng bộ với DB khi invoice có ID, không cần kiểm tra điều kiện hasOnlyOneService

---

## [5.2.2.1.5] - 2026-01-07

### Thêm mới

- **Branch Helpers** - Tập hợp helper functions xử lý chi nhánh
  - `checkin_mkt192_is_multi_branch_enabled()` - Kiểm tra chế độ đa chi nhánh
  - `checkin_mkt192_get_staff_primary_branch_id()` - Lấy chi nhánh chính của nhân viên
  - `checkin_mkt192_get_staff_all_branch_ids()` - Lấy tất cả chi nhánh của nhân viên
  - `checkin_mkt192_staff_belongs_to_branch()` - Kiểm tra nhân viên thuộc chi nhánh
  - `checkin_mkt192_get_branch_name()` - Lấy tên chi nhánh từ ID
  - `checkin_mkt192_get_branch_id_from_context()` - Lấy branch_id từ request context
  - `checkin_mkt192_build_branch_where_clause()` - Build SQL WHERE clause theo branch
  - `checkin_mkt192_get_staff_data()` - Lấy thông tin staff đầy đủ

- **Multi-branch cho Salary Levels** - Hỗ trợ gán cấp bậc lương cho nhiều chi nhánh
  - Thêm cột `branch_ids` (JSON array) trong bảng salary_level_settings
  - API hỗ trợ đọc/ghi danh sách chi nhánh cho mỗi cấp bậc lương
  - Backward compatible với `branch_id` đơn lẻ (legacy)

- **Project Coding Rules** - File `.github/projectCodingRules.prompt.md` chuẩn hóa coding conventions
  - Quy tắc Semi Design cho UI/UX
  - Cấu trúc dự án và đặt tên chuẩn
  - Hướng dẫn scale lâu dài

### Thay đổi

- **ZNS Template Update** - Cập nhật template ID từ 517002 sang 518927 cho tin nhắn hóa đơn Zalo

- **Shift Permissions Standardization** - Chuẩn hóa quyền shift từ `set` sang `add`/`edit`
  - Cập nhật UI checkboxes trong admin-setting-frontend.html
  - Cập nhật default permissions trong class-checkin-mkt192-activation.php

### Sửa lỗi

- **Branch API - Undefined $staff** - Sửa lỗi "Undefined variable $staff" và "Attempt to read property 'branch_id' on null"
  - Thêm query lấy staff data trước khi sử dụng
  - Thêm null safety check với ternary operator

- **Lark Notification OU ID** - Sửa lỗi gửi thông báo Lark với open_id thay vì user_id
  - Lấy `lark_open_id` từ database thay vì dùng `user_id`
  - Xử lý multiple recipients với open_ids hợp lệ

---

## [5.2.1.3.7] - 2025-12-20

### Thêm mới

- **Trang Push Notifications riêng biệt** - Di chuyển cấu hình Push Notifications ra khỏi trang Connections thành trang riêng
  - Tab Push Notifications trong header navigation (kế bên Connections)
  - Di chuyển submenu Push Notifications lên dưới Connections trong sidebar
  - Card cấu hình OneSignal với toggle bật/tắt, icon collapse để ẩn/hiện form
  - Badge trạng thái "Đã kích hoạt" / "Chưa kích hoạt"

- **Xuất/Nhập cài đặt Push Notifications**
  - Nút "Xuất" - Tải file JSON chứa toàn bộ cài đặt thông báo
  - Nút "Nhập" - Import cài đặt từ file JSON (hỗ trợ setup nhiều site nhanh chóng)
  - File export có dạng: `push-notifications-settings-YYYY-MM-DD.json`

- **Xem trước thông báo (Preview)**
  - Preview box hiển thị mẫu thông báo với dữ liệu giả lập
  - Cập nhật realtime khi nhập tiêu đề và nội dung
  - Hỗ trợ xuống hàng trong nội dung thông báo

- **Biến mới cho thông báo**
  - Thêm `staff_name` cho "Đánh giá mới" và "Hóa đơn truy thu"
  - Lọc biến `branch_name` - chỉ hiển thị khi bật chế độ đa chi nhánh

### Thay đổi

- **Giao diện Modal chỉnh sửa thông báo**
  - Di chuyển phần "Vai trò nhận thông báo" lên cùng hàng với toggle trạng thái (canh phải)
  - Thêm scroll cho modal body khi nội dung vượt chiều cao
  - Tăng chiều rộng modal lên 750px

- **Cải thiện UX**
  - Form OneSignal mặc định đóng (collapse) để giao diện gọn gàng
  - Sau khi lưu cài đặt thông báo, chỉ cập nhật UI thay vì reload toàn trang
  - Toast notification hiển thị đủ 1.5 giây trước khi reload

### Sửa lỗi

- **Nút lưu loading vô hạn** - Reset trạng thái nút submit sau khi lưu thành công
- **Toast biến mất quá nhanh** - Thêm delay trước reload để user thấy thông báo
- **Vai trò không hiển thị** - Sửa lỗi roles checkbox không xuất hiện trong modal
- **Preview không xuống hàng** - Chuyển từ `.text()` sang `.html()` với `<br>` cho preview

---

## [5.2.1.3.5] - 2025-12-18

### Thêm mới

- **Script xử lý ảnh thủ công** - Xử lý ảnh tồn đọng trong temp folders
  - Pagination: xử lý từng batch (5-50 files) tránh timeout
  - Logging và UI thân thiện với stats

### Thay đổi

- **Push Notifications** - Thêm branch name vào body notification khi bật multi-branch mode
- **Image Cleanup Logic** - Giữ 3 lần ghé gần nhất, cần ít nhất 4 lần ghé mới bắt đầu xóa
- **LocalStorage Cleanup** - Thêm các keys còn thiếu

### Sửa lỗi

- **Image Path Bug** - Sửa đường dẫn temp-feedback
- **SQL Column Error** - Sửa tên cột trong script xử lý ảnh
- **Image Upload Cronjob** - Xóa file source sau khi convert

---

## [5.1.8.0.0] - 2025-12-15

### Thêm mới

- **Push Notifications (OneSignal)** - Thông báo đẩy trên trình duyệt
  - Tích hợp OneSignal SDK cho Web Push
  - Admin Settings: Cấu hình trong trang Connections
  - User Profile: Tab Thông báo để bật/tắt push notifications
  - Database table lưu subscription info
- **Push Notification Manager** - Class JS quản lý subscriptions phía client
- **Helper Functions** - Các hàm gửi push notifications từ PHP

### Thay đổi

- **User Profile Page** - Thêm tab Thông báo với UI toggle
- **Connections Page** - Thêm card Push Notifications với modal cấu hình
- **Assets Loading** - Load push config cho user-profile

---

## [5.1.7.4.0] - 2025-12-13

### Thêm mới

- **Approval Request System** - Hệ thống yêu cầu phê duyệt thay đổi thông tin nhân viên
  - Nhân viên yêu cầu thay đổi: họ tên, SĐT, ngày sinh, địa chỉ, avatar
  - Manager/Admin phê duyệt hoặc từ chối
  - Tự động cập nhật thông tin sau khi phê duyệt
- **Modern Edit Modal** - Giao diện modal hiện đại cho sửa thông tin profile
- **Request Approval UI** - Giao diện quản lý yêu cầu phê duyệt
- **GitHub Actions CI/CD Workflows** - Code quality, PHP compatibility, auto release
- **GitHub Templates** - Pull Request và Issue templates
- **Documentation** - CONTRIBUTING.md, CHANGELOG.md

### Thay đổi

- **Git Workflow Migration** - Chuyển sang plugin-only repo
- **Modern Git Practices** - Conventional Commits, Git Flow branching
- **Shortcode Registration** - Thêm `request_approval` shortcode

### Sửa lỗi

- **Permission Check Bug** - Sửa lỗi xác thực user trong REST API
- **REST API Authentication** - Cải thiện xác thực qua JWT token

### Bảo mật

- Thêm permission check cho các API endpoints nhạy cảm
- Validation và sanitization cho dữ liệu approval request

---

## [5.1.7.3.0] - 2025-12-12

### Thêm mới

- Quản lý thông tin profile nhân viên

### Thay đổi

- Cải thiện cấu trúc frontend assets

---

## [5.1.7.2.0] - 2025-12-11

### Thêm mới

- Hệ thống quản lý lương
- Tính năng theo dõi KPI

---

## [5.0.0] - 2023-12-01

### Thêm mới

- Phiên bản chính thức với hệ thống check-in hoàn chỉnh
- Hỗ trợ check-in bằng QR code
- Xuất Excel
- Tích hợp Lark cho thông báo
- Tích hợp Zalo OA cho tin nhắn khách hàng
- Quản lý chi nhánh
- Quản lý kho hàng
- Theo dõi hóa đơn và thanh toán
- Hệ thống đánh giá khách hàng (online/offline)
- Hệ thống đặt lịch với nhắc nhở

---

[5.2.1.3.6]: https://github.com/monkeytech192/checkin-mkt192-wp/compare/v5.2.1.3.5...v5.2.1.3.6
[5.2.1.3.5]: https://github.com/monkeytech192/checkin-mkt192-wp/compare/v5.1.8.0.0...v5.2.1.3.5
[5.1.8.0.0]: https://github.com/monkeytech192/checkin-mkt192-wp/compare/v5.1.7.4.0...v5.1.8.0.0
[5.1.7.4.0]: https://github.com/monkeytech192/checkin-mkt192-wp/compare/v5.1.7.3.0...v5.1.7.4.0
[5.1.7.3.0]: https://github.com/monkeytech192/checkin-mkt192-wp/compare/v5.1.7.2.0...v5.1.7.3.0
[5.1.7.2.0]: https://github.com/monkeytech192/checkin-mkt192-wp/compare/v5.0.0...v5.1.7.2.0
[5.0.0]: https://github.com/monkeytech192/checkin-mkt192-wp/releases/tag/v5.0.0
