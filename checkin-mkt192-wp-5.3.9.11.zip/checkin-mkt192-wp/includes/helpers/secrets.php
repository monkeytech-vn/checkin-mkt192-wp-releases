<?php
/**
 * Đọc bí mật (khoá PayOS, token Lark, token API hệ thống) từ ngoài mã nguồn.
 *
 * Thứ tự: hằng số trong wp-config.php (ví dụ CHECKIN_PAYOS_API_KEY) rồi tới option trong DB
 * (checkin_mkt192_<tên>). Không có giá trị thì trả chuỗi rỗng và nơi gọi phải TỪ CHỐI yêu cầu,
 * không được rơi về một giá trị mặc định viết cứng (bản trước 5.3.9.10 viết cứng các khoá này trong git).
 *
 * Tên dùng:
 *   payos_client_id, payos_api_key, payos_checksum_key, payos_webhook_secret
 *   api_token                  token cho route /system/* (header X-API-Token)
 *   lark_verification_token    mặc định đọc option cũ `lark_verification_token`
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!function_exists('checkin_mkt192_secret')) {
    function checkin_mkt192_secret($name) {
        $const = 'CHECKIN_' . strtoupper($name);
        if (defined($const) && constant($const) !== '') {
            return (string) constant($const);
        }
        // Token Lark đã có option riêng từ trước, giữ tên cũ để không phải nhập lại
        $option = $name === 'lark_verification_token' ? 'lark_verification_token' : 'checkin_mkt192_' . $name;
        return (string) get_option($option, '');
    }
}

if (!function_exists('checkin_mkt192_secret_equals')) {
    /** So sánh hằng thời gian; bí mật chưa cấu hình thì luôn sai. */
    function checkin_mkt192_secret_equals($name, $given) {
        $expected = checkin_mkt192_secret($name);
        if ($expected === '' || !is_string($given) || $given === '') {
            return false;
        }
        return hash_equals($expected, $given);
    }
}
