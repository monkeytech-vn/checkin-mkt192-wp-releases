<?php
if (!defined('ABSPATH')) exit;
// Chạy bằng wp eval-file trong WordPress local riêng, không chạy trên site khách.
if (!defined('WP_CLI') || !WP_CLI || !in_array(wp_parse_url(home_url(), PHP_URL_HOST), ['localhost', '127.0.0.1'], true)) {
    throw new RuntimeException('Chỉ chạy kiểm tra trên WordPress local.');
}
global $wpdb;
wp_set_current_user(1);
global $check_count;
$check_count = 0;
function ckm_check($condition, $label) {
    global $check_count;
    if (!$condition) throw new RuntimeException('FAIL: ' . $label);
    $check_count++;
    echo 'PASS: ' . $label . "\n";
}
function ckm_request($period, $name = '') {
    $request = new WP_REST_Request('POST');
    $request->set_param('period', $period);
    $request->set_param('staff_name', $name);
    return $request;
}
$period = current_time('Y-m');
$previous = date('Y-m', strtotime($period . '-01 -1 month'));
$staff_table = $wpdb->prefix . 'checkin_mkt192_staff';
$salary_table = $wpdb->prefix . 'checkin_mkt192_hairdresser_salary';
$kpi_table = $wpdb->prefix . 'checkin_mkt192_kpi_results';
$social_table = $wpdb->prefix . 'checkin_mkt192_social_posts';
$wpdb->query('START TRANSACTION');
try {
    foreach (['ON', 'OFF', 'BUSY', 'PAUSE', 'ARCHIVED', 'DELETED'] as $status) {
        $name = 'Codex Test ' . $status;
        ckm_check($wpdb->insert($staff_table, ['employee_id' => 'CT-' . $status, 'ou_id' => 'local', 'user_login' => 'ct-' . strtolower($status), 'display_name' => $name, 'user_email' => 'local@example.test', 'user_role' => 'Thợ Chính', 'status' => $status]) !== false, 'seed ' . $status);
        ckm_check(checkin_mkt192_staff_can_autocompute_salary($name) === in_array($status, ['ON', 'OFF', 'BUSY', 'PAUSE'], true), 'eligibility ' . $status);
    }
    foreach (['ARCHIVED', 'DELETED', 'MISSING'] as $status) {
        ckm_check(checkin_mkt192_maybe_autocompute_salary('hairdresser', 'Codex Test ' . $status, $period) === false, 'no automatic salary ' . $status);
    }
    ckm_check(count(checkin_mkt192_list_hairdressers()) === 4, 'bulk staff includes OFF/PAUSE, excludes resigned');
    ckm_check(checkin_mkt192_list_hairdressers('Codex Test ARCHIVED') === ['Codex Test ARCHIVED'], 'manual historical staff stays accessible');
    // Bản ghi đã chốt phải giữ nguyên khi tính hàng loạt.
    ckm_check($wpdb->insert($salary_table, ['staff_id' => 0, 'staff_name' => 'Codex Test ON', 'period' => $period, 'level_name' => 'local', 'actual_salary' => 123456, 'xac_nhan_luong' => 'Đồng ý']) !== false, 'seed locked salary');
    checkin_mkt192_evaluate_kpi_and_update_salary($period);
    checkin_mkt192_update_hairdresser_salary(ckm_request($period));
    foreach (['ARCHIVED', 'DELETED'] as $status) {
        $name = 'Codex Test ' . $status;
        ckm_check((int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $salary_table WHERE staff_name=%s AND period=%s", $name, $period)) === 0, 'bulk no salary ' . $status);
        ckm_check((int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $kpi_table WHERE staff_name=%s AND period=%s", $name, $period)) === 0, 'bulk no KPI ' . $status);
    }
    ckm_check((int)$wpdb->get_var("SELECT actual_salary FROM $salary_table WHERE staff_name='Codex Test ON'") === 123456, 'locked salary unchanged');
    foreach (['OFF', 'BUSY', 'PAUSE'] as $status) {
        ckm_check((int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $salary_table WHERE staff_name=%s AND period=%s", 'Codex Test ' . $status, $period)) === 1, 'active salary ' . $status);
    }
    checkin_mkt192_update_hairdresser_salary(ckm_request($previous, 'Codex Test ARCHIVED'));
    ckm_check((int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $salary_table WHERE staff_name='Codex Test ARCHIVED' AND period=%s", $previous)) === 1, 'manual final salary can still be calculated');
    $before = $wpdb->get_row($wpdb->prepare("SELECT * FROM $salary_table WHERE staff_name='Codex Test ARCHIVED' AND period=%s", $previous), ARRAY_A);
    ckm_check(checkin_mkt192_maybe_autocompute_salary('hairdresser', 'Codex Test ARCHIVED', $previous) === false, 'viewing final salary never recalculates archived staff');
    ckm_check($before === $wpdb->get_row($wpdb->prepare("SELECT * FROM $salary_table WHERE staff_name='Codex Test ARCHIVED' AND period=%s", $previous), ARRAY_A), 'final salary remains unchanged');
    $nonce = wp_create_nonce('wp_rest');
    $save = function ($id, $aliases = []) use ($nonce, $period) {
        $r = new WP_REST_Request('POST');
        foreach (['display_name' => 'Codex Test ON', 'post_type' => 'facebook', 'post_id' => $id, 'content_ids' => $aliases, 'post_date' => $period . '-01', 'nonce' => $nonce] as $k => $v) $r->set_param($k, $v);
        return checkin_mkt192_wp_staff_update_social_post($r);
    };
    ckm_check($save('100_123')->get_status() === 200, 'feed video saved');
    ckm_check($save('456', ['123', '456'])->get_status() === 200, 'same reel alternate ID skipped');
    ckm_check($save('123')->get_status() === 200, 'resync skipped');
    ckm_check($save('456')->get_status() === 200, 'video-only later sync skipped through saved alias');
    ckm_check($save('789')->get_status() === 200, 'second content same day saved');
    ckm_check($save('bad')->get_status() === 400, 'invalid ID rejected');
    ckm_check((int)$wpdb->get_var("SELECT COUNT(*) FROM $social_table WHERE staff_name='Codex Test ON'") === 2, 'two distinct contents persisted');
    // Giữ dữ liệu cũ, nhưng KPI không cộng hai lần một mã bài đã bị ghi trùng.
    $wpdb->insert($social_table, ['staff_name' => 'Codex Test ON', 'post_type' => 'facebook', 'post_id' => '789', 'post_date' => $period . '-01']);
    $actual = checkin_mkt192_kpi_actuals('Codex Test ON', $period);
    ckm_check($actual['post_fb'] === 2, 'KPI ignores legacy duplicate rows');
    $r = ckm_request($period, 'Codex Test ON');
    $r->set_param('start_date', $period . '-01');
    $r->set_param('end_date', date('Y-m-t', strtotime($period . '-01')));
    ckm_check(checkin_mkt192_get_social_posts_count($r)['post_count'] === 2, 'KPI count API matches actuals');
    ckm_check($wpdb->last_error === '', 'no remaining SQL error');
    echo "PASS TOTAL: $check_count\n";
} finally {
    $wpdb->query('ROLLBACK');
}
