# Kiểm tra lương và đồng bộ Facebook

- Chạy kiểm tra dữ liệu Facebook: `node --test tests/facebook-posts.test.cjs`.
- Chạy lại với múi giờ trình duyệt khác: `TZ=America/Los_Angeles node --test tests/facebook-posts.test.cjs`.
- Trên WordPress local riêng đã kích hoạt plugin, chạy `wp eval-file wp-content/plugins/checkin-mkt192-wp/tests/payroll-social-integration.php`.
- Kiểm tra tích hợp cần cơ sở dữ liệu thử riêng, chưa có nhân viên. Script từ chối host khác localhost/127.0.0.1 và rollback dữ liệu thử khi kết thúc.
- Không dùng dữ liệu hoặc token Facebook thật trong fixture.

Kiểm tra tích hợp xác nhận trạng thái nhân viên, tính lương/KPI hàng loạt, phiếu đã chốt, kỳ lương cuối tính riêng và lưu nội dung trùng qua ID bài viết/video. Kiểm tra JavaScript xác nhận phân kỳ theo giờ Việt Nam, phân trang, nhiều bài cùng ngày, tài khoản chỉ có video và thiếu quyền đọc video.

Việc đối chiếu Reels thật cần phiên Facebook của chính thợ có quyền user_posts và user_videos. Bài/video không được Facebook trả về không thể xác nhận chỉ bằng fixture. Luồng đồng bộ báo dữ liệu chưa đầy đủ khi một nguồn lỗi hoặc bị giới hạn phân trang.
