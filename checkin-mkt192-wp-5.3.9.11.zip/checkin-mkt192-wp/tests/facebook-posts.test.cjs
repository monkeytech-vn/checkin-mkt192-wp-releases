const {test} = require('node:test');
const assert = require('node:assert/strict');
const fb = require('../frontend/assets/js/utils/facebook-posts.js');
const now = new Date('2026-11-02T20:00:00+07:00');
const post = (id, created_time, extra = {}) => ({ id, created_time, ...extra });
test('Vietnam midnight and month end, independent of browser timezone', () => {
  assert.equal(fb.day('2026-10-31T17:00:00Z'), '2026-11-01');
  const rows = [post('1', '2026-10-31T16:59:59Z'), post('2', '2026-10-31T17:00:00Z')];
  assert.deepEqual(fb.select(rows, 'lastMonth', now).map(p => p.id), ['1']);
  assert.deepEqual(fb.select(rows, 'thisMonth', now).map(p => p.id), ['2']);
  assert.deepEqual(fb.bounds('lastMonth', new Date('2027-01-01T01:00:00+07:00')), ['2026-12-01', '2027-01-01']);
});
test('multiple posts in one day count, video IDs survive, Reels duplicated in feed count once', () => {
  const time = '2026-11-02T12:00:00Z';
  const rows = fb.merge([post('100_10', time, {attachments:{data:[{media_type:'video',target:{id:'20'}}]}}),post('100_11', time)], [post('20', time), post('30', time), post('bad',time)]);
  assert.deepEqual(rows.map(p => p.id), ['10','11','30']);
  assert.deepEqual(rows[0].content_ids, ['10','20']);
  assert.equal(fb.select(rows,'today',now).length,3);
});
test('reads both edges and all paging, only keeps last two months', async () => {
  const urls = [];
  const request = async url => {
    urls.push(url);
    if(url.includes('after=next')) return {ok:true,json:async()=>({data:[post('100_12','2026-10-31T23:50:00+07:00')]})};
    if(new URL(url).searchParams.get('fields').startsWith('posts')) return {ok:true,json:async()=>({posts:{data:[post('100_10','2026-11-02T12:00:00Z')],paging:{next:'https://graph.facebook.com/v22.0/100/posts?after=next'}}})};
    assert.match(new URL(url).searchParams.get('fields'),/videos.type\(uploaded\)/);
    return {ok:true,json:async()=>({videos:{data:[post('30','2026-10-05T00:00:00+07:00'),post('40','2026-09-01T00:00:00+07:00')]}})};
  };
  const result = await fb.collect('fixture-token', request, now);
  assert.equal(urls.length,3);
  assert.deepEqual(result.posts.map(p=>p.id),['10','12','30']);
  assert.deepEqual(result.warnings,[]);
});
test('missing video permission preserves posts but marks partial, including video-only accounts', async () => {
  const result = await fb.collect('fixture', async url => ({ok:true,json:async()=>new URL(url).searchParams.get('fields').startsWith('posts')?{posts:{data:[post('1','2026-11-02T12:00:00Z')]}}:{error:{code:200}}}), now);
  assert.equal(result.posts.length,1); assert.deepEqual(result.warnings,['videos']);
  const onlyVideos = await fb.collect('fixture', async url => ({ok:true,json:async()=>new URL(url).searchParams.get('fields').startsWith('posts')?{posts:{data:[]}}:{videos:{data:[post('2','2026-11-02T12:00:00Z')]}}}), now);
  assert.equal(onlyVideos.posts[0].id,'2'); assert.deepEqual(onlyVideos.warnings,[]);
});
test('rejects foreign pagination URLs and detects repeated cursors', async () => {
  const result = await fb.collect('fixture', async url => ({ok:true,json:async()=>({posts:{data:[],paging:{next:'https://evil.test/token'}},videos:{data:[]}})}), now);
  assert.deepEqual(result.warnings,['posts']);
});

test('two photo posts sharing the same target remain separate contents', () => {
  const time = '2026-11-02T12:00:00Z';
  const photo = { attachments:{data:[{media_type:'photo',target:{id:'50'}}]} };
  assert.equal(fb.merge([post('1', time, photo),post('2', time, photo)], []).length,2);
});
