/* Dữ liệu bài viết và video dùng chung cho hiển thị và KPI. */
(function (root) {
  'use strict';
  const day = (value) => {
    const date = new Date(value);
    if (!Number.isFinite(date.getTime())) return '';
    return new Intl.DateTimeFormat('en-CA', {
      timeZone: 'Asia/Ho_Chi_Minh', year: 'numeric', month: '2-digit', day: '2-digit',
    }).format(date);
  };
  const shortId = (id) => String(id || '').split('_').pop();
  function bounds(filter, now = new Date()) {
    const today = day(now);
    const [year, month] = today.split('-').map(Number);
    const start = (offset) => day(new Date(Date.UTC(year, month - 1 + offset, 1)));
    if (filter === 'thisMonth') return [start(0), start(1)];
    if (filter === 'lastMonth') return [start(-1), start(0)];
    const previous = day(new Date(Date.parse(today + 'T12:00:00+07:00') - 86400000));
    return filter === 'yesterday' ? [previous, today] : [today, day(new Date(Date.parse(today + 'T12:00:00+07:00') + 86400000))];
  }
  function select(posts, filter, now) {
    const [from, until] = bounds(filter, now);
    return posts.filter((post) => { const date = day(post.created_time); return date >= from && date < until; });
  }
  function merge(posts, videos) {
    const result = [];
    for (const item of [...posts, ...videos]) {
      const id = shortId(item.id);
      if (!/^\d+$/.test(id) || !day(item.created_time)) continue;
      const aliases = [id, ...(item.attachments?.data || []).filter((a) => a.media_type === 'video').map((a) => shortId(a.target?.id))].filter((id) => /^\d+$/.test(id));
      const existing = result.find((post) => post.content_ids.some((alias) => aliases.includes(alias)));
      if (existing) existing.content_ids = [...new Set([...existing.content_ids, ...aliases])];
      else result.push({ ...item, id, message: item.message || item.description || '', content_ids: [...new Set(aliases)] });
    }
    return result.sort((a, b) => Date.parse(b.created_time) - Date.parse(a.created_time));
  }
  async function collect(token, request = fetch, now = new Date()) {
    const from = bounds('lastMonth', now)[0];
    const since = Math.floor(Date.parse(from + 'T00:00:00+07:00') / 1000);
    const fields = { posts: 'id,created_time,message,attachments{media_type,target{id}}', videos: 'id,created_time,description' };
    const warnings = [];
    async function edge(kind) {
      const rows = [];
      let url = 'https://graph.facebook.com/v22.0/me?' + new URLSearchParams({
        fields: `${kind}${kind === 'videos' ? '.type(uploaded)' : `.since(${since})`}.limit(100){${fields[kind]}}`, access_token: token,
      });
      const seen = new Set();
      for (let page = 0; url && page < 100; page++) {
        if (seen.has(url)) { warnings.push(kind); break; }
        seen.add(url);
        try {
          const response = await request(url);
          const body = await response.json();
          if (!response.ok || body.error) throw new Error('Facebook không trả đủ dữ liệu');
          const data = page === 0 ? body[kind] : body;
          if (!Array.isArray(data?.data)) throw new Error('Thiếu quyền đọc ' + kind);
          rows.push(...data.data);
          url = data.paging?.next || '';
          if (url && (new URL(url).hostname !== 'graph.facebook.com' || !url.startsWith('https://'))) throw new Error('Đường dẫn phân trang không hợp lệ');
          if (page === 99 && url) warnings.push(kind);
        } catch (error) { warnings.push(kind); break; }
      }
      return rows.filter((post) => day(post.created_time) >= from);
    }
    const [posts, videos] = await Promise.all([edge('posts'), edge('videos')]);
    return { posts: merge(posts, videos), warnings: [...new Set(warnings)] };
  }
  const api = { day, bounds, select, merge, collect };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.CheckinFacebookPosts = api;
})(typeof window !== 'undefined' ? window : globalThis);
