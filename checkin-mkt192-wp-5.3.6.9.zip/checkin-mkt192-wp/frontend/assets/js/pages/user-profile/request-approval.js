/**
 * Request Approval Modal JavaScript
 * Chức năng tạo và quản lý đơn xin phép
 * Sử dụng HTML có sẵn trong user-profile.html
 */

(function () {
  'use strict';

  // Request type configurations
  const REQUEST_TYPES = {
    late_early: {
      label: 'Đi trễ/Về sớm',
      icon: 'fa-clock',
      emoji: '⏰',
      color: '#f59e0b',
    },
    leave: {
      label: 'Nghỉ phép',
      icon: 'fa-calendar-minus',
      emoji: '🏖️',
      color: '#3b82f6',
    },
    overtime: {
      label: 'Tăng ca',
      icon: 'fa-business-time',
      emoji: '💪',
      color: '#10b981',
    },
    salary_advance: {
      label: 'Ứng lương',
      icon: 'fa-money-bill-wave',
      emoji: '💰',
      color: '#ef4444',
    },
  };

  const STATUS_LABELS = {
    pending: 'Chờ duyệt',
    approved: 'Đã duyệt',
    rejected: 'Từ chối',
  };

  /**
   * Request Approval Modal Class
   */
  class RequestApprovalModal {
    constructor() {
      this.modal = document.getElementById('request-approval-modal');
      this.currentType = null;
      this.myRequests = [];
      this.filteredRequests = [];
      this.timeFilter = 'this_month';
      this.isSubmitting = false;

      if (this.modal) {
        this.init();
      }
    }

    init() {
      this.renderTypePills();
      this.createTriggerButton();
      this.bindEvents();
    }

    /**
     * Render type pills vào container
     */
    renderTypePills() {
      const container = document.getElementById('request-type-options');
      if (!container) return;

      const pillsHTML = Object.entries(REQUEST_TYPES)
        .map(
          ([type, config]) => `
        <label class="request-type-pill" data-type="${type}">
          <input type="radio" name="request_type" value="${type}">
          <i class="fas ${config.icon}"></i>
          <span>${config.label}</span>
        </label>
      `
        )
        .join('');

      container.innerHTML = pillsHTML;
    }

    /**
     * Render form fields dựa trên type được chọn
     */
    renderFormForType(type) {
      const container = document.getElementById('request-form-container');
      if (!container) return;

      const today = new Date().toISOString().split('T')[0];
      let formHTML = '';

      switch (type) {
        case 'late_early':
          formHTML = `
            <div class="request-form-section active" id="form-late_early">
              <div class="request-form-group">
                <label>Loại <span class="required">*</span></label>
                <div class="sub-type-pills">
                  <label class="sub-type-pill" data-value="late">
                    <input type="radio" name="late_early_type" value="late">
                    <i class="fas fa-sign-in-alt"></i> Đi trễ
                  </label>
                  <label class="sub-type-pill" data-value="early">
                    <input type="radio" name="late_early_type" value="early">
                    <i class="fas fa-sign-out-alt"></i> Về sớm
                  </label>
                </div>
              </div>

              <div class="request-form-row">
                <div class="request-form-group">
                  <label><i class="fas fa-calendar-day"></i> Ngày <span class="required">*</span></label>
                  <input type="date" class="request-form-input" name="late_early_date" value="${today}" min="${today}" required>
                </div>
                <div class="request-form-group">
                  <label><i class="fas fa-stopwatch"></i> Số phút <span class="required">*</span></label>
                  <input type="number" class="request-form-input" name="late_early_minutes" min="1" max="480" placeholder="VD: 30" required>
                </div>
              </div>

              <div class="request-form-group">
                <label><i class="fas fa-comment-alt"></i> Lý do <span class="required">*</span></label>
                <textarea class="request-form-textarea" name="reason_late_early" placeholder="Nhập lý do xin đi trễ/về sớm..." required></textarea>
              </div>
            </div>
          `;
          break;

        case 'leave':
          formHTML = `
            <div class="request-form-section active" id="form-leave">
              <div class="request-form-group">
                <label>Loại nghỉ phép <span class="required">*</span></label>
                <div class="sub-type-pills">
                  <label class="sub-type-pill" data-value="annual">
                    <input type="radio" name="leave_type" value="annual">
                    <i class="fas fa-umbrella-beach"></i> Phép năm
                  </label>
                  <label class="sub-type-pill" data-value="unpaid">
                    <input type="radio" name="leave_type" value="unpaid">
                    <i class="fas fa-file-invoice"></i> Không lương
                  </label>
                  <label class="sub-type-pill" data-value="sick">
                    <input type="radio" name="leave_type" value="sick">
                    <i class="fas fa-hospital"></i> Nghỉ ốm
                  </label>
                </div>
              </div>

              <div class="request-form-row">
                <div class="request-form-group">
                  <label><i class="fas fa-calendar-alt"></i> Từ ngày <span class="required">*</span></label>
                  <input type="date" class="request-form-input" name="leave_start_date" value="${today}" min="${today}" required>
                </div>
                <div class="request-form-group">
                  <label><i class="fas fa-calendar-alt"></i> Đến ngày <span class="required">*</span></label>
                  <input type="date" class="request-form-input" name="leave_end_date" value="${today}" min="${today}" required>
                </div>
              </div>

              <div class="request-form-group">
                <label><i class="fas fa-calculator"></i> Tổng ngày nghỉ</label>
                <div class="calculated-value" id="leave-total-days">
                  <i class="fas fa-calendar-check"></i>
                  <span class="value">1 ngày</span>
                </div>
              </div>

              <div class="request-form-group">
                <label><i class="fas fa-comment-alt"></i> Lý do <span class="required">*</span></label>
                <textarea class="request-form-textarea" name="reason_leave" placeholder="Nhập lý do xin nghỉ phép..." required></textarea>
              </div>
            </div>
          `;
          break;

        case 'overtime':
          formHTML = `
            <div class="request-form-section active" id="form-overtime">
              <div class="request-form-group">
                <label><i class="fas fa-calendar-day"></i> Ngày tăng ca <span class="required">*</span></label>
                <input type="date" class="request-form-input" name="overtime_date" value="${today}" min="${today}" required>
              </div>

              <div class="request-form-row">
                <div class="request-form-group">
                  <label><i class="fas fa-play-circle"></i> Giờ bắt đầu <span class="required">*</span></label>
                  <input type="time" class="request-form-input" name="overtime_start_time" value="18:00" required>
                </div>
                <div class="request-form-group">
                  <label><i class="fas fa-stop-circle"></i> Giờ kết thúc <span class="required">*</span></label>
                  <input type="time" class="request-form-input" name="overtime_end_time" value="21:00" required>
                </div>
              </div>

              <div class="request-form-group">
                <label><i class="fas fa-hourglass-half"></i> Tổng giờ tăng ca</label>
                <div class="calculated-value" id="overtime-total-hours">
                  <i class="fas fa-clock"></i>
                  <span class="value">3.0 giờ</span>
                </div>
              </div>

              <div class="request-form-group">
                <label><i class="fas fa-comment-alt"></i> Lý do <span class="required">*</span></label>
                <textarea class="request-form-textarea" name="reason_overtime" placeholder="Nhập lý do xin tăng ca..." required></textarea>
              </div>
            </div>
          `;
          break;

        case 'salary_advance':
          formHTML = `
            <div class="request-form-section active" id="form-salary_advance">
              <div class="request-form-group">
                <label><i class="fas fa-money-bill-wave"></i> Số tiền xin ứng <span class="required">*</span></label>
                <div class="amount-input-wrapper">
                  <span class="currency-prefix">VNĐ</span>
                  <input type="number" class="request-form-input" name="advance_amount" min="100000" step="50000" placeholder="VD: 2000000" required>
                </div>
              </div>

              <div class="request-form-group">
                <label><i class="fas fa-comment-alt"></i> Lý do <span class="required">*</span></label>
                <textarea class="request-form-textarea" name="reason_salary_advance" placeholder="Nhập lý do xin ứng lương..." required></textarea>
              </div>
            </div>
          `;
          break;
      }

      container.innerHTML = formHTML;
      this.bindFormEvents();
    }

    /**
     * Bind events cho form sau khi render
     */
    bindFormEvents() {
      const container = document.getElementById('request-form-container');
      if (!container) return;

      // Sub-type pills
      container.querySelectorAll('.sub-type-pill').forEach((pill) => {
        pill.addEventListener('click', () => {
          const parentPills = pill.closest('.sub-type-pills');
          parentPills
            .querySelectorAll('.sub-type-pill')
            .forEach((p) => p.classList.remove('active'));
          pill.classList.add('active');
          pill.querySelector('input').checked = true;
          this.validateForm();
        });
      });

      // Date inputs for leave calculation
      const leaveStartDate = container.querySelector('[name="leave_start_date"]');
      const leaveEndDate = container.querySelector('[name="leave_end_date"]');
      if (leaveStartDate && leaveEndDate) {
        leaveStartDate.addEventListener('change', () => this.calculateLeaveDays());
        leaveEndDate.addEventListener('change', () => this.calculateLeaveDays());
      }

      // Time inputs for overtime calculation
      const overtimeStart = container.querySelector('[name="overtime_start_time"]');
      const overtimeEnd = container.querySelector('[name="overtime_end_time"]');
      if (overtimeStart && overtimeEnd) {
        overtimeStart.addEventListener('change', () => this.calculateOvertimeHours());
        overtimeEnd.addEventListener('change', () => this.calculateOvertimeHours());
        // Calculate initial value
        this.calculateOvertimeHours();
      }

      // Form validation on input
      container.querySelectorAll('input, textarea, select').forEach((input) => {
        input.addEventListener('input', () => this.validateForm());
        input.addEventListener('change', () => this.validateForm());
      });
    }

    /**
     * Create floating trigger button
     */
    createTriggerButton() {
      // Check if button already exists
      if (document.getElementById('request-approval-trigger')) return;

      const buttonHTML = `
        <button id="request-approval-trigger" class="request-approval-trigger" aria-label="Tạo đơn xin phép">
          <i class="fas fa-file-signature"></i>
        </button>
      `;
      document.body.insertAdjacentHTML('beforeend', buttonHTML);
    }

    /**
     * Bind all events
     */
    bindEvents() {
      // Trigger button
      const triggerBtn = document.getElementById('request-approval-trigger');
      if (triggerBtn) {
        triggerBtn.addEventListener('click', () => this.open());
      }

      // Close button
      const closeBtn = this.modal.querySelector('.request-approval-close');
      if (closeBtn) {
        closeBtn.addEventListener('click', () => this.close());
      }

      // Overlay click to close
      const overlay = this.modal.querySelector('.request-approval-overlay');
      if (overlay) {
        overlay.addEventListener('click', () => this.close());
      }

      // Cancel button
      const cancelBtn = document.getElementById('request-cancel-btn');
      if (cancelBtn) {
        cancelBtn.addEventListener('click', () => this.close());
      }

      // Submit button
      const submitBtn = document.getElementById('request-submit-btn');
      if (submitBtn) {
        submitBtn.addEventListener('click', () => this.submit());
      }

      // Type pills - using event delegation
      const typeOptions = document.getElementById('request-type-options');
      if (typeOptions) {
        typeOptions.addEventListener('click', (e) => {
          const pill = e.target.closest('.request-type-pill');
          if (pill) {
            const type = pill.dataset.type;
            this.selectType(type);
          }
        });
      }

      // Refresh button
      const refreshBtn = document.getElementById('refresh-my-requests');
      if (refreshBtn) {
        refreshBtn.addEventListener('click', () => this.fetchMyRequests());
      }

      // Time filter dropdown
      const timeFilter = document.getElementById('requests-time-filter');
      if (timeFilter) {
        timeFilter.addEventListener('change', (e) => {
          this.timeFilter = e.target.value;
          this.applyFilters();
        });
      }

      // Keyboard escape to close
      document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && this.modal.classList.contains('active')) {
          this.close();
        }
      });
    }

    /**
     * Open modal
     */
    open() {
      this.modal.classList.add('active');
      document.body.style.overflow = 'hidden';
      this.fetchMyRequests();

      // Auto-select first type if none selected
      if (!this.currentType) {
        this.selectType('late_early');
      }
    }

    /**
     * Close modal
     */
    close() {
      this.modal.classList.remove('active');
      document.body.style.overflow = '';
      this.resetForm();
    }

    /**
     * Select request type
     */
    selectType(type) {
      this.currentType = type;

      // Update pills
      const typeOptions = document.getElementById('request-type-options');
      if (typeOptions) {
        typeOptions.querySelectorAll('.request-type-pill').forEach((pill) => {
          const isActive = pill.dataset.type === type;
          pill.classList.toggle('active', isActive);
          const input = pill.querySelector('input');
          if (input) input.checked = isActive;
        });
      }

      // Render form for this type
      this.renderFormForType(type);
      this.validateForm();
    }

    /**
     * Calculate leave days
     */
    calculateLeaveDays() {
      const container = document.getElementById('request-form-container');
      if (!container) return;

      const startInput = container.querySelector('[name="leave_start_date"]');
      const endInput = container.querySelector('[name="leave_end_date"]');
      const display = container.querySelector('#leave-total-days .value');

      if (startInput && endInput && display) {
        if (startInput.value && endInput.value) {
          const start = new Date(startInput.value);
          const end = new Date(endInput.value);

          if (end >= start) {
            const diffTime = Math.abs(end - start);
            const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;
            display.textContent = `${diffDays} ngày`;
          } else {
            display.textContent = 'Ngày không hợp lệ';
          }
        } else {
          display.textContent = '0 ngày';
        }
      }

      this.validateForm();
    }

    /**
     * Calculate overtime hours
     */
    calculateOvertimeHours() {
      const container = document.getElementById('request-form-container');
      if (!container) return;

      const startInput = container.querySelector('[name="overtime_start_time"]');
      const endInput = container.querySelector('[name="overtime_end_time"]');
      const display = container.querySelector('#overtime-total-hours .value');

      if (startInput && endInput && display) {
        if (startInput.value && endInput.value) {
          const [startH, startM] = startInput.value.split(':').map(Number);
          const [endH, endM] = endInput.value.split(':').map(Number);

          const startMinutes = startH * 60 + startM;
          const endMinutes = endH * 60 + endM;

          if (endMinutes > startMinutes) {
            const diffMinutes = endMinutes - startMinutes;
            const hours = (diffMinutes / 60).toFixed(1);
            display.textContent = `${hours} giờ`;
          } else {
            display.textContent = 'Giờ không hợp lệ';
          }
        } else {
          display.textContent = '0 giờ';
        }
      }

      this.validateForm();
    }

    /**
     * Validate form
     */
    validateForm() {
      const submitBtn = document.getElementById('request-submit-btn');
      if (!submitBtn) return;

      let isValid = false;

      if (!this.currentType) {
        submitBtn.disabled = true;
        return;
      }

      const container = document.getElementById('request-form-container');
      if (!container) {
        submitBtn.disabled = true;
        return;
      }

      const section = container.querySelector(`.request-form-section`);
      if (!section) {
        submitBtn.disabled = true;
        return;
      }

      switch (this.currentType) {
        case 'late_early':
          const lateEarlyType = section.querySelector('[name="late_early_type"]:checked');
          const lateEarlyDate = section.querySelector('[name="late_early_date"]')?.value;
          const lateEarlyMinutes = section.querySelector('[name="late_early_minutes"]')?.value;
          const reasonLateEarly = section
            .querySelector('[name="reason_late_early"]')
            ?.value?.trim();
          isValid = lateEarlyType && lateEarlyDate && lateEarlyMinutes > 0 && reasonLateEarly;
          break;

        case 'leave':
          const leaveType = section.querySelector('[name="leave_type"]:checked');
          const leaveStart = section.querySelector('[name="leave_start_date"]')?.value;
          const leaveEnd = section.querySelector('[name="leave_end_date"]')?.value;
          const reasonLeave = section.querySelector('[name="reason_leave"]')?.value?.trim();
          isValid =
            leaveType &&
            leaveStart &&
            leaveEnd &&
            reasonLeave &&
            new Date(leaveEnd) >= new Date(leaveStart);
          break;

        case 'overtime':
          const overtimeDate = section.querySelector('[name="overtime_date"]')?.value;
          const overtimeStart = section.querySelector('[name="overtime_start_time"]')?.value;
          const overtimeEnd = section.querySelector('[name="overtime_end_time"]')?.value;
          const reasonOvertime = section.querySelector('[name="reason_overtime"]')?.value?.trim();
          if (overtimeStart && overtimeEnd) {
            const [startH, startM] = overtimeStart.split(':').map(Number);
            const [endH, endM] = overtimeEnd.split(':').map(Number);
            isValid = overtimeDate && reasonOvertime && endH * 60 + endM > startH * 60 + startM;
          }
          break;

        case 'salary_advance':
          const advanceAmount = section.querySelector('[name="advance_amount"]')?.value;
          const reasonAdvance = section
            .querySelector('[name="reason_salary_advance"]')
            ?.value?.trim();
          isValid = advanceAmount >= 100000 && reasonAdvance;
          break;
      }

      submitBtn.disabled = !isValid;
    }

    /**
     * Reset form
     */
    resetForm() {
      this.currentType = null;

      // Reset type pills
      const typeOptions = document.getElementById('request-type-options');
      if (typeOptions) {
        typeOptions.querySelectorAll('.request-type-pill').forEach((pill) => {
          pill.classList.remove('active');
          const input = pill.querySelector('input');
          if (input) input.checked = false;
        });
      }

      // Clear form container
      const formContainer = document.getElementById('request-form-container');
      if (formContainer) {
        formContainer.innerHTML = '';
      }

      // Reset submit button
      const submitBtn = document.getElementById('request-submit-btn');
      if (submitBtn) {
        submitBtn.disabled = true;
      }
    }

    /**
     * Collect form data
     */
    collectFormData() {
      const container = document.getElementById('request-form-container');
      if (!container) return null;

      const section = container.querySelector('.request-form-section');
      if (!section) return null;

      const data = {
        request_type: this.currentType,
      };

      switch (this.currentType) {
        case 'late_early':
          data.late_early_type = section.querySelector('[name="late_early_type"]:checked')?.value;
          data.late_early_date = section.querySelector('[name="late_early_date"]')?.value;
          data.late_early_minutes = section.querySelector('[name="late_early_minutes"]')?.value;
          data.reason = section.querySelector('[name="reason_late_early"]')?.value;
          break;

        case 'leave':
          data.leave_type = section.querySelector('[name="leave_type"]:checked')?.value;
          data.leave_start_date = section.querySelector('[name="leave_start_date"]')?.value;
          data.leave_end_date = section.querySelector('[name="leave_end_date"]')?.value;
          const display = container.querySelector('#leave-total-days .value');
          data.leave_total_days = display ? parseInt(display.textContent) : 1;
          data.reason = section.querySelector('[name="reason_leave"]')?.value;
          break;

        case 'overtime':
          data.overtime_date = section.querySelector('[name="overtime_date"]')?.value;
          data.overtime_start_time = section.querySelector('[name="overtime_start_time"]')?.value;
          data.overtime_end_time = section.querySelector('[name="overtime_end_time"]')?.value;
          const hoursDisplay = container.querySelector('#overtime-total-hours .value');
          data.overtime_hours = hoursDisplay ? parseFloat(hoursDisplay.textContent) : 0;
          data.reason = section.querySelector('[name="reason_overtime"]')?.value;
          break;

        case 'salary_advance':
          data.advance_amount = section.querySelector('[name="advance_amount"]')?.value;
          data.reason = section.querySelector('[name="reason_salary_advance"]')?.value;
          break;
      }

      return data;
    }

    /**
     * Submit form
     */
    async submit() {
      if (this.isSubmitting) return;

      const formData = this.collectFormData();
      if (!formData) {
        this.showToast('Vui lòng điền đầy đủ thông tin', 'error');
        return;
      }

      const submitBtn = document.getElementById('request-submit-btn');
      this.isSubmitting = true;

      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Đang gửi...';
      }

      try {
        const nonce = typeof checkinData !== 'undefined' ? checkinData.nonce : '';
        const response = await fetch('/wp-json/vg/v1/approval-requests', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-WP-Nonce': nonce,
          },
          body: JSON.stringify(formData),
        });

        const result = await response.json();

        if (response.ok && result.success) {
          this.showToast('Đã gửi đơn thành công!', 'success');
          this.resetForm();
          this.selectType('late_early');
          this.fetchMyRequests();
        } else {
          throw new Error(result.message || 'Có lỗi xảy ra');
        }
      } catch (error) {
        console.error('Submit error:', error);
        this.showToast(error.message || 'Không thể gửi đơn. Vui lòng thử lại.', 'error');
      } finally {
        this.isSubmitting = false;
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.innerHTML = '<i class="fas fa-paper-plane"></i> Gửi ngay';
        }
        this.validateForm();
      }
    }

    /**
     * Fetch my requests
     */
    async fetchMyRequests() {
      const listContainer = document.getElementById('my-requests-list');
      if (!listContainer) return;

      const refreshBtn = document.getElementById('refresh-my-requests');
      if (refreshBtn) {
        refreshBtn.classList.add('spinning');
      }

      try {
        const nonce = typeof checkinData !== 'undefined' ? checkinData.nonce : '';
        const response = await fetch('/wp-json/vg/v1/my-approval-requests', {
          headers: {
            'X-WP-Nonce': nonce,
          },
        });

        const result = await response.json();

        if (response.ok) {
          this.myRequests = result.data || [];
          this.applyFilters(); // Apply filters after fetching
        }
      } catch (error) {
        console.error('Fetch requests error:', error);
      } finally {
        if (refreshBtn) {
          refreshBtn.classList.remove('spinning');
        }
      }
    }

    /**
     * Render my requests list
     */
    renderMyRequests() {
      const listContainer = document.getElementById('my-requests-list');
      if (!listContainer) return;

      // Use filtered requests
      const requests = this.filteredRequests || this.myRequests || [];

      if (requests.length === 0) {
        const emptyMessage =
          this.myRequests.length > 0
            ? 'Không có đơn nào trong khoảng thời gian này'
            : 'Chưa có đơn nào';
        listContainer.innerHTML = `
          <div class="my-requests-empty">
            <i class="fas fa-inbox"></i>
            <p>${emptyMessage}</p>
          </div>
        `;
        return;
      }

      listContainer.innerHTML = requests
        .map((request) => {
          const typeConfig = REQUEST_TYPES[request.request_type] || {};
          const statusLabel = STATUS_LABELS[request.status] || request.status;
          const detail = this.getRequestDetail(request);
          const createdDate = new Date(request.created_at).toLocaleDateString('vi-VN', {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
          });

          // Chỉ hiện nút thu hồi cho đơn đang chờ duyệt
          const showRevoke = request.status === 'pending';

          return `
          <div class="my-request-card" data-request-id="${request.request_id}">
            <div class="my-request-icon ${request.request_type}">
              <i class="fas ${typeConfig.icon || 'fa-file'}"></i>
            </div>
            <div class="my-request-info">
              <div class="my-request-type">${typeConfig.label || request.request_type}</div>
              <div class="my-request-date">${createdDate}</div>
              <div class="my-request-detail">${detail}</div>
            </div>
            <div class="my-request-right">
              <span class="my-request-status ${request.status}">${statusLabel}</span>
              ${
                showRevoke
                  ? `
                <button type="button" class="my-request-revoke-btn" data-request-id="${request.request_id}" title="Thu hồi đơn">
                  <i class="fas fa-undo"></i> Thu hồi
                </button>
              `
                  : ''
              }
            </div>
          </div>
        `;
        })
        .join('');

      // Bind revoke button events
      this.bindRevokeButtons();
    }

    /**
     * Bind revoke button click events
     */
    bindRevokeButtons() {
      const revokeButtons = document.querySelectorAll('.my-request-revoke-btn');
      revokeButtons.forEach((btn) => {
        btn.addEventListener('click', (e) => {
          e.stopPropagation();
          const requestId = btn.dataset.requestId;
          this.revokeRequest(requestId);
        });
      });
    }

    /**
     * Revoke (cancel) a pending request
     */
    async revokeRequest(requestId) {
      if (!confirm('Bạn có chắc muốn thu hồi đơn này? Hành động này không thể hoàn tác.')) {
        return;
      }

      try {
        const response = await fetch(`/wp-json/vg/v1/approval-requests/${requestId}/cancel`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-WP-Nonce': checkinData.nonce,
          },
        });

        const result = await response.json();

        if (response.ok && result.success) {
          this.showToast('Đã thu hồi đơn thành công!', 'success');
          this.fetchMyRequests(); // Refresh list
        } else {
          this.showToast(result.message || 'Không thể thu hồi đơn', 'error');
        }
      } catch (error) {
        console.error('Revoke error:', error);
        this.showToast('Lỗi kết nối. Vui lòng thử lại.', 'error');
      }
    }

    /**
     * Get request detail text
     */
    getRequestDetail(request) {
      switch (request.request_type) {
        case 'late_early':
          const typeLabel = request.late_early_type === 'late' ? 'Đi trễ' : 'Về sớm';
          return `${typeLabel} ${request.late_early_minutes} phút - ${request.late_early_date}`;

        case 'leave':
          const leaveTypeLabels = { annual: 'Phép năm', unpaid: 'Không lương', sick: 'Nghỉ ốm' };
          return `${leaveTypeLabels[request.leave_type] || ''}: ${request.leave_start_date} → ${
            request.leave_end_date
          }`;

        case 'overtime':
          return `${request.overtime_date}: ${request.overtime_start_time} - ${request.overtime_end_time}`;

        case 'salary_advance':
          const amount = parseFloat(request.advance_amount || 0).toLocaleString('vi-VN');
          return `Số tiền: ${amount} VNĐ`;

        default:
          return request.reason?.substring(0, 50) || '';
      }
    }

    /**
     * Show toast notification
     */
    showToast(message, type = 'info') {
      if (typeof showCheckinToast === 'function') {
        showCheckinToast({ message, type, duration: 3000 });
      } else {
        alert(message);
      }
    }

    /**
     * Apply filters (type + time)
     */
    applyFilters() {
      let filtered = [...this.myRequests];

      // Filter by current type (if user wants to see only current type)
      // For now, we show all types but you can enable this:
      // if (this.currentType) {
      //   filtered = filtered.filter(r => r.request_type === this.currentType);
      // }

      // Filter by time
      filtered = this.filterByTime(filtered);

      this.filteredRequests = filtered;
      this.renderMyRequests();
    }

    /**
     * Filter requests by time period
     */
    filterByTime(requests) {
      const now = new Date();
      const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      const yesterday = new Date(today);
      yesterday.setDate(yesterday.getDate() - 1);
      const sevenDaysAgo = new Date(today);
      sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
      const thisMonthStart = new Date(now.getFullYear(), now.getMonth(), 1);
      const lastMonthStart = new Date(now.getFullYear(), now.getMonth() - 1, 1);
      const lastMonthEnd = new Date(now.getFullYear(), now.getMonth(), 0);

      switch (this.timeFilter) {
        case 'upcoming':
          // Đơn có ngày trong tương lai
          return requests.filter((r) => {
            const requestDate = this.getRequestDate(r);
            return requestDate && requestDate > today;
          });

        case 'today':
          return requests.filter((r) => {
            const createdDate = new Date(r.created_at);
            return createdDate >= today;
          });

        case 'yesterday':
          return requests.filter((r) => {
            const createdDate = new Date(r.created_at);
            return createdDate >= yesterday && createdDate < today;
          });

        case '7days':
          return requests.filter((r) => {
            const createdDate = new Date(r.created_at);
            return createdDate >= sevenDaysAgo;
          });

        case 'this_month':
          return requests.filter((r) => {
            const createdDate = new Date(r.created_at);
            return createdDate >= thisMonthStart;
          });

        case 'last_month':
          return requests.filter((r) => {
            const createdDate = new Date(r.created_at);
            return createdDate >= lastMonthStart && createdDate <= lastMonthEnd;
          });

        case 'all':
        default:
          return requests;
      }
    }

    /**
     * Get the main date of a request for filtering
     */
    getRequestDate(request) {
      switch (request.request_type) {
        case 'late_early':
          return request.late_early_date ? new Date(request.late_early_date) : null;
        case 'leave':
          return request.leave_start_date ? new Date(request.leave_start_date) : null;
        case 'overtime':
          return request.overtime_date ? new Date(request.overtime_date) : null;
        default:
          return request.created_at ? new Date(request.created_at) : null;
      }
    }
  }

  // Initialize when DOM is ready
  document.addEventListener('DOMContentLoaded', () => {
    // Only initialize if on user-profile page
    if (document.getElementById('request-approval-modal')) {
      window.requestApprovalModal = new RequestApprovalModal();
    }
  });
})();
