// Page loading functions (shared with app-tho)
(function () {
  /**
   * Show page loading overlay
   */
  window.showPageLoading = function () {
    // Check if overlay already exists
    if (document.querySelector('.checkin-glassmorphism-loader')) return;

    const overlay = document.createElement('div');
    overlay.className = 'checkin-glassmorphism-loader';
    overlay.innerHTML =
      '<div class="checkin-glass-container">' +
      '<div class="checkin-spinner-wrapper">' +
      '<div class="checkin-spinner-inner"></div>' +
      '</div>' +
      '<div class="checkin-loader-text">Đang tải</div>' +
      '</div>';
    document.body.appendChild(overlay);
  };

  /**
   * Hide page loading overlay
   */
  window.hidePageLoading = function () {
    const loader = document.querySelector('.checkin-glassmorphism-loader');
    if (loader) {
      loader.style.opacity = '0';
      setTimeout(() => loader.remove(), 300);
    }
  };
})();

document.addEventListener('DOMContentLoaded', () => {
  // Hiển thị page loading
  showPageLoading();

  /* ========================================
     COMMENTED API FUNCTIONS - For future reference
     ======================================== */
  /*
  // Fetch checkin history from API
  async function fetchCheckinHistory(staffName) {
    try {
      const response = await fetch(
        `${checkinData.restUrl}get-checkin-logs?staff_name=${encodeURIComponent(staffName)}`,
        {
          method: 'GET',
          headers: { 'X-WP-Nonce': checkinData.nonce },
        }
      );
      const result = await response.json();
      return result.success ? result.data : [];
    } catch (error) {
      console.error('Error fetching checkin history:', error);
      return [];
    }
  }

  // Fetch late history from API
  async function fetchLateHistory(staffName) {
    try {
      const response = await fetch(
        `${checkinData.restUrl}get-late-logs?staff_name=${encodeURIComponent(staffName)}`,
        {
          method: 'GET',
          headers: { 'X-WP-Nonce': checkinData.nonce },
        }
      );
      const result = await response.json();
      return result.success ? result.data : [];
    } catch (error) {
      console.error('Error fetching late history:', error);
      return [];
    }
  }
  */

  // Constants and global variables
  const originalAvatar = document.querySelector('.checkin-mkt-avatar-image')?.getAttribute('src');
  let allPosts = [];
  let lastToastTime = 0;
  const TOAST_THROTTLE_MS = 500;

  // Toast notification functions
  function showToast(message, type = 'info') {
    const now = Date.now();
    if (now - lastToastTime < TOAST_THROTTLE_MS) {
      return;
    }
    lastToastTime = now;

    if (typeof showCheckinToast === 'function') {
      showCheckinToast({ message, type, duration: 3000 });
    }
  }

  function toastSuccess(message) {
    showToast(message, 'success');
  }

  function toastError(message) {
    showToast(message, 'error');
  }

  function toastWarning(message) {
    showToast(message, 'warning');
  }

  function toastInfo(message) {
    showToast(message, 'info');
  }

  function showError(message) {
    toastError(message);
  }

  function showSuccess(message) {
    toastSuccess(message);
  }

  // showConfirm is now imported from modals.js

  // Utility function to toggle element visibility
  const toggleVisibility = (element, show) => {
    if (!element || typeof show !== 'boolean') {
      return;
    }
    element.style.display = show ? 'flex' : 'none';

    // Nếu đang mở modal (popup), vô hiệu hóa click vào các element bên dưới
    if (show && element.classList.contains('checkin-mkt-popup')) {
      // Vô hiệu hóa pointer events cho tất cả trừ modal
      const allElements = document.querySelectorAll(
        'body > *:not(.checkin-mkt-popup):not(.checkin-glassmorphism-loader)'
      );
      allElements.forEach((el) => {
        if (el !== element) {
          el.style.pointerEvents = 'none';
        }
      });
    } else if (!show && element.classList.contains('checkin-mkt-popup')) {
      // Kích hoạt lại pointer events khi đóng modal
      const allElements = document.querySelectorAll('body > *');
      allElements.forEach((el) => {
        el.style.pointerEvents = '';
      });
    }
  };

  // Helper function to render profile data to UI
  function renderProfileData(data) {
    const updateElement = (selector, value, attribute = 'textContent') => {
      const element = document.querySelector(selector);
      if (element) {
        if (attribute === 'href') {
          element.setAttribute('href', value || '#');
        } else if (attribute === 'src') {
          element.setAttribute('src', value || originalAvatar || '');
        } else {
          element[attribute] = value || 'Chưa cập nhật';
        }
      }
    };

    updateElement('.checkin-mkt-display-name', data.display_name);
    updateElement('.checkin-mkt-user-role', data.user_role || 'Chưa xác định');
    updateElement('.checkin-mkt-avatar-image', data.avatar_url, 'src');
    updateElement('.checkin-mkt-user-birthday', data.birthday);
    updateElement('.checkin-mkt-user-email', data.email);
    updateElement('.checkin-mkt-user-facebook', data.facebook);
    updateElement('.checkin-mkt-user-facebook', data.facebook, 'href');
    updateElement('.checkin-mkt-user-tiktok', data.tiktok);
    updateElement('.checkin-mkt-user-tiktok', data.tiktok, 'href');
    updateElement('.checkin-mkt-user-address', data.address);
    updateElement('.checkin-mkt-user-cccd', data.is_cccd ? 'Đã cập nhật' : 'Chưa cập nhật');
  }

  // Save profile to localStorage
  function saveProfileToLocalStorage(data) {
    try {
      localStorage.setItem('checkin_user_profile', JSON.stringify(data));
      localStorage.setItem('checkin_user_profile_timestamp', Date.now().toString());
    } catch (error) {
      console.error('Error saving profile to localStorage:', error);
    }
  }

  // Load profile from localStorage
  function loadProfileFromLocalStorage() {
    try {
      const profileData = localStorage.getItem('checkin_user_profile');
      const timestamp = localStorage.getItem('checkin_user_profile_timestamp');

      if (profileData && timestamp) {
        // Chỉ dùng cache trong vòng 5 phút
        const age = Date.now() - parseInt(timestamp);
        if (age < 5 * 60 * 1000) {
          return JSON.parse(profileData);
        }
      }
    } catch (error) {
      console.error('Error loading profile from localStorage:', error);
    }
    return null;
  }

  // Set brand settings
  function applyBrandSettings() {
    const logo = document.querySelector('.checkin-mkt-logo');
    if (checkinData.logoUrl) {
      logo.src = checkinData.logoUrl;
    }

    // Set app name
    const appNameElements = document.querySelectorAll('.checkin-mkt-app-name');
    if (checkinData.domain) {
      appNameElements.forEach((el) => {
        el.textContent = checkinData.domain;
      });
    }

    document.documentElement.style.setProperty('--primary-color', checkinData.primaryColor);
    document.documentElement.style.setProperty('--secondary-color', checkinData.secondaryColor);
  }

  // Setup navbar based on user role
  function setupNavbarForRole() {
    const userRole = checkinData.currentUser?.user_role;
    const syncFacebookBtn = document.querySelector('#sync-facebook-btn');
    const adminPanelBtn = document.querySelector('#admin-panel-btn');

    if (userRole === 'administrator') {
      // Ẩn nút Đồng bộ Fb, hiện nút Admin
      if (syncFacebookBtn) syncFacebookBtn.style.display = 'none';
      if (adminPanelBtn) adminPanelBtn.style.display = '';
    } else {
      // Ngược lại: hiện Đồng bộ Fb, ẩn Admin
      if (syncFacebookBtn) syncFacebookBtn.style.display = '';
      if (adminPanelBtn) adminPanelBtn.style.display = 'none';
    }
  }

  // Áp dụng kết quả login vào state hiện tại (nonce + role + navbar) — không cần reload trang
  function applyLoginResult(result) {
    if (result.nonce) {
      checkinData.nonce = result.nonce;
    }
    if (!checkinData.currentUser) {
      checkinData.currentUser = {};
    }
    checkinData.currentUser.is_logged_in = true;
    if (result.wp_role) {
      checkinData.currentUser.user_role = result.wp_role;
    }
    if (result.profile?.display_name) {
      checkinData.currentUser.display_name = result.profile.display_name;
    }
    // Navbar nhận role mới ngay (VD: admin thấy tab Admin không cần load lại)
    setupNavbarForRole();
  }

  // Check login status
  async function checkLoginStatus() {
    // Load từ cache trước nếu có để hiển thị ngay
    const cachedProfile = loadProfileFromLocalStorage();

    try {
      const response = await fetch(`${checkinData.restUrl}user-profile`, {
        method: 'GET',
        headers: { 'X-WP-Nonce': checkinData.nonce },
        credentials: 'include',
      });
      const result = await response.json();
      const isLoggedIn = result.success && response.status !== 401;

      document.body.classList.toggle('checkin-mkt-logged-out', !isLoggedIn);
      const modal = document.getElementById('checkin-mkt-login-modal');
      modal.style.display = isLoggedIn ? 'none' : 'flex';

      if (isLoggedIn && result.data) {
        // Lưu profile vào cache
        saveProfileToLocalStorage(result.data);

        // Render profile từ response (không cần gọi API lần 2)
        renderProfileData(result.data);

        // Ẩn loading sau khi render xong
        hidePageLoading();
      } else if (!isLoggedIn) {
        // Nếu chưa đăng nhập, ẩn loading ngay
        hidePageLoading();
      }
    } catch (error) {
      document.body.classList.add('checkin-mkt-logged-out');
      const modal = document.getElementById('checkin-mkt-login-modal');
      modal.style.display = 'flex';
      hidePageLoading();
    }
  }

  // Google OneTap đã bị xóa - không sử dụng nữa

  // handleGoogleLoginResponse đã bị xóa - không sử dụng nữa

  // Initialize Google Sign-In
  function initGoogleSignIn() {
    const googleBtnContainer = document.getElementById('google-login-btn');

    if (!checkinData.useGoogleLogin || !checkinData.googleClientId) {
      if (googleBtnContainer) googleBtnContainer.style.display = 'none';
      return;
    }

    if (!googleBtnContainer) {
      console.error('Google login button not found');
      return;
    }

    // Load Google Sign-In SDK
    if (!document.getElementById('google-signin-script')) {
      const script = document.createElement('script');
      script.id = 'google-signin-script';
      script.src = 'https://accounts.google.com/gsi/client';
      script.async = true;
      script.defer = true;
      script.onload = () => setupGoogleButton();
      script.onerror = () => {
        console.error('Failed to load Google Sign-In SDK');
        if (googleBtnContainer) googleBtnContainer.style.display = 'none';
      };
      document.head.appendChild(script);
    } else {
      setupGoogleButton();
    }
  }

  // Setup Google Sign-In Button
  function setupGoogleButton() {
    const googleBtnContainer = document.getElementById('google-login-btn');
    if (!googleBtnContainer || typeof google === 'undefined') return;

    // Prevent duplicate renders
    if (googleBtnContainer.hasAttribute('data-google-rendered')) {
      console.warn('Google button already rendered, skipping...');
      return;
    }

    // PWA standalone: popup không hoạt động (window.open bị chặn/mất opener)
    // → dùng ux_mode redirect, Google POST credential về endpoint riêng rồi redirect lại
    const isStandalonePWA =
      window.matchMedia('(display-mode: standalone)').matches ||
      window.navigator.standalone === true;

    try {
      google.accounts.id.initialize({
        client_id: checkinData.googleClientId,
        callback: handleGoogleLoginResponse,
        context: 'signin',
        ux_mode: isStandalonePWA ? 'redirect' : 'popup',
        ...(isStandalonePWA
          ? { login_uri: window.location.origin + '/wp-json/vg/v1/google-login-redirect' }
          : {}),
        auto_prompt: false,
        error_callback: (error) => {
          if (error.type === 'idpiframe_initialization_failed') {
            console.error('Google Sign-In 403: Origin not authorized -', window.location.origin);
            if (googleBtnContainer) {
              googleBtnContainer.innerHTML = `
                <div style="padding: 15px; background: #fff3cd; border: 2px solid #ffc107; border-radius: 8px; color: #856404; font-size: 14px;">
                  <strong>⚠️ Đăng nhập Google chưa được cấu hình</strong>
                  <p style="margin: 8px 0 0 0; font-size: 13px;">
                    Vui lòng liên hệ quản trị viên để thêm origin vào Google Cloud Console.
                  </p>
                </div>
              `;
              googleBtnContainer.style.display = 'block';
            }
          }
        },
      });

      google.accounts.id.renderButton(googleBtnContainer, {
        theme: 'outline',
        size: 'large',
        width: googleBtnContainer.offsetWidth || 300,
        text: 'signin_with',
        logo_alignment: 'left',
      });

      // Mark as rendered
      googleBtnContainer.setAttribute('data-google-rendered', 'true');
      googleBtnContainer.style.display = 'block';
    } catch (error) {
      console.error('Error setting up Google Sign-In:', error);
      googleBtnContainer.style.display = 'none';
    }
  }

  // Handle Google Login Response
  function handleGoogleLoginResponse(response) {
    if (!response.credential) {
      toastError('Không thể lấy thông tin từ Google.');
      return;
    }

    // Decode JWT to get email for account linking
    const googleEmail = decodeGoogleJWT(response.credential)?.email || '';

    // Show page loading immediately
    showPageLoading();

    const remember = document.getElementById('remember-me')?.checked || true;

    fetch(`${checkinData.restUrl}google-login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-WP-Nonce': checkinData.nonce,
      },
      body: JSON.stringify({
        id_token: response.credential,
        remember,
      }),
      credentials: 'include',
    })
      .then((res) => res.json())
      .then(async (result) => {
        if (result.success) {
          // Cập nhật nonce + role + navbar ngay, không cần reload
          applyLoginResult(result);

          // Đóng modal đăng nhập
          document.getElementById('checkin-mkt-login-modal').style.display = 'none';
          document.body.classList.remove('checkin-mkt-logged-out');

          toastSuccess('Đăng nhập bằng Google thành công!');

          // Nếu login API trả về profile luôn, dùng nó
          if (result.profile) {
            saveProfileToLocalStorage(result.profile);
            renderProfileData(result.profile);
            await new Promise((resolve) => requestAnimationFrame(resolve));
          } else {
            // Fallback: Fetch profile nếu API không trả về
            await new Promise((resolve) => setTimeout(resolve, 500));
            await fetchUserProfileData(false);
          }

          // Ẩn page loading sau khi đã render xong
          hidePageLoading();
        } else {
          hidePageLoading();
          console.error('Google login failed:', result.message);

          // Kiểm tra nếu là tài khoản mới (user không tồn tại)
          // Hiển thị Account Linking modal để liên kết với tài khoản cũ
          if (result.is_new_account || result.message?.includes('không tìm thấy')) {
            showAccountLinkingOption('google', googleEmail, response.credential);
          } else {
            showError(result.message || 'Đăng nhập bằng Google thất bại.');
          }
        }
      })
      .catch((error) => {
        hidePageLoading();
        console.error('Error during Google login:', error);
        showError('Lỗi khi đăng nhập bằng Google.');
      });
  }

  // Initialize Facebook Sign-In and Sync
  function initFacebookSignIn() {
    console.log('initFacebookSignIn called', {
      useFacebookLogin: checkinData.useFacebookLogin,
      facebookAppId: checkinData.facebookAppId ? 'Set' : 'Not set',
    });

    // Check config nhưng vẫn load SDK
    const hasValidConfig = checkinData.useFacebookLogin && checkinData.facebookAppId;

    if (!checkinData.useFacebookLogin) {
      console.log('Đăng nhập Facebook không được kích hoạt.');
      const facebookBtn = document.getElementById('facebook-login-btn');
      if (facebookBtn) facebookBtn.style.display = 'none';
    }

    if (!checkinData.facebookAppId) {
      console.warn('Facebook App ID chưa được cấu hình. Chức năng đồng bộ sẽ bị giới hạn.');
    }

    // Load Facebook SDK bất kể config (cần cho sync button)
    (function (d, s, id) {
      const fjs = d.getElementsByTagName(s)[0];
      if (d.getElementById(id)) {
        console.log('Facebook SDK already loaded');
        // Nếu SDK đã load, setup luôn
        if (typeof FB !== 'undefined') {
          setupFacebookSync();
        }
        return;
      }

      const js = d.createElement(s);
      js.id = id;
      js.src = 'https://connect.facebook.net/en_US/sdk.js';
      js.async = true;
      js.onload = () => {
        console.log('Facebook SDK loaded successfully');

        // Chỉ init nếu có config hợp lệ
        if (hasValidConfig) {
          FB.init({
            appId: checkinData.facebookAppId,
            cookie: true,
            xfbml: true,
            version: 'v22.0',
          });
          console.log('Facebook SDK initialized with app ID');

          const facebookBtn = document.getElementById('facebook-login-btn');
          if (facebookBtn) {
            facebookBtn.style.display = 'block';
            facebookBtn.addEventListener('click', (e) => {
              e.preventDefault();
              FB.login(
                (response) => {
                  if (response.status === 'connected') {
                    handleFacebookLogin(response.authResponse.accessToken);
                  } else {
                    toastError('Bạn cần cấp quyền để đăng nhập bằng Facebook!');
                  }
                },
                { scope: 'public_profile,email', auth_type: 'reauthenticate' }
              );
            });
          }
        } else {
          // Init với fallback config nếu thiếu
          if (checkinData.facebookAppId) {
            FB.init({
              appId: checkinData.facebookAppId,
              cookie: true,
              xfbml: true,
              version: 'v22.0',
            });
            console.log('Facebook SDK initialized with limited config');
          } else {
            console.warn('Cannot initialize FB SDK without App ID. Some features may not work.');
          }
        }

        // Luôn setup sync button sau khi SDK load
        setupFacebookSync();
      };

      js.onerror = () => {
        console.error('Failed to load Facebook SDK');
        toastError('Không thể tải Facebook SDK. Vui lòng kiểm tra kết nối internet.');
        // Vẫn setup sync button để hiển thị lỗi thân thiện
        setupFacebookSync();
      };

      fjs.parentNode.insertBefore(js, fjs);
    })(document, 'script', 'facebook-jssdk');
  }

  // Handle Facebook login
  function handleFacebookLogin(accessToken, fbEmail = '') {
    // Hiển thị page loading ngay khi bắt đầu đăng nhập
    showPageLoading();

    const remember = document.getElementById('remember-me')?.checked || true;
    fetch(`${checkinData.restUrl}facebook-login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-WP-Nonce': checkinData.nonce,
      },
      body: JSON.stringify({ access_token: accessToken, remember }),
      credentials: 'include',
    })
      .then((response) => response.json())
      .then(async (result) => {
        if (result.success) {
          // Cập nhật nonce + role + navbar ngay, không cần reload
          applyLoginResult(result);

          localStorage.setItem('fb_access_token', accessToken);

          // Đóng modal đăng nhập
          document.getElementById('checkin-mkt-login-modal').style.display = 'none';
          document.body.classList.remove('checkin-mkt-logged-out');

          toastSuccess('Đăng nhập bằng Facebook thành công.');

          // Nếu login API trả về profile luôn, dùng nó
          if (result.profile) {
            saveProfileToLocalStorage(result.profile);
            renderProfileData(result.profile);
            await new Promise((resolve) => requestAnimationFrame(resolve));
          } else {
            // Fallback: Fetch profile nếu API không trả về
            await new Promise((resolve) => setTimeout(resolve, 500));
            await fetchUserProfileData(false);
          }

          // Ẩn page loading sau khi đã render xong
          hidePageLoading();
        } else {
          hidePageLoading();
          console.error('Facebook login failed:', result.message);

          // Kiểm tra nếu là tài khoản mới - hiển thị Account Linking
          if (result.is_new_account || result.message?.includes('không tìm thấy')) {
            showAccountLinkingOption('facebook', fbEmail, accessToken);
          } else {
            showError(result.message || 'Đăng nhập bằng Facebook thất bại.');
          }
        }
      })
      .catch((error) => {
        hidePageLoading();
        console.error('Error during Facebook login:', error);
        showError('Lỗi khi đăng nhập bằng Facebook.');
      });
  }

  // Helper function to wait for FB SDK
  function waitForFB(callback, maxAttempts = 20) {
    let attempts = 0;
    const checkFB = setInterval(() => {
      attempts++;
      if (typeof FB !== 'undefined') {
        clearInterval(checkFB);
        console.log('FB SDK ready after', attempts, 'attempts');
        callback(true);
      } else if (attempts >= maxAttempts) {
        clearInterval(checkFB);
        console.error('FB SDK failed to load after', maxAttempts, 'attempts');
        callback(false);
      }
    }, 100); // Check every 100ms
  }

  // ---- Đồng bộ Facebook: một luồng kết nối dùng chung cho nút navbar và nút "Cập Nhật Số Lượng" ----
  // Lỗi cũ (5.3.6.2 trở về trước): FB.login luôn kèm auth_type 'reauthenticate' → với user ĐÃ từng cấp quyền, Facebook mở
  // màn nhập lại mật khẩu, trên iPhone nhảy sang web trắng rồi sang app FB, quay về không có authResponse → báo "cần cấp quyền".
  // User chưa từng cấp quyền thấy hộp đồng ý bình thường nên vẫn chạy. Nay: token còn dùng → dùng; hết hạn → getLoginStatus
  // lấy token mới; chưa kết nối → FB.login thường (rerequest chỉ khi thiếu quyền user_posts).
  const FB_SYNC_SCOPE = 'public_profile,email,user_posts';

  function fbSyncWithToken(token, filter) {
    localStorage.setItem('fb_access_token', token);
    fbSyncButtonLabel(false);
    return fetchFacebookData(token, filter);
  }

  function fbSyncLogin(filter, rerequest) {
    const opts = { scope: FB_SYNC_SCOPE, return_scopes: true };
    if (rerequest) opts.auth_type = 'rerequest';
    FB.login((response) => {
      if (response.status === 'connected' && response.authResponse) {
        const granted = String(response.authResponse.grantedScopes || '');
        if (granted && !granted.includes('user_posts') && !rerequest) {
          console.log('FB: thiếu quyền user_posts → xin lại');
          return fbSyncLogin(filter, true);
        }
        console.log('Facebook login successful');
        fbSyncWithToken(response.authResponse.accessToken, filter);
      } else {
        console.log('Facebook login failed or cancelled', response && response.status);
        toastError('Bạn cần cấp quyền để đồng bộ Facebook!');
      }
    }, opts);
  }

  // Nút trong popup: đổi nhãn khi cần đăng nhập lại để thợ biết bấm
  function fbSyncButtonLabel(needLogin) {
    const btn = document.getElementById('fb-login-btn');
    if (btn) btn.textContent = needLogin ? 'Đăng nhập Facebook để đồng bộ' : 'Cập Nhật Số Lượng';
  }

  // Token hết hạn → hỏi SDK (không cần thao tác bấm); còn phiên thì lấy token mới và đồng bộ luôn,
  // không thì đổi nhãn nút để thợ bấm → FB.login chạy đồng bộ trong click (trình duyệt chặn popup nếu gọi ngoài click).
  function fbSyncRecover(filter) {
    if (typeof FB === 'undefined') return fbSyncButtonLabel(true);
    FB.getLoginStatus((st) => {
      if (st.status === 'connected' && st.authResponse && st.authResponse.accessToken) {
        console.log('FB còn phiên, dùng token mới từ SDK');
        fbSyncWithToken(st.authResponse.accessToken, filter);
      } else {
        fbSyncButtonLabel(true);
        toastWarning('Phiên Facebook đã hết hạn — bấm "Đăng nhập Facebook để đồng bộ".');
      }
    }, true);
  }

  // Gọi TRỰC TIẾP trong handler click: có token → đồng bộ; không → FB.login ngay (đồng bộ, không qua callback nào khác)
  function fbSyncConnect(filter = 'today') {
    const stored = localStorage.getItem('fb_access_token');
    if (stored) {
      console.log('Using stored access token');
      return fbSyncWithToken(stored, filter);
    }
    if (typeof FB === 'undefined') {
      console.warn('Facebook SDK not ready yet, waiting...');
      toastInfo('Đang tải Facebook SDK... bấm lại sau vài giây.');
      waitForFB((ready) => {
        if (!ready) toastError('Không thể tải Facebook SDK. Vui lòng kiểm tra kết nối internet và thử lại.');
        else fbSyncButtonLabel(true);
      });
      return;
    }
    fbSyncLogin(filter, false);
  }

  // Setup Facebook sync button and tab navigation
  function setupFacebookSync() {
    console.log('setupFacebookSync called');
    const syncButton = document.querySelector('#sync-facebook-btn');
    // Làm mới token nền cho thợ đã kết nối FB (không mở popup): token cũ trong localStorage thường đã hết hạn
    if (typeof FB !== 'undefined' && typeof FB.getLoginStatus === 'function') {
      try {
        FB.getLoginStatus((st) => {
          if (st.status === 'connected' && st.authResponse && st.authResponse.accessToken) {
            localStorage.setItem('fb_access_token', st.authResponse.accessToken);
            console.log('FB token làm mới từ SDK');
          }
        });
      } catch (err) { console.warn('FB.getLoginStatus lỗi', err); }
    }

    if (!syncButton) {
      console.warn('Facebook sync button not found (#sync-facebook-btn)');
      return;
    }

    syncButton.addEventListener('click', (e) => {
      e.preventDefault();
      console.log('Facebook sync button clicked');

      const popup = document.querySelector('#facebook-sync-popup');
      const navbar = document.querySelector('.checkin-mkt-nav-bar');

      if (!popup) {
        console.error('Facebook sync popup not found (#facebook-sync-popup)');
        toastError('Không tìm thấy popup đồng bộ Facebook!');
        return;
      }

      toggleVisibility(popup, true);
      if (navbar) toggleVisibility(navbar, false);
      fbSyncButtonLabel(!localStorage.getItem('fb_access_token'));
      fbSyncConnect('today');
    });

    console.log('Facebook sync button event listener attached successfully');

    // Nút "Cập Nhật Số Lượng" trong popup
    const fbLoginBtn = document.getElementById('fb-login-btn');
    if (fbLoginBtn) {
      fbLoginBtn.addEventListener('click', (e) => {
        e.preventDefault();
        fbSyncConnect('today');
      });
    }

    // Setup tabs trong popup
    document.querySelectorAll('#fb-tabs .tab').forEach((tab) => {
      tab.addEventListener('click', () => {
        fbSyncConnect(tab.dataset.filter);
      });
    });
  }

  // Toggle loading modal
  function toggleLoadingModal(show) {
    const loadingModal = document.getElementById('fb-loading-modal');
    if (loadingModal) {
      loadingModal.style.display = show ? 'flex' : 'none';
    }
  }

  // Fetch Facebook data
  async function fetchFacebookData(accessToken, filter = 'today') {
    console.log('fetchFacebookData called with filter:', filter);
    toggleLoadingModal(true);
    try {
      const response = await fetch(
        `https://graph.facebook.com/v22.0/me?fields=id,name,picture,videos,posts.limit(100){id,created_time,message}&access_token=${accessToken}`
      );
      const data = await response.json();
      console.log('Facebook API response:', data);

      if (data && !data.error) {
        toggleVisibility(document.getElementById('fb-profile'), true);
        document.getElementById('fb-avatar').src = data.picture.data.url;
        document.getElementById('fb-username').innerText = data.name;

        if (data.posts && data.posts.data) {
          allPosts = data.posts.data.map((post) => ({
            ...post,
            id: post.id.split('_')[1],
          }));
          toggleVisibility(document.getElementById('fb-tabs'), true);
          toggleVisibility(
            document.getElementById('fb-progress-this-month'),
            filter === 'thisMonth'
          );
          toggleVisibility(
            document.getElementById('fb-progress-last-month'),
            filter === 'lastMonth'
          );
          filterPosts(filter);
          await updateSocialPosts(allPosts, filter);
        } else {
          const resultElement = document.getElementById('fb-result');
          if (resultElement) {
            resultElement.innerText = 'Không tìm thấy bài viết nào.';
          }
          toastWarning('Không tìm thấy bài viết nào từ Facebook.');
        }
      } else {
        // Xử lý lỗi từ Facebook API
        const resultElement = document.getElementById('fb-result');
        if (resultElement) {
          resultElement.innerText = 'Lỗi khi gọi API Facebook.';
        }
        console.error('Lỗi API Facebook:', data.error);
        localStorage.removeItem('fb_access_token');
        const code = Number(data.error?.code);
        const expired = code === 190 || code === 102 || data.error?.type === 'OAuthException';
        if (expired && !fetchFacebookData._retried) {
          // Token cũ hết hạn (user đã đồng bộ từ lâu) → thử lấy phiên từ SDK; không có thì đổi nhãn nút để thợ bấm đăng nhập
          fetchFacebookData._retried = true;
          setTimeout(() => (fetchFacebookData._retried = false), 5000);
          fbSyncRecover(filter);
        } else {
          toastError(`Lỗi Facebook API: ${data.error?.message || 'Unknown error'}`);
        }
      }
    } catch (error) {
      console.error('Lỗi khi lấy dữ liệu Facebook:', error);
      const resultElement = document.getElementById('fb-result');
      if (resultElement) {
        resultElement.innerText = 'Lỗi kết nối đến Facebook.';
      }
      toastError('Không thể kết nối đến Facebook. Vui lòng thử lại.');
    } finally {
      toggleLoadingModal(false);
    }
  }

  // Update social_posts table
  async function updateSocialPosts(posts, filter) {
    toggleLoadingModal(true);
    const displayName = document.querySelector('.checkin-mkt-display-name')?.textContent || '';
    const postsByDate = {};
    posts.forEach((post) => {
      const postDate = new Date(post.created_time).toISOString().split('T')[0];
      if (!postsByDate[postDate]) {
        postsByDate[postDate] = post;
      }
    });

    const validPosts = Object.values(postsByDate);
    let filteredPosts = [];

    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(today.getDate() - 1);
    const thisMonthStart = new Date(today.getFullYear(), today.getMonth(), 1);
    const lastMonthStart = new Date(today.getFullYear(), today.getMonth() - 1, 1);
    const lastMonthEnd = new Date(today.getFullYear(), today.getMonth(), 0);

    switch (filter) {
      case 'today':
        filteredPosts = validPosts.filter((post) =>
          post.created_time.startsWith(today.toISOString().split('T')[0])
        );
        break;
      case 'yesterday':
        filteredPosts = validPosts.filter((post) =>
          post.created_time.startsWith(yesterday.toISOString().split('T')[0])
        );
        break;
      case 'thisMonth':
        filteredPosts = validPosts.filter((post) => new Date(post.created_time) >= thisMonthStart);
        break;
      case 'lastMonth':
        filteredPosts = validPosts.filter((post) => {
          const postDate = new Date(post.created_time);
          return postDate >= lastMonthStart && postDate <= lastMonthEnd;
        });
        break;
    }

    for (const post of filteredPosts) {
      const postDate = new Date(post.created_time).toISOString().split('T')[0];
      try {
        const response = await fetch(`${checkinData.restUrl}staff-update-social-post`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-WP-Nonce': checkinData.nonce,
          },
          body: JSON.stringify({
            action: 'update_social_post',
            display_name: displayName,
            post_type: 'facebook',
            post_id: post.id,
            post_date: postDate,
            nonce: checkinData.nonce,
          }),
        });
        const result = await response.json();
        if (!result.success) {
          console.error('Failed to update social_post:', result.message);
          showError(result.message || 'Lỗi khi cập nhật bài đăng.');
        }
      } catch (error) {
        console.error('Error updating social_post:', error);
        showError('Lỗi khi cập nhật bài đăng.');
      }
    }
    toggleLoadingModal(false);
  }

  // Filter Facebook posts
  function filterPosts(filter) {
    const tabs = document.querySelectorAll('#fb-tabs .tab');
    tabs.forEach((tab) => tab.classList.remove('active'));
    document.querySelector(`#fb-tabs .tab[data-filter="${filter}"]`).classList.add('active');

    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(today.getDate() - 1);
    const thisMonthStart = new Date(today.getFullYear(), today.getMonth(), 1);
    const lastMonthStart = new Date(today.getFullYear(), today.getMonth() - 1, 1);
    const lastMonthEnd = new Date(today.getFullYear(), today.getMonth(), 0);

    let filteredPosts = [];
    let resultText = '';

    document.getElementById('fb-progress-container-this-month').style.display =
      filter === 'thisMonth' ? 'block' : 'none';
    document.getElementById('fb-progress-container-last-month').style.display =
      filter === 'lastMonth' ? 'block' : 'none';

    const postsByDate = {};
    allPosts.forEach((post) => {
      const postDate = new Date(post.created_time).toISOString().split('T')[0];
      if (!postsByDate[postDate]) {
        postsByDate[postDate] = post;
      }
    });
    const validPosts = Object.values(postsByDate);

    switch (filter) {
      case 'today':
        filteredPosts = validPosts.filter((post) =>
          post.created_time.startsWith(today.toISOString().split('T')[0])
        );
        resultText =
          filteredPosts.length > 0
            ? filteredPosts
                .map(
                  (post) => `
                <div class="post">
                    <div>ID: ${post.id}</div>
                    <div>Thời gian: ${new Date(post.created_time).toLocaleString('vi-VN', {
                      day: '2-digit',
                      month: '2-digit',
                      year: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}</div>
                    <div>Nội dung: ${post.message || 'Không có nội dung'}</div>
                </div>`
                )
                .join('')
            : 'Bạn chưa đăng bài hôm nay! ❌';
        break;
      case 'yesterday':
        filteredPosts = validPosts.filter((post) =>
          post.created_time.startsWith(yesterday.toISOString().split('T')[0])
        );
        resultText =
          filteredPosts.length > 0
            ? filteredPosts
                .map(
                  (post) => `
                <div class="post">
                    <div>ID: ${post.id}</div>
                    <div>Thời gian: ${new Date(post.created_time).toLocaleString('vi-VN', {
                      day: '2-digit',
                      month: '2-digit',
                      year: 'numeric',
                      hour: '2-digit',
                      minute: '2-digit',
                    })}</div>
                    <div>Nội dung: ${post.message || 'Không có nội dung'}</div>
                </div>`
                )
                .join('')
            : 'Bạn chưa đăng bài hôm qua! ❌';
        break;
      case 'thisMonth':
        filteredPosts = validPosts.filter((post) => new Date(post.created_time) >= thisMonthStart);
        resultText =
          `<p>Tổng số bài: ${filteredPosts.length}</p>` +
          filteredPosts
            .map(
              (post) => `
                <div class="post">
                    <div>ID: ${post.id}</div>
                    <div>Ngày: ${new Date(post.created_time).toLocaleDateString('vi-VN')}</div>
                </div>`
            )
            .join('');
        updateProgress(filteredPosts.length, 'this-month');
        break;
      case 'lastMonth':
        filteredPosts = validPosts.filter((post) => {
          const postDate = new Date(post.created_time);
          return postDate >= lastMonthStart && postDate <= lastMonthEnd;
        });
        resultText =
          `<p>Tổng số bài: ${filteredPosts.length}</p>` +
          filteredPosts
            .map(
              (post) => `
                <div class="post">
                    <div>ID: ${post.id}</div>
                    <div>Ngày: ${new Date(post.created_time).toLocaleDateString('vi-VN')}</div>
                </div>`
            )
            .join('');
        updateProgress(filteredPosts.length, 'last-month');
        break;
    }

    document.getElementById('fb-result').innerHTML = resultText;
  }

  // Update progress bar
  function updateProgress(postCount, period) {
    const progressPercent = Math.min((postCount / 30) * 100, 100);
    const countElement = document.getElementById(`fb-post-count-${period}`);
    const progressElement = document.getElementById(`fb-progress-${period}`);

    if (countElement && progressElement) {
      countElement.innerText = postCount;
      progressElement.style.width = `${progressPercent}%`;
      console.log(`Progress updated: ${postCount}/30 (${progressPercent}%) for ${period}`);
    } else {
      console.error(`Element with ID fb-post-count-${period} or fb-progress-${period} not found.`);
    }
  }

  // Handle manual login
  async function handleManualLogin(event) {
    event.preventDefault();
    const form = document.getElementById('manual-login-form');
    const errorElement = document.getElementById('login-error');
    const submitButton = form.querySelector('button[type="submit"]');
    const rememberCheckbox = document.getElementById('remember-me');

    if (!form.checkValidity()) {
      errorElement.textContent = 'Vui lòng điền đầy đủ thông tin.';
      errorElement.style.display = 'block';
      return;
    }

    const formData = new FormData(form);
    const username = formData.get('log');
    const password = formData.get('pwd');
    const remember = rememberCheckbox ? rememberCheckbox.checked : false;

    // Hiển thị loading trên button và page
    submitButton.disabled = true;
    const originalButtonText = submitButton.value;
    submitButton.value = 'Đang đăng nhập...';
    submitButton.classList.add('loading');

    // Hiển thị page loading
    showPageLoading();

    try {
      const response = await fetch(`${checkinData.restUrl}login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-WP-Nonce': checkinData.nonce,
        },
        body: JSON.stringify({ username, password, remember }),
        credentials: 'include',
      });

      const result = await response.json();
      if (result.success) {
        // Cập nhật nonce + role + navbar ngay, không cần reload
        applyLoginResult(result);

        // Đóng modal đăng nhập
        document.getElementById('checkin-mkt-login-modal').style.display = 'none';
        document.body.classList.remove('checkin-mkt-logged-out');

        toastSuccess('Đăng nhập thành công!');

        // Nếu login API trả về profile luôn, dùng nó
        if (result.profile) {
          saveProfileToLocalStorage(result.profile);
          renderProfileData(result.profile);
          await new Promise((resolve) => requestAnimationFrame(resolve));
        } else {
          // Fallback: Fetch profile nếu API không trả về
          await new Promise((resolve) => setTimeout(resolve, 500));
          await fetchUserProfileData(false);
        }

        // Ẩn page loading sau khi đã render xong
        hidePageLoading();

        // Reset button
        submitButton.disabled = false;
        submitButton.value = originalButtonText;
        submitButton.classList.remove('loading');
      } else {
        // Ẩn page loading khi có lỗi
        hidePageLoading();
        errorElement.textContent = result.message || 'Đăng nhập thất bại.';
        errorElement.style.display = 'block';

        // Reset button
        submitButton.disabled = false;
        submitButton.value = originalButtonText;
        submitButton.classList.remove('loading');
      }
    } catch (error) {
      // Ẩn page loading khi có lỗi
      hidePageLoading();
      errorElement.textContent = 'Lỗi kết nối. Vui lòng thử lại.';
      errorElement.style.display = 'block';

      // Reset button
      submitButton.disabled = false;
      submitButton.value = originalButtonText;
      submitButton.classList.remove('loading');
    }
  }

  // Handle logout
  function handleLogout() {
    showConfirm('Bạn có chắc muốn đăng xuất khỏi hệ thống?', 'Xác nhận đăng xuất').then(
      (confirmed) => {
        if (!confirmed) {
          return;
        }

        toastInfo('Đang xử lý yêu cầu đăng xuất...');

        fetch(`${checkinData.restUrl}logout`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': checkinData.nonce },
          credentials: 'include',
        })
          .then((response) => {
            if (!response.ok) {
              throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
          })
          .then((result) => {
            if (result.success) {
              localStorage.clear();
              sessionStorage.clear();
              toastSuccess('Đăng xuất thành công!');

              // Reload page to properly handle cookie check and show login modal
              setTimeout(() => {
                window.location.reload();
              }, 1000);
            } else {
              toastError(result.message || 'Đăng xuất thất bại. Vui lòng thử lại.');
            }
          })
          .catch((error) => {
            toastError('Lỗi khi đăng xuất. Vui lòng thử lại.');
          });
      }
    );
  }

  // Fetch user profile data
  async function fetchUserProfileData(fromCache = true) {
    // Load từ cache trước để render nhanh
    if (fromCache) {
      const cachedProfile = loadProfileFromLocalStorage();
      if (cachedProfile) {
        renderProfileData(cachedProfile);
        // Đợi DOM render xong
        await new Promise((resolve) => requestAnimationFrame(resolve));
      }
    }

    // Fetch API để cập nhật dữ liệu mới nhất
    let response;
    try {
      console.log('Fetching user profile with nonce:', checkinData.nonce);

      response = await fetch(`${checkinData.restUrl}user-profile`, {
        method: 'GET',
        headers: { 'X-WP-Nonce': checkinData.nonce },
        credentials: 'include',
      });

      const contentType = response.headers.get('content-type');
      if (!contentType || !contentType.includes('application/json')) {
        throw new Error('Server returned non-JSON response');
      }

      const result = await response.json();

      // Kiểm tra lỗi nonce
      if (result.code === 'rest_cookie_invalid_nonce') {
        console.error('Invalid nonce error:', {
          currentNonce: checkinData.nonce,
          status: response.status,
          error: result,
        });
        showError('Lỗi xác thực. Vui lòng tải lại trang.');
        return;
      }

      if (result.success) {
        const { data } = result;

        // Lưu vào localStorage
        saveProfileToLocalStorage(data);

        // Render lại với dữ liệu mới nhất
        renderProfileData(data);

        // Đợi DOM render xong
        await new Promise((resolve) => requestAnimationFrame(resolve));
      } else {
        showError(result.message || 'Không thể tải dữ liệu hồ sơ.');
      }
    } catch (error) {
      if (error.message.includes('non-JSON')) {
        showError('Phản hồi từ server không hợp lệ. Vui lòng kiểm tra cấu hình server.');
      } else if (response && response.status === 401) {
        // Xóa cache khi unauthorized
        localStorage.removeItem('checkin_user_profile');
        localStorage.removeItem('checkin_user_profile_timestamp');
        window.location.href = '/user-profile';
      } else {
        showError(error.message || 'Không thể tải dữ liệu hồ sơ.');
      }
    }
  }

  // setupTabNavigation đã bị xóa - không dùng tabs điểm danh/đi trễ/lương nữa

  // Popup close handling
  function setupPopupClose() {
    document.addEventListener('click', (e) => {
      if (e.target.classList.contains('checkin-mkt-popup-close')) {
        const elementsToClose = [
          '#facebook-sync-popup',
          '#checkin-mkt-history-popup',
          '#salary-popup',
          // '#edit-profile-modal' is handled by ModernProfileModal.close() for a smooth animation
        ];

        elementsToClose.forEach((id) => {
          const element = document.querySelector(id);
          if (element) {
            toggleVisibility(element, false);
          }
        });

        // If edit profile modal exists and is open, close via modern modal logic for smooth animation
        const editProfileModal = document.getElementById('edit-profile-modal');
        if (
          window.modernProfileModal &&
          editProfileModal &&
          editProfileModal.style.display !== 'none'
        ) {
          try {
            window.modernProfileModal.close();
          } catch (err) {
            // Fallback to generic hide if something goes wrong
            toggleVisibility(editProfileModal, false);
          }
        }

        const navbar = document.querySelector('.checkin-mkt-nav-bar');
        if (navbar) {
          toggleVisibility(navbar, true);
        }

        // Kích hoạt lại pointer events cho các element khác
        const allElements = document.querySelectorAll('body > *');
        allElements.forEach((el) => {
          el.style.pointerEvents = '';
        });
      }
    });

    const popupSelectors = '#facebook-sync-popup, #salary-popup, #edit-profile-modal';
    document.querySelectorAll(popupSelectors).forEach((popup) => {
      if (!popup) return;
      popup.addEventListener('click', (e) => {
        if (e.target === popup) {
          // If it's the modern edit profile modal, use the modern modal close method
          if (popup.id === 'edit-profile-modal' && window.modernProfileModal) {
            try {
              window.modernProfileModal.close();
            } catch (err) {
              toggleVisibility(popup, false);
            }
          } else {
            toggleVisibility(popup, false);
          }
          const navbar = document.querySelector('.checkin-mkt-nav-bar');
          if (navbar) {
            toggleVisibility(navbar, true);
          }

          // Kích hoạt lại pointer events cho các element khác
          const allElements = document.querySelectorAll('body > *');
          allElements.forEach((el) => {
            el.style.pointerEvents = '';
          });
        }
      });
    });
  }

  // Trang phiếu lương: nút "Xem lương" mở trang riêng (module psSalaryPage trong salary-staff.js)
  function getCurrentStaff() {
    const name = document.querySelector('.checkin-mkt-display-name')?.textContent.trim() || '';
    const role = document.querySelector('.checkin-mkt-user-role')?.textContent.trim() || '';
    return { name: name === 'Tên người dùng' ? '' : name, role };
  }

  function setupSalaryPage() {
    document.querySelector('.checkin-mkt-salary-btn')?.addEventListener('click', () => {
      const staff = getCurrentStaff();
      if (!staff.name || !window.psSalaryPage) return;
      window.psSalaryPage.open({
        staff: staff.name,
        role: staff.role,
        period: window.psSalaryPage.curPeriod(),
      });
    });
    document.getElementById('salary-page-back')?.addEventListener('click', () => {
      window.psSalaryPage?.close();
    });
    // Hồ sơ & lịch sử công việc của chính mình (hạng, hoa hồng, phiếu lương)
    document.getElementById('salary-history-btn')?.addEventListener('click', () => {
      const staff = getCurrentStaff();
      if (!staff.name || !window.psStaffProfile) return;
      window.psStaffProfile.open({
        staffName: staff.name,
        onOpenPeriod: (p) => window.psSalaryPage?.select(p),
      });
    });
  }

  // Mở thẳng trang phiếu lương khi vào bằng link /user-profile?view=salary[&period=YYYY-MM]
  function openSalaryFromUrl() {
    const params = new URLSearchParams(window.location.search);
    if (params.get('view') !== 'salary' || !window.psSalaryPage) return;
    const staff = getCurrentStaff();
    if (!staff.name) return;
    window.psSalaryPage.open({
      staff: staff.name,
      role: staff.role,
      period: params.get('period') || window.psSalaryPage.curPeriod(),
      push: false,
    });
  }

  // ✨ MODERN EDIT PROFILE MODAL - Handled by modern-edit-modal.js
  // Old setupEditProfileModal function has been removed and replaced with ModernProfileModal class

  // ============================================
  // Account Linking Helper Functions
  // ============================================

  /**
   * Decode Google JWT to get email
   */
  function decodeGoogleJWT(token) {
    try {
      const base64Url = token.split('.')[1];
      const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
      const jsonPayload = decodeURIComponent(
        atob(base64)
          .split('')
          .map((c) => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2))
          .join('')
      );
      return JSON.parse(jsonPayload);
    } catch (e) {
      console.error('Error decoding Google JWT:', e);
      return null;
    }
  }

  /**
   * Show Account Linking option when social login fails (new account)
   * Gives user choice to link with existing account or create new
   */
  function showAccountLinkingOption(provider, email, token) {
    // Kiểm tra AccountLinking module đã load chưa
    if (typeof window.AccountLinking === 'undefined') {
      // Load account-linking.js dynamically nếu chưa có
      const script = document.createElement('script');
      script.src =
        (checkinData.pluginUrl || '') + 'frontend/assets/js/components/account-linking.js';
      script.onload = () => {
        openAccountLinkingModal(provider, email, token);
      };
      script.onerror = () => {
        // Fallback: Show simple confirmation
        showAccountLinkingFallback(provider, email, token);
      };
      document.head.appendChild(script);
    } else {
      openAccountLinkingModal(provider, email, token);
    }
  }

  /**
   * Open Account Linking Modal
   */
  function openAccountLinkingModal(provider, email, token) {
    window.AccountLinking.open({
      provider: provider,
      newEmail: email,
      onSuccess: async (result) => {
        // Đóng modal đăng nhập
        document.getElementById('checkin-mkt-login-modal').style.display = 'none';
        document.body.classList.remove('checkin-mkt-logged-out');

        toastSuccess('Liên kết tài khoản thành công!');

        // Render profile từ result
        if (result.profile) {
          saveProfileToLocalStorage(result.profile);
          renderProfileData(result.profile);
        } else {
          await fetchUserProfileData(false);
        }
      },
      onSkip: () => {
        // User chọn tạo tài khoản mới - thực hiện đăng nhập lại
        // Lần này sẽ tạo account mới
        if (provider === 'google' && token) {
          createNewAccountFromSocial('google', token);
        } else if (provider === 'facebook' && token) {
          createNewAccountFromSocial('facebook', token);
        }
      },
    });
  }

  /**
   * Fallback khi không load được Account Linking module
   */
  function showAccountLinkingFallback(provider, email, token) {
    const providerName = provider === 'google' ? 'Google' : 'Facebook';
    const confirmed = confirm(
      `Email ${email} chưa có tài khoản.\n\n` +
        `Bạn đã có tài khoản trước đây và muốn liên kết?\n` +
        `- Bấm OK để liên kết với tài khoản cũ\n` +
        `- Bấm Cancel để tạo tài khoản mới`
    );

    if (confirmed) {
      // Mở form liên kết đơn giản
      const username = prompt('Nhập username tài khoản cũ:');
      const employeeId = prompt('Nhập mã nhân viên:');

      if (username && employeeId) {
        verifyAndLinkAccount(username, employeeId, '', email, provider);
      }
    } else {
      createNewAccountFromSocial(provider, token);
    }
  }

  /**
   * Verify and link account (fallback method)
   */
  async function verifyAndLinkAccount(username, employeeId, birthday, newEmail, provider) {
    showPageLoading();

    try {
      const response = await fetch(`${checkinData.restUrl}account-linking/verify`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-WP-Nonce': checkinData.nonce,
        },
        credentials: 'include',
        body: JSON.stringify({
          username: username,
          employee_id: employeeId,
          birthday: birthday,
          new_email: newEmail,
          provider: provider,
          remember: true,
        }),
      });

      const result = await response.json();

      if (result.success) {
        if (result.nonce) {
          checkinData.nonce = result.nonce;
        }

        document.getElementById('checkin-mkt-login-modal').style.display = 'none';
        document.body.classList.remove('checkin-mkt-logged-out');

        toastSuccess('Liên kết tài khoản thành công!');

        if (result.profile) {
          saveProfileToLocalStorage(result.profile);
          renderProfileData(result.profile);
        } else {
          await fetchUserProfileData(false);
        }
      } else {
        toastError(result.message || 'Xác minh thất bại');
      }
    } catch (error) {
      console.error('Account linking error:', error);
      toastError('Có lỗi xảy ra. Vui lòng thử lại.');
    } finally {
      hidePageLoading();
    }
  }

  /**
   * Create new account from social login (when user skips linking)
   */
  async function createNewAccountFromSocial(provider, token) {
    showPageLoading();

    try {
      const endpoint = provider === 'google' ? 'google-login' : 'facebook-login';
      const body =
        provider === 'google'
          ? { id_token: token, remember: true, force_create: true }
          : { access_token: token, remember: true, force_create: true };

      const response = await fetch(`${checkinData.restUrl}${endpoint}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-WP-Nonce': checkinData.nonce,
        },
        credentials: 'include',
        body: JSON.stringify(body),
      });

      const result = await response.json();

      if (result.success) {
        if (result.nonce) {
          checkinData.nonce = result.nonce;
        }

        document.getElementById('checkin-mkt-login-modal').style.display = 'none';
        document.body.classList.remove('checkin-mkt-logged-out');

        toastSuccess('Đăng nhập thành công! Tài khoản mới đã được tạo.');

        if (result.profile) {
          saveProfileToLocalStorage(result.profile);
          renderProfileData(result.profile);
        } else {
          await fetchUserProfileData(false);
        }
      } else {
        showError(result.message || 'Không thể tạo tài khoản.');
      }
    } catch (error) {
      console.error('Create account error:', error);
      showError('Có lỗi xảy ra. Vui lòng thử lại.');
    } finally {
      hidePageLoading();
    }
  }

  // Initialize event listeners
  document.querySelectorAll('.toggle-password').forEach((btn) => {
    btn.addEventListener('click', function () {
      const targetInput = document.getElementById(this.dataset.target);
      const type = targetInput.getAttribute('type') === 'password' ? 'text' : 'password';
      targetInput.setAttribute('type', type);
      this.textContent = type === 'password' ? '👁' : '🙈';
    });
  });

  const manualLoginForm = document.getElementById('manual-login-form');
  if (manualLoginForm) {
    manualLoginForm.addEventListener('submit', handleManualLogin);
  }

  document.querySelectorAll('#logoutButton').forEach((tab) => {
    tab.addEventListener('click', () => {
      handleLogout();
    });
  });

  // Kết quả từ Google login dạng redirect (PWA): đọc query param, báo toast rồi xoá param
  const loginParams = new URLSearchParams(window.location.search);
  if (loginParams.has('login') || loginParams.has('login_error')) {
    if (loginParams.get('login') === 'success') {
      toastSuccess('Đăng nhập bằng Google thành công!');
    } else if (loginParams.get('login_error') === 'new_account') {
      toastError(
        'Email Google này chưa có tài khoản. Vui lòng đăng nhập website để liên kết tài khoản trước.'
      );
    } else if (loginParams.get('login_error')) {
      toastError(decodeURIComponent(loginParams.get('login_error')));
    }
    window.history.replaceState({}, '', window.location.pathname);
  }

  // Initialize
  applyBrandSettings();
  setupNavbarForRole();
  checkLoginStatus().then(openSalaryFromUrl);
  // setupEditProfileModal(); // ✨ Removed - Now handled by ModernProfileModal class
  setupPopupClose();
  setupSalaryPage();
  initGoogleSignIn();
  initFacebookSignIn();
});
