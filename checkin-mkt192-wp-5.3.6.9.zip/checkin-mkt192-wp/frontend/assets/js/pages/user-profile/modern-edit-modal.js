/**
 * ========================================
 * ✨ MODERN EDIT PROFILE MODAL - JavaScript
 * Ultra-modern implementation with ES6+
 * ========================================
 */

class ModernProfileModal {
  constructor() {
    this.modal = null;
    this.currentTab = 'profile';
    this.isCCCDVerified = false;
    // Ảnh đã nén sẵn từ lúc chọn file (Promise<File>) — submit chỉ việc await,
    // pipeline giống app-tho: nén trong lúc user còn đang điền form
    this.compressedFiles = { avatar: null, cccd_front: null, cccd_back: null };
    this.init();
  }

  /**
   * Nén ảnh phía client (port từ app-tho): createImageBitmap decode ngoài
   * main-thread, hỗ trợ mọi định dạng ảnh kể cả HEIC của iPhone (xuất JPEG
   * để server convert webp được ngay, không cần cron xử lý lại).
   * @param {File} file
   * @param {number} maxDim  cạnh dài tối đa (avatar 512 là đủ, CCCD 1600 để đọc chữ)
   * @param {number} quality chất lượng JPEG 0-1
   */
  async compressProfileImage(file, maxDim = 1200, quality = 0.8) {
    if (!file || !file.type.startsWith('image/')) {
      return file;
    }

    // Đường nhanh: createImageBitmap (decode nhanh, tự xoay theo EXIF)
    try {
      if (typeof createImageBitmap === 'function') {
        let bmp;
        try {
          bmp = await createImageBitmap(file, { imageOrientation: 'from-image' });
        } catch (e) {
          bmp = await createImageBitmap(file); // Safari cũ không nhận options
        }
        const scale = Math.min(1, maxDim / Math.max(bmp.width, bmp.height));
        const w = Math.max(1, Math.round(bmp.width * scale));
        const h = Math.max(1, Math.round(bmp.height * scale));
        const canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        canvas.getContext('2d').drawImage(bmp, 0, 0, w, h);
        bmp.close();
        const blob = await new Promise((res) => canvas.toBlob(res, 'image/jpeg', quality));
        if (blob && blob.size > 0) {
          const newFilename = file.name.replace(/\.[^/.]+$/, '') + '.jpg';
          return new File([blob], newFilename, { type: 'image/jpeg', lastModified: Date.now() });
        }
      }
    } catch (err) {
      console.warn('createImageBitmap failed, falling back to FileReader compress', err);
    }

    // Đường dự phòng: FileReader + <img> (trình duyệt cũ)
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const img = new Image();
        img.onload = () => {
          let width = img.width;
          let height = img.height;
          if (width > maxDim || height > maxDim) {
            if (width > height) {
              height = Math.round((height * maxDim) / width);
              width = maxDim;
            } else {
              width = Math.round((width * maxDim) / height);
              height = maxDim;
            }
          }

          // Downscale bậc thang cho ảnh cực lớn (24-48MP) — iOS giới hạn canvas
          let source = img;
          let sw = img.width;
          let sh = img.height;
          while (sw > 2400 && sh > 2400 && sw / 2 >= width && sh / 2 >= height) {
            const step = document.createElement('canvas');
            step.width = Math.round(sw / 2);
            step.height = Math.round(sh / 2);
            step.getContext('2d').drawImage(source, 0, 0, step.width, step.height);
            source = step;
            sw = step.width;
            sh = step.height;
          }

          const canvas = document.createElement('canvas');
          canvas.width = width;
          canvas.height = height;
          canvas.getContext('2d').drawImage(source, 0, 0, sw, sh, 0, 0, width, height);
          canvas.toBlob(
            (blob) => {
              if (blob) {
                const newFilename = file.name.replace(/\.[^/.]+$/, '') + '.jpg';
                resolve(
                  new File([blob], newFilename, { type: 'image/jpeg', lastModified: Date.now() })
                );
              } else {
                resolve(file);
              }
            },
            'image/jpeg',
            quality
          );
        };
        img.onerror = () => resolve(file);
        img.src = e.target.result;
      };
      reader.onerror = () => resolve(file);
      reader.readAsDataURL(file);
    });
  }

  /**
   * Initialize modal and event listeners
   */
  init() {
    this.modal = document.getElementById('edit-profile-modal');
    if (!this.modal) {
      return;
    }

    this.setupEventListeners();
    this.setupFilePreview();
    this.setupPasswordToggles();
    this.setupTabNavigation();
  }

  /**
   * Setup all event listeners
   */
  setupEventListeners() {
    // Open modal button
    const editBtn = document.querySelector('.checkin-mkt-edit-profile-btn');
    if (editBtn) {
      editBtn.addEventListener('click', () => this.open());
    }

    // Close modal handlers
    const closeBtn = this.modal.querySelector('.modern-modal-close');
    const overlay = this.modal.querySelector('.modern-modal-overlay');

    if (closeBtn) {
      closeBtn.addEventListener('click', () => this.close());
    }

    if (overlay) {
      overlay.addEventListener('click', () => this.close());
    }

    // ESC key to close
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && this.modal.classList.contains('active')) {
        this.close();
      }
    });

    // Form submissions
    this.setupFormSubmissions();
  }

  /**
   * Setup file preview for avatar and CCCD
   */
  setupFilePreview() {
    // Avatar preview
    const avatarInput = document.getElementById('modern-avatar');
    const avatarPreview = document.getElementById('modern-avatar-preview');
    const avatarWrapper = document.querySelector('.avatar-preview-wrapper');

    if (avatarInput && avatarPreview) {
      avatarInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file && file.type.startsWith('image/')) {
          // Nén ngay khi chọn (512px là đủ cho avatar) — submit chỉ việc await
          this.compressedFiles.avatar = this.compressProfileImage(file, 512, 0.8).catch(
            () => file
          );
          this.compressedFiles.avatar.then((compressed) => {
            avatarPreview.src = URL.createObjectURL(compressed);
            this.showToast('Ảnh đại diện đã được chọn', 'success');
          });
        } else {
          this.showToast('Vui lòng chọn file ảnh hợp lệ', 'error');
        }
      });

      // Click on wrapper to trigger file input
      if (avatarWrapper) {
        avatarWrapper.addEventListener('click', () => avatarInput.click());
      }
    }

    // CCCD file buttons
    this.setupCCCDFileButtons();
  }

  /**
   * Setup CCCD file upload buttons with image preview
   */
  setupCCCDFileButtons() {
    const cccdFront = document.getElementById('modern-cccd-front');
    const cccdBack = document.getElementById('modern-cccd-back');
    const frontPreview = document.getElementById('cccd-front-preview');
    const backPreview = document.getElementById('cccd-back-preview');

    // CCCD: nén 1600px (đủ nét để đọc chữ trên thẻ), preview từ ảnh đã nén
    const setupCCCDInput = (input, preview, labelSelector, sideLabel, fileKey) => {
      if (!input || !preview) return;
      input.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (!file || !file.type.startsWith('image/')) return;
        this.compressedFiles[fileKey] = this.compressProfileImage(file, 1600, 0.8).catch(
          () => file
        );
        this.compressedFiles[fileKey].then((compressed) => {
          const img = preview.querySelector('.cccd-preview-image');
          img.src = URL.createObjectURL(compressed);
          preview.classList.add('has-image');

          const btn = document.querySelector(labelSelector);
          if (btn) {
            btn.innerHTML = '<i class="fas fa-check"></i><span>Đã chọn</span>';
            btn.style.background = '#34c759';
          }
          this.showToast(`CCCD ${sideLabel} đã được chọn`, 'success');
        });
      });
    };

    setupCCCDInput(cccdFront, frontPreview, 'label[for="modern-cccd-front"]', 'mặt trước', 'cccd_front');
    setupCCCDInput(cccdBack, backPreview, 'label[for="modern-cccd-back"]', 'mặt sau', 'cccd_back');
  }

  /**
   * Setup password toggle buttons
   */
  setupPasswordToggles() {
    const toggleButtons = this.modal.querySelectorAll('.modern-password-toggle');

    toggleButtons.forEach((btn) => {
      btn.addEventListener('click', () => {
        const targetId = btn.dataset.target;
        const input = document.getElementById(targetId);

        if (input) {
          const isPassword = input.type === 'password';
          input.type = isPassword ? 'text' : 'password';

          // Use emoji instead of FontAwesome icons
          btn.textContent = isPassword ? '🙈' : '👁';
        }
      });
    });
  }

  /**
   * Setup tab navigation
   */
  setupTabNavigation() {
    const tabs = this.modal.querySelectorAll('.modern-tab');

    tabs.forEach((tab) => {
      tab.addEventListener('click', () => {
        const tabName = tab.dataset.tab;
        this.switchTab(tabName);
      });
    });
  }

  /**
   * Switch between tabs
   */
  switchTab(tabName) {
    // Update tabs
    this.modal.querySelectorAll('.modern-tab').forEach((tab) => {
      tab.classList.toggle('active', tab.dataset.tab === tabName);
    });

    // Update panes
    this.modal.querySelectorAll('.modern-tab-pane').forEach((pane) => {
      const paneId = `${tabName}-pane`;
      pane.classList.toggle('active', pane.id === paneId);
    });

    // Update footer styling based on active tab
    const modernFooter = document.getElementById('modernFooter');
    if (modernFooter) {
      modernFooter.classList.remove('profile-active', 'password-active', 'notifications-active');
      modernFooter.classList.add(`${tabName}-active`);
    }

    // Show/hide appropriate submit button
    const profileBtn = document.getElementById('profile-submit-btn');
    const passwordBtn = document.getElementById('password-submit-btn');

    if (tabName === 'profile') {
      if (profileBtn) {
        profileBtn.style.display = 'flex';
        profileBtn.disabled = false;
      }
      if (passwordBtn) {
        passwordBtn.style.display = 'none';
        passwordBtn.disabled = true;
      }
    } else if (tabName === 'password') {
      if (profileBtn) {
        profileBtn.style.display = 'none';
        profileBtn.disabled = true;
      }
      if (passwordBtn) {
        passwordBtn.style.display = 'flex';
        passwordBtn.disabled = false;
      }
    } else if (tabName === 'notifications') {
      // Hide all submit buttons for notifications tab
      if (profileBtn) {
        profileBtn.style.display = 'none';
        profileBtn.disabled = true;
      }
      if (passwordBtn) {
        passwordBtn.style.display = 'none';
        passwordBtn.disabled = true;
      }
      // Initialize push notifications when switching to this tab
      this.initPushNotifications();
    }

    this.currentTab = tabName;
  }

  /**
   * Initialize push notifications tab
   */
  initPushNotifications() {
    // Skip if already initialized
    if (this.pushNotificationsInitialized) {
      // But still try to setup checkboxes if not done
      if (!this.notificationTypesInitialized) {
        this.setupNotificationTypeCheckboxes();
      }
      return;
    }

    const toggle = document.getElementById('push-notifications-toggle');
    const statusBadge = document.getElementById('push-status-badge');
    const blockedWarning = document.getElementById('push-blocked-warning');
    const notSupportedWarning = document.getElementById('push-not-supported');
    const typesContainer = document.getElementById('notification-types-container');
    const testContainer = document.getElementById('test-notification-container');
    const testBtn = document.getElementById('test-notification-btn');

    // Update notification descriptions based on user role
    this.updateNotificationTypesByRole();

    // Check if OneSignal is configured in Admin
    if (!window.checkinData || !window.checkinData.push || !window.checkinData.push.appId) {
      this.updatePushStatusBadge('not-configured');
      if (toggle) {
        toggle.disabled = true;
      }
      this.pushNotificationsInitialized = true;
      return;
    }

    // Check if browser supports push notifications
    const hasServiceWorker = 'serviceWorker' in navigator;
    const hasPushManager = 'PushManager' in window;
    const hasNotification = 'Notification' in window;
    const isIOS =
      /iPad|iPhone|iPod/.test(navigator.userAgent) ||
      (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
    const isPWA =
      window.matchMedia('(display-mode: standalone)').matches ||
      window.navigator.standalone === true;
    const iosVersion = (() => {
      const match = navigator.userAgent.match(/OS (\d+)_(\d+)/);
      return match ? parseFloat(`${match[1]}.${match[2]}`) : 0;
    })();

    console.log('[Push Debug]', {
      hasServiceWorker,
      hasPushManager,
      hasNotification,
      isIOS,
      isPWA,
      iosVersion,
      standalone: window.navigator.standalone,
    });

    // For iOS PWA: try manual init if OneSignal not loaded
    if (isIOS && isPWA) {
      const globalConfig = window.checkinData || window.checkinMkt192;
      const hasConfig = !!(globalConfig && globalConfig.push && globalConfig.push.appId);
      if (!window.OneSignal && hasConfig) {
        this.tryManualOneSignalInit(globalConfig.push.appId);
      }
    }

    if (!hasServiceWorker || !hasPushManager || !hasNotification) {
      if (notSupportedWarning) {
        notSupportedWarning.style.display = 'flex';

        // Show iOS-specific message
        if (isIOS) {
          const warningText = notSupportedWarning.querySelector('span') || notSupportedWarning;
          if (iosVersion > 0 && iosVersion < 16.4) {
            warningText.innerHTML = `<strong>iOS ${iosVersion}</strong> không hỗ trợ Push Notifications. Vui lòng cập nhật lên iOS 16.4 trở lên.`;
          } else if (!isPWA) {
            warningText.innerHTML =
              'Để nhận thông báo trên iPhone, vui lòng:<br>1. Mở trang này trong Safari<br>2. Nhấn nút <strong>Chia sẻ</strong> (hình vuông có mũi tên)<br>3. Chọn <strong>"Thêm vào Màn hình chính"</strong><br>4. Mở ứng dụng từ Màn hình chính';
          }
        }
      }
      if (toggle) {
        toggle.disabled = true;
      }
      this.updatePushStatusBadge('not-supported');
      return;
    }

    // Listen for push status changes
    document.addEventListener('pushStatusChange', (e) => {
      this.handlePushStatusChange(e.detail.status, e.detail.info);
    });

    // Setup checkbox event listeners immediately (they may already be visible)
    this.setupNotificationTypeCheckboxes();

    // Setup toggle handler
    if (toggle) {
      toggle.addEventListener('change', async () => {
        if (!window.pushManager) {
          console.error('PushManager not initialized');
          this.showToast('Hệ thống thông báo chưa sẵn sàng. Vui lòng đợi...', 'error');
          toggle.checked = !toggle.checked;
          return;
        }

        toggle.disabled = true;

        try {
          if (toggle.checked) {
            const result = await window.pushManager.subscribe();

            // Theo OneSignal docs: optedIn=true means subscribed
            const osOptedIn = window.OneSignal?.User?.PushSubscription?.optedIn;
            if (!result && osOptedIn === true) {
              // Không revert toggle vì optedIn = true = subscribed theo tài liệu
            } else if (!result) {
              // Revert toggle nếu thực sự thất bại
              toggle.checked = false;
            }
          } else {
            await window.pushManager.unsubscribe();
          }
        } catch (error) {
          console.error('Error toggling push notifications:', error);
          toggle.checked = !toggle.checked;
        }
        toggle.disabled = false;
      });
    }

    // Setup test notification button
    if (testBtn) {
      testBtn.addEventListener('click', async () => {
        testBtn.disabled = true;
        testBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> <span>Đang gửi...</span>';

        try {
          // Sử dụng pushManager.sendTestNotification() nếu có, hoặc gọi trực tiếp API
          let result;
          if (window.pushManager && window.pushManager.sendTestNotification) {
            result = await window.pushManager.sendTestNotification();
          } else {
            const response = await fetch(`${checkinData.restUrl}push/test`, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'X-WP-Nonce': checkinData.nonce,
              },
            });
            result = await response.json();
          }

          if (result.success) {
            this.showToast('Đã gửi thông báo thử!', 'success');
          } else {
            // Check if error is "no device" - try auto re-sync
            const errorMsg = result.message || '';
            if (
              errorMsg.includes('không tìm thấy') ||
              errorMsg.includes('no device') ||
              errorMsg.includes('No active')
            ) {
              this.showToast('Thiết bị chưa được đăng ký. Đang thử đăng ký lại...', 'info');

              // Try to force re-sync
              if (window.pushManager && window.pushManager.forceSync) {
                testBtn.innerHTML =
                  '<i class="fas fa-sync fa-spin"></i> <span>Đang đăng ký lại...</span>';
                const syncResult = await window.pushManager.forceSync();

                if (syncResult && syncResult.success) {
                  this.showToast('Đã đăng ký lại thành công! Hãy gửi thử lần nữa.', 'success');
                } else {
                  // If force sync failed, offer to re-subscribe
                  this.showResubscribeOption(testBtn);
                }
              } else {
                this.showResubscribeOption(testBtn);
              }
            } else {
              this.showToast(errorMsg || 'Lỗi gửi thông báo', 'error');
            }
          }
        } catch (error) {
          console.error('Error sending test notification:', error);
          this.showToast('Lỗi gửi thông báo thử', 'error');
        }

        testBtn.disabled = false;
        testBtn.innerHTML = '<i class="fas fa-paper-plane"></i> <span>Gửi thông báo thử</span>';
      });
    }

    // Check initial status
    this.checkInitialPushStatus();

    this.pushNotificationsInitialized = true;
  }

  /**
   * Check initial push notification status
   */
  async checkInitialPushStatus() {
    const toggle = document.getElementById('push-notifications-toggle');

    // If pushManager exists, get status from it
    if (window.pushManager) {
      const status = window.pushManager.getStatus();
      this.handlePushStatusChange(status, {});
      return;
    }

    // Try to get status directly from Notification API while waiting for pushManager
    const directStatus = this.getDirectNotificationStatus();
    if (directStatus) {
      this.handlePushStatusChange(directStatus, {});
      return;
    }

    // Wait for pushManager to be ready (max 5 seconds)
    let attempts = 0;
    const maxAttempts = 10;
    const checkInterval = setInterval(() => {
      attempts++;
      if (window.pushManager) {
        clearInterval(checkInterval);
        const status = window.pushManager.getStatus();
        this.handlePushStatusChange(status, {});
      } else if (attempts >= maxAttempts) {
        // Timeout - try direct status check as fallback
        clearInterval(checkInterval);
        const fallbackStatus = this.getDirectNotificationStatus() || 'not-asked';
        this.handlePushStatusChange(fallbackStatus, {});
        if (toggle) {
          toggle.disabled = false; // Allow user to try enabling
        }
      }
    }, 500);
  }

  /**
   * Get notification status directly from browser API (fallback when pushManager not ready)
   */
  getDirectNotificationStatus() {
    if (!('Notification' in window)) {
      return 'not-supported';
    }

    const permission = Notification.permission;
    switch (permission) {
      case 'granted':
        return 'subscribed'; // Assume subscribed if permission granted
      case 'denied':
        return 'denied';
      case 'default':
        return 'not-asked';
      default:
        return null;
    }
  }

  /**
   * Handle push status change
   */
  handlePushStatusChange(status, info) {
    const toggle = document.getElementById('push-notifications-toggle');
    const blockedWarning = document.getElementById('push-blocked-warning');
    const typesContainer = document.getElementById('notification-types-container');
    const testContainer = document.getElementById('test-notification-container');

    this.updatePushStatusBadge(status);

    if (toggle) {
      toggle.checked = status === 'subscribed';
      toggle.disabled = status === 'denied' || status === 'not-supported';
    }

    if (blockedWarning) {
      blockedWarning.style.display = status === 'denied' ? 'flex' : 'none';
    }

    if (typesContainer) {
      typesContainer.style.display = status === 'subscribed' ? 'block' : 'none';

      // Setup checkbox event listeners for notification types (only once)
      if (status === 'subscribed' && !this.notificationTypesInitialized) {
        this.setupNotificationTypeCheckboxes();
        this.notificationTypesInitialized = true;
      }
    }

    if (testContainer) {
      testContainer.style.display = status === 'subscribed' ? 'flex' : 'none';
    }
  }

  /**
   * Setup event listeners for notification type checkboxes
   * When user changes checkboxes, save to server immediately
   */
  setupNotificationTypeCheckboxes() {
    // Skip if already initialized
    if (this.notificationTypesInitialized) {
      console.log('[Push] Notification type checkboxes already initialized');
      return;
    }

    const checkboxes = document.querySelectorAll('input[name="notify_type"]');
    console.log('[Push] setupNotificationTypeCheckboxes - found', checkboxes.length, 'checkboxes');

    if (!checkboxes.length) {
      console.log('[Push] No checkboxes found, will retry on status change');
      return;
    }

    const self = this;

    // Debounce function to avoid too many API calls
    let saveTimeout = null;
    const debouncedSave = () => {
      if (saveTimeout) clearTimeout(saveTimeout);
      saveTimeout = setTimeout(() => {
        self.saveNotificationTypes();
      }, 500);
    };

    checkboxes.forEach((checkbox) => {
      checkbox.addEventListener('change', debouncedSave);
    });

    this.notificationTypesInitialized = true;
    console.log('[Push] Notification type checkboxes initialized successfully');
  }

  /**
   * Save notification types to server
   * Only saves checked types - unchecked types will not receive notifications
   */
  async saveNotificationTypes() {
    const checkboxes = document.querySelectorAll('input[name="notify_type"]:checked');
    const selectedTypes = Array.from(checkboxes).map((cb) => cb.value);

    console.log('[Push] Saving notification types:', selectedTypes);

    if (selectedTypes.length === 0) {
      this.showToast('Vui lòng chọn ít nhất một loại thông báo', 'warning');
      return;
    }

    try {
      const response = await fetch(`${checkinData.restUrl}push/preferences`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-WP-Nonce': checkinData.nonce,
        },
        credentials: 'include',
        body: JSON.stringify({
          notification_types: selectedTypes,
        }),
      });

      const result = await response.json();

      if (result.success) {
        this.showToast('Đã cập nhật loại thông báo', 'success');
        console.log('[Push] Notification types saved:', result.notification_types);
      } else {
        this.showToast(result.message || 'Lỗi cập nhật', 'error');
      }
    } catch (error) {
      console.error('[Push] Error saving notification types:', error);
      this.showToast('Lỗi kết nối', 'error');
    }
  }

  /**
   * Update push status badge
   */
  updatePushStatusBadge(status) {
    const badge = document.getElementById('push-status-badge');
    if (!badge) return;

    const statusConfig = {
      subscribed: {
        icon: 'fas fa-check-circle',
        text: 'Đã bật thông báo',
        class: 'status-subscribed',
      },
      unsubscribed: {
        icon: 'fas fa-bell-slash',
        text: 'Đã tắt thông báo',
        class: 'status-unsubscribed',
      },
      denied: { icon: 'fas fa-ban', text: 'Bị chặn', class: 'status-denied' },
      'not-asked': {
        icon: 'fas fa-question-circle',
        text: 'Chưa cấp quyền',
        class: 'status-not-asked',
      },
      'not-supported': {
        icon: 'fas fa-exclamation-triangle',
        text: 'Không hỗ trợ',
        class: 'status-denied',
      },
      'not-configured': {
        icon: 'fas fa-cog',
        text: 'Chưa cấu hình (Admin)',
        class: 'status-not-asked',
      },
      unknown: {
        icon: 'fas fa-spinner fa-spin',
        text: 'Đang kiểm tra...',
        class: 'status-unknown',
      },
    };

    const config = statusConfig[status] || statusConfig.unknown;

    badge.className = `status-badge ${config.class}`;
    badge.innerHTML = `<i class="${config.icon}"></i> <span>${config.text}</span>`;
  }

  /**
   * Update notification type descriptions based on user role
   * Manager/Cashier see additional options for Invoice and Approval
   */
  updateNotificationTypesByRole() {
    const userRole = window.checkinData?.userRole || window.checkinData?.user_role || '';
    const isManagerOrCashier = ['administrator', 'manager', 'cashier', 'quanly', 'thungan'].some(
      (role) => userRole.toLowerCase().includes(role)
    );

    // Show appropriate descriptions
    const staffDescs = document.querySelectorAll('.notify-desc-staff');
    const managerDescs = document.querySelectorAll('.notify-desc-manager');

    staffDescs.forEach((el) => {
      el.style.display = isManagerOrCashier ? 'none' : 'block';
    });

    managerDescs.forEach((el) => {
      el.style.display = isManagerOrCashier ? 'block' : 'none';
    });

    console.log('[Push] User role:', userRole, '| Manager view:', isManagerOrCashier);
  }

  /**
   * Show toast notification
   */
  showToast(message, type = 'info') {
    if (typeof showCheckinToast === 'function') {
      showCheckinToast({ message, type, duration: 3000 });
    } else {
      console.log(`[${type}] ${message}`);
    }
  }

  /**
   * Show resubscribe option when device not found
   */
  async showResubscribeOption(testBtn) {
    const testContainer = document.getElementById('test-notification-container');
    if (!testContainer) return;

    // Check if resubscribe button already exists
    if (document.getElementById('resubscribe-btn')) return;

    this.showToast('Không thể đồng bộ. Vui lòng đăng ký lại thông báo.', 'warning');

    // Create resubscribe button
    const resubscribeBtn = document.createElement('button');
    resubscribeBtn.id = 'resubscribe-btn';
    resubscribeBtn.type = 'button';
    resubscribeBtn.className = 'setting-btn btn-warning';
    resubscribeBtn.innerHTML = '<i class="fas fa-sync"></i> <span>Đăng ký lại</span>';
    resubscribeBtn.style.marginLeft = '10px';

    resubscribeBtn.addEventListener('click', async () => {
      resubscribeBtn.disabled = true;
      resubscribeBtn.innerHTML =
        '<i class="fas fa-spinner fa-spin"></i> <span>Đang xử lý...</span>';

      try {
        if (window.pushManager) {
          // Unsubscribe first
          await window.pushManager.unsubscribe();
          await new Promise((resolve) => setTimeout(resolve, 1000));

          // Subscribe again
          await window.pushManager.subscribe();

          this.showToast('Đã đăng ký lại thành công! Hãy thử gửi thông báo.', 'success');
          resubscribeBtn.remove();
        }
      } catch (error) {
        console.error('Resubscribe error:', error);
        this.showToast('Lỗi đăng ký lại. Vui lòng thử tắt/bật lại thông báo.', 'error');
        resubscribeBtn.innerHTML = '<i class="fas fa-sync"></i> <span>Thử lại</span>';
        resubscribeBtn.disabled = false;
      }
    });

    testContainer.appendChild(resubscribeBtn);
  }

  /**
   * Try to manually load and init OneSignal (fallback for iOS PWA)
   */
  async tryManualOneSignalInit(appId) {
    console.log('[Push] Manual init starting...');

    try {
      // Load OneSignal SDK if not present
      if (!window.OneSignal && !window.OneSignalDeferred) {
        console.log('[Push] Loading SDK...');

        await new Promise((resolve, reject) => {
          const script = document.createElement('script');
          script.src = 'https://cdn.onesignal.com/sdks/web/v16/OneSignalSDK.page.js';
          script.async = true;
          script.onload = () => {
            console.log('[Push] SDK loaded');
            resolve();
          };
          script.onerror = () => reject(new Error('SDK load failed'));
          document.head.appendChild(script);
        });
      }

      // Quick poll for OneSignalDeferred (max 500ms)
      let attempts = 0;
      while (!window.OneSignalDeferred && attempts < 10) {
        await new Promise((r) => setTimeout(r, 50));
        attempts++;
      }

      if (!window.OneSignalDeferred) {
        console.error('[Push] SDK not ready after polling');
        return;
      }

      console.log('[Push] Configuring OneSignal...');

      const self = this;
      window.OneSignalDeferred.push(async function (OneSignal) {
        try {
          await OneSignal.init({
            appId: appId,
            allowLocalhostAsSecureOrigin: true,
            serviceWorkerParam: { scope: '/' },
            serviceWorkerPath: '/OneSignalSDKWorker.js',
          });

          const perm = OneSignal.Notifications.permission;
          const sub = OneSignal.User?.PushSubscription?.optedIn;

          console.log('[Push] Ready:', { permission: perm, subscribed: sub });

          // Update UI
          const status = sub ? 'subscribed' : perm ? 'unsubscribed' : 'not-asked';
          self.handlePushStatusChange(status, { permission: perm, isSubscribed: sub });

          // Setup toggle handler
          self.setupDirectToggleHandler(OneSignal);
        } catch (initErr) {
          console.error('[Push] Init error:', initErr);
        }
      });
    } catch (err) {
      console.error('[Push] Manual init error:', err);
    }
  }

  /**
   * Setup direct toggle handler for iOS PWA (bypasses pushManager)
   */
  setupDirectToggleHandler(OneSignal) {
    const toggle = document.getElementById('push-notifications-toggle');
    if (!toggle) return;

    // Remove old handler and add new one
    const newToggle = toggle.cloneNode(true);
    toggle.parentNode.replaceChild(newToggle, toggle);

    newToggle.disabled = false;

    const self = this;
    newToggle.addEventListener('change', async () => {
      newToggle.disabled = true;
      const isEnabling = newToggle.checked;
      console.log('[Push] Toggle:', isEnabling ? 'ON' : 'OFF');

      try {
        if (isEnabling) {
          // Subscribe
          console.log('[Push] Requesting permission...');
          await OneSignal.Notifications.requestPermission();

          const perm = OneSignal.Notifications.permission;
          console.log('[Push] Permission result:', perm);

          if (perm) {
            console.log('[Push] Opting in...');
            await OneSignal.User.PushSubscription.optIn();

            // Wait for subscription to complete
            await new Promise((r) => setTimeout(r, 1500));

            const sub = OneSignal.User.PushSubscription.optedIn;
            let playerId = OneSignal.User.PushSubscription.id;
            console.log('[Push] Subscribed:', sub, 'ID:', playerId);

            // iOS sometimes needs more time to get player ID
            if (sub && !playerId) {
              console.log('[Push] Player ID not ready, waiting...');
              await new Promise((r) => setTimeout(r, 2000));
              playerId = OneSignal.User.PushSubscription.id;
              console.log('[Push] Player ID after wait:', playerId);
            }

            if (sub && playerId) {
              // Sync with server FIRST
              if (window.checkinData) {
                try {
                  // Thử sync lần đầu
                  let response = await fetch(`${checkinData.restUrl}push/subscribe`, {
                    method: 'POST',
                    headers: {
                      'Content-Type': 'application/json',
                      'X-WP-Nonce': checkinData.nonce,
                    },
                    credentials: 'include',
                    body: JSON.stringify({
                      subscription_id: playerId,
                      platform: 'ios_pwa',
                    }),
                  });

                  // Nếu 401/403, thử refresh nonce và retry
                  if (response.status === 401 || response.status === 403) {
                    console.warn('[Push] Got 401/403, refreshing nonce and retrying...');
                    const refreshed = await self.refreshNonce();
                    if (refreshed) {
                      response = await fetch(`${checkinData.restUrl}push/subscribe`, {
                        method: 'POST',
                        headers: {
                          'Content-Type': 'application/json',
                          'X-WP-Nonce': checkinData.nonce,
                        },
                        credentials: 'include',
                        body: JSON.stringify({
                          subscription_id: playerId,
                          platform: 'ios_pwa',
                        }),
                      });
                    }
                  }

                  const result = await response.json();
                  console.log('[Push] Server sync result:', result);

                  if (result.success) {
                    self.handlePushStatusChange('subscribed', {});
                    self.showToast('Đã bật thông báo đẩy!', 'success');
                  } else {
                    throw new Error(result.message || 'Sync failed');
                  }
                } catch (e) {
                  console.error('[Push] Server sync failed:', e);
                  self.showToast('Lỗi đồng bộ với server', 'error');
                  newToggle.checked = false;
                  self.handlePushStatusChange('error', {});
                }
              } else {
                self.handlePushStatusChange('subscribed', {});
                self.showToast('Đã bật thông báo đẩy!', 'success');
              }
            } else if (sub && !playerId) {
              console.error('[Push] Subscribed but no player ID - iOS issue');
              self.showToast('Lỗi: Không nhận được ID thiết bị', 'error');
              newToggle.checked = false;
              self.handlePushStatusChange('error', {});
            } else {
              newToggle.checked = false;
              self.handlePushStatusChange('unsubscribed', {});
            }
          } else {
            newToggle.checked = false;
            self.handlePushStatusChange('denied', {});
            self.showToast('Quyền thông báo bị từ chối', 'error');
          }
        } else {
          // Unsubscribe
          console.log('[Push] Opting out...');
          await OneSignal.User.PushSubscription.optOut();
          self.handlePushStatusChange('unsubscribed', {});
          self.showToast('Đã tắt thông báo đẩy', 'info');
          console.log('[Push] Opted out');
        }
      } catch (err) {
        console.error('[Push] Toggle error:', err);
        newToggle.checked = !newToggle.checked;
        self.showToast('Lỗi: ' + err.message, 'error');
      }

      newToggle.disabled = false;
    });

    console.log('[Push] Direct toggle handler ready');
  }

  /**
   * Setup form submissions
   */
  setupFormSubmissions() {
    // Profile submit button
    const profileBtn = document.getElementById('profile-submit-btn');
    if (profileBtn) {
      profileBtn.addEventListener('click', (e) => {
        e.preventDefault();
        const form = document.getElementById('modern-edit-profile-form');
        if (form) {
          this.handleProfileSubmit({ target: form, preventDefault: () => {} });
        }
      });
    }

    // Password submit button
    const passwordBtn = document.getElementById('password-submit-btn');
    if (passwordBtn) {
      passwordBtn.addEventListener('click', (e) => {
        e.preventDefault();
        const form = document.getElementById('modern-change-password-form');
        if (form) {
          this.handlePasswordSubmit({ target: form, preventDefault: () => {} });
        }
      });
    }
  }

  /**
   * Handle edit profile form submission
   */
  async handleProfileSubmit(e, isRetry = false) {
    e.preventDefault();

    const form = e.target;
    const submitBtn = document.getElementById('profile-submit-btn');

    // Validate form
    if (!form.checkValidity()) {
      form.reportValidity();
      return;
    }

    // Disable button and show loading
    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.classList.add('loading');
      submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i><span>Đang lưu...</span>';
    }
    this.showPageLoading();

    try {
      // Prepare form data
      const formData = new FormData();
      formData.append('display_name', document.getElementById('modern-display-name').value.trim());
      formData.append('email', document.getElementById('modern-email').value.trim());
      formData.append('facebook', document.getElementById('modern-facebook').value.trim());
      formData.append('tiktok', document.getElementById('modern-tiktok').value.trim());
      formData.append('birthday', document.getElementById('modern-birthday').value);
      formData.append('gender', document.getElementById('modern-gender').value);
      formData.append('address', document.getElementById('modern-address').value.trim());

      // Add files if selected — dùng bản ĐÃ NÉN (nén sẵn từ lúc chọn file,
      // ảnh iPhone HEIC 48MP → JPEG ~100-300KB nên upload nhanh và server
      // convert webp lưu được ngay, không phải chờ xử lý lại)
      const avatarRaw = document.getElementById('modern-avatar').files[0];
      const avatarFile = avatarRaw
        ? await (this.compressedFiles.avatar || this.compressProfileImage(avatarRaw, 512, 0.8))
        : null;
      if (avatarFile) {
        formData.append('avatar', avatarFile, avatarFile.name);
      }

      // CHỈ gửi CCCD files nếu user thực sự chọn file mới và CCCD chưa verified
      // Tránh gửi empty file khi CCCD đã verified
      if (!this.isCCCDVerified) {
        const frontRaw = document.getElementById('modern-cccd-front').files[0];
        const cccdFrontFile = frontRaw
          ? await (this.compressedFiles.cccd_front ||
              this.compressProfileImage(frontRaw, 1600, 0.8))
          : null;
        if (cccdFrontFile) {
          formData.append('cccd_front', cccdFrontFile, cccdFrontFile.name);
        }

        const backRaw = document.getElementById('modern-cccd-back').files[0];
        const cccdBackFile = backRaw
          ? await (this.compressedFiles.cccd_back ||
              this.compressProfileImage(backRaw, 1600, 0.8))
          : null;
        if (cccdBackFile) {
          formData.append('cccd_back', cccdBackFile, cccdBackFile.name);
        }
      }

      formData.append('nonce', checkinData.nonce);

      // Log what we're sending for debugging
      console.log('Sending profile update:', {
        hasAvatar: !!avatarFile,
        hasCCCDFront: !!document.getElementById('modern-cccd-front').files[0],
        hasCCCDBack: !!document.getElementById('modern-cccd-back').files[0],
        isCCCDVerified: this.isCCCDVerified,
        isRetry: isRetry,
      });

      // Send request with timeout protection (30 seconds)
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 30000);

      try {
        const response = await fetch(`${checkinData.restUrl}staff-update-profile`, {
          method: 'POST',
          headers: {
            'X-WP-Nonce': checkinData.nonce,
          },
          body: formData,
          credentials: 'include', // Critical: Include cookies for WordPress authentication
          signal: controller.signal,
        });

        clearTimeout(timeoutId);

        // Log response for debugging
        console.log('Profile update response status:', response.status);

        const contentType = response.headers.get('content-type');
        if (!contentType || !contentType.includes('application/json')) {
          console.error('Non-JSON response received');
          const textResponse = await response.text();
          console.error('Response text:', textResponse);
          throw new Error('Server returned non-JSON response. Check console for details.');
        }

        const result = await response.json();
        console.log('Profile update result:', result);

        // Check for authentication errors - try to refresh nonce and retry once
        if (response.status === 401 || result.code === 'rest_cookie_invalid_nonce') {
          if (!isRetry) {
            console.log('Nonce invalid, attempting to refresh and retry...');
            const refreshed = await this.refreshNonce();
            if (refreshed) {
              // Reset UI and retry
              if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.classList.remove('loading');
              }
              this.hidePageLoading();
              // Retry with new nonce
              return this.handleProfileSubmit(e, true);
            }
          }
          throw new Error('Phiên đăng nhập hết hạn. Vui lòng tải lại trang và đăng nhập lại.');
        }

        if (result.success) {
          this.showToast('Cập nhật hồ sơ thành công!', 'success');

          // Fetch fresh data from server to get updated profile
          const freshData = await this.fetchFreshProfileData();

          if (freshData) {
            // Update profile page UI with fresh data
            this.updateProfileUI(freshData);

            // Update modal form with fresh data
            this.populateFormWithData(freshData);
          } // Close modal after delay
          setTimeout(() => {
            this.close();
          }, 1000);
        } else {
          throw new Error(result.message || 'Cập nhật hồ sơ thất bại');
        }
      } catch (error) {
        clearTimeout(timeoutId);
        console.error('Profile update error:', error);

        if (error.name === 'AbortError') {
          this.showToast('Yêu cầu quá lâu (timeout 30s). Vui lòng thử lại.', 'error');
        } else {
          this.showToast(error.message || 'Lỗi khi cập nhật hồ sơ', 'error');
        }
      } finally {
        const submitBtn = document.getElementById('profile-submit-btn');
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.classList.remove('loading');
          submitBtn.innerHTML = '<i class="fas fa-save"></i><span>Lưu thay đổi</span>';
        }
        this.hidePageLoading();
      }
    } catch (error) {
      console.error('Outer profile update error:', error);
      this.showToast('Lỗi không xác định khi cập nhật hồ sơ', 'error');
      this.hidePageLoading();
    }
  }

  /**
   * Handle change password form submission
   */
  async handlePasswordSubmit(e) {
    e.preventDefault();

    const form = e.target;
    const submitBtn = document.getElementById('password-submit-btn');

    // Validate form
    if (!form.checkValidity()) {
      form.reportValidity();
      return;
    }

    const currentPassword = document.getElementById('modern-current-password').value;
    const newPassword = document.getElementById('modern-new-password').value;
    const confirmPassword = document.getElementById('modern-confirm-password').value;

    // Check if new passwords match
    if (newPassword !== confirmPassword) {
      this.showToast('Mật khẩu mới không khớp!', 'error');
      return;
    }

    // Password strength validation
    if (newPassword.length < 8) {
      this.showToast('Mật khẩu phải có ít nhất 8 ký tự', 'error');
      return;
    }

    // Disable button and show loading
    if (submitBtn) {
      submitBtn.disabled = true;
      submitBtn.classList.add('loading');
      submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i><span>Đang đổi...</span>';
    }
    this.showPageLoading();

    try {
      const response = await fetch(`${checkinData.restUrl}change-password`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-WP-Nonce': checkinData.nonce,
        },
        body: JSON.stringify({
          current_password: currentPassword,
          new_password: newPassword,
        }),
      });

      const contentType = response.headers.get('content-type');
      if (!contentType || !contentType.includes('application/json')) {
        throw new Error('Server returned non-JSON response');
      }

      const result = await response.json();

      if (result.success) {
        this.showToast('Đổi mật khẩu thành công! Đang đăng xuất...', 'success');

        // Logout and redirect after delay
        setTimeout(async () => {
          await fetch(`${checkinData.restUrl}logout`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'X-WP-Nonce': checkinData.nonce,
            },
          });

          localStorage.clear();
          sessionStorage.clear();
          window.location.reload();
        }, 1500);
      } else {
        throw new Error(result.message || 'Đổi mật khẩu thất bại');
      }
    } catch (error) {
      this.showToast(error.message || 'Lỗi khi đổi mật khẩu', 'error');
      const submitBtn = document.getElementById('password-submit-btn');
      if (submitBtn) {
        submitBtn.disabled = false;
        submitBtn.classList.remove('loading');
        submitBtn.innerHTML = '<i class="fas fa-check-circle"></i><span>Đổi mật khẩu</span>';
      }
      this.hidePageLoading();
    }
  }

  /**
   * Open modal and load current data
   */
  async open() {
    // Show loading while fetching data
    this.showPageLoading();

    // Ensure closing class is removed if present
    this.modal.classList.remove('closing');
    this.modal.classList.add('active');
    this.modal.style.display = 'flex';

    // Hide navbar
    const navbar = document.querySelector('.checkin-mkt-nav-bar');
    if (navbar) {
      navbar.style.display = 'none';
    }

    // Switch to profile tab by default
    this.switchTab('profile');

    // Load current profile data
    await this.loadProfileData();

    // Disable body scroll
    document.body.style.overflow = 'hidden';

    // Hide loading after data loaded
    this.hidePageLoading();
  }

  /**
   * Close modal
   */
  close() {
    // Add closing class to play exit animations and keep layout centered
    this.modal.classList.add('closing');

    // Wait for animation to finish (match CSS 280ms), then hide and cleanup
    setTimeout(() => {
      this.modal.classList.remove('active');
      this.modal.classList.remove('closing');
      this.modal.style.display = 'none';
    }, 320);

    // Show navbar
    const navbar = document.querySelector('.checkin-mkt-nav-bar');
    if (navbar) {
      navbar.style.display = 'flex';
    }

    // Enable body scroll
    document.body.style.overflow = '';

    // Reset forms
    this.resetForms();
  }

  /**
   * Load profile from localStorage
   */
  loadProfileFromLocalStorage() {
    try {
      // Sử dụng cùng key với user-profile.js
      const profileData = localStorage.getItem('checkin_user_profile');
      const timestamp = localStorage.getItem('checkin_user_profile_timestamp');

      console.log('📦 Checking localStorage:', {
        hasProfile: !!profileData,
        hasTimestamp: !!timestamp,
        timestamp: timestamp,
      });

      if (!profileData || !timestamp) {
        console.log('❌ No profile data in localStorage');
        return null;
      }

      const now = Date.now();
      const fiveMinutes = 5 * 60 * 1000;
      const age = now - parseInt(timestamp);

      console.log('⏰ Cache age:', {
        age: Math.round(age / 1000) + 's',
        valid: age < fiveMinutes,
      });

      // Check if cache is still valid (5 minutes)
      if (age < fiveMinutes) {
        return JSON.parse(profileData);
      }

      // Cache expired
      console.log('⏳ Cache expired');
      return null;
    } catch (error) {
      console.error('Error loading profile from localStorage:', error);
      return null;
    }
  }

  /**
   * Save profile to localStorage
   */
  saveProfileToLocalStorage(data) {
    try {
      // Sử dụng cùng key với user-profile.js
      localStorage.setItem('checkin_user_profile', JSON.stringify(data));
      localStorage.setItem('checkin_user_profile_timestamp', Date.now().toString());
    } catch (error) {
      console.error('Error saving profile to localStorage:', error);
    }
  }

  /**
   * Fetch fresh profile data from API
   */
  async fetchFreshProfileData() {
    try {
      const response = await fetch(`${checkinData.restUrl}user-profile`, {
        method: 'GET',
        headers: {
          'X-WP-Nonce': checkinData.nonce,
        },
        credentials: 'include',
      });

      const result = await response.json();

      if (result.success && result.data) {
        // Lưu vào localStorage để dùng lần sau
        this.saveProfileToLocalStorage(result.data);
        return result.data;
      } else {
        return null;
      }
    } catch (error) {
      return null;
    }
  }

  /**
   * Populate form with data
   */
  populateFormWithData(data) {
    if (!data) return;

    // Populate form fields
    this.setFieldValue('modern-display-name', data.display_name);
    this.setFieldValue('modern-email', data.email);
    this.setFieldValue('modern-facebook', data.facebook);
    this.setFieldValue('modern-tiktok', data.tiktok);
    this.setFieldValue('modern-birthday', data.birthday);
    this.setFieldValue('modern-address', data.address);

    // Set gender select
    const genderSelect = document.getElementById('modern-gender');
    if (genderSelect && data.gender) {
      const genderMap = {
        Nam: 'male',
        nam: 'male',
        Nữ: 'female',
        nu: 'female',
        nữ: 'female',
        Khác: 'other',
        khac: 'other',
        male: 'male',
        female: 'female',
        other: 'other',
      };
      genderSelect.value = genderMap[data.gender] || '';
    }

    // Set avatar preview
    const avatarPreview = document.getElementById('modern-avatar-preview');
    if (avatarPreview && data.avatar_url) {
      avatarPreview.src = data.avatar_url;
    }

    // Handle CCCD verification status
    if (data.is_cccd === 1) {
      this.isCCCDVerified = true;
      this.handleCCCDVerified();
    } else {
      this.isCCCDVerified = false;
      this.handleCCCDNotVerified();
    }
  }

  /**
   * Load current profile data into form
   */
  async loadProfileData() {
    try {
      // Lấy data từ localStorage trước (nhanh hơn)
      const cachedProfile = this.loadProfileFromLocalStorage();

      if (cachedProfile) {
        this.populateFormWithData(cachedProfile);
        return;
      }

      // Fallback: Nếu không có cache, gọi API
      const response = await fetch(`${checkinData.restUrl}user-profile`, {
        method: 'GET',
        headers: {
          'X-WP-Nonce': checkinData.nonce,
        },
        credentials: 'include',
      });

      const result = await response.json();

      if (result.success) {
        const data = result.data;
        this.populateFormWithData(data);
        // Lưu vào cache
        this.saveProfileToLocalStorage(data);
      } else if (result.code === 'rest_cookie_invalid_nonce') {
        // Nonce invalid - xóa cache cũ và yêu cầu login lại
        localStorage.removeItem('checkin_user_profile');
        localStorage.removeItem('checkin_user_profile_timestamp');
        this.showToast('Phiên đăng nhập hết hạn. Vui lòng đăng nhập lại.', 'error');
      } else {
        this.showToast(result.message || 'Không thể tải dữ liệu hồ sơ', 'error');
      }
    } catch (error) {
      this.showToast('Không thể tải dữ liệu hồ sơ', 'error');
    }
  }

  /**
   * Handle CCCD verified state
   */
  handleCCCDVerified() {
    const badge = document.getElementById('cccd-verified-badge');
    const uploadContainer = document.getElementById('cccd-upload-container');
    const frontInput = document.getElementById('modern-cccd-front');
    const backInput = document.getElementById('modern-cccd-back');

    if (badge) {
      badge.style.display = 'inline-flex';
    }

    if (uploadContainer) {
      uploadContainer.style.display = 'none';
    }

    // Remove required attribute
    if (frontInput) frontInput.removeAttribute('required');
    if (backInput) backInput.removeAttribute('required');
  }

  /**
   * Handle CCCD not verified state
   */
  handleCCCDNotVerified() {
    const badge = document.getElementById('cccd-verified-badge');
    const uploadContainer = document.getElementById('cccd-upload-container');
    const frontInput = document.getElementById('modern-cccd-front');
    const backInput = document.getElementById('modern-cccd-back');

    if (badge) {
      badge.style.display = 'none';
    }

    if (uploadContainer) {
      uploadContainer.style.display = 'grid';
    }

    // KHÔNG set required cho CCCD - cho phép user cập nhật thông tin khác trước
    // User có thể upload CCCD sau
    if (frontInput) frontInput.removeAttribute('required');
    if (backInput) backInput.removeAttribute('required');
  }

  /**
   * Set field value safely
   */
  setFieldValue(id, value) {
    const field = document.getElementById(id);
    if (field) {
      field.value = value || '';
    }
  }

  /**
   * Reset all forms
   */
  resetForms() {
    const profileForm = document.getElementById('modern-edit-profile-form');
    const passwordForm = document.getElementById('modern-change-password-form');

    if (profileForm) profileForm.reset();
    if (passwordForm) passwordForm.reset();

    // Reset CCCD file buttons
    const cccdFrontBtn = document.querySelector('label[for="modern-cccd-front"]');
    const cccdBackBtn = document.querySelector('label[for="modern-cccd-back"]');

    if (cccdFrontBtn) {
      cccdFrontBtn.innerHTML = '<i class="fas fa-cloud-upload-alt"></i><span>Chọn ảnh</span>';
      cccdFrontBtn.style.background = '';
    }

    if (cccdBackBtn) {
      cccdBackBtn.innerHTML = '<i class="fas fa-cloud-upload-alt"></i><span>Chọn ảnh</span>';
      cccdBackBtn.style.background = '';
    }
  }

  /**
   * Show toast notification using shared toast component
   */
  showToast(message, type = 'info') {
    if (typeof showCheckinToast === 'function') {
      showCheckinToast({ message, type, duration: 3000 });
    } else {
      console.log(`[${type.toUpperCase()}] ${message}`);
    }
  }

  /**
   * Refresh nonce by fetching from server
   * This is needed after login when the old nonce becomes invalid
   */
  async refreshNonce() {
    try {
      // Dùng admin-ajax thay vì REST API để bypass nonce check
      // wp_ajax_checkin_refresh_nonce chỉ kiểm tra user login qua session cookie
      const response = await fetch(`${checkinData.ajaxUrl}?action=checkin_refresh_nonce`, {
        method: 'GET',
        credentials: 'include',
      });

      if (response.ok) {
        const result = await response.json();
        if (result.success && result.data && result.data.nonce) {
          checkinData.nonce = result.data.nonce;
          console.log('Nonce refreshed successfully via admin-ajax');
          return true;
        }
      }
      console.error('Failed to refresh nonce, response:', await response.text());
      return false;
    } catch (error) {
      console.error('Failed to refresh nonce:', error);
      return false;
    }
  }

  /**
   * Show page loading overlay
   */
  showPageLoading() {
    if (typeof showPageLoading === 'function') {
      showPageLoading();
    }
  }

  /**
   * Hide page loading overlay
   */
  hidePageLoading() {
    if (typeof hidePageLoading === 'function') {
      hidePageLoading();
    }
  }

  /**
   * Update profile UI immediately after successful save
   */
  updateProfileUI(data) {
    if (!data) return;

    // Update avatar
    if (data.avatar_url) {
      const avatarElements = document.querySelectorAll('.checkin-mkt-avatar-image');
      avatarElements.forEach((img) => {
        img.src = data.avatar_url;
      });
    }

    // Update display name
    if (data.display_name) {
      const nameElements = document.querySelectorAll('.checkin-mkt-display-name');
      nameElements.forEach((el) => {
        el.textContent = data.display_name;
      });
    }

    // Update email
    if (data.email) {
      const emailElements = document.querySelectorAll('.checkin-mkt-user-email');
      emailElements.forEach((el) => {
        if (el.tagName === 'A') {
          el.href = `mailto:${data.email}`;
          el.textContent = data.email;
        } else {
          el.textContent = data.email;
        }
      });
    }

    // Update birthday
    if (data.birthday) {
      const birthdayElements = document.querySelectorAll('.checkin-mkt-user-birthday');
      birthdayElements.forEach((el) => {
        el.textContent = data.birthday;
      });
    }

    // Update Facebook
    const facebookElements = document.querySelectorAll('.checkin-mkt-user-facebook');
    facebookElements.forEach((el) => {
      if (data.facebook) {
        if (el.tagName === 'A') {
          el.href = data.facebook;
          el.textContent = data.facebook;
        } else {
          el.textContent = data.facebook;
        }
        el.style.display = '';
      } else {
        el.textContent = 'Chưa cập nhật';
        if (el.tagName === 'A') {
          el.href = '#';
        }
      }
    });

    // Update TikTok
    const tiktokElements = document.querySelectorAll('.checkin-mkt-user-tiktok');
    tiktokElements.forEach((el) => {
      if (data.tiktok) {
        if (el.tagName === 'A') {
          el.href = data.tiktok;
          el.textContent = data.tiktok;
        } else {
          el.textContent = data.tiktok;
        }
        el.style.display = '';
      } else {
        el.textContent = 'Chưa cập nhật';
        if (el.tagName === 'A') {
          el.href = '#';
        }
      }
    });

    // Update address
    if (data.address) {
      const addressElements = document.querySelectorAll('.checkin-mkt-user-address');
      addressElements.forEach((el) => {
        el.textContent = data.address;
      });
    }

    // Update CCCD status
    const cccdElements = document.querySelectorAll('.checkin-mkt-user-cccd');
    cccdElements.forEach((el) => {
      el.textContent = data.is_cccd ? 'Đã cập nhật' : 'Chưa cập nhật';
    });
  }
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    window.modernProfileModal = new ModernProfileModal();
  });
} else {
  window.modernProfileModal = new ModernProfileModal();
}
