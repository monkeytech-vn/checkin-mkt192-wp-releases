document.addEventListener('DOMContentLoaded', function () {
  // ============================================
  // PERFORMANCE UTILITIES
  // ============================================

  // Debounce function - delay execution until after wait ms have passed
  function debounce(func, wait = 100) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func.apply(this, args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }

  // Throttle function - limit execution to once per wait ms
  function throttle(func, wait = 100) {
    let inThrottle;
    return function (...args) {
      if (!inThrottle) {
        func.apply(this, args);
        inThrottle = true;
        setTimeout(() => (inThrottle = false), wait);
      }
    };
  }

  // DOM element cache to avoid repeated querySelector calls
  const domCache = new Map();
  function getElement(selector) {
    if (!domCache.has(selector)) {
      domCache.set(selector, document.querySelector(selector));
    }
    return domCache.get(selector);
  }
  function getElementById(id) {
    if (!domCache.has(id)) {
      domCache.set(id, document.getElementById(id));
    }
    return domCache.get(id);
  }
  // Clear cache when resetting form
  function clearDomCache() {
    domCache.clear();
  }

  // ============================================
  // IMAGE PRELOADER - Cache hình ảnh thanh toán
  // ============================================
  const imageCache = new Map();

  // Preload và cache hình ảnh vào memory + localStorage
  // force = true sẽ xóa cache cũ và load lại
  function preloadImage(url, key, force = false) {
    if (!url) return Promise.resolve();

    // Nếu force = true, xóa cache cũ
    if (force) {
      imageCache.delete(key);
      localStorage.removeItem(`qr_cache_${key}`);
    } else if (imageCache.has(key)) {
      return Promise.resolve();
    }

    return new Promise((resolve) => {
      // Kiểm tra localStorage trước (chỉ khi không force)
      if (!force) {
        const cachedData = localStorage.getItem(`qr_cache_${key}`);
        if (cachedData) {
          imageCache.set(key, cachedData);
          resolve();
          return;
        }
      }

      // Load từ URL (không dùng crossOrigin để tránh lỗi CORS)
      const img = new Image();
      img.onload = function () {
        try {
          // Lưu vào memory cache
          imageCache.set(key, url);
          // Thử lưu vào localStorage (có thể fail nếu quá lớn)
          localStorage.setItem(`qr_cache_${key}`, url);
        } catch (e) {
          // Silent fail - không cần warn
        }
        resolve();
      };
      img.onerror = () => resolve(); // Không fail nếu load lỗi
      img.src = url;
    });
  }

  // Lấy hình ảnh từ cache (nhanh hơn load từ server)
  function getCachedImageUrl(key, fallbackUrl) {
    return imageCache.get(key) || fallbackUrl;
  }

  // App state - khai báo sớm để các hàm có thể truy cập
  const state = {
    invoiceId: null,
    bookingId: null,
    branchId: null,
    customerId: null,
    customerName: '',
    customerPhone: '',
    membershipLabel: '',
    promoCode: '',
    ctkmList: [],
    services: [],
    barbers: [],
    servicePrice: 0,
    currentStep: 0,
    totalSteps: 7,
    promotion: null,
    promotionAmount: 0,
    ratings: {
      service: null,
      barbers: {},
    },
    dissatisfactionReasons: {
      service: [],
      barbers: [],
    },
    otherReason: {
      service: '',
      barbers: '',
    },
    tipAmount: 0,
    showTipStep: true,
    paymentMethod: null,
    totalAmount: 0,
    isPaid: false,
  };

  /**
   * Lấy URL QR code dựa trên loại thanh toán và chi nhánh
   * @param {string} type - Loại thanh toán: 'bank', 'momo', 'zalopay'
   * @param {string} defaultUrl - URL mặc định nếu không có QR
   * @param {number|null} branchId - Branch ID (optional, sẽ lấy từ state nếu không truyền)
   * @returns {string} URL của QR code
   */
  function getPaymentQRUrl(type, defaultUrl, branchId = null) {
    const paymentData = checkinData.paymentQRs?.[type];
    if (!paymentData) return defaultUrl;

    // Kiểm tra nếu bật chế độ multi-branch và có QR theo chi nhánh
    if (paymentData.qr_per_branch && paymentData.qr_branches) {
      // Ưu tiên: branchId truyền vào > state.branchId > currentUser.branch_id
      const rawBranchId = branchId || state.branchId || checkinData.currentUser?.branch_id;
      if (rawBranchId) {
        // Thử cả string và integer key vì PHP có thể lưu dưới dạng khác nhau
        const branchIdStr = String(rawBranchId);
        const branchIdInt = parseInt(rawBranchId, 10);
        const qrUrl = paymentData.qr_branches[branchIdStr] || paymentData.qr_branches[branchIdInt];
        if (qrUrl) {
          return qrUrl;
        }
      }
    }

    // Fallback về QR mặc định
    return paymentData.qr_url || defaultUrl;
  }

  // Preload tất cả hình ảnh QR thanh toán
  // force = true sẽ xóa cache cũ và load lại (dùng khi có branch_id mới từ invoice)
  function preloadPaymentImages(branchId = null, force = false) {
    const preloadPromises = [];

    // Chỉ preload các QR đã được cấu hình trong hệ thống
    // Không preload URL mặc định hardcoded để tránh lỗi CORS khi test local
    const paymentQRs = checkinData.paymentQRs || {};

    // Preload bank QR
    if (paymentQRs.bank?.enabled) {
      const bankUrl = getPaymentQRUrl('bank', null, branchId);
      if (bankUrl) preloadPromises.push(preloadImage(bankUrl, 'bank', force));
    }

    // Preload MoMo QR
    if (paymentQRs.momo?.enabled) {
      const momoUrl = getPaymentQRUrl('momo', null, branchId);
      if (momoUrl) preloadPromises.push(preloadImage(momoUrl, 'momo', force));
    }

    // Preload ZaloPay QR
    if (paymentQRs.zalopay?.enabled) {
      const zalopayUrl = getPaymentQRUrl('zalopay', null, branchId);
      if (zalopayUrl) preloadPromises.push(preloadImage(zalopayUrl, 'zalopay', force));
    }

    if (preloadPromises.length > 0) {
      Promise.all(preloadPromises).then(() => {
        // Payment QR images preloaded
      });
    }
  }

  // Khởi chạy preload ngay khi DOM ready (dùng QR mặc định hoặc theo currentUser)
  preloadPaymentImages();

  // DOM elements
  const progressFill = document.getElementById('progressFill');
  const submitButton = document.getElementById('submitBtn');
  const newFeedbackBtn = document.getElementById('newFeedbackBtn');
  const resetPromoBtn = document.getElementById('resetPromoBtn');
  const promotionOptions = document.querySelectorAll('input[name="promotion"]');
  const checkboxOptions = document.querySelectorAll('.checkbox-option input[type="checkbox"]');
  const section4 = document.getElementById('section4');
  const tipOptions = document.querySelectorAll('.tip-option');
  const customTipInput = document.getElementById('customTip');
  const otherServiceReasonInput = document.getElementById('otherServiceReason');
  const otherBarberReasonInput = document.getElementById('otherBarberReason');
  const barberRatingsContainer = document.getElementById('barberRatings');
  const paymentMethodModal = document.getElementById('paymentMethodModal');
  const closePaymentModal = document.getElementById('closePaymentModal');
  const qrPaymentSection = document.getElementById('qrPaymentSection');
  const qrPaymentAmount = document.getElementById('qrPaymentAmount');
  const confirmPaymentBtn = document.getElementById('confirmPaymentBtn');

  // Display elements
  const customerNameDisplay = document.getElementById('customerName');
  const customerPhoneDisplay = document.getElementById('customerPhone');
  const summaryServiceName = document.getElementById('summaryServiceName');
  const summaryBarberName = document.getElementById('summaryBarberName');
  const servicePriceDisplay = document.getElementById('servicePrice');
  const promotionDisplay = document.getElementById('promotionDisplay');
  const tipDisplay = document.getElementById('tipDisplay');
  const totalDisplay = document.getElementById('totalDisplay');
  const promoDisplay = document.getElementById('promoDisplay');
  const finalAmountDisplay = document.getElementById('finalAmountDisplay');
  const serviceRatingDisplay = document.getElementById('serviceRatingDisplay');
  const barberRatingsDisplay = document.getElementById('barberRatingsDisplay');
  const serviceStarsDisplay = document.getElementById('serviceStarsDisplay');
  const transactionIdDisplay = document.getElementById('transactionId');
  const tipSummaryRow = document.getElementById('tipSummaryRow');

  // Polling variables - must be declared before checkPendingReview is called
  let cashier = null;
  let pollingIntervalId = null;

  // Event delegation flags - must be declared before any setup functions are called
  let ratingDelegationSetup = false;
  let tipDelegationSetup = false;
  let tipTouchActiveElement = null;
  let checkboxDelegationSetup = false;
  let checkboxTouchActiveElement = null;

  // Initialize
  checkPendingReview();
  updateProgressBar();
  setCurrentDate();
  setupEventListeners();
  attachRatingEventListeners();
  setupScrollReveal();

  async function fetchAPI(endpoint, options = {}) {
    try {
      const response = await fetch(`${checkinData.restUrl}${endpoint}`, {
        ...options,
        headers: {
          'Content-Type': 'application/json',
          'X-WP-Nonce': checkinData.nonce,
          ...options.headers,
        },
      });
      const text = await response.text();


      let result;
      try {
        result = JSON.parse(text);
      } catch (e) {
        return { success: false, message: 'Phản hồi API không phải JSON' };
      }

      // Xử lý cho notify-review
      if (endpoint.includes('notify-review')) {
        if (result.success === false) {
          throw new Error(result.message || 'Lỗi từ server');
        }
        return result;
      }

      if (result.success === undefined) {
        result.success = true;
      }
      if (result.status === undefined) {
        result.status = response.status;
      }

      if (!result.success) {
        return { success: false, message: result.message || `Lỗi khi gọi API ${endpoint}` };
      }
      return { success: true, data: result.data || result };
    } catch (error) {

      return { success: false, message: error.message };
    }
  }

  function checkPendingReview() {
    // Clear existing interval if any
    if (pollingIntervalId) {
      clearInterval(pollingIntervalId);
    }

    // Polling function with debounce
    const pollPendingReview = debounce(async () => {
      if (state.invoiceId) return; // Skip if already has invoice

      try {
        const result = await fetchAPI('pending-review');
        if (
          result.success &&
          result.data &&
          result.data.invoice_id &&
          result.data.invoice_id !== state.invoiceId
        ) {
          state.invoiceId = result.data.invoice_id;
          cashier = result.data.cashier || null;

          await loadInvoiceData();
        }
      } catch (error) {

      }
    }, 300);

    // Increased interval to 8 seconds for old touch devices
    pollingIntervalId = setInterval(pollPendingReview, 8000);

    // Initial poll
    pollPendingReview();
  }

  async function loadInvoiceData() {
    if (!state.invoiceId) {
      const urlParams = new URLSearchParams(window.location.search);
      state.invoiceId = urlParams.get('invoice_id');
      if (!state.invoiceId) {
        const result = await fetchAPI('pending-review');
        if (result.success && result.data && result.data.invoice_id) {
          state.invoiceId = result.data.invoice_id;
        } else {

          return;
        }
      }
    }

    try {
      // Tải danh sách CTKM
      const ctkmResult = await fetchAPI('settings/ctkm');
      if (ctkmResult.success) {
        state.ctkmList = ctkmResult.data.map((ctkm) => ({
          ...ctkm,
          applicable_services: normalizeApplicableServices(ctkm.applicable_services),
        }));
      } else {
        console.warn('Không thể tải danh sách CTKM:', ctkmResult.message);
        state.ctkmList = [];
      }

      // Tải danh sách dịch vụ để kiểm tra discounted_price
      const servicesResult = await fetchAPI('services');
      if (servicesResult.success) {
        state.serviceList = servicesResult.data;
      } else {
        console.warn('Không thể tải danh sách dịch vụ:', servicesResult.message);
        state.serviceList = [];
      }

      // Tải dữ liệu hóa đơn
      const result = await fetchAPI(`review/invoices/${state.invoiceId}`);
      if (result.success) {
        const invoice = result.data;


        state.bookingId = invoice.booking_id || null;
        state.branchId = invoice.branch_id || null;
        state.customerId = invoice.customer_id || null;

        // Preload lại QR images theo branch của invoice (force update cache)
        if (state.branchId) {
          preloadPaymentImages(state.branchId, true);
        }
        state.customerName = invoice.customer_name || 'Khách vãng lai';
        state.customerPhone = invoice.customer_phone || '123456789';
        state.membershipLabel = invoice.membership_label || 'Khách thường';
        state.promoCode = invoice.promo_code || null;
        state.promoName = invoice.promo_name || null;
        state.promoStatus = invoice.promo_status || null;
        state.services = invoice.services || [];
        state.servicePrice = parseFloat(invoice.subtotal) || 0;
        state.promotionAmount = parseFloat(invoice.discount) || 0;
        state.tipAmount = parseFloat(invoice.tips) || 0;
        state.totalAmount = parseFloat(invoice.total) || 0;
        state.barbers = [
          ...new Set(state.services.map((s) => s.staff_name).filter((name) => name)),
        ];
        state.transactionDate = invoice.created_at
          ? formatDate(invoice.created_at)
          : 'Không xác định';
        state.isPaid = invoice.status === 'paid';

        // Nếu không có promo_name, kiểm tra Ưu đãi Combo
        if (!state.promoName) {
          const discountedServicesCount = state.services.filter((s) => {
            const serviceData = state.serviceList.find((srv) => srv.service_id === s.service_id);
            return serviceData?.discounted_price && parseFloat(serviceData.discounted_price) > 0;
          }).length;
          if (discountedServicesCount >= 2) {
            state.promoName = 'Ưu đãi Combo';
            state.promotionAmount = state.services.reduce((sum, s) => {
              const serviceData = state.serviceList.find((srv) => srv.service_id === s.service_id);
              if (serviceData?.discounted_price && parseFloat(serviceData.discounted_price) > 0) {
                return (
                  sum +
                  (parseFloat(serviceData.service_price) - parseFloat(serviceData.discounted_price))
                );
              }
              return sum;
            }, 0);
            state.servicePrice = state.services.reduce((sum, s) => {
              const serviceData = state.serviceList.find((srv) => srv.service_id === s.service_id);
              return (
                sum +
                (serviceData?.discounted_price && parseFloat(serviceData.discounted_price) > 0
                  ? parseFloat(serviceData.discounted_price)
                  : parseFloat(s.price))
              );
            }, 0);
            state.totalAmount = state.servicePrice + state.tipAmount; // Không trừ promotionAmount
          } else if (discountedServicesCount === 1) {
            const serviceId = state.services.find((s) => {
              const serviceData = state.serviceList.find((srv) => srv.service_id === s.service_id);
              return serviceData?.discounted_price && parseFloat(serviceData.discounted_price) > 0;
            })?.service_id;
            const matchingVoucher = state.ctkmList.find(
              (ctkm) =>
                ctkm.applicable_services &&
                ctkm.applicable_services.some((sId) => String(sId) === String(serviceId))
            );
            if (matchingVoucher) {
              state.promoName = matchingVoucher.ctkm_name;
              state.promotionAmount = parseFloat(matchingVoucher.value) || 0;
              state.servicePrice = state.services.reduce((sum, s) => {
                const serviceData = state.serviceList.find(
                  (srv) => srv.service_id === s.service_id
                );
                return (
                  sum +
                  (serviceData?.discounted_price && parseFloat(serviceData.discounted_price) > 0
                    ? parseFloat(serviceData.discounted_price)
                    : parseFloat(s.price))
                );
              }, 0);
              state.totalAmount = state.servicePrice - state.promotionAmount + state.tipAmount;
            }
          }
        }

        // Cập nhật giao diện
        document.getElementById('invoiceId').textContent = state.invoiceId || 'Không xác định';
        document.getElementById('transactionDate').textContent = state.transactionDate;
        document.getElementById('transactionDateFinal').textContent = state.transactionDate;
        customerPhoneDisplay.textContent = state.customerPhone;
        customerNameDisplay.textContent = state.customerName;

        const membershipLabelElement = document.getElementById('membershipLabel');
        membershipLabelElement.textContent = state.membershipLabel;
        membershipLabelElement.classList.remove('vip-tag', 'member-tag', 'normal-tag');
        if (state.membershipLabel === 'Khách Vip') {
          membershipLabelElement.classList.add('vip-tag');
        } else if (state.membershipLabel === 'Thành Viên') {
          membershipLabelElement.classList.add('member-tag');
        } else {
          membershipLabelElement.classList.add('normal-tag');
        }

        const promoCodeElement = document.getElementById('promoCode');
        const promoStatusElement = document.getElementById('promoStatus');

        // Clear previous status classes
        promoStatusElement.classList.remove(
          'status-active',
          'status-expired',
          'status-invalid',
          'status-none',
          'hidden'
        );

        // Logic hiển thị promoCode và promoStatus
        const isNotMember =
          state.membershipLabel === 'Khách thường' ||
          state.membershipLabel === 'Khách Thường' ||
          state.membershipLabel === 'Thường' ||
          state.customerName === 'KHÁCH VÃNG LAI';

        if (isNotMember) {
          promoCodeElement.textContent = 'Không có';
          promoCodeElement.classList.add('hidden');
          promoStatusElement.classList.add('hidden');
        } else {
          // Show promo code
          const promoCodeDisplay =
            state.promoCode && state.promoCode !== 'Không có' ? state.promoCode : 'Không có';
          promoCodeElement.textContent = promoCodeDisplay;
          promoCodeElement.classList.remove('hidden');

          // Show promo status with appropriate styling
          if (state.promoStatus) {
            const statusLower = state.promoStatus.toLowerCase();
            if (
              statusLower.includes('hiệu lực') ||
              statusLower.includes('active') ||
              statusLower.includes('hợp lệ')
            ) {
              promoStatusElement.textContent = 'Có hiệu lực';
              promoStatusElement.classList.add('status-active');
            } else if (statusLower.includes('hết hạn') || statusLower.includes('expired')) {
              promoStatusElement.textContent = 'Hết hạn';
              promoStatusElement.classList.add('status-expired');
            } else if (statusLower.includes('không') || statusLower.includes('invalid')) {
              promoStatusElement.textContent = 'Không áp dụng';
              promoStatusElement.classList.add('status-invalid');
            } else {
              promoStatusElement.textContent = state.promoStatus;
              promoStatusElement.classList.add('status-active');
            }
            promoStatusElement.classList.remove('hidden');
          } else if (!state.promoCode || state.promoCode === 'Không có') {
            promoStatusElement.textContent = 'Không có mã';
            promoStatusElement.classList.add('status-none');
            promoStatusElement.classList.remove('hidden');
          } else {
            promoStatusElement.classList.add('hidden');
          }
        }

        summaryServiceName.textContent =
          state.services.map((s) => s.service_name).join(', ') || 'Không xác định';
        summaryBarberName.textContent = state.barbers.join(', ') || 'Không xác định';
        servicePriceDisplay.textContent = formatCurrency(state.servicePrice);

        renderPromoCodeOptions();
        renderBarberRatings();
        updateSummarySection();
        updateProgressBar();
      } else {
        throw new Error(result.message);
      }
    } catch (error) {
      console.error(`Lỗi khi tải hóa đơn ${state.invoiceId}:`, error.message);
      showError(`Lỗi: ${error.message || 'Không thể tải thông tin hóa đơn'}`);
    }
  }

  function normalizeApplicableServices(services) {
    if (Array.isArray(services)) {
      return services;
    }
    if (typeof services === 'string') {
      try {
        const parsed = JSON.parse(services);
        return Array.isArray(parsed) ? parsed : [];
      } catch (e) {
        console.warn('Failed to parse applicable_services:', services);
        return [];
      }
    }
    return [];
  }

  function renderPromoCodeOptions() {
    const promoOptionsContainer = document.getElementById('promoOptions');
    if (!promoOptionsContainer) return;

    // Xóa nội dung cũ và thêm Không áp dụng
    promoOptionsContainer.innerHTML = `
        <div class="promo-checkbox-option flex items-center p-5 bg-white border-2 border-gray-200 rounded-xl shadow-sm cursor-pointer transition-all duration-200">
            <input type="radio" name="promoCode" id="promoNone" value="" class="mr-4 w-5 h-5 text-blue-600">
            <label for="promoNone" class="flex-1 cursor-pointer">
                <span class="block text-lg font-semibold text-gray-800">Không áp dụng</span>
                <span class="block text-sm text-gray-500 mt-1">Không sử dụng khuyến mãi</span>
            </label>
        </div>
    `;

    // Thêm Ưu đãi Combo nếu có ≥ 2 dịch vụ với discounted_price
    const discountedServicesCount = state.services.filter((s) => {
      const serviceData = state.serviceList.find((srv) => srv.service_id === s.service_id);
      return serviceData?.discounted_price && parseFloat(serviceData.discounted_price) > 0;
    }).length;
    if (discountedServicesCount >= 2) {
      const totalDiscount = state.services.reduce((sum, s) => {
        const serviceData = state.serviceList.find((srv) => srv.service_id === s.service_id);
        if (serviceData?.discounted_price && parseFloat(serviceData.discounted_price) > 0) {
          return (
            sum + (parseFloat(serviceData.service_price) - parseFloat(serviceData.discounted_price))
          );
        }
        return sum;
      }, 0);
      const comboOption = document.createElement('div');
      comboOption.className =
        'promo-checkbox-option flex items-center p-5 bg-white border-2 border-gray-200 rounded-xl shadow-sm cursor-pointer transition-all duration-200';
      comboOption.innerHTML = `
            <input type="radio" name="promoCode" id="promo-combo" value="Ưu đãi Combo" class="mr-4 w-5 h-5 text-blue-600">
            <label for="promo-combo" class="flex-1 cursor-pointer">
                <span class="block text-lg font-semibold text-gray-800">Ưu đãi Combo</span>
                <span class="block text-sm text-gray-500 mt-1">Giảm ${formatCurrency(
                  totalDiscount
                )} cho ${discountedServicesCount} dịch vụ</span>
            </label>
        `;
      promoOptionsContainer.appendChild(comboOption);
    }

    // Thêm CTKM/voucher
    const today = new Date();
    state.ctkmList.forEach((ctkm, index) => {
      const startDate = new Date(ctkm.start_date);
      const endDate = new Date(ctkm.end_date);
      const membershipLabels = Array.isArray(ctkm.membership_label)
        ? ctkm.membership_label
        : [ctkm.membership_label || 'Tất cả'];
      const isMembershipValid =
        membershipLabels.includes('Tất cả') || membershipLabels.includes(state.membershipLabel);

      if (ctkm.status === 'active' && today >= startDate && today <= endDate && isMembershipValid) {
        const description =
          ctkm.description && ctkm.description.length > 100
            ? ctkm.description.substring(0, 97) + '...'
            : ctkm.description || 'Không có mô tả';
        const div = document.createElement('div');
        div.className =
          'promo-checkbox-option flex items-center p-5 bg-white border-2 border-gray-200 rounded-xl shadow-sm cursor-pointer transition-all duration-200';
        const safeId = `promo-${index}-${ctkm.ctkm_name.replace(/[^a-zA-Z0-9]/g, '')}`;
        div.innerHTML = `
                <input type="radio" name="promoCode" id="${safeId}" value="${
                  ctkm.ctkm_name
                }" class="mr-4 w-5 h-5 text-blue-600">
                <label for="${safeId}" class="flex-1 cursor-pointer">
                    <span class="block text-lg font-semibold text-gray-800">${
                      ctkm.ctkm_name
                    } (${formatCurrency(ctkm.ctkm_value || ctkm.value)})</span>
                    <span class="block text-sm text-gray-500 mt-1">${description}</span>
                </label>
            `;
        promoOptionsContainer.appendChild(div);
      }
    });

    // Setup promo option listeners with pointer events
    setupPromoOptionListeners(discountedServicesCount);
  }

  function setupPromoOptionListeners(discountedServicesCount) {
    document.querySelectorAll('.promo-checkbox-option').forEach((option) => {
      let promoTouchActive = false;

      option.addEventListener(
        'pointerdown',
        (e) => {
          promoTouchActive = true;
          option.classList.add('touching');
        },
        { passive: true }
      );

      option.addEventListener(
        'pointerup',
        (e) => {
          if (!promoTouchActive) return;
          option.classList.remove('touching');

          const input = option.querySelector('input');
          if (e.target !== input && input) {
            input.checked = true;
          }

          requestAnimationFrame(() => {
            // Clear all touched states
            document.querySelectorAll('.promo-checkbox-option').forEach((opt) => {
              opt.classList.remove('touched');
            });

            // Mark selected
            if (input && input.checked) {
              option.classList.add('touched');
            }

            handlePromoCodeChange();
            promoTouchActive = false;
          });
        },
        { passive: true }
      );

      option.addEventListener(
        'pointercancel',
        () => {
          option.classList.remove('touching');
          promoTouchActive = false;
        },
        { passive: true }
      );

      option.addEventListener(
        'pointerleave',
        () => {
          option.classList.remove('touching');
          promoTouchActive = false;
        },
        { passive: true }
      );
    });

    // Apply initial selection state - ưu tiên promoName (tự động áp dụng), nếu không có thì dùng promoCode
    const selectedPromo = state.promoName || state.promoCode || '';
    let selectedPromoInput = null;

    // Tìm và chọn card khuyến mãi tương ứng
    if (selectedPromo) {
      selectedPromoInput = document.querySelector(
        `input[name="promoCode"][value="${selectedPromo}"]`
      );
      if (selectedPromoInput) {
        selectedPromoInput.checked = true;
        selectedPromoInput.closest('.promo-checkbox-option')?.classList.add('touched');
      }
    }

    // Nếu không tìm thấy card tương ứng và có dịch vụ ưu đãi, tự động chọn combo hoặc voucher
    if (!selectedPromoInput && !selectedPromo) {
      if (discountedServicesCount >= 2) {
        selectedPromoInput = document.querySelector(
          `input[name="promoCode"][value="Ưu đãi Combo"]`
        );
        if (selectedPromoInput) {
          selectedPromoInput.checked = true;
          selectedPromoInput.closest('.promo-checkbox-option')?.classList.add('touched');
        }
      } else if (discountedServicesCount === 1) {
        const serviceId = state.services.find((s) => {
          const serviceData = state.serviceList.find((srv) => srv.service_id === s.service_id);
          return serviceData?.discounted_price && parseFloat(serviceData.discounted_price) > 0;
        })?.service_id;
        const matchingVoucher = state.ctkmList.find(
          (ctkm) =>
            ctkm.applicable_services &&
            ctkm.applicable_services.some((sId) => String(sId) === String(serviceId))
        );
        if (matchingVoucher) {
          selectedPromoInput = document.querySelector(
            `input[name="promoCode"][value="${matchingVoucher.ctkm_name}"]`
          );
          if (selectedPromoInput) {
            selectedPromoInput.checked = true;
            selectedPromoInput.closest('.promo-checkbox-option')?.classList.add('touched');
          }
        }
      }
    }

    // Disable if paid and not cashier
    const isDisabled = state.isPaid && !checkinData.currentUser?.is_cashier;
    document.querySelectorAll('input[name="promoCode"]').forEach((input) => {
      input.disabled = isDisabled;
    });
  }

  function handlePromoCodeChange() {
    const selectedRadio = document.querySelector('input[name="promoCode"]:checked');
    const selectedPromo = selectedRadio ? selectedRadio.value : '';

    if (selectedPromo) {
      if (selectedPromo === 'Ưu đãi Combo') {
        state.promotion = 'Ưu đãi Combo';
        state.promotionAmount = state.services.reduce((sum, s) => {
          const serviceData = state.serviceList.find((srv) => srv.service_id === s.service_id);
          if (serviceData?.discounted_price && parseFloat(serviceData.discounted_price) > 0) {
            return (
              sum +
              (parseFloat(serviceData.service_price) - parseFloat(serviceData.discounted_price))
            );
          }
          return sum;
        }, 0);
        state.servicePrice = state.services.reduce((sum, s) => {
          const serviceData = state.serviceList.find((srv) => srv.service_id === s.service_id);
          return (
            sum +
            (serviceData?.discounted_price && parseFloat(serviceData.discounted_price) > 0
              ? parseFloat(serviceData.discounted_price)
              : parseFloat(s.price))
          );
        }, 0);
        state.totalAmount = state.servicePrice + state.tipAmount; // Không trừ promotionAmount
      } else {
        const ctkm = state.ctkmList.find((c) => c.ctkm_name === selectedPromo);
        if (ctkm) {
          state.promotion = ctkm.ctkm_name;
          state.promotionAmount = parseFloat(ctkm.value) || 0;
          state.servicePrice = state.services.reduce((sum, s) => {
            return sum + parseFloat(s.price);
          }, 0);
          state.totalAmount = state.servicePrice - state.promotionAmount + state.tipAmount;
        } else {
          state.promotion = null;
          state.promotionAmount = 0;
          state.servicePrice = state.services.reduce((sum, s) => {
            return sum + parseFloat(s.price);
          }, 0);
          state.totalAmount = state.servicePrice + state.tipAmount;
        }
      }
    } else {
      // User chọn "Không áp dụng" - hiển thị giá gốc, khuyến mãi = chênh lệch giá gốc và giá ưu đãi (nếu có)
      state.promotion = null;

      // Tính giá gốc (service_price) cho tất cả dịch vụ
      state.servicePrice = state.services.reduce((sum, s) => {
        const serviceData = state.serviceList.find((srv) => srv.service_id === s.service_id);
        // Luôn dùng giá gốc từ serviceData hoặc từ invoice nếu không có serviceData
        return sum + (serviceData ? parseFloat(serviceData.service_price) : parseFloat(s.price));
      }, 0);

      // Tính khuyến mãi = chênh lệch giữa giá gốc và giá ưu đãi (nếu có discounted_price)
      state.promotionAmount = state.services.reduce((sum, s) => {
        const serviceData = state.serviceList.find((srv) => srv.service_id === s.service_id);
        if (serviceData?.discounted_price && parseFloat(serviceData.discounted_price) > 0) {
          return (
            sum + (parseFloat(serviceData.service_price) - parseFloat(serviceData.discounted_price))
          );
        }
        return sum;
      }, 0);

      // Tổng tiền = giá gốc - khuyến mãi + tips
      state.totalAmount = state.servicePrice - state.promotionAmount + state.tipAmount;
    }

    updateSummarySection();
  }

  function formatDate(dateString) {
    try {
      const date = new Date(dateString);
      if (isNaN(date.getTime())) {
        throw new Error('Ngày không hợp lệ');
      }
      return date.toLocaleString('vi-VN', {
        hour: '2-digit',
        minute: '2-digit',
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
      });
    } catch (error) {
      console.warn(`Lỗi định dạng ngày: ${dateString}`, error);
      return 'Không xác định';
    }
  }

  function formatCurrency(amount) {
    return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(amount);
  }

  function renderBarberRatings() {
    barberRatingsContainer.innerHTML = '';
    state.barbers.forEach((barber) => {
      const div = document.createElement('div');
      div.className = 'mb-8';
      // Thêm rating-scroll-area wrapper để có vùng an toàn 2 bên khi vuốt màn hình
      div.innerHTML = `
            <h3 class="font-semibold text-2xl text-center text-blue-500 mb-4">${barber}</h3>
            <div class="rating-scroll-area">
              <div class="rating-container">
                  <div class="rating-option touch-friendly text-center p-4 bg-gray-50 rounded-xl cursor-pointer flex-1" data-type="barber" data-barber="${barber}" data-value="1">
                      <i class="fas fa-angry text-red-500 text-3xl mb-2"></i><br><span class="text-sm font-medium">Rất Tệ</span>
                  </div>
                  <div class="rating-option touch-friendly text-center p-4 bg-gray-50 rounded-xl cursor-pointer flex-1" data-type="barber" data-barber="${barber}" data-value="2">
                      <i class="fas fa-frown text-orange-500 text-3xl mb-2"></i><br><span class="text-sm font-medium">Chê Nha</span>
                  </div>
                  <div class="rating-option touch-friendly text-center p-4 bg-gray-50 rounded-xl cursor-pointer flex-1" data-type="barber" data-barber="${barber}" data-value="3">
                      <i class="fas fa-meh text-yellow-500 text-3xl mb-2"></i><br><span class="text-sm font-medium">Không Ưng Lắm</span>
                  </div>
                  <div class="rating-option touch-friendly text-center p-4 bg-gray-50 rounded-xl cursor-pointer flex-1" data-type="barber" data-barber="${barber}" data-value="4">
                      <i class="fas fa-smile text-blue-500 text-3xl mb-2"></i><br><span class="text-sm font-medium">Hài Lòng</span>
                  </div>
                  <div class="rating-option touch-friendly text-center p-4 bg-gray-50 rounded-xl cursor-pointer flex-1" data-type="barber" data-barber="${barber}" data-value="5">
                      <i class="fas fa-grin-stars text-green-500 text-3xl mb-2"></i><br><span class="text-sm font-medium">Siêu Hài Lòng</span>
                  </div>
              </div>
            </div>
        `;
      barberRatingsContainer.appendChild(div);

      // Apply saved rating state using new data attributes
      const selectedRating = state.ratings.barbers[barber];
      if (selectedRating) {
        requestAnimationFrame(() => {
          updateRatingUI('barber', barber, selectedRating);
        });
      }
    });

    // Apply service rating state
    const serviceRating = state.ratings.service;
    if (serviceRating) {
      requestAnimationFrame(() => {
        updateRatingUI('service', null, serviceRating);
      });
    }

    attachRatingEventListeners();
  }

  // Modern touch-friendly rating system using Event Delegation for better performance
  function attachRatingEventListeners() {
    // Use event delegation - attach once to parent container
    if (ratingDelegationSetup) return;
    ratingDelegationSetup = true;

    const container = document.body;

    container.addEventListener(
      'pointerdown',
      (e) => {
        const option = e.target.closest('.rating-option');
        if (option) handleRatingPointerDown({ currentTarget: option });
      },
      { passive: true }
    );

    container.addEventListener(
      'pointerup',
      (e) => {
        const option = e.target.closest('.rating-option');
        if (option) handleRatingPointerUp({ currentTarget: option });
      },
      { passive: true }
    );

    container.addEventListener(
      'pointercancel',
      (e) => {
        const option = e.target.closest('.rating-option');
        if (option) handleRatingPointerCancel({ currentTarget: option });
      },
      { passive: true }
    );

    container.addEventListener(
      'pointerleave',
      (e) => {
        const option = e.target.closest('.rating-option');
        if (option) handleRatingPointerCancel({ currentTarget: option });
      },
      { passive: true, capture: true }
    );

    // Prevent default touch behavior
    container.addEventListener(
      'touchstart',
      (e) => {
        if (e.target.closest('.rating-option')) {
          e.preventDefault();
        }
      },
      { passive: false }
    );
  }

  let ratingTouchTimeout = null;
  let isRatingInteracting = false;

  function handleRatingPointerDown(e) {
    if (isRatingInteracting) return;
    isRatingInteracting = true;

    const option = e.currentTarget;
    option.classList.add('touching');

    // Add ripple effect
    option.classList.add('ripple');
    clearTimeout(ratingTouchTimeout);
    ratingTouchTimeout = setTimeout(() => {
      option.classList.remove('ripple');
    }, 400);
  }

  function handleRatingPointerUp(e) {
    if (!isRatingInteracting) return;

    const option = e.currentTarget;
    option.classList.remove('touching');

    // Use requestAnimationFrame for smooth visual update
    requestAnimationFrame(() => {
      processRatingSelection(option);
      isRatingInteracting = false;
    });
  }

  function handleRatingPointerCancel(e) {
    const option = e.currentTarget;
    option.classList.remove('touching', 'ripple');
    isRatingInteracting = false;
  }

  function processRatingSelection(option) {
    const value = parseInt(option.getAttribute('data-value'));
    const type = option.getAttribute('data-type');
    const barber = option.getAttribute('data-barber');

    // Update state
    if (type === 'service') {
      state.ratings.service = value;
      state.currentStep = 1;
      updateRatingUI('service', null, value);
    } else if (type === 'barber' && barber) {
      state.ratings.barbers[barber] = value;
      state.currentStep = 2;
      updateRatingUI('barber', barber, value);
    }

    updateConditionalSections();
    updateSummarySection();
    updateProgressBar();
  }

  function updateRatingUI(type, barber, selectedValue) {
    // Get all options in the same group
    let groupSelector;
    if (type === 'service') {
      groupSelector = '.rating-option[data-type="service"]';
    } else {
      groupSelector = `.rating-option[data-type="barber"][data-barber="${barber}"]`;
    }

    const options = document.querySelectorAll(groupSelector);

    // Use requestAnimationFrame for smooth batch update
    requestAnimationFrame(() => {
      options.forEach((opt) => {
        const optValue = parseInt(opt.getAttribute('data-value'));

        // Clear old states
        opt.removeAttribute('data-selected');
        opt.removeAttribute('data-faded');
        opt.classList.remove('active', 'inactive');

        if (optValue === selectedValue) {
          // Selected option
          opt.setAttribute('data-selected', 'true');
        } else {
          // Fade other options
          opt.setAttribute('data-faded', 'true');
        }
      });
    });
  }

  function clearRatingUI(type, barber) {
    let groupSelector;
    if (type === 'service') {
      groupSelector = '.rating-option[data-type="service"]';
    } else if (barber) {
      groupSelector = `.rating-option[data-type="barber"][data-barber="${barber}"]`;
    } else {
      groupSelector = '.rating-option[data-type="barber"]';
    }

    const options = document.querySelectorAll(groupSelector);
    options.forEach((opt) => {
      opt.removeAttribute('data-selected');
      opt.removeAttribute('data-faded');
      opt.classList.remove('active', 'inactive', 'touching', 'ripple');
    });
  }

  // Touch-friendly tip selection system using Event Delegation
  function setupTipOptionsListeners() {
    if (tipDelegationSetup) return;
    tipDelegationSetup = true;

    const container = document.body;

    container.addEventListener(
      'pointerdown',
      (e) => {
        const option = e.target.closest('.tip-option');
        if (option) {
          tipTouchActiveElement = option;
          option.classList.add('touching');
        }
      },
      { passive: true }
    );

    container.addEventListener(
      'pointerup',
      (e) => {
        const option = e.target.closest('.tip-option');
        if (option && tipTouchActiveElement === option) {
          option.classList.remove('touching');

          requestAnimationFrame(() => {
            const value = parseInt(option.getAttribute('data-value'));
            state.tipAmount = value;

            // Clear all tip options - batch update
            document.querySelectorAll('.tip-option').forEach((opt) => {
              opt.classList.remove('bg-blue-500', 'text-white');
              opt.removeAttribute('data-selected');
            });

            // Mark selected
            option.classList.add('bg-blue-500', 'text-white');
            option.setAttribute('data-selected', 'true');

            // Reset custom input
            customTipInput.value = '';

            debouncedUpdateSummary();
            tipTouchActiveElement = null;
          });
        }
      },
      { passive: true }
    );

    container.addEventListener(
      'pointercancel',
      (e) => {
        const option = e.target.closest('.tip-option');
        if (option) {
          option.classList.remove('touching');
          tipTouchActiveElement = null;
        }
      },
      { passive: true }
    );

    container.addEventListener(
      'pointerleave',
      (e) => {
        const option = e.target.closest('.tip-option');
        if (option) {
          option.classList.remove('touching');
          tipTouchActiveElement = null;
        }
      },
      { passive: true, capture: true }
    );
  }

  // Touch-friendly checkbox system using Event Delegation
  function setupCheckboxListeners() {
    if (checkboxDelegationSetup) return;
    checkboxDelegationSetup = true;

    const container = document.body;

    container.addEventListener(
      'pointerdown',
      (e) => {
        const option = e.target.closest('.checkbox-option');
        if (option) {
          checkboxTouchActiveElement = option;
          option.classList.add('touching');
        }
      },
      { passive: true }
    );

    container.addEventListener(
      'pointerup',
      (e) => {
        const option = e.target.closest('.checkbox-option');
        if (option && checkboxTouchActiveElement === option) {
          option.classList.remove('touching');

          const input = option.querySelector('input[type="checkbox"]');
          if (!input) return;

          if (e.target !== input) {
            input.checked = !input.checked;
          }

          requestAnimationFrame(() => {
            const isChecked = input.checked;
            option.setAttribute('data-checked', isChecked ? 'true' : 'false');

            if (isChecked) {
              option.classList.add('touched');
            } else {
              option.classList.remove('touched');
            }

            // Trigger change handler
            const reasonText = input.nextElementSibling?.textContent?.trim() || '';
            const isServiceReason = input.id.startsWith('serviceReason');
            const targetArray = isServiceReason
              ? state.dissatisfactionReasons.service
              : state.dissatisfactionReasons.barbers;

            if (isChecked) {
              if (!targetArray.includes(reasonText)) {
                targetArray.push(reasonText);
              }
            } else {
              const index = targetArray.indexOf(reasonText);
              if (index !== -1) {
                targetArray.splice(index, 1);
              }
            }

            checkboxTouchActiveElement = null;
          });
        }
      },
      { passive: true }
    );

    container.addEventListener(
      'pointercancel',
      (e) => {
        const option = e.target.closest('.checkbox-option');
        if (option) {
          option.classList.remove('touching');
          checkboxTouchActiveElement = null;
        }
      },
      { passive: true }
    );
  }

  async function deleteReviewNotification() {
    try {
      const response = await fetchAPI(`notify-review`, {
        method: 'DELETE',
        body: JSON.stringify({
          invoice_id: state.invoiceId,
        }),
      });

      if (!response.success) {
        console.error('Lỗi khi xóa thông báo đánh giá:', response.message);
        showError(`Lỗi: ${response.message}`);
      } else {
        toastSuccess('Đánh giá đã được xóa: ' + response.message);
      }
    } catch (error) {
      console.error('Lỗi khi gọi API xóa thông báo:', error);
      showError('Lỗi khi xóa thông báo đánh giá');
    }
  }

  function setupEventListeners() {
    submitButton.addEventListener('click', validateAndOpenPaymentModal);
    newFeedbackBtn.addEventListener('click', async () => {
      resetForm();
      checkPendingReview(); // Auto-load invoice tiếp theo từ queue
    });

    resetPromoBtn.addEventListener('click', async () => {
      await deleteReviewNotification();
      resetForm();
      checkPendingReview(); // Auto-load invoice tiếp theo từ queue
    });

    promotionOptions.forEach((option) => {
      option.addEventListener('change', handlePromotionChange);
    });

    // Setup checkbox listeners with pointer events for touch-friendly experience
    setupCheckboxListeners();

    otherServiceReasonInput.addEventListener('input', function () {
      state.otherReason.service = this.value;
    });

    otherBarberReasonInput.addEventListener('input', function () {
      state.otherReason.barbers = this.value;
    });

    // Setup tip options with pointer events for touch-friendly experience
    setupTipOptionsListeners();

    // Custom tip input with debounced update for better performance
    const handleCustomTipInput = debounce(function (value) {
      state.tipAmount = value;

      // Clear selection from preset tip options - batch in rAF
      requestAnimationFrame(() => {
        tipOptions.forEach((opt) => {
          opt.classList.remove('bg-blue-500', 'text-white');
          opt.removeAttribute('data-selected');
        });
      });

      // Update summary section to reflect new tip amount
      debouncedUpdateSummary();
    }, 150);

    customTipInput.addEventListener('input', function () {
      handleCustomTipInput(parseFloat(this.value) || 0);
    });

    closePaymentModal.addEventListener('click', () => {
      paymentMethodModal.classList.add('hidden');
      resetPaymentModalState();
      stopPaymentPolling();
    });
  }

  // Hàm reset và setup lại payment modal để tránh lỗi event listener trùng lặp
  function resetPaymentModalState() {
    // Reset trạng thái button - lấy element động
    const confirmPaymentBtn = document.getElementById('confirmPaymentBtn');
    if (confirmPaymentBtn) {
      confirmPaymentBtn.classList.remove('loading', 'success');
      confirmPaymentBtn.disabled = false;
    }

    // Reset selected state
    document.querySelectorAll('.payment-method-btn').forEach((btn) => {
      btn.classList.remove('selected', 'bg-blue-500', 'text-white');
      btn.classList.add('bg-gray-100', 'text-gray-700');
    });

    // Reset QR section - lấy element động
    const qrPaymentSection = document.getElementById('qrPaymentSection');
    if (qrPaymentSection) {
      qrPaymentSection.classList.add('hidden');
    }

    // Clear QR code container
    const qrCodeContainer = document.getElementById('qrCodeContainer');
    if (qrCodeContainer) {
      qrCodeContainer.innerHTML = '';
    }

    // Reset payment method
    state.paymentMethod = null;
  }

  // Hàm setup payment modal event listeners (được gọi mỗi lần mở modal)
  function setupPaymentModalListeners() {
    // Remove old listeners bằng cách clone và replace các buttons
    const paymentMethodBtns = document.querySelectorAll('.payment-method-btn');
    paymentMethodBtns.forEach((btn) => {
      const newBtn = btn.cloneNode(true);
      btn.parentNode.replaceChild(newBtn, btn);
      newBtn.addEventListener('click', () => selectPaymentMethodHandler(newBtn.dataset.method));
    });

    // Clone và replace confirm button để remove old listeners
    const oldConfirmBtn = document.getElementById('confirmPaymentBtn');
    if (oldConfirmBtn) {
      const newConfirmBtn = oldConfirmBtn.cloneNode(true);
      oldConfirmBtn.parentNode.replaceChild(newConfirmBtn, oldConfirmBtn);

      // Update reference
      Object.defineProperty(window, 'confirmPaymentBtn', {
        value: newConfirmBtn,
        writable: true,
        configurable: true,
      });

      newConfirmBtn.addEventListener('click', async () => {
        // Prevent double-click
        if (newConfirmBtn.disabled) {
          return;
        }

        // Use ButtonLoader for loading state
        if (typeof ButtonLoader !== 'undefined') {
          ButtonLoader.setLoading(newConfirmBtn, 'Đang xử lý...');
        } else {
          newConfirmBtn.disabled = true;
          newConfirmBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Đang xử lý...';
        }

        try {
          await completePayment();

          // Show success state with ButtonLoader
          if (typeof ButtonLoader !== 'undefined') {
            newConfirmBtn.innerHTML = '<i class="fas fa-check"></i> Thành công!';
            newConfirmBtn.classList.add('success');
          } else {
            newConfirmBtn.innerHTML = '<i class="fas fa-check"></i> Thành công!';
          }

          await new Promise((resolve) => setTimeout(resolve, 1000));

          // Reset state after success
          if (typeof ButtonLoader !== 'undefined') {
            ButtonLoader.reset(newConfirmBtn);
          }
          newConfirmBtn.classList.remove('success');
          resetPaymentModalState();
        } catch (error) {
          console.error('Payment error:', error);
          // Reset loading state on error
          if (typeof ButtonLoader !== 'undefined') {
            ButtonLoader.reset(newConfirmBtn);
          } else {
            newConfirmBtn.disabled = false;
            newConfirmBtn.innerHTML = 'Xác nhận thanh toán';
          }
        }
      });
    }
  }

  function setupScrollReveal() {
    // Simplified: Show all sections immediately without scroll animation
    // This improves performance on touch screen devices
    const sections = document.querySelectorAll('.scroll-reveal, .section');
    sections.forEach((section) => {
      section.classList.add('revealed');
    });
  }

  // Legacy handlers removed - using new pointer event system

  // Legacy handleRatingClick removed - using new pointer event system in attachRatingEventListeners

  function handlePromotionChange() {
    if (this.id === 'promo1') {
      state.promotion = 'Khách Hàng Mới';
      state.promotionAmount = state.servicePrice * 0.1;
    } else if (this.id === 'promo2') {
      state.promotion = 'Khách Hàng Thân Thiết';
      state.promotionAmount = 20000;
    } else {
      state.promotion = null;
      state.promotionAmount = 0;
    }

    document.querySelectorAll('.checkbox-option').forEach((opt) => {
      opt.classList.remove('bg-blue-100');
    });
    this.closest('.checkbox-option').classList.add('bg-blue-100');

    updateSummarySection();
  }

  // handleCheckboxChange removed - logic integrated into setupCheckboxListeners

  function handleTipClick() {
    const value = parseInt(this.getAttribute('data-value'));
    state.tipAmount = value;

    // Clear all tip options using both old classes and new data attributes
    tipOptions.forEach((opt) => {
      opt.classList.remove('bg-blue-500', 'text-white');
      opt.removeAttribute('data-selected');
    });

    // Mark selected tip option
    this.classList.add('bg-blue-500', 'text-white');
    this.setAttribute('data-selected', 'true');

    // Reset custom tip input
    customTipInput.value = '';

    // Update summary
    updateSummarySection();
  }

  function updateConditionalSections() {
    const lowServiceRating = state.ratings.service <= 3 && state.ratings.service !== null;
    const lowBarberRating = Object.values(state.ratings.barbers).some((rating) => rating <= 3);
    const highRating =
      state.ratings.service > 3 ||
      Object.values(state.ratings.barbers).some((rating) => rating > 3);
    const allBarberRatings = Object.values(state.ratings.barbers);
    const allBarbersHigh =
      allBarberRatings.length > 0 && allBarberRatings.every((rating) => rating > 3);
    const allBarbersLow =
      allBarberRatings.length > 0 && allBarberRatings.every((rating) => rating <= 3);

    section4.classList.add('hidden');

    const serviceDissatisfactionDiv = document.getElementById('serviceDissatisfaction');
    const barberDissatisfactionDiv = document.getElementById('barberDissatisfaction');

    if (lowServiceRating && allBarbersHigh) {
      section4.classList.remove('hidden');
      serviceDissatisfactionDiv.style.display = 'block';
      barberDissatisfactionDiv.style.display = 'none';
    } else if (allBarbersLow && state.ratings.service > 3) {
      section4.classList.remove('hidden');
      serviceDissatisfactionDiv.style.display = 'none';
      barberDissatisfactionDiv.style.display = 'block';
    } else if (lowServiceRating || lowBarberRating) {
      section4.classList.remove('hidden');
      serviceDissatisfactionDiv.style.display = 'block';
      barberDissatisfactionDiv.style.display = 'block';
    } else {
      section4.classList.add('hidden');
      serviceDissatisfactionDiv.style.display = 'block';
      barberDissatisfactionDiv.style.display = 'block';
    }

    if (highRating) {
      document.getElementById('section5').classList.remove('hidden');
      state.showTipStep = true;
    } else {
      document.getElementById('section5').classList.add('hidden');
      state.showTipStep = false;
    }
  }

  // Debounced version for frequent calls (e.g., during input)
  const debouncedUpdateSummary = debounce(_updateSummarySection, 50);

  function _updateSummarySection() {
    // Batch DOM updates using requestAnimationFrame
    requestAnimationFrame(() => {
      // Hiển thị giá dịch vụ
      servicePriceDisplay.textContent = formatCurrency(state.servicePrice);

      // Hiển thị khuyến mãi
      promotionDisplay.textContent =
        state.promotionAmount > 0 ? `-${formatCurrency(state.promotionAmount)}` : '0 VNĐ';

      // Hiển thị tip nếu showTipStep được bật
      if (state.showTipStep) {
        tipDisplay.textContent = formatCurrency(state.tipAmount);
        tipSummaryRow.style.display = 'flex';
      } else {
        tipSummaryRow.style.display = 'none';
      }

      // Tính tổng tiền: giá dịch vụ - khuyến mãi + tip
      const total = state.servicePrice - (state.promotionAmount || 0) + state.tipAmount;
      totalDisplay.textContent = formatCurrency(total);
    });
  }

  // Immediate update for critical actions
  function updateSummarySection() {
    _updateSummarySection();
  }

  // ==============================
  // Combined Payment Helper Functions
  // ==============================
  function showCombinedPaymentSection(totalAmount) {
    const combinedSection = document.getElementById('combinedPaymentSection');
    const combinedTotalAmount = document.getElementById('combinedTotalAmount');
    const combinedCashAmount = document.getElementById('combinedCashAmount');
    const combinedBankAmount = document.getElementById('combinedBankAmount');

    if (!combinedSection) return;

    // Reset inputs
    if (combinedCashAmount) combinedCashAmount.value = '';
    if (combinedBankAmount) combinedBankAmount.value = '';

    // Hiển thị tổng tiền cần thanh toán
    if (combinedTotalAmount) {
      combinedTotalAmount.textContent = formatCurrency(totalAmount);
    }

    // Hiển thị section
    combinedSection.classList.remove('hidden');

    // Thiết lập event listeners cho inputs
    setupCombinedPaymentListeners(totalAmount);

    // Cập nhật summary ban đầu
    updateCombinedPaymentSummary(totalAmount);
  }

  function hideCombinedPaymentSection() {
    const combinedSection = document.getElementById('combinedPaymentSection');
    if (combinedSection) {
      combinedSection.classList.add('hidden');
    }
  }

  function setupCombinedPaymentListeners(totalAmount) {
    const combinedCashAmount = document.getElementById('combinedCashAmount');
    const combinedBankAmount = document.getElementById('combinedBankAmount');

    const updateHandler = () => updateCombinedPaymentSummary(totalAmount);

    if (combinedCashAmount) {
      // Remove old listeners by cloning
      const newCashInput = combinedCashAmount.cloneNode(true);
      combinedCashAmount.replaceWith(newCashInput);
      newCashInput.addEventListener('input', updateHandler);
    }

    if (combinedBankAmount) {
      // Remove old listeners by cloning
      const newBankInput = combinedBankAmount.cloneNode(true);
      combinedBankAmount.replaceWith(newBankInput);
      newBankInput.addEventListener('input', updateHandler);
    }
  }

  function updateCombinedPaymentSummary(totalAmount) {
    const combinedCashAmount = document.getElementById('combinedCashAmount');
    const combinedBankAmount = document.getElementById('combinedBankAmount');
    const combinedEnteredTotal = document.getElementById('combinedEnteredTotal');
    const combinedRemainingAmount = document.getElementById('combinedRemainingAmount');
    const combinedPaymentError = document.getElementById('combinedPaymentError');
    const remainingRow = document.querySelector('.combined-remaining');

    const cashValue = parseFloat(combinedCashAmount?.value) || 0;
    const bankValue = parseFloat(combinedBankAmount?.value) || 0;
    const enteredTotal = cashValue + bankValue;
    const remaining = totalAmount - enteredTotal;

    if (combinedEnteredTotal) {
      combinedEnteredTotal.textContent = formatCurrency(enteredTotal);
    }

    if (combinedRemainingAmount) {
      combinedRemainingAmount.textContent = formatCurrency(Math.abs(remaining));
      if (remaining === 0) {
        combinedRemainingAmount.parentElement.querySelector('span').textContent = 'Hoàn tất:';
      } else if (remaining > 0) {
        combinedRemainingAmount.parentElement.querySelector('span').textContent = 'Còn thiếu:';
      } else {
        combinedRemainingAmount.parentElement.querySelector('span').textContent = 'Thừa:';
      }
    }

    if (remainingRow) {
      remainingRow.classList.toggle('valid', remaining === 0);
    }

    if (combinedPaymentError) {
      combinedPaymentError.classList.toggle('hidden', remaining === 0);
    }
  }

  function validateCombinedPayment(totalAmount) {
    const combinedCashAmount = document.getElementById('combinedCashAmount');
    const combinedBankAmount = document.getElementById('combinedBankAmount');

    const cashValue = parseFloat(combinedCashAmount?.value) || 0;
    const bankValue = parseFloat(combinedBankAmount?.value) || 0;
    const enteredTotal = cashValue + bankValue;

    if (enteredTotal !== totalAmount) {
      return {
        valid: false,
        message: `Tổng số tiền nhập (${formatCurrency(
          enteredTotal
        )}) phải bằng tổng cần thanh toán (${formatCurrency(totalAmount)})`,
      };
    }

    if (cashValue <= 0 && bankValue <= 0) {
      return {
        valid: false,
        message: 'Vui lòng nhập ít nhất một phương thức thanh toán',
      };
    }

    return {
      valid: true,
      details: {
        cash: cashValue,
        bank: bankValue,
      },
    };
  }

  function validateAndOpenPaymentModal() {
    if (!state.ratings.service) {
      showWarning('Vui lòng đánh giá dịch vụ trước khi thanh toán');
      document.getElementById('section2').scrollIntoView({ behavior: 'smooth' });
      return;
    }

    const missingRatings = state.barbers.filter((barber) => !state.ratings.barbers[barber]);
    if (missingRatings.length > 0) {
      showWarning(`Vui lòng đánh giá tất cả thợ cắt: ${missingRatings.join(', ')}`);
      document.getElementById('section3').scrollIntoView({ behavior: 'smooth' });
      return;
    }

    state.totalAmount = state.servicePrice - state.promotionAmount + state.tipAmount;
    if (state.totalAmount < 0) {
      showWarning('Tổng số tiền không hợp lệ');
      return;
    }

    // Reset state trước khi mở modal
    resetPaymentModalState();

    // Mở modal
    paymentMethodModal.classList.remove('hidden');
    hideCombinedPaymentSection(); // Ẩn phần combined payment

    // Lấy danh sách phương thức thanh toán đã bật (chỉ QR-based)
    const enabledMethods = checkinData.paymentQRs ? Object.keys(checkinData.paymentQRs) : [];


    // Ẩn/hiện các nút phương thức thanh toán
    document.querySelectorAll('.payment-method-btn').forEach((btn) => {
      const method = btn.dataset.method;
      // combined luôn hiển thị cùng với cash
      const isEnabled =
        method === 'cash' || method === 'combined' || enabledMethods.includes(method);

      if (!isEnabled) {
        btn.style.display = 'none';
        return;
      }

      btn.style.display = ''; // Hiển thị lại nếu trước đó bị ẩn
      btn.classList.remove('bg-blue-500', 'text-white', 'selected');
      btn.classList.add('bg-gray-100', 'text-gray-700');
    });

    // Setup lại event listeners
    setupPaymentModalListeners();

    // Ẩn section QR và nút xác nhận ban đầu
    const qrPaymentSection = document.getElementById('qrPaymentSection');
    const confirmPaymentBtn = document.getElementById('confirmPaymentBtn');

    if (qrPaymentSection) {
      qrPaymentSection.classList.add('hidden');
    }
    if (confirmPaymentBtn) {
      confirmPaymentBtn.classList.add('hidden');
    }
  }

  // ==============================
  // Bank Transfer Info Helpers (QR động)
  // ==============================
  function showBankTransferInfo(addInfo) {
    const infoSection = document.getElementById('bankTransferInfo');
    const transferContent = document.getElementById('transferContent');
    const copyBtn = document.getElementById('copyTransferContent');
    const copyMsg = document.getElementById('copySuccessMsg');

    if (!infoSection || !transferContent) return;

    transferContent.textContent = addInfo;
    infoSection.classList.remove('hidden');

    // Setup copy button
    if (copyBtn) {
      const newCopyBtn = copyBtn.cloneNode(true);
      copyBtn.replaceWith(newCopyBtn);
      newCopyBtn.addEventListener('click', async () => {
        try {
          await navigator.clipboard.writeText(addInfo);
          if (copyMsg) {
            copyMsg.classList.remove('hidden');
            setTimeout(() => copyMsg.classList.add('hidden'), 2000);
          }
        } catch {
          // Fallback for older browsers
          const textArea = document.createElement('textarea');
          textArea.value = addInfo;
          textArea.style.position = 'fixed';
          textArea.style.opacity = '0';
          document.body.appendChild(textArea);
          textArea.select();
          document.execCommand('copy');
          document.body.removeChild(textArea);
          if (copyMsg) {
            copyMsg.classList.remove('hidden');
            setTimeout(() => copyMsg.classList.add('hidden'), 2000);
          }
        }
      });
    }
  }

  function hideBankTransferInfo() {
    const infoSection = document.getElementById('bankTransferInfo');
    if (infoSection) {
      infoSection.classList.add('hidden');
    }
  }

  // ==============================
  // Payment Note Generator
  // ==============================
  function generatePaymentNote(bankData, invoiceId) {
    const prefix = bankData?.note_prefix || 'MKT';
    const syntax = bankData?.note_syntax || '{invoice_id}';

    // Generate random string of length N for {random:N} placeholder
    const randomChars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    function makeRandom(len) {
      let result = '';
      for (let i = 0; i < len; i++) {
        result += randomChars.charAt(Math.floor(Math.random() * randomChars.length));
      }
      return result;
    }

    let note = syntax;
    // Replace {prefix} with the configured prefix
    note = note.replace(/\{prefix\}/gi, prefix);
    // Replace {random:N} with random alphanumeric of length N
    note = note.replace(/\{random:(\d+)\}/gi, (_, len) => makeRandom(parseInt(len, 10)));
    // Replace {invoice_id} with actual invoice ID
    note = note.replace(/\{invoice_id\}/gi, invoiceId || '');
    // Replace {date} with YYYYMMDD
    const now = new Date();
    const dateStr = now.getFullYear().toString()
      + String(now.getMonth() + 1).padStart(2, '0')
      + String(now.getDate()).padStart(2, '0');
    note = note.replace(/\{date\}/gi, dateStr);
    // Replace {timestamp} with unix timestamp
    note = note.replace(/\{timestamp\}/gi, Math.floor(now.getTime() / 1000).toString());

    // Only prepend prefix if syntax doesn't contain {prefix} placeholder
    if (!/\{prefix\}/i.test(syntax)) {
      note = prefix + note;
    }

    return note.toUpperCase();
  }

  // ==============================
  // Payment Polling (auto-confirm)
  // ==============================
  let paymentPollingTimer = null;
  let paymentPollingInvoiceId = null;

  function startPaymentPolling(invoiceId) {
    stopPaymentPolling();
    paymentPollingInvoiceId = invoiceId;

    const pollingSection = document.getElementById('paymentPollingSection');
    const intervalLabel = document.getElementById('pollingIntervalLabel');
    const statusText = document.getElementById('pollingStatusText');
    const pollingIcon = document.getElementById('pollingIcon');

    if (!pollingSection) return;
    pollingSection.classList.remove('hidden');

    // Get interval from admin settings (seconds)
    const bankData = checkinData?.paymentQRs?.bank;
    const intervalSec = bankData?.polling_interval || 5;
    const intervalMs = intervalSec * 1000;

    // Display human-readable interval
    if (intervalLabel) {
      if (intervalSec >= 60) {
        intervalLabel.textContent = `${intervalSec / 60} phút`;
      } else {
        intervalLabel.textContent = `${intervalSec} giây`;
      }
    }

    if (statusText) statusText.textContent = 'Đang chờ thanh toán...';
    if (pollingIcon) {
      pollingIcon.className = 'fas fa-spinner fa-spin';
      pollingIcon.style.color = '';
    }

    const pollOnce = async () => {
      if (!paymentPollingInvoiceId) return;
      try {
        const res = await fetch(`${checkinData.restUrl}mbbank-check-payment`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-WP-Nonce': checkinData.nonce,
          },
          body: JSON.stringify({ invoice_id: paymentPollingInvoiceId }),
        });
        const data = await res.json();

        if (data.success && !data.data?.already_paid) {
          onPaymentConfirmed(invoiceId);
          return;
        }
        if (data.data?.already_paid) {
          onPaymentConfirmed(invoiceId);
          return;
        }
        if (statusText) {
          statusText.textContent = 'Đang chờ thanh toán...';
        }
      } catch (err) {
        console.error('Payment polling error:', err);
        if (statusText) statusText.textContent = 'Lỗi kiểm tra, thử lại...';
      }
      paymentPollingTimer = setTimeout(pollOnce, intervalMs);
    };

    paymentPollingTimer = setTimeout(pollOnce, intervalMs);
  }

  function stopPaymentPolling() {
    if (paymentPollingTimer) {
      clearTimeout(paymentPollingTimer);
      paymentPollingTimer = null;
    }
    paymentPollingInvoiceId = null;
    hidePaymentPolling();
  }

  function hidePaymentPolling() {
    const pollingSection = document.getElementById('paymentPollingSection');
    if (pollingSection) pollingSection.classList.add('hidden');
  }

  /**
   * Phát âm thanh "ting-ting" khi thanh toán thành công
   * Sử dụng Web Audio API — không cần file âm thanh, hoạt động offline (PWA)
   */
  function playPaymentSuccessSound() {
    try {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if (!AudioContext) return;

      const ctx = new AudioContext();

      // Tạo âm thanh "ting" — 2 nốt liên tiếp giống tiếng xu rơi
      const playTing = (frequency, startTime, duration) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.type = 'sine';
        osc.frequency.setValueAtTime(frequency, startTime);

        // Envelope: attack nhanh, decay dần → tiếng "ting" trong trẻo
        gain.gain.setValueAtTime(0, startTime);
        gain.gain.linearRampToValueAtTime(0.3, startTime + 0.01);
        gain.gain.exponentialRampToValueAtTime(0.001, startTime + duration);

        osc.start(startTime);
        osc.stop(startTime + duration);
      };

      const now = ctx.currentTime;

      // Ting 1: C6 (1047 Hz) — nốt dài, vang
      playTing(1047, now, 0.9);
      // Ting 2: G6 (1568 Hz) — nốt cao (sau 0.3s)
      playTing(1568, now + 0.3, 0.6);
      // Ting 3: E6 (1319 Hz) — kết thúc (sau 0.55s)
      playTing(1319, now + 0.55, 0.4);

      // Cleanup sau khi âm thanh kết thúc
      setTimeout(() => ctx.close(), 20000);
    } catch (e) {
      // Không crash nếu audio không khả dụng
    }
  }

  function onPaymentConfirmed(invoiceId) {
    stopPaymentPolling();

    // Ẩn QR, bank info, polling section, total
    const qrCodeContainer = document.getElementById('qrCodeContainer');
    const bankTransferInfo = document.getElementById('bankTransferInfo');
    const pollingSection = document.getElementById('paymentPollingSection');
    const qrLabel = document.querySelector('.qr-payment-label');
    const qrTotal = document.querySelector('.qr-payment-total');

    if (qrCodeContainer) qrCodeContainer.classList.add('hidden');
    if (bankTransferInfo) bankTransferInfo.classList.add('hidden');
    if (pollingSection) pollingSection.classList.add('hidden');
    if (qrLabel) qrLabel.classList.add('hidden');
    if (qrTotal) qrTotal.classList.add('hidden');
    if (confirmPaymentBtn) confirmPaymentBtn.classList.add('hidden');

    // Phát âm thanh thành công
    playPaymentSuccessSound();

    // Tạo hiệu ứng thành công lớn thay thế QR
    if (qrPaymentSection) {
      qrPaymentSection.classList.remove('hidden');
      const successEl = document.createElement('div');
      successEl.className = 'payment-success-animation';
      successEl.innerHTML = `
        <div class="success-checkmark-wrapper">
          <svg class="success-checkmark" viewBox="0 0 100 100">
            <circle class="success-circle" cx="50" cy="50" r="45" />
            <polyline class="success-check" points="30,52 45,66 72,36" />
          </svg>
        </div>
        <p class="success-text">Thanh toán thành công!</p>
        <p class="success-subtext">Hóa đơn đã được xác nhận tự động</p>
      `;
      qrPaymentSection.appendChild(successEl);
    }

    // Sau 4s animation → gọi completePayment (đã xử lý đóng modal)
    setTimeout(async () => {
      try {
        await completePayment();
      } catch (err) {
        console.error('Auto complete payment error:', err);
      }
    }, 4000);
  }

  async function selectPaymentMethodHandler(method) {
    state.paymentMethod = method;

    document.querySelectorAll('.payment-method-btn').forEach((btn) => {
      const isSelected = btn.dataset.method === method;
      btn.classList.toggle('selected', isSelected);
    });

    const qrCodeContainer = document.getElementById('qrCodeContainer');
    if (!qrCodeContainer) {
      console.error('QR code container not found');
      showError('Không tìm thấy container QR');
      return;
    }

    const qrPaymentSection = document.getElementById('qrPaymentSection');
    const qrPaymentAmount = document.getElementById('qrPaymentAmount');
    const confirmPaymentBtn = document.getElementById('confirmPaymentBtn');

    if (!confirmPaymentBtn) {
      console.error('confirmPaymentBtn not found');
      return;
    }

    const totalFormatted = formatCurrency(state.totalAmount);
    const showQRCode = (src) => {
      qrPaymentAmount.textContent = totalFormatted;
      qrPaymentSection.classList.remove('hidden');
      qrCodeContainer.innerHTML = `<img src="${src}" alt="${method} QR Code" style="max-width: 100%; height: auto;">`;
    };

    if (method === 'cash') {
      qrPaymentSection.classList.add('hidden');
      hideCombinedPaymentSection();
      hideBankTransferInfo();
      stopPaymentPolling();
    } else if (method === 'bank') {
      hideCombinedPaymentSection();
      const bankData = checkinData.paymentQRs?.bank;
      if (bankData?.account_number && bankData?.bank_bin) {
        if (bankData.is_monkeypay) {
          // MonkeyPay mode (both auto & manual): call API to create/poll TX
          try {
            const res = await fetch(`${checkinData.restUrl}mbbank-check-payment`, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'X-WP-Nonce': checkinData.nonce,
              },
              body: JSON.stringify({ invoice_id: state.invoiceId }),
            });
            const data = await res.json();
            const mpNote = data.data?.payment_note || '';
            const addInfo = mpNote || generatePaymentNote(bankData, state.invoiceId);

            // Build VietQR URL
            let vietQRUrl = `https://img.vietqr.io/image/${bankData.bank_bin}-${bankData.account_number}-compact2.png`
              + `?addInfo=${encodeURIComponent(addInfo)}`
              + `&accountName=${encodeURIComponent(bankData.account_name || '')}`;

            // Auto mode: include amount in QR; Manual mode: no amount (customer enters freely)
            if (bankData.auto_amount) {
              vietQRUrl += `&amount=${Math.round(state.totalAmount)}`;
            }

            showQRCode(vietQRUrl);
            showBankTransferInfo(addInfo);
          } catch (err) {
            console.error('MonkeyPay init error:', err);
            // Fallback: generate local payment note
            const addInfo = generatePaymentNote(bankData, state.invoiceId);
            let vietQRUrl = `https://img.vietqr.io/image/${bankData.bank_bin}-${bankData.account_number}-compact2.png`
              + `?addInfo=${encodeURIComponent(addInfo)}`
              + `&accountName=${encodeURIComponent(bankData.account_name || '')}`;
            if (bankData.auto_amount) {
              vietQRUrl += `&amount=${Math.round(state.totalAmount)}`;
            }
            showQRCode(vietQRUrl);
            showBankTransferInfo(addInfo);
          }
          // Always poll in MonkeyPay mode (both auto & manual)
          startPaymentPolling(state.invoiceId);
        } else {
          // Legacy mode: generate local payment note, no polling
          const addInfo = generatePaymentNote(bankData, state.invoiceId);
          const vietQRUrl = `https://img.vietqr.io/image/${bankData.bank_bin}-${bankData.account_number}-compact2.png`
            + `?amount=${Math.round(state.totalAmount)}&addInfo=${encodeURIComponent(addInfo)}`
            + `&accountName=${encodeURIComponent(bankData.account_name || '')}`;
          showQRCode(vietQRUrl);
          showBankTransferInfo(addInfo);
          hidePaymentPolling();
        }
      } else {
        const defaultUrl = 'https://vangroupbarbershop.store/wp-content/uploads/2025/05/Untitled.png';
        const qrUrl = getCachedImageUrl('bank', getPaymentQRUrl('bank', defaultUrl));
        showQRCode(qrUrl);
        hideBankTransferInfo();
        stopPaymentPolling();
      }
    } else if (method === 'momo') {
      hideCombinedPaymentSection();
      hideBankTransferInfo();
      stopPaymentPolling();
      const defaultUrl =
        'https://vangroupbarbershop.store/wp-content/uploads/2025/05/MOMO-NGOC-QUYNH.png';
      const qrUrl = getCachedImageUrl('momo', getPaymentQRUrl('momo', defaultUrl));
      showQRCode(qrUrl);
    } else if (method === 'zalopay') {
      hideCombinedPaymentSection();
      hideBankTransferInfo();
      stopPaymentPolling();
      const defaultUrl =
        'https://vangroupbarbershop.store/wp-content/uploads/2025/05/ZALOPAY-DEFAULT.png';
      const qrUrl = getCachedImageUrl('zalopay', getPaymentQRUrl('zalopay', defaultUrl));
      showQRCode(qrUrl);
    } else if (method === 'combined') {
      qrPaymentSection.classList.add('hidden');
      hideBankTransferInfo();
      stopPaymentPolling();
      showCombinedPaymentSection(state.totalAmount);
    }

    // Show confirm button
    confirmPaymentBtn.classList.remove('hidden');

    // Show toast message
    toastSuccess('Đã chọn phương thức thanh toán');
  }

  async function completePayment() {
    // Validate combined payment nếu cần
    if (state.paymentMethod === 'combined') {
      const validation = validateCombinedPayment(state.totalAmount);
      if (!validation.valid) {
        showError(validation.message);
        return;
      }
      state.combinedPaymentDetails = validation.details;
    }

    try {
      const updateData = {
        payment_method: state.paymentMethod,
        status: 'paid',
        cashier: cashier,
        tips: state.tipAmount,
        total: state.totalAmount,
        promo_code: state.promoCode || null,
        promo_name: state.promotion || null,
        discount: state.promotionAmount,
        booking_id: state.bookingId,
        customer_id: state.customerId,
        services: state.services,
      };

      // Thêm chi tiết thanh toán kết hợp nếu có
      if (state.paymentMethod === 'combined' && state.combinedPaymentDetails) {
        updateData.combined_payment_details = state.combinedPaymentDetails;
      }

      const result = await fetchAPI(`invoices/${state.invoiceId}/payment-for-page-review`, {
        method: 'PUT',
        body: JSON.stringify(updateData),
      });

      if (!result.success) {
        throw new Error(result.message);
      }

      state.isPaid = true;
      toastSuccess('Thanh toán thành công');
    } catch (error) {
      console.error('Lỗi khi cập nhật hóa đơn:', error);
      toastError('Lỗi khi cập nhật hóa đơn: ' + error.message);
      return;
    }

    // Gửi tin nhắn Zalo nếu không phải khách vãng lai
    if (state.isPaid && state.customerName !== 'KHÁCH VÃNG LAI') {
      try {
        const zaloResponse = await fetchAPI('send-invoice-message-type-zalo', {
          method: 'POST',
          body: JSON.stringify({
            invoice_id: state.invoiceId,
          }),
        });

        if (!zaloResponse.success) {
          console.warn('Zalo không gửi được:', zaloResponse.message);
          toastWarning('Không gửi được hóa đơn qua Zalo');
        }
      } catch (zaloError) {
        console.error('Lỗi gọi API Zalo:', zaloError);
        toastWarning('Gặp sự cố khi gửi Zalo');
      }
    }

    paymentMethodModal.classList.add('hidden');
    await submitForm();
    state.paymentMethod = null;
  }

  async function submitForm() {
    try {
      const serviceFeedback =
        state.dissatisfactionReasons.service.length > 0
          ? `Dịch vụ: ${state.dissatisfactionReasons.service.join(', ')}${
              state.otherReason.service ? '; ' + state.otherReason.service : ''
            }`
          : state.otherReason.service
            ? `Dịch vụ: ${state.otherReason.service}`
            : '';

      const barberFeedback =
        state.dissatisfactionReasons.barbers.length > 0
          ? `Thợ: ${state.dissatisfactionReasons.barbers.join(', ')}${
              state.otherReason.barbers ? '; ' + state.otherReason.barbers : ''
            }`
          : state.otherReason.barbers
            ? `Thợ: ${state.otherReason.barbers}`
            : '';

      const feedback = [serviceFeedback, barberFeedback].filter(Boolean).join(' | ');

      const mode = 'offline';
      const endpoint = mode === 'offline' ? 'save-reviews?mode=offline' : 'save-reviews';

      const reviewPromises = state.barbers.map(async (barber) => {
        const reviewData = {
          invoice_id: state.invoiceId,
          customer_id: state.customerId,
          customer_name: state.customerName,
          customer_phone: state.customerPhone,
          service_rating: state.ratings.service,
          staff_rating: state.ratings.barbers[barber],
          feedback: feedback || null,
          staff_name: barber,
        };



        try {
          const response = await fetchAPI(endpoint, {
            method: 'POST',
            body: JSON.stringify(reviewData),
          });

          return { success: true, data: response };
        } catch (error) {
          console.error(`Error submitting review for ${barber}:`, error);
          return { success: false, message: error.message, barber };
        }
      });

      const results = await Promise.all(reviewPromises);
      const errors = results.filter((r) => !r.success);

      if (errors.length > 0) {
        const errorMessages = errors.map((err) => `Thợ ${err.barber}: ${err.message}`).join('; ');
        console.warn(`Một số đánh giá không lưu được: ${errorMessages}`);

        if (results.some((r) => r.success)) {
          toastWarning('Một số đánh giá không lưu được. Vui lòng kiểm tra lại.');
        } else {
          throw new Error(`Không lưu được đánh giá nào: ${errorMessages}`);
        }
      }

      // Chuyển sang bước cuối
      document.querySelectorAll('.section:not(#section7)').forEach((section) => {
        section.classList.add('hidden');
      });
      document.getElementById('section7').classList.remove('hidden');
      document.getElementById('section7').classList.add('revealed');
      state.currentStep = 7;
      progressFill.style.width = '100%';

      displayTransactionDetails();
      window.scrollTo({ top: 0, behavior: 'smooth' });

      toastSuccess('Đánh giá đã được gửi thành công');
    } catch (error) {
      console.error('Lỗi khi gửi đánh giá:', error);
      toastError('Lỗi khi gửi đánh giá: ' + error.message);
    }
  }

  function displayTransactionDetails() {
    const total = state.servicePrice - state.promotionAmount + state.tipAmount;
    finalAmountDisplay.textContent = formatCurrency(total);
    transactionIdDisplay.textContent = state.invoiceId;

    serviceRatingDisplay.textContent = getRatingText(state.ratings.service);

    serviceStarsDisplay.innerHTML = '';
    for (let i = 0; i < 5; i++) {
      const star = document.createElement('i');
      star.className = `fas ${
        i < state.ratings.service ? 'fa-star text-yellow-400' : 'fa-star text-gray-300'
      } mx-1`;
      serviceStarsDisplay.appendChild(star);
    }

    barberRatingsDisplay.innerHTML = '';
    state.barbers.forEach((barber) => {
      const div = document.createElement('div');
      div.className = 'flex justify-between items-center mb-3';
      div.innerHTML = `
                Thợ ${barber}:
                <div>
                    <span class="font-semibold text-blue-800 mr-3">
                        ${getRatingText(state.ratings.barbers[barber])}
                    </span>
                    <span>
                        ${Array(5)
                          .fill()
                          .map(
                            (_, i) => `
                            <i class="fas ${
                              i < state.ratings.barbers[barber]
                                ? 'fa-star text-yellow-400'
                                : 'fa-star text-gray-300'
                            } mx-1"></i>
                        `
                          )
                          .join('')}
                    </span>
                </div>
            `;
      barberRatingsDisplay.appendChild(div);
    });
  }

  function getRatingText(rating) {
    switch (rating) {
      case 1:
        return 'Rất Tệ';
      case 2:
        return 'Chê Nha';
      case 3:
        return 'Không Ưng Lắm';
      case 4:
        return 'Hài Lòng';
      case 5:
        return 'Siêu Hài Lòng';
      default:
        return '';
    }
  }

  function setCurrentDate() {
    const currentDate = new Date();
    state.transactionDate = currentDate.toLocaleString('vi-VN', {
      hour: '2-digit',
      minute: '2-digit',
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
    });
    document.getElementById('transactionDate').textContent = state.transactionDate;
    document.getElementById('transactionDateFinal').textContent = state.transactionDate;
  }

  function resetForm() {
    state.invoiceId = null;
    state.customerId = null;
    state.customerName = '';
    state.customerPhone = '';
    state.membershipLabel = '';
    state.promoCode = '';
    state.promoName = null;
    state.promoStatus = null;
    state.ctkmList = [];
    state.services = [];
    state.barbers = [];
    state.servicePrice = 0;
    state.transactionDate = '';
    state.currentStep = 0;
    state.promotion = null;
    state.promotionAmount = 0;
    state.ratings = {
      service: null,
      barbers: {},
    };
    state.dissatisfactionReasons = {
      service: [],
      barbers: [],
    };
    state.otherReason = {
      service: '',
      barbers: '',
    };
    state.tipAmount = 0;
    state.showTipStep = true;
    state.totalSteps = 7;
    state.paymentMethod = null;
    state.totalAmount = 0;
    state.isPaid = false;

    document.querySelectorAll('.section').forEach((section) => {
      section.classList.remove('hidden');
      section.classList.remove('revealed');
    });
    document.getElementById('section7').classList.add('hidden');
    if (state.isPaid) {
      document.getElementById('section6').classList.add('hidden');
    }

    // Reset rating options using new data attribute system
    document.querySelectorAll('.rating-option').forEach((option) => {
      option.removeAttribute('data-selected');
      option.removeAttribute('data-faded');
      option.classList.remove('active', 'inactive', 'touching', 'ripple');
    });

    // Đặt lại trạng thái giao diện của các nút phương thức thanh toán
    document.querySelectorAll('.payment-method-btn').forEach((btn) => {
      btn.classList.remove('bg-blue-500', 'text-white');
      btn.classList.add('bg-gray-100', 'text-gray-700');
    });

    document.querySelectorAll('.checkbox-option').forEach((option) => {
      option.classList.remove('bg-blue-100', 'touched', 'touching');
      option.removeAttribute('data-checked');
    });

    // Reset promo card selection states
    document.querySelectorAll('.promo-checkbox-option').forEach((option) => {
      option.classList.remove('touched', 'touching');
    });

    document.querySelectorAll('.tip-option').forEach((option) => {
      option.classList.remove('bg-blue-500', 'text-white', 'touching');
      option.removeAttribute('data-selected');
    });

    document.querySelectorAll('input[type="checkbox"]').forEach((checkbox) => {
      checkbox.checked = false;
    });

    document.querySelectorAll('input[type="radio"]').forEach((radio) => {
      radio.checked = false;
    });

    customTipInput.value = '';
    otherServiceReasonInput.value = '';
    otherBarberReasonInput.value = '';

    customerNameDisplay.textContent = 'Đang tải...';
    customerPhoneDisplay.textContent = 'Đang tải...';
    totalDisplay.textContent = 'Đang tải...';
    summaryServiceName.textContent = '';
    summaryBarberName.textContent = '';
    servicePriceDisplay.textContent = '';
    document.getElementById('invoiceId').textContent = 'Đang tải...';
    document.getElementById('transactionDate').textContent = 'Đang tải...';
    document.getElementById('transactionDateFinal').textContent = 'Đang tải...';
    document.getElementById('membershipLabel').textContent = '';
    document.getElementById('promoCode').textContent = '';

    // Reset promo status element
    const promoStatusElement = document.getElementById('promoStatus');
    if (promoStatusElement) {
      promoStatusElement.textContent = '';
      promoStatusElement.classList.remove(
        'status-active',
        'status-expired',
        'status-invalid',
        'status-none'
      );
      promoStatusElement.classList.add('hidden');
    }

    // Reset promotion display in summary
    promotionDisplay.textContent = formatCurrency(0);

    // Reset promo options container - xóa các card CTKM cũ
    const promoOptionsContainer = document.getElementById('promoOptions');
    if (promoOptionsContainer) {
      promoOptionsContainer.innerHTML = '';
    }

    barberRatingsContainer.innerHTML = '';
    barberRatingsDisplay.innerHTML = '';
    serviceRatingDisplay.innerHTML = '';
    tipDisplay.textContent = formatCurrency(state.tipAmount);
    tipSummaryRow.style.display = 'none';

    // Reset modal elements - lấy động
    const qrPaymentSection = document.getElementById('qrPaymentSection');
    const qrCodeContainer = document.getElementById('qrCodeContainer');
    const confirmPaymentBtn = document.getElementById('confirmPaymentBtn');

    if (qrPaymentSection) {
      qrPaymentSection.classList.add('hidden');
      // Xóa success animation từ lần thanh toán trước (nếu có)
      const prevSuccess = qrPaymentSection.querySelector('.payment-success-animation');
      if (prevSuccess) prevSuccess.remove();
    }
    if (qrCodeContainer) {
      qrCodeContainer.innerHTML = '';
      qrCodeContainer.classList.remove('hidden');
    }
    if (confirmPaymentBtn) {
      confirmPaymentBtn.classList.remove('hidden');
    }

    // Reset các phần tử bị ẩn bởi onPaymentConfirmed
    const bankTransferInfo = document.getElementById('bankTransferInfo');
    const pollingSection = document.getElementById('paymentPollingSection');
    const qrLabel = document.querySelector('.qr-payment-label');
    const qrTotal = document.querySelector('.qr-payment-total');
    if (bankTransferInfo) bankTransferInfo.classList.remove('hidden');
    if (pollingSection) pollingSection.classList.add('hidden');
    if (qrLabel) qrLabel.classList.remove('hidden');
    if (qrTotal) qrTotal.classList.remove('hidden');

    // Clear DOM cache để tránh stale references
    clearDomCache();

    // Gọi lại renderBarberRatings để làm mới giao diện đánh giá thợ cắt
    renderBarberRatings();
    updateConditionalSections(); // Ẩn section4 và đặt lại trạng thái dissatisfaction divs
    updateProgressBar();
    // Event delegation listeners đã setup 1 lần, không cần re-setup
    setupScrollReveal();
  }

  function updateProgressBar() {
    let progress;
    if (state.currentStep === 0) {
      progress = 0;
    } else if (state.currentStep === 1) {
      progress = 30;
    } else if (state.currentStep === 2) {
      progress = 60;
    } else if (state.currentStep === 7) {
      progress = 100;
    } else {
      progress = (state.currentStep / state.totalSteps) * 100;
    }
    progressFill.style.width = `${progress}%`;
  }
});
