/* =================================================================
   BOOKING FORM BRANCH LOGIC - Chi nhánh functionality
   Xử lý logic chọn chi nhánh, tự động chọn chi nhánh dựa trên thợ,
   modal cảnh báo đổi chi nhánh và lọc danh sách thợ theo chi nhánh
   ================================================================= */

// ==================== GLOBAL VARIABLES ====================
let branches = [];
let allHairdressers = [];
let selectedBranch = ''; // Will store branch_id as string
let previousSelectedHairdresser = '';
let previousSelectedBranch = '';
let hairdresserBranchMap = new Map(); // Map thợ -> branch_id
const branchNameToIdMap = new Map(); // Map branch_name -> branch_id

// ==================== LOAD BRANCHES ON INIT ====================
async function loadBranches() {
  try {
    const response = await fetch(`${checkinData.restUrl}branches`, {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' },
    });

    if (!response.ok) throw new Error('Network response was not ok');

    const result = await response.json();

    if (!result.success) {
      throw new Error(result.message || 'Lỗi khi tải danh sách chi nhánh');
    }

    branches = result.data || [];

    // Build branch name to ID map
    branchNameToIdMap.clear();
    branches.forEach((branch) => {
      branchNameToIdMap.set(branch.branch_name, branch.id);
    });

    // Expose branches globally
    window.branches = branches;

    // No need to populate select with pill structure - dropdown will be populated on demand
    console.log('Loaded branches:', branches);
  } catch (error) {
    console.error('Error loading branches:', error);
    showError('Không thể tải danh sách chi nhánh. Vui lòng thử lại.');
  }
}

// ==================== LOAD HAIRDRESSERS WITH BRANCH INFO ====================
async function loadHairdressersWithBranch() {
  try {
    const response = await fetch(`${checkinData.restUrl}hairdressers`, {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' },
    });

    if (!response.ok) throw new Error('Network response was not ok');

    const result = await response.json();

    if (!result.success) {
      throw new Error(result.message || 'Lỗi khi tải danh sách thợ');
    }

    allHairdressers = result.data || [];
    if (typeof window.updateStaffInfoMap === 'function') {
      window.updateStaffInfoMap(allHairdressers);
    }

    // Build hairdresser -> branch map (using branch_id)
    hairdresserBranchMap.clear();
    allHairdressers.forEach((hairdresser) => {
      // Use branch_id directly from API response if available
      if (hairdresser.branch_id) {
        hairdresserBranchMap.set(hairdresser.hairdresser_name, parseInt(hairdresser.branch_id));
      } else if (hairdresser.branch) {
        // Fallback to branch name lookup if branch_id not available
        const branchId = branchNameToIdMap.get(hairdresser.branch);
        if (branchId) {
          hairdresserBranchMap.set(hairdresser.hairdresser_name, branchId);
        }
      }
    });

    // Expose globally
    window.allHairdressers = allHairdressers;
    window.hairdresserBranchMap = hairdresserBranchMap;

    console.log('Loaded hairdressers with branches (using branch_id):', hairdresserBranchMap);
    console.log('Sample hairdresser data:', allHairdressers[0]);
  } catch (error) {
    console.error('Error loading hairdressers:', error);
    showError('Không thể tải danh sách thợ. Vui lòng thử lại.');
  }
}

// ==================== FILTER HAIRDRESSERS BY BRANCH ====================
function filterHairdressersByBranch(branchId) {
  if (!branchId) {
    return allHairdressers;
  }

  // Filter by branch_id directly from hairdresser data
  return allHairdressers.filter((hairdresser) => {
    // Compare branch_id as both might be string or number
    return hairdresser.branch_id && hairdresser.branch_id == branchId;
  });
}

// ==================== UPDATE HAIRDRESSER LIST BY BRANCH ====================
function updateHairdresserListByBranch(branchId) {
  const filteredHairdressers = filterHairdressersByBranch(branchId);

  const hairdresserSelect = document.getElementById('hairdresserSelect');
  if (!hairdresserSelect) return;

  // Preserve current selection
  const currentSelection = hairdresserSelect.value;

  // Just update the hidden select value, no need to populate options with pill structure
  // The pill dropdown will be populated on demand when opened

  // Restore selection if it exists in filtered list
  if (
    currentSelection &&
    filteredHairdressers.some((h) => h.hairdresser_name === currentSelection)
  ) {
    hairdresserSelect.value = currentSelection;
  } else {
    hairdresserSelect.value = '';
  }

  // Store filtered hairdressers globally for use by pill dropdown
  if (typeof window !== 'undefined') {
    window.filteredHairdressers = filteredHairdressers;
  }

  console.log(`Filtered hairdressers for branch_id "${branchId}":`, filteredHairdressers.length);
}

// ==================== AUTO SELECT BRANCH FROM HAIRDRESSER ====================
function autoSelectBranchFromHairdresser(hairdresserName) {
  const branchSelect = document.getElementById('branchSelect');
  if (!branchSelect) return;

  const hairdresserBranchId = hairdresserBranchMap.get(hairdresserName);

  if (hairdresserBranchId) {
    branchSelect.value = hairdresserBranchId;
    selectedBranch = hairdresserBranchId;
    console.log(
      `Auto-selected branch_id "${hairdresserBranchId}" for hairdresser "${hairdresserName}"`
    );
  }
}

// ==================== BRANCH CHANGE HANDLER ====================
function onBranchChange() {
  const branchSelect = document.getElementById('branchSelect');
  if (!branchSelect) return;

  const newBranchId = branchSelect.value;
  const hairdresserSelect = document.getElementById('hairdresserSelect');
  const currentHairdresser = hairdresserSelect ? hairdresserSelect.value : '';

  // Check if hairdresser is selected and belongs to a different branch
  if (
    currentHairdresser &&
    currentHairdresser !== 'Chọn Thợ phục vụ' &&
    currentHairdresser !== ''
  ) {
    const hairdresserBranchId = hairdresserBranchMap.get(currentHairdresser);

    if (hairdresserBranchId && hairdresserBranchId != newBranchId) {
      // Save previous branch BEFORE showing modal
      previousSelectedBranch = selectedBranch || hairdresserBranchId;
      // Show warning modal with branch names for display
      const currentBranchName = [...branchNameToIdMap.entries()].find(
        ([name, id]) => id == hairdresserBranchId
      )?.[0];
      const newBranchName = [...branchNameToIdMap.entries()].find(
        ([name, id]) => id == newBranchId
      )?.[0];
      showBranchChangeWarning(currentHairdresser, currentBranchName, newBranchName);
      return;
    }
  }

  // Update selected branch and filter hairdressers
  previousSelectedBranch = selectedBranch;
  selectedBranch = newBranchId;
  updateHairdresserListByBranch(newBranchId);
  validateStep1();
}

// ==================== SHOW BRANCH CHANGE WARNING MODAL ====================
function showBranchChangeWarning(hairdresserName, currentBranch, newBranch) {
  const modal = document.getElementById('branchWarningModal');
  const message = document.getElementById('branchWarningMessage');

  if (!modal || !message) return;

  message.innerHTML = `
    Thợ <strong>${hairdresserName}</strong> đang làm việc tại Chi nhánh <strong>${currentBranch}</strong>.<br><br>
    Quý khách đang chọn Chi nhánh <strong>${newBranch}</strong>.<br><br>
    Vui lòng chọn lại Thợ phục vụ tại chi nhánh mới.
  `;

  modal.style.display = 'flex';
  previousSelectedHairdresser = hairdresserName;
}

// ==================== CONFIRM BRANCH CHANGE ====================
function confirmBranchChange() {
  const modal = document.getElementById('branchWarningModal');
  const branchSelect = document.getElementById('branchSelect');
  const hairdresserSelect = document.getElementById('hairdresserSelect');
  const hairdresserDisplay = document.getElementById('hairdresserPillDisplay');

  if (modal) modal.style.display = 'none';

  // Keep the new branch selection
  selectedBranch = branchSelect.value;

  // Reset hairdresser selection
  if (hairdresserSelect) {
    hairdresserSelect.value = '';
  }

  // Reset hairdresser pill display
  if (hairdresserDisplay) {
    hairdresserDisplay.innerHTML = '<span class="pill-placeholder">-- Chọn thợ phục vụ --</span>';
    hairdresserDisplay.classList.remove('has-selection');
  }

  // Clear hairdresser status
  const statusDiv = document.getElementById('hairdresserStatus');
  if (statusDiv) {
    statusDiv.textContent = 'Vui lòng chọn Thợ phục vụ tại chi nhánh mới';
    statusDiv.style.color = 'var(--secondary-color)';
    statusDiv.style.fontWeight = 'bold';
    statusDiv.style.fontStyle = 'italic';
  }

  // Update hairdresser list for the new branch
  updateHairdresserListByBranch(selectedBranch);

  // Validate step 1 to update button state
  setTimeout(() => validateStep1(), 100);
}

// ==================== CANCEL BRANCH CHANGE ====================
function cancelBranchChange() {
  const modal = document.getElementById('branchWarningModal');
  const branchSelect = document.getElementById('branchSelect');
  const hairdresserSelect = document.getElementById('hairdresserSelect');
  const branchDisplay = document.getElementById('branchPillDisplay');

  if (modal) modal.style.display = 'none';

  console.log('Cancel branch change - Restoring to:', previousSelectedBranch);
  console.log('Restoring hairdresser:', previousSelectedHairdresser);

  // Revert to previous branch
  if (branchSelect && previousSelectedBranch) {
    branchSelect.value = previousSelectedBranch;
    selectedBranch = previousSelectedBranch;

    // Update branch pill display
    const branch = branches.find((b) => b.id == previousSelectedBranch);
    if (branch && branchDisplay) {
      branchDisplay.innerHTML = `
        <div class="pill-item">
          <span>${branch.branch_name}</span>
          <span class="pill-remove" onclick="removeBranchPill(event)">
            <i class="fas fa-times"></i>
          </span>
        </div>
      `;
      branchDisplay.classList.add('has-selection');
    }
  }

  // Update hairdresser list for the original branch FIRST
  if (previousSelectedBranch) {
    updateHairdresserListByBranch(previousSelectedBranch);
  }

  // Then restore the previously selected hairdresser (after list is updated)
  setTimeout(() => {
    if (hairdresserSelect && previousSelectedHairdresser) {
      hairdresserSelect.value = previousSelectedHairdresser;

      // Update hairdresser status display
      const statusDiv = document.getElementById('hairdresserStatus');
      if (statusDiv) {
        const canhBao = pausedNotice(previousSelectedHairdresser);
        statusDiv.textContent = canhBao || `Thợ ${previousSelectedHairdresser} sẵn sàng phục vụ.`;
        statusDiv.style.color = canhBao ? '#ff9f43' : '#32CD32';
        statusDiv.style.fontWeight = 'bold';
        statusDiv.style.fontStyle = 'italic';
      }
    }

    // Validate and enable the next button after everything is restored
    validateStep1();
  }, 100);
}


// Thợ tạm dừng: không đặt lịch qua web được, chỉ hiện SĐT để khách liên hệ riêng.
function pausedNotice(name) {
  return typeof window.getPausedStaffNotice === 'function'
    ? window.getPausedStaffNotice(name)
    : null;
}

// ==================== VALIDATE STEP 1 (Enable/Disable Next Button) ====================
function validateStep1() {
  const step1NextBtn = document.getElementById('step1NextBtn');
  if (!step1NextBtn) {
    console.warn('step1NextBtn not found!');
    return;
  }

  const customerPhone = document.getElementById('customerPhone');
  const branchSelect = document.getElementById('branchSelect');
  const hairdresserSelect = document.getElementById('hairdresserSelect');
  const customerNameInput = document.getElementById('customerNameInput');
  const customerInfo = document.getElementById('customerInfo');

  let isValid = true;
  let validationLog = {
    phone: false,
    branch: false,
    hairdresser: false,
    customerName: true, // Default true unless it's a new customer
  };

  // Check phone number (at least 9 digits)
  if (!customerPhone || !customerPhone.value || customerPhone.value.replace(/^0/, '').length < 9) {
    isValid = false;
  } else {
    validationLog.phone = true;
  }

  // Check branch selection (skip if branch mode is disabled)
  const branchModeEnabled =
    (typeof checkinData !== 'undefined' && checkinData.branchModeEnabled) || false;
  const branchSelectElement = document.getElementById('branchSelect');
  const hasBranchSelectInDOM = branchSelectElement !== null;

  if (branchModeEnabled && hasBranchSelectInDOM) {
    // Branch mode is enabled and element exists - validate it
    if (!branchSelect || !branchSelect.value) {
      isValid = false;
      console.log('Branch validation failed: no branch selected');
    } else {
      validationLog.branch = true;
    }
  } else {
    // Branch mode disabled or element doesn't exist - always valid
    validationLog.branch = true;
  }

  // Check hairdresser selection
  if (
    !hairdresserSelect ||
    !hairdresserSelect.value ||
    hairdresserSelect.value === 'Chọn Thợ phục vụ' ||
    hairdresserSelect.value === ''
  ) {
    isValid = false;
  } else if (pausedNotice(hairdresserSelect.value)) {
    // Thợ tạm dừng: khoá nút Tiếp Theo, khách phải chọn thợ khác hoặc gọi trực tiếp
    isValid = false;
    validationLog.hairdresser = 'tạm dừng';
  } else {
    validationLog.hairdresser = true;
  }

  // Check customer name for new customers
  if (customerInfo && customerInfo.style.display === 'none') {
    const newCustomerInfo = document.getElementById('newCustomerInfo');
    if (newCustomerInfo && newCustomerInfo.style.display !== 'none') {
      if (!customerNameInput || !customerNameInput.value || customerNameInput.value.trim() === '') {
        isValid = false;
        validationLog.customerName = false;
      }
    }
  }

  console.log('Validate Step 1:', validationLog, 'Final valid:', isValid);

  // Ensure button is always visible (display block)
  step1NextBtn.style.display = 'inline-block';

  // Enable or disable button
  if (isValid) {
    step1NextBtn.disabled = false;
    step1NextBtn.style.opacity = '1';
    step1NextBtn.style.cursor = 'pointer';
    console.log('Step1 Next Button: ENABLED');
  } else {
    step1NextBtn.disabled = true;
    step1NextBtn.style.opacity = '0.5';
    step1NextBtn.style.cursor = 'not-allowed';
    console.log('Step1 Next Button: DISABLED');
  }
}

// ==================== OVERRIDE selectHairdresser TO AUTO-SELECT BRANCH ====================
const originalSelectHairdresser = window.selectHairdresser;
window.selectHairdresser = function (
  hairdresserNameSelected,
  hairdresserStatus,
  offStart,
  offEnd,
  isManagerSelected
) {
  console.log('selectHairdresser called with:', hairdresserNameSelected);

  // Call original function
  if (originalSelectHairdresser) {
    originalSelectHairdresser(
      hairdresserNameSelected,
      hairdresserStatus,
      offStart,
      offEnd,
      isManagerSelected
    );
  }

  // Auto-select branch if hairdresser is selected AND branch is not already set correctly
  if (hairdresserNameSelected && hairdresserNameSelected !== 'Chọn Thợ phục vụ') {
    const hairdresserBranch = hairdresserBranchMap.get(hairdresserNameSelected);
    const branchSelect = document.getElementById('branchSelect');

    // Only auto-select if branch is empty OR different from hairdresser's branch
    if (branchSelect && (!branchSelect.value || branchSelect.value !== hairdresserBranch)) {
      console.log('Auto-selecting branch for hairdresser:', hairdresserNameSelected);
      autoSelectBranchFromHairdresser(hairdresserNameSelected);
    } else {
      console.log('Branch already correct, no need to auto-select');
    }
  }

  // Always validate step 1 after selecting hairdresser
  setTimeout(() => {
    console.log('Running validateStep1 after selectHairdresser');
    validateStep1();
  }, 150);
};

// ==================== OVERRIDE checkCustomer TO SHOW BRANCH INFO ====================
const originalCheckCustomer = window.checkCustomer;
window.checkCustomer = async function () {
  // Call original function
  if (originalCheckCustomer) {
    await originalCheckCustomer();
  }

  // Get customer info and show branch if available
  const customerInfo = document.getElementById('customerInfo');
  if (customerInfo && customerInfo.style.display === 'block') {
    const phone = document.getElementById('customerPhone').value.replace(/^0/, '');

    try {
      const response = await fetch(`${checkinData.restUrl}check-customer?phone=${phone}`, {
        method: 'GET',
        headers: { 'Content-Type': 'application/json' },
      });

      if (!response.ok) throw new Error('Network response was not ok');

      const result = await response.json();

      if (result.exists) {
        // Try to get customer's usual branch from their hairdresser
        const customerHairdresser = result.hairdresserName;
        if (customerHairdresser) {
          const customerBranchId = hairdresserBranchMap.get(customerHairdresser);
          const oldBranchSpan = document.getElementById('oldBranch');
          if (oldBranchSpan && customerBranchId) {
            // Display branch name instead of ID
            const branchName = [...branchNameToIdMap.entries()].find(
              ([name, id]) => id == customerBranchId
            )?.[0];
            oldBranchSpan.textContent = branchName || 'Chưa có thông tin';

            // Auto-select the customer's usual branch by ID
            const branchSelect = document.getElementById('branchSelect');
            if (branchSelect) {
              branchSelect.value = customerBranchId;
              selectedBranch = customerBranchId;
              updateHairdresserListByBranch(customerBranchId);
            }
          } else if (oldBranchSpan) {
            oldBranchSpan.textContent = 'Chưa có thông tin';
          }
        }
      }
    } catch (error) {
      console.error('Error getting customer branch:', error);
    }
  }

  // Validate step 1
  validateStep1();
};

// ==================== ADD BRANCH TO BOOKING DATA ON SUBMIT ====================
const originalLoadSubmit = window.loadSubmit || function () {};
window.loadSubmit = function () {
  // Call original function
  originalLoadSubmit();

  // Override submit button to include branch data
  const submitBookingButton = document.getElementById('submitBooking');
  if (submitBookingButton) {
    submitBookingButton.addEventListener(
      'click',
      function () {
        // Add branch_id to booking data
        if (window.bookingData) {
          window.bookingData.branch_id = selectedBranch; // selectedBranch now contains branch_id
        }
      },
      { once: true, capture: true }
    );
  }
};

// ==================== UPDATE CONFIRMATION STEP TO SHOW BRANCH ====================
const originalNextStep = window.nextStep;
window.nextStep = function (step) {
  // If moving to step 4 (confirmation), update branch info first
  if (step === 4) {
    const branchSelect = document.getElementById('branchSelect');
    if (branchSelect && branchSelect.value) {
      selectedBranch = branchSelect.value;
    }

    const selectedBranchSpan = document.getElementById('selectedBranch');
    if (selectedBranchSpan) {
      // Display branch name instead of ID
      const branchName = [...branchNameToIdMap.entries()].find(
        ([name, id]) => id == selectedBranch
      )?.[0];
      selectedBranchSpan.textContent = branchName || 'Chưa chọn';
    }

    console.log('Step 4: Displaying branch_id:', selectedBranch);
  }

  // Call original function
  if (originalNextStep) {
    originalNextStep(step);
  }
};

// ==================== CHECK AND AUTO SELECT BRANCH ON MODAL OPEN ====================
function checkAndAutoSelectBranchOnModalOpen() {
  // Wait for data to load first
  setTimeout(() => {
    const hairdresserSelect = document.getElementById('hairdresserSelect');
    const branchSelect = document.getElementById('branchSelect');
    const branchPillDisplay = document.getElementById('branchPillDisplay');
    const hairdresserPillDisplay = document.getElementById('hairdresserPillDisplay');

    const currentHairdresser = hairdresserSelect ? hairdresserSelect.value : '';

    console.log('Modal opened, checking hairdresser:', currentHairdresser);
    console.log('Hairdresser-Branch Map:', hairdresserBranchMap);

    // If hairdresser is already selected and not empty
    if (
      currentHairdresser &&
      currentHairdresser !== '' &&
      currentHairdresser !== 'Chọn Thợ phục vụ' &&
      branchSelect
    ) {
      // Auto-select branch by ID
      const branchId = hairdresserBranchMap.get(currentHairdresser);
      console.log('Found branch_id for hairdresser:', branchId);

      if (branchId) {
        branchSelect.value = branchId;
        selectedBranch = branchId;
        console.log('Auto-selected branch_id:', branchId);

        // Find branch name and update pill display
        const branch = branches.find((b) => b.id == branchId);
        if (branch && branchPillDisplay) {
          branchPillDisplay.innerHTML = `
            <div class="pill-item">
              <span>${branch.branch_name}</span>
              <span class="pill-remove" onclick="removeBranchPill(event)">
                <i class="fas fa-times"></i>
              </span>
            </div>
          `;
          branchPillDisplay.classList.add('has-selection');
          console.log('Updated branch pill display:', branch.branch_name);
        }

        // Update hairdresser pill display if hairdresser is selected
        if (hairdresserPillDisplay) {
          hairdresserPillDisplay.innerHTML = `
            <div class="pill-item">
              <span>${currentHairdresser}</span>
              <span class="pill-remove" onclick="removeHairdresserPill(event)">
                <i class="fas fa-times"></i>
              </span>
            </div>
          `;
          hairdresserPillDisplay.classList.add('has-selection');
          console.log('Updated hairdresser pill display:', currentHairdresser);
        }

        // Update hairdresser list by branch
        updateHairdresserListByBranch(branchId);
      }
    } else {
      // No hairdresser selected yet - ensure all hairdressers are available
      console.log('No hairdresser selected on modal open - showing all hairdressers');
      if (branchSelect && !branchSelect.value) {
        // If branch mode enabled but no branch selected, allow all hairdressers
        updateHairdresserListByBranch(null);
      }
    }

    // Always validate after processing
    validateStep1();
  }, 300);
}

// ==================== INITIALIZE ON DOM LOAD ====================
document.addEventListener('DOMContentLoaded', function () {
  console.log('Branch logic loaded');

  // Load branches and hairdressers with branch info
  loadBranches();
  loadHairdressersWithBranch();

  // Add event listeners
  const branchSelect = document.getElementById('branchSelect');
  if (branchSelect) {
    branchSelect.addEventListener('change', onBranchChange);
  }

  const customerPhone = document.getElementById('customerPhone');
  if (customerPhone) {
    customerPhone.addEventListener('input', validateStep1);
  }

  const customerNameInput = document.getElementById('customerNameInput');
  if (customerNameInput) {
    customerNameInput.addEventListener('input', validateStep1);
  }

  const customerCount = document.getElementById('customerCount');
  if (customerCount) {
    customerCount.addEventListener('input', validateStep1);
  }

  // Listen for modal open events
  const bookingModal = document.querySelector('.popup');
  if (bookingModal) {
    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        if (mutation.attributeName === 'style' && bookingModal.style.display === 'block') {
          checkAndAutoSelectBranchOnModalOpen();
        }
      });
    });
    observer.observe(bookingModal, { attributes: true });
  }

  // Expose functions and data globally
  window.onBranchChange = onBranchChange;
  window.confirmBranchChange = confirmBranchChange;
  window.cancelBranchChange = cancelBranchChange;
  window.loadBranches = loadBranches;
  window.validateStep1 = validateStep1;
  window.checkAndAutoSelectBranchOnModalOpen = checkAndAutoSelectBranchOnModalOpen;
  window.toggleBranchDropdown = toggleBranchDropdown;
  window.toggleHairdresserDropdown = toggleHairdresserDropdown;
  window.selectBranchPill = selectBranchPill;
  window.selectHairdresserPill = selectHairdresserPill;
  window.removeBranchPill = removeBranchPill;
  window.removeHairdresserPill = removeHairdresserPill;
  window.autoSelectBranchFromHairdresser = autoSelectBranchFromHairdresser;

  // Expose data arrays
  window.branches = branches;
  window.allHairdressers = allHairdressers;
  window.hairdresserBranchMap = hairdresserBranchMap;

  // Close dropdowns when clicking outside
  document.addEventListener('click', function (e) {
    if (!e.target.closest('.pill-select-container')) {
      const branchDropdown = document.getElementById('branchDropdown');
      const hairdresserDropdown = document.getElementById('hairdresserDropdown');
      if (branchDropdown) branchDropdown.style.display = 'none';
      if (hairdresserDropdown) hairdresserDropdown.style.display = 'none';
    }
  });
});

// ==================== PILL SELECT FUNCTIONS ====================

// Toggle Branch Dropdown
function toggleBranchDropdown(event) {
  if (event) event.stopPropagation();
  const dropdown = document.getElementById('branchDropdown');
  const hairdresserDropdown = document.getElementById('hairdresserDropdown');

  // Close hairdresser dropdown
  hairdresserDropdown.style.display = 'none';

  // Toggle branch dropdown
  const isVisible = dropdown.style.display === 'block';
  dropdown.style.display = isVisible ? 'none' : 'block';

  // Populate dropdown if empty
  if (!isVisible && dropdown.querySelector('.pill-dropdown-list').children.length === 0) {
    populateBranchDropdown();
  }
}

// Toggle Hairdresser Dropdown
function toggleHairdresserDropdown(event) {
  if (event) event.stopPropagation();
  const dropdown = document.getElementById('hairdresserDropdown');
  const branchDropdown = document.getElementById('branchDropdown');

  // Close branch dropdown
  if (branchDropdown) {
    branchDropdown.style.display = 'none';
  }

  // Toggle hairdresser dropdown
  const isVisible = dropdown.style.display === 'block';
  dropdown.style.display = isVisible ? 'none' : 'block';

  // Always populate dropdown when opening (even if pill exists)
  if (!isVisible) {
    populateHairdresserDropdown();
  }
}

// Populate Branch Dropdown
function populateBranchDropdown() {
  const list = document.getElementById('branchDropdownList');
  list.innerHTML = '';

  branches.forEach((branch) => {
    const li = document.createElement('li');
    li.textContent = branch.branch_name;
    li.setAttribute('data-branch-id', branch.id);
    li.onclick = () => selectBranchPill(branch.id, branch.branch_name);
    list.appendChild(li);
  });
}

// Populate Hairdresser Dropdown
function populateHairdresserDropdown() {
  const list = document.getElementById('hairdresserDropdownList');
  const branchSelect = document.getElementById('branchSelect');
  const branchModeEnabled = checkinData.branchModeEnabled || false;

  list.innerHTML = '';

  // If branch mode is disabled, show all hairdressers
  // If branch mode is enabled but no branch selected yet, show all hairdressers
  // If branch mode is enabled and branch is selected, filter by branch
  let selectedBranchId = null;
  if (branchModeEnabled && branchSelect && branchSelect.value) {
    selectedBranchId = branchSelect.value;
  }
  const filteredHairdressers = filterHairdressersByBranch(selectedBranchId);

  console.log(
    'Populating hairdresser dropdown. Branch mode:',
    branchModeEnabled,
    'Selected branch:',
    selectedBranchId,
    'Hairdressers:',
    filteredHairdressers.length
  );

  filteredHairdressers.forEach((h) => {
    const li = document.createElement('li');
    let statusText = '';
    if (h.is_off_today === '1') {
      statusText = ` (Đang nghỉ phép hôm nay)`;
    } else if (h.off_future_start) {
      statusText = ` (Lịch OFF sắp tới: ${h.off_future_start}-${h.off_future_end || ''})`;
    }
    li.textContent = h.hairdresser_name + statusText;
    li.setAttribute('data-hairdresser-name', h.hairdresser_name);
    li.setAttribute('data-status', h.hairdresser_status);
    li.onclick = () =>
      selectHairdresserPill(
        h.hairdresser_name,
        h.hairdresser_status,
        h.off_future_start || '',
        h.off_future_end || '',
        h.is_manager
      );
    list.appendChild(li);
  });
}

// Select Branch Pill
function selectBranchPill(branchId, branchName) {
  const branchSelect = document.getElementById('branchSelect');
  const display = document.getElementById('branchPillDisplay');
  const dropdown = document.getElementById('branchDropdown');

  // Store the previous branch for comparison
  const previousBranchId = branchSelect.value;

  // Update hidden input
  branchSelect.value = branchId;
  selectedBranch = branchId;

  // Update display with pill
  display.innerHTML = `
    <div class="pill-item">
      <span>${branchName}</span>
      <span class="pill-remove" onclick="removeBranchPill(event)">
        <i class="fas fa-times"></i>
      </span>
    </div>
  `;
  display.classList.add('has-selection');

  // Close dropdown
  dropdown.style.display = 'none';

  // If branch changed and hairdresser is selected, check compatibility
  if (previousBranchId && previousBranchId !== branchId) {
    const hairdresserSelect = document.getElementById('hairdresserSelect');
    const currentHairdresser = hairdresserSelect.value;

    if (currentHairdresser) {
      const hairdresserBranchId = hairdresserBranchMap.get(currentHairdresser);
      if (hairdresserBranchId && hairdresserBranchId != branchId) {
        // Branch mismatch - show warning
        previousSelectedBranch = previousBranchId;
        previousSelectedHairdresser = currentHairdresser;
        showBranchWarning(branchName);
        return;
      }
    }
  }

  // Update hairdresser list
  updateHairdresserListByBranch(branchId);

  // Trigger onBranchChange for any additional logic
  if (typeof onBranchChange === 'function') {
    onBranchChange();
  }
}

// Select Hairdresser Pill
function selectHairdresserPill(name, status, offStart, offEnd, isManager) {
  const hairdresserSelect = document.getElementById('hairdresserSelect');
  const display = document.getElementById('hairdresserPillDisplay');
  const dropdown = document.getElementById('hairdresserDropdown');

  // Update hidden input
  hairdresserSelect.value = name;

  // Update display with pill
  display.innerHTML = `
    <div class="pill-item">
      <span>${name}</span>
      <span class="pill-remove" onclick="removeHairdresserPill(event)">
        <i class="fas fa-times"></i>
      </span>
    </div>
  `;
  display.classList.add('has-selection');

  // Close dropdown
  dropdown.style.display = 'none';

  // Auto-select branch if not selected (only if branch mode is enabled)
  const branchSelect = document.getElementById('branchSelect');
  if (branchSelect && !branchSelect.value) {
    autoSelectBranchFromHairdresser(name);
    // Update branch pill display
    const hairdresserBranchId = hairdresserBranchMap.get(name);
    if (hairdresserBranchId) {
      const branch = branches.find((b) => b.id == hairdresserBranchId);
      if (branch) {
        const branchDisplay = document.getElementById('branchPillDisplay');
        if (branchDisplay) {
          branchDisplay.innerHTML = `
            <div class="pill-item">
              <span>${branch.branch_name}</span>
              <span class="pill-remove" onclick="removeBranchPill(event)">
                <i class="fas fa-times"></i>
              </span>
            </div>
          `;
          branchDisplay.classList.add('has-selection');
        }
      }
    }
  }

  // Update hairdresser status display
  const statusDiv = document.getElementById('hairdresserStatus');
  if (statusDiv) {
    const canhBaoTamDung = pausedNotice(name);
    if (canhBaoTamDung) {
      statusDiv.textContent = canhBaoTamDung;
      statusDiv.style.color = '#ff9f43';
    } else if (status === 'ON' || status === 'AVAILABLE') {
      statusDiv.textContent = `Thợ ${name} sẵn sàng phục vụ.`;
      statusDiv.style.color = '#32CD32';
    } else if (status === 'OFF') {
      statusDiv.textContent = `Thợ ${name} đang nghỉ phép.`;
      statusDiv.style.color = '#ff6b6b';
    } else {
      statusDiv.textContent = `Thợ ${name} đã được chọn.`;
      statusDiv.style.color = 'var(--secondary-color)';
    }
    statusDiv.style.fontWeight = 'bold';
    statusDiv.style.fontStyle = 'italic';
  }

  // Call original selectHairdresser to update status and load services
  if (typeof window.selectHairdresser === 'function') {
    window.selectHairdresser(name, status, offStart, offEnd, isManager);
  }

  // Validate step 1 after selection
  setTimeout(() => validateStep1(), 100);
}

// Remove Branch Pill
function removeBranchPill(event) {
  if (event) {
    event.stopPropagation();
  }

  const branchSelect = document.getElementById('branchSelect');
  const display = document.getElementById('branchPillDisplay');
  const dropdown = document.getElementById('branchDropdown');

  // Clear selection
  branchSelect.value = '';
  selectedBranch = '';

  // Reset display
  display.innerHTML = '<span class="pill-placeholder">-- Vui lòng chọn chi nhánh --</span>';
  display.classList.remove('has-selection');

  // Show all hairdressers
  updateHairdresserListByBranch('');

  // Open dropdown
  dropdown.style.display = 'block';
  populateBranchDropdown();
}

// Remove Hairdresser Pill
function removeHairdresserPill(event) {
  if (event) {
    event.stopPropagation();
  }

  const hairdresserSelect = document.getElementById('hairdresserSelect');
  const display = document.getElementById('hairdresserPillDisplay');
  const dropdown = document.getElementById('hairdresserDropdown');

  // Clear selection
  hairdresserSelect.value = '';

  // Reset display
  display.innerHTML = '<span class="pill-placeholder">-- Chọn thợ phục vụ --</span>';
  display.classList.remove('has-selection');

  // Open dropdown
  dropdown.style.display = 'block';
  populateHairdresserDropdown();
}

// Show Branch Warning Modal
function showBranchWarning(newBranchName) {
  const modal = document.getElementById('branchWarningModal');
  const message = document.getElementById('branchWarningMessage');

  message.textContent = `Bạn đã chọn Thợ thuộc chi nhánh khác. Chuyển sang chi nhánh "${newBranchName}" sẽ xóa lựa chọn Thợ hiện tại. Bạn có muốn tiếp tục?`;

  modal.style.display = 'flex';
}
