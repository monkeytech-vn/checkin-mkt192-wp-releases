document.addEventListener('DOMContentLoaded', function () {
  // App state
  const state = {
    invoiceId: null,
    customerId: null,
    customerName: '',
    customerPhone: '',
    membershipLabel: '',
    services: [],
    barbers: [],
    servicePrice: 0,
    currentStep: 0,
    totalSteps: 4,
    promotionAmount: 0,
    promoCode: '',
    promoName: '',
    tipAmount: 0,
    ratings: {
      service: null,
      barbers: {},
    },
    // Lý do không hài lòng (rating <= 3)
    dissatisfactionReasons: {
      service: [],
      barbers: [],
    },
    otherReason: {
      service: '',
      barbers: '',
    },
    // Lý do hài lòng (rating >= 4)
    satisfactionReasons: {
      service: [],
      barbers: [],
    },
    satisfactionComment: '',
    transactionDate: '',
  };

  // DOM elements
  const progressFill = document.getElementById('progressFill');
  const submitButton = document.getElementById('submitBtn');
  const editFeedbackBtn = document.getElementById('editFeedbackBtn');
  const section4 = document.getElementById('section4'); // Dissatisfaction
  const section5 = document.getElementById('section5'); // Satisfaction
  const successMessage = document.getElementById('successMessage');
  const otherServiceReasonInput = document.getElementById('otherServiceReason');
  const otherBarberReasonInput = document.getElementById('otherBarberReason');
  const satisfactionCommentInput = document.getElementById('satisfactionComment');
  const barberRatingsContainer = document.getElementById('barberRatings');

  // Display elements
  const customerNameDisplay = document.getElementById('customerName');
  const customerPhoneDisplay = document.getElementById('customerPhone');
  const promoCodeDisplay = document.getElementById('promoCode');
  const summaryServiceName = document.getElementById('summaryServiceName');
  const summaryBarberName = document.getElementById('summaryBarberName');
  const servicePriceDisplay = document.getElementById('servicePrice');
  const promoNameDisplay = document.getElementById('promoName');
  const promotionDisplay = document.getElementById('promotionDisplay');
  const tipDisplay = document.getElementById('tipDisplay');
  const totalDisplay = document.getElementById('totalDisplay');
  const finalAmountDisplay = document.getElementById('finalAmountDisplay');
  const serviceRatingDisplay = document.getElementById('serviceRatingDisplay');
  const barberRatingsDisplay = document.getElementById('barberRatingsDisplay');
  const serviceStarsDisplay = document.getElementById('serviceStarsDisplay');
  const transactionIdDisplay = document.getElementById('transactionId');
  const transactionDateFinalDisplay = document.getElementById('transactionDateFinal');
  const summaryServiceNameDisplay = document.getElementById('summaryServiceNameDisplay');
  const summaryBarberNameDisplay = document.getElementById('summaryBarberNameDisplay');

  // Initialize
  loadInvoiceData();
  updateProgressBar();
  setCurrentDate();
  setupEventListeners();
  attachRatingEventListeners();
  setupChipListeners();
  setupScrollReveal();

  async function fetchAPI(endpoint, options = {}) {
    try {
      const response = await fetch(`${checkinData.restUrl}${endpoint}`, {
        ...options,
        headers: {
          'Content-Type': 'application/json',
          'X-WP-Nonce': checkinData.nonce,
          ...options.headers,
        },
      });
      const text = await response.text();
      console.log(`Raw response from ${endpoint}:`, text);

      let result;
      try {
        result = JSON.parse(text);
      } catch (e) {
        return { success: false, message: 'Phản hồi API không phải JSON' };
      }

      if (result.success === undefined) {
        result.success = true;
      }
      if (result.status === undefined) {
        result.status = response.status;
      }

      if (!result.success) {
        return { success: false, message: result.message || `Lỗi khi gọi API ${endpoint}` };
      }
      return { success: true, data: result.data || result };
    } catch (error) {
      console.log(`Lỗi khi gọi ${endpoint}:`, error.message);
      return { success: false, message: error.message };
    }
  }

  async function loadInvoiceData() {
    const urlParams = new URLSearchParams(window.location.search);
    state.invoiceId = urlParams.get('invoice_id');
    if (!state.invoiceId) {
      console.log('Không tìm thấy invoice_id trong URL');
      showError('Lỗi: Không tìm thấy mã hóa đơn trong liên kết');
      return;
    }

    try {
      const result = await fetchAPI(`review/invoices/${state.invoiceId}`);
      if (result.success) {
        const invoice = result.data;
        console.log('Dữ liệu hóa đơn:', invoice);

        state.customerId = invoice.customer_id || null;
        state.customerName = invoice.customer_name || 'Khách vãng lai';
        state.customerPhone = invoice.customer_phone || '123456789';
        state.membershipLabel = invoice.membership_label || 'Thường';
        state.services = invoice.services || [];
        state.servicePrice = parseFloat(invoice.subtotal) || 0;
        state.promotionAmount = parseFloat(invoice.discount) || 0;
        state.promoCode = invoice.promo_code || 'Không có';
        state.promoName = invoice.promo_name || 'Không có';
        state.tipAmount = parseFloat(invoice.tips) || 0;
        state.totalAmount = parseFloat(invoice.total) || 0;
        state.barbers = [
          ...new Set(state.services.map((s) => s.staff_name).filter((name) => name)),
        ];
        state.transactionDate = invoice.created_at
          ? formatDate(invoice.created_at)
          : 'Không xác định';

        // Cập nhật giao diện
        document.getElementById('invoiceId').textContent = state.invoiceId || 'Không xác định';
        document.getElementById('transactionDate').textContent = state.transactionDate;
        document.getElementById('transactionDateFinal').textContent = state.transactionDate;
        customerPhoneDisplay.textContent = state.customerPhone;
        customerNameDisplay.textContent = state.customerName;
        promoCodeDisplay.textContent = state.promoCode;

        const membershipLabelElement = document.getElementById('membershipLabel');
        membershipLabelElement.textContent = state.membershipLabel;
        membershipLabelElement.classList.remove('vip-tag', 'premium-tag', 'normal-tag');
        if (state.membershipLabel.toLowerCase() === 'vip') {
          membershipLabelElement.classList.add('vip-tag');
        } else if (state.membershipLabel.toLowerCase() === 'premium') {
          membershipLabelElement.classList.add('premium-tag');
        } else {
          membershipLabelElement.classList.add('normal-tag');
        }

        summaryServiceName.textContent =
          state.services.map((s) => s.service_name).join(', ') || 'Không xác định';
        summaryBarberName.textContent = state.barbers.join(', ') || 'Không xác định';
        servicePriceDisplay.textContent = formatCurrency(state.servicePrice);
        promoNameDisplay.textContent = state.promoName;
        promotionDisplay.textContent =
          state.promotionAmount > 0 ? `-${formatCurrency(state.promotionAmount)}` : '0 VNĐ';
        tipDisplay.textContent = formatCurrency(state.tipAmount);
        totalDisplay.textContent = formatCurrency(state.totalAmount);

        renderBarberRatings();
        updateSummarySection();
        updateProgressBar();
      } else {
        throw new Error(result.message);
      }
    } catch (error) {
      console.error(`Lỗi khi tải hóa đơn ${state.invoiceId}:`, error.message);
      showError(`Lỗi: ${error.message || 'Không thể tải thông tin hóa đơn'}`);
    }
  }

  function formatDate(dateString) {
    try {
      const date = new Date(dateString);
      if (isNaN(date.getTime())) {
        throw new Error('Ngày không hợp lệ');
      }
      return date.toLocaleString('vi-VN', {
        hour: '2-digit',
        minute: '2-digit',
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
      });
    } catch (error) {
      console.warn(`Lỗi định dạng ngày: ${dateString}`, error);
      return 'Không xác định';
    }
  }

  function formatCurrency(amount) {
    return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(amount);
  }

  function renderBarberRatings() {
    barberRatingsContainer.innerHTML = '';
    state.barbers.forEach((barber) => {
      const div = document.createElement('div');
      div.className = 'mb-8';
      div.innerHTML = `
                <h3 class="font-semibold text-xl text-center text-blue-500 mb-2">${barber}</h3>
                <div class="grid grid-cols-2 md:grid-cols-5 gap-4">
                    <div class="rating-option touch-friendly text-center p-4 bg-gray-50 rounded-lg cursor-pointer hover:bg-blue-50" data-type="barber" data-barber="${barber}" data-value="1">
                        <i class="fas fa-angry text-red-500 text-2xl mb-2"></i><br>Rất Tệ
                    </div>
                    <div class="rating-option touch-friendly text-center p-4 bg-gray-50 rounded-lg cursor-pointer hover:bg-blue-50" data-type="barber" data-barber="${barber}" data-value="2">
                        <i class="fas fa-frown text-orange-500 text-2xl mb-2"></i><br>Chê Nha
                    </div>
                    <div class="rating-option touch-friendly text-center p-4 bg-gray-50 rounded-lg cursor-pointer hover:bg-blue-50" data-type="barber" data-barber="${barber}" data-value="3">
                        <i class="fas fa-meh text-yellow-500 text-2xl mb-2"></i><br>Không Ưng Lắm
                    </div>
                    <div class="rating-option touch-friendly text-center p-4 bg-gray-50 rounded-lg cursor-pointer hover:bg-blue-50" data-type="barber" data-barber="${barber}" data-value="4">
                        <i class="fas fa-smile text-blue-500 text-2xl mb-2"></i><br>Hài Lòng
                    </div>
                    <div class="rating-option touch-friendly text-center p-4 bg-gray-50 rounded-lg cursor-pointer hover:bg-blue-50" data-type="barber" data-barber="${barber}" data-value="5">
                        <i class="fas fa-grin-stars text-green-500 text-2xl mb-2"></i><br>Siêu Hài Lòng
                    </div>
                </div>
            `;
      barberRatingsContainer.appendChild(div);

      const selectedRating = state.ratings.barbers[barber];
      if (selectedRating) {
        const selectedOption = div.querySelector(
          `.rating-option[data-type="barber"][data-barber="${barber}"][data-value="${selectedRating}"]`
        );
        if (selectedOption) {
          selectedOption.classList.add('active');
          div
            .querySelectorAll(`.rating-option[data-type="barber"][data-barber="${barber}"]`)
            .forEach((opt) => {
              if (opt !== selectedOption) {
                opt.classList.add('inactive');
              }
            });
        }
      }
    });

    const serviceRating = state.ratings.service;
    if (serviceRating) {
      const serviceOptions = document.querySelectorAll('.rating-option[data-type="service"]');
      serviceOptions.forEach((opt) => {
        if (parseInt(opt.getAttribute('data-value')) === serviceRating) {
          opt.classList.add('active');
        } else {
          opt.classList.add('inactive');
        }
      });
    }

    attachRatingEventListeners();
  }

  function attachRatingEventListeners() {
    document.querySelectorAll('.rating-option').forEach((option) => {
      option.removeEventListener('click', handleRatingClick);
      option.removeEventListener('touchstart', handleTouchStart);
      option.removeEventListener('touchend', handleTouchEnd);
      option.addEventListener('click', handleRatingClick);
      option.addEventListener('touchstart', handleTouchStart);
      option.addEventListener('touchend', handleTouchEnd);
    });
  }

  function setupEventListeners() {
    submitButton.addEventListener('click', validateAndSubmit);
    editFeedbackBtn.addEventListener('click', resetForm);

    // Textarea inputs
    if (otherServiceReasonInput) {
      otherServiceReasonInput.addEventListener('input', function () {
        state.otherReason.service = this.value;
      });
    }

    if (otherBarberReasonInput) {
      otherBarberReasonInput.addEventListener('input', function () {
        state.otherReason.barbers = this.value;
      });
    }

    if (satisfactionCommentInput) {
      satisfactionCommentInput.addEventListener('input', function () {
        state.satisfactionComment = this.value;
      });
    }
  }

  function setupChipListeners() {
    // Dissatisfaction chips
    document.querySelectorAll('.dissatisfaction-chip').forEach((chip) => {
      chip.addEventListener('click', handleDissatisfactionChipClick);
    });

    // Satisfaction chips
    document.querySelectorAll('.satisfaction-chip').forEach((chip) => {
      chip.addEventListener('click', handleSatisfactionChipClick);
    });
  }

  function handleDissatisfactionChipClick(e) {
    const chip = e.currentTarget;
    const reasonType = chip.getAttribute('data-reason');
    const value = chip.getAttribute('data-value');

    chip.classList.toggle('selected');

    const targetArray =
      reasonType === 'service'
        ? state.dissatisfactionReasons.service
        : state.dissatisfactionReasons.barbers;

    if (chip.classList.contains('selected')) {
      if (!targetArray.includes(value)) {
        targetArray.push(value);
      }
    } else {
      const index = targetArray.indexOf(value);
      if (index !== -1) {
        targetArray.splice(index, 1);
      }
    }
  }

  function handleSatisfactionChipClick(e) {
    const chip = e.currentTarget;
    const reasonType = chip.getAttribute('data-reason');
    const value = chip.getAttribute('data-value');

    chip.classList.toggle('selected');

    const targetArray =
      reasonType === 'service-good'
        ? state.satisfactionReasons.service
        : state.satisfactionReasons.barbers;

    if (chip.classList.contains('selected')) {
      if (!targetArray.includes(value)) {
        targetArray.push(value);
      }
    } else {
      const index = targetArray.indexOf(value);
      if (index !== -1) {
        targetArray.splice(index, 1);
      }
    }
  }

  function setupScrollReveal() {
    // Show all sections immediately without scroll animation
    // for better touch screen performance
    const sections = document.querySelectorAll('.scroll-reveal, .section');
    sections.forEach((section) => {
      section.classList.add('revealed');
    });
  }

  function handleTouchStart(e) {
    const element = e.currentTarget;
    if (!element.classList.contains('inactive')) {
      element.classList.add('bg-blue-600', 'text-white');
    }
  }

  function handleTouchEnd(e) {
    const element = e.currentTarget;
    if (!element.classList.contains('inactive')) {
      element.classList.remove('bg-blue-600', 'text-white');
    }
  }

  function handleRatingClick(e) {
    e.preventDefault();
    e.stopPropagation();

    const option = e.currentTarget;
    const value = parseInt(option.getAttribute('data-value'));
    const type = option.getAttribute('data-type');
    const barber = option.getAttribute('data-barber');

    if (type === 'service') {
      state.ratings.service = value;
      document.querySelectorAll('.rating-option[data-type="service"]').forEach((opt) => {
        opt.classList.remove('active', 'inactive', 'bg-blue-100');
        opt.style.opacity = '';
      });
      state.currentStep = 1;
    } else if (type === 'barber' && barber) {
      state.ratings.barbers[barber] = value;
      document
        .querySelectorAll(`.rating-option[data-type="barber"][data-barber="${barber}"]`)
        .forEach((opt) => {
          opt.classList.remove('active', 'inactive', 'bg-blue-100');
          opt.style.opacity = '';
        });
      state.currentStep = 2;
    }

    option.classList.add('active');

    if (type === 'service') {
      document.querySelectorAll('.rating-option[data-type="service"]').forEach((opt) => {
        if (opt !== option) {
          opt.classList.add('inactive');
        }
      });
    } else if (type === 'barber' && barber) {
      document
        .querySelectorAll(`.rating-option[data-type="barber"][data-barber="${barber}"]`)
        .forEach((opt) => {
          if (opt !== option) {
            opt.classList.add('inactive');
          }
        });
    }

    const icon = option.querySelector('i');
    if (icon) {
      icon.classList.add('bounce');
      setTimeout(() => {
        icon.classList.remove('bounce');
      }, 400);
    }

    updateConditionalSections();
    updateSummarySection();
    updateProgressBar();
  }

  function updateConditionalSections() {
    const serviceRating = state.ratings.service;
    const barberRatings = Object.values(state.ratings.barbers);
    const allBarbersRated = barberRatings.length === state.barbers.length;

    // Determine satisfaction levels
    const lowServiceRating = serviceRating !== null && serviceRating <= 3;
    const highServiceRating = serviceRating !== null && serviceRating >= 4;
    const hasLowBarberRating = barberRatings.some((rating) => rating <= 3);
    const hasHighBarberRating = barberRatings.some((rating) => rating >= 4);
    const allBarbersHigh = allBarbersRated && barberRatings.every((rating) => rating >= 4);
    const allBarbersLow = allBarbersRated && barberRatings.every((rating) => rating <= 3);

    // Hide both sections initially
    section4.classList.add('hidden');
    section5.classList.add('hidden');

    const serviceDissatisfactionDiv = document.getElementById('serviceDissatisfaction');
    const barberDissatisfactionDiv = document.getElementById('barberDissatisfaction');
    const serviceSatisfactionDiv = document.getElementById('serviceSatisfaction');
    const barberSatisfactionDiv = document.getElementById('barberSatisfaction');

    // Show dissatisfaction section (section4) if any low ratings
    if (lowServiceRating || hasLowBarberRating) {
      section4.classList.remove('hidden');

      // Show/hide relevant parts
      if (lowServiceRating) {
        serviceDissatisfactionDiv.style.display = 'block';
      } else {
        serviceDissatisfactionDiv.style.display = 'none';
      }

      if (hasLowBarberRating) {
        barberDissatisfactionDiv.style.display = 'block';
      } else {
        barberDissatisfactionDiv.style.display = 'none';
      }
    }

    // Show satisfaction section (section5) if any high ratings
    if (highServiceRating || hasHighBarberRating) {
      section5.classList.remove('hidden');

      // Show/hide relevant parts
      if (highServiceRating) {
        serviceSatisfactionDiv.style.display = 'block';
      } else {
        serviceSatisfactionDiv.style.display = 'none';
      }

      if (hasHighBarberRating) {
        barberSatisfactionDiv.style.display = 'block';
      } else {
        barberSatisfactionDiv.style.display = 'none';
      }
    }
  }

  function updateSummarySection() {
    servicePriceDisplay.textContent = formatCurrency(state.servicePrice);
    promoNameDisplay.textContent = state.promoName || 'Không có';
    promotionDisplay.textContent =
      state.promotionAmount > 0 ? `-${formatCurrency(state.promotionAmount)}` : '0 VNĐ';
    tipDisplay.textContent = formatCurrency(state.tipAmount);
    totalDisplay.textContent = formatCurrency(state.totalAmount);
  }

  function validateAndSubmit() {
    if (!state.ratings.service) {
      showWarning('Vui lòng đánh giá dịch vụ trước khi gửi');
      document.getElementById('section2').scrollIntoView({ behavior: 'smooth' });
      return;
    }

    const missingRatings = state.barbers.filter((barber) => !state.ratings.barbers[barber]);
    if (missingRatings.length > 0) {
      showWarning(`Vui lòng đánh giá tất cả thợ cắt: ${missingRatings.join(', ')}`);
      document.getElementById('section3').scrollIntoView({ behavior: 'smooth' });
      return;
    }

    submitButton.classList.add('hidden');
    successMessage.classList.add('show');
    submitForm();
  }

  async function submitForm() {
    try {
      // Build dissatisfaction feedback
      const serviceDissatisfaction =
        state.dissatisfactionReasons.service.length > 0
          ? `Không hài lòng dịch vụ: ${state.dissatisfactionReasons.service.join(', ')}${
              state.otherReason.service ? '; ' + state.otherReason.service : ''
            }`
          : state.otherReason.service
          ? `Góp ý dịch vụ: ${state.otherReason.service}`
          : '';

      const barberDissatisfaction =
        state.dissatisfactionReasons.barbers.length > 0
          ? `Không hài lòng thợ: ${state.dissatisfactionReasons.barbers.join(', ')}${
              state.otherReason.barbers ? '; ' + state.otherReason.barbers : ''
            }`
          : state.otherReason.barbers
          ? `Góp ý thợ: ${state.otherReason.barbers}`
          : '';

      // Build satisfaction feedback
      const serviceSatisfaction =
        state.satisfactionReasons.service.length > 0
          ? `Hài lòng dịch vụ: ${state.satisfactionReasons.service.join(', ')}`
          : '';

      const barberSatisfaction =
        state.satisfactionReasons.barbers.length > 0
          ? `Hài lòng thợ: ${state.satisfactionReasons.barbers.join(', ')}`
          : '';

      const satisfactionComment = state.satisfactionComment
        ? `Chia sẻ thêm: ${state.satisfactionComment}`
        : '';

      // Combine all feedback
      const allFeedback = [
        serviceDissatisfaction,
        barberDissatisfaction,
        serviceSatisfaction,
        barberSatisfaction,
        satisfactionComment,
      ]
        .filter((f) => f)
        .join(' | ');

      // Xác định mode dựa trên URL hoặc logic (ví dụ: tham số mode từ URL)
      const mode = 'online';
      const endpoint = mode === 'offline' ? 'save-reviews?mode=offline' : 'save-reviews';

      const reviewPromises = state.barbers.map(async (barber) => {
        const reviewData = {
          invoice_id: state.invoiceId,
          customer_id: state.customerId,
          customer_name: state.customerName,
          customer_phone: state.customerPhone,
          service_rating: state.ratings.service,
          staff_rating: state.ratings.barbers[barber],
          feedback: allFeedback || null,
        };

        console.log(`Sending review data for barber: ${barber} to ${endpoint}`, reviewData);
        try {
          const response = await fetchAPI(endpoint, {
            method: 'POST',
            body: JSON.stringify(reviewData),
          });
          console.log(`Received response for barber: ${barber}`, response);
          return { success: true, data: response };
        } catch (error) {
          console.error(`Error submitting review for barber: ${barber}`, error);
          return { success: false, message: error.message, barber };
        }
      });

      const results = await Promise.all(reviewPromises);

      const errors = results.filter((result) => !result.success);
      if (errors.length > 0) {
        const errorMessages = errors.map((err) => `Thợ ${err.barber}: ${err.message}`).join('; ');
        console.warn(`Một số đánh giá không được lưu: ${errorMessages}`);
        if (results.some((result) => result.success)) {
          console.log('Ít nhất một đánh giá đã được lưu thành công, tiếp tục hiển thị kết quả.');
        } else {
          throw new Error(`Không lưu được đánh giá nào: ${errorMessages}`);
        }
      }

      document.querySelectorAll('.section:not(#section7)').forEach((section) => {
        section.classList.add('hidden');
      });
      document.getElementById('section7').classList.remove('hidden');
      document.getElementById('section7').classList.add('revealed');
      state.currentStep = 4;
      progressFill.style.width = '100%';

      displayTransactionDetails();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (error) {
      console.error('Lỗi chi tiết khi gửi đánh giá:', error);
      showError('Lỗi khi gửi đánh giá: ' + error.message);
      submitButton.classList.remove('hidden');
      successMessage.classList.remove('show');
    }
  }

  function displayTransactionDetails() {
    finalAmountDisplay.textContent = formatCurrency(state.totalAmount);
    transactionIdDisplay.textContent = state.invoiceId;
    transactionDateFinalDisplay.textContent = state.transactionDate;

    serviceRatingDisplay.textContent = getRatingText(state.ratings.service);

    serviceStarsDisplay.innerHTML = '';
    for (let i = 0; i < 5; i++) {
      const star = document.createElement('i');
      star.className = `fas ${
        i < state.ratings.service ? 'fa-star text-yellow-400' : 'fa-star text-gray-300'
      } mx-1`;
      serviceStarsDisplay.appendChild(star);
    }

    barberRatingsDisplay.innerHTML = '';
    state.barbers.forEach((barber) => {
      const div = document.createElement('div');
      div.className = 'flex justify-between items-center mb-3';
      div.innerHTML = `
                Thợ:
                <div>
                    <span class="font-semibold text-blue-800 mr-3">
                        ${getRatingText(state.ratings.barbers[barber])}
                    </span>
                    <span>
                        ${Array(5)
                          .fill()
                          .map(
                            (_, i) => `
                            <i class="fas ${
                              i < state.ratings.barbers[barber]
                                ? 'fa-star text-yellow-400'
                                : 'fa-star text-gray-300'
                            } mx-1"></i>
                        `
                          )
                          .join('')}
                    </span>
                </div>
            `;
      barberRatingsDisplay.appendChild(div);
    });
  }

  function getRatingText(rating) {
    switch (rating) {
      case 1:
        return 'Rất Tệ';
      case 2:
        return 'Chê Nha';
      case 3:
        return 'Không Ưng Lắm';
      case 4:
        return 'Hài Lòng';
      case 5:
        return 'Siêu Hài Lòng';
      default:
        return '';
    }
  }

  function setCurrentDate() {
    const currentDate = new Date();
    state.transactionDate = currentDate.toLocaleString('vi-VN', {
      hour: '2-digit',
      minute: '2-digit',
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
    });
    document.getElementById('transactionDate').textContent = state.transactionDate;
    transactionDateFinalDisplay.textContent = state.transactionDate;
  }

  function resetForm() {
    // Giữ lại dữ liệu hóa đơn
    const invoiceData = {
      invoiceId: state.invoiceId,
      customerId: state.customerId,
      customerName: state.customerName,
      customerPhone: state.customerPhone,
      membershipLabel: state.membershipLabel,
      services: state.services,
      barbers: state.barbers,
      servicePrice: state.servicePrice,
      promotionAmount: state.promotionAmount,
      promoCode: state.promoCode,
      promoName: state.promoName,
      tipAmount: state.tipAmount,
      totalAmount: state.totalAmount,
      transactionDate: state.transactionDate,
    };

    // Reset đánh giá
    state.ratings = { service: null, barbers: {} };
    state.dissatisfactionReasons = { service: [], barbers: [] };
    state.satisfactionReasons = { service: [], barbers: [] };
    state.otherReason = { service: '', barbers: '' };
    state.satisfactionComment = '';
    state.currentStep = 0;

    // Khôi phục dữ liệu hóa đơn
    Object.assign(state, invoiceData);

    document.querySelectorAll('.section').forEach((section) => {
      section.classList.remove('hidden');
      section.classList.remove('revealed');
    });
    document.getElementById('section4').classList.add('hidden');
    document.getElementById('section5').classList.add('hidden');
    document.getElementById('section7').classList.add('hidden');
    submitButton.classList.remove('hidden');
    successMessage.classList.remove('show');

    document.querySelectorAll('.rating-option').forEach((option) => {
      option.classList.remove('active', 'inactive', 'bg-blue-100');
      option.style.opacity = '';
    });

    // Reset chips
    document.querySelectorAll('.satisfaction-chip, .dissatisfaction-chip').forEach((chip) => {
      chip.classList.remove('selected');
    });

    // Reset textareas
    if (otherServiceReasonInput) otherServiceReasonInput.value = '';
    if (otherBarberReasonInput) otherBarberReasonInput.value = '';
    if (satisfactionCommentInput) satisfactionCommentInput.value = '';

    customerNameDisplay.textContent = state.customerName;
    customerPhoneDisplay.textContent = state.customerPhone;
    promoCodeDisplay.textContent = state.promoCode;
    totalDisplay.textContent = formatCurrency(state.totalAmount);
    summaryServiceName.textContent =
      state.services.map((s) => s.service_name).join(', ') || 'Không xác định';
    summaryBarberName.textContent = state.barbers.join(', ') || 'Không xác định';
    servicePriceDisplay.textContent = formatCurrency(state.servicePrice);
    promoNameDisplay.textContent = state.promoName || 'Không có';
    promotionDisplay.textContent =
      state.promotionAmount > 0 ? `-${formatCurrency(state.promotionAmount)}` : '0 VNĐ';
    tipDisplay.textContent = formatCurrency(state.tipAmount);
    document.getElementById('invoiceId').textContent = state.invoiceId || 'Đang tải...';
    document.getElementById('transactionDate').textContent = state.transactionDate;
    transactionDateFinalDisplay.textContent = state.transactionDate;
    document.getElementById('membershipLabel').textContent = state.membershipLabel;
    barberRatingsContainer.innerHTML = '';
    barberRatingsDisplay.innerHTML = '';

    updateConditionalSections();
    updateProgressBar();
    attachRatingEventListeners();
    setupChipListeners();
    setupScrollReveal();
    renderBarberRatings();
  }

  function updateProgressBar() {
    let progress;
    if (state.currentStep === 0) {
      progress = 0;
    } else if (state.currentStep === 1) {
      progress = 33;
    } else if (state.currentStep === 2) {
      progress = 66;
    } else if (state.currentStep === 4) {
      progress = 100;
    } else {
      progress = (state.currentStep / state.totalSteps) * 100;
    }
    progressFill.style.width = `${progress}%`;
  }
});
