/**
 * Customer Registration JavaScript
 * Xử lý logic đăng ký thành viên
 */

(function () {
  'use strict';

  // Lấy tham số từ URL
  function getUrlParameter(name) {
    name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
    const regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
    const results = regex.exec(location.search);

    if (results === null) {
      return '';
    }

    try {
      // Try to decode, handle malformed URI
      return decodeURIComponent(results[1].replace(/\+/g, ' '));
    } catch (e) {
      console.warn(`⚠️ Cannot decode parameter "${name}":`, results[1], e);
      // Try to fix common encoding issues
      let fixed = results[1].replace(/\+/g, ' ');

      // Remove invalid percent-encoded sequences (like %F2)
      fixed = fixed.replace(/%[0-9A-Fa-f]{0,1}(?![0-9A-Fa-f])|%[8-9A-Fa-f][0-9A-Fa-f]/g, '');

      // Try to decode again after cleaning
      try {
        return decodeURIComponent(fixed);
      } catch (e2) {
        // If still fails, return cleaned raw value
        return fixed.replace(/%[0-9A-Fa-f]{2}/g, '');
      }
    }
  }

  // Lưu các tham số Zalo từ URL
  const userIdZalo = getUrlParameter('user_id');
  const userIsFollower = getUrlParameter('user_is_follower');
  const displayName = getUrlParameter('display_name');

  // Params from Zalo Social Login redirect
  const prefilledPhone = getUrlParameter('phone');
  const prefilledName = getUrlParameter('zalo_name');
  const zaloSocialId = getUrlParameter('zalo_id');

  // DOM Elements
  const form = document.getElementById('registrationForm');
  const submitBtn = document.getElementById('submitBtn');
  const modalOverlay = document.getElementById('modalOverlay');
  const modalIcon = document.getElementById('modalIcon');
  const modalTitle = document.getElementById('modalTitle');
  const modalMessage = document.getElementById('modalMessage');
  const modalBtn = document.getElementById('modalBtn');
  const modalBtnMember = document.getElementById('modalBtnMember');
  const phoneInput = document.getElementById('phone');
  const nameInput = document.getElementById('name');

  // Auto-fill from URL params (Zalo Social Login redirect)
  if (phoneInput && prefilledPhone) {
    // Normalize: add leading 0 if needed
    let phoneVal = prefilledPhone;
    if (phoneVal.length === 9 && !phoneVal.startsWith('0')) {
      phoneVal = '0' + phoneVal;
    }
    phoneInput.value = phoneVal;
  }
  if (nameInput && (prefilledName || displayName)) {
    nameInput.value = (prefilledName || displayName).toUpperCase();
  }

  // Biến lưu số điện thoại để dùng cho redirect
  let registeredPhone = '';

  // Form submit handler
  if (form) {
    // Remove inline onsubmit to allow JS handling
    form.removeAttribute('onsubmit');

    // Mark as JS attached
    form.dataset.jsAttached = 'true';

    form.addEventListener('submit', async (e) => {
      e.preventDefault();

      // Validate form
      if (!form.checkValidity()) {
        form.reportValidity();
        return;
      }

      // Get form data
      const formData = {
        customer_phone: document.getElementById('phone').value.trim(),
        customer_name: document.getElementById('name').value.trim(),
        customer_birthday: document.getElementById('birthday').value || null,
        gender: document.getElementById('gender').value || null,
        email: document.getElementById('email').value.trim() || null,
        address: document.getElementById('address').value.trim() || null,
        id_zalo: zaloSocialId || userIdZalo || null,
        name_zalo: displayName || prefilledName || null,
        follower_zalo: userIsFollower || null,
      };

      // Show loading
      submitBtn.classList.add('loading');
      submitBtn.disabled = true;

      try {
        // Call API
        const response = await fetch('/wp-json/vg/v1/customer-registration', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(formData),
        });

        const data = await response.json();

        // Debug: Log full response để kiểm tra
        console.log('=== API Response ===');
        console.log('Full response:', data);
        console.log('Customer data:', data.customer);

        // Hide loading
        submitBtn.classList.remove('loading');
        submitBtn.disabled = false;

        if (data.success) {
          // Lưu số điện thoại để dùng cho nút "Ưu đãi thành viên"
          registeredPhone = data.customer?.customer_phone || formData.customer_phone;

          // Show success modal
          showModal(
            'success',
            'Thành công!',
            data.message || 'Đăng ký thành viên thành công!',
            () => {
              // Reset form sau khi đóng modal
              form.reset();
              registeredPhone = ''; // Clear phone
            }
          );
        } else {
          // Show error modal
          showModal('error', 'Lỗi!', data.message || 'Đã xảy ra lỗi. Vui lòng thử lại.', null);
        }
      } catch (error) {
        console.error('Registration error:', error);

        // Hide loading
        submitBtn.classList.remove('loading');
        submitBtn.disabled = false;

        // Show error modal
        showModal(
          'error',
          'Lỗi!',
          'Không thể kết nối đến server. Vui lòng kiểm tra kết nối mạng.',
          null
        );
      }
    });
  }

  // Show modal function
  function showModal(type, title, message, onClose) {
    const icon = modalIcon.querySelector('i');
    const promoInfoBox = document.getElementById('promoInfoBox');

    if (type === 'success') {
      modalIcon.className = 'modal-icon success';
      icon.className = 'fas fa-check-circle';
      // Hiển thị thông tin mã khuyến mãi khi đăng ký thành công
      if (promoInfoBox) promoInfoBox.style.display = 'block';
    } else {
      modalIcon.className = 'modal-icon error';
      icon.className = 'fas fa-exclamation-circle';
      // Ẩn thông tin mã khuyến mãi khi có lỗi
      if (promoInfoBox) promoInfoBox.style.display = 'none';
    }

    modalTitle.textContent = title;
    modalMessage.textContent = message;
    modalOverlay.classList.add('active');

    // Handle close button
    modalBtn.onclick = () => {
      modalOverlay.classList.remove('active');
      if (onClose) onClose();
    };

    // Handle "Ưu đãi thành viên" button (chỉ hiển thị khi success)
    if (modalBtnMember) {
      if (type === 'success') {
        modalBtnMember.style.display = 'inline-flex';
        modalBtnMember.onclick = () => {
          modalOverlay.classList.remove('active');
          // Redirect to customer-member page with phone parameter
          const phone = registeredPhone || '';
          window.location.href = `/customer-member?phone=${encodeURIComponent(phone)}`;
        };
      } else {
        modalBtnMember.style.display = 'none';
      }
    }

    // Close on overlay click
    modalOverlay.onclick = (e) => {
      if (e.target === modalOverlay) {
        modalOverlay.classList.remove('active');
        if (onClose) onClose();
      }
    };
  }

  // Input formatting - Phone
  if (phoneInput) {
    phoneInput.addEventListener('input', (e) => {
      e.target.value = e.target.value.replace(/[^0-9]/g, '');
    });
  }

  // Auto uppercase name
  if (nameInput) {
    nameInput.addEventListener('blur', (e) => {
      e.target.value = e.target.value.trim().toUpperCase();
    });
  }
})();
