/** Escape chuỗi để nhét vào thuộc tính HTML. */
function escapeAttr(text) {
  return String(text ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}




/**
 * Bảng tra nhanh trạng thái + SĐT của thợ, gom từ mọi lần tải danh sách thợ.
 * Dùng chung cho home.js và home-booking-branch.js.
 */
window.checkinStaffInfo = window.checkinStaffInfo || {};

function updateStaffInfoMap(list) {
  (list || []).forEach((h) => {
    if (!h || !h.hairdresser_name) return;
    window.checkinStaffInfo[h.hairdresser_name] = {
      status: String(h.hairdresser_status || '').toUpperCase(),
      phone: String(h.phone || '').trim(),
    };
  });
}

/**
 * Thợ đang tạm dừng thì không cho đặt lịch qua web: trả về câu thông báo
 * kèm SĐT để khách liên hệ riêng. Thợ bình thường trả về null.
 */
function getPausedStaffNotice(name) {
  const info = window.checkinStaffInfo[name];
  if (!info || info.status !== 'PAUSE') return null;
  return info.phone
    ? `Thợ ${name} hiện không còn hoạt động tại Shop. Quý khách vui lòng liên hệ ${info.phone} để đặt lịch riêng. Xin cảm ơn.`
    : `Thợ ${name} hiện không còn hoạt động tại Shop. Quý khách vui lòng liên hệ Shop để được hỗ trợ. Xin cảm ơn.`;
}
window.getPausedStaffNotice = getPausedStaffNotice;
window.updateStaffInfoMap = updateStaffInfoMap;

/**
 * Show page loading overlay
 */
function showPageLoading() {
  // Check if overlay already exists
  if (document.querySelector('.checkin-glassmorphism-loader')) {
    return;
  }

  const overlay = document.createElement('div');
  overlay.className = 'checkin-glassmorphism-loader';
  overlay.innerHTML = `
    <div class="checkin-glass-container">
      <div class="checkin-spinner-wrapper">
        <div class="checkin-spinner-inner"></div>
      </div>
      <div class="checkin-loader-text">Đang tải</div>
    </div>
  `;
  document.body.appendChild(overlay);
}

/**
 * Hide page loading overlay
 */
function hidePageLoading() {
  const overlay = document.querySelector('.checkin-glassmorphism-loader');
  if (overlay) {
    overlay.style.opacity = '0';
    setTimeout(() => {
      overlay.remove();
    }, 300);
  }
}

// Throttle utility for scroll performance
const throttle = (fn, wait) => {
  let lastTime = 0;
  return (...args) => {
    const now = Date.now();
    if (now - lastTime >= wait) {
      lastTime = now;
      fn(...args);
    }
  };
};

// Initialize Modern Image Loader
let imageLoader = null;
if (typeof ModernImageLoader !== 'undefined') {
  imageLoader = new ModernImageLoader({
    rootMargin: '300px 0px',
    threshold: 0.01,
  });
}

document.addEventListener('DOMContentLoaded', function () {
  // Preloader
  const preloader = document.querySelector('.preloader');
  if (preloader) {
    window.addEventListener('load', function () {
      preloader.classList.add('hidden');
      setTimeout(() => {
        document.body.classList.add('loaded');
      }, 1000);
    });
  }

  // Mobile Menu Toggle
  const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
  const mobileMenu = document.querySelector('.mobile-menu');
  const mobileMenuClose = document.querySelector('.mobile-menu-close');

  if (mobileMenuBtn && mobileMenu && mobileMenuClose) {
    mobileMenuBtn.addEventListener('click', function () {
      mobileMenu.classList.toggle('active');
      document.body.style.overflow = mobileMenu.classList.contains('active') ? 'hidden' : 'auto';
    });

    mobileMenuClose.addEventListener('click', function () {
      mobileMenu.classList.remove('active');
      document.body.style.overflow = 'auto';
    });

    document.querySelectorAll('.mobile-menu a').forEach((link) => {
      link.addEventListener('click', function () {
        mobileMenu.classList.remove('active');
        document.body.style.overflow = 'auto';
      });
    });
  }

  // Header scroll effect + Back to top button — combined throttled handler
  const header = document.querySelector('.header');
  const backToTop = document.querySelector('.back-to-top');

  if (header || backToTop) {
    // rAF ticking — class chỉ toggle đúng nhịp frame, không lệch pha gây giật
    let headerTicking = false;
    const onScroll = () => {
      if (headerTicking) return;
      headerTicking = true;
      requestAnimationFrame(() => {
        const scrollY = window.scrollY;
        if (header) {
          header.classList.toggle('scrolled', scrollY > 100);
        }
        if (backToTop) {
          backToTop.classList.toggle('active', scrollY > 300);
        }
        headerTicking = false;
      });
    };

    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  if (backToTop) {
    backToTop.addEventListener('click', function (e) {
      e.preventDefault();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  // Mobile Native Navigation Bar - Scroll Behavior
  const mobileNav = document.getElementById('mobileNativeNav');
  const navItems = document.querySelectorAll('.mobile-nav-item[data-section]');

  if (mobileNav && window.innerWidth <= 768) {
    let lastScrollY = window.scrollY;
    let ticking = false;

    // Hide/show nav on scroll
    window.addEventListener('scroll', () => {
      if (!ticking) {
        window.requestAnimationFrame(() => {
          const currentScrollY = window.scrollY;

          if (currentScrollY > lastScrollY && currentScrollY > 100) {
            // Scrolling down - hide nav
            mobileNav.classList.add('hidden');
          } else {
            // Scrolling up - show nav
            mobileNav.classList.remove('hidden');
          }

          lastScrollY = currentScrollY;
          ticking = false;
        });
        ticking = true;
      }
    });

    // Update active state based on section in view
    const sections = document.querySelectorAll('section[id]');
    const navObserverOptions = {
      root: null,
      rootMargin: '-50% 0px -50% 0px',
      threshold: 0,
    };

    const navObserver = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const sectionId = entry.target.getAttribute('id');
          navItems.forEach((item) => {
            const itemSection = item.getAttribute('data-section');
            if (itemSection === sectionId) {
              navItems.forEach((i) => i.classList.remove('active'));
              item.classList.add('active');
            }
          });
        }
      });
    }, navObserverOptions);

    sections.forEach((section) => navObserver.observe(section));

    // Smooth scroll on nav click
    navItems.forEach((item) => {
      item.addEventListener('click', (e) => {
        e.preventDefault();
        const sectionId = item.getAttribute('data-section');
        const section = document.getElementById(sectionId);
        if (section) {
          section.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      });
    });
  }

  // Scroll Reveal Animations — handled by scrollRevealObserver below
  // (removed duplicate revealOnScroll IntersectionObserver)

  // Hero Cinema — cuộn: nhân vật phóng to + trôi vào giữa, chữ đẩy lên & mờ;
  // khi nhân vật vào giữa thì tự luân chuyển các kiểu tóc.
  const heroCinema = document.querySelector('.hero-cinema');
  if (heroCinema) {
    const copy = heroCinema.querySelector('.hero-copy');
    const charWrap = heroCinema.querySelector('.hero-char-wrap');
    const chars = Array.from(heroCinema.querySelectorAll('.hero-char'));
    const thumbs = Array.from(heroCinema.querySelectorAll('.hero-hair-thumb'));
    const rail = heroCinema.querySelector('.hero-hair-rail');
    const dots = Array.from(heroCinema.querySelectorAll('.hero-dot'));
    const dotsWrap = heroCinema.querySelector('.hero-dots');
    const scrollHint = heroCinema.querySelector('.hero-scroll-hint');
    const styleCount = chars.length || 1;
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    // 3 nhịp cuộn đều nhau: nhịp 1 = nhân vật ra giữa (+ mẫu 1), nhịp 2 = mẫu 2, nhịp 3 = mẫu 3.
    // Cuộn đủ 3 nhịp mới rời hero; cuộn lên trả ngược từng nhịp.
    // CENTER_AT = 1 nhịp = 1/số-kiểu (canh giữa xong đúng lúc hết nhịp 1).
    const CENTER_AT = 1 / (chars.length || 1);

    let activeStyle = 1;
    let heroInView = true;
    let introStarted = false;
    let introDone = false;
    let rendered = 0; // tiến độ đã render (bám theo cuộn)
    let replaying = false; // đang chạy chuyển cảnh vòng lặp (khoá update theo cuộn)
    let metrics = { dx: 0, dy: 0, smax: 1.24 };

    // position:sticky chết nếu ancestor có overflow != visible (app-container, wrapper theme...)
    // → gỡ tại chỗ; body vẫn giữ overflow-x:hidden nên không tràn ngang
    let heroAncestor = heroCinema.parentElement;
    while (heroAncestor && heroAncestor !== document.body) {
      const ancStyle = getComputedStyle(heroAncestor);
      if (
        ancStyle.overflow !== 'visible' ||
        ancStyle.overflowX !== 'visible' ||
        ancStyle.overflowY !== 'visible'
      ) {
        heroAncestor.style.setProperty('overflow', 'visible', 'important');
      }
      heroAncestor = heroAncestor.parentElement;
    }

    function isMobile() {
      return window.innerWidth <= 768;
    }

    // Đo tâm nhân vật khi CHƯA transform để biết quãng dời vào giữa màn hình
    function measure() {
      const prev = charWrap.style.transform;
      charWrap.style.transform = 'none';
      const r = charWrap.getBoundingClientRect();
      charWrap.style.transform = prev;
      metrics.dx = window.innerWidth / 2 - (r.left + r.width / 2);
      // Mobile: phóng to mạnh (đầu lên cao theo transform-origin, thân fill xuống đáy) + nâng nhẹ
      metrics.dy = isMobile() ? -window.innerHeight * 0.05 : -window.innerHeight * 0.02;
      metrics.smax = isMobile() ? 1.35 : 1.5;
    }

    function crossfadeChar(styleId) {
      activeStyle = styleId;
      chars.forEach((c) => c.classList.toggle('is-active', +c.dataset.style === styleId));
      thumbs.forEach((t) => t.classList.toggle('is-current', +t.dataset.style === styleId));
      dots.forEach((d) => d.classList.toggle('is-current', +d.dataset.style === styleId));
    }

    // Vẽ 1 khung theo tiến độ t (0 = ban đầu, 1 = nhân vật ở giữa & phóng to)
    function applyFrame(t) {
      charWrap.style.transform =
        'translate(' +
        (metrics.dx * t).toFixed(2) +
        'px,' +
        (metrics.dy * t).toFixed(2) +
        'px) scale(' +
        (1 + (metrics.smax - 1) * t).toFixed(4) +
        ')';

      const copyFade = Math.max(0, 1 - t * 1.35);
      copy.style.transform = 'translateY(' + (-72 * t).toFixed(1) + 'px)';
      copy.style.opacity = copyFade.toFixed(3);
      copy.style.pointerEvents = copyFade < 0.05 ? 'none' : '';

      // Rail chuyển trạng thái side <-> showcase bằng class (CSS + media query lo giao diện,
      // để mobile hiện hàng ngang trên đầu còn desktop ẩn — không fix cứng inline).
      heroCinema.classList.toggle('is-showcase', t > 0.8);
      if (dotsWrap) {
        dotsWrap.style.opacity = Math.max(0, Math.min(1, (t - 0.7) / 0.3)).toFixed(3);
      }
      if (scrollHint) scrollHint.style.opacity = t > 0.05 ? '0' : '0.85';
    }

    // Tiến độ cuộn thô trong hero (0 = đầu, 1 = cuối section)
    function rawProgress() {
      const rect = heroCinema.getBoundingClientRect();
      const total = rect.height - window.innerHeight;
      if (total <= 0) return 0;
      return Math.min(1, Math.max(0, -rect.top / total));
    }
    function targetProgress() {
      return Math.min(1, rawProgress() / CENTER_AT);
    }

    // Kiểu tóc bám theo cuộn: pha showcase (CENTER_AT→1) chia đều cho số kiểu.
    // Cuộn hết hero = đã xem đủ; cuộn ngược lên = trả về đúng kiểu trước đó.
    function styleFromProgress(p) {
      // Chia toàn bộ hero thành styleCount nhịp đều nhau: nhịp i -> mẫu i.
      return Math.min(styleCount, Math.floor(p * styleCount) + 1);
    }

    // Map trực tiếp vị trí cuộn -> khung hình (transition CSS ngắn lo phần mượt).
    // Không dùng rAF tự-chuỗi vì trình duyệt tạm dừng rAF ở tab nền.
    function update() {
      if (!introDone || replaying) return;
      const p = rawProgress();
      rendered = Math.min(1, p / CENTER_AT);
      applyFrame(rendered);
      const idx = styleFromProgress(p);
      if (idx !== activeStyle) crossfadeChar(idx);
    }
    function kick() {
      if (!introDone) {
        if (targetProgress() > 0.02) finishIntro();
        return;
      }
      update();
    }

    function finishIntro() {
      if (introDone) return;
      introDone = true;
      heroCinema.classList.remove('intro-play');
      heroCinema.classList.add('intro-done');
      measure();
      update(); // reload/scroll giữa hero: vào đúng trạng thái + đúng kiểu tóc, không nhảy
    }

    // Intro tách lớp khi trang load xong; sau intro thì trao quyền cho JS
    function playIntro() {
      if (introStarted) return;
      introStarted = true;
      if (reduceMotion) {
        heroCinema.classList.add('intro-done');
        finishIntro();
        kick();
        return;
      }
      heroCinema.classList.add('intro-play');
      setTimeout(() => {
        finishIntro();
        kick();
      }, 2100); // khớp tổng thời lượng intro (delay + duration)
    }
    if (document.readyState === 'complete') {
      playIntro();
    } else {
      window.addEventListener('load', playIntro);
      setTimeout(playIntro, 3500); // fallback nếu resource chậm
    }

    window.addEventListener('scroll', kick, { passive: true });
    window.addEventListener('resize', () => {
      if (introDone) measure();
      kick();
    });

    if ('IntersectionObserver' in window) {
      new IntersectionObserver((entries) => {
        heroInView = entries[0].isIntersecting;
        if (heroInView) kick();
      }).observe(heroCinema);
    }

    // Bấm thumbnail: cuộn tới đúng đoạn showcase của kiểu tóc đó (style theo cuộn sẽ tự khớp)
    thumbs.forEach((thumb) => {
      thumb.addEventListener('click', () => {
        const idx = +thumb.dataset.style;
        const heroTop = heroCinema.getBoundingClientRect().top + window.pageYOffset;
        const total = heroCinema.offsetHeight - window.innerHeight;
        const p = (idx - 0.5) / styleCount; // giữa nhịp của mẫu đó
        window.scrollTo({
          top: heroTop + total * p,
          behavior: reduceMotion ? 'auto' : 'smooth',
        });
      });
    });
    // Vòng lặp: cuộn hết trang rồi cuộn tiếp → nhảy về đầu và REPLAY hero ngược lại
    // (nhân vật zoom-out về vị trí header + chữ/nút trái fade mờ→rõ) → nối liền chính header.
    function playLoopIn() {
      if (replaying) return;
      replaying = true;
      window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
      crossfadeChar(1); // về mẫu đầu (Sidepart) như trạng thái header ban đầu
      if (reduceMotion) {
        applyFrame(0);
        replaying = false;
        return;
      }
      // Bắt đầu ở trạng thái "đã vào giữa + phóng to", chữ ẩn — KHÔNG transition
      charWrap.style.transition = 'none';
      copy.style.transition = 'none';
      applyFrame(1);
      void charWrap.offsetHeight; // reflow để chốt trạng thái bắt đầu
      // Rồi zoom-out về vị trí header + chữ/nút fade vào (transition dài)
      const DUR = '1.15s';
      const E = 'cubic-bezier(0.22, 1, 0.36, 1)';
      charWrap.style.transition = 'transform ' + DUR + ' ' + E;
      copy.style.transition = 'transform ' + DUR + ' ' + E + ', opacity ' + DUR + ' ' + E;
      applyFrame(0);
      setTimeout(() => {
        charWrap.style.transition = '';
        copy.style.transition = '';
        replaying = false;
        update();
      }, 1220);
    }

    function atPageBottom() {
      return (
        window.innerHeight + Math.ceil(window.scrollY) >=
        document.documentElement.scrollHeight - 2
      );
    }

    window.addEventListener(
      'wheel',
      (e) => {
        if (!replaying && e.deltaY > 0 && atPageBottom()) playLoopIn();
      },
      { passive: true }
    );

    let loopTouchY = null;
    window.addEventListener(
      'touchstart',
      (e) => {
        loopTouchY = e.touches[0].clientY;
      },
      { passive: true }
    );
    window.addEventListener(
      'touchmove',
      (e) => {
        if (replaying || loopTouchY === null) return;
        if (loopTouchY - e.touches[0].clientY > 40 && atPageBottom()) playLoopIn();
      },
      { passive: true }
    );
  }

  // Smooth scrolling for anchor links
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener('click', function (e) {
      if (this.getAttribute('href') === '#') {
        e.preventDefault();
        return;
      }

      e.preventDefault();
      const targetId = this.getAttribute('href');
      const targetElement = document.querySelector(targetId);

      if (targetElement) {
        const headerHeight = document.querySelector('.header')?.offsetHeight || 0;
        const targetPosition =
          targetElement.getBoundingClientRect().top + window.pageYOffset - headerHeight;
        window.scrollTo({ top: targetPosition, behavior: 'smooth' });
      }
    });
  });

  // Animation on scroll - OPTIMIZED with IntersectionObserver for smooth reveal
  const revealedElements = new Set();

  // Use IntersectionObserver for better performance
  const scrollRevealObserver = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting && !revealedElements.has(entry.target)) {
          revealedElements.add(entry.target);
          // Use RAF for smooth animation
          requestAnimationFrame(() => {
            entry.target.classList.add('revealed');
          });
        }
      });
    },
    {
      threshold: 0.1,
      rootMargin: '0px 0px -50px 0px', // Trigger slightly before fully visible
    },
  );

  function initScrollReveal() {
    const elements = document.querySelectorAll(
      '.section, .about-content, .features-content, .service-card, .team-member, .product-card, .gallery-item, .team-card-modern, .gallery-item-modern, .feature-card-modern, .stat-card, .contact-item',
    );

    elements.forEach((element) => {
      if (!element.classList.contains('scroll-reveal')) {
        element.classList.add('scroll-reveal');
        scrollRevealObserver.observe(element);
      }
    });
  }

  // Expose for dynamic content
  window.initScrollReveal = initScrollReveal;

  // Initialize
  initScrollReveal();

  // Form submission
  const appointmentForm = document.getElementById('appointment-form');
  if (appointmentForm) {
    appointmentForm.addEventListener('submit', function (e) {
      e.preventDefault();
      toastSuccess('Cảm ơn bạn đã đặt lịch! Chúng tôi sẽ liên hệ lại để xác nhận.');
      this.reset();
    });
  }

  const newsletterForm = document.querySelector('.newsletter-form');
  if (newsletterForm) {
    newsletterForm.addEventListener('submit', function (e) {
      e.preventDefault();
      toastSuccess('Cảm ơn bạn đã đăng ký nhận tin!');
      this.reset();
    });
  }

  // Load Services Section dynamically
  async function loadServicesSection() {
    try {
      // Tải danh sách dịch vụ
      const serviceResponse = await fetch(`${checkinData.restUrl}services`, {
        method: 'GET',
        headers: { 'Content-Type': 'application/json' },
      });
      if (!serviceResponse.ok) throw new Error('Network response was not ok');
      const serviceResult = await serviceResponse.json();
      if (!serviceResult.success)
        throw new Error(serviceResult.message || 'Lỗi khi tải danh sách dịch vụ');
      const services = serviceResult.data;

      // Tải danh sách hình ảnh dịch vụ từ API
      const imageResponse = await fetch(`${checkinData.restUrl}service-images`, {
        method: 'GET',
        headers: { 'Content-Type': 'application/json' },
      });
      if (!imageResponse.ok) throw new Error('Network response was not ok');
      const imageResult = await imageResponse.json();
      if (!imageResult.success)
        throw new Error(imageResult.message || 'Lỗi khi tải danh sách hình ảnh dịch vụ');
      const serviceImages = imageResult.data;

      // Skip blocking preload - let lazy loading handle images
      // Images will be loaded progressively as user scrolls

      // Tìm giá thấp nhất cho các dịch vụ đặc biệt
      const getMinPrice = (serviceNames, excludeChild = true) => {
        const filteredServices = services.filter(
          (s) =>
            serviceNames.some((name) =>
              s.service_name.toLowerCase().includes(name.toLowerCase()),
            ) &&
            (!excludeChild || !s.service_name.toLowerCase().includes('trẻ em')),
        );
        if (filteredServices.length === 0) return null;
        return filteredServices.reduce((min, s) =>
          parseFloat(s.discounted_price || s.service_price) <
          parseFloat(min.discounted_price || min.service_price)
            ? s
            : min,
        );
      };

      // Tìm dịch vụ cắt tóc có service_id nhỏ nhất
      const haircutService = services
        .filter(
          (s) =>
            (s.service_name.toLowerCase().includes('combo') ||
              s.service_name.toLowerCase().includes('cắt tóc')) &&
            !s.service_name.toLowerCase().includes('trẻ em'),
        )
        .sort((a, b) => a.service_id.localeCompare(b.service_id))[0];

      // Tìm giá thấp nhất cho uốn tóc, nhuộm tóc và massage mặt
      const permPrice = getMinPrice(['uốn']);
      const dyePrice = getMinPrice(['nhuộm']);
      const massagePrice = getMinPrice(['massage', 'relax']);

      // Sử dụng IntersectionObserver để hiển thị hình ảnh khi thẻ vào khung nhìn
      const observer = new IntersectionObserver(
        (entries, observer) => {
          entries.forEach((entry) => {
            if (entry.isIntersecting) {
              const card = entry.target;
              const title = card.querySelector('h3').textContent.toLowerCase();
              let priceText = '';
              let imageUrl = '';
              let imageAlt = '';

              requestAnimationFrame(() => {
                // Tìm hình ảnh tương ứng từ API
                const matchingImage = serviceImages.find((img) =>
                  img.service_name.toLowerCase().includes(title),
                );

                if (title.includes('cắt tóc') && haircutService) {
                  priceText = haircutService.discounted_price_formatted
                    ? `${haircutService.discounted_price_formatted}đ`
                    : `${haircutService.service_price_formatted}đ`;
                } else if (title.includes('uốn tóc') && permPrice) {
                  priceText = permPrice.discounted_price_formatted
                    ? `Từ ${permPrice.discounted_price_formatted}đ`
                    : `Từ ${permPrice.service_price_formatted}đ`;
                } else if (title.includes('nhuộm tóc') && dyePrice) {
                  priceText = dyePrice.discounted_price_formatted
                    ? `Từ ${dyePrice.discounted_price_formatted}đ`
                    : `Từ ${dyePrice.service_price_formatted}đ`;
                } else if (title.includes('massage mặt') && massagePrice) {
                  priceText = massagePrice.discounted_price_formatted
                    ? `${massagePrice.discounted_price_formatted}đ`
                    : `${massagePrice.service_price_formatted}đ`;
                } else {
                  // Tìm dịch vụ khớp với tiêu đề
                  const service = services.find((s) =>
                    s.service_name.toLowerCase().includes(title),
                  );
                  if (service) {
                    priceText = service.discounted_price_formatted
                      ? `${service.discounted_price_formatted}đ`
                      : `${service.service_price_formatted}đ`;
                  }
                }

                // Sử dụng hình ảnh từ API nếu có, nếu không thì fallback về placeholder
                if (matchingImage) {
                  imageUrl = matchingImage.image_url;
                  imageAlt = matchingImage.alt;
                } else {
                  // Placeholder image nếu không tìm thấy hình ảnh
                  imageUrl = `${checkinData.pluginUrl}/assets/image/service-section/placeholder.jpg`;
                  imageAlt = 'Hình ảnh dịch vụ mặc định';
                }

                if (priceText) {
                  card.querySelector('.service-price').textContent = priceText;
                }

                // Skip image override for carousel images (already set in PHP)
                const imgElement = card.querySelector('.service-image img');
                const serviceImage = card.querySelector('.service-image');

                if (imgElement && imgElement.classList.contains('service-img-carousel')) {
                  // Carousel image — already has correct src and data-images from PHP
                  // Just mark as loaded for CSS transitions
                  serviceImage.classList.add('loaded');
                } else if (imageUrl) {
                  // Non-carousel image — load from API or fallback
                  imgElement.dataset.src = imageUrl;
                  imgElement.alt = imageAlt;

                  // Let ModernImageLoader handle lazy loading
                  if (imageLoader) {
                    imageLoader.observe([serviceImage]);
                  } else {
                    // Fallback if imageLoader not available
                    imgElement.src = imageUrl;
                    imgElement.onload = () => serviceImage.classList.add('loaded');
                  }
                }
              });

              observer.unobserve(card); // Ngừng quan sát sau khi cập nhật
            }
          });
        },
        {
          threshold: 0.1,
          rootMargin: '200px 0px', // Kích hoạt sớm hơn 200px trước khi vào viewport
        },
      );

      // Quan sát các service-card
      document.querySelectorAll('.service-card').forEach((card) => observer.observe(card));
    } catch (error) {
      console.error('Error loading services section:', error);
      showError('Không thể tải giá và hình ảnh dịch vụ. Vui lòng thử lại.');
    }
  }

  // Initialize service image carousels (modern crossfade + zoom — flicker-free)
  function initServiceCarousels() {
    const TRANSITION =
      'opacity 1s cubic-bezier(0.4, 0, 0.2, 1), transform 1.4s cubic-bezier(0.4, 0, 0.2, 1)';

    const carousels = document.querySelectorAll('.service-img-carousel');

    // Chỉ đổi ảnh khi carousel còn trong viewport — khuất màn hình thì bỏ qua,
    // tránh 6 carousel cùng crossfade ngầm gây giật khi cuộn
    const visibleCarousels = new WeakSet();
    const carouselVisibilityObserver =
      'IntersectionObserver' in window
        ? new IntersectionObserver((entries) => {
            entries.forEach((entry) => {
              if (entry.isIntersecting) {
                visibleCarousels.add(entry.target);
              } else {
                visibleCarousels.delete(entry.target);
              }
            });
          })
        : null;

    carousels.forEach((originalImg) => {
      try {
        const images = JSON.parse(originalImg.dataset.images);
        if (!images || images.length <= 1) return;

        const parent = originalImg.parentElement;
        parent.style.position = 'relative';
        parent.style.overflow = 'hidden';

        if (carouselVisibilityObserver) {
          carouselVisibilityObserver.observe(parent);
        } else {
          visibleCarousels.add(parent);
        }

        // Hide original img, use two new layers instead
        originalImg.style.display = 'none';

        // Create two layers that alternate — no swap-back = no flicker
        const layers = [];
        for (let i = 0; i < 2; i++) {
          const layer = document.createElement('img');
          layer.alt = originalImg.alt;
          layer.loading = 'lazy';
          layer.draggable = false;
          layer.style.cssText = `
            position: absolute; top: 0; left: 0;
            width: 100%; height: 100%; object-fit: cover;
            transition: ${TRANSITION};
          `;
          parent.appendChild(layer);
          layers.push(layer);
        }

        // Layer 0: visible with first image
        layers[0].src = images[0];
        layers[0].style.opacity = '1';
        layers[0].style.transform = 'scale(1)';
        layers[0].style.zIndex = '2';

        // Layer 1: hidden, ready for next
        layers[1].style.opacity = '0';
        layers[1].style.transform = 'scale(1.05)';
        layers[1].style.zIndex = '1';

        let currentIndex = 0;
        let activeLayer = 0;

        setInterval(() => {
          if (document.hidden || !visibleCarousels.has(parent)) return;

          const nextIndex = (currentIndex + 1) % images.length;
          const hiddenLayer = activeLayer === 0 ? 1 : 0;

          // Load next image on hidden layer (transitions off)
          layers[hiddenLayer].style.transition = 'none';
          layers[hiddenLayer].style.opacity = '0';
          layers[hiddenLayer].style.transform = 'scale(1.05)';
          layers[hiddenLayer].src = images[nextIndex];

          layers[hiddenLayer].onload = () => {
            // Re-enable transitions then animate
            requestAnimationFrame(() => {
              layers[hiddenLayer].style.transition = TRANSITION;
              requestAnimationFrame(() => {
                // Fade in hidden layer on top
                layers[hiddenLayer].style.zIndex = '2';
                layers[hiddenLayer].style.opacity = '1';
                layers[hiddenLayer].style.transform = 'scale(1)';

                // Fade out active layer below
                layers[activeLayer].style.zIndex = '1';
                layers[activeLayer].style.opacity = '0';
                layers[activeLayer].style.transform = 'scale(1.08)';

                activeLayer = hiddenLayer;
                currentIndex = nextIndex;
              });
            });
          };

          layers[hiddenLayer].onerror = () => {
            currentIndex = nextIndex;
          };
        }, 4000);
      } catch (e) {
        console.warn('Carousel init error:', e);
      }
    });
  }

  // Load services section, then start carousels
  loadServicesSection().then(() => {
    initServiceCarousels();
  });

  // Load Team Section dynamically
  async function loadTeamSection() {
    try {
      const response = await fetch(`${checkinData.restUrl}hairdressers`, {
        method: 'GET',
        headers: { 'Content-Type': 'application/json' },
      });
      if (!response.ok) {
        const errorText = await response.text();
        console.error('API Error Response:', errorText);
        throw new Error('Network response was not ok');
      }

      const contentType = response.headers.get('content-type');
      if (!contentType || !contentType.includes('application/json')) {
        const text = await response.text();
        console.error('Non-JSON response received:', text.substring(0, 500));
        throw new Error('Server returned non-JSON response');
      }

      const result = await response.json();
      console.log('Hairdressers API response:', result);

      if (!result.success) throw new Error(result.message || 'Lỗi khi tải danh sách thợ');
      const hairdressers = result.data;

      console.log('Hairdressers data:', hairdressers);
      console.log('Number of hairdressers:', hairdressers ? hairdressers.length : 0);

      const teamGrid = document.querySelector('.team-grid-modern, .team-grid');
      if (!teamGrid) {
        console.error('Team grid element not found in DOM');
        console.log('Available team elements:', {
          modern: document.querySelector('.team-grid-modern'),
          regular: document.querySelector('.team-grid'),
        });
        return;
      }

      console.log('Team grid found:', teamGrid);

      // Clear existing team members
      teamGrid.innerHTML = '';

      // Check if hairdressers array is valid
      if (!Array.isArray(hairdressers) || hairdressers.length === 0) {
        console.warn('No hairdressers to display');
        teamGrid.innerHTML = '<p class="text-center">Chưa có thợ nào.</p>';
        return;
      }

      // Generate team members dynamically with lazy loading
      console.log('Starting to render hairdressers...');
      hairdressers.forEach((hairdresser, index) => {
        console.log(`Rendering hairdresser ${index + 1}:`, hairdresser.hairdresser_name);
        const teamMember = document.createElement('div');
        teamMember.classList.add('team-card-modern', 'team-member');

        // Use data-src for lazy loading (first 2 load immediately)
        const shouldLoadNow = index < 2;


        teamMember.innerHTML = `
          <div class="member-image">
            <img
              ${
                shouldLoadNow
                  ? `src="${hairdresser.hairdresser_image}"`
                  : `data-src="${hairdresser.hairdresser_image}"`
              }
              alt="${hairdresser.hairdresser_name}"
              loading="lazy"
              decoding="async"
            />
            <div class="member-social">
              <a href="#"><i class="fab fa-facebook-f"></i></a>
              <a href="#"><i class="fab fa-tiktok"></i></a>
            </div>
          </div>
          <div class="member-info">
            <button class="btn btn-primary book-btn" data-barber="${escapeAttr(
              hairdresser.hairdresser_name
            )}">Đặt lịch ngay!</button>
          </div>
        `;
        teamGrid.appendChild(teamMember);

        // Add loaded class for immediate images
        if (shouldLoadNow) {
          const memberImage = teamMember.querySelector('.member-image');
          const img = memberImage.querySelector('img');
          img.onload = () => memberImage.classList.add('loaded');
        }

        console.log(`Appended hairdresser ${index + 1} to grid`);
      });

      // Lazy load remaining team member images
      if (imageLoader) {
        const memberImages = teamGrid.querySelectorAll('.member-image');
        // Skip first 2 (already loaded), observe the rest
        [...memberImages].slice(2).forEach((img) => imageLoader.observe([img]));
      }

      console.log('Finished rendering. Team grid children:', teamGrid.children.length);

      // Trigger animation for dynamically loaded team members
      setTimeout(() => {
        if (typeof initScrollReveal === 'function') {
          initScrollReveal();
        }
      }, 100);

      // Re-attach event listeners for book buttons
      document.querySelectorAll('.book-btn').forEach((button) => {
        button.addEventListener('click', async function () {
          // Show loading overlay
          showPageLoading();

          hairdresserName = this.getAttribute('data-barber');
          // Wait for initialization to complete before opening modal
          await initializeHairdresserSelection(hairdresserName);

          document.getElementById('bookingPopup').style.display = 'block';
          document.body.classList.add('modal-open');

          // Hide loading overlay after modal is shown
          hidePageLoading();
        });
      });
    } catch (error) {
      console.error('Error loading team section:', error);
      showError('Không thể tải danh sách thợ. Vui lòng thử lại.');
    }
  }

  // Call the function to load team section
  loadTeamSection();

  // Load Gallery Section dynamically
  async function loadGallerySection() {
    try {
      const response = await fetch(`${checkinData.restUrl}gallery`, {
        method: 'GET',
        headers: { 'Content-Type': 'application/json' },
      });
      if (!response.ok) throw new Error('Network response was not ok');
      const result = await response.json();
      console.log('Gallery API response:', result);

      if (!result.success) throw new Error(result.message || 'Lỗi khi tải danh sách ảnh gallery');
      const images = result.data;

      console.log('Gallery images:', images);
      console.log('Number of images:', images ? images.length : 0);

      const galleryGrid = document.querySelector('.gallery-grid-modern, .gallery-grid');
      if (!galleryGrid) {
        console.error('Gallery grid element not found in DOM');
        console.log('Available gallery elements:', {
          modern: document.querySelector('.gallery-grid-modern'),
          regular: document.querySelector('.gallery-grid'),
        });
        return;
      }

      console.log('Gallery grid found:', galleryGrid);

      // Clear existing gallery items
      galleryGrid.innerHTML = '';

      // Check if images array is valid
      if (!Array.isArray(images) || images.length === 0) {
        console.warn('No gallery images to display');
        galleryGrid.innerHTML = '<p class="text-center">Chưa có ảnh nào.</p>';
        return;
      }

      // Generate gallery items dynamically with lazy loading
      images.forEach((image, index) => {
        const galleryItem = document.createElement('div');
        galleryItem.classList.add('gallery-item-modern', 'gallery-item');
        // Đánh dấu item đầu tiên là active trên mobile
        if (index === 0 && window.innerWidth <= 768) {
          galleryItem.classList.add('active');
        }

        // First 3 images load immediately, rest use lazy loading
        const shouldLoadNow = index < 3;

        galleryItem.innerHTML = `
        <img
          ${shouldLoadNow ? `src="${image.url}"` : `data-src="${image.url}"`}
          alt="${image.alt}"
          loading="lazy"
          decoding="async"
        />
        <div class="gallery-overlay">
          <a href="${image.url}" class="gallery-zoom"><i class="fas fa-search"></i></a>
        </div>
      `;
        galleryGrid.appendChild(galleryItem);

        // Add loaded class for immediate images and handle errors
        if (shouldLoadNow) {
          const img = galleryItem.querySelector('img');
          img.onload = () => galleryItem.classList.add('loaded');
          img.onerror = () => {
            console.error('Failed to load gallery image:', image.url);
            galleryItem.classList.add('error');
          };
        }
      });

      // Lazy load remaining gallery images
      if (imageLoader) {
        const galleryItems = galleryGrid.querySelectorAll('.gallery-item');
        // Skip first 3 (already loading), observe the rest
        [...galleryItems].slice(3).forEach((item) => imageLoader.observe([item]));
      } else {
        // Fallback: Load all images directly if imageLoader is not available
        console.warn('ModernImageLoader not available, loading images directly');
        const lazyImages = galleryGrid.querySelectorAll('img[data-src]');
        lazyImages.forEach((img) => {
          const src = img.dataset.src;
          if (src) {
            img.src = src;
            img.removeAttribute('data-src');
            img.onload = () => {
              const container = img.closest('.gallery-item');
              if (container) container.classList.add('loaded');
            };
            img.onerror = () => {
              console.error('Failed to load gallery image:', src);
            };
          }
        });
      }

      // Gallery Auto-Scroll and Navigation for Mobile
      if (window.innerWidth <= 768) {
        // Hàm để cập nhật trạng thái active - INSTANT update
        function updateActiveItem() {
          const galleryItems = galleryGrid.querySelectorAll('.gallery-item');
          const viewportCenter = window.innerWidth / 2;
          let closestItem = null;
          let closestDistance = Infinity;

          galleryItems.forEach((item) => {
            const rect = item.getBoundingClientRect();
            const itemCenter = rect.left + rect.width / 2;
            const distance = Math.abs(viewportCenter - itemCenter);

            if (distance < closestDistance) {
              closestDistance = distance;
              closestItem = item;
            }
          });

          // Cập nhật ngay lập tức - không delay
          galleryItems.forEach((item) => item.classList.remove('active'));
          if (closestItem) {
            closestItem.classList.add('active');
          }
        }

        // Debounce cho scroll end detection
        let scrollTimeout = null;
        const onScrollEnd = () => {
          clearTimeout(scrollTimeout);
          scrollTimeout = setTimeout(() => {
            updateActiveItem();
          }, 50); // Gọi sau 50ms khi scroll dừng
        };

        // Throttle cho scroll liên tục
        let rafId = null;
        const throttledUpdateActive = () => {
          if (rafId) return;
          rafId = requestAnimationFrame(() => {
            updateActiveItem();
            rafId = null;
          });
        };

        // Chỉ auto-scroll khi gallery còn trong viewport và tab đang mở
        let galleryVisible = true;
        if ('IntersectionObserver' in window) {
          new IntersectionObserver((entries) => {
            galleryVisible = entries[0].isIntersecting;
          }).observe(galleryGrid);
        }

        const autoAdvance = () => {
          if (document.hidden || !galleryVisible) return;
          if (galleryGrid.scrollWidth > galleryGrid.clientWidth) {
            const maxScroll = galleryGrid.scrollWidth - galleryGrid.clientWidth;
            if (galleryGrid.scrollLeft >= maxScroll - 10) {
              galleryGrid.scrollTo({ left: 0, behavior: 'smooth' });
            } else {
              galleryGrid.scrollBy({
                left: galleryGrid.clientWidth * 0.85,
                behavior: 'smooth',
              });
            }
            setTimeout(throttledUpdateActive, 350);
          }
        };

        // Tự động cuộn - tăng interval để giảm load
        let autoScrollInterval = setInterval(autoAdvance, 4000);

        // Tạm dừng khi hover hoặc chạm
        galleryGrid.addEventListener('mouseenter', () => clearInterval(autoScrollInterval), {
          passive: true,
        });
        galleryGrid.addEventListener('touchstart', () => clearInterval(autoScrollInterval), {
          passive: true,
        });
        galleryGrid.addEventListener(
          'mouseleave',
          () => {
            clearInterval(autoScrollInterval);
            autoScrollInterval = setInterval(autoAdvance, 4000);
          },
          { passive: true },
        );

        // Cập nhật active item khi scroll dừng — không đo layout từng frame khi đang vuốt
        galleryGrid.addEventListener('scroll', onScrollEnd, { passive: true });

        // Xử lý nút điều hướng
        const prevBtn = document.querySelector('.gallery-nav.prev');
        const nextBtn = document.querySelector('.gallery-nav.next');

        if (prevBtn && nextBtn) {
          prevBtn.addEventListener('click', () => {
            clearInterval(autoScrollInterval);
            galleryGrid.scrollBy({
              left: -galleryGrid.clientWidth * 0.85,
              behavior: 'smooth',
            });
            setTimeout(updateActiveItem, 300);
          });

          nextBtn.addEventListener('click', () => {
            clearInterval(autoScrollInterval);
            galleryGrid.scrollBy({
              left: galleryGrid.clientWidth * 0.85,
              behavior: 'smooth',
            });
            setTimeout(updateActiveItem, 300);
          });
        }

        // Initial active state - gọi ngay lập tức
        updateActiveItem();
      }

      // Trigger animation for dynamically loaded gallery items
      setTimeout(() => {
        if (typeof initScrollReveal === 'function') {
          initScrollReveal();
        }
      }, 100);
    } catch (error) {
      console.error('Error loading gallery section:', error);
      showError('Không thể tải danh sách ảnh gallery. Vui lòng thử lại.');
    }
  }

  // Call the function to load gallery section
  loadGallerySection();

  // Booking Popup Logic
  let hairdressers = [];
  let hairdresserName = '';
  let selectedServices = [];
  let selectedDateToday = 'Hôm nay';
  let selectedOtherDate = '';
  let selectedTimeToday = '';
  let selectedTimeOtherDay = '';
  let customerExists = null;
  let isBookingConflict = false;
  let bookingData = {};
  let specialServiceDataCache = null;
  let flatpickrInstance = null;
  let isManager = false;

  // Handle book button clicks
  document.querySelectorAll('.book-btn').forEach((button) => {
    button.addEventListener('click', function () {
      hairdresserName = this.getAttribute('data-barber');
      document.getElementById('bookingPopup').style.display = 'block';
      document.body.classList.add('modal-open');
      initializeHairdresserSelection(hairdresserName);
    });
  });

  async function initializeHairdresserSelection(selectedHairdresserName) {
    await loadHairdressers();
    updateDefaultHairdresserOption(selectedHairdresserName);
    loadSubmit();
  }

  async function loadHairdressers() {
    try {
      const response = await fetch(`${checkinData.restUrl}hairdressers`, {
        method: 'GET',
        headers: { 'Content-Type': 'application/json' },
      });
      if (!response.ok) throw new Error('Network response was not ok');
      const result = await response.json();
      if (!result.success) throw new Error(result.message || 'Lỗi khi tải danh sách thợ');
      hairdressers = result.data || [];
      updateStaffInfoMap(hairdressers);

      // No need to populate dropdown here - it will be populated when opened
      console.log('Loaded hairdressers:', hairdressers.length);
    } catch (error) {
      console.error('Error loading hairdressers:', error);
      showError('Không thể tải danh sách thợ. Vui lòng thử lại.');
    }
  }

  function updateDefaultHairdresserOption(selectedHairdresserName) {
    const hairdresserSelect = document.getElementById('hairdresserSelect');
    hairdresserName = selectedHairdresserName || '-- Chọn Thợ Phục Vụ --';

    console.log('updateDefaultHairdresserOption called with:', selectedHairdresserName);
    console.log(
      'Available hairdressers:',
      hairdressers.map((h) => h.hairdresser_name),
    );

    // Update hidden select value (no need for options with new pill structure)
    if (hairdresserSelect) {
      hairdresserSelect.value = selectedHairdresserName || '';
    }

    const defaultHairdresser = hairdressers.find((h) => h.hairdresser_name === hairdresserName) || {
      hairdresser_name: 'Chọn Thợ phục vụ',
      hairdresser_status: 'AVAILABLE',
      is_manager: 0,
    };
    isManager = defaultHairdresser.is_manager === 1;

    console.log('Found hairdresser:', defaultHairdresser);

    // Trigger full hairdresser selection to update status and load services
    if (
      hairdresserName &&
      hairdresserName !== '-- Chọn Thợ Phục Vụ --' &&
      hairdresserName !== 'Chọn Thợ phục vụ'
    ) {
      console.log('Triggering selectHairdresser for:', hairdresserName);
      selectHairdresser(
        defaultHairdresser.hairdresser_name,
        defaultHairdresser.hairdresser_status,
        defaultHairdresser.off_future_start || '',
        defaultHairdresser.off_future_end || '',
        defaultHairdresser.is_manager,
      );
    }
  }
  async function checkCustomer() {
    const phone = document.getElementById('customerPhone').value.replace(/^0/, '');
    if (phone.length >= 9) {
      try {
        const response = await fetch(`${checkinData.restUrl}check-customer?phone=${phone}`, {
          method: 'GET',
          headers: { 'Content-Type': 'application/json' },
        });
        if (!response.ok) throw new Error('Network response was not ok');
        const result = await response.json();
        if (!result.success) throw new Error(result.message || 'Lỗi khi kiểm tra khách hàng');
        const customer = result;
        customerExists = customer.exists;

        if (customer.exists) {
          document.getElementById('customerInfo').style.display = 'block';
          document.getElementById('customerName').textContent = customer.customerName;
          document.getElementById('oldHairdresser').textContent =
            customer.hairdresserName || 'Chưa có';
          document.getElementById('newCustomerInfo').style.display = 'none';
        } else {
          document.getElementById('newCustomerInfo').style.display = 'block';
          document.getElementById('customerInfo').style.display = 'none';
        }
      } catch (error) {
        console.error('Error checking customer:', error);
        showError('Không thể kiểm tra thông tin khách hàng. Vui lòng thử lại.');
      }
    } else {
      document.getElementById('customerInfo').style.display = 'none';
      document.getElementById('newCustomerInfo').style.display = 'none';
    }
  }

  function showHairdresserPopup() {
    // Legacy function - now handled by toggleHairdresserDropdown in home-booking-branch.js
    if (typeof window.toggleHairdresserDropdown === 'function') {
      window.toggleHairdresserDropdown();
    }
  }

  function hideHairdresserPopup() {
    // Close the pill dropdown if it exists
    const dropdown = document.getElementById('hairdresserDropdown');
    if (dropdown) {
      dropdown.style.display = 'none';
    }

    const statusDiv = document.getElementById('hairdresserStatus');
    if (statusDiv) {
      statusDiv.style.display = 'block';
    }

    if (customerExists === true) {
      const customerInfo = document.getElementById('customerInfo');
      if (customerInfo) customerInfo.style.display = 'block';
    } else if (customerExists === false) {
      const newCustomerInfo = document.getElementById('newCustomerInfo');
      if (newCustomerInfo) newCustomerInfo.style.display = 'block';
    }
  }

  function selectHairdresser(
    hairdresserNameSelected,
    hairdresserStatus,
    offStart,
    offEnd,
    isManagerSelected,
  ) {
    const hairdresserSelect = document.getElementById('hairdresserSelect');
    hairdresserName = hairdresserNameSelected;
    isManager = isManagerSelected === 1;

    if (hairdresserSelect) {
      hairdresserSelect.value = hairdresserNameSelected;
    }

    // Update pill display if exists
    const hairdresserDisplay = document.getElementById('hairdresserPillDisplay');
    if (hairdresserDisplay && hairdresserNameSelected !== 'Chọn Thợ phục vụ') {
      hairdresserDisplay.innerHTML = `
        <div class="pill-item">
          <span>${hairdresserNameSelected}</span>
          <span class="pill-remove" onclick="removeHairdresserPill(event)">
            <i class="fas fa-times"></i>
          </span>
        </div>
      `;
      hairdresserDisplay.classList.add('has-selection');
    }

    // Auto-select branch based on hairdresser
    if (
      hairdresserNameSelected !== 'Chọn Thợ phục vụ' &&
      typeof window.autoSelectBranchFromHairdresser === 'function'
    ) {
      // Call the branch auto-select function
      window.autoSelectBranchFromHairdresser(hairdresserNameSelected);

      // Also update the branch pill display
      const branchSelect = document.getElementById('branchSelect');
      const branchPillDisplay = document.getElementById('branchPillDisplay');

      if (branchSelect && branchSelect.value && branchPillDisplay) {
        // Get branch name from the select
        const branchId = branchSelect.value;

        // Find branch name using the global branches array from home-booking-branch.js
        if (typeof window.branches !== 'undefined') {
          const branch = window.branches.find((b) => b.id == branchId);
          if (branch) {
            branchPillDisplay.innerHTML = `
              <div class="pill-item">
                <span>${branch.branch_name}</span>
                <span class="pill-remove" onclick="removeBranchPill(event)">
                  <i class="fas fa-times"></i>
                </span>
              </div>
            `;
            branchPillDisplay.classList.add('has-selection');
          }
        }
      }
    }

    hideHairdresserPopup();
    updateHairdresserStatus(hairdresserStatus, hairdresserName, offStart, offEnd);
    loadServices(hairdresserName);
  }
  function updateHairdresserStatus(status, name, offStart, offEnd) {
    const statusDiv = document.getElementById('hairdresserStatus');
    if (name === 'Chọn Thợ phục vụ') {
      statusDiv.textContent = 'Vui lòng chọn Thợ phục vụ trước khi đặt lịch hẹn!';
      statusDiv.style.color = 'red';
    } else if (getPausedStaffNotice(name)) {
      statusDiv.textContent = getPausedStaffNotice(name);
      statusDiv.style.color = '#ff9f43';
    } else if (status === 'OFF') {
      statusDiv.textContent = `🆘 Thợ ${name} có lịch OFF/ nghỉ phép hôm nay. Vui lòng đặt lịch hẹn trước cho ngày khác hoặc đổi Thợ khác!`;
      statusDiv.style.color = 'red';
    } else {
      if (offStart) {
        statusDiv.textContent = `Lịch Off sắp tới: ${offStart}-${offEnd || ''}.`;
        statusDiv.style.color = 'yellow';
      } else {
        statusDiv.textContent = `Thợ ${name} sẵn sàng phục vụ.`;
        statusDiv.style.color = '#32CD32';
      }
    }
    statusDiv.style.fontWeight = 'bold';
    statusDiv.style.fontStyle = 'italic';
  }

  async function loadServices() {
    // Show loading overlay
    showPageLoading();

    try {
      // Build URL with branch_id if branch mode is enabled
      let servicesUrl = `${checkinData.restUrl}services`;
      const branchModeEnabled =
        (typeof checkinData !== 'undefined' && checkinData.branchModeEnabled) || false;

      if (branchModeEnabled) {
        const branchSelect = document.getElementById('branchSelect');
        if (branchSelect && branchSelect.value) {
          servicesUrl += `?branch_id=${branchSelect.value}`;
          console.log('Loading services for branch_id:', branchSelect.value);
        }
      }

      const response = await fetch(servicesUrl, {
        method: 'GET',
        headers: { 'Content-Type': 'application/json' },
      });
      if (!response.ok) throw new Error('Failed to fetch services');
      const result = await response.json();
      if (!result.success) throw new Error(result.message || 'Lỗi khi tải dịch vụ');
      const services = result.data;

      // Tạo danh sách nhóm dịch vụ với service_group_id
      const serviceGroupsMap = new Map();
      services.forEach((s) => {
        if (!serviceGroupsMap.has(s.service_group)) {
          serviceGroupsMap.set(s.service_group, {
            name: s.service_group,
            id: parseInt(s.service_group_id, 10),
          });
        }
      });

      // Lọc và sắp xếp nhóm dịch vụ theo service_group_id
      const serviceGroups = Array.from(serviceGroupsMap.values())
        .filter((group) => {
          if (isManager) {
            return group.name !== 'CẮT';
          } else {
            return group.name !== 'VIP';
          }
        })
        .sort((a, b) => a.id - b.id)
        .map((group) => group.name);

      const serviceTab = document.getElementById('serviceTab');
      serviceTab.innerHTML = serviceGroups
        .map(
          (group, index) => `
                <button class="tab-button ${index === 0 ? 'active' : ''}" data-group="${group}">
                    ${group}
                </button>
            `,
        )
        .join('');

      const tabButtons = document.querySelectorAll('#serviceTab .tab-button');
      tabButtons.forEach((button) => {
        button.removeEventListener('click', button._clickHandler);
        button._clickHandler = function () {
          showServiceGroup(button.getAttribute('data-group'), services, specialServiceDataCache);
        };
        button.addEventListener('click', button._clickHandler);
      });

      if (serviceGroups.length > 0) {
        showServiceGroup(serviceGroups[0], services, specialServiceDataCache);
      } else {
        document.getElementById('serviceGrid').innerHTML = '<p>Không có dịch vụ nào.</p>';
      }

      // Hide loading overlay after services rendered
      hidePageLoading();

      // Validate step 1 after services loaded (to ensure button state is correct)
      if (typeof validateStep1 === 'function') {
        setTimeout(() => validateStep1(), 100);
      }
    } catch (error) {
      console.error('Error loading services:', error);
      showError('Không thể tải dịch vụ. Vui lòng thử lại.');
      document.getElementById('serviceGrid').innerHTML = '<p>Lỗi khi tải dịch vụ.</p>';
      document.getElementById('servicePopup').style.display = 'block';

      // Hide loading even on error
      hidePageLoading();
    }
  }

  function showServiceGroup(group, servicesData, specialServiceData) {
    const tabs = document.querySelectorAll('#serviceTab .tab-button');
    tabs.forEach((tab) => tab.classList.remove('active'));
    tabs.forEach((tab) => {
      if (tab.getAttribute('data-group') === group) tab.classList.add('active');
    });

    // Build URL with branch_id if branch mode is enabled
    let servicesUrl = `${checkinData.restUrl}services`;
    const branchModeEnabled =
      (typeof checkinData !== 'undefined' && checkinData.branchModeEnabled) || false;

    if (branchModeEnabled && !servicesData) {
      const branchSelect = document.getElementById('branchSelect');
      if (branchSelect && branchSelect.value) {
        servicesUrl += `?branch_id=${branchSelect.value}`;
      }
    }

    const fetchServices = servicesData
      ? Promise.resolve(servicesData)
      : fetch(servicesUrl, {
          method: 'GET',
          headers: { 'Content-Type': 'application/json' },
        })
          .then((res) => res.json())
          .then((res) => {
            if (!res.success) throw new Error(res.message || 'Lỗi khi tải dịch vụ');
            return res.data;
          });

    fetchServices
      .then((services) => {
        let isReplaced = false;
        const serviceGrid = document.getElementById('serviceGrid');
        serviceGrid.innerHTML = services
          .filter((service) => service.service_group === group)
          .map((service) => {
            let displayService = service;
            if (
              (service.service_name === 'COMBO ĐẸP TRAI 100K' ||
                service.service_name === 'COMBO HS-SV 90K' ||
                service.service_name === 'COMBO ĐẸP TRAI VIP 190K') &&
              specialServiceData?.service_name &&
              !isReplaced
            ) {
              displayService = {
                service_id: service.service_id,
                service_name: specialServiceData.service_name,
                service_group: service.service_group,
                service_price: specialServiceData.price,
                sort_order: service.sort_order,
                discounted_price: specialServiceData.discounted_price_formatted,
                service_type: service.service_type,
              };
              isReplaced = true;
            } else if (specialServiceData?.service_name) {
              return '';
            }

            const isSelected = selectedServices.some((s) => s.name === displayService.service_name);
            const priceDisplay = displayService.discounted_price_formatted
              ? `<span class="original-price">${displayService.service_price_formatted}</span> <span class="discount-price">${displayService.discounted_price_formatted}</span>`
              : `${displayService.service_price_formatted}`;
            return `
                            <div class="booking-service-card ${isSelected ? 'active' : ''}"
                                 data-service-name="${displayService.service_name}"
                                 data-service-price="${displayService.service_price_formatted}"
                                 data-display-price="${
                                   displayService.discounted_price_formatted ||
                                   displayService.service_price_formatted
                                 }">
                                <h4>${displayService.service_name}</h4>
                                <p class="price">${priceDisplay}</p>
                            </div>
                        `;
          })
          .join('');

        const serviceCards = document.querySelectorAll('.booking-service-card');
        serviceCards.forEach((card) => {
          card.removeEventListener('click', card._clickHandler);
          card._clickHandler = function () {
            toggleService(
              card.getAttribute('data-service-name'),
              card.getAttribute('data-service-price'),
              card.getAttribute('data-display-price'),
              card,
            );
          };
          card.addEventListener('click', card._clickHandler);
        });

        // Show services directly in Step 2, no popup
        document.getElementById('selectedServices').style.display = 'block';
        updateSelectedServicesDisplay();
        updateNextButtonState();
      })
      .catch((error) => {
        console.error('Error loading service group:', error);
        showError('Không thể tải dịch vụ của nhóm này.');
        document.getElementById('serviceGrid').innerHTML = '<p>Lỗi khi tải dịch vụ.</p>';
      });
  }

  function toggleService(serviceName, servicePrice, displayPrice, element) {
    if (!element) {
      console.error('Element is undefined in toggleService', {
        serviceName,
        servicePrice,
        displayPrice,
      });
      return;
    }

    const isAlreadySelected = selectedServices.some((service) => service.name === serviceName);

    if (!isAlreadySelected) {
      selectedServices.push({
        name: serviceName,
        price: displayPrice,
        originalPrice: servicePrice,
        hasDiscount: servicePrice !== displayPrice,
      });
      element.classList.add('active');
    } else {
      selectedServices = selectedServices.filter((service) => service.name !== serviceName);
      element.classList.remove('active');
    }

    updateSelectedServicesDisplay();
    updateNextButtonState();
  }

  function removeService(serviceName) {
    selectedServices = selectedServices.filter((service) => service.name !== serviceName);

    // Remove 'active' class from corresponding service card in serviceGrid
    const serviceCards = document.querySelectorAll('.booking-service-card');
    serviceCards.forEach((card) => {
      const cardTitle = card.querySelector('h4');
      if (cardTitle && cardTitle.textContent.trim() === serviceName) {
        card.classList.remove('active');
      }
    });

    const activeTab = document.querySelector('#serviceTab .tab-button.active');
    const currentGroup = activeTab ? activeTab.textContent : null;
    if (currentGroup) {
      updateSelectedServicesDisplay();
      updateNextButtonState();
    }
  }

  function updateSelectedServicesDisplay() {
    const selectedServicesDiv = document.getElementById('selectedServices');
    selectedServicesDiv.innerHTML =
      selectedServices.length > 0
        ? selectedServices
            .map((service) => {
              const priceDisplay = service.hasDiscount
                ? `<span class="original-price">${service.originalPrice}</span><span class="discount-price">${service.price}</span>`
                : service.price;
              return `
                  <div class="service-item">
                      <span class="service-info">${service.name} - ${priceDisplay}</span>
                      <button class="remove-button" onclick="removeService('${service.name}')"> <i class="fas fa-trash-alt"></i> </button>
                  </div>
                `;
            })
            .join('')
        : '<p>Chưa có dịch vụ nào được chọn.</p>';
  }

  function filterServices() {
    const searchTerm = document.getElementById('searchServiceInput').value.toLowerCase();
    const serviceCards = document
      .getElementById('serviceGrid')
      .querySelectorAll('.booking-service-card');
    serviceCards.forEach((card) => {
      const text = card.querySelector('h4').textContent.toLowerCase();
      card.style.display = text.includes(searchTerm) ? '' : 'none';
    });
  }

  function showServicePopup() {
    // Step 2 now shows services directly, no popup needed
    loadServices(hairdresserName);
    document.getElementById('selectedServices').style.display = 'block';
  }

  function hideServicePopup() {
    // Not used anymore, services display directly in Step 2
    updateSelectedServicesDisplay();
    updateNextButtonState();
  }

  function updateNextButtonState() {
    const nextButton = document.getElementById('nextStepBtn');
    if (nextButton) {
      nextButton.disabled = selectedServices.length === 0;
      if (selectedServices.length > 0) {
        nextButton.style.opacity = '1';
        nextButton.style.cursor = 'pointer';
      } else {
        nextButton.style.opacity = '0.5';
        nextButton.style.cursor = 'not-allowed';
      }
    }
  }

  function showToday() {
    document.getElementById('timeSlotsToday').style.display = 'block';
    document.getElementById('timeSlotsOtherDay').style.display = 'none';
    document.getElementById('calendarPopup').style.display = 'none';
    document.getElementById('todayTab').classList.add('active');
    document.getElementById('otherDayTab').classList.remove('active');
    // Fix: Re-initialize selectedDateToday khi chuyển tab Hôm Nay
    // (resetBookingForm() đã clear nó thành '' trước đó)
    selectedDateToday = 'Hôm nay';
    generateTodayTimeButtons();
  }

  function generateTodayTimeButtons() {
    const now = new Date();
    const vnTime = new Date(now.toLocaleString('en-US', { timeZone: 'Asia/Ho_Chi_Minh' }));
    const timeButtons = document.getElementById('timeButtonsToday');
    timeButtons.innerHTML = '';

    // Show loading overlay
    showPageLoading();

    // Get hairdresser from hidden input (pill structure)
    const hairdresserInput = document.getElementById('hairdresserSelect');
    const hairdresserName = hairdresserInput ? hairdresserInput.value : '';

    if (hairdresserName && hairdresserName !== 'Chọn Thợ phục vụ') {
      const vnDate = vnTime
        .toLocaleString('en-CA', {
          timeZone: 'Asia/Ho_Chi_Minh',
          year: 'numeric',
          month: '2-digit',
          day: '2-digit',
        })
        .split('T')[0]
        .replace(/(\d+)\/(\d+)\/(\d+)/, '$3-$1-$2');

      // Tạo danh sách khung giờ mặc định để gửi lên API
      const startHour = 8;
      const endHour = 20;
      const timeSlots = [];
      for (let hour = startHour; hour <= Math.floor(endHour); hour++) {
        const minutes = hour === startHour ? [30] : [0, 30];
        for (let minute of minutes) {
          const slotText = `${hour.toString().padStart(2, '0')}:${minute
            .toString()
            .padStart(2, '0')}`;
          timeSlots.push(slotText);
        }
      }

      fetch(`${checkinData.restUrl}hairdresser-availability`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          hairdresser: hairdresserName,
          date: vnDate,
          timeSlots: timeSlots.map((slot) => slot + ':00'),
        }),
      })
        .then((response) => response.json())
        .then((data) => {
          if (!data.success) {
            // ✅ FIX: Luôn tắt loading overlay khi API trả success:false
            hidePageLoading();
            if (data.message.includes('Quản Lý') && data.schedules && data.schedules.length > 0) {
              let scheduleList = data.schedules
                .map((s) => `${s.start_date} đến ${s.end_date}`)
                .join('<br>');
              showConfirm(
                `${data.message}<br><strong>Lịch làm việc:</strong><br>${scheduleList}`,
              ).then((userConfirmed) => {
                if (userConfirmed) {
                  showOtherDay();
                }
              });
            } else {
              showError(data.message);
              timeButtons.innerHTML =
                '<p>Không có khung giờ khả dụng. Vui lòng chọn ngày khác.</p>';
              if (data.resetToStep1) {
                resetBookingStep();
                showServicePopup();
                document
                  .querySelectorAll('.booking-step')
                  .forEach((step) => (step.style.display = 'none'));
                document.getElementById('step1').style.display = 'block';
                document.getElementById('todayTab').style.display = 'none';
              }
            }
            return;
          }

          const conflicts = data.conflicts || {};
          const nearestTimeConflict = data.nearestTimeConflict;
          const isEvent = data.message && data.message.includes('sự kiện');
          let allDisabled = true;

          // Lọc các khung giờ từ thời gian hiện tại + 1 giờ
          const roundedTime = new Date(vnTime);
          if (vnTime.getMinutes() < 30) {
            roundedTime.setMinutes(0);
            roundedTime.setHours(vnTime.getHours() + 1);
          } else {
            roundedTime.setMinutes(30);
            roundedTime.setHours(vnTime.getHours() + 1);
          }
          roundedTime.setSeconds(0);
          roundedTime.setMilliseconds(0);

          const displaySlots = (
            data.available_time_slots && data.available_time_slots.length
              ? data.available_time_slots
              : timeSlots
          ).filter((slotText) => {
            const [hour, minute] = slotText.split(':').map(Number);
            const slotTime = new Date(
              vnTime.getFullYear(),
              vnTime.getMonth(),
              vnTime.getDate(),
              hour,
              minute,
            );
            return slotTime >= roundedTime;
          });

          if (displaySlots.length === 0) {
            hidePageLoading();
            showWarning(
              `Không còn khung giờ khả dụng trong ngày ${vnTime.toLocaleDateString(
                'vi-VN',
              )}. Vui lòng chọn ngày khác!`,
            );
            const messageDiv = document.getElementById('timeSlotMessageToday');
            if (messageDiv) {
              messageDiv.innerHTML = '<p>Không có khung giờ khả dụng. Vui lòng chọn ngày khác.</p>';
            }
            return;
          }

          // Hiển thị thông báo sự kiện nếu có
          if (isEvent) {
            showWarning(data.message);
          }

          displaySlots.forEach((slotText) => {
            const button = document.createElement('button');
            button.textContent = slotText;
            button.classList.add('time-slot-button');
            const isConflict = conflicts[slotText] || false;
            const isNearest = slotText === nearestTimeConflict;

            if (isConflict || isNearest) {
              button.style.opacity = '0.5';
              button.style.cursor = 'not-allowed';
              button.onclick = () =>
                showWarning(
                  isEvent && isConflict
                    ? data.message
                    : isConflict
                      ? `Khung giờ ${slotText} đã có khách đặt, vui lòng chọn khung giờ khác!`
                      : `Khung giờ ${slotText} quá gần, thợ đang bận, vui lòng chọn khung giờ khác!`,
                );
            } else {
              allDisabled = false;
              button.onclick = function () {
                document.getElementById('bookingTime').value = slotText;
                selectedTimeToday = slotText;
                Array.from(timeButtons.getElementsByTagName('button')).forEach((btn) =>
                  btn.classList.remove('active'),
                );
                button.classList.add('active');
              };
            }
            timeButtons.appendChild(button);
          });

          if (allDisabled) {
            showWarning(
              isEvent && data.message
                ? data.message
                : `Tất cả khung giờ trong ngày ${vnTime.toLocaleDateString(
                    'vi-VN',
                  )} đều bị trùng hoặc không khả dụng. Vui lòng chọn ngày khác!`,
            );
            const messageDiv = document.getElementById('timeSlotMessageToday');
            if (messageDiv) {
              messageDiv.innerHTML =
                isEvent && data.message
                  ? `<p>${data.message}</p>`
                  : '<p>Không có khung giờ khả dụng. Vui lòng chọn ngày khác.</p>';
            }
          }

          // Hide loading overlay after buttons rendered
          hidePageLoading();
        })
        .catch((error) => {
          console.error('Error checking bookings:', error);
          showError('Không thể kiểm tra khung giờ. Vui lòng thử lại.');
          hidePageLoading();
        });
    } else {
      showWarning('Vui lòng chọn Thợ phục vụ trước khi chọn khung giờ.');
      hidePageLoading();
    }
  }

  function showOtherDay() {
    document.getElementById('timeSlotsToday').style.display = 'none';
    document.getElementById('timeSlotsOtherDay').style.display = 'block';
    document.getElementById('calendarPopup').style.display = 'block';
    document.getElementById('otherDayTab').classList.add('active');
    document.getElementById('todayTab').classList.remove('active');
    document.getElementById('timeButtonsOtherDay').innerHTML = '';
    document.getElementById('otherDate').value = '';

    if (flatpickrInstance) {
      flatpickrInstance.destroy();
    }
    flatpickrInstance = flatpickr('#otherDate', {
      dateFormat: 'd/m/Y',
      minDate: 'today',
      inline: true,
      locale: 'vn',
      monthSelectorType: 'static',
      theme: 'dark',
      onChange: function (selectedDates, dateStr) {
        selectedOtherDate = dateStr;
        document.getElementById('calendarPopup').style.display = 'none';
        loadOtherDaySlots();
      },
    });
  }

  function loadOtherDaySlots() {
    if (!selectedOtherDate) {
      showWarning('Vui lòng chọn ngày.');
      return;
    }

    const timeButtons = document.getElementById('timeButtonsOtherDay');
    timeButtons.innerHTML = '';
    document.getElementById('bookingTime').value = '';

    const selectedDateObj = new Date(selectedOtherDate.split('/').reverse().join('-'));
    const days = ['Chủ Nhật', 'Thứ Hai', 'Thứ Ba', 'Thứ Tư', 'Thứ Năm', 'Thứ Sáu', 'Thứ Bảy'];
    const dayOfWeek = days[selectedDateObj.getDay()];
    const today = new Date()
      .toLocaleDateString('vi-VN', { timeZone: 'Asia/Ho_Chi_Minh' })
      .split('/')
      .reverse()
      .join('-');
    const displayedDate =
      selectedOtherDate === today ? 'Hôm nay' : `${selectedOtherDate} (${dayOfWeek})`;
    document.getElementById('displayedDate').textContent = displayedDate;
    document.getElementById('selectedDateDisplay').style.display = 'block';

    generateNormalDateSlots(selectedOtherDate, timeButtons);
  }

  function generateNormalDateSlots(selectedDate, timeButtons) {
    // Get hairdresser from hidden input (pill structure) - giống tab Hôm nay
    const hairdresserInput = document.getElementById('hairdresserSelect');
    const hairdresserName = hairdresserInput ? hairdresserInput.value : '';

    // Lấy thông tin thợ từ pill display để có data attributes
    const pillDisplay = document.getElementById('hairdresserPillDisplay');
    const selectedPill = pillDisplay ? pillDisplay.querySelector('.pill-item.selected') : null;
    const hairdresserStatus = selectedPill ? selectedPill.getAttribute('data-status') : '';
    const offStart = selectedPill ? selectedPill.getAttribute('data-off-start') : '';
    const offEnd = selectedPill ? selectedPill.getAttribute('data-off-end') : '';

    timeButtons.innerHTML = '';
    const messageDiv =
      timeButtons.id === 'timeButtonsToday'
        ? document.getElementById('timeSlotMessageToday')
        : document.getElementById('timeSlotMessageOtherDay');

    if (messageDiv) {
      messageDiv.innerHTML = '';
    }

    const selectedDateObj = new Date(selectedDate.split('/').reverse().join('-'));

    if (hairdresserName !== 'Chọn Thợ phục vụ' && offStart && offEnd) {
      const leaveStartDate = new Date(offStart);
      const leaveEndDate = new Date(offEnd);
      if (selectedDateObj >= leaveStartDate && selectedDateObj <= leaveEndDate) {
        showWarning(
          `Thợ ${hairdresserName} có lịch nghỉ phép từ ${offStart} đến ${offEnd}. Vui lòng chọn ngày khác.`,
        );
        if (messageDiv) {
          messageDiv.innerHTML = '<p>Không có khung giờ khả dụng. Vui lòng chọn ngày khác.</p>';
        }
        return;
      }
    }

    // Tạo danh sách khung giờ mặc định để gửi lên API
    const startHour = 8;
    const endHour = 20;
    const timeSlots = [];
    for (let hour = startHour; hour <= Math.floor(endHour); hour++) {
      const minutes = hour === startHour ? [30] : [0, 30];
      for (let minute of minutes) {
        const slotText = `${hour.toString().padStart(2, '0')}:${minute
          .toString()
          .padStart(2, '0')}`;
        timeSlots.push(slotText);
      }
    }

    if (hairdresserName !== 'Chọn Thợ phục vụ') {
      // Show loading overlay
      showPageLoading();

      fetch(`${checkinData.restUrl}hairdresser-availability`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          hairdresser: hairdresserName,
          date: selectedDateObj.toISOString().split('T')[0],
          timeSlots: timeSlots.map((slot) => slot + ':00'),
        }),
      })
        .then((response) => response.json())
        .then((data) => {
          if (!data.success) {
            // ✅ FIX: Luôn tắt loading overlay khi API trả success:false
            hidePageLoading();
            if (data.message.includes('Quản Lý') && data.schedules && data.schedules.length > 0) {
              let scheduleList = data.schedules
                .map((s) => `${s.start_date} đến ${s.end_date}`)
                .join('<br>');
              showConfirm(
                `${data.message}<br><br><strong>Lịch làm việc :</strong>${scheduleList}`,
              ).then((userConfirmed) => {
                if (userConfirmed) {
                  showOtherDay();
                }
              });
            } else {
              showError(data.message);
              timeButtons.innerHTML =
                '<p>Không có khung giờ khả dụng. Vui lòng chọn ngày khác.</p>';
              if (data.resetToStep1) {
                resetBookingStep();
                showServicePopup();
                document
                  .querySelectorAll('.booking-step')
                  .forEach((step) => (step.style.display = 'none'));
                document.getElementById('step1').style.display = 'block';
                document.getElementById('todayTab').style.display = 'none';
              }
            }
            return;
          }

          const conflicts = data.conflicts || {};
          const isEvent = data.message && data.message.includes('sự kiện');
          let allDisabled = true;

          // Sử dụng tất cả các khung giờ từ available_time_slots
          const displaySlots =
            data.available_time_slots && data.available_time_slots.length
              ? data.available_time_slots
              : timeSlots;

          if (displaySlots.length === 0) {
            hidePageLoading();
            showWarning(
              `Không còn khung giờ khả dụng trong ngày ${selectedDate}. Vui lòng chọn ngày khác!`,
            );
            const messageDiv = document.getElementById('timeSlotMessageOtherDay');
            if (messageDiv) {
              messageDiv.innerHTML = '<p>Không có khung giờ khả dụng. Vui lòng chọn ngày khác.</p>';
            }
            return;
          }

          // Hiển thị thông báo sự kiện nếu có
          if (isEvent) {
            showWarning(data.message);
          }

          displaySlots.forEach((slotText) => {
            const button = document.createElement('button');
            button.textContent = slotText;
            button.classList.add('time-slot-button');
            const isConflict = conflicts[slotText] || false;

            if (isConflict) {
              button.style.opacity = '0.5';
              button.style.cursor = 'not-allowed';
              button.onclick = () =>
                showWarning(
                  isEvent
                    ? data.message
                    : `Khung giờ ${slotText} đã bị đặt, vui lòng chọn khung giờ khác!`,
                );
            } else {
              allDisabled = false;
              button.onclick = function () {
                document.getElementById('bookingTime').value = slotText;
                selectedTimeOtherDay = slotText;
                Array.from(timeButtons.getElementsByTagName('button')).forEach((btn) =>
                  btn.classList.remove('active'),
                );
                button.classList.add('active');
              };
            }
            timeButtons.appendChild(button);
          });

          if (allDisabled) {
            showWarning(
              isEvent && data.message
                ? data.message
                : `Tất cả khung giờ trong ngày ${selectedDate} đều bị trùng hoặc không khả dụng. Vui lòng chọn ngày khác!`,
            );
            const messageDiv = document.getElementById('timeSlotMessageOtherDay');
            if (messageDiv) {
              messageDiv.innerHTML =
                isEvent && data.message
                  ? `<p>${data.message}</p>`
                  : '<p>Không có khung giờ khả dụng. Vui lòng chọn ngày khác.</p>';
            }
          }

          // Hide loading overlay after buttons rendered
          hidePageLoading();
        })
        .catch((error) => {
          console.error('Error checking bookings:', error);
          showError('Không thể kiểm tra khung giờ. Vui lòng thử lại.');
          hidePageLoading();
        });
    } else {
      showWarning('Vui lòng chọn Thợ phục vụ trước khi chọn khung giờ.');
      hidePageLoading();
    }

    document.getElementById('timeSlotsOtherDay').style.display = 'block';
  }

  function nextStep(step) {
    if (step === 2) {
      const customerPhone = document.getElementById('customerPhone').value;
      const customerName =
        document.getElementById('customerName').textContent ||
        document.getElementById('customerNameInput').value;
      const phonePattern = /^0\d{9}$|^\d{9}$/;
      if (!phonePattern.test(customerPhone)) {
        showError('Số điện thoại không hợp lệ. Vui lòng nhập đúng định dạng chuỗi số: 0xxxxxxxxx.');
        return;
      }

      if (
        !customerPhone ||
        (!customerName && document.getElementById('newCustomerInfo').style.display === 'block')
      ) {
        showError('Vui lòng nhập tên khách hàng do Quý khách chưa có thông tin trên hệ thống.');
        return;
      }

      // Get hairdresser from hidden input (pill structure)
      const hairdresserInput = document.getElementById('hairdresserSelect');
      const hairdresserName = hairdresserInput ? hairdresserInput.value : '';

      if (!hairdresserName || hairdresserName === 'Chọn Thợ phục vụ') {
        showError('Vui lòng chọn Thợ phục vụ trước khi tiếp tục.');
        return;
      }

      // Get hairdresser data from global array
      const hairdresserData = window.allHairdressers?.find(
        (h) => h.hairdresser_name === hairdresserName,
      );
      const hairdresserStatus = hairdresserData?.status || '';
      const isManagerSelected =
        hairdresserData?.is_manager === '1' || hairdresserData?.is_manager === 1;

      if (hairdresserStatus === 'OFF') {
        showConfirm(
          `Thợ có lịch OFF/ nghỉ phép hôm nay. Bấm "Đồng ý" để đặt lịch hẹn vào ngày khác. Hoặc "Hủy" để đổi Thợ khác!`,
        ).then((userConfirmed) => {
          if (!userConfirmed) {
            return;
          }
          resetBookingStep();
          showServicePopup();
          document
            .querySelectorAll('.booking-step')
            .forEach((step) => (step.style.display = 'none'));
          document.getElementById(`step${step}`).style.display = 'block';
          document.getElementById('todayTab').style.display = 'none';
          showOtherDay();
        });
        return;
      }
    }

    if (step === 3) {
      if (document.getElementById('todayTab').style.display !== 'none') {
        showToday();
      }
      if (selectedServices.length === 0) {
        showError('Vui lòng chọn ít nhất một dịch vụ trước khi tiếp tục.');
        return;
      }
    }

    if (step === 4) {
      const time = document.getElementById('bookingTime').value;
      if (!time) {
        showError('Vui lòng chọn khung giờ trước khi tiếp tục.');
        return;
      }
      if (isBookingConflict) {
        showError('Lịch hẹn bị trùng, vui lòng chọn thời gian khác!!!');
        return;
      }

      // Bỏ modal xác nhận sdt, tiến thẳng sang bước xác nhận
      populateSummaryForReview();
      document.querySelectorAll('.booking-step').forEach((step) => (step.style.display = 'none'));
      document.getElementById(`step${step}`).style.display = 'block';
      return;
    }

    const currentStep = document.querySelector('.booking-step:not([style*="display: none"])');
    currentStep.style.display = 'none';
    document.getElementById(`step${step}`).style.display = 'block';
  }

  function prevStep(step) {
    resetBookingStep();
    const currentStep = document.querySelector('.booking-step:not([style*="display: none"])');
    currentStep.style.display = 'none';
    document.getElementById(`step${step}`).style.display = 'block';

    // When returning to step 3 (date/time selection), automatically activate today tab
    if (step === 3) {
      showToday();
    }
  }

  function populateSummaryForReview() {
    bookingData.services = selectedServices.map((service) => service.name);
    bookingData.customerName =
      document.getElementById('customerName').textContent ||
      document.getElementById('customerNameInput').value;
    bookingData.customerPhone =
      document.getElementById('customerPhone').textContent ||
      document.getElementById('customerPhone').value;

    // Get hairdresser from hidden input (pill structure)
    const hairdresserInput = document.getElementById('hairdresserSelect');
    bookingData.hairdresser = hairdresserInput ? hairdresserInput.value : '';

    // Get branch name from pill display text (not ID from hidden input)
    const branchPillDisplay = document.querySelector('#branchPillDisplay .pill-item');
    bookingData.branch = branchPillDisplay ? branchPillDisplay.textContent.trim() : 'Chưa chọn';
    bookingData.date =
      document.getElementById('timeSlotsToday').style.display === 'block'
        ? selectedDateToday
        : selectedOtherDate;
    bookingData.time =
      document.getElementById('timeSlotsToday').style.display === 'block'
        ? selectedTimeToday
        : selectedTimeOtherDay;
    bookingData.customerCount = 1; // Default to 1 customer
    bookingData.silentService = document.getElementById('silentService').checked ? 'Có' : 'Không';

    document.getElementById('selectedService').textContent = bookingData.services.join(', ');
    document.getElementById('selectedCustomerName').textContent = bookingData.customerName;
    document.getElementById('selectedCustomerPhone').textContent = bookingData.customerPhone;
    document.getElementById('selectedHairdresser').textContent = bookingData.hairdresser;

    // Display branch name in summary
    const selectedBranchElement = document.getElementById('selectedBranch');
    if (selectedBranchElement) {
      selectedBranchElement.textContent = bookingData.branch || 'Chưa chọn';
    }

    document.getElementById('selectedDate').textContent = bookingData.date;
    document.getElementById('selectedTime').textContent = bookingData.time;
    document.getElementById('selectedSilentService').textContent = bookingData.silentService;
  }

  function loadSubmit() {
    const submitBookingButton = document.getElementById('submitBooking');
    if (submitBookingButton) {
      const newButton = submitBookingButton.cloneNode(true);
      submitBookingButton.parentNode.replaceChild(newButton, submitBookingButton);

      newButton.addEventListener(
        'click',
        async function (event) {
          event.preventDefault();
          if (newButton.disabled) return;

          newButton.disabled = true;

          // Store original button text and add loading state
          const originalText = newButton.textContent;
          newButton.textContent = 'Đang xử lý...';
          newButton.style.opacity = '0.7';

          bookingData.phone = document.getElementById('customerPhone').value.replace(/^0/, '');
          bookingData.customerType =
            bookingData.customerName === document.getElementById('customerNameInput').value
              ? 'Khách hàng mới'
              : 'Khách hàng cũ';
          // Get note from display area instead of old textarea
          const noteDisplayText = document.getElementById('noteDisplayText');
          bookingData.note = noteDisplayText ? noteDisplayText.textContent : '';
          bookingData.customerCount = 1; // Default to 1 customer
          bookingData.silentService = document.getElementById('silentService').checked
            ? 'Có'
            : 'Không';

          if (!bookingData.services.length) {
            showError('Vui lòng chọn ít nhất một dịch vụ.');
            newButton.disabled = false;
            newButton.textContent = originalText;
            newButton.style.opacity = '1';
            return;
          }

          if (!bookingData.hairdresser) {
            showError('Vui lòng chọn tên thợ.');
            newButton.disabled = false;
            newButton.textContent = originalText;
            newButton.style.opacity = '1';
            return;
          }

          document
            .querySelectorAll('.booking-step')
            .forEach((step) => (step.style.display = 'none'));
          document.getElementById('loadingStep').style.display = 'block';

          let idBooking = '';
          try {
            const response = await fetch(`${checkinData.restUrl}last-booking-number`, {
              method: 'GET',
              headers: { 'Content-Type': 'application/json' },
            });
            if (!response.ok) throw new Error('Network response was not ok');
            const data = await response.json();
            if (data.success && data.id_booking) {
              idBooking = data.id_booking;
            } else {
              throw new Error(data.message || 'Không thể tạo mã đặt lịch.');
            }
          } catch (error) {
            console.error('Error generating booking ID:', error);
            showError('Không thể tạo mã đặt lịch. Vui lòng thử lại.');
            newButton.disabled = false;
            newButton.textContent = originalText;
            newButton.style.opacity = '1';
            return;
          }

          bookingData.idBooking = idBooking;

          // Lấy Zalo UID từ localStorage (nếu khách đã đồng ý cấp quyền)
          const zaloUid = localStorage.getItem('zalo_uid');
          if (zaloUid) {
            bookingData.id_zalo = zaloUid;
            console.log('📱 Including Zalo UID in booking:', zaloUid);
          }

          const endpoint = 'bookings';

          try {
            const response = await fetch(`${checkinData.restUrl}${endpoint}`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify(bookingData),
            });
            if (!response.ok) throw new Error('Network response was not ok');

            document
              .querySelectorAll('.booking-step')
              .forEach((step) => (step.style.display = 'none'));
            document.getElementById('loadingStep').style.display = 'none';
            document.getElementById('successStep').style.display = 'block';
          } catch (error) {
            console.error('Error submitting booking:', error);
            showError('Không thể gửi đặt lịch. Vui lòng thử lại.');
            newButton.disabled = false;
            newButton.textContent = originalText;
            newButton.style.opacity = '1';
            document.getElementById('loadingStep').style.display = 'none';
            document.getElementById('step4').style.display = 'block';
          }
        },
        { once: true },
      );
    }
  }

  function resetBookingStep() {
    selectedTimeToday = '';
    selectedTimeOtherDay = '';
    selectedOtherDate = '';
    document.getElementById('bookingTime').value = '';
    document.getElementById('timeButtonsToday').innerHTML = '';
    document.getElementById('timeButtonsOtherDay').innerHTML = '';
    document.getElementById('displayedDate').textContent = '';
    updateSelectedServicesDisplay();
    updateNextButtonState();
  }

  function resetBookingForm() {
    // Reset form fields
    document.getElementById('customerPhone').value = '';
    document.getElementById('customerNameInput').value = '';
    document.getElementById('silentService').checked = false;

    // Reset customer info sections
    document.getElementById('customerInfo').style.display = 'none';
    document.getElementById('newCustomerInfo').style.display = 'none';
    const customerNameEl = document.getElementById('customerName');
    const oldHairdresserEl = document.getElementById('oldHairdresser');
    if (customerNameEl) customerNameEl.textContent = '';
    if (oldHairdresserEl) oldHairdresserEl.textContent = '';
    customerExists = null;

    // Reset note display
    const noteDisplayArea = document.getElementById('noteDisplayArea');
    const noteDisplayText = document.getElementById('noteDisplayText');
    const addNoteBtn = document.getElementById('addNoteBtn');
    const noteModalTextarea = document.getElementById('noteModalTextarea');

    if (noteDisplayArea) noteDisplayArea.style.display = 'none';
    if (noteDisplayText) noteDisplayText.textContent = '';
    if (addNoteBtn) addNoteBtn.style.display = 'flex';
    if (noteModalTextarea) noteModalTextarea.value = '';

    // Reset branch select
    const branchSelect = document.getElementById('branchSelect');
    if (branchSelect) {
      branchSelect.value = '';
    }

    // Reset hairdresser
    document.getElementById('hairdresserSelect').innerHTML =
      '<option value="">-- Chọn Thợ Phục Vụ --</option>';
    document.getElementById('hairdresserStatus').textContent = '';
    hairdresserName = '';

    // Reset services
    selectedServices = [];
    updateSelectedServicesDisplay();

    // Clear service grid active states
    document.querySelectorAll('.booking-service-card.active').forEach((card) => {
      card.classList.remove('active');
    });

    // Reset time slots
    document.getElementById('bookingTime').value = '';
    document.getElementById('timeButtonsToday').innerHTML = '';
    document.getElementById('timeButtonsOtherDay').innerHTML = '';
    selectedTimeToday = '';
    selectedTimeOtherDay = '';
    selectedDateToday = '';
    selectedOtherDate = '';

    // Reset steps
    document.querySelectorAll('.booking-step').forEach((step) => (step.style.display = 'none'));
    document.getElementById('step1').style.display = 'block';

    // Destroy flatpickr
    if (flatpickrInstance) {
      flatpickrInstance.destroy();
      flatpickrInstance = null;
    }

    // Reset booking data
    bookingData = {
      customerName: '',
      customerPhone: '',
      hairdresser: '',
      services: [],
      date: '',
      time: '',
      customerCount: 1,
      silentService: 'Không',
    };
  }

  const closePopupButton = document.querySelector('#bookingPopup .close-popup-button');
  if (closePopupButton) {
    closePopupButton.addEventListener('click', function () {
      document.getElementById('bookingPopup').style.display = 'none';
      document.body.classList.remove('modal-open');
      resetBookingForm();
    });
  }

  const viewReviewButton = document.getElementById('viewReviewBtn');
  if (viewReviewButton) {
    viewReviewButton.addEventListener('click', function () {
      document.getElementById('bookingPopup').style.display = 'none';
      document.body.classList.remove('modal-open');
      resetBookingForm();
      window.location.href = '#reviews';
    });
  }

  const viewBookingButton = document.getElementById('viewBookingBtn');
  if (viewBookingButton) {
    viewBookingButton.addEventListener('click', function () {
      const customerPhone = document.getElementById('customerPhone').value.replace(/^0/, '');
      const bookingUrl = `https://vangroupbarbershop.store/customer-member?booking_id=${customerPhone}`;
      document.querySelector('.preloader').style.display = 'flex';
      document.getElementById('bookingPopup').style.display = 'none';
      document.body.classList.remove('modal-open');
      resetBookingForm();
      window.location.href = bookingUrl;
      document.querySelector('.preloader').style.display = 'none';
    });
  }

  // Note modal functionality - No auto initialization needed

  // Expose global functions
  window.checkCustomer = checkCustomer;
  window.showHairdresserPopup = showHairdresserPopup;
  window.hideHairdresserPopup = hideHairdresserPopup;
  window.selectHairdresser = selectHairdresser;
  window.showServicePopup = showServicePopup;
  window.hideServicePopup = hideServicePopup;
  window.removeService = removeService;
  window.filterServices = filterServices;
  window.showToday = showToday;
  window.generateTodayTimeButtons = generateTodayTimeButtons;
  window.showOtherDay = showOtherDay;
  window.loadOtherDaySlots = loadOtherDaySlots;
  window.nextStep = nextStep;
  window.prevStep = prevStep;
  window.showServiceGroup = showServiceGroup;
  window.openNoteModal = openNoteModal;
  window.closeNoteModal = closeNoteModal;
  window.confirmNote = confirmNote;
});

// ==================== NOTE MODAL FUNCTIONS ====================

function openNoteModal() {
  const modal = document.getElementById('noteModal');
  const textarea = document.getElementById('noteModalTextarea');
  const displayText = document.getElementById('noteDisplayText');

  // Load existing note if any
  if (displayText && displayText.textContent) {
    textarea.value = displayText.textContent;
  }

  modal.style.display = 'flex';
  setTimeout(() => textarea.focus(), 100);
}

function closeNoteModal() {
  const modal = document.getElementById('noteModal');
  modal.style.display = 'none';
}

function confirmNote() {
  const textarea = document.getElementById('noteModalTextarea');
  const noteText = textarea.value.trim();
  const displayArea = document.getElementById('noteDisplayArea');
  const displayText = document.getElementById('noteDisplayText');
  const addNoteBtn = document.getElementById('addNoteBtn');

  if (noteText) {
    // Show note display area
    displayText.textContent = noteText;
    displayArea.style.display = 'flex';
    addNoteBtn.style.display = 'none';
  } else {
    // Hide note display if empty
    displayArea.style.display = 'none';
    addNoteBtn.style.display = 'flex';
  }

  closeNoteModal();
}
