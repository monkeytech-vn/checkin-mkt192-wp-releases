/**
 * Modern App-Style Customer Member Page
 * JavaScript for handling navigation, API calls, and UI interactions
 */

(function () {
  'use strict';

  // Global state
  let currentTab = 'home';
  let customerData = null;
  let lastSearchedPhone = null; // Track last searched phone number
  let currentCustomerPhone = null; // Track current customer phone (for visit history)

  // Zalo Social Login state
  let zaloSocialConfig = null; // { app_id, callback_url }
  let zaloLoginData = null; // { zalo_id, zalo_name, zalo_avatar }
  let brandColors = {
    primary: getComputedStyle(document.documentElement).getPropertyValue('--primary-color').trim(),
    secondary: getComputedStyle(document.documentElement)
      .getPropertyValue('--secondary-color')
      .trim(),
  };

  // localStorage keys
  const STORAGE_KEY_SESSION = 'checkin_member_session';

  // Initialize on DOM ready
  document.addEventListener('DOMContentLoaded', function () {
    console.log('🚀 Customer Member Page V2 initialized');

    initializeApp();
    initZaloSocialLogin();
    checkUrlParameters();
    attachEventListeners();
    attachPhoneSearchListeners();
  });

  /**
   * Initialize application
   */
  function initializeApp() {
    // Set brand colors from WordPress if available
    if (window.checkinData && window.checkinData.checkinBrandColors) {
      document.documentElement.style.setProperty(
        '--primary-color',
        window.checkinData.checkinBrandColors.primary
      );
      document.documentElement.style.setProperty(
        '--primary-dark',
        adjustColor(window.checkinData.checkinBrandColors.primary, -20)
      );
      document.documentElement.style.setProperty(
        '--primary-light',
        adjustColor(window.checkinData.checkinBrandColors.primary, 20)
      );
      brandColors.primary = window.checkinData.checkinBrandColors.primary;
    }

    // Initialize QRCode library check
    if (typeof QRCode === 'undefined') {
      console.warn('⚠️ QRCode library not loaded');
    }

    // Ẩn profile header ban đầu (chưa tìm kiếm)
    const profileHeader = document.getElementById('profileHeader');
    if (profileHeader) {
      profileHeader.style.display = 'none';
    }
  }

  /**
   * Check URL parameters for auto-navigation
   */
  function checkUrlParameters() {
    const urlParams = new URLSearchParams(window.location.search);
    const phone = urlParams.get('phone');
    const customerPhone = urlParams.get('customer_phone');
    const customerId = urlParams.get('customer_id');
    const bookingCode = urlParams.get('booking_code');
    const bookingId = urlParams.get('booking_id'); // Thêm hỗ trợ booking_id

    // Priority: Booking lookup parameters (booking_code or booking_id)
    if (bookingCode || bookingId) {
      const searchValue = bookingCode || bookingId;
      console.log('� Auto-search booking:', searchValue);

      // Switch to booking tab and search
      switchTab('booking');
      setTimeout(() => {
        document.getElementById('bookingSearchInput').value = searchValue;
        searchBooking();
      }, 300);
    } else if (phone || customerPhone || customerId) {
      // Customer lookup parameters
      const searchValue = phone || customerPhone || customerId;
      console.log('Auto-search with:', searchValue);

      // Check hash to determine which tab to use
      const hash = window.location.hash.replace('#', '');
      if (hash === 'booking') {
        // If #booking hash, search in booking tab
        switchTab('booking');
        setTimeout(() => {
          document.getElementById('bookingSearchInput').value = searchValue;
          searchBooking();
        }, 300);
      } else {
        // Default: Switch to promo tab and search
        switchTab('promo');
        setTimeout(() => {
          document.getElementById('promoSearchInput').value = searchValue;
          searchPromo();
        }, 300);
      }
    } else {
      // No query params — check hash for tab navigation only
      const hash = window.location.hash.replace('#', '');
      const validTabs = ['home', 'promo', 'booking', 'history'];
      if (hash && validTabs.includes(hash)) {
        console.log('Hash navigation to tab:', hash);
        switchTab(hash);
      }
    }
  }

  /**
   * Attach event listeners
   */
  function attachEventListeners() {
    // Promo search
    const promoSearchBtn = document.getElementById('promoSearchBtn');
    const promoSearchInput = document.getElementById('promoSearchInput');

    if (promoSearchBtn) {
      promoSearchBtn.addEventListener('click', searchPromo);
    }

    if (promoSearchInput) {
      promoSearchInput.addEventListener('keypress', function (e) {
        if (e.key === 'Enter') {
          searchPromo();
        }
      });
    }

    // Booking search
    const bookingSearchBtn = document.getElementById('bookingSearchBtn');
    const bookingSearchInput = document.getElementById('bookingSearchInput');

    if (bookingSearchBtn) {
      bookingSearchBtn.addEventListener('click', searchBooking);
    }

    if (bookingSearchInput) {
      bookingSearchInput.addEventListener('keypress', function (e) {
        if (e.key === 'Enter') {
          searchBooking();
        }
      });
    }

    // Stat cards click to switch tabs
    document.querySelectorAll('.stat-card').forEach((card, index) => {
      card.addEventListener('click', function () {
        const tabs = ['promo', 'booking', 'history'];
        if (tabs[index]) {
          switchTab(tabs[index]);
        }
      });
    });

    // Hash change listener — switch tabs when URL hash changes
    window.addEventListener('hashchange', function () {
      const hash = window.location.hash.replace('#', '');
      const validTabs = ['home', 'promo', 'booking', 'history'];
      if (hash && validTabs.includes(hash) && hash !== currentTab) {
        switchTab(hash);
      }
    });

    // Avatar click to open image popup
    const userAvatar = document.getElementById('userAvatar');
    if (userAvatar) {
      userAvatar.style.cursor = 'pointer';
      userAvatar.addEventListener('click', function () {
        const avatarSrc = this.src;
        // Open popup for all avatars (both real and ui-avatars)
        if (avatarSrc) {
          openImagePopup(avatarSrc);
        }
      });
    }

    // Zalo Social Login button
    const zaloLoginBtn = document.getElementById('zaloLoginBtn');
    if (zaloLoginBtn) {
      zaloLoginBtn.addEventListener('click', startZaloLogin);
    }

    // Zalo Phone Linking button & Enter key
    const zaloLinkBtn = document.getElementById('zaloLinkBtn');
    if (zaloLinkBtn) {
      zaloLinkBtn.addEventListener('click', linkZaloPhone);
    }

    const zaloLinkPhoneInput = document.getElementById('zaloLinkPhoneInput');
    if (zaloLinkPhoneInput) {
      zaloLinkPhoneInput.addEventListener('keypress', function (e) {
        if (e.key === 'Enter') linkZaloPhone();
      });
    }
  }

  /**
   * Switch between tabs
   */
  window.switchTab = function (tabName) {
    currentTab = tabName;

    // Sync URL hash (without triggering hashchange loop)
    const newHash = '#' + tabName;
    if (window.location.hash !== newHash) {
      history.replaceState(null, '', newHash);
    }

    // Update tab panes
    document.querySelectorAll('.tab-pane').forEach((pane) => {
      pane.classList.remove('active');
    });

    const targetPane = document.getElementById(tabName + 'Pane');
    if (targetPane) {
      targetPane.classList.add('active');
    }

    // Update bottom nav
    document.querySelectorAll('.nav-item').forEach((item) => {
      item.classList.remove('active');
    });

    const targetNavItem = document.querySelector(`.nav-item[data-tab="${tabName}"]`);
    if (targetNavItem) {
      targetNavItem.classList.add('active');
    }

    // Auto-fill phone number from last search when switching to promo/booking tabs
    if (lastSearchedPhone) {
      if (tabName === 'promo') {
        const promoInput = document.getElementById('promoSearchInput');
        const promoResult = document.getElementById('promoResult');
        // Only auto-fill and search if input is empty OR result is hidden
        if (
          promoInput &&
          (!promoInput.value || !promoResult || promoResult.style.display === 'none')
        ) {
          promoInput.value = lastSearchedPhone;
          console.log('📱 Auto-filled promo search with:', lastSearchedPhone);
          // Auto search after a short delay
          setTimeout(() => searchPromo(), 300);
        }
      } else if (tabName === 'booking') {
        const bookingInput = document.getElementById('bookingSearchInput');
        const bookingResult = document.getElementById('bookingResult');
        // Only auto-fill and search if input is empty OR result is hidden
        if (
          bookingInput &&
          (!bookingInput.value || !bookingResult || bookingResult.style.display === 'none')
        ) {
          bookingInput.value = lastSearchedPhone;
          console.log('📱 Auto-filled booking search with:', lastSearchedPhone);
          // Auto search after a short delay
          setTimeout(() => searchBooking(), 300);
        }
      }
    }

    // Smooth scroll to top of content
    document.getElementById('contentWrapper').scrollIntoView({ behavior: 'smooth' });

    console.log('📑 Switched to tab:', tabName);
  };

  /**
   * Search for promo code
   */
  function searchPromo() {
    const searchInput = document.getElementById('promoSearchInput');
    const searchValue = searchInput.value.trim();

    if (!searchValue) {
      showToast('error', 'Vui lòng nhập số điện thoại hoặc mã khách hàng');
      return;
    }

    // Store phone number if it's a phone format
    if (/^\d{9,10}$/.test(searchValue)) {
      lastSearchedPhone = searchValue;
      console.log('💾 Stored phone for auto-fill:', lastSearchedPhone);
    }

    console.log('🔍 Searching promo for:', searchValue);
    showLoading(true);

    // Call API with customerInput field (API expects this field name)
    const requestData = {
      customerInput: searchValue,
    };

    // Call API
    fetch('/wp-json/vg/v1/customer-promo', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(requestData),
    })
      .then((response) => response.json())
      .then((data) => {
        console.log('✅ Promo API response:', data);
        showLoading(false);

        if (data.success) {
          // Check if customer is a member
          if (
            !data.membershipLevel ||
            data.membershipLevel === '' ||
            data.membershipLevel === 'None' ||
            data.membershipLevel === null
          ) {
            // Not a member - hide old promo result and show registration modal
            hidePromoResult();

            // Clear customerData to prevent showing old info
            customerData = null;

            // Show non-member modal
            showNonMemberModal(data);
          } else {
            // Is a member - show promo normally
            customerData = data;

            // Store current customer phone for visit history tracking
            if (data.customerPhone) {
              currentCustomerPhone = normalizePhone(data.customerPhone);
              console.log('💾 Stored current customer phone:', currentCustomerPhone);
            }

            displayPromoResult(data);
            updateHomeTabData(data);
            updateProfileHeader(data);
          }
        } else {
          showToast('error', data.message || 'Không tìm thấy thông tin');
          hidePromoResult();
        }
      })
      .catch((error) => {
        console.error('❌ Promo API error:', error);
        showLoading(false);
        showToast('error', 'Lỗi kết nối. Vui lòng thử lại.');
        hidePromoResult();
      });
  }

  /**
   * Display promo result
   */
  function displayPromoResult(data) {
    const promoResult = document.getElementById('promoResult');

    if (!promoResult) return;

    // Show result container
    promoResult.style.display = 'block';

    // Hiện profile header khi có kết quả
    const profileHeader = document.getElementById('profileHeader');
    if (profileHeader) profileHeader.style.display = '';

    // Update customer data in profile if available (API uses camelCase)
    if (data.customerName) {
      document.getElementById('userName').textContent = data.customerName;
    }
    if (data.customerPhone) {
      document.getElementById('userPhone').textContent = formatPhone(data.customerPhone);
    }
    if (data.avatar) {
      document.getElementById('userAvatar').src = data.avatar;
    }
    if (data.membershipLevel) {
      document.getElementById('membershipType').textContent = data.membershipLevel;
    }

    // Check if has promo code (API returns 'promoCode' not 'promo_code')
    const hasPromoCode = data.promoCode && data.promoCode !== '';

    if (hasPromoCode) {
      // Display promo code details (API uses camelCase)
      document.getElementById('promoCodeLarge').textContent = data.promoCode;

      const statusBadge = document.getElementById('promoStatusLarge');
      if (data.promoStatus === 'Có hiệu lực') {
        statusBadge.textContent = 'Có hiệu lực';
        statusBadge.style.background = 'rgba(0, 212, 170, 0.15)';
        statusBadge.style.color = 'var(--ads-manager-secondary)';
        statusBadge.style.borderColor = 'var(--success)';
      } else {
        statusBadge.textContent = 'Hết hạn';
        statusBadge.style.background = 'rgba(238, 90, 111, 0.15)';
        statusBadge.style.color = 'var(--ads-manager-secondary)';
        statusBadge.style.borderColor = 'var(--danger)';
      }

      // Generate QR code
      generateQRCode('promoQr', data.promoCode);

      // Update details (API uses camelCase)
      document.getElementById('promoIssueDate').textContent = data.issueDate || '--';
      document.getElementById('promoExpiry').textContent = data.expiry || '--';
      document.getElementById('promoTypeDetail').textContent =
        data.promoType || 'Khuyến mãi thành viên';
      document.getElementById('promoDiscount').textContent = data.discount || '--';

      // Show all sections
      document.querySelector('.promo-qr-section').style.display = 'block';
      document.querySelector('.promo-details-section').style.display = 'block';
      document.querySelector('.promo-terms').style.display = 'block';
    } else {
      // No promo code - show friendly message
      document.getElementById('promoCodeLarge').textContent = 'Chưa có mã';

      const statusBadge = document.getElementById('promoStatusLarge');
      statusBadge.textContent = 'Đang phân phối';
      statusBadge.style.background = 'rgba(254, 202, 87, 0.15)';
      statusBadge.style.color = 'var(--warning)';
      statusBadge.style.borderColor = 'var(--warning)';

      // Hide QR and details
      document.querySelector('.promo-qr-section').style.display = 'none';
      document.querySelector('.promo-details-section').style.display = 'none';
      document.querySelector('.promo-terms').style.display = 'none';

      // Show friendly message in terms section
      const termsSection = document.querySelector('.promo-terms');
      termsSection.style.display = 'block';
      termsSection.innerHTML = `
                <div style="text-align: center; padding: 20px;">
                    <i class="fas fa-gift" style="font-size: 48px; color: var(--primary-color); margin-bottom: 16px;"></i>
                    <h4 style="margin-bottom: 8px;">Hệ thống đang phân phối mã khuyến mãi</h4>
                    <p style="color: var(--text-muted); font-size: 14px;">Vui lòng ghé shop hoặc liên hệ để nhận mã ưu đãi mới</p>
                </div>
            `;
    }

    // Update visit count in stats (API uses camelCase 'visitHistory')
    console.log('API Response visitHistory:', data.visitHistory);
    if (data.visitHistory && data.visitHistory.length > 0) {
      document.getElementById('visitCount').textContent = data.visitHistory.length;
      displayVisitHistory(data.visitHistory);
      // Also update recent activity on home tab
      displayRecentActivity(data.visitHistory);
    } else {
      console.warn('No visitHistory in API response:', data);
      // Reset visit count to 0
      document.getElementById('visitCount').textContent = '0';

      // Reset history list to empty state
      const historyList = document.getElementById('historyList');
      if (historyList) {
        historyList.innerHTML =
          '<div class="empty-state"><i class="fas fa-history"></i><p>Chưa có lịch sử ghé thăm</p></div>';
      }

      // Reset recent activity to empty state
      const activityList = document.getElementById('recentActivity');
      if (activityList) {
        activityList.innerHTML =
          '<div class="empty-state"><i class="fas fa-calendar-day"></i><p>Chưa có hoạt động</p></div>';
      }
    }

    // Animate result
    promoResult.style.animation = 'fadeInUp 0.5s ease';
  }

  /**
   * Hide promo result
   */
  function hidePromoResult() {
    const promoResult = document.getElementById('promoResult');
    if (promoResult) {
      promoResult.style.display = 'none';
    }
  }

  /**
   * Search for booking
   */
  function searchBooking() {
    const searchInput = document.getElementById('bookingSearchInput');
    const searchValue = searchInput.value.trim();

    if (!searchValue) {
      showToast('error', 'Vui lòng nhập số điện thoại hoặc mã booking');
      return;
    }

    // Store phone number if it's a phone format
    if (/^\d{9,10}$/.test(searchValue)) {
      lastSearchedPhone = searchValue;
      console.log('💾 Stored phone for auto-fill:', lastSearchedPhone);
    }

    console.log('🔍 Searching booking for:', searchValue);
    showLoading(true);

    // Determine search type
    let requestData = {};
    if (/^\d{9,10}$/.test(searchValue)) {
      requestData.customer_phone = searchValue;
    } else {
      requestData.booking_code = searchValue;
    }

    // Call API
    fetch('/wp-json/vg/v1/customer-booking', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(requestData),
    })
      .then((response) => response.json())
      .then((data) => {
        console.log('✅ Booking API response:', data);
        showLoading(false);

        if (data.success) {
          if (data.has_active_booking === false) {
            // No active booking, but has history
            hideBookingResult(); // hide detail card
            if (data.all_bookings && data.all_bookings.length > 0) {
              renderBookingHistory(data.all_bookings);
              showToast('info', data.message || 'Không có booking đang chờ, hiển thị lịch sử.');
            }
            updateProfileHeaderWithoutAvatar(data);
          } else {
            displayBookingResult(data);
            // Update profile header but exclude avatar to keep it consistent
            updateProfileHeaderWithoutAvatar(data);
          }

          // Check if this is a different customer than the one with visit history
          const bookingPhone = data.customer_phone ? normalizePhone(data.customer_phone) : null;

          if (bookingPhone && currentCustomerPhone && bookingPhone !== currentCustomerPhone) {
            // Different customer - reset visit history
            console.log('⚠️ Different customer detected, resetting visit history');
            console.log('Current:', currentCustomerPhone, 'Booking:', bookingPhone);
            resetVisitHistory();
            currentCustomerPhone = bookingPhone; // Update to new customer
          } else if (bookingPhone && !currentCustomerPhone) {
            // First booking search without promo search - just update current customer
            currentCustomerPhone = bookingPhone;
            console.log('💾 Set current customer from booking:', currentCustomerPhone);
          }
          // If same customer - keep visit history as is
        } else {
          showToast('error', data.message || 'Không tìm thấy thông tin booking');
          hideBookingResult();
        }
      })
      .catch((error) => {
        console.error('❌ Booking API error:', error);
        showLoading(false);
        showToast('error', 'Lỗi kết nối. Vui lòng thử lại.');
        hideBookingResult();
      });
  }

  /**
   * Display booking result
   */
  function displayBookingResult(data) {
    const bookingResult = document.getElementById('bookingResult');

    if (!bookingResult) return;

    // Show result container
    bookingResult.style.display = 'block';

    // Update booking code
    document.getElementById('bookingCodeLarge').textContent = data.booking_code || 'N/A';

    // Update status
    const statusBadge = document.getElementById('bookingStatusLarge');
    if (data.booking_status === 'confirmed' || data.booking_status === 'Đã xác nhận') {
      statusBadge.textContent = 'Đã xác nhận';
      statusBadge.style.background = 'rgba(0, 212, 170, 0.15)';
      statusBadge.style.color = 'var(--ads-manager-secondary)';
      statusBadge.style.borderColor = 'var(--ads-manager-secondary)';
    } else {
      statusBadge.textContent = data.booking_status || 'Chờ xác nhận';
      statusBadge.style.background = 'rgba(254, 202, 87, 0.15)';
      statusBadge.style.color = 'var(--ads-manager-secondary)';
      statusBadge.style.borderColor = 'var(--ads-manager-secondary)';
    }

    // Generate QR code
    if (data.booking_code) {
      generateQRCode('bookingQr', data.booking_code);
    }

    // Update details
    document.getElementById('bookingCustomerName').textContent = data.customer_name || '--';
    document.getElementById('bookingDate').textContent = formatDate(data.booking_date);
    document.getElementById('bookingTime').textContent = data.booking_time || '--';
    document.getElementById('bookingStaff').textContent = data.staff_name || '--';
    document.getElementById('bookingService').textContent = data.service_name || '--';
    document.getElementById('bookingNote').textContent = data.note || 'Không có';

    // Update profile if available
    if (data.customer_name) {
      document.getElementById('userName').textContent = data.customer_name;
    }
    if (data.customer_phone) {
      document.getElementById('userPhone').textContent = formatPhone(data.customer_phone);
    }

    // Animate result
    bookingResult.style.animation = 'fadeInUp 0.5s ease';

    // Render booking history list if available
    if (data.all_bookings && data.all_bookings.length > 0) {
      renderBookingHistory(data.all_bookings);
    }
  }

  /**
   * Render booking history list (similar to visit history)
   */
  function renderBookingHistory(bookings) {
    const section = document.getElementById('bookingHistorySection');
    const list = document.getElementById('bookingHistoryList');
    if (!section || !list) return;

    if (!bookings || bookings.length === 0) {
      section.style.display = 'none';
      return;
    }

    section.style.display = 'block';

    const statusColors = {
      'start': { bg: 'rgba(255, 215, 0, 0.15)', color: '#ffd700', border: 'rgba(255, 215, 0, 0.3)' },
      'pending': { bg: 'rgba(59, 130, 246, 0.15)', color: '#60a5fa', border: 'rgba(59, 130, 246, 0.3)' },
      'success': { bg: 'rgba(0, 212, 170, 0.15)', color: '#00d4aa', border: 'rgba(0, 212, 170, 0.3)' },
      'deleted': { bg: 'rgba(220, 38, 38, 0.15)', color: '#f87171', border: 'rgba(220, 38, 38, 0.3)' },
    };

    let html = '';
    bookings.forEach((bk) => {
      const colors = statusColors[bk.status_raw] || statusColors['start'];
      const dateStr = bk.booking_date ? formatDate(bk.booking_date) : '--';
      const timeStr = bk.booking_time || '--';

      html += `
        <div class="booking-history-item">
          <div class="booking-history-header">
            <div class="booking-history-code">
              <i class="fas fa-calendar-check"></i>
              <span>${bk.id_booking || '--'}</span>
            </div>
            <div class="booking-history-status" style="background:${colors.bg}; color:${colors.color}; border-color:${colors.border}">
              ${bk.status}
            </div>
          </div>
          <div class="booking-history-details">
            <div class="booking-history-row">
              <i class="fas fa-clock"></i>
              <span>${dateStr} — ${timeStr}</span>
            </div>
            <div class="booking-history-row">
              <i class="fas fa-cut"></i>
              <span>${bk.service_name || '--'}</span>
            </div>
            ${bk.staff_name && bk.staff_name !== '--' ? `
            <div class="booking-history-row">
              <i class="fas fa-user-tie"></i>
              <span>${bk.staff_name}</span>
            </div>` : ''}
          </div>
        </div>
      `;
    });

    list.innerHTML = html;
    section.style.animation = 'fadeInUp 0.5s ease';
  }

  /**
   * Hide booking result
   */
  function hideBookingResult() {
    const bookingResult = document.getElementById('bookingResult');
    if (bookingResult) {
      bookingResult.style.display = 'none';
    }
    const historySection = document.getElementById('bookingHistorySection');
    if (historySection) {
      historySection.style.display = 'none';
    }
  }

  /**
   * Update home tab with customer data
   */
  function updateHomeTabData(data) {
    // Update promo highlight on home (API uses camelCase)
    if (data.promoCode) {
      document.getElementById('promoTitleHome').textContent = 'Mã khuyến mãi của bạn';
      document.getElementById('promoCodeHome').textContent = data.promoCode;
      document.getElementById('promoDescHome').textContent = `Hạn dùng: ${data.expiry || '--'}`;

      const statusBadge = document.getElementById('promoStatusHome');
      if (data.promoStatus === 'Có hiệu lực') {
        statusBadge.textContent = 'Còn hạn';
        statusBadge.className = 'promo-status-badge active';
      } else {
        statusBadge.textContent = 'Hết hạn';
        statusBadge.className = 'promo-status-badge expired';
      }
    } else {
      document.getElementById('promoTitleHome').textContent = 'Ưu đãi thành viên';
      document.getElementById('promoCodeHome').textContent = 'Chưa có mã';
      document.getElementById('promoDescHome').textContent = 'Ghé shop để nhận mã mới';

      const statusBadge = document.getElementById('promoStatusHome');
      statusBadge.textContent = 'Đang phân phối';
      statusBadge.className = 'promo-status-badge';
      statusBadge.style.background = 'rgba(254, 202, 87, 0.15)';
      statusBadge.style.color = 'var(--warning)';
    }

    // Update promo count
    document.getElementById('promoCount').textContent = data.promoCode ? '1' : '0';

    // Update visit history (API uses camelCase) - already handled in displayPromoResult
    // No need to duplicate here
  }

  /**
   * Update profile header
   */
  function updateProfileHeader(data) {
    // Hiện profile header khi có data
    const profileHeader = document.getElementById('profileHeader');
    if (profileHeader) profileHeader.style.display = '';

    // API uses camelCase field names
    if (data.customerName) {
      document.getElementById('userName').textContent = data.customerName;
    }

    if (data.customerPhone) {
      document.getElementById('userPhone').textContent = formatPhone(data.customerPhone);
    }

    if (data.avatar) {
      document.getElementById('userAvatar').src = data.avatar;
    } else {
      // Set default avatar
      document.getElementById('userAvatar').src =
        'https://ui-avatars.com/api/?name=' +
        encodeURIComponent(data.customerName || 'User') +
        '&background=00d4aa&color=fff&size=200';
    }

    if (data.membershipLevel) {
      document.getElementById('membershipType').textContent = data.membershipLevel;
    }

    // Update membership points (if available in future)
    // document.getElementById('membershipPoints').innerHTML = '<i class="fas fa-star"></i> ' + (data.points || 0) + ' điểm';
  }

  /**
   * Update profile header for booking results with smart avatar logic
   */
  function updateProfileHeaderWithoutAvatar(data) {
    // Hiện profile header khi có data
    const profileHeader = document.getElementById('profileHeader');
    if (profileHeader) profileHeader.style.display = '';

    // Booking API uses snake_case for these fields
    if (data.customer_name) {
      document.getElementById('userName').textContent = data.customer_name;
    }

    if (data.customer_phone) {
      document.getElementById('userPhone').textContent = formatPhone(data.customer_phone);
    }

    // Smart avatar logic:
    // 1. If no previous customerData (not searched promo yet) → use booking avatar
    // 2. If customerData exists and phone matches → use promo avatar
    // 3. If customerData exists but phone differs → use booking avatar to avoid confusion

    const bookingPhone = normalizePhone(data.customer_phone);
    const promoPhone = customerData ? normalizePhone(customerData.customerPhone) : '';

    console.log(
      '🔍 Avatar logic - Booking:',
      bookingPhone,
      'Promo:',
      promoPhone,
      'Match:',
      bookingPhone === promoPhone
    );

    if (!customerData) {
      // Case 1: No promo data yet → use booking avatar from API
      if (data.avatar) {
        document.getElementById('userAvatar').src = data.avatar;
        console.log('📸 Using booking avatar from API');
      } else {
        // Fallback to generated avatar by name
        document.getElementById('userAvatar').src =
          'https://ui-avatars.com/api/?name=' +
          encodeURIComponent(data.customer_name || 'User') +
          '&background=00d4aa&color=fff&size=200';
        console.log('📸 Using generated avatar by booking name');
      }
    } else if (bookingPhone === promoPhone) {
      // Case 2: Phone matches promo → keep promo avatar (already set)
      // Avatar is already set from promo search, no need to change
      console.log('📱 Booking phone matches promo, keeping promo avatar');
    } else {
      // Case 3: Phone differs → use booking avatar to avoid confusion
      if (data.avatar) {
        document.getElementById('userAvatar').src = data.avatar;
        console.log('📸 Phones differ, using booking avatar from API');
      } else {
        // Fallback to generated avatar by booking customer name
        document.getElementById('userAvatar').src =
          'https://ui-avatars.com/api/?name=' +
          encodeURIComponent(data.customer_name || 'User') +
          '&background=00d4aa&color=fff&size=200';
        console.log('� Phones differ, using generated avatar by booking name');
      }
    }
  }

  /**
   * Display visit history in history tab
   */
  function displayVisitHistory(visits) {
    const historyList = document.getElementById('historyList');

    if (!historyList || !visits || visits.length === 0) {
      console.warn('displayVisitHistory: No history list element or empty visits', {
        historyList,
        visits,
      });
      return;
    }

    console.log('displayVisitHistory: Processing visits', visits);
    historyList.innerHTML = '';

    // Support both old format (date strings) and new format (objects)
    visits.forEach((visitItem, index) => {
      console.log(`Processing visit item ${index}:`, visitItem);

      const isObject = visitItem && typeof visitItem === 'object';

      // Handle both old format (string dates) and new format (objects)
      let created, displayTitle, dataCode;

      if (isObject) {
        // New format: {invoice_id, code, created_at, date_display}
        created = visitItem.created_at || visitItem.createdAt || visitItem.date;
        // Always show invoice code without "Mã hóa đơn:" prefix
        if (visitItem.code) {
          displayTitle = visitItem.code;
          dataCode = visitItem.code;
        } else if (visitItem.invoice_id) {
          displayTitle = visitItem.invoice_id;
          dataCode = visitItem.invoice_id;
        } else {
          // Object but no code - use date as fallback
          created = created || visitItem;
          const visitDate = new Date(created);
          const formattedDate = `${visitDate.getDate().toString().padStart(2, '0')}/${(
            visitDate.getMonth() + 1
          )
            .toString()
            .padStart(2, '0')}/${visitDate.getFullYear()}`;
          displayTitle = formattedDate;
          dataCode = formattedDate;
        }
      } else {
        // Old format: string date like "10/11/2025"
        created = visitItem;
        const visitDate = new Date(created);
        const formattedDate = `${visitDate.getDate().toString().padStart(2, '0')}/${(
          visitDate.getMonth() + 1
        )
          .toString()
          .padStart(2, '0')}/${visitDate.getFullYear()}`;
        displayTitle = formattedDate;
        dataCode = formattedDate;
      }

      if (!created) {
        console.warn('No created date found for visit item:', visitItem);
        return;
      }

      const visitDate = new Date(created);
      const day = visitDate.getDate();
      const month = visitDate.toLocaleDateString('vi-VN', { month: 'short' });

      const historyItem = document.createElement('div');
      historyItem.className = 'history-item';
      historyItem.innerHTML = `
                <div class="history-date-badge">
                    <span class="history-date-day">${day}</span>
                    <span class="history-date-month">${month}</span>
                </div>
                <div class="history-info">
                    <div class="history-title">${displayTitle}</div>
                    <div class="history-desc">${formatDateTime(created)}</div>
                </div>
                <button class="btn-invoice-detail" data-code="${dataCode}" aria-label="Xem chi tiết ${displayTitle}">Xem chi tiết</button>
            `;
      historyList.appendChild(historyItem);
    });

    // Attach click handlers to detail buttons
    historyList.querySelectorAll('.btn-invoice-detail').forEach((btn) => {
      btn.addEventListener('click', function (e) {
        const code = this.getAttribute('data-code');
        if (!code) return;
        showInvoiceDetailModal(code);
      });
    });
  }

  // Fetch and show invoice details in a modal. Expects WP REST endpoint /vg/v1/invoice-detail?code=...
  function showInvoiceDetailModal(code) {
    showLoading(true);

    const tryFetch = (params) =>
      fetch(`/wp-json/vg/v1/invoice-detail?${params}`).then((res) => {
        if (!res.ok) {
          const err = new Error('Network response was not ok');
          err.status = res.status;
          throw err;
        }
        return res.json();
      });

    // First try by code
    tryFetch(`code=${encodeURIComponent(code)}`)
      .catch((err) => {
        // If not found (404) and code looks like a date dd/mm/YYYY, try created_at fallback
        if (err && err.status === 404) {
          const m = String(code).match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
          if (m) {
            const created_at = `${m[3]}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}`;
            return tryFetch(`created_at=${encodeURIComponent(created_at)}`);
          }
        }
        throw err;
      })
      .then((data) => {
        showLoading(false);
        // Build modal content
        const lines = [];
        // Use actual invoice code from API response, not the search parameter
        const invoiceCode =
          data.data?.code || data.data?.invoice_code || data.data?.invoice_id || code;
        const createdAt = data.data?.created_at || data.data?.createdAt || data.data?.date;

        lines.push(`<h3 style="margin-top:0">Mã hóa đơn: ${invoiceCode}</h3>`);
        lines.push(
          `<div style="font-size:13px;color:var(--text-gold-light);margin-bottom:8px">${formatDateTime(
            createdAt
          )}</div>`
        );
        const invoiceData = data.data || data;

        if (invoiceData.images && invoiceData.images.length) {
          lines.push(
            '<div class="invoice-images-container" style="display:flex;justify-content:center;gap:8px;flex-wrap:wrap;margin:8px 0">' +
              invoiceData.images
                .map(
                  (img, idx) =>
                    `<img src="${img}" data-index="${idx}" class="invoice-image-clickable" style="width:80px;height:80px;object-fit:cover;border-radius:8px;cursor:pointer;"/>`
                )
                .join('') +
              '</div>'
          );
        }
        lines.push(
          `<div style="margin-top:12px;color:var(--text-gold)"><b>Dịch vụ:</b> <span style="color:var(--text-white)">${
            Array.isArray(invoiceData.services)
              ? invoiceData.services.map((s) => s.service_name || s.name || s).join(', ')
              : invoiceData.service_name || invoiceData.services || '--'
          }</span></div>`
        );
        lines.push(
          `<div style="color:var(--text-gold)"><b>Thợ:</b> <span style="color:var(--text-white)">${
            invoiceData.staff_name ||
            invoiceData.staff ||
            (Array.isArray(invoiceData.services) && invoiceData.services[0]?.staff_name) ||
            '--'
          }</span></div>`
        );
        lines.push(
          `<div style="color:var(--text-gold)"><b>Tạm tính:</b> <span style="color:var(--text-white)">${formatMoney(
            invoiceData.subtotal
          )}</span></div>`
        );
        lines.push(
          `<div style="color:var(--text-gold)"><b>Giảm giá:</b> <span style="color:var(--text-white)">${formatMoney(
            invoiceData.discount
          )}</span></div>`
        );
        lines.push(
          `<div style="color:var(--text-gold)"><b>Tips:</b> <span style="color:var(--text-white)">${formatMoney(
            invoiceData.tips
          )}</span></div>`
        );
        lines.push(
          `<div style="margin-top:12px;font-size:18px;color:var(--text-gold)"><b>Tổng:</b> <span style="color:var(--primary-gold);font-weight:700">${formatMoney(
            invoiceData.total
          )}</span></div>`
        );

        showModal(lines.join(''));
      })
      .catch((err) => {
        showLoading(false);
        showToast('error', 'Không lấy được chi tiết hóa đơn');
        console.error(err);
      });
  }

  // Simple modal implementation
  function showModal(innerHtml) {
    // remove existing
    const existing = document.querySelector('.invoice-modal');
    if (existing) existing.remove();

    const modal = document.createElement('div');
    modal.className = 'invoice-modal';
    modal.innerHTML = `
      <div class="invoice-modal-content">
        <button class="modal-close" aria-label="Đóng">
          <i class="fas fa-times"></i>
        </button>
        ${innerHtml}
      </div>
    `;
    document.body.appendChild(modal);

    // Close modal on background click
    modal.addEventListener('click', (e) => {
      if (e.target === modal) modal.remove();
    });

    // Close modal on close button click
    modal.querySelector('.modal-close').addEventListener('click', () => modal.remove());

    // Close modal on Escape key
    const handleEscape = (e) => {
      if (e.key === 'Escape') {
        modal.remove();
        document.removeEventListener('keydown', handleEscape);
      }
    };
    document.addEventListener('keydown', handleEscape);

    // Add click handlers for invoice images
    const invoiceImages = modal.querySelectorAll('.invoice-image-clickable');
    if (invoiceImages.length > 0) {
      const imageUrls = Array.from(invoiceImages).map((img) => img.src);
      invoiceImages.forEach((img, index) => {
        img.addEventListener('click', (e) => {
          e.stopPropagation(); // Prevent modal close
          openImagePopup(imageUrls, index);
        });
      });
    }
  }

  /**
   * Display recent activity on home tab
   */
  function displayRecentActivity(visits) {
    const activityList = document.getElementById('recentActivity');

    if (!activityList || !visits || visits.length === 0) return;

    activityList.innerHTML = '';

    // Show only latest 3 visits
    const recentVisits = visits.slice(0, 3);

    recentVisits.forEach((visit) => {
      console.log('Processing recent visit:', visit);

      const isObject = visit && typeof visit === 'object';
      let visitTime, title;

      if (isObject) {
        // New format: object with code and created_at
        visitTime = visit.created_at || visit.createdAt || visit.date;
        title = visit.code
          ? `Hóa đơn ${visit.code}`
          : `Ghé thăm ${(window.checkinData && window.checkinData.brandName) || 'Shop'}`;
      } else {
        // Old format: string date
        visitTime = visit;
        title = `Ghé thăm ${(window.checkinData && window.checkinData.brandName) || 'Shop'}`;
      }

      const activityItem = document.createElement('div');
      activityItem.className = 'activity-item';
      activityItem.innerHTML = `
                <div class="activity-icon">
                    <i class="fas fa-receipt"></i>
                </div>
                <div class="activity-info">
                    <div class="activity-title">${title}</div>
                    <div class="activity-date">${formatDateTime(visitTime)}</div>
                </div>
            `;
      activityList.appendChild(activityItem);
    });
  }

  /**
   * Generate QR Code
   */
  function generateQRCode(containerId, value) {
    const container = document.getElementById(containerId);

    if (!container) return;

    // Clear existing QR
    container.innerHTML = '';

    // Check if QRCode library is available
    if (typeof QRCode === 'undefined') {
      container.innerHTML =
        '<p style="color: var(--text-muted); font-size: 13px;">QR Code không khả dụng</p>';
      return;
    }

    try {
      new QRCode(container, {
        text: value,
        width: 200,
        height: 200,
        colorDark: '#000000',
        colorLight: '#ffffff',
        correctLevel: QRCode.CorrectLevel.H,
      });
    } catch (error) {
      console.error('❌ QR Code generation error:', error);
      container.innerHTML =
        '<p style="color: var(--text-muted); font-size: 13px;">Không thể tạo QR Code</p>';
    }
  }

  /**
   * Show/hide loading overlay
   */
  function showLoading(show) {
    const overlay = document.getElementById('loadingOverlay');
    if (overlay) {
      if (show) {
        overlay.classList.add('active');
      } else {
        overlay.classList.remove('active');
      }
    }
  }

  /**
   * Show toast notification
   */
  function showToast(type, message) {
    const container = document.getElementById('toastContainer');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast ${type}`;

    let icon = 'fa-info-circle';
    if (type === 'success') icon = 'fa-check-circle';
    if (type === 'error') icon = 'fa-exclamation-circle';
    if (type === 'warning') icon = 'fa-exclamation-triangle';

    toast.innerHTML = `
            <i class="fas ${icon} toast-icon"></i>
            <span class="toast-message">${message}</span>
        `;

    container.appendChild(toast);

    // Auto remove after 3 seconds
    setTimeout(() => {
      toast.style.animation = 'fadeOut 0.3s ease';
      setTimeout(() => {
        container.removeChild(toast);
      }, 300);
    }, 3000);
  }

  /**
   * Utility: Normalize phone number for comparison (remove 0/84 prefix)
   */
  function normalizePhone(phone) {
    if (!phone) return '';
    return phone.replace(/\D/g, '').replace(/^(0|84)/, '');
  }

  /**
   * Utility: Format phone number
   */
  function formatPhone(phone) {
    if (!phone) return '';

    // Remove all non-digit characters
    const cleaned = phone.replace(/\D/g, '');

    // Add leading 0 if 9 digits
    const formatted = cleaned.length === 9 ? '0' + cleaned : cleaned;

    // Format as 0xxx xxx xxx
    if (formatted.length === 10) {
      return formatted.replace(/(\d{4})(\d{3})(\d{3})/, '$1 $2 $3');
    }

    return formatted;
  }

  /**
   * Utility: Format date
   */
  function formatDate(dateString) {
    if (!dateString) return '--';

    try {
      const date = new Date(dateString);
      return date.toLocaleDateString('vi-VN', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
      });
    } catch (error) {
      return dateString;
    }
  }

  /**
   * Utility: Format money (VND friendly)
   */
  function formatMoney(value) {
    if (value === undefined || value === null || value === '') return '--';
    const num = Number(value);
    if (isNaN(num)) return value;
    try {
      return num.toLocaleString('vi-VN', { style: 'currency', currency: 'VND' });
    } catch (e) {
      return num.toString();
    }
  }

  /**
   * Utility: Format date and time
   */
  function formatDateTime(dateString) {
    if (!dateString) return '--';

    try {
      const date = new Date(dateString);
      return date.toLocaleDateString('vi-VN', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch (error) {
      return dateString;
    }
  }

  /**
   * Utility: Adjust color brightness
   */
  function adjustColor(color, percent) {
    // Simple color adjustment (hex only)
    const num = parseInt(color.replace('#', ''), 16);
    const amt = Math.round(2.55 * percent);
    const R = (num >> 16) + amt;
    const G = ((num >> 8) & 0x00ff) + amt;
    const B = (num & 0x0000ff) + amt;
    return (
      '#' +
      (
        0x1000000 +
        (R < 255 ? (R < 1 ? 0 : R) : 255) * 0x10000 +
        (G < 255 ? (G < 1 ? 0 : G) : 255) * 0x100 +
        (B < 255 ? (B < 1 ? 0 : B) : 255)
      )
        .toString(16)
        .slice(1)
    );
  }

  /**
   * Reset visit history to empty state
   */
  function resetVisitHistory() {
    console.log('🔄 Resetting visit history');

    // Reset visit count
    document.getElementById('visitCount').textContent = '0';

    // Reset history list to empty state
    const historyList = document.getElementById('historyList');
    if (historyList) {
      historyList.innerHTML =
        '<div class="empty-state"><i class="fas fa-history"></i><p>Chưa có lịch sử ghé thăm</p></div>';
    }

    // Reset recent activity to empty state
    const activityList = document.getElementById('recentActivity');
    if (activityList) {
      activityList.innerHTML =
        '<div class="empty-state"><i class="fas fa-calendar-day"></i><p>Chưa có hoạt động</p></div>';
    }

    console.log('✅ Visit history reset complete');
  }

  /**
   * Reset customer information and keep non-member info
   */
  function resetCustomerInfo() {
    console.log('🔄 Resetting customer information while keeping non-member data');

    // Check if we have non-member customer data to restore
    const nonMemberData = window.nonMemberCustomerData;

    if (nonMemberData) {
      // Keep non-member customer info
      console.log('📌 Restoring non-member customer info:', nonMemberData);

      document.getElementById('userName').textContent =
        nonMemberData.customerName || 'Tên khách hàng';
      document.getElementById('userPhone').textContent =
        formatPhone(nonMemberData.customerPhone) || 'Số điện thoại';

      // Set avatar by name
      const avatarName = nonMemberData.customerName || 'User';
      document.getElementById('userAvatar').src =
        'https://ui-avatars.com/api/?name=' +
        encodeURIComponent(avatarName) +
        '&background=ffd700&color=000&size=200';

      // Keep "Không phải thành viên" status
      document.getElementById('membershipType').textContent = 'Chưa là thành viên';
      document.getElementById('membershipPoints').innerHTML =
        '<i class="fas fa-user-plus"></i> Chưa có điểm';
    } else {
      // No non-member data, reset to default
      console.log('📌 No non-member data, resetting to default');

      document.getElementById('userName').textContent = 'Tên khách hàng';
      document.getElementById('userPhone').textContent = 'Số điện thoại';

      // Reset avatar to default
      document.getElementById('userAvatar').src =
        'https://ui-avatars.com/api/?name=User&background=cccccc&color=666666&size=200';

      // Reset membership info
      document.getElementById('membershipType').textContent = 'Thành Viên';
      document.getElementById('membershipPoints').innerHTML = '<i class="fas fa-star"></i> 0 điểm';
    }

    // Always reset stats
    document.getElementById('promoCount').textContent = '0';
    document.getElementById('bookingCount').textContent = '0';

    // Hide search results
    const promoResult = document.getElementById('promoResult');
    const bookingResult = document.getElementById('bookingResult');
    if (promoResult) promoResult.style.display = 'none';
    if (bookingResult) bookingResult.style.display = 'none';

    // Reset visit history using the dedicated function
    resetVisitHistory();

    // Clear customer data
    customerData = null;

    console.log('✅ Customer information reset complete');
  }

  /**
   * Show modal for non-member customers
   */
  function showNonMemberModal(data) {
    console.log('🔔 Showing non-member modal for:', data);

    const modal = document.getElementById('notificationModal');
    const icon = document.getElementById('notificationModalIcon');
    const title = document.getElementById('notificationModalTitle');
    const message = document.getElementById('notificationModalMessage');
    const buttons = document.getElementById('notificationModalButtons');

    console.log('Modal elements found:', {
      modal: !!modal,
      icon: !!icon,
      title: !!title,
      message: !!message,
      buttons: !!buttons,
    });

    if (!modal) {
      console.error('❌ Modal not found! Showing toast instead.');
      showToast('warning', 'Khách hàng chưa là thành viên. Vui lòng đăng ký để nhận ưu đãi!');
      return;
    }

    // Store non-member customer data for later use after modal closes
    window.nonMemberCustomerData = {
      customerName: data.customerName,
      customerPhone: data.customerPhone,
    };

    // Set icon
    icon.className = 'notification-modal-icon fas fa-user-plus';
    icon.style.color = '#ffd700'; // Use direct color value

    // Set title
    title.textContent = 'Khách hàng chưa là thành viên';

    // Set message
    message.innerHTML = `
      <div style="text-align: center; margin: 20px 0;">
        <p style="margin-bottom: 12px; color: #ffd700; font-size: 16px;">
          <strong>${data.customerName || 'Quý khách'}</strong>
        </p>
        <p style="margin-bottom: 12px; color: #ffffff; font-size: 14px;">
          Số điện thoại: <strong>${formatPhone(data.customerPhone)}</strong>
        </p>
        <p style="color: #888888; font-size: 14px; line-height: 1.6;">
          ${
            data.message ||
            'Bạn chưa là thành viên của Shop nên chưa có mã khuyến mãi.<br/>Đăng ký ngay để nhận nhiều ưu đãi hấp dẫn!'
          }
        </p>
      </div>
    `;

    // Determine registration URL based on Zalo OA setting
    const useZaloOA = window.checkinData && window.checkinData.useZaloOA;
    const zaloOaId = window.checkinData && window.checkinData.zaloOaId;
    let registrationUrl = '/dang-ky-thanh-vien'; // Default URL

    // Check if Zalo OA is enabled and has oa_id
    if (
      (useZaloOA === '1' ||
      useZaloOA === 1 ||
      useZaloOA === true ||
      useZaloOA === 'yes' ||
      useZaloOA === 'true') &&
      zaloOaId
    ) {
      registrationUrl = 'https://chatbot.zalo.me/ref/' + zaloOaId + '?id=dangkythanhvien';
      console.log('✅ Using Zalo OA registration URL:', registrationUrl);
    } else {
      console.log('✅ Using local registration URL:', registrationUrl);
    }

    // Set buttons
    buttons.innerHTML = `
      <button class="notification-modal-btn notification-modal-btn-secondary" onclick="window.checkinMemberApp.resetCustomerInfo(); document.getElementById('notificationModal').classList.remove('active')">
        <i class="fas fa-times"></i> Hủy
      </button>
      <button class="notification-modal-btn notification-modal-btn-primary" onclick="window.location.href='${registrationUrl}'">
        <i class="fas fa-user-plus"></i> Đăng ký thành viên ngay
      </button>
    `;

    // Show modal with flex display
    modal.classList.add('active');

    console.log('✅ Modal displayed');
  }

  /**
   * Open image popup modal for viewing images
   * @param {Array|string} images - Array of image URLs or single image URL
   * @param {number} startIndex - Starting index for image carousel (default: 0)
   */
  function openImagePopup(images, startIndex = 0) {
    const popup = document.getElementById('imagePopup');
    const popupImage = document.getElementById('popupImage');
    const closeBtn = document.getElementById('closePopup');
    const prevBtn = document.getElementById('prevImage');
    const nextBtn = document.getElementById('nextImage');
    const counter = document.getElementById('imageCounter');
    const thumbnailsContainer = document.getElementById('imageThumbnails');
    const loadingIndicator = popup?.querySelector('.image-popup-loading');

    // Validate elements
    if (
      !popup ||
      !popupImage ||
      !closeBtn ||
      !prevBtn ||
      !nextBtn ||
      !counter ||
      !thumbnailsContainer
    ) {
      console.error('❌ Image popup elements not found:', {
        popup: !!popup,
        popupImage: !!popupImage,
        closeBtn: !!closeBtn,
        prevBtn: !!prevBtn,
        nextBtn: !!nextBtn,
        counter: !!counter,
        thumbnailsContainer: !!thumbnailsContainer,
        loadingIndicator: !!loadingIndicator,
      });
      return;
    }

    // Normalize images to array
    const imageArray = Array.isArray(images) ? images : [images];
    if (imageArray.length === 0) {
      console.warn('⚠️ No images to display');
      return;
    }

    let currentIndex = Math.max(0, Math.min(startIndex, imageArray.length - 1));
    let touchStartX = 0;
    let touchEndX = 0;

    // ===== UPDATE IMAGE (SMOOTH TRANSITION) =====
    function updateImage() {
      const newSrc = imageArray[currentIndex];

      // If src is the same, no need to reload
      if (popupImage.src === newSrc) {
        updateThumbnails();
        return;
      }

      console.log('🖼️ Loading image:', newSrc);

      // Preload new image in background
      const tempImg = new Image();
      let imageLoaded = false;

      tempImg.onload = () => {
        if (imageLoaded) return; // Prevent double execution
        imageLoaded = true;

        // Fade out old image
        popupImage.classList.remove('loaded');

        // Wait for fade out before changing src (smooth transition)
        setTimeout(() => {
          popupImage.src = newSrc;

          // Fade in new image (double RAF for smoother rendering)
          requestAnimationFrame(() => {
            requestAnimationFrame(() => {
              popupImage.classList.add('loaded');
              if (loadingIndicator) {
                loadingIndicator.classList.add('hidden');
              }
            });
          });
        }, 250); // Match CSS transition duration (0.25s)

        console.log('✅ Image loaded successfully');
      };

      tempImg.onerror = () => {
        if (imageLoaded) return;
        imageLoaded = true;

        console.error('❌ Failed to load image:', newSrc);
        popupImage.src = newSrc; // Still show it
        popupImage.classList.add('loaded');
        if (loadingIndicator) {
          loadingIndicator.classList.add('hidden');
        }
      };

      // Show loading indicator if load takes long
      const loadingTimeout = setTimeout(() => {
        if (!imageLoaded && loadingIndicator) {
          loadingIndicator.classList.remove('hidden');
        }
      }, 200); // Only show loading if > 200ms

      // Start loading
      tempImg.src = newSrc;

      // Fallback: If image is already cached
      if (tempImg.complete && tempImg.naturalHeight !== 0) {
        clearTimeout(loadingTimeout);
        tempImg.onload();
      }

      // Update UI elements
      counter.textContent = `${currentIndex + 1} / ${imageArray.length}`;
      prevBtn.disabled = imageArray.length <= 1;
      nextBtn.disabled = imageArray.length <= 1;
      updateThumbnails();

      // Preload adjacent images for smoother navigation
      preloadAdjacentImages();
    }

    // ===== PRELOAD ADJACENT IMAGES =====
    function preloadAdjacentImages() {
      const nextIndex = (currentIndex + 1) % imageArray.length;
      const prevIndex = (currentIndex - 1 + imageArray.length) % imageArray.length;

      // Preload next image
      if (imageArray[nextIndex]) {
        const nextImg = new Image();
        nextImg.src = imageArray[nextIndex];
      }

      // Preload previous image
      if (imageArray[prevIndex] && prevIndex !== nextIndex) {
        const prevImg = new Image();
        prevImg.src = imageArray[prevIndex];
      }
    }

    // ===== RENDER THUMBNAILS =====
    function renderThumbnails() {
      thumbnailsContainer.innerHTML = '';

      if (imageArray.length <= 1) {
        thumbnailsContainer.style.display = 'none';
        return;
      }

      thumbnailsContainer.style.display = 'flex';

      imageArray.forEach((url, index) => {
        const thumb = document.createElement('div');
        thumb.className = 'image-popup-thumbnail';
        if (index === currentIndex) {
          thumb.classList.add('active');
        }

        const img = document.createElement('img');
        img.src = url;
        img.alt = `Thumbnail ${index + 1}`;
        img.loading = 'lazy';

        thumb.appendChild(img);
        thumb.addEventListener('click', () => {
          currentIndex = index;
          updateImage();
        });

        thumbnailsContainer.appendChild(thumb);
      });
    }

    // ===== UPDATE THUMBNAILS ACTIVE STATE =====
    function updateThumbnails() {
      const thumbs = thumbnailsContainer.querySelectorAll('.image-popup-thumbnail');
      thumbs.forEach((thumb, index) => {
        thumb.classList.toggle('active', index === currentIndex);
      });

      // Scroll active thumbnail into view
      const activeThumb = thumbnailsContainer.querySelector('.image-popup-thumbnail.active');
      if (activeThumb) {
        activeThumb.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
      }
    }

    // ===== NAVIGATION =====
    function goToPrev() {
      currentIndex = (currentIndex - 1 + imageArray.length) % imageArray.length;
      updateImage();
    }

    function goToNext() {
      currentIndex = (currentIndex + 1) % imageArray.length;
      updateImage();
    }

    // ===== CLOSE POPUP =====
    function handleClose() {
      popup.classList.add('hidden');
      document.body.style.overflow = ''; // Restore scroll
      cleanup();
    }

    // ===== KEYBOARD NAVIGATION =====
    function handleKeydown(e) {
      if (popup.classList.contains('hidden')) return;

      switch (e.key) {
        case 'ArrowLeft':
          goToPrev();
          break;
        case 'ArrowRight':
          goToNext();
          break;
        case 'Escape':
          handleClose();
          break;
      }
    }

    // ===== TOUCH SWIPE (Mobile) =====
    function handleTouchStart(e) {
      touchStartX = e.changedTouches[0].screenX;
    }

    function handleTouchEnd(e) {
      touchEndX = e.changedTouches[0].screenX;
      handleSwipe();
    }

    function handleSwipe() {
      const swipeThreshold = 50;
      const diff = touchStartX - touchEndX;

      if (Math.abs(diff) > swipeThreshold) {
        if (diff > 0) {
          goToNext(); // Swipe left
        } else {
          goToPrev(); // Swipe right
        }
      }
    }

    // ===== CLICK OUTSIDE TO CLOSE =====
    function handleOutsideClick(e) {
      if (e.target === popup) {
        handleClose();
      }
    }

    // ===== CLEANUP =====
    function cleanup() {
      document.removeEventListener('keydown', handleKeydown);
      popup.removeEventListener('click', handleOutsideClick);
      popupImage.removeEventListener('touchstart', handleTouchStart);
      popupImage.removeEventListener('touchend', handleTouchEnd);
      prevBtn.onclick = null;
      nextBtn.onclick = null;
      closeBtn.onclick = null;
    }

    // ===== INITIALIZE =====
    cleanup(); // Remove old listeners
    renderThumbnails();
    updateImage();

    // Show popup
    popup.classList.remove('hidden');
    document.body.style.overflow = 'hidden'; // Prevent background scroll

    // Attach event listeners
    closeBtn.onclick = handleClose;
    prevBtn.onclick = goToPrev;
    nextBtn.onclick = goToNext;
    popup.addEventListener('click', handleOutsideClick);
    document.addEventListener('keydown', handleKeydown);
    popupImage.addEventListener('touchstart', handleTouchStart);
    popupImage.addEventListener('touchend', handleTouchEnd);

    console.log(
      `✅ Opened image popup: ${imageArray.length} images, starting at index ${currentIndex}`
    );
  }

  // ============================================
  // ZALO SOCIAL LOGIN - PKCE OAuth Flow
  // ============================================

  /**
   * Initialize Zalo Social Login — fetch app config from backend
   */
  async function initZaloSocialLogin() {
    // Step 1: Check if we have a saved session — auto-login immediately
    const savedSession = getSavedSession();
    if (savedSession && savedSession.customer_phone) {
      console.log('🔄 Restoring saved session for phone:', savedSession.customer_phone);
      // Hide login/phone sections, show content
      const loginSection = document.getElementById('zaloLoginSection');
      const phoneSection = document.getElementById('phoneSearchSection');
      if (loginSection) loginSection.style.display = 'none';
      if (phoneSection) phoneSection.style.display = 'none';
      setMainContentVisible(true);

      // Auto-search — respect hash for tab routing
      const hash = window.location.hash.replace('#', '');
      if (hash === 'booking') {
        switchTab('booking');
        setTimeout(() => {
          document.getElementById('bookingSearchInput').value = savedSession.customer_phone;
          searchBooking();
        }, 300);
      } else {
        // Default to promo tab (also handles #promo)
        switchTab(hash === 'history' ? 'history' : 'promo');
        if (hash !== 'history') {
          setTimeout(() => {
            document.getElementById('promoSearchInput').value = savedSession.customer_phone;
            searchPromo();
          }, 300);
        }
      }
      return; // Skip Zalo config fetch — already logged in
    }

    // Step 2: No saved session — fetch Zalo config
    try {
      const resp = await fetch(`${getApiBase()}/vg/v1/zalo-social-config`);
      const data = await resp.json();
      if (data.success && data.data.app_id) {
        zaloSocialConfig = data.data;
        console.log('✅ Zalo Social config loaded, app_id:', zaloSocialConfig.app_id);
        // Show Zalo login + phone search, hide main content
        setMainContentVisible(false);
      } else {
        // No Zalo Social App configured — hide Zalo login, show phone search only
        const section = document.getElementById('zaloLoginSection');
        if (section) section.style.display = 'none';
        // Keep phone search visible, hide main content
        setMainContentVisible(false);
        console.log('ℹ️ Zalo Social Login not configured — showing phone search only');
      }
    } catch (err) {
      console.error('❌ Failed to load Zalo Social config:', err);
      const section = document.getElementById('zaloLoginSection');
      if (section) section.style.display = 'none';
      // Keep phone search visible
      setMainContentVisible(false);
    }

    // Check if we're returning from an OAuth callback
    handleZaloOAuthCallback();
  }

  /**
   * Toggle main content (stats, promos, tabs, bottom nav) visibility
   */
  function setMainContentVisible(visible) {
    const contentWrapper = document.getElementById('contentWrapper');
    if (contentWrapper) contentWrapper.style.display = visible ? '' : 'none';
    // Bottom nav stays visible always
  }

  /**
   * PKCE Helpers: generate code_verifier and code_challenge
   */
  function generateCodeVerifier(length = 64) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~';
    let result = '';
    const array = new Uint8Array(length);
    crypto.getRandomValues(array);
    for (let i = 0; i < length; i++) {
      result += chars[array[i] % chars.length];
    }
    return result;
  }

  async function generateCodeChallenge(verifier) {
    const encoder = new TextEncoder();
    const data = encoder.encode(verifier);
    const hash = await crypto.subtle.digest('SHA-256', data);
    return btoa(String.fromCharCode(...new Uint8Array(hash)))
      .replace(/\+/g, '-')
      .replace(/\//g, '_')
      .replace(/=+$/, '');
  }

  /**
   * Start Zalo OAuth login flow
   */
  async function startZaloLogin() {
    if (!zaloSocialConfig || !zaloSocialConfig.app_id) {
      showToast('Chưa cấu hình Zalo Social App', 'error');
      return;
    }

    const btn = document.getElementById('zaloLoginBtn');
    if (btn) {
      btn.disabled = true;
      btn.innerHTML = '<div class="spinner-inline"></div><span>Đang kết nối...</span>';
    }

    try {
      // Generate PKCE values
      const codeVerifier = generateCodeVerifier();
      const codeChallenge = await generateCodeChallenge(codeVerifier);

      // Store code_verifier in sessionStorage for callback
      sessionStorage.setItem('zalo_code_verifier', codeVerifier);

      // Build callback URL — use configured callback or current page
      const callbackUrl = zaloSocialConfig.callback_url || window.location.origin + window.location.pathname;

      // Build Zalo OAuth URL
      const authUrl = new URL('https://oauth.zaloapp.com/v4/permission');
      authUrl.searchParams.set('app_id', zaloSocialConfig.app_id);
      authUrl.searchParams.set('redirect_uri', callbackUrl);
      authUrl.searchParams.set('code_challenge', codeChallenge);
      authUrl.searchParams.set('state', 'zalo_social_login');

      console.log('🔗 Redirecting to Zalo OAuth:', authUrl.toString());

      // Redirect to Zalo OAuth (same window, not popup)
      window.location.href = authUrl.toString();
    } catch (err) {
      console.error('❌ Failed to start Zalo login:', err);
      showToast('Lỗi khi khởi tạo đăng nhập Zalo', 'error');
      if (btn) {
        btn.disabled = false;
        btn.innerHTML = `<svg viewBox="0 0 24 24" width="20" height="20" fill="white">
          <rect width="24" height="24" rx="4" fill="white" fill-opacity="0.15"/>
          <path d="M7 15.5L10.5 10H7.5V9H13V10L9.5 15H13V16H7V15.5Z" fill="white"/>
          <path d="M17 9C17 8.72 16.78 8.5 16.5 8.5C16.22 8.5 16 8.72 16 9V14H14L16.5 16.5L19 14H17V9Z" fill="white"/>
        </svg><span>Đăng nhập bằng Zalo</span>`;
      }
    }
  }

  /**
   * Handle OAuth callback — check URL for 'code' param from Zalo
   */
  async function handleZaloOAuthCallback() {
    const urlParams = new URLSearchParams(window.location.search);
    const code = urlParams.get('code');
    const state = urlParams.get('state');

    if (!code || state !== 'zalo_social_login') return;

    console.log('🔄 Handling Zalo OAuth callback...');

    // Clean URL (remove code/state params)
    const cleanUrl = window.location.origin + window.location.pathname;
    window.history.replaceState({}, '', cleanUrl);

    // Get stored code_verifier
    const codeVerifier = sessionStorage.getItem('zalo_code_verifier');
    if (!codeVerifier) {
      showToast('Phiên đăng nhập hết hạn. Vui lòng thử lại.', 'error');
      return;
    }
    sessionStorage.removeItem('zalo_code_verifier');

    // Hide login section, show loading
    const loginSection = document.getElementById('zaloLoginSection');
    if (loginSection) loginSection.style.display = 'none';

    showToast('Đang xác thực với Zalo...', 'info');

    try {
      // Exchange code for user info via backend
      const resp = await fetch(`${getApiBase()}/vg/v1/zalo-social-login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code, code_verifier: codeVerifier }),
      });

      const data = await resp.json();

      if (!data.success) {
        showToast(data.message || 'Đăng nhập Zalo thất bại', 'error');
        if (loginSection) loginSection.style.display = '';
        return;
      }

      // Store Zalo login data
      zaloLoginData = {
        zalo_id: data.zalo_id,
        zalo_name: data.zalo_name,
        zalo_avatar: data.zalo_avatar,
      };

      if (data.linked) {
        // Already linked — save session, show content and auto-search
        const loginSection = document.getElementById('zaloLoginSection');
        const phoneSection = document.getElementById('phoneSearchSection');
        if (loginSection) loginSection.style.display = 'none';
        if (phoneSection) phoneSection.style.display = 'none';
        setMainContentVisible(true);

        showToast(`Xin chào ${data.zalo_name}! 🎉`, 'success');

        // Save session to localStorage
        saveSession({
          customer_phone: data.customer.customer_phone,
          customer_name: data.customer.customer_name,
          zalo_name: data.zalo_name,
          zalo_avatar: data.zalo_avatar,
        });

        // Update profile header with Zalo data
        if (data.zalo_avatar) {
          document.getElementById('userAvatar').src = data.zalo_avatar;
        }
        if (data.zalo_name) {
          document.getElementById('userName').textContent = data.zalo_name;
        }

        // Auto-search in promo tab
        const phone = data.customer.customer_phone;
        switchTab('promo');
        setTimeout(() => {
          document.getElementById('promoSearchInput').value = phone;
          searchPromo();
        }, 300);

      } else {
        // Not linked — show phone linking form
        showZaloLinkForm(data.zalo_name, data.zalo_avatar);
      }

    } catch (err) {
      console.error('❌ Zalo OAuth callback error:', err);
      showToast('Lỗi khi xác thực Zalo', 'error');
      if (loginSection) loginSection.style.display = '';
    }
  }

  /**
   * Show the phone linking form with Zalo user info
   */
  function showZaloLinkForm(name, avatar) {
    const loginSection = document.getElementById('zaloLoginSection');
    const linkSection = document.getElementById('zaloLinkSection');

    if (loginSection) loginSection.style.display = 'none';
    // Hide main content to keep UI clean
    setMainContentVisible(false);

    if (linkSection) {
      linkSection.style.display = '';

      // Set avatar and name
      const avatarImg = document.getElementById('zaloLinkAvatar');
      const nameEl = document.getElementById('zaloLinkName');

      if (avatarImg) {
        avatarImg.src = avatar || `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=0068FF&color=fff&size=160`;
      }
      if (nameEl) nameEl.textContent = name || 'Người dùng Zalo';

      // Focus phone input
      setTimeout(() => {
        const input = document.getElementById('zaloLinkPhoneInput');
        if (input) input.focus();
      }, 400);
    }
  }

  /**
   * Link Zalo account with phone number
   */
  async function linkZaloPhone() {
    if (!zaloLoginData || !zaloLoginData.zalo_id) {
      showToast('Cần đăng nhập Zalo trước', 'error');
      return;
    }

    const phoneInput = document.getElementById('zaloLinkPhoneInput');
    const errorEl = document.getElementById('zaloLinkError');
    const linkBtn = document.getElementById('zaloLinkBtn');
    const phone = phoneInput ? phoneInput.value.trim() : '';

    // Validate phone
    if (!phone || phone.length < 9) {
      if (errorEl) {
        errorEl.textContent = 'Vui lòng nhập số điện thoại hợp lệ (tối thiểu 9 số)';
        errorEl.style.display = '';
      }
      return;
    }

    // Hide error, show loading
    if (errorEl) errorEl.style.display = 'none';
    if (linkBtn) {
      linkBtn.disabled = true;
      linkBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Đang liên kết...';
    }

    try {
      const resp = await fetch(`${getApiBase()}/vg/v1/zalo-social-link`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          zalo_id: zaloLoginData.zalo_id,
          phone: phone,
        }),
      });

      const data = await resp.json();

      if (data.not_found || data.needs_registration) {
        // Redirect to registration page with prefilled data
        const regUrl = new URL('/dang-ky-thanh-vien', window.location.origin);
        if (data.phone) regUrl.searchParams.set('phone', data.phone);
        if (zaloLoginData && zaloLoginData.zalo_name) regUrl.searchParams.set('zalo_name', zaloLoginData.zalo_name);
        if (zaloLoginData && zaloLoginData.zalo_id) regUrl.searchParams.set('zalo_id', zaloLoginData.zalo_id);

        showToast('info', data.message || 'Chuyển đến trang đăng ký thành viên...');
        setTimeout(() => {
          window.location.href = regUrl.toString();
        }, 1500);
        return;
      }

      if (!data.success) {
        if (errorEl) {
          errorEl.textContent = data.message || 'Liên kết thất bại';
          errorEl.style.display = '';
        }
        return;
      }

      // Success! Hide linking form + phone section, show content, and auto-search
      const linkSection = document.getElementById('zaloLinkSection');
      const phoneSection = document.getElementById('phoneSearchSection');
      if (linkSection) linkSection.style.display = 'none';
      if (phoneSection) phoneSection.style.display = 'none';
      setMainContentVisible(true);

      showToast('success', `Liên kết thành công! Chào ${zaloLoginData.zalo_name} 🎉`);

      // Save session to localStorage
      saveSession({
        customer_phone: data.customer.customer_phone,
        customer_name: data.customer.customer_name,
        zalo_name: zaloLoginData.zalo_name,
        zalo_avatar: zaloLoginData.zalo_avatar,
      });

      // Update profile header with Zalo avatar
      if (zaloLoginData.zalo_avatar) {
        document.getElementById('userAvatar').src = zaloLoginData.zalo_avatar;
      }

      // Auto-search in promo tab
      const customerPhone = data.customer.customer_phone;
      switchTab('promo');
      setTimeout(() => {
        document.getElementById('promoSearchInput').value = customerPhone;
        searchPromo();
      }, 300);

    } catch (err) {
      console.error('❌ Zalo link error:', err);
      if (errorEl) {
        errorEl.textContent = 'Lỗi kết nối. Vui lòng thử lại.';
        errorEl.style.display = '';
      }
    } finally {
      if (linkBtn) {
        linkBtn.disabled = false;
        linkBtn.innerHTML = '<i class="fas fa-link"></i> Liên kết';
      }
    }
  }

  /**
   * Get API base URL
   */
  function getApiBase() {
    if (window.checkinData && window.checkinData.apiBase) {
      return window.checkinData.apiBase;
    }
    // Fallback: guess from current URL
    return window.location.origin + '/wp-json';
  }

  // ============================================
  // SESSION MANAGEMENT (localStorage)
  // ============================================

  function saveSession(data) {
    try {
      localStorage.setItem(STORAGE_KEY_SESSION, JSON.stringify(data));
      console.log('💾 Session saved:', data.customer_phone);
    } catch (e) {
      console.warn('⚠️ Could not save session:', e);
    }
  }

  function getSavedSession() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY_SESSION);
      return raw ? JSON.parse(raw) : null;
    } catch (e) {
      return null;
    }
  }

  function clearSession() {
    try {
      localStorage.removeItem(STORAGE_KEY_SESSION);
    } catch (e) {
      // ignore
    }
  }

  // ============================================
  // QUICK PHONE SEARCH (on login screen)
  // ============================================

  function attachPhoneSearchListeners() {
    const phoneInput = document.getElementById('quickPhoneInput');
    const phoneBtn = document.getElementById('quickPhoneBtn');

    if (phoneBtn) {
      phoneBtn.addEventListener('click', handleQuickPhoneSearch);
    }
    if (phoneInput) {
      phoneInput.addEventListener('keypress', function (e) {
        if (e.key === 'Enter') handleQuickPhoneSearch();
      });
    }
  }

  function handleQuickPhoneSearch() {
    const phoneInput = document.getElementById('quickPhoneInput');
    const phone = phoneInput ? phoneInput.value.trim() : '';

    if (!phone || phone.length < 9) {
      showToast('error', 'Vui lòng nhập số điện thoại hợp lệ (tối thiểu 9 số)');
      return;
    }

    // Hide login/phone sections, show content
    const loginSection = document.getElementById('zaloLoginSection');
    const phoneSection = document.getElementById('phoneSearchSection');
    if (loginSection) loginSection.style.display = 'none';
    if (phoneSection) phoneSection.style.display = 'none';
    setMainContentVisible(true);

    // Save session
    saveSession({ customer_phone: phone });

    // Auto-search in promo tab
    switchTab('promo');
    setTimeout(() => {
      document.getElementById('promoSearchInput').value = phone;
      searchPromo();
    }, 300);
  }

  // Expose functions globally if needed
  window.checkinMemberApp = {
    switchTab: switchTab,
    searchPromo: searchPromo,
    searchBooking: searchBooking,
    showToast: showToast,
    resetCustomerInfo: resetCustomerInfo,
    openImagePopup: openImagePopup,
    startZaloLogin: startZaloLogin,
    clearSession: clearSession,
  };
})();
