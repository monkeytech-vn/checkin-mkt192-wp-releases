/**
 * Dashboard Module for App Thợ
 * Modern, responsive dashboard with role-based views
 * @version 1.0.0
 */

(function () {
  'use strict';

  // ============================================
  // Dashboard State
  // ============================================
  let dashboardFilter = 'today';
  let dashboardChartInstance = null;
  let isManager = false;
  let cachedSalaryLevels = null; // Cache salary levels để tính lương
  let dashboardDataLoaded = false; // Track xem đã load data 7days chưa
  let inventoryStatusLoaded = false; // Track xem đã load inventory status chưa
  let cachedBookingsData = null; // Cache bookings data 7days
  let cachedInvoicesData = null; // Cache invoices data 7days

  // ============================================
  // Dashboard Cache Management
  // ============================================
  /**
   * Reset dashboard cache - gọi khi branch thay đổi
   */
  function resetDashboardCache() {
    dashboardDataLoaded = false;
    inventoryStatusLoaded = false;
    cachedBookingsData = null;
    cachedInvoicesData = null;
    previousPeriodInvoices = [];
    console.log('✅ Dashboard cache reset');
  }

  // ============================================
  // Dashboard Initialization
  // ============================================
  async function initDashboard() {
    const dashboardContent = document.getElementById('dashboardContent');
    if (!dashboardContent) return;

    try {
      // Determine role
      const managerRoles = ['Quản Lý', 'Thu Ngân', 'administrator', 'admin', 'Quản lý'];
      isManager = managerRoles.includes(window.currentUserRole || '');

      // Update body class for CSS role handling
      updateRoleClass(isManager);

      // Update welcome & date
      updateDashboardHeader();

      // Attach filter listeners
      attachDashboardFilterListeners();

      // Load and display data
      await refreshDashboardData();
    } catch (error) {
      console.error('Dashboard init error:', error);
      if (typeof showError === 'function') {
        showError('Lỗi tải bảng điều khiển: ' + error.message);
      }
    }
  }

  function updateRoleClass(isManager) {
    if (isManager) {
      document.body.classList.add('role-manager');
      document.body.classList.remove('role-worker');
    } else {
      document.body.classList.add('role-worker');
      document.body.classList.remove('role-manager');
    }
  }

  function updateDashboardHeader() {
    const welcomeEl = document.getElementById('dashboardWelcome');
    if (welcomeEl) {
      welcomeEl.textContent = `Xin chào, ${window.currentUserDisplayName || 'Bạn'}!`;
    }

    const dateEl = document.getElementById('currentDate');
    if (dateEl) {
      const now = new Date();
      const options = { weekday: 'long', day: 'numeric', month: 'numeric', year: 'numeric' };
      dateEl.textContent = now.toLocaleDateString('vi-VN', options);
    }
  }

  // ============================================
  // Filter Handling
  // ============================================
  function attachDashboardFilterListeners() {
    const filterContainer = document.getElementById('dashboardTimeFilter');
    if (!filterContainer) return;

    // Clone to remove old listeners
    const newFilterContainer = filterContainer.cloneNode(true);
    filterContainer.parentNode.replaceChild(newFilterContainer, filterContainer);

    newFilterContainer.querySelectorAll('.dashboard-filter-btn').forEach((btn) => {
      btn.addEventListener('click', async (e) => {
        const filter = e.currentTarget.dataset.filter;
        dashboardFilter = filter;

        // Update active state with animation
        newFilterContainer.querySelectorAll('.dashboard-filter-btn').forEach((b) => {
          b.classList.remove('active');
        });
        e.currentTarget.classList.add('active');

        // Refresh data
        await refreshDashboardData();
      });
    });
  }

  // ============================================
  // Data Loading
  // ============================================

  // Lưu trữ dữ liệu so sánh
  let previousPeriodInvoices = [];

  // ✅ OPTIMIZED: Helper để filter data theo thời gian từ cache
  function filterDataByPeriod(data, dateField, period) {
    if (!Array.isArray(data)) return [];

    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    const thisMonthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    const lastMonthStart = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    const lastMonthEnd = new Date(now.getFullYear(), now.getMonth(), 0);

    return data.filter((item) => {
      const itemDate = new Date(item[dateField]);
      if (period === 'today') return itemDate >= today;
      if (period === 'yesterday') return itemDate >= yesterday && itemDate < today;
      if (period === 'thisMonth') return itemDate >= thisMonthStart;
      if (period === 'lastMonth') return itemDate >= lastMonthStart && itemDate <= lastMonthEnd;
      return true;
    });
  }

  // ✅ OPTIMIZED: Ẩn/hiện các section chỉ cần cho "Hôm nay"
  function toggleTodayOnlySections(showSections) {
    // Tìm các section cha chứa các element cần ẩn
    // Sử dụng closest() để tìm container cha .chart-section
    // Hỗ trợ cả 2 ID: worker và manager - toggle tất cả elements
    const elementsToToggle = [
      document.getElementById('upcomingBookingsList')?.closest('.chart-section'),
      document.getElementById('managerUpcomingBookingsList')?.closest('.chart-section'),
      document.getElementById('recentActivityList')?.closest('.chart-section'),
      document.getElementById('managerRecentActivityList')?.closest('.chart-section'),
      document.querySelector('.quick-actions-grid')?.closest('.chart-section'),
    ].filter((el) => el !== null);

    elementsToToggle.forEach((el) => {
      if (el) {
        if (showSections) {
          el.classList.remove('hidden');
          el.style.display = '';
        } else {
          el.classList.add('hidden');
          el.style.display = 'none';
        }
      }
    });
  }

  async function refreshDashboardData() {
    try {
      const isTodayOrYesterday = dashboardFilter === 'today' || dashboardFilter === 'yesterday';

      // ✅ OPTIMIZED: Ẩn các section không cần thiết khi không phải "Hôm nay"
      toggleTodayOnlySections(dashboardFilter === 'today');

      // ✅ OPTIMIZED: Chỉ load API khi cần thiết
      // - today/yesterday: Dùng data 7days đã cache (hoặc load 1 lần nếu chưa có)
      // - thisMonth/lastMonth: Load API riêng vì data lớn

      if (isTodayOrYesterday) {
        // ✅ OPTIMIZED: Kiểm tra xem data 7days đã được load từ app-tho.js chưa
        // Nếu window.invoicesData đã có data → sử dụng luôn, không cần gọi API
        const hasInvoicesData = window.invoicesData && window.invoicesData.length > 0;
        const hasBookingsData = window.bookingsData && window.bookingsData.length > 0;

        // ✅ Cần load 7days nếu:
        // 1. Chưa load dashboard data lần nào, HOẶC
        // 2. Đang xem yesterday nhưng chưa có đủ data 7days cho bookings
        const needsLoad = !dashboardDataLoaded && (!hasInvoicesData || !hasBookingsData);

        if (needsLoad) {
          // Chưa có data → load 7days một lần duy nhất
          if (typeof loadStaffInvoices === 'function' && typeof loadStaffBookings === 'function') {
            await Promise.all([loadStaffInvoices('7days'), loadStaffBookings('7days')]);
          }
        }

        // Cache data để sử dụng sau
        cachedInvoicesData = window.invoicesData || [];
        cachedBookingsData = window.bookingsData || [];
        dashboardDataLoaded = true;

        // Không cần load previousPeriod riêng vì 7days đã bao gồm cả today và yesterday
        previousPeriodInvoices = [];
      } else {
        // thisMonth hoặc lastMonth - cần load API riêng
        let previousPeriod = dashboardFilter === 'thisMonth' ? 'lastMonth' : null;

        if (typeof loadStaffInvoices === 'function' && typeof loadStaffBookings === 'function') {
          await Promise.all([
            loadStaffInvoices(dashboardFilter),
            loadStaffBookings(dashboardFilter),
          ]);

          // Load previous period data for comparison
          if (previousPeriod) {
            try {
              let apiUrl = `${checkinData.restUrl}staff-invoices?filter=${previousPeriod}`;
              if (
                window.branchHelper &&
                typeof window.branchHelper.getCurrentBranchId === 'function'
              ) {
                const branchId = window.branchHelper.getCurrentBranchId();
                if (branchId) {
                  apiUrl += `&branch_id=${branchId}`;
                }
              }

              const response = await fetch(apiUrl, {
                headers: {
                  'X-WP-Nonce': checkinData.nonce,
                  'Content-Type': 'application/json',
                },
              });

              const prevResponse = await response.json();

              if (Array.isArray(prevResponse)) {
                previousPeriodInvoices = prevResponse;
              } else if (prevResponse && prevResponse.success && Array.isArray(prevResponse.data)) {
                previousPeriodInvoices = prevResponse.data;
              } else if (prevResponse && Array.isArray(prevResponse.data)) {
                previousPeriodInvoices = prevResponse.data;
              } else {
                previousPeriodInvoices = [];
              }
            } catch (e) {
              console.warn('Failed to load previous period data:', e);
              previousPeriodInvoices = [];
            }
          } else {
            previousPeriodInvoices = [];
          }
        }
      }

      // Load salary levels cho việc tính lương (chỉ cho Thợ)
      if (!isManager && !cachedSalaryLevels) {
        try {
          const salaryResponse = await fetch(`${checkinData.restUrl}salary-levels`, {
            headers: {
              'X-WP-Nonce': checkinData.nonce,
              'Content-Type': 'application/json',
            },
          });
          const salaryResult = await salaryResponse.json();
          if (salaryResult.success && Array.isArray(salaryResult.data)) {
            cachedSalaryLevels = salaryResult.data;
          } else if (Array.isArray(salaryResult)) {
            cachedSalaryLevels = salaryResult;
          }
        } catch (e) {
          console.warn('Failed to load salary levels:', e);
          cachedSalaryLevels = [];
        }
      }

      // Calculate and display stats
      const stats = await calculateDashboardStats(previousPeriodInvoices);
      updateDashboardUI(stats);

      // ✅ OPTIMIZED: Chỉ render các section cần thiết
      // Lịch hẹn sắp đến, Hoạt động gần đây chỉ hiển thị khi filter = today
      if (dashboardFilter === 'today') {
        renderRecentActivity();
        renderUpcomingBookings();
      }

      if (isManager) {
        renderWorkerRanking();
        renderTopServicesManager();
        // ✅ FIXED: Inventory/Stock status cần load lại khi đổi filter
        // vì cần hiển thị phiếu của khoảng thời gian đang xem
        updateInventoryStatus();
        updateStockTransferStatus();
        updateApprovalRequestsStatus();
        initRevenueChart(stats);
      } else {
        renderTopServices();
        // Thợ cũng xem được trạng thái đơn của mình
        updateApprovalRequestsStatus();
      }
    } catch (error) {
      console.error('Dashboard refresh error:', error);
    }
  }

  // ============================================
  // Stats Calculation
  // ============================================
  async function calculateDashboardStats(prevPeriodInvoices = []) {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    const dayBeforeYesterday = new Date(yesterday);
    dayBeforeYesterday.setDate(dayBeforeYesterday.getDate() - 1);
    const thisMonthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    const lastMonthStart = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    const lastMonthEnd = new Date(now.getFullYear(), now.getMonth(), 0);

    const filterData = (data, dateField) => {
      if (!Array.isArray(data)) return [];
      return data.filter((item) => {
        const itemDate = new Date(item[dateField]);
        if (dashboardFilter === 'today') return itemDate >= today;
        if (dashboardFilter === 'yesterday') return itemDate >= yesterday && itemDate < today;
        if (dashboardFilter === 'thisMonth') return itemDate >= thisMonthStart;
        if (dashboardFilter === 'lastMonth')
          return itemDate >= lastMonthStart && itemDate <= lastMonthEnd;
        return true;
      });
    };

    // Filter for comparison period (previous day)
    const filterPreviousData = (data, dateField) => {
      if (!Array.isArray(data)) return [];
      return data.filter((item) => {
        const itemDate = new Date(item[dateField]);
        if (dashboardFilter === 'today') return itemDate >= yesterday && itemDate < today;
        if (dashboardFilter === 'yesterday')
          return itemDate >= dayBeforeYesterday && itemDate < yesterday;
        // For month filters, compare with previous month
        if (dashboardFilter === 'thisMonth')
          return itemDate >= lastMonthStart && itemDate <= lastMonthEnd;
        if (dashboardFilter === 'lastMonth') {
          const prevMonthStart = new Date(lastMonthStart);
          prevMonthStart.setMonth(prevMonthStart.getMonth() - 1);
          const prevMonthEnd = new Date(lastMonthStart);
          prevMonthEnd.setDate(prevMonthEnd.getDate() - 1);
          return itemDate >= prevMonthStart && itemDate <= prevMonthEnd;
        }
        return false;
      });
    };

    const bookings = filterData(window.bookingsData || [], 'booking_date');
    const invoices = filterData(window.invoicesData || [], 'created_at');
    // Sử dụng dữ liệu kỳ trước đã load riêng (cho today/thisMonth) hoặc filter từ data hiện có
    const previousInvoices =
      prevPeriodInvoices.length > 0
        ? prevPeriodInvoices.filter((inv) => inv.status === 'paid')
        : filterPreviousData(window.invoicesData || [], 'created_at');

    // Booking stats
    // Trạng thái booking: success=hoàn thành, deleted=đã hủy, pending=đang phục vụ, waiting/other=chờ phục vụ
    const bookingStats = {
      total: bookings.length,
      pending: bookings.filter(
        (b) =>
          b.status === 'waiting' ||
          !b.status ||
          (b.status !== 'success' && b.status !== 'deleted' && b.status !== 'pending')
      ).length,
      serving: bookings.filter((b) => b.status === 'pending').length,
      completed: bookings.filter((b) => b.status === 'success').length,
      cancelled: bookings.filter((b) => b.status === 'deleted').length,
    };

    // Invoice stats
    const invoiceStats = {
      total: invoices.length,
      serving: invoices.filter((i) => i.status === 'pending').length,
      completed: invoices.filter((i) => i.status === 'paid').length,
    };

    // Financial stats
    let revenue = 0,
      tips = 0,
      discount = 0;
    let serviceRevenue = 0,
      productRevenue = 0,
      chemicalRevenue = 0;
    let penaltyServiceRevenue = 0,
      penaltyChemicalRevenue = 0;
    let totalExpense = 0;

    // Lấy tên user hiện tại để filter doanh số của thợ
    const currentUserName = window.currentUserDisplayName || '';

    invoices.forEach((inv) => {
      if (inv.status === 'paid') {
        revenue += parseFloat(inv.total) || 0;
        tips += parseFloat(inv.tips) || 0;
        discount += parseFloat(inv.discount) || 0;

        if (inv.services) {
          inv.services.forEach((s) => {
            // Chỉ tính doanh số của thợ hiện tại (cho giao diện Thợ)
            const isCurrentStaff = !isManager ? s.staff_name === currentUserName : true;
            if (!isCurrentStaff) return;

            const itemTotal = (parseFloat(s.price) || 0) * (s.quantity || 1);
            const isPenalty = s.is_penalty === true || s.is_penalty === '1' || s.is_penalty === 1;

            if (s.type === 'product') {
              productRevenue += itemTotal;
            } else if (s.type === 'chemical' || s.category === 'hoa-chat') {
              if (isPenalty) {
                penaltyChemicalRevenue += itemTotal;
              } else {
                chemicalRevenue += itemTotal;
              }
            } else {
              if (isPenalty) {
                penaltyServiceRevenue += itemTotal;
              } else {
                serviceRevenue += itemTotal;
              }
            }
          });
        }
      }
    });

    // Tính doanh số thợ = dịch vụ + hóa chất - truy thu
    const totalPenalty = penaltyServiceRevenue + penaltyChemicalRevenue;
    const workerRevenue = serviceRevenue + chemicalRevenue - totalPenalty;

    // Tính lương tạm tính cho Thợ
    let estimatedSalary = 0;
    let serviceCommissionRate = 0;
    let chemicalCommissionRate = 0;

    if (!isManager) {
      // Ưu tiên % từ phiếu lương kỳ hiện tại (thẻ hoa hồng theo kỳ, đã trừ KPI); fallback: bậc cũ
      try {
        const now = new Date();
        const period = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
        const payslipRes = await fetch(
          `${checkinData.restUrl}hairdresser-salary-data?type=salary&period=${period}&staff_name=${encodeURIComponent(currentUserName)}`,
          { headers: { 'X-WP-Nonce': checkinData.nonce } }
        );
        const payslip = await payslipRes.json();
        const row = payslip.success && Array.isArray(payslip.data) ? payslip.data[0] : null;
        if (row && row.service_commission_percent !== undefined) {
          serviceCommissionRate = parseFloat(row.service_commission_percent) || 0;
          chemicalCommissionRate = parseFloat(row.chemical_commission_percent) || 0;
        }
      } catch (e) {
        console.warn('Payslip rates unavailable, fallback to level:', e);
      }
      if (!serviceCommissionRate && !chemicalCommissionRate && cachedSalaryLevels && cachedSalaryLevels.length > 0) {
        try {
          const today = new Date().toISOString().split('T')[0];
          const levelResponse = await fetch(
            `${checkinData.restUrl}staff-levels?staff_name=${encodeURIComponent(currentUserName)}&date=${today}`,
            { headers: { 'X-WP-Nonce': checkinData.nonce, 'Content-Type': 'application/json' } }
          );
          const levelResult = await levelResponse.json();
          const salaryConfig =
            levelResult.success && levelResult.data
              ? cachedSalaryLevels.find((sl) => sl.level_name === levelResult.data.level_name)
              : null;
          if (salaryConfig) {
            serviceCommissionRate = parseFloat(salaryConfig.service_salary) || 0;
            chemicalCommissionRate = parseFloat(salaryConfig.chemical_salary) || 0;
          }
        } catch (e) {
          console.warn('Failed to get staff level for salary calculation:', e);
        }
      }
      const netServiceRevenue = serviceRevenue - penaltyServiceRevenue;
      const netChemicalRevenue = chemicalRevenue - penaltyChemicalRevenue;
      estimatedSalary = (netServiceRevenue * serviceCommissionRate) / 100 + (netChemicalRevenue * chemicalCommissionRate) / 100;
    }
    // Calculate previous period revenue for growth comparison
    let previousRevenue = 0;
    previousInvoices.forEach((inv) => {
      // Nếu đã filter paid ở trên thì không cần check lại, nhưng để an toàn vẫn check
      if (inv.status === 'paid' || prevPeriodInvoices.length > 0) {
        previousRevenue += parseFloat(inv.total) || 0;
      }
    });

    // Calculate growth percentage
    // null = không có dữ liệu so sánh (cả 2 đều = 0)
    let revenueGrowth = null;
    if (previousRevenue > 0) {
      // Có doanh thu kỳ trước -> tính % thay đổi
      revenueGrowth = ((revenue - previousRevenue) / previousRevenue) * 100;
    } else if (revenue > 0) {
      // Hôm nay có doanh thu, hôm trước = 0 -> tăng 100%
      revenueGrowth = 100;
    } else {
      // Cả 2 đều = 0 -> không hiển thị trend
      revenueGrowth = null;
    }

    // Get comparison date for display
    const comparisonDate =
      dashboardFilter === 'today'
        ? yesterday
        : dashboardFilter === 'yesterday'
          ? dayBeforeYesterday
          : dashboardFilter === 'thisMonth'
            ? lastMonthEnd
            : null;

    // 🆕 Gọi API lấy tổng phiếu chi theo filter hiện tại
    try {
      const expenseUrl = `cash-shifts/total-expenses?filter=${dashboardFilter}`;
      const expenseResponse = await fetch(`${checkinData.restUrl}${expenseUrl}`, {
        headers: {
          'X-WP-Nonce': checkinData.nonce,
          'Content-Type': 'application/json',
        },
      });
      const expenseResult = await expenseResponse.json();
      if (expenseResult && expenseResult.success) {
        totalExpense = expenseResult.total_expenses || 0;
      }
    } catch (e) {
      totalExpense = 0;
    }

    return {
      bookings: bookingStats,
      invoices: invoiceStats,
      financial: {
        revenue,
        tips,
        discount,
        serviceRevenue,
        productRevenue,
        chemicalRevenue,
        penaltyServiceRevenue,
        penaltyChemicalRevenue,
        workerRevenue, // Doanh số thợ = dịch vụ + hóa chất - truy thu
        estimatedSalary, // Lương tạm tính
        serviceCommissionRate,
        chemicalCommissionRate,
        totalExpense, // Placeholder - sẽ được cập nhật từ API
        previousRevenue,
        revenueGrowth,
        comparisonDate,
      },
    };
  }

  // ============================================
  // UI Updates
  // ============================================
  function updateDashboardUI(stats) {
    const formatCurrency = window.formatCurrency || ((v) => v.toLocaleString('vi-VN') + 'đ');

    // Worker View Stats
    updateElement('dashWorkerBookings', stats.bookings.total);
    // Hiển thị: X chờ / Y đang phục vụ / Z hoàn thành
    updateElement(
      'dashWorkerBookingsSub',
      `${stats.bookings.pending} chờ / ${stats.bookings.serving} đang phục vụ / ${stats.bookings.completed} hoàn thành`
    );
    updateElement('dashWorkerInvoices', stats.invoices.total);
    updateElement('dashWorkerInvoicesSub', `${stats.invoices.serving} đang phục vụ`);
    updateElement('dashWorkerTips', formatCurrency(stats.financial.tips));
    // Doanh số thợ = dịch vụ + hóa chất - truy thu
    updateElement('dashWorkerRevenue', formatCurrency(stats.financial.workerRevenue || 0));
    // Lương tạm tính
    updateElement('dashWorkerSalary', formatCurrency(stats.financial.estimatedSalary || 0));
    // Cập nhật sub text cho salary card
    const salarySubEl = document.getElementById('dashWorkerSalarySub');
    if (salarySubEl) {
      const svcRate = stats.financial.serviceCommissionRate || 0;
      const chemRate = stats.financial.chemicalCommissionRate || 0;
      salarySubEl.textContent = `DV: ${svcRate}% | HC: ${chemRate}%`;
    }

    // Manager View Stats - Main Grid
    updateElement('dashManagerBookings', stats.bookings.total);
    // Hiển thị: X chờ / Y đang / Z xong
    updateElement(
      'dashManagerBookingsSub',
      `${stats.bookings.pending} chờ / ${stats.bookings.serving} đang phục vụ / ${stats.bookings.completed} hoàn thành`
    );
    updateElement('dashManagerInvoices', stats.invoices.total);
    updateElement('dashManagerInvoicesSub', `${stats.invoices.serving} đang phục vụ`);
    updateElement('dashManagerRevenue', formatCurrency(stats.financial.revenue));
    updateElement('dashManagerDiscount', formatCurrency(stats.financial.discount));
    updateElement('dashManagerExpense', formatCurrency(stats.financial.totalExpense));

    // Update revenue growth trend
    updateRevenueTrend(stats.financial);
  }

  function updateElement(id, value) {
    const el = document.getElementById(id);
    if (el) {
      el.textContent = value;
      // Add animation
      el.classList.add('stat-value-updated');
      setTimeout(() => el.classList.remove('stat-value-updated'), 300);
    }
  }

  // ============================================
  // Revenue Growth Trend Display
  // ============================================
  function updateRevenueTrend(financial) {
    const trendEl = document.getElementById('dashRevenueTrend');
    if (!trendEl) return;

    const { revenueGrowth, comparisonDate } = financial;

    // Nếu không có dữ liệu so sánh (revenueGrowth === null), ẩn trend
    if (revenueGrowth === null) {
      trendEl.className = 'stat-trend hidden';
      trendEl.innerHTML = '';
      return;
    }

    const isUp = revenueGrowth >= 0;
    const absGrowth = Math.abs(revenueGrowth).toFixed(0); // Không số thập phân

    // Format comparison date
    let dateStr = '';
    if (comparisonDate) {
      const day = String(comparisonDate.getDate()).padStart(2, '0');
      const month = String(comparisonDate.getMonth() + 1).padStart(2, '0');
      dateStr = `(${day}/${month})`;
    }

    // Determine comparison text based on filter
    let compareText = 'hôm qua';
    if (dashboardFilter === 'thisMonth' || dashboardFilter === 'lastMonth') {
      compareText = 'tháng trước';
    }

    // Update trend element
    trendEl.className = `stat-trend ${isUp ? 'up' : 'down'}`;
    trendEl.innerHTML = `
      <i class="fas fa-arrow-${isUp ? 'up' : 'down'}"></i>
      <span class="trend-text">${isUp ? 'Tăng' : 'Giảm'} ${absGrowth}%</span>
      <span class="trend-compare">so với ${compareText} ${dateStr}</span>
    `;
  }

  // ============================================
  // Inventory & Stock Transfer Status
  // ============================================

  // Helper: Lấy khoảng thời gian theo filter
  function getFilterDateRange(filter) {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    const thisMonthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    const lastMonthStart = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    const lastMonthEnd = new Date(now.getFullYear(), now.getMonth(), 0);
    lastMonthEnd.setHours(23, 59, 59, 999);

    switch (filter) {
      case 'today':
        return { start: today, end: tomorrow };
      case 'yesterday':
        return { start: yesterday, end: today };
      case 'thisMonth':
        return { start: thisMonthStart, end: tomorrow };
      case 'lastMonth':
        return { start: lastMonthStart, end: new Date(lastMonthEnd.getTime() + 1) };
      default:
        return { start: today, end: tomorrow };
    }
  }

  // Helper: Lấy label thời gian theo filter
  function getFilterLabel(filter) {
    switch (filter) {
      case 'today':
        return 'Hôm nay';
      case 'yesterday':
        return 'Hôm qua';
      case 'thisMonth':
        return 'Tháng này';
      case 'lastMonth':
        return 'Tháng trước';
      default:
        return 'Hôm nay';
    }
  }

  async function updateInventoryStatus() {
    const container = document.getElementById('inventoryStatusCard');
    if (!container) return;

    let inventoryData = null;
    const dateRange = getFilterDateRange(dashboardFilter);
    const filterLabel = getFilterLabel(dashboardFilter);

    // Thử lấy từ cache trước
    let checks = window.getInventoryCache ? window.getInventoryCache() : null;

    // Nếu không có cache, fetch từ API
    if (!checks || checks.length === 0) {
      // Chỉ show loading khi cần fetch API
      container.innerHTML = `
        <div class="inventory-status no-check">
          <div class="status-icon muted">
            <i class="fas fa-spinner fa-spin"></i>
          </div>
          <div class="status-content">
            <div class="status-title">Đang kiểm tra...</div>
            <div class="status-sub">Vui lòng đợi</div>
          </div>
        </div>
      `;

      try {
        const response = await fetch(`${checkinData.restUrl}inventory-checks?per_page=50`, {
          headers: { 'X-WP-Nonce': checkinData.nonce },
        });
        const result = await response.json();
        if (result.success && result.data) {
          checks = result.data;
        }
      } catch (error) {
        console.error('Failed to fetch inventory checks:', error);
        checks = [];
      }
    }

    // ✅ FIXED: Lọc phiếu kiểm kho theo filter thời gian
    const filteredChecks = (checks || []).filter((check) => {
      const checkDate = new Date(check.check_date || check.created_at);
      return checkDate >= dateRange.start && checkDate < dateRange.end;
    });

    // Lấy phiếu mới nhất trong khoảng thời gian
    if (filteredChecks.length > 0) {
      // Sắp xếp theo thời gian mới nhất
      filteredChecks.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
      const latestCheck = filteredChecks[0];

      inventoryData = {
        status: parseInt(latestCheck.mismatched_count) > 0 ? 'mismatch' : 'matched',
        checked_at: formatTime(latestCheck.created_at),
        diff_count: parseInt(latestCheck.mismatched_count) || 0,
        check_code: latestCheck.check_code,
        total_checks: filteredChecks.length,
      };
      window.inventoryCheckData = inventoryData;
    }

    renderInventoryStatusUI(inventoryData, filterLabel);
  }

  function formatTime(dateString) {
    if (!dateString) return '--:--';
    const date = new Date(dateString);
    return date.toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' });
  }

  function renderInventoryStatusUI(inventoryData, filterLabel = 'Hôm nay') {
    const container = document.getElementById('inventoryStatusCard');
    if (!container) return;

    let statusHtml = '';
    const isToday = dashboardFilter === 'today';

    if (!inventoryData) {
      if (isToday) {
        statusHtml = `
          <div class="inventory-status no-check">
            <div class="status-icon warning">
              <i class="fas fa-exclamation-circle"></i>
            </div>
            <div class="status-content">
              <div class="status-title">${filterLabel} chưa kiểm kho</div>
              <div class="status-sub">Vui lòng thực hiện kiểm kho</div>
            </div>
            <button class="status-btn" onclick="window.openInventoryCheckModal && window.openInventoryCheckModal()">
              <i class="fas fa-clipboard-check"></i> Kiểm kho
            </button>
          </div>
        `;
      } else {
        statusHtml = `
          <div class="inventory-status empty">
            <div class="status-icon muted">
              <i class="fas fa-inbox"></i>
            </div>
            <div class="status-content">
              <div class="status-title">Không có phiếu kiểm kho</div>
              <div class="status-sub">${filterLabel}</div>
            </div>
          </div>
        `;
      }
    } else if (inventoryData.status === 'matched') {
      const totalInfo =
        inventoryData.total_checks > 1 ? ` (${inventoryData.total_checks} phiếu)` : '';
      statusHtml = `
        <div class="inventory-status checked">
          <div class="status-icon success">
            <i class="fas fa-check-circle"></i>
          </div>
          <div class="status-content">
            <div class="status-title">Đã kiểm - Khớp kho${totalInfo}</div>
            <div class="status-sub">Kiểm lúc ${inventoryData.checked_at || '--:--'}</div>
          </div>
        </div>
      `;
    } else if (inventoryData.status === 'mismatch') {
      const totalInfo =
        inventoryData.total_checks > 1 ? ` (${inventoryData.total_checks} phiếu)` : '';
      statusHtml = `
        <div class="inventory-status has-pending">
          <div class="status-icon danger">
            <i class="fas fa-exclamation-triangle"></i>
          </div>
          <div class="status-content">
            <div class="status-title">Đã kiểm - Có chênh lệch${totalInfo}</div>
            <div class="status-sub">${inventoryData.diff_count || 0} sản phẩm lệch</div>
          </div>
          <button class="status-btn" onclick="window.handleNavigation && window.handleNavigation('inventory')">
            <i class="fas fa-eye"></i> Xem chi tiết
          </button>
        </div>
      `;
    }

    container.innerHTML = statusHtml;
  }

  async function updateStockTransferStatus() {
    const container = document.getElementById('stockTransferStatusCard');
    if (!container) return;

    // Lấy branch_id hiện tại
    const currentBranchId = window.branchHelper?.getCurrentBranchId?.() || null;
    console.log('📦 updateStockTransferStatus - currentBranchId:', currentBranchId);

    // Luôn fetch mới từ API khi có branch filter để đảm bảo data đúng
    let allTransactions = null;

    // Chỉ show loading khi cần fetch API
    container.innerHTML = `
      <div class="inventory-status empty">
        <div class="status-icon muted">
          <i class="fas fa-spinner fa-spin"></i>
        </div>
        <div class="status-content">
          <div class="status-title">Đang kiểm tra...</div>
          <div class="status-sub">Vui lòng đợi</div>
        </div>
      </div>
    `;

    try {
      // Thêm branch_id vào query nếu có
      const branchQuery = currentBranchId ? `&branch_id=${currentBranchId}` : '';
      const url = `${checkinData.restUrl}inventory-transactions?per_page=100${branchQuery}`;
      console.log('📦 Fetching:', url);

      const response = await fetch(url, {
        headers: { 'X-WP-Nonce': checkinData.nonce },
      });
      const result = await response.json();
      console.log('📦 API Response:', result);

      if (result.success && result.data) {
        allTransactions = result.data;
      }
    } catch (error) {
      console.error('Failed to fetch inventory transactions:', error);
      allTransactions = [];
    }

    // ✅ Lọc phiếu xuất/nhập theo filter thời gian
    const dateRange = getFilterDateRange(dashboardFilter);
    const filterLabel = getFilterLabel(dashboardFilter);

    const filteredTransactions = (allTransactions || []).filter((t) => {
      // Lọc theo thời gian
      const transDate = new Date(t.transaction_date || t.created_at);
      const inDateRange = transDate >= dateRange.start && transDate < dateRange.end;
      return inDateRange;
    });

    console.log('📦 Filtered transactions:', filteredTransactions.length, filteredTransactions);

    // Đếm số phiếu pending trong khoảng thời gian
    // Status tiếng Việt: 'CHỜ DUYỆT', 'HOÀN THÀNH', 'TỪ CHỐI'
    const pendingTransfers = filteredTransactions.filter(
      (t) => t.status === 'CHỜ DUYỆT' || t.status === 'pending'
    ).length;
    const totalTransfers = filteredTransactions.length;
    window.pendingStockTransfers = pendingTransfers;

    // ✅ Cache filtered transactions for modal
    window.cachedStockTransfers = filteredTransactions;

    renderStockTransferStatusUI(pendingTransfers, totalTransfers, filterLabel);
  }

  function renderStockTransferStatusUI(
    pendingTransfers,
    totalTransfers = 0,
    filterLabel = 'Hôm nay'
  ) {
    const container = document.getElementById('stockTransferStatusCard');
    if (!container) return;

    let statusHtml = '';
    // ✅ Thêm onclick để mở modal khi có transactions
    const hasTransactions = totalTransfers > 0;
    const clickHandler = hasTransactions ? 'onclick="window.openStockTransferModal()"' : '';
    const cursorStyle = hasTransactions ? 'style="cursor: pointer;"' : '';

    if (pendingTransfers > 0) {
      statusHtml = `
        <div class="inventory-status has-pending" ${clickHandler} ${cursorStyle}>
          <div class="status-icon danger">
            <i class="fas fa-dolly"></i>
          </div>
          <div class="status-content">
            <div class="status-title">Phiếu Xuất/Nhập chờ duyệt</div>
            <div class="status-sub">${pendingTransfers}/${totalTransfers} phiếu - ${filterLabel}</div>
          </div>
          <span class="pending-count">${pendingTransfers}</span>
        </div>
      `;
    } else if (totalTransfers > 0) {
      statusHtml = `
        <div class="inventory-status checked" ${clickHandler} ${cursorStyle}>
          <div class="status-icon success">
            <i class="fas fa-check-circle"></i>
          </div>
          <div class="status-content">
            <div class="status-title">Đã xử lý ${totalTransfers} phiếu</div>
            <div class="status-sub">${filterLabel}</div>
          </div>
        </div>
      `;
    } else {
      statusHtml = `
        <div class="inventory-status empty">
          <div class="status-icon muted">
            <i class="fas fa-inbox"></i>
          </div>
          <div class="status-content">
            <div class="status-title">Không có phiếu xuất/nhập</div>
            <div class="status-sub">${filterLabel}</div>
          </div>
        </div>
      `;
    }

    container.innerHTML = statusHtml;
  }

  // ============================================
  // Stock Transfer Modal Functions (Shared between Dashboard & Inventory)
  // ============================================

  // Check if user has inventory.approve permission
  function hasInventoryApprovePermission() {
    return (
      window.checkinData?.userPermissions?.includes('inventory.approve') ||
      ['Quản lý', 'Administrator', 'administrator'].includes(window.currentUserRole || '')
    );
  }

  // Open stock transfer modal - full detail view
  window.openStockTransferModal = function (filterStatus = 'all') {
    const transactions = window.cachedStockTransfers || [];
    const filterLabel = getFilterLabel(dashboardFilter);
    const canApprove = hasInventoryApprovePermission();

    // Filter by status
    let filteredTransactions = transactions;
    if (filterStatus === 'pending') {
      filteredTransactions = transactions.filter(
        (t) => t.status === 'CHỜ DUYỆT' || t.status === 'pending'
      );
    } else if (filterStatus === 'approved') {
      filteredTransactions = transactions.filter(
        (t) => t.status === 'HOÀN THÀNH' || t.status === 'approved'
      );
    }

    const statusCounts = {
      pending: transactions.filter((t) => t.status === 'CHỜ DUYỆT' || t.status === 'pending')
        .length,
      approved: transactions.filter((t) => t.status === 'HOÀN THÀNH' || t.status === 'approved')
        .length,
    };

    // Render cards with full details
    const cardsHtml =
      filteredTransactions.length === 0
        ? '<div class="stock-transfer-empty"><i class="fas fa-inbox"></i><p>Không có phiếu nào</p></div>'
        : filteredTransactions.map((t) => renderStockTransferCard(t, canApprove)).join('');

    const modalHtml = `
      <div class="stock-transfer-modal-overlay" id="stockTransferModalOverlay" onclick="window.closeStockTransferModal(event)">
        <div class="stock-transfer-modal" onclick="event.stopPropagation()">
          <div class="stock-transfer-modal-header">
            <h3>Phiếu Xuất/Nhập Kho - ${filterLabel}</h3>
            <button class="stock-transfer-modal-close" onclick="window.closeStockTransferModal()">
              <i class="fas fa-times"></i>
            </button>
          </div>
          <div class="stock-transfer-modal-tabs">
            <button class="tab-btn ${filterStatus === 'all' ? 'active' : ''}" onclick="window.openStockTransferModal('all')">
              Tất cả (${transactions.length})
            </button>
            <button class="tab-btn ${filterStatus === 'pending' ? 'active' : ''}" onclick="window.openStockTransferModal('pending')">
              Chờ duyệt (${statusCounts.pending})
            </button>
            <button class="tab-btn ${filterStatus === 'approved' ? 'active' : ''}" onclick="window.openStockTransferModal('approved')">
              Đã duyệt (${statusCounts.approved})
            </button>
          </div>
          <div class="stock-transfer-modal-body">
            ${cardsHtml}
          </div>
        </div>
      </div>
    `;

    // Remove existing modal
    const existingModal = document.getElementById('stockTransferModalOverlay');
    if (existingModal) existingModal.remove();

    document.body.insertAdjacentHTML('beforeend', modalHtml);
    document.body.style.overflow = 'hidden';
  };

  // Render single stock transfer card
  function renderStockTransferCard(t, canApprove = false) {
    const formatDate = (dateStr) => {
      if (!dateStr) return '--';
      const d = new Date(dateStr);
      return d.toLocaleString('vi-VN', {
        hour: '2-digit',
        minute: '2-digit',
        day: '2-digit',
        month: '2-digit',
      });
    };

    const isIn = t.transaction_type === 'in' || t.transaction_type === 'IN';
    const typeLabel = isIn ? 'Nhập kho' : 'Xuất kho';
    const typeClass = isIn ? 'type-in' : 'type-out';
    const typeIcon = isIn ? 'fa-arrow-down' : 'fa-arrow-up';

    const isPending = t.status === 'CHỜ DUYỆT' || t.status === 'pending';
    const statusClass = isPending ? 'status-pending' : 'status-approved';
    const statusLabel = isPending ? 'Chờ duyệt' : 'Đã duyệt';

    const showApproveButtons = canApprove && isPending;

    return `
      <div class="stock-transfer-card">
        <div class="stock-transfer-card-header">
          <span class="stock-transfer-type ${typeClass}">
            <i class="fas ${typeIcon}"></i> ${typeLabel}
          </span>
          <span class="stock-transfer-status ${statusClass}">${statusLabel}</span>
        </div>
        <div class="stock-transfer-card-body">
          <div class="detail-row">
            <i class="fas fa-hashtag"></i>
            <span class="label">Mã phiếu:</span>
            <span class="value">${t.transaction_id || '--'}</span>
          </div>
          <div class="detail-row">
            <i class="fas fa-user"></i>
            <span class="label">Nhân viên:</span>
            <span class="value">${t.staff_name || '--'}</span>
          </div>
          <div class="detail-row">
            <i class="fas fa-clock"></i>
            <span class="label">Thời gian:</span>
            <span class="value">${formatDate(t.transaction_date)}</span>
          </div>
          <div class="detail-row">
            <i class="fas fa-boxes"></i>
            <span class="label">Sản phẩm:</span>
            <span class="value">${t.product_count || 0} SP (${t.total_quantity || 0} đơn vị)</span>
          </div>
          ${
            t.note
              ? `
          <div class="detail-row">
            <i class="fas fa-sticky-note"></i>
            <span class="label">Ghi chú:</span>
            <span class="value">${t.note}</span>
          </div>
          `
              : ''
          }
          <div class="detail-row">
            <i class="fas fa-list"></i>
            <span class="label">Chi tiết:</span>
            <span class="value products">${t.products || '--'}</span>
          </div>
          ${
            (t.image_url || t.image_key) && (t.image_url || t.image_key).startsWith('http')
              ? `
          <div class="detail-row" style="flex-direction: column; align-items: flex-start;">
            <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 8px;">
              <i class="fas fa-image"></i>
              <span class="label">Ảnh đính kèm:</span>
            </div>
            <img src="${t.image_url || t.image_key}" alt="Ảnh phiếu kho"
              style="max-width: 100%; border-radius: 8px; border: 1px solid #e5e7eb; cursor: pointer;"
              onclick="window.open('${t.image_url || t.image_key}', '_blank')" />
          </div>
          `
              : ''
          }
        </div>
        ${
          showApproveButtons
            ? `
        <div class="stock-transfer-card-actions">
          <button class="btn-approve" onclick="window.approveStockTransfer('${t.transaction_id}')">
            <i class="fas fa-check"></i> Duyệt
          </button>
          <button class="btn-reject" onclick="window.rejectStockTransfer('${t.transaction_id}')">
            <i class="fas fa-times"></i> Từ chối
          </button>
        </div>
        `
            : ''
        }
      </div>
    `;
  }

  // Close stock transfer modal
  window.closeStockTransferModal = function (event) {
    if (event && event.target !== event.currentTarget) return;
    const modal = document.getElementById('stockTransferModalOverlay');
    if (modal) {
      modal.remove();
      document.body.style.overflow = '';
    }
  };

  // Approve stock transfer - reuse logic from app-tho if available
  window.approveStockTransfer = async function (transactionId) {
    const confirmed = await showConfirm(
      `Bạn có chắc muốn duyệt phiếu <strong>${transactionId}</strong>?`,
      'Xác nhận duyệt'
    );
    if (!confirmed) return;

    try {
      const response = await fetch(
        `${checkinData.restUrl}inventory-transactions/${transactionId}/approve`,
        {
          method: 'POST',
          headers: {
            'X-WP-Nonce': checkinData.nonce,
            'Content-Type': 'application/json',
          },
        }
      );
      const result = await response.json();

      if (result.success) {
        if (window.toastSuccess) {
          window.toastSuccess('Đã duyệt phiếu thành công!', 3000);
        }
        // Close modal and refresh
        window.closeStockTransferModal();
        if (window.clearTransactionCache) window.clearTransactionCache();
        updateStockTransferStatus();
        if (window.loadInventoryTransactions) window.loadInventoryTransactions('all', true);
      } else {
        if (window.toastError) {
          window.toastError(result.message || 'Lỗi khi duyệt phiếu', 3000);
        }
      }
    } catch (error) {
      console.error('Approve error:', error);
      if (window.toastError) {
        window.toastError('Lỗi kết nối: ' + error.message, 3000);
      }
    }
  };

  // Reject stock transfer
  window.rejectStockTransfer = async function (transactionId) {
    const confirmed = await showConfirm(
      `Bạn có chắc muốn từ chối phiếu <strong>${transactionId}</strong>?`,
      'Xác nhận từ chối'
    );
    if (!confirmed) return;

    try {
      const response = await fetch(
        `${checkinData.restUrl}inventory-transactions/${transactionId}/reject`,
        {
          method: 'POST',
          headers: {
            'X-WP-Nonce': checkinData.nonce,
            'Content-Type': 'application/json',
          },
        }
      );
      const result = await response.json();

      if (result.success) {
        if (window.toastSuccess) {
          window.toastSuccess('Đã từ chối phiếu!', 3000);
        }
        window.closeStockTransferModal();
        if (window.clearTransactionCache) window.clearTransactionCache();
        updateStockTransferStatus();
        if (window.loadInventoryTransactions) window.loadInventoryTransactions('all', true);
      } else {
        if (window.toastError) {
          window.toastError(result.message || 'Lỗi khi từ chối phiếu', 3000);
        }
      }
    } catch (error) {
      console.error('Reject error:', error);
      if (window.toastError) {
        window.toastError('Lỗi kết nối: ' + error.message, 3000);
      }
    }
  };

  // ============================================
  // Approval Requests Status
  // ============================================
  let cachedApprovalRequests = [];
  const APPROVAL_CACHE_KEY = 'dashboard_approval_requests';
  const APPROVAL_CACHE_DURATION = 5 * 60 * 1000; // 5 phút

  // Helper: Lưu approval requests vào localStorage (ALL data, không filter theo date)
  function saveApprovalToCache(data, branchId) {
    try {
      const cacheData = {
        data,
        branchId,
        timestamp: Date.now(),
        isManager,
      };
      localStorage.setItem(APPROVAL_CACHE_KEY, JSON.stringify(cacheData));
    } catch (e) {
      console.warn('Failed to save approval cache:', e);
    }
  }

  // Helper: Lấy approval requests từ localStorage (kiểm tra cache hợp lệ)
  function getApprovalFromCache(branchId) {
    try {
      const cached = localStorage.getItem(APPROVAL_CACHE_KEY);
      if (!cached) return null;

      const cacheData = JSON.parse(cached);
      const isExpired = Date.now() - cacheData.timestamp > APPROVAL_CACHE_DURATION;
      const isMatchBranch = cacheData.branchId === branchId;
      const isMatchRole = cacheData.isManager === isManager;

      if (!isExpired && isMatchBranch && isMatchRole) {
        return cacheData.data;
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  // Helper: Clear approval cache (khi có thay đổi)
  function clearApprovalCache() {
    try {
      localStorage.removeItem(APPROVAL_CACHE_KEY);
    } catch (e) {
      // ignore
    }
  }

  async function updateApprovalRequestsStatus(forceRefresh = false) {
    // Chọn container dựa theo role
    const containerId = isManager ? 'approvalRequestsStatusCard' : 'workerApprovalStatusCard';
    const container = document.getElementById(containerId);
    if (!container) return;

    const filterLabel = getFilterLabel(dashboardFilter);
    const dateRange = getFilterDateRange(dashboardFilter);

    // Lấy branch ID (chỉ cho Manager)
    let branchId = '';
    if (
      isManager &&
      window.branchHelper &&
      typeof window.branchHelper.getCurrentBranchId === 'function'
    ) {
      branchId = window.branchHelper.getCurrentBranchId() || '';
    }

    // Kiểm tra cache trước (nếu không force refresh)
    // Cache lưu ALL data, không filter theo date - giống inventory/stock
    let allApprovalRequests = null;
    if (!forceRefresh) {
      allApprovalRequests = getApprovalFromCache(branchId);
    }

    // Nếu không có cache hoặc force refresh, fetch từ API
    if (!allApprovalRequests) {
      // Show loading
      container.innerHTML = `
        <div class="inventory-status empty">
          <div class="status-icon muted">
            <i class="fas fa-spinner fa-spin"></i>
          </div>
          <div class="status-content">
            <div class="status-title">Đang kiểm tra...</div>
            <div class="status-sub">Vui lòng đợi</div>
          </div>
        </div>
      `;

      try {
        // Build API URL - Manager xem tất cả, Thợ xem của mình
        // KHÔNG filter theo date ở API - lấy ALL data rồi filter local
        let apiUrl = isManager
          ? `${checkinData.restUrl}approval-requests?per_page=100`
          : `${checkinData.restUrl}my-approval-requests?per_page=100`;

        if (isManager && branchId) {
          apiUrl += `&branch=${branchId}`;
        }

        // Fetch approval requests từ API
        const response = await fetch(apiUrl, {
          headers: { 'X-WP-Nonce': checkinData.nonce },
        });
        const result = await response.json();

        allApprovalRequests = [];
        if (result.success && result.data) {
          allApprovalRequests = result.data;
          // Lưu ALL data vào cache (không filter theo date)
          saveApprovalToCache(allApprovalRequests, branchId);
        }
      } catch (error) {
        console.error('Failed to fetch approval requests:', error);
        container.innerHTML = `
          <div class="inventory-status empty">
            <div class="status-icon muted">
              <i class="fas fa-exclamation-triangle"></i>
            </div>
            <div class="status-content">
              <div class="status-title">Lỗi tải dữ liệu</div>
              <div class="status-sub">Không thể tải đơn duyệt</div>
            </div>
          </div>
        `;
        return;
      }
    }

    // ✅ FIXED: Lọc đơn theo filter thời gian dựa trên status
    // - pending: Nếu ngày trong đơn là hôm nay hoặc tương lai thì KHÔNG lọc, chỉ lọc nếu quá khứ
    // - approved: filter theo approved_at (ngày duyệt)
    // - rejected: filter theo updated_at (ngày từ chối)
    const filterByStatus = (requests, status) => {
      const today = new Date();
      today.setHours(0, 0, 0, 0); // Reset về đầu ngày để so sánh chính xác

      return (requests || []).filter((r) => {
        if (r.status !== status) return false;

        // Đối với đơn pending: kiểm tra ngày trong đơn
        if (status === 'pending') {
          // Lấy ngày trong đơn dựa trên loại đơn
          let requestDate = null;
          switch (r.request_type) {
            case 'late_early':
              requestDate = r.late_early_date ? new Date(r.late_early_date) : null;
              break;
            case 'leave':
              // Dùng ngày bắt đầu nghỉ phép
              requestDate = r.leave_start_date ? new Date(r.leave_start_date) : null;
              break;
            case 'overtime':
              requestDate = r.overtime_date ? new Date(r.overtime_date) : null;
              break;
            case 'salary_advance':
              // Đơn ứng lương không có ngày cụ thể, dùng ngày tạo
              requestDate = r.created_at ? new Date(r.created_at) : null;
              break;
            default:
              requestDate = r.created_at ? new Date(r.created_at) : null;
          }

          if (requestDate) {
            requestDate.setHours(0, 0, 0, 0);
            // Nếu ngày trong đơn là hôm nay hoặc tương lai → luôn hiển thị (không lọc theo time filter)
            if (requestDate >= today) {
              return true;
            }
          }

          // Ngày trong đơn là quá khứ → áp dụng bộ lọc thời gian theo created_at
          const dateToCheck = new Date(r.created_at);
          return dateToCheck >= dateRange.start && dateToCheck < dateRange.end;
        }

        // Đối với approved và rejected: giữ nguyên logic cũ
        let dateToCheck;
        if (status === 'approved') {
          dateToCheck = new Date(r.approved_at || r.updated_at || r.created_at);
        } else if (status === 'rejected') {
          dateToCheck = new Date(r.updated_at || r.created_at);
        } else {
          dateToCheck = new Date(r.created_at);
        }

        return dateToCheck >= dateRange.start && dateToCheck < dateRange.end;
      });
    };

    // Lọc theo từng status
    const pendingRequests = filterByStatus(allApprovalRequests, 'pending');
    const approvedRequests = filterByStatus(allApprovalRequests, 'approved');
    const rejectedRequests = filterByStatus(allApprovalRequests, 'rejected');

    // Lưu vào biến global để modal sử dụng - gộp tất cả đơn đã filter
    cachedApprovalRequests = [...pendingRequests, ...approvedRequests, ...rejectedRequests];

    // Đếm số đơn theo status
    const pendingCount = pendingRequests.length;
    const approvedCount = approvedRequests.length;
    const rejectedCount = rejectedRequests.length;

    renderApprovalRequestsStatusUI(pendingCount, approvedCount, rejectedCount, filterLabel);
  }

  function renderApprovalRequestsStatusUI(
    pendingCount,
    approvedCount = 0,
    rejectedCount = 0,
    filterLabel = 'Hôm nay'
  ) {
    // Chọn container dựa theo role
    const containerId = isManager ? 'approvalRequestsStatusCard' : 'workerApprovalStatusCard';
    const container = document.getElementById(containerId);
    if (!container) return;

    const totalCount = pendingCount + approvedCount + rejectedCount;
    const cardTitle = isManager ? 'Phê duyệt' : 'Đơn của tôi';

    let statusHtml = `
      <div class="approval-status-card">
        <div class="approval-header">
          <div class="status-icon ${pendingCount > 0 ? 'warning' : 'success'}">
            <i class="fas fa-file-signature"></i>
          </div>
          <div class="approval-title">
            <div class="status-title">${cardTitle}</div>
            <div class="status-sub">${filterLabel}</div>
          </div>
        </div>
        <div class="approval-stats">
          <div class="approval-stat ${pendingCount > 0 ? 'pending clickable' : 'pending'}"
               ${pendingCount > 0 ? 'onclick="window.openApprovalModal(\'pending\')"' : ''}>
            <span class="stat-number ${pendingCount > 0 ? 'danger' : ''}">${pendingCount}</span>
            <span class="stat-label">Chờ duyệt</span>
          </div>
          <div class="approval-stat ${approvedCount > 0 ? 'approved clickable' : 'approved'}"
               ${approvedCount > 0 ? 'onclick="window.openApprovalModal(\'approved\')"' : ''}>
            <span class="stat-number ${approvedCount > 0 ? 'success' : ''}">${approvedCount}</span>
            <span class="stat-label">Đã duyệt</span>
          </div>
          <div class="approval-stat ${rejectedCount > 0 ? 'rejected clickable' : 'rejected'}"
               ${rejectedCount > 0 ? 'onclick="window.openApprovalModal(\'rejected\')"' : ''}>
            <span class="stat-number ${rejectedCount > 0 ? 'muted' : ''}">${rejectedCount}</span>
            <span class="stat-label">Từ chối</span>
          </div>
        </div>
      </div>
    `;

    container.innerHTML = statusHtml;
  }

  // Open approval modal
  window.openApprovalModal = function (status) {
    const filteredRequests = cachedApprovalRequests.filter((r) => r.status === status);
    const filterLabel = getFilterLabel(dashboardFilter);

    const statusLabels = {
      pending: 'Chờ duyệt',
      approved: 'Đã duyệt',
      rejected: 'Đã từ chối',
    };

    const modalHtml = `
      <div class="approval-modal-overlay" id="approvalModalOverlay" onclick="window.closeApprovalModal(event)">
        <div class="approval-modal" onclick="event.stopPropagation()">
          <div class="approval-modal-header">
            <h3><i class="fas fa-file-signature"></i> Đơn ${
              statusLabels[status]
            } - ${filterLabel}</h3>
            <button class="approval-modal-close" onclick="window.closeApprovalModal()">
              <i class="fas fa-times"></i>
            </button>
          </div>
          <div class="approval-modal-body">
            ${
              filteredRequests.length === 0
                ? '<div class="approval-empty"><i class="fas fa-inbox"></i><p>Không có đơn nào</p></div>'
                : filteredRequests.map((req) => renderApprovalCard(req, status)).join('')
            }
          </div>
        </div>
      </div>
    `;

    // Remove existing modal if any
    const existingModal = document.getElementById('approvalModalOverlay');
    if (existingModal) existingModal.remove();

    document.body.insertAdjacentHTML('beforeend', modalHtml);
    document.body.style.overflow = 'hidden';
  };

  // Close approval modal
  window.closeApprovalModal = function (event) {
    if (event && event.target !== event.currentTarget) return;
    const modal = document.getElementById('approvalModalOverlay');
    if (modal) {
      modal.remove();
      document.body.style.overflow = '';
    }
  };

  // Render single approval card
  function renderApprovalCard(req, status) {
    const typeLabels = {
      late_early: 'Đi trễ/Về sớm',
      leave: 'Nghỉ phép',
      overtime: 'Tăng ca',
      salary_advance: 'Ứng lương',
    };

    const typeIcons = {
      late_early: 'fa-clock',
      leave: 'fa-calendar-times',
      overtime: 'fa-business-time',
      salary_advance: 'fa-money-bill-wave',
    };

    const formatDate = (dateStr) => {
      if (!dateStr) return '--';
      const d = new Date(dateStr);
      return d.toLocaleDateString('vi-VN', { day: '2-digit', month: '2-digit', year: 'numeric' });
    };

    const formatDateTime = (dateStr) => {
      if (!dateStr) return '--';
      const d = new Date(dateStr);
      return d.toLocaleString('vi-VN', {
        day: '2-digit',
        month: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
      });
    };

    const formatCurrency = (amount) => {
      if (!amount) return '0đ';
      return Number(amount).toLocaleString('vi-VN') + 'đ';
    };

    // Build detail info based on type
    let detailHtml = '';
    switch (req.request_type) {
      case 'late_early':
        detailHtml = `
          <div class="approval-detail-row">
            <span class="detail-label">Loại:</span>
            <span class="detail-value">${
              req.late_early_type === 'late' ? 'Đi trễ' : 'Về sớm'
            }</span>
          </div>
          <div class="approval-detail-row">
            <span class="detail-label">Ngày:</span>
            <span class="detail-value">${formatDate(req.late_early_date)}</span>
          </div>
          <div class="approval-detail-row">
            <span class="detail-label">Số phút:</span>
            <span class="detail-value">${req.late_early_minutes || 0} phút</span>
          </div>
        `;
        break;
      case 'leave':
        detailHtml = `
          <div class="approval-detail-row">
            <span class="detail-label">Từ ngày:</span>
            <span class="detail-value">${formatDate(req.leave_start_date)}</span>
          </div>
          <div class="approval-detail-row">
            <span class="detail-label">Đến ngày:</span>
            <span class="detail-value">${formatDate(req.leave_end_date)}</span>
          </div>
          <div class="approval-detail-row">
            <span class="detail-label">Số ngày:</span>
            <span class="detail-value">${req.leave_total_days || 1} ngày</span>
          </div>
        `;
        break;
      case 'overtime':
        detailHtml = `
          <div class="approval-detail-row">
            <span class="detail-label">Ngày:</span>
            <span class="detail-value">${formatDate(req.overtime_date)}</span>
          </div>
          <div class="approval-detail-row">
            <span class="detail-label">Giờ:</span>
            <span class="detail-value">${req.overtime_start_time || '--'} - ${
              req.overtime_end_time || '--'
            }</span>
          </div>
          <div class="approval-detail-row">
            <span class="detail-label">Số giờ:</span>
            <span class="detail-value">${req.overtime_hours || 0}h</span>
          </div>
        `;
        break;
      case 'salary_advance':
        detailHtml = `
          <div class="approval-detail-row">
            <span class="detail-label">Số tiền:</span>
            <span class="detail-value highlight">${formatCurrency(req.advance_amount)}</span>
          </div>
        `;
        break;
    }

    // Action buttons based on status and role
    let actionsHtml = '';
    if (status === 'pending') {
      if (isManager) {
        // Manager: Duyệt, Từ chối, Xóa
        actionsHtml = `
          <div class="approval-card-actions">
            <button class="approval-btn approve" onclick="window.handleApprovalAction('${req.request_id}', 'approve')">
              <i class="fas fa-check"></i> Duyệt
            </button>
            <button class="approval-btn reject" onclick="window.handleApprovalAction('${req.request_id}', 'reject')">
              <i class="fas fa-times"></i> Từ chối
            </button>
            <button class="approval-btn delete" onclick="window.handleApprovalAction('${req.request_id}', 'delete')">
              <i class="fas fa-trash"></i>
            </button>
          </div>
        `;
      } else {
        // Thợ: Chỉ có nút Hủy đơn
        actionsHtml = `
          <div class="approval-card-actions worker">
            <button class="approval-btn cancel" onclick="window.handleApprovalAction('${req.request_id}', 'cancel')">
              <i class="fas fa-ban"></i> Hủy đơn
            </button>
          </div>
        `;
      }
    } else if (status === 'approved') {
      actionsHtml = `
        <div class="approval-card-footer">
          <span class="approved-info"><i class="fas fa-user-check"></i> ${
            req.approved_by || 'Admin'
          }</span>
          <span class="approved-time">${formatDateTime(req.approved_at)}</span>
        </div>
      `;
    } else if (status === 'rejected') {
      actionsHtml = `
        <div class="approval-card-footer rejected">
          <span class="reject-reason">${req.reject_reason || 'Không có lý do'}</span>
        </div>
      `;
    }

    return `
      <div class="approval-card" data-request-id="${req.request_id}">
        <div class="approval-card-header">
          <div class="approval-type">
            <i class="fas ${typeIcons[req.request_type] || 'fa-file'}"></i>
            <span>${typeLabels[req.request_type] || req.request_type}</span>
          </div>
          <div class="approval-staff">${req.staff_name || 'N/A'}</div>
        </div>
        <div class="approval-card-body">
          ${detailHtml}
          ${
            req.reason
              ? `<div class="approval-reason"><i class="fas fa-comment"></i> ${req.reason}</div>`
              : ''
          }
        </div>
        ${actionsHtml}
      </div>
    `;
  }

  // Handle approval actions
  window.handleApprovalAction = async function (requestId, action) {
    const actionLabels = {
      approve: 'duyệt',
      reject: 'từ chối',
      delete: 'xóa',
      cancel: 'hủy',
    };

    // Confirm for delete or cancel
    if (action === 'delete') {
      if (!confirm('Bạn có chắc muốn xóa đơn này?')) return;
    }
    if (action === 'cancel') {
      if (!confirm('Bạn có chắc muốn hủy đơn này?')) return;
    }

    // Reject reason
    let rejectReason = '';
    if (action === 'reject') {
      rejectReason = prompt('Nhập lý do từ chối (không bắt buộc):') || '';
    }

    try {
      const card = document.querySelector(`.approval-card[data-request-id="${requestId}"]`);
      if (card) {
        card.style.opacity = '0.5';
        card.style.pointerEvents = 'none';
      }

      let apiUrl = '';
      let method = 'POST';
      let body = {};

      switch (action) {
        case 'approve':
          apiUrl = `${checkinData.restUrl}approval-requests/${requestId}/approve`;
          break;
        case 'reject':
          apiUrl = `${checkinData.restUrl}approval-requests/${requestId}/reject`;
          body = { reject_reason: rejectReason };
          break;
        case 'delete':
          apiUrl = `${checkinData.restUrl}approval-requests/${requestId}`;
          method = 'DELETE';
          break;
        case 'cancel':
          // Worker cancel - dùng POST endpoint riêng
          apiUrl = `${checkinData.restUrl}approval-requests/${requestId}/cancel`;
          break;
      }

      const response = await fetch(apiUrl, {
        method,
        headers: {
          'Content-Type': 'application/json',
          'X-WP-Nonce': checkinData.nonce,
        },
        body: action === 'reject' ? JSON.stringify(body) : undefined,
      });

      const result = await response.json();

      if (result.success) {
        // Remove card from modal
        if (card) card.remove();

        // Check if modal is empty
        const modalBody = document.querySelector('.approval-modal-body');
        if (modalBody && modalBody.querySelectorAll('.approval-card').length === 0) {
          modalBody.innerHTML =
            '<div class="approval-empty"><i class="fas fa-check-circle"></i><p>Đã xử lý hết!</p></div>';
        }

        // Clear cache và refresh dashboard data
        clearApprovalCache();
        await updateApprovalRequestsStatus(true);

        if (typeof showSuccess === 'function') {
          showSuccess(`Đã ${actionLabels[action]} đơn thành công!`);
        }
      } else {
        throw new Error(result.message || 'Thao tác thất bại');
      }
    } catch (error) {
      console.error('Approval action failed:', error);
      if (typeof showError === 'function') {
        showError('Lỗi: ' + error.message);
      }
      // Restore card
      const card = document.querySelector(`.approval-card[data-request-id="${requestId}"]`);
      if (card) {
        card.style.opacity = '';
        card.style.pointerEvents = '';
      }
    }
  };

  // ============================================
  // Recent Activity
  // ============================================
  function renderRecentActivity() {
    // Hỗ trợ cả 2 ID: recentActivityList (worker) và managerRecentActivityList (manager)
    // Populate tất cả elements có ID tương ứng
    const listElements = [
      document.getElementById('recentActivityList'),
      document.getElementById('managerRecentActivityList'),
    ].filter((el) => el !== null);

    if (listElements.length === 0) return;

    const activities = [];
    const formatCurrency = window.formatCurrency || ((v) => v.toLocaleString('vi-VN') + 'đ');
    let bookings = window.bookingsData || [];
    let invoices = window.invoicesData || [];

    // Nếu là thợ, chỉ hiển thị hoạt động liên quan đến thợ hiện tại
    const currentUserName = window.currentUserDisplayName || '';
    if (!isManager && currentUserName) {
      // Filter bookings theo hairdresser_name
      bookings = bookings.filter(
        (b) =>
          b.hairdresser_name && b.hairdresser_name.toLowerCase() === currentUserName.toLowerCase()
      );
      // Filter invoices theo staff_name trong services
      invoices = invoices.filter((i) => {
        if (!i.services || i.services.length === 0) return false;
        return i.services.some(
          (s) => s.staff_name && s.staff_name.toLowerCase() === currentUserName.toLowerCase()
        );
      });
    }

    bookings.slice(0, 10).forEach((b) => {
      activities.push({
        type: 'booking',
        time: b.time_start || b.created_at || '',
        title: b.customer_name || 'Khách hàng',
        staff: b.hairdresser_name || '',
        status: b.status,
        icon: 'fa-calendar-check',
      });
    });

    invoices.slice(0, 10).forEach((i) => {
      // Lấy tên thợ từ services nếu có
      let staffName = '';
      if (i.services && i.services.length > 0) {
        const staffNames = [...new Set(i.services.map((s) => s.staff_name).filter(Boolean))];
        staffName = staffNames.join(', ');
      }
      activities.push({
        type: 'invoice',
        time: i.created_at || '',
        title: i.customer_name || 'Khách lẻ',
        staff: staffName,
        subtitle: formatCurrency(i.total || 0),
        status: i.status,
        icon: 'fa-file-invoice-dollar',
      });
    });

    // Sort by time desc
    activities.sort((a, b) => new Date(b.time).getTime() - new Date(a.time).getTime());

    const recent = activities.slice(0, 6);

    // Tạo nội dung HTML
    let htmlContent;
    if (recent.length === 0) {
      htmlContent = `
        <div class="dashboard-empty-state">
          <i class="fas fa-inbox"></i>
          <p>Chưa có hoạt động nào</p>
        </div>
      `;
    } else {
      htmlContent = recent
        .map((act) => {
          const statusClass =
            act.status === 'paid' || act.status === 'completed'
              ? 'completed'
              : act.status === 'cancelled'
                ? 'cancelled'
                : 'pending';
          const statusText =
            act.status === 'paid'
              ? 'Đã thanh toán'
              : act.status === 'completed'
                ? 'Xong'
                : act.status === 'pending'
                  ? 'Đang phục vụ'
                  : act.status === 'cancelled'
                    ? 'Hủy'
                    : 'Chờ';

          // Xây dựng subtitle với tên thợ và thời gian
          let subtitleParts = [];
          if (act.staff) subtitleParts.push(act.staff);
          subtitleParts.push(formatTimeAgo(act.time));
          const subtitleText = subtitleParts.join(' • ');

          return `
          <div class="activity-item" onclick="handleNavigation('${
            act.type === 'booking' ? 'bookings' : 'services'
          }')">
            <div class="activity-icon">
              <i class="fas ${act.icon}"></i>
            </div>
            <div class="activity-content">
              <div class="activity-title">${act.title}</div>
              <div class="activity-time">${subtitleText}</div>
            </div>
            <div class="activity-status status-${statusClass}">${statusText}</div>
          </div>
        `;
        })
        .join('');
    }

    // Update tất cả elements
    listElements.forEach((el) => {
      el.innerHTML = htmlContent;
    });
  }

  function formatTimeAgo(dateString) {
    if (!dateString) return '';
    const date = new Date(dateString);
    const now = new Date();
    const diff = Math.floor((now - date) / 1000);

    if (diff < 60) return 'Vừa xong';
    if (diff < 3600) return `${Math.floor(diff / 60)} phút trước`;
    if (diff < 86400) return `${Math.floor(diff / 3600)} giờ trước`;
    if (diff < 604800) return `${Math.floor(diff / 86400)} ngày trước`;
    return `${date.getDate()}/${date.getMonth() + 1}`;
  }

  // ============================================
  // Worker Ranking (Manager Only)
  // ============================================
  function renderWorkerRanking() {
    const listEl = document.getElementById('workerRankingList');
    if (!listEl) return;

    const formatCurrency = window.formatCurrency || ((v) => v.toLocaleString('vi-VN') + 'đ');
    const invoices = window.invoicesData || [];
    const ranking = {};

    invoices.forEach((inv) => {
      if (inv.status === 'paid' && inv.services) {
        inv.services.forEach((s) => {
          if (s.staff_name) {
            if (!ranking[s.staff_name]) {
              ranking[s.staff_name] = { name: s.staff_name, count: 0, revenue: 0 };
            }
            ranking[s.staff_name].count += s.quantity || 1;
            ranking[s.staff_name].revenue += (parseFloat(s.price) || 0) * (s.quantity || 1);
          }
        });
      }
    });

    const sortedRanking = Object.values(ranking)
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 5);

    if (sortedRanking.length === 0) {
      listEl.innerHTML = `
        <div class="dashboard-empty-state">
          <i class="fas fa-users"></i>
          <p>Chưa có dữ liệu</p>
        </div>
      `;
      return;
    }

    listEl.innerHTML = sortedRanking
      .map((r, idx) => {
        const badgeClass =
          idx === 0 ? 'gold' : idx === 1 ? 'silver' : idx === 2 ? 'bronze' : 'default';
        return `
        <div class="ranking-item">
          <div class="ranking-badge ${badgeClass}">${idx + 1}</div>
          <div class="ranking-info">
            <div class="ranking-name">${r.name}</div>
            <div class="ranking-count">${r.count} dịch vụ</div>
          </div>
          <div class="ranking-value">${formatCurrency(r.revenue)}</div>
        </div>
      `;
      })
      .join('');
  }

  // ============================================
  // Top Services
  // ============================================
  function renderTopServices() {
    const listEl = document.getElementById('topServicesList');
    if (!listEl) return;

    const formatCurrency = window.formatCurrency || ((v) => v.toLocaleString('vi-VN') + 'đ');
    const invoices = window.invoicesData || [];
    const services = {};

    invoices.forEach((inv) => {
      if (inv.status === 'paid' && inv.services) {
        inv.services.forEach((s) => {
          if (s.service_name && s.type !== 'product') {
            if (!services[s.service_name]) {
              services[s.service_name] = { name: s.service_name, count: 0, revenue: 0 };
            }
            services[s.service_name].count += s.quantity || 1;
            services[s.service_name].revenue += (parseFloat(s.price) || 0) * (s.quantity || 1);
          }
        });
      }
    });

    const sortedServices = Object.values(services)
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);

    if (sortedServices.length === 0) {
      listEl.innerHTML = `
        <div class="dashboard-empty-state">
          <i class="fas fa-cut"></i>
          <p>Chưa có dịch vụ nào</p>
        </div>
      `;
      return;
    }

    listEl.innerHTML = sortedServices
      .map(
        (s, idx) => `
      <div class="ranking-item">
        <div class="ranking-badge ${idx === 0 ? 'gold' : 'default'}">${idx + 1}</div>
        <div class="ranking-info">
          <div class="ranking-name">${s.name}</div>
          <div class="ranking-count">${s.count} lần</div>
        </div>
        <div class="ranking-value">${formatCurrency(s.revenue)}</div>
      </div>
    `
      )
      .join('');
  }

  // ============================================
  // Upcoming Bookings (Cả Manager và Worker - trong 30 phút tới)
  // ============================================
  function renderUpcomingBookings() {
    // Hỗ trợ cả 2 ID: upcomingBookingsList (worker) và managerUpcomingBookingsList (manager)
    // Populate tất cả elements có ID tương ứng
    const listElements = [
      document.getElementById('upcomingBookingsList'),
      document.getElementById('managerUpcomingBookingsList'),
    ].filter((el) => el !== null);

    if (listElements.length === 0) return;

    const now = new Date();
    const in30Minutes = new Date(now.getTime() + 30 * 60 * 1000);
    const currentUserName = window.currentUserDisplayName || '';

    // ✅ OPTIMIZED: Sử dụng data đã cache thay vì gọi API riêng
    // Data 7days đã được load trong refreshDashboardData
    let bookings = window.bookingsData || cachedBookingsData || [];

    // Filter theo thợ hiện tại nếu KHÔNG phải Manager
    if (!isManager && currentUserName) {
      bookings = bookings.filter(
        (b) =>
          b.hairdresser_name && b.hairdresser_name.toLowerCase() === currentUserName.toLowerCase()
      );
    }

    // Filter bookings trong 30 phút tới và chưa hoàn thành
    const upcomingBookings = bookings.filter((b) => {
      if (b.status === 'success' || b.status === 'deleted') return false;

      const bookingDateTime = new Date(`${b.booking_date}T${b.booking_time || '00:00:00'}`);
      return bookingDateTime >= now && bookingDateTime <= in30Minutes;
    });

    // Sắp xếp theo thời gian gần nhất
    upcomingBookings.sort((a, b) => {
      const dateA = new Date(`${a.booking_date}T${a.booking_time || '00:00:00'}`);
      const dateB = new Date(`${b.booking_date}T${b.booking_time || '00:00:00'}`);
      return dateA - dateB;
    });

    // Tạo nội dung HTML
    let htmlContent;
    if (upcomingBookings.length === 0) {
      htmlContent = `
        <div class="dashboard-empty-state">
          <i class="fas fa-calendar-check"></i>
          <p>Không có lịch hẹn sắp đến</p>
        </div>
      `;
    } else {
      htmlContent = upcomingBookings
        .map((b) => {
          const bookingTime = b.booking_time ? b.booking_time.substring(0, 5) : '--:--';
          const bookingDateTime = new Date(`${b.booking_date}T${b.booking_time || '00:00:00'}`);
          const minutesUntil = Math.round((bookingDateTime - now) / (1000 * 60));

          // Xác định màu badge dựa trên thời gian còn lại
          let badgeClass = 'default';
          let timeText = `${minutesUntil} phút nữa`;
          if (minutesUntil <= 5) {
            badgeClass = 'danger';
            timeText = minutesUntil <= 0 ? 'Đến giờ!' : `${minutesUntil} phút nữa`;
          } else if (minutesUntil <= 15) {
            badgeClass = 'warning';
          }

          // Hiển thị tên thợ cho Manager
          const staffInfo =
            isManager && b.hairdresser_name
              ? `<div class="upcoming-staff">${b.hairdresser_name}</div>`
              : '';

          return `
          <div class="upcoming-booking-item" onclick="handleNavigation('bookings')">
            <div class="upcoming-time ${badgeClass}">
              <i class="fas fa-clock"></i>
              <span>${bookingTime}</span>
            </div>
            <div class="upcoming-content">
              <div class="upcoming-customer">${b.customer_name || 'Khách hàng'}</div>
              <div class="upcoming-service">${b.service_name || 'Dịch vụ'}</div>
              ${staffInfo}
            </div>
            <div class="upcoming-countdown ${badgeClass}">${timeText}</div>
          </div>
        `;
        })
        .join('');
    }

    // Update tất cả elements
    listElements.forEach((el) => {
      el.innerHTML = htmlContent;
    });
  }

  function renderTopServicesManager() {
    const listEl = document.getElementById('topServicesManagerList');
    if (!listEl) return;

    const formatCurrency = window.formatCurrency || ((v) => v.toLocaleString('vi-VN') + 'đ');
    const invoices = window.invoicesData || [];
    const services = {};

    invoices.forEach((inv) => {
      if (inv.status === 'paid' && inv.services) {
        inv.services.forEach((s) => {
          if (s.service_name) {
            if (!services[s.service_name]) {
              services[s.service_name] = {
                name: s.service_name,
                count: 0,
                revenue: 0,
                type: s.type,
              };
            }
            services[s.service_name].count += s.quantity || 1;
            services[s.service_name].revenue += (parseFloat(s.price) || 0) * (s.quantity || 1);
          }
        });
      }
    });

    const sortedServices = Object.values(services)
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 5);

    if (sortedServices.length === 0) {
      listEl.innerHTML = `
        <div class="dashboard-empty-state">
          <i class="fas fa-fire"></i>
          <p>Chưa có dữ liệu</p>
        </div>
      `;
      return;
    }

    listEl.innerHTML = sortedServices
      .map(
        (s, idx) => `
      <div class="ranking-item">
        <div class="ranking-badge ${idx === 0 ? 'gold' : idx === 1 ? 'silver' : 'default'}">${
          idx + 1
        }</div>
        <div class="ranking-info">
          <div class="ranking-name">${s.name}</div>
          <div class="ranking-count">${s.count} lần${s.type === 'product' ? ' (SP)' : ''}</div>
        </div>
        <div class="ranking-value">${formatCurrency(s.revenue)}</div>
      </div>
    `
      )
      .join('');
  }

  // ============================================
  // Revenue Chart (Manager Only)
  // ============================================

  // Màu sắc cho từng chi nhánh
  const branchColors = [
    { border: '#667eea', bg: 'rgba(102, 126, 234, 0.2)' }, // Tím
    { border: '#10b981', bg: 'rgba(16, 185, 129, 0.2)' }, // Xanh lá
    { border: '#f59e0b', bg: 'rgba(245, 158, 11, 0.2)' }, // Cam
    { border: '#ef4444', bg: 'rgba(239, 68, 68, 0.2)' }, // Đỏ
    { border: '#8b5cf6', bg: 'rgba(139, 92, 246, 0.2)' }, // Tím đậm
    { border: '#06b6d4', bg: 'rgba(6, 182, 212, 0.2)' }, // Cyan
  ];

  async function initRevenueChart(stats) {
    const ctx = document.getElementById('dashboardRevenueChart');
    const chartSection = document.getElementById('revenueChartSection');

    // Ẩn hoàn toàn section biểu đồ nếu filter là "today"
    if (dashboardFilter === 'today') {
      if (chartSection) {
        chartSection.classList.add('hidden');
      }
      // Destroy chart nếu có
      if (dashboardChartInstance) {
        dashboardChartInstance.destroy();
        dashboardChartInstance = null;
      }
      return;
    } else {
      if (chartSection) {
        chartSection.classList.remove('hidden');
      }
    }

    if (!ctx || typeof Chart === 'undefined') {
      console.log('Chart.js or canvas not available');
      return;
    }

    // Destroy existing chart
    if (dashboardChartInstance) {
      dashboardChartInstance.destroy();
      dashboardChartInstance = null;
    }

    const formatCurrency = window.formatCurrency || ((v) => v.toLocaleString('vi-VN') + 'đ');

    // Tính toán khoảng thời gian dựa trên dashboardFilter
    const now = new Date();
    const labels = [];
    const dateList = [];

    if (dashboardFilter === 'yesterday') {
      // Hiển thị 2 ngày: hôm qua và hôm nay
      const yesterday = new Date(now);
      yesterday.setDate(yesterday.getDate() - 1);

      dateList.push(yesterday.toISOString().split('T')[0]);
      labels.push(`${yesterday.getDate()}/${yesterday.getMonth() + 1} (Hôm qua)`);

      dateList.push(now.toISOString().split('T')[0]);
      labels.push(`${now.getDate()}/${now.getMonth() + 1} (Hôm nay)`);
    } else if (dashboardFilter === 'thisMonth') {
      // Hiển thị từ ngày 1 đến hôm nay
      const thisMonthStart = new Date(now.getFullYear(), now.getMonth(), 1);
      const daysCount = now.getDate(); // Số ngày từ đầu tháng đến hôm nay

      for (let i = 0; i < daysCount; i++) {
        const d = new Date(thisMonthStart);
        d.setDate(d.getDate() + i);
        // Format date theo local timezone thay vì UTC
        const year = d.getFullYear();
        const month = String(d.getMonth() + 1).padStart(2, '0');
        const day = String(d.getDate()).padStart(2, '0');
        const dateStr = `${year}-${month}-${day}`;
        labels.push(`${d.getDate()}`);
        dateList.push(dateStr);
      }
    } else if (dashboardFilter === 'lastMonth') {
      // Hiển thị tất cả ngày trong tháng trước
      const lastMonthStart = new Date(now.getFullYear(), now.getMonth() - 1, 1);
      const lastMonthEnd = new Date(now.getFullYear(), now.getMonth(), 0); // Ngày cuối tháng trước
      const daysCount = lastMonthEnd.getDate();

      for (let i = 0; i < daysCount; i++) {
        const d = new Date(lastMonthStart);
        d.setDate(d.getDate() + i);
        // Format date theo local timezone thay vì UTC
        const year = d.getFullYear();
        const month = String(d.getMonth() + 1).padStart(2, '0');
        const day = String(d.getDate()).padStart(2, '0');
        const dateStr = `${year}-${month}-${day}`;
        labels.push(`${d.getDate()}`);
        dateList.push(dateStr);
      }
    }

    // Lấy branch_id hiện tại
    const currentBranchId =
      window.branchHelper && typeof window.branchHelper.getCurrentBranchId === 'function'
        ? window.branchHelper.getCurrentBranchId()
        : null;

    // Lấy danh sách tất cả chi nhánh
    const allBranches =
      window.branchHelper && window.branchHelper.allBranches ? window.branchHelper.allBranches : [];

    const isAllBranches = !currentBranchId; // true nếu đang xem tất cả chi nhánh

    // Xác định filter period để gọi API
    // Nếu yesterday thì cần load cả 2 ngày, dùng filter "today" để có đủ data
    // Nếu thisMonth hoặc lastMonth thì dùng trực tiếp
    let apiPeriod = dashboardFilter;
    if (dashboardFilter === 'yesterday') {
      apiPeriod = '2days'; // Sẽ cần custom hoặc dùng today rồi filter lại
    }

    let datasets = [];
    let chartType = 'bar';

    if (isAllBranches && allBranches.length > 1) {
      // === CHẾ ĐỘ TẤT CẢ CHI NHÁNH: Biểu đồ LINE, mỗi line là 1 chi nhánh ===
      chartType = 'line';

      // Load invoices cho từng chi nhánh song song
      const branchDataPromises = allBranches.map(async (branch, index) => {
        try {
          // Gọi API với filter phù hợp
          let apiUrl = `${checkinData.restUrl}staff-invoices?filter=${
            dashboardFilter === 'yesterday' ? 'today' : dashboardFilter
          }&branch_id=${branch.id}`;

          const response = await fetch(apiUrl, {
            headers: {
              'X-WP-Nonce': checkinData.nonce,
              'Content-Type': 'application/json',
            },
          });
          const result = await response.json();

          let invoices = [];
          if (Array.isArray(result)) {
            invoices = result;
          } else if (result && result.success && Array.isArray(result.data)) {
            invoices = result.data;
          } else if (result && Array.isArray(result.data)) {
            invoices = result.data;
          }

          // Nếu là yesterday, cần load thêm data yesterday
          if (dashboardFilter === 'yesterday') {
            try {
              const yesterdayUrl = `${checkinData.restUrl}staff-invoices?filter=yesterday&branch_id=${branch.id}`;
              const yesterdayResponse = await fetch(yesterdayUrl, {
                headers: {
                  'X-WP-Nonce': checkinData.nonce,
                  'Content-Type': 'application/json',
                },
              });
              const yesterdayResult = await yesterdayResponse.json();
              let yesterdayInvoices = [];
              if (Array.isArray(yesterdayResult)) {
                yesterdayInvoices = yesterdayResult;
              } else if (
                yesterdayResult &&
                yesterdayResult.success &&
                Array.isArray(yesterdayResult.data)
              ) {
                yesterdayInvoices = yesterdayResult.data;
              } else if (yesterdayResult && Array.isArray(yesterdayResult.data)) {
                yesterdayInvoices = yesterdayResult.data;
              }
              invoices = [...yesterdayInvoices, ...invoices];
            } catch (e) {
              console.warn('Failed to load yesterday data for chart:', e);
            }
          }

          // Group by date
          const dailyRevenue = {};
          invoices.forEach((inv) => {
            if (inv.status === 'paid' && inv.created_at) {
              const date = inv.created_at.split('T')[0].split(' ')[0];
              dailyRevenue[date] = (dailyRevenue[date] || 0) + (parseFloat(inv.total) || 0);
            }
          });

          // Build revenue data array
          const revenueData = dateList.map((date) => dailyRevenue[date] || 0);
          const color = branchColors[index % branchColors.length];

          return {
            label: branch.branch_name || `Chi nhánh ${branch.id}`,
            data: revenueData,
            borderColor: color.border,
            backgroundColor: color.bg,
            tension: 0.4,
            fill: false,
            borderWidth: 2,
            pointRadius: 3,
            pointHoverRadius: 5,
          };
        } catch (e) {
          console.warn(`Failed to load chart data for branch ${branch.id}:`, e);
          return null;
        }
      });

      const branchDatasets = await Promise.all(branchDataPromises);
      datasets = branchDatasets.filter((ds) => ds !== null);
    } else {
      // === CHẾ ĐỘ 1 CHI NHÁNH: Biểu đồ BAR (cột) ===
      chartType = 'bar';

      let chartInvoices = [];
      try {
        let apiUrl = `${checkinData.restUrl}staff-invoices?filter=${
          dashboardFilter === 'yesterday' ? 'today' : dashboardFilter
        }`;
        if (currentBranchId) {
          apiUrl += `&branch_id=${currentBranchId}`;
        }

        const response = await fetch(apiUrl, {
          headers: {
            'X-WP-Nonce': checkinData.nonce,
            'Content-Type': 'application/json',
          },
        });

        const result = await response.json();

        if (Array.isArray(result)) {
          chartInvoices = result;
        } else if (result && result.success && Array.isArray(result.data)) {
          chartInvoices = result.data;
        } else if (result && Array.isArray(result.data)) {
          chartInvoices = result.data;
        }

        // Nếu là yesterday, cần load thêm data yesterday
        if (dashboardFilter === 'yesterday') {
          try {
            let yesterdayUrl = `${checkinData.restUrl}staff-invoices?filter=yesterday`;
            if (currentBranchId) {
              yesterdayUrl += `&branch_id=${currentBranchId}`;
            }
            const yesterdayResponse = await fetch(yesterdayUrl, {
              headers: {
                'X-WP-Nonce': checkinData.nonce,
                'Content-Type': 'application/json',
              },
            });
            const yesterdayResult = await yesterdayResponse.json();
            let yesterdayInvoices = [];
            if (Array.isArray(yesterdayResult)) {
              yesterdayInvoices = yesterdayResult;
            } else if (
              yesterdayResult &&
              yesterdayResult.success &&
              Array.isArray(yesterdayResult.data)
            ) {
              yesterdayInvoices = yesterdayResult.data;
            } else if (yesterdayResult && Array.isArray(yesterdayResult.data)) {
              yesterdayInvoices = yesterdayResult.data;
            }
            chartInvoices = [...yesterdayInvoices, ...chartInvoices];
          } catch (e) {
            console.warn('Failed to load yesterday data for chart:', e);
          }
        }
      } catch (e) {
        console.warn('Failed to load chart data:', e);
        chartInvoices = window.invoicesData || [];
      }

      // Group by date
      const dailyRevenue = {};
      chartInvoices.forEach((inv) => {
        if (inv.status === 'paid' && inv.created_at) {
          const date = inv.created_at.split('T')[0].split(' ')[0];
          dailyRevenue[date] = (dailyRevenue[date] || 0) + (parseFloat(inv.total) || 0);
        }
      });

      const revenueData = dateList.map((date) => dailyRevenue[date] || 0);

      // Tìm tên chi nhánh hiện tại
      let branchName = 'Doanh thu';
      if (currentBranchId && allBranches.length > 0) {
        const branch = allBranches.find((b) => b.id === currentBranchId);
        if (branch) {
          branchName = branch.branch_name;
        }
      }

      datasets = [
        {
          label: branchName,
          data: revenueData,
          backgroundColor: 'rgba(102, 126, 234, 0.7)',
          borderColor: '#667eea',
          borderWidth: 1,
          borderRadius: 4,
          barThickness: 'flex',
          maxBarThickness: 40,
        },
      ];
    }

    // Tạo chart config
    const chartConfig = {
      type: chartType,
      data: {
        labels: labels,
        datasets: datasets,
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: {
          mode: 'index',
          intersect: false,
        },
        plugins: {
          legend: {
            position: 'top',
            labels: {
              usePointStyle: true,
              padding: 15,
              font: { size: 12 },
            },
          },
          tooltip: {
            backgroundColor: 'rgba(0, 0, 0, 0.8)',
            padding: 12,
            titleFont: { size: 14 },
            bodyFont: { size: 13 },
            callbacks: {
              label: function (context) {
                return context.dataset.label + ': ' + formatCurrency(context.raw);
              },
            },
          },
        },
        scales: {
          y: {
            type: 'linear',
            display: true,
            position: 'left',
            beginAtZero: true,
            grid: { color: 'rgba(0, 0, 0, 0.05)' },
            ticks: {
              callback: function (value) {
                if (value >= 1000000) return (value / 1000000).toFixed(1) + 'M';
                if (value >= 1000) return (value / 1000).toFixed(0) + 'K';
                return value;
              },
            },
          },
          x: {
            grid: { display: false },
          },
        },
      },
    };

    dashboardChartInstance = new Chart(ctx, chartConfig);
  }

  // ============================================
  // Expose to global scope
  // ============================================
  window.AppThoDashboard = {
    init: initDashboard,
    refresh: refreshDashboardData,
    refreshInventoryStatus: updateInventoryStatus,
    refreshStockTransferStatus: updateStockTransferStatus,
    resetCache: resetDashboardCache, // Reset cache khi branch thay đổi
  };

  // Alias for backward compatibility
  window.renderDashboard = initDashboard;
})();
