/**
 * Shift Management Module for App Thợ
 * Tính năng giao nhận ca dành cho Thu Ngân & Quản Lý
 * @version 1.0.0
 */

(function () {
  'use strict';

  // ============================================
  // Shift Management State
  // ============================================
  let currentShift = null; // Ca làm việc hiện tại
  let shiftHistory = []; // Lịch sử ca
  let cashTransactions = []; // Phiếu thu/chi trong ca
  let salesData = null; // Doanh số realtime
  let shiftFilter = 'today'; // Bộ lọc lịch sử ca
  let isManager = false;
  let currentUserId = null;
  let currentUserDisplayName = '';

  // Cache keys
  const CACHE_KEYS = {
    CURRENT_SHIFT: 'mkt192_current_shift',
    SHIFT_HISTORY: 'mkt192_shift_history',
    CASH_TRANSACTIONS: 'mkt192_cash_transactions',
  };

  // ============================================
  // Shift Status Constants
  // ============================================
  const SHIFT_STATUS = {
    OPEN: 'open',
    CLOSED: 'closed',
    HANDOVER_PENDING: 'handover_pending',
    HANDOVER_COMPLETED: 'handover_completed',
  };

  const TRANSACTION_TYPES = {
    RECEIPT: 'receipt', // Phiếu thu
    PAYMENT: 'payment', // Phiếu chi
  };

  const HANDOVER_METHODS = {
    CASH: 'cash', // Tiền mặt
    TRANSFER: 'transfer', // Chuyển khoản
  };

  // ============================================
  // Initialization
  // ============================================
  async function initShiftManagement() {
    const shiftContent = document.getElementById('shiftsContent');
    if (!shiftContent) {
      console.warn('Shift management content not found');
      return;
    }

    try {
      // Determine role
      const managerRoles = ['Quản Lý', 'Thu Ngân', 'administrator', 'admin', 'Quản lý'];
      isManager = managerRoles.includes(window.currentUserRole || '');

      if (!isManager) {
        shiftContent.innerHTML = `
          <div class="shift-access-denied">
            <i class="fas fa-lock"></i>
            <h3>Không có quyền truy cập</h3>
            <p>Tính năng này chỉ dành cho Thu Ngân và Quản Lý</p>
          </div>
        `;
        return;
      }

      // Show loading state using global page loader
      if (window.showPageLoader) {
        window.showPageLoader({ text: 'Đang tải quản lý ca...', subtitle: 'Vui lòng đợi' });
      }

      // Get current user info
      currentUserId = window.checkinData?.currentUser?.ID || '';
      currentUserDisplayName = window.currentUserDisplayName || 'Nhân viên';

      // Load fresh data from API first
      await refreshShiftData();

      // Hide loader after data loaded
      if (window.hidePageLoader) {
        window.hidePageLoader();
      }
    } catch (error) {
      console.error('Shift management init error:', error);
      // Hide loader on error
      if (window.hidePageLoader) {
        window.hidePageLoader();
      }
      // If API fails, try cached data
      loadCachedData();
      renderShiftManagement();
      attachShiftEventListeners();
      if (typeof showError === 'function') {
        showError('Lỗi tải quản lý ca: ' + error.message);
      }
    }
  }

  // ============================================
  // Cache Management
  // ============================================
  function loadCachedData() {
    try {
      const cachedShift = localStorage.getItem(CACHE_KEYS.CURRENT_SHIFT);
      if (cachedShift) {
        currentShift = JSON.parse(cachedShift);
      }

      const cachedHistory = localStorage.getItem(CACHE_KEYS.SHIFT_HISTORY);
      if (cachedHistory) {
        shiftHistory = JSON.parse(cachedHistory);
      }

      const cachedTransactions = localStorage.getItem(CACHE_KEYS.CASH_TRANSACTIONS);
      if (cachedTransactions) {
        cashTransactions = JSON.parse(cachedTransactions);
      }
    } catch (e) {
      console.error('Error loading cached shift data:', e);
    }
  }

  function saveCachedData() {
    try {
      if (currentShift) {
        localStorage.setItem(CACHE_KEYS.CURRENT_SHIFT, JSON.stringify(currentShift));
      } else {
        localStorage.removeItem(CACHE_KEYS.CURRENT_SHIFT);
      }
      localStorage.setItem(CACHE_KEYS.SHIFT_HISTORY, JSON.stringify(shiftHistory));
      localStorage.setItem(CACHE_KEYS.CASH_TRANSACTIONS, JSON.stringify(cashTransactions));
    } catch (e) {
      console.error('Error saving shift data to cache:', e);
    }
  }

  function clearCachedData() {
    try {
      localStorage.removeItem(CACHE_KEYS.CURRENT_SHIFT);
      localStorage.removeItem(CACHE_KEYS.SHIFT_HISTORY);
      localStorage.removeItem(CACHE_KEYS.CASH_TRANSACTIONS);
      // Reset in-memory data
      currentShift = null;
      shiftHistory = [];
      cashTransactions = [];
      salesData = null;
      preOpenSalesData = null;
    } catch (e) {
      // Error clearing shift cache
    }
  }

  // ============================================
  // Permission Helper
  // ============================================

  /**
   * Check if current user has permission for module.action
   * @param {string} module - Module name (e.g., 'shift')
   * @param {string} action - Action name (e.g., 'delete')
   * @returns {boolean}
   */
  function checkPermission(module, action) {
    const permissionKey = `${module}.${action}`;
    // Check via checkinData.userPermissions (array of allowed actions)
    if (
      typeof checkinData !== 'undefined' &&
      checkinData.userPermissions &&
      Array.isArray(checkinData.userPermissions)
    ) {
      return checkinData.userPermissions.includes(permissionKey);
    }
    return false;
  }

  // ============================================
  // API Functions
  // ============================================

  /**
   * Lấy branch_id hiện tại từ nhiều nguồn
   * Priority: branchHelper > localStorage > cookie > select dropdown
   */
  function getCurrentBranchId() {
    let branchId = 0;

    // 1. Thử lấy từ branchHelper global (ưu tiên cao nhất)
    if (typeof window.branchHelper !== 'undefined' && window.branchHelper?.getCurrentBranchId) {
      branchId = window.branchHelper.getCurrentBranchId();
      if (branchId > 0) return branchId;
    }

    // 2. Fallback: Lấy từ localStorage
    const storedBranchId = localStorage.getItem('checkin_current_branch_id');
    if (storedBranchId) {
      branchId = parseInt(storedBranchId);
      if (branchId > 0) return branchId;
    }

    // 3. Fallback: Lấy từ cookie
    const cookieMatch = document.cookie.match(/checkinBranchId=(\d+)/);
    if (cookieMatch) {
      branchId = parseInt(cookieMatch[1]);
      if (branchId > 0) return branchId;
    }

    // 4. Fallback cuối: Lấy từ select dropdown trên header
    const branchSelect =
      document.getElementById('branch-select') ||
      document.querySelector('[data-branch-select]') ||
      document.querySelector('select[name="branch"]');
    if (branchSelect && branchSelect.value) {
      branchId = parseInt(branchSelect.value);
      if (branchId > 0) return branchId;
    }

    return 0;
  }

  /**
   * Kiểm tra chế độ đa chi nhánh có bật không
   */
  function isMultiBranchEnabled() {
    return (
      window.checkinData?.enableMultiBranch === true ||
      window.checkinData?.enableMultiBranch === '1'
    );
  }

  async function fetchShiftAPI(endpoint, options = {}) {
    try {
      let url = `${window.checkinData.restUrl}cash-shifts/${endpoint}`;

      // ✅ FIXED: Luôn thêm branch_id vào URL để đảm bảo tìm ca đúng chi nhánh
      // Điều này quan trọng để các user khác trong cùng chi nhánh thấy ca đang mở
      const branchId = getCurrentBranchId();
      if (branchId > 0) {
        const separator = url.includes('?') ? '&' : '?';
        url = `${url}${separator}branch_id=${branchId}`;
      }

      const response = await fetch(url, {
        ...options,
        headers: {
          'Content-Type': 'application/json',
          'X-WP-Nonce': window.checkinData.nonce,
          ...options.headers,
        },
      });

      const result = await response.json();

      if (result.code && result.message) {
        throw new Error(result.message);
      }

      if (result.success === false) {
        throw new Error(result.message || 'Lỗi từ server');
      }

      return result.data || result;
    } catch (error) {
      console.error('Cash Shift API error:', error);
      throw error;
    }
  }

  async function refreshShiftData() {
    try {
      // Load current open shift
      const openShift = await fetchShiftAPI('current');
      // API trả về null hoặc object shift có id
      currentShift = openShift && openShift.id ? openShift : null;

      // Load today's transactions and sales if shift is open
      if (currentShift && currentShift.id) {
        const [transactions, sales] = await Promise.all([
          fetchShiftAPI(`${currentShift.id}/transactions`),
          fetchShiftAPI(`${currentShift.id}/sales`),
        ]);
        cashTransactions = transactions || [];
        salesData = sales || null;
        // Clear pre-open data since shift is open
        preOpenSalesData = null;
      } else {
        cashTransactions = [];
        salesData = null;
        // Prefetch pre-open-sales in background (không chờ đợi)
        fetchShiftAPI('pre-open-sales')
          .then((data) => {
            preOpenSalesData = data;
          })
          .catch(() => {
            preOpenSalesData = null;
          });
      }

      // Load shift history
      const history = await fetchShiftAPI(`history?filter=${shiftFilter}`);
      shiftHistory = history || [];

      // Save to cache
      saveCachedData();

      // Re-render UI
      renderShiftManagement();
    } catch (error) {
      console.error('Error refreshing shift data:', error);
      // Continue with cached data
      renderShiftManagement();
    }
  }

  // ============================================
  // Main Render Function
  // ============================================
  function renderShiftManagement() {
    const shiftContent = document.getElementById('shiftsContent');
    if (!shiftContent) return;

    // ✅ FIXED: Kiểm tra ca có phải của user hiện tại không
    // API trả về is_own_shift = true nếu ca thuộc về user hiện tại
    const isOwnShift = currentShift
      ? currentShift.is_own_shift === true ||
        currentShift.is_own_shift === 1 ||
        currentShift.is_own_shift === '1'
      : false;
    const isOtherUserShift = currentShift && !isOwnShift;

    shiftContent.innerHTML = `
      <div class="shift-management-container">
        <!-- Header with current shift status -->
        <div class="shift-header">
          <div class="shift-status-card ${
            currentShift ? (isOwnShift ? 'shift-open' : 'shift-other-user') : 'shift-closed'
          }">
            <div class="shift-status-icon">
              <i class="fas ${currentShift ? 'fa-door-open' : 'fa-door-closed'}"></i>
            </div>
            <div class="shift-status-info">
              <h3 class="shift-status-title">${
                currentShift
                  ? isOwnShift
                    ? 'Ca đang mở'
                    : 'Ca đang mở bởi người khác'
                  : 'Chưa mở ca'
              }</h3>
              ${
                currentShift
                  ? `
                <p class="shift-status-detail">
                  <span class="shift-user"><i class="fas fa-user"></i> ${
                    currentShift.staff_name || currentUserDisplayName
                  }</span>
                  <span class="shift-time"><i class="fas fa-clock"></i> ${formatDateTime(
                    currentShift.start_time
                  )}</span>
                </p>
                <p class="shift-opening-balance">
                  <i class="fas fa-wallet"></i> Số dư đầu ca: <strong>${formatCurrency(
                    currentShift.opening_balance || 0
                  )}</strong>
                </p>
                ${
                  isOtherUserShift
                    ? `
                <p class="shift-other-user-notice">
                  <i class="fas fa-info-circle"></i>
                  Ca này được mở bởi <strong>${currentShift.staff_name}</strong>.
                  Bạn cần đợi ca hiện tại kết thúc mới có thể mở ca mới.
                </p>
                `
                    : ''
                }
              `
                  : `
                <p class="shift-status-detail">Nhấn "Mở ca" để bắt đầu làm việc</p>
              `
              }
            </div>
            <div class="shift-actions">
              ${
                !currentShift
                  ? `
                <button id="openShiftBtn" class="shift-btn shift-btn-primary">
                  <i class="fas fa-play-circle"></i> Mở ca
                </button>
              `
                  : isOwnShift
                  ? `
                <button id="closeShiftBtn" class="shift-btn shift-btn-danger">
                  <i class="fas fa-stop-circle"></i> Kết ca
                </button>
              `
                  : `
                <span class="shift-waiting-badge">
                  <i class="fas fa-hourglass-half"></i> Đang chờ kết ca
                </span>
              `
              }
            </div>
          </div>
        </div>

        ${currentShift && isOwnShift ? renderCurrentShiftContent() : ''}
        ${currentShift && isOtherUserShift ? renderOtherUserShiftContent() : ''}

        <!-- Shift History -->
        <div class="shift-history-section">
          <div class="shift-section-header">
            <h3><i class="fas fa-history"></i> Lịch sử ca</h3>
            <div class="shift-history-filter">
              <select id="shiftHistoryFilter" class="shift-select">
                <option value="today" ${shiftFilter === 'today' ? 'selected' : ''}>Hôm nay</option>
                <option value="yesterday" ${
                  shiftFilter === 'yesterday' ? 'selected' : ''
                }>Hôm qua</option>
                <option value="thisWeek" ${
                  shiftFilter === 'thisWeek' ? 'selected' : ''
                }>Tuần này</option>
                <option value="thisMonth" ${
                  shiftFilter === 'thisMonth' ? 'selected' : ''
                }>Tháng này</option>
              </select>
            </div>
          </div>
          <div class="shift-history-list" id="shiftHistoryList">
            ${renderShiftHistory()}
          </div>
        </div>
      </div>
    `;

    // Reattach listeners after render
    attachShiftEventListeners();
  }

  function renderCurrentShiftContent() {
    const totalReceipts = cashTransactions
      .filter((t) => t.type === TRANSACTION_TYPES.RECEIPT)
      .reduce((sum, t) => sum + (parseFloat(t.amount) || 0), 0);

    const totalPayments = cashTransactions
      .filter((t) => t.type === TRANSACTION_TYPES.PAYMENT)
      .reduce((sum, t) => sum + (parseFloat(t.amount) || 0), 0);

    const openingBalance = parseFloat(currentShift.opening_balance) || 0;
    const openingTransferBalance = parseFloat(currentShift.opening_transfer_balance) || 0;

    // Sử dụng salesData realtime nếu có
    const cashRevenue = salesData
      ? parseFloat(salesData.cash_revenue) || 0
      : parseFloat(currentShift.cash_revenue) || 0;
    const cashInvoiceCount = salesData
      ? parseInt(salesData.cash_invoice_count) || 0
      : parseInt(currentShift.cash_invoice_count) || 0;
    const transferRevenue = salesData
      ? parseFloat(salesData.transfer_revenue) || 0
      : parseFloat(currentShift.transfer_revenue) || 0;
    const transferInvoiceCount = salesData
      ? parseInt(salesData.transfer_invoice_count) || 0
      : parseInt(currentShift.transfer_invoice_count) || 0;

    // Số dư TM dự kiến = Đầu ca + Doanh số tiền mặt + Thu - Chi
    const expectedCashBalance = openingBalance + cashRevenue + totalReceipts - totalPayments;

    // Số dư CK dự kiến = Đầu ca CK + Doanh số chuyển khoản
    const expectedTransferBalance = openingTransferBalance + transferRevenue;

    return `
      <!-- Quick Stats -->
      <div class="shift-quick-stats">
        <div class="shift-stat-card">
          <div class="shift-stat-icon bg-blue"><i class="fas fa-wallet"></i></div>
          <div class="shift-stat-info">
            <span class="shift-stat-label">Số dư TM đầu ca</span>
            <span class="shift-stat-value">${formatCurrency(openingBalance)}</span>
          </div>
        </div>
        ${
          openingTransferBalance > 0
            ? `
        <div class="shift-stat-card">
          <div class="shift-stat-icon bg-indigo"><i class="fas fa-piggy-bank"></i></div>
          <div class="shift-stat-info">
            <span class="shift-stat-label">Số dư CK đầu ca</span>
            <span class="shift-stat-value">${formatCurrency(openingTransferBalance)}</span>
          </div>
        </div>
        `
            : ''
        }
        <div class="shift-stat-card">
          <div class="shift-stat-icon bg-green"><i class="fas fa-money-bill-wave"></i></div>
          <div class="shift-stat-info">
            <span class="shift-stat-label">Tiền mặt<br><small>(${cashInvoiceCount} HĐ)</small></span>
            <span class="shift-stat-value">${formatCurrency(cashRevenue)}</span>
          </div>
        </div>
        <div class="shift-stat-card">
          <div class="shift-stat-icon bg-cyan"><i class="fas fa-university"></i></div>
          <div class="shift-stat-info">
            <span class="shift-stat-label">Chuyển khoản<br><small>(${transferInvoiceCount} HĐ)</small></span>
            <span class="shift-stat-value">${formatCurrency(transferRevenue)}</span>
          </div>
        </div>
        <div class="shift-stat-card">
          <div class="shift-stat-icon bg-teal"><i class="fas fa-arrow-down"></i></div>
          <div class="shift-stat-info">
            <span class="shift-stat-label">Tổng thu</span>
            <span class="shift-stat-value">${formatCurrency(totalReceipts)}</span>
          </div>
        </div>
        <div class="shift-stat-card">
          <div class="shift-stat-icon bg-red"><i class="fas fa-arrow-up"></i></div>
          <div class="shift-stat-info">
            <span class="shift-stat-label">Tổng chi</span>
            <span class="shift-stat-value">${formatCurrency(totalPayments)}</span>
          </div>
        </div>
        <div class="shift-stat-card shift-stat-highlight">
          <div class="shift-stat-icon bg-purple"><i class="fas fa-calculator"></i></div>
          <div class="shift-stat-info">
            <span class="shift-stat-label">Số dư TM dự kiến</span>
            <span class="shift-stat-value">${formatCurrency(expectedCashBalance)}</span>
          </div>
        </div>
        ${
          openingTransferBalance > 0 || transferRevenue > 0
            ? `
        <div class="shift-stat-card shift-stat-highlight">
          <div class="shift-stat-icon bg-indigo"><i class="fas fa-chart-line"></i></div>
          <div class="shift-stat-info">
            <span class="shift-stat-label">Số dư CK dự kiến</span>
            <span class="shift-stat-value">${formatCurrency(expectedTransferBalance)}</span>
          </div>
        </div>
        `
            : ''
        }
      </div>

      <!-- Transaction Actions -->
      <div class="shift-transaction-section">
        <div class="shift-section-header">
          <h3><i class="fas fa-exchange-alt"></i> Phiếu thu/chi trong ca</h3>
          <div class="shift-action-buttons">
            <button id="addReceiptBtn" class="shift-btn shift-btn-success">
              <i class="fas fa-plus"></i> Phiếu thu
            </button>
            <button id="addPaymentBtn" class="shift-btn shift-btn-warning">
              <i class="fas fa-minus"></i> Phiếu chi
            </button>
          </div>
        </div>

        <!-- Transaction List -->
        <div class="shift-transaction-list" id="transactionList">
          ${renderTransactionList()}
        </div>
      </div>
    `;
  }

  function renderTransactionList() {
    if (!cashTransactions || cashTransactions.length === 0) {
      return `
        <div class="shift-empty-state">
          <i class="fas fa-receipt"></i>
          <p>Chưa có phiếu thu/chi nào trong ca</p>
        </div>
      `;
    }

    // Sort by created_at desc
    const sortedTransactions = [...cashTransactions].sort(
      (a, b) => new Date(b.created_at) - new Date(a.created_at)
    );

    return `
      <div class="transaction-table-wrapper">
        <table class="transaction-table">
          <thead>
            <tr>
              <th>Thời gian</th>
              <th>Loại</th>
              <th>Số tiền</th>
              <th>Lý do</th>
              <th>Người tạo</th>
              <th>Thao tác</th>
            </tr>
          </thead>
          <tbody>
            ${sortedTransactions
              .map(
                (t) => `
              <tr class="transaction-row ${
                t.type === TRANSACTION_TYPES.RECEIPT ? 'receipt' : 'payment'
              }">
                <td>${formatDateTime(t.created_at)}</td>
                <td>
                  <span class="transaction-type-badge ${t.type}">
                    <i class="fas ${
                      t.type === TRANSACTION_TYPES.RECEIPT ? 'fa-arrow-down' : 'fa-arrow-up'
                    }"></i>
                    ${t.type === TRANSACTION_TYPES.RECEIPT ? 'Thu' : 'Chi'}
                  </span>
                </td>
                <td class="transaction-amount ${t.type}">${formatCurrency(t.amount)}</td>
                <td class="transaction-reason">${escapeHtml(t.reason || '-')}</td>
                <td>${escapeHtml(t.created_by_name || '-')}</td>
                <td>
                  <button class="shift-btn-icon delete-transaction" data-id="${t.id}" title="Xóa">
                    <i class="fas fa-trash"></i>
                  </button>
                </td>
              </tr>
            `
              )
              .join('')}
          </tbody>
        </table>
      </div>
    `;
  }

  // ✅ ADDED: Render content khi ca đang mở bởi người khác
  function renderOtherUserShiftContent() {
    const openingBalance = parseFloat(currentShift.opening_balance) || 0;

    // ✅ FIXED: Sử dụng salesData realtime nếu có (được load từ API sales)
    const cashRevenue = salesData
      ? parseFloat(salesData.cash_revenue) || 0
      : parseFloat(currentShift.cash_revenue) || 0;
    const transferRevenue = salesData
      ? parseFloat(salesData.transfer_revenue) || 0
      : parseFloat(currentShift.transfer_revenue) || 0;
    const cashInvoiceCount = salesData
      ? parseInt(salesData.cash_invoice_count) || 0
      : parseInt(currentShift.cash_invoice_count) || 0;
    const transferInvoiceCount = salesData
      ? parseInt(salesData.transfer_invoice_count) || 0
      : parseInt(currentShift.transfer_invoice_count) || 0;

    // Tính tổng thu/chi từ transactions nếu có
    const totalReceipts = cashTransactions
      .filter((t) => t.type === TRANSACTION_TYPES.RECEIPT)
      .reduce((sum, t) => sum + (parseFloat(t.amount) || 0), 0);
    const totalPayments = cashTransactions
      .filter((t) => t.type === TRANSACTION_TYPES.PAYMENT)
      .reduce((sum, t) => sum + (parseFloat(t.amount) || 0), 0);

    // Số dư TM dự kiến
    const expectedBalance = openingBalance + cashRevenue + totalReceipts - totalPayments;

    return `
      <!-- Info khi ca mở bởi người khác -->
      <div class="shift-other-user-info">
        <div class="other-user-alert">
          <div class="alert-icon">
            <i class="fas fa-user-clock"></i>
          </div>
          <div class="alert-content">
            <h4>Chi nhánh đang có ca hoạt động</h4>
            <p>Ca này được mở bởi <strong>${
              currentShift.staff_name || 'Nhân viên khác'
            }</strong> lúc <strong>${formatDateTime(currentShift.start_time)}</strong>.</p>
            <p>Bạn có thể xem thông tin tổng quan nhưng không thể thực hiện các thao tác trên ca này.</p>
          </div>
        </div>

        <!-- Hiển thị thống kê read-only -->
        <div class="shift-readonly-stats">
          <h4><i class="fas fa-chart-bar"></i> Thống kê ca hiện tại</h4>
          <div class="shift-quick-stats readonly">
            <div class="shift-stat-card">
              <div class="shift-stat-icon bg-blue"><i class="fas fa-wallet"></i></div>
              <div class="shift-stat-info">
                <span class="shift-stat-label">Số dư đầu ca</span>
                <span class="shift-stat-value">${formatCurrency(openingBalance)}</span>
              </div>
            </div>
            <div class="shift-stat-card">
              <div class="shift-stat-icon bg-green"><i class="fas fa-money-bill-wave"></i></div>
              <div class="shift-stat-info">
                <span class="shift-stat-label">Tiền mặt<br><small>(${cashInvoiceCount} HĐ)</small></span>
                <span class="shift-stat-value">${formatCurrency(cashRevenue)}</span>
              </div>
            </div>
            <div class="shift-stat-card">
              <div class="shift-stat-icon bg-indigo"><i class="fas fa-university"></i></div>
              <div class="shift-stat-info">
                <span class="shift-stat-label">Chuyển khoản<br><small>(${transferInvoiceCount} HĐ)</small></span>
                <span class="shift-stat-value">${formatCurrency(transferRevenue)}</span>
              </div>
            </div>
            <div class="shift-stat-card">
              <div class="shift-stat-icon bg-cyan"><i class="fas fa-arrow-down"></i></div>
              <div class="shift-stat-info">
                <span class="shift-stat-label">Tổng thu</span>
                <span class="shift-stat-value">${formatCurrency(totalReceipts)}</span>
              </div>
            </div>
            <div class="shift-stat-card">
              <div class="shift-stat-icon bg-red"><i class="fas fa-arrow-up"></i></div>
              <div class="shift-stat-info">
                <span class="shift-stat-label">Tổng chi</span>
                <span class="shift-stat-value">${formatCurrency(totalPayments)}</span>
              </div>
            </div>
            <div class="shift-stat-card shift-stat-highlight">
              <div class="shift-stat-icon bg-purple"><i class="fas fa-calculator"></i></div>
              <div class="shift-stat-info">
                <span class="shift-stat-label">Số dư TM dự kiến</span>
                <span class="shift-stat-value">${formatCurrency(expectedBalance)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
  }

  function renderShiftHistory() {
    if (!shiftHistory || shiftHistory.length === 0) {
      return `
        <div class="shift-empty-state">
          <i class="fas fa-calendar-times"></i>
          <p>Không có lịch sử ca trong khoảng thời gian này</p>
        </div>
      `;
    }

    // Check if user has shift.delete_history permission
    const canDeleteShift = checkPermission('shift', 'delete_history');

    return shiftHistory
      .map(
        (shift) => `
      <div class="shift-history-item ${shift.status}" data-shift-id="${shift.id}">
        <div class="shift-history-header">
          <div class="shift-history-user">
            <i class="fas fa-user-circle"></i>
            <span>${escapeHtml(shift.staff_name || 'N/A')}</span>
          </div>
          <div class="shift-history-status">
            <span class="status-badge ${shift.status}">
              ${getStatusLabel(shift.status)}
            </span>
          </div>
        </div>
        <div class="shift-history-details">
          <div class="shift-summary-row">
            <div class="shift-time-info">
              <span><i class="fas fa-play"></i> ${formatDateTime(shift.start_time)}</span>
              ${
                shift.end_time
                  ? `<span><i class="fas fa-stop"></i> ${formatDateTime(shift.end_time)}</span>`
                  : ''
              }
            </div>
            <div class="shift-balance-info">
              <span class="label">Đầu ca:</span>
              <span class="value">${formatCurrency(shift.opening_balance || 0)}</span>
            </div>
          </div>
          <div class="shift-summary-row shift-stats-row">
            <div class="summary-item">
              <span class="label">TM (${shift.cash_invoice_count || 0}):</span>
              <span class="value text-green">${formatCurrency(shift.cash_revenue || 0)}</span>
            </div>
            <div class="summary-item">
              <span class="label">CK (${shift.transfer_invoice_count || 0}):</span>
              <span class="value text-blue">${formatCurrency(shift.transfer_revenue || 0)}</span>
            </div>
            <div class="summary-item">
              <span class="label">Thu/Chi:</span>
              <span class="value">${formatCurrency(
                (shift.total_receipts || 0) - (shift.total_payments || 0)
              )}</span>
            </div>
            <div class="summary-item total">
              <span class="label">Số dư TM:</span>
              <span class="value">${formatCurrency(
                (parseFloat(shift.opening_balance) || 0) +
                  (parseFloat(shift.cash_revenue) || 0) +
                  (parseFloat(shift.total_receipts) || 0) -
                  (parseFloat(shift.total_payments) || 0)
              )}</span>
            </div>
          </div>
          ${
            shift.handover_to
              ? `
            <div class="shift-handover-info">
              <i class="fas fa-handshake"></i>
              Bàn giao: <strong>${escapeHtml(shift.handover_to_name || shift.handover_to)}</strong>
              (${shift.handover_method === HANDOVER_METHODS.CASH ? 'TM' : 'CK'})
            </div>
          `
              : ''
          }
        </div>
        <div class="shift-history-actions">
          <button class="shift-btn-link view-shift-detail" data-shift-id="${shift.id}">
            <i class="fas fa-eye"></i> Xem chi tiết
          </button>
          ${
            shift.status === 'closed'
              ? `
            <button class="shift-btn-link copy-shift-report" data-shift-id="${shift.id}">
              <i class="fas fa-paper-plane"></i> Gửi báo cáo
            </button>
          `
              : ''
          }
          ${
            canDeleteShift
              ? `
            <button class="shift-btn-icon delete-shift" data-shift-id="${shift.id}" title="Xóa lịch sử ca">
              <i class="fas fa-trash"></i>
            </button>
          `
              : ''
          }
        </div>
      </div>
    `
      )
      .join('');
  }

  // ============================================
  // Event Listeners
  // ============================================
  function attachShiftEventListeners() {
    // Open Shift Button
    const openShiftBtn = document.getElementById('openShiftBtn');
    if (openShiftBtn) {
      openShiftBtn.addEventListener('click', showOpenShiftModal);
    }

    // Close Shift Button
    const closeShiftBtn = document.getElementById('closeShiftBtn');
    if (closeShiftBtn) {
      closeShiftBtn.addEventListener('click', showCloseShiftModal);
    }

    // Add Receipt Button
    const addReceiptBtn = document.getElementById('addReceiptBtn');
    if (addReceiptBtn) {
      addReceiptBtn.addEventListener('click', () =>
        showTransactionModal(TRANSACTION_TYPES.RECEIPT)
      );
    }

    // Add Payment Button
    const addPaymentBtn = document.getElementById('addPaymentBtn');
    if (addPaymentBtn) {
      addPaymentBtn.addEventListener('click', () =>
        showTransactionModal(TRANSACTION_TYPES.PAYMENT)
      );
    }

    // History Filter
    const historyFilter = document.getElementById('shiftHistoryFilter');
    if (historyFilter) {
      historyFilter.addEventListener('change', async (e) => {
        shiftFilter = e.target.value;
        // Show page loader while loading history
        if (window.showPageLoader) {
          window.showPageLoader({ text: 'Đang tải lịch sử ca...', subtitle: 'Vui lòng đợi' });
        }
        try {
          await refreshShiftData();
        } finally {
          if (window.hidePageLoader) {
            window.hidePageLoader();
          }
        }
      });
    }

    // Delete Transaction Buttons
    document.querySelectorAll('.delete-transaction').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        const transactionId = e.currentTarget.dataset.id;
        confirmDeleteTransaction(transactionId);
      });
    });

    // View Shift Detail
    document.querySelectorAll('.view-shift-detail').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        const shiftId = e.currentTarget.dataset.shiftId;
        showShiftDetailModal(shiftId);
      });
    });

    // Delete Shift
    document.querySelectorAll('.delete-shift').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        const shiftId = e.currentTarget.dataset.shiftId;
        confirmDeleteShift(shiftId);
      });
    });

    // Copy Shift Report (for closed shifts in history)
    document.querySelectorAll('.copy-shift-report').forEach((btn) => {
      btn.addEventListener('click', async (e) => {
        const shiftId = e.currentTarget.dataset.shiftId;
        await copyHistoryShiftReport(shiftId);
      });
    });
  }

  // ============================================
  // Modal Functions
  // ============================================

  // Biến lưu doanh số trước khi mở ca
  let preOpenSalesData = null;

  async function showOpenShiftModal() {
    // Chỉ gọi API nếu chưa có dữ liệu prefetch
    if (!preOpenSalesData) {
      // Hiển thị loading
      if (window.showPageLoader) {
        window.showPageLoader({ text: 'Đang kiểm tra doanh số...', subtitle: 'Vui lòng đợi' });
      }

      try {
        // Lấy doanh số trước khi mở ca
        preOpenSalesData = await fetchShiftAPI('pre-open-sales');
      } catch (error) {
        preOpenSalesData = null;
      } finally {
        if (window.hidePageLoader) {
          window.hidePageLoader();
        }
      }
    }

    const hasPreOpenSales = preOpenSalesData?.has_pre_open_sales || false;
    const cashRevenue = preOpenSalesData?.cash_revenue || 0;
    const transferRevenue = preOpenSalesData?.transfer_revenue || 0;
    const cashCount = preOpenSalesData?.cash_invoice_count || 0;
    const transferCount = preOpenSalesData?.transfer_invoice_count || 0;
    const totalRevenue = preOpenSalesData?.total_revenue || 0;
    const startTime = preOpenSalesData?.start_time || '';
    const lastClosedShift = preOpenSalesData?.last_closed_shift || null;
    const lastShiftTransferBalance = preOpenSalesData?.last_shift_transfer_balance || 0;

    // Kiểm tra nếu là ca thứ 2 trong ngày (có ca trước đã đóng)
    const isSecondShiftOfDay = lastClosedShift !== null;

    // Tạo HTML cho phần doanh số trước đó
    const preOpenSalesHtml = hasPreOpenSales
      ? `
      <div class="pre-open-sales-section">
        <div class="pre-open-sales-alert">
          <i class="fas fa-info-circle"></i>
          <div>
            <strong>Có doanh số phát sinh trước khi mở ca!</strong>
            <p>Từ ${formatDateTime(startTime)} đến hiện tại</p>
          </div>
        </div>
        <div class="pre-open-sales-summary">
          <div class="sales-row">
            <span><i class="fas fa-money-bill-wave"></i> Tiền mặt (${cashCount} HĐ):</span>
            <span class="text-green">${formatCurrency(cashRevenue)}</span>
          </div>
          <div class="sales-row">
            <span><i class="fas fa-credit-card"></i> Chuyển khoản (${transferCount} HĐ):</span>
            <span class="text-blue">${formatCurrency(transferRevenue)}</span>
          </div>
          <div class="sales-row total">
            <span><strong>Tổng doanh số:</strong></span>
            <span><strong>${formatCurrency(totalRevenue)}</strong></span>
          </div>
        </div>
        <div class="shift-form-group">
          <label class="shift-checkbox-label">
            <input type="checkbox" id="includePreOpenSales" checked>
            <span>Gộp doanh số trước đó vào ca này</span>
          </label>
          <small class="form-hint">
            Nếu chọn, doanh số trên sẽ được tính vào ca của bạn.
            Số tiền mặt này cần có trong két khi nhận ca.
          </small>
        </div>
      </div>
    `
      : '';

    // Tạo hint cho số dư đầu ca
    let openingBalanceHint = 'Nhập số tiền mặt có trong két đầu ca';
    if (hasPreOpenSales && cashRevenue > 0) {
      openingBalanceHint = `Số tiền mặt thực tế trong két. <strong>Lưu ý:</strong> Nếu gộp doanh số, cần bao gồm ${formatCurrency(
        cashRevenue
      )} tiền mặt từ doanh số trước đó.`;
    } else if (hasPreOpenSales) {
      openingBalanceHint =
        'Số tiền mặt thực tế trong két (doanh số trước đó là chuyển khoản, không ảnh hưởng số dư két)';
    }

    // HTML cho trường số dư CK đầu ca (chỉ hiển thị khi là ca thứ 2 trong ngày)
    const transferBalanceHtml = isSecondShiftOfDay
      ? `
      <div class="shift-form-group">
        <label for="openingTransferBalance">Số dư CK đầu ca (VNĐ)</label>
        <input type="text" id="openingTransferBalance" class="shift-input currency-input"
               placeholder="0" autocomplete="off" value="${
                 lastShiftTransferBalance > 0
                   ? formatCurrency(lastShiftTransferBalance).replace(/[^\d]/g, '')
                   : ''
               }">
        <small class="form-hint">
          Số dư chuyển khoản dồn từ ca trước${
            lastShiftTransferBalance > 0
              ? ` (gợi ý: <strong>${formatCurrency(lastShiftTransferBalance)}</strong>)`
              : ''
          }
        </small>
      </div>
    `
      : '';

    const modalHtml = `
      <div id="openShiftModal" class="shift-modal">
        <div class="shift-modal-overlay"></div>
        <div class="shift-modal-content ${hasPreOpenSales ? 'shift-modal-lg' : ''}">
          <div class="shift-modal-header">
            <h3><i class="fas fa-play-circle"></i> Mở ca làm việc</h3>
            <button class="shift-modal-close">&times;</button>
          </div>
          <div class="shift-modal-body">
            ${preOpenSalesHtml}
            <form id="openShiftForm">
              <div class="shift-form-group">
                <label for="openingBalance">Số dư TM đầu ca (VNĐ) <span class="required">*</span></label>
                <input type="text" id="openingBalance" class="shift-input currency-input"
                       placeholder="0" required autocomplete="off" value="">
                <small class="form-hint">${openingBalanceHint}</small>
              </div>
              ${transferBalanceHtml}
              <div class="shift-form-group">
                <label for="openingNote">Ghi chú</label>
                <textarea id="openingNote" class="shift-textarea" rows="2"
                          placeholder="Ghi chú thêm nếu có..."></textarea>
              </div>
            </form>
          </div>
          <div class="shift-modal-footer">
            <button type="button" class="shift-btn shift-btn-secondary" id="cancelOpenShift">Hủy</button>
            <button type="button" class="shift-btn shift-btn-primary" id="confirmOpenShift">
              <i class="fas fa-check"></i> Xác nhận mở ca
            </button>
          </div>
        </div>
      </div>
    `;

    document.body.insertAdjacentHTML('beforeend', modalHtml);
    attachModalListeners('openShiftModal', handleOpenShift);
    setupCurrencyInput(document.getElementById('openingBalance'));

    // Setup currency input cho số dư CK nếu có
    const transferBalanceInput = document.getElementById('openingTransferBalance');
    if (transferBalanceInput) {
      setupCurrencyInput(transferBalanceInput);
    }

    document.getElementById('openingBalance').focus();
  }

  function showCloseShiftModal() {
    // Calculate expected balance
    const totalReceipts = cashTransactions
      .filter((t) => t.type === TRANSACTION_TYPES.RECEIPT)
      .reduce((sum, t) => sum + (parseFloat(t.amount) || 0), 0);

    const totalPayments = cashTransactions
      .filter((t) => t.type === TRANSACTION_TYPES.PAYMENT)
      .reduce((sum, t) => sum + (parseFloat(t.amount) || 0), 0);

    const openingBalance = parseFloat(currentShift.opening_balance) || 0;
    const cashRevenue = salesData?.cash_revenue || 0;
    const expectedBalance = openingBalance + cashRevenue + totalReceipts - totalPayments;
    const transferRevenue = salesData?.transfer_revenue || 0;
    const totalRevenue = cashRevenue + transferRevenue;

    const modalHtml = `
      <div id="closeShiftModal" class="shift-modal">
        <div class="shift-modal-overlay"></div>
        <div class="shift-modal-content shift-modal-lg">
          <div class="shift-modal-header">
            <h3><i class="fas fa-stop-circle"></i> Kết ca làm việc</h3>
            <button class="shift-modal-close">&times;</button>
          </div>
          <div class="shift-modal-body">
            <!-- Shift Summary -->
            <div class="close-shift-summary">
              <h4><i class="fas fa-chart-pie"></i> Tổng kết ca</h4>
              <div class="summary-grid">
                <div class="summary-row">
                  <span>Số dư đầu ca:</span>
                  <span>${formatCurrency(openingBalance)}</span>
                </div>
                <div class="summary-row">
                  <span>Doanh số tiền mặt:</span>
                  <span class="text-green">+${formatCurrency(cashRevenue)}</span>
                </div>
                <div class="summary-row">
                  <span>Doanh số chuyển khoản:</span>
                  <span class="text-blue">+${formatCurrency(transferRevenue)}</span>
                </div>
                <div class="summary-row">
                  <span>Tổng phiếu thu:</span>
                  <span class="text-green">+${formatCurrency(totalReceipts)}</span>
                </div>
                <div class="summary-row">
                  <span>Tổng phiếu chi:</span>
                  <span class="text-red">-${formatCurrency(totalPayments)}</span>
                </div>
                <div class="summary-row summary-total">
                  <span><strong>Số dư két dự kiến:</strong></span>
                  <span><strong>${formatCurrency(expectedBalance)}</strong></span>
                </div>
              </div>

              <!-- Selected Summary Pills - will be updated dynamically -->
              <div class="selected-summary" id="selectedSummary" style="display: none;"></div>
            </div>

            <form id="closeShiftForm">
              <!-- Step 1: Actual Balance -->
              <div class="shift-form-group">
                <label for="actualBalance">Số tiền thực tế trong két (VNĐ) <span class="required">*</span></label>
                <input type="text" id="actualBalance" class="shift-input currency-input"
                       placeholder="0" required autocomplete="off">
                <small class="form-hint">Đếm số tiền mặt thực tế trong két</small>
              </div>

              <div class="shift-form-group" id="balanceDifferenceGroup" style="display: none;">
                <div class="balance-difference-alert">
                  <i class="fas fa-exclamation-triangle"></i>
                  <span id="balanceDifferenceText"></span>
                </div>
                <label for="differenceReason">Lý do chênh lệch <span class="required">*</span></label>
                <textarea id="differenceReason" class="shift-textarea" rows="2"
                          placeholder="Giải thích lý do chênh lệch..."></textarea>
              </div>

              <div class="step-divider"><span>Bàn giao ca</span></div>

              <!-- Step 2: Handover Type Selection -->
              <div class="handover-type-selector">
                <div class="handover-type-pill" data-type="self" id="pillSelfKeep">
                  <i class="fas fa-wallet"></i>
                  <div class="pill-text">
                    <span class="pill-title">Tự giữ tiền</span>
                    <span class="pill-subtitle">Không bàn giao</span>
                  </div>
                </div>
                <div class="handover-type-pill" data-type="handover" id="pillHandover">
                  <i class="fas fa-people-arrows"></i>
                  <div class="pill-text">
                    <span class="pill-title">Bàn giao</span>
                    <span class="pill-subtitle">Cho người khác</span>
                  </div>
                </div>
              </div>

              <!-- Step 3: Handover Person (hidden by default) -->
              <div class="close-shift-step" id="stepHandoverPerson">
                <div class="shift-form-group">
                  <label for="handoverToSelect">Chọn người nhận bàn giao <span class="required">*</span></label>
                  <div class="handover-person-input">
                    <select id="handoverToSelect" class="shift-input">
                      <option value="">-- Chọn nhân viên --</option>
                      <option value="other">Người khác (nhập tên)</option>
                    </select>
                    <i class="fas fa-user input-icon"></i>
                  </div>
                </div>
              </div>

              <!-- Step 3b: Custom Name (hidden by default, shows when "Người khác" selected) -->
              <div class="close-shift-step" id="stepHandoverOther">
                <div class="shift-form-group">
                  <label for="handoverOtherInput">Tên người nhận <span class="required">*</span></label>
                  <div class="handover-person-input">
                    <input type="text" id="handoverOtherInput" class="shift-input"
                           placeholder="Nhập tên người nhận..." autocomplete="off">
                    <i class="fas fa-edit input-icon"></i>
                  </div>
                  <small class="form-hint">Nhập tên người sẽ nhận bàn giao ca</small>
                </div>
              </div>

              <!-- Step 4: Handover Method (hidden by default) -->
              <div class="close-shift-step" id="stepHandoverMethod">
                <div class="shift-form-group">
                  <label>Phương thức bàn giao <span class="required">*</span></label>
                  <div class="handover-method-cards">
                    <label class="handover-method-card" data-method="cash">
                      <input type="radio" name="handoverMethod" value="cash">
                      <i class="fas fa-money-bill-wave"></i>
                      <span class="method-label">Tiền mặt</span>
                    </label>
                    <label class="handover-method-card" data-method="transfer">
                      <input type="radio" name="handoverMethod" value="transfer">
                      <i class="fas fa-university"></i>
                      <span class="method-label">Chuyển khoản</span>
                    </label>
                  </div>
                </div>
              </div>

              <!-- Step 5: Closing Note (always visible) -->
              <div class="shift-form-group">
                <label for="closingNote">Ghi chú kết ca</label>
                <textarea id="closingNote" class="shift-textarea" rows="2"
                          placeholder="Ghi chú thêm nếu có..."></textarea>
              </div>
            </form>
          </div>
          <div class="shift-modal-footer">
            <button type="button" class="shift-btn shift-btn-secondary" id="cancelCloseShift">Hủy</button>
            <button type="button" class="shift-btn shift-btn-danger" id="confirmCloseShift" disabled>
              <i class="fas fa-check"></i> Xác nhận kết ca
            </button>
          </div>
        </div>
      </div>
    `;

    document.body.insertAdjacentHTML('beforeend', modalHtml);

    // State
    let selectedHandoverType = null;
    let selectedMethod = null;
    let selectedHandoverUserId = null;

    // Elements
    const pillSelfKeep = document.getElementById('pillSelfKeep');
    const pillHandover = document.getElementById('pillHandover');
    const stepHandoverPerson = document.getElementById('stepHandoverPerson');
    const stepHandoverMethod = document.getElementById('stepHandoverMethod');
    const stepHandoverOther = document.getElementById('stepHandoverOther');
    const handoverToSelect = document.getElementById('handoverToSelect');
    const handoverOtherInput = document.getElementById('handoverOtherInput');
    const methodCards = document.querySelectorAll('.handover-method-card');
    const confirmBtn = document.getElementById('confirmCloseShift');
    const selectedSummary = document.getElementById('selectedSummary');
    const actualBalanceInput = document.getElementById('actualBalance');

    // Load danh sách nhân viên vào select - ưu tiên dùng cache có sẵn
    async function loadStaffOptions() {
      if (!handoverToSelect) return;

      try {
        let staffData = [];

        // 1. Thử dùng cached data từ app-tho.js (window.getStaffData)
        if (typeof window.getStaffData === 'function') {
          try {
            staffData = await window.getStaffData();
          } catch (e) {
            // Silent fail
          }
        }

        // 2. Fallback: Đọc từ localStorage
        if (!staffData || staffData.length === 0) {
          const EXPIRY_TIME = 60 * 60 * 1000; // 1 hour
          const stored = localStorage.getItem('staffList');

          if (stored) {
            try {
              const parsed = JSON.parse(stored);
              if (parsed.data && parsed.timestamp && Date.now() - parsed.timestamp <= EXPIRY_TIME) {
                staffData = parsed.data;
              }
            } catch (e) {
              // Silent fail
            }
          }
        }

        // 3. Fallback: Fetch từ API
        if (!staffData || staffData.length === 0) {
          // restUrl đã có /wp-json/vg/v1/ nên chỉ cần thêm endpoint
          const apiUrl = `${window.checkinData?.restUrl || '/wp-json/vg/v1/'}staff`;

          const response = await fetch(apiUrl, {
            headers: {
              'X-WP-Nonce': window.checkinData?.nonce || '',
            },
          });

          if (response.ok) {
            const result = await response.json();
            if (result.success && result.data) {
              staffData = result.data;
              // Lưu vào localStorage cho lần sau
              localStorage.setItem(
                'staffList',
                JSON.stringify({
                  data: staffData,
                  timestamp: Date.now(),
                })
              );
            }
          }
        }

        if (!staffData || staffData.length === 0) return;

        // Lấy current user để loại bỏ khỏi danh sách
        const currentUserId = window.checkinData?.currentUser?.user_id;

        // Kiểm tra multi-branch mode
        const multiBranchEnabled = window.checkinData?.branchModeEnabled === '1';
        const currentBranchId = parseInt(window.branchHelper?.getCurrentBranchId()) || 0;

        // Lọc staff theo branch nếu multi-branch enabled
        let filteredStaff = staffData;
        if (multiBranchEnabled && currentBranchId > 0) {
          filteredStaff = staffData.filter((staff) => {
            // API staff trả về user_branch (array) hoặc branch_id (số)
            const staffBranches = staff.user_branch || [];
            const staffBranchId = parseInt(staff.branch_id) || 0;

            // Nếu user_branch là array, check xem currentBranchId có trong đó không
            // Convert tất cả về number để so sánh chính xác
            if (Array.isArray(staffBranches) && staffBranches.length > 0) {
              const branchIds = staffBranches.map((b) => parseInt(b) || 0);
              return branchIds.includes(currentBranchId);
            }

            // Fallback: check branch_id
            return staffBranchId === 0 || staffBranchId === currentBranchId;
          });
        }
        // Khi multi-branch disabled: không filter theo branch, lấy tất cả staff

        // Lọc bỏ thợ không còn làm việc (nghỉ, đã nghỉ việc/lưu trữ, đã xoá)
        const NGUNG_LAM_VIEC = ['OFF', 'ARCHIVED', 'DELETED'];
        filteredStaff = filteredStaff.filter(
          (staff) => !NGUNG_LAM_VIEC.includes(String(staff.status || '').toUpperCase())
        );

        // Xóa các option cũ (giữ lại default và other)
        const existingOptions = handoverToSelect.querySelectorAll(
          'option:not([value=""]):not([value="other"])'
        );
        existingOptions.forEach((opt) => opt.remove());

        // Tìm option "Người khác" để insert trước nó
        const otherOption = handoverToSelect.querySelector('option[value="other"]');

        filteredStaff.forEach((staff) => {
          // Bỏ qua user hiện tại
          if (staff.user_id && staff.user_id == currentUserId) return;

          const option = document.createElement('option');
          option.value = staff.user_id || '';
          option.textContent = staff.staff_name || staff.display_name || 'N/A';
          option.dataset.name = staff.staff_name || staff.display_name || '';

          // Insert trước option "Người khác"
          if (otherOption) {
            handoverToSelect.insertBefore(option, otherOption);
          } else {
            handoverToSelect.appendChild(option);
          }
        });
      } catch (error) {
        console.error('[Shift] Error loading staff for handover:', error);
      }
    }

    // Load staff khi mở modal
    loadStaffOptions();

    // Update selected summary pills
    function updateSummaryPills() {
      const pills = [];

      if (selectedHandoverType === 'self') {
        pills.push('<span class="summary-pill"><i class="fas fa-wallet"></i> Tự giữ tiền</span>');
      } else if (selectedHandoverType === 'handover') {
        let personName = '';
        if (handoverToSelect.value === 'other') {
          personName = handoverOtherInput.value.trim();
        } else if (handoverToSelect.value) {
          personName =
            handoverToSelect.options[handoverToSelect.selectedIndex]?.dataset?.name || '';
        }
        if (personName) {
          pills.push(
            `<span class="summary-pill"><i class="fas fa-user"></i> Bàn giao: ${escapeHtml(
              personName
            )}</span>`
          );
        }
        if (selectedMethod) {
          const methodLabel = selectedMethod === 'cash' ? 'Tiền mặt' : 'Chuyển khoản';
          const methodIcon = selectedMethod === 'cash' ? 'fa-money-bill-wave' : 'fa-university';
          pills.push(
            `<span class="summary-pill"><i class="fas ${methodIcon}"></i> ${methodLabel}</span>`
          );
        }
      }

      if (pills.length > 0) {
        selectedSummary.innerHTML = pills.join('');
        selectedSummary.style.display = 'flex';
      } else {
        selectedSummary.style.display = 'none';
      }
    }

    // Validate and enable/disable confirm button
    function validateForm() {
      let isValid = false;

      // Check actual balance
      const actualBalance = parseCurrency(actualBalanceInput.value);
      if (actualBalance < 0) {
        confirmBtn.disabled = true;
        return;
      }

      // Check difference reason if needed
      const difference = actualBalance - expectedBalance;
      if (difference !== 0) {
        const differenceReason = document.getElementById('differenceReason')?.value.trim();
        if (!differenceReason) {
          confirmBtn.disabled = true;
          return;
        }
      }

      if (selectedHandoverType === 'self') {
        isValid = true;
      } else if (selectedHandoverType === 'handover') {
        const selectedValue = handoverToSelect.value;
        if (selectedValue === 'other') {
          // Need custom name
          const customName = handoverOtherInput.value.trim();
          isValid = customName && selectedMethod;
        } else if (selectedValue) {
          // Staff selected from dropdown
          isValid = !!selectedMethod;
        } else {
          isValid = false;
        }
      }

      confirmBtn.disabled = !isValid;
    }

    // Handover type selection
    function selectHandoverType(type) {
      selectedHandoverType = type;
      selectedMethod = null;

      // Update pill states
      pillSelfKeep.classList.toggle('active', type === 'self');
      pillHandover.classList.toggle('active', type === 'handover');

      // Reset method cards
      methodCards.forEach((card) => card.classList.remove('active'));
      document.querySelectorAll('input[name="handoverMethod"]').forEach((r) => (r.checked = false));

      if (type === 'self') {
        // Hide all steps
        stepHandoverPerson.classList.remove('visible');
        stepHandoverMethod.classList.remove('visible');
        stepHandoverOther.classList.remove('visible');
        handoverToSelect.value = '';
        handoverOtherInput.value = '';
      } else if (type === 'handover') {
        // Show person select
        stepHandoverPerson.classList.add('visible');
        stepHandoverMethod.classList.remove('visible');
        stepHandoverOther.classList.remove('visible');
        setTimeout(() => handoverToSelect.focus(), 300);
      }

      updateSummaryPills();
      validateForm();
    }

    // Event listeners for handover type pills
    pillSelfKeep.addEventListener('click', () => selectHandoverType('self'));
    pillHandover.addEventListener('click', () => selectHandoverType('handover'));

    // Person select change handler
    handoverToSelect.addEventListener('change', () => {
      const selectedValue = handoverToSelect.value;
      if (selectedValue === 'other') {
        // Show custom name input, hide method until name entered
        stepHandoverOther.classList.add('visible');
        stepHandoverMethod.classList.remove('visible');
        selectedMethod = null;
        methodCards.forEach((card) => card.classList.remove('active'));
        setTimeout(() => handoverOtherInput.focus(), 100);
      } else if (selectedValue) {
        // Staff selected, show method step
        stepHandoverOther.classList.remove('visible');
        stepHandoverMethod.classList.add('visible');
      } else {
        // Nothing selected
        stepHandoverOther.classList.remove('visible');
        stepHandoverMethod.classList.remove('visible');
        selectedMethod = null;
        methodCards.forEach((card) => card.classList.remove('active'));
      }
      updateSummaryPills();
      validateForm();
    });

    // Custom name input handler
    handoverOtherInput.addEventListener('input', () => {
      const name = handoverOtherInput.value.trim();
      if (name.length >= 2) {
        stepHandoverMethod.classList.add('visible');
      } else {
        stepHandoverMethod.classList.remove('visible');
        selectedMethod = null;
        methodCards.forEach((card) => card.classList.remove('active'));
      }
      updateSummaryPills();
      validateForm();
    });

    // Method card selection
    methodCards.forEach((card) => {
      card.addEventListener('click', () => {
        selectedMethod = card.dataset.method;
        methodCards.forEach((c) => c.classList.remove('active'));
        card.classList.add('active');
        card.querySelector('input[type="radio"]').checked = true;
        updateSummaryPills();
        validateForm();
      });
    });

    // Setup currency input
    setupCurrencyInput(actualBalanceInput);
    actualBalanceInput.focus();

    // Listen for balance changes to show difference
    actualBalanceInput.addEventListener('input', () => {
      const actualValue = parseCurrency(actualBalanceInput.value);
      const difference = actualValue - expectedBalance;
      const differenceGroup = document.getElementById('balanceDifferenceGroup');
      const differenceText = document.getElementById('balanceDifferenceText');

      if (difference !== 0 && actualValue > 0) {
        differenceGroup.style.display = 'block';
        if (difference > 0) {
          differenceText.innerHTML = `<span class="text-green">Thừa ${formatCurrency(
            difference
          )}</span>`;
        } else {
          differenceText.innerHTML = `<span class="text-red">Thiếu ${formatCurrency(
            Math.abs(difference)
          )}</span>`;
        }
      } else {
        differenceGroup.style.display = 'none';
      }
      validateForm();
    });

    // Difference reason input
    document.getElementById('differenceReason')?.addEventListener('input', validateForm);

    // Attach modal listeners with custom handler
    attachModalListeners('closeShiftModal', handleCloseShift);
  }

  function showTransactionModal(type) {
    const isReceipt = type === TRANSACTION_TYPES.RECEIPT;
    const title = isReceipt ? 'Tạo phiếu thu' : 'Tạo phiếu chi';
    const icon = isReceipt ? 'fa-arrow-down' : 'fa-arrow-up';
    const btnClass = isReceipt ? 'shift-btn-success' : 'shift-btn-warning';

    const commonReasons = isReceipt
      ? [
          'Khách trả thêm',
          'Thu tiền đặt cọc',
          'Thu tiền từ dịch vụ khác',
          'Thu nợ khách hàng',
          'Khác',
        ]
      : [
          'Chi tiền tips',
          'Chi mua nguyên liệu',
          'Chi phí giao hàng',
          'Chi trả lương tạm ứng',
          'Trả lại tiền khách',
          'Chi phí khác',
        ];

    const modalHtml = `
      <div id="transactionModal" class="shift-modal">
        <div class="shift-modal-overlay"></div>
        <div class="shift-modal-content">
          <div class="shift-modal-header">
            <h3><i class="fas ${icon}"></i> ${title}</h3>
            <button class="shift-modal-close">&times;</button>
          </div>
          <div class="shift-modal-body">
            <form id="transactionForm">
              <input type="hidden" id="shiftTransactionType" value="${type}">

              <div class="shift-form-group">
                <label for="transactionAmount">Số tiền (VNĐ) <span class="required">*</span></label>
                <input type="text" id="transactionAmount" class="shift-input currency-input"
                       placeholder="0" required autocomplete="off">
              </div>

              <div class="shift-form-group">
                <label for="transactionReason">Lý do <span class="required">*</span></label>
                <select id="transactionReasonSelect" class="shift-select">
                  <option value="">-- Chọn lý do --</option>
                  ${commonReasons.map((r) => `<option value="${r}">${r}</option>`).join('')}
                </select>
              </div>

              <div class="shift-form-group" id="customReasonGroup" style="display: none;">
                <label for="transactionCustomReason">Lý do cụ thể</label>
                <input type="text" id="transactionCustomReason" class="shift-input"
                       placeholder="Nhập lý do cụ thể...">
              </div>

              <div class="shift-form-group">
                <label for="transactionNote">Ghi chú thêm</label>
                <textarea id="transactionNote" class="shift-textarea" rows="2"
                          placeholder="Ghi chú thêm nếu có..."></textarea>
              </div>
            </form>
          </div>
          <div class="shift-modal-footer">
            <button type="button" class="shift-btn shift-btn-secondary" id="cancelTransaction">Hủy</button>
            <button type="button" class="shift-btn ${btnClass}" id="confirmTransaction">
              <i class="fas fa-check"></i> Xác nhận
            </button>
          </div>
        </div>
      </div>
    `;

    document.body.insertAdjacentHTML('beforeend', modalHtml);
    attachModalListeners('transactionModal', handleCreateTransaction);

    const amountInput = document.getElementById('transactionAmount');
    setupCurrencyInput(amountInput);
    amountInput.focus();

    // Show custom reason input when "Khác" selected
    const reasonSelect = document.getElementById('transactionReasonSelect');
    const customReasonGroup = document.getElementById('customReasonGroup');
    reasonSelect.addEventListener('change', () => {
      if (reasonSelect.value === 'Khác' || reasonSelect.value === 'Chi phí khác') {
        customReasonGroup.style.display = 'block';
      } else {
        customReasonGroup.style.display = 'none';
      }
    });
  }

  function showShiftDetailModal(shiftId) {
    const shift = shiftHistory.find((s) => s.id == shiftId);
    if (!shift) return;

    const modalHtml = `
      <div id="shiftDetailModal" class="shift-modal">
        <div class="shift-modal-overlay"></div>
        <div class="shift-modal-content shift-modal-lg">
          <div class="shift-modal-header">
            <h3><i class="fas fa-info-circle"></i> Chi tiết ca làm việc</h3>
            <button class="shift-modal-close">&times;</button>
          </div>
          <div class="shift-modal-body">
            <div class="shift-detail-grid">
              <div class="detail-section">
                <h4>Thông tin chung</h4>
                <div class="detail-row">
                  <span class="label">Nhân viên:</span>
                  <span class="value">${escapeHtml(shift.staff_name || 'N/A')}</span>
                </div>
                <div class="detail-row">
                  <span class="label">Trạng thái:</span>
                  <span class="value"><span class="status-badge ${shift.status}">${getStatusLabel(
      shift.status
    )}</span></span>
                </div>
                <div class="detail-row">
                  <span class="label">Bắt đầu:</span>
                  <span class="value">${formatDateTime(shift.start_time)}</span>
                </div>
                ${
                  shift.end_time
                    ? `
                  <div class="detail-row">
                    <span class="label">Kết thúc:</span>
                    <span class="value">${formatDateTime(shift.end_time)}</span>
                  </div>
                `
                    : ''
                }
              </div>

              <div class="detail-section">
                <h4>Số liệu</h4>
                <div class="detail-row">
                  <span class="label">Số dư đầu ca:</span>
                  <span class="value">${formatCurrency(shift.opening_balance || 0)}</span>
                </div>
                <div class="detail-row">
                  <span class="label">Tiền mặt (${shift.cash_invoice_count || 0} HĐ):</span>
                  <span class="value text-green">+${formatCurrency(shift.cash_revenue || 0)}</span>
                </div>
                <div class="detail-row">
                  <span class="label">Chuyển khoản (${shift.transfer_invoice_count || 0} HĐ):</span>
                  <span class="value text-blue">+${formatCurrency(
                    shift.transfer_revenue || 0
                  )}</span>
                </div>
                <div class="detail-row">
                  <span class="label">Tổng thu:</span>
                  <span class="value text-green">+${formatCurrency(
                    shift.total_receipts || 0
                  )}</span>
                </div>
                <div class="detail-row">
                  <span class="label">Tổng chi:</span>
                  <span class="value text-red">-${formatCurrency(shift.total_payments || 0)}</span>
                </div>
                <div class="detail-row total">
                  <span class="label">Số dư TM cuối ca:</span>
                  <span class="value">${formatCurrency(
                    (parseFloat(shift.opening_balance) || 0) +
                      (parseFloat(shift.cash_revenue) || 0) +
                      (parseFloat(shift.total_receipts) || 0) -
                      (parseFloat(shift.total_payments) || 0)
                  )}</span>
                </div>
                <div class="detail-row total">
                  <span class="label">Số dư CK cuối ca:</span>
                  <span class="value text-blue">${formatCurrency(
                    (parseFloat(shift.opening_transfer_balance) || 0) +
                      (parseFloat(shift.transfer_revenue) || 0)
                  )}</span>
                </div>
                ${
                  shift.actual_balance
                    ? `
                  <div class="detail-row">
                    <span class="label">Số tiền thực tế:</span>
                    <span class="value">${formatCurrency(shift.actual_balance)}</span>
                  </div>
                  <div class="detail-row">
                    <span class="label">Chênh lệch:</span>
                    <span class="value ${
                      parseFloat(shift.actual_balance) >=
                      (parseFloat(shift.opening_balance) || 0) +
                        (parseFloat(shift.cash_revenue) || 0) +
                        (parseFloat(shift.total_receipts) || 0) -
                        (parseFloat(shift.total_payments) || 0)
                        ? 'text-green'
                        : 'text-red'
                    }">
                      ${formatCurrency(
                        parseFloat(shift.actual_balance) -
                          ((parseFloat(shift.opening_balance) || 0) +
                            (parseFloat(shift.cash_revenue) || 0) +
                            (parseFloat(shift.total_receipts) || 0) -
                            (parseFloat(shift.total_payments) || 0))
                      )}
                    </span>
                  </div>
                `
                    : ''
                }
              </div>

              ${
                shift.handover_to
                  ? `
                <div class="detail-section full-width">
                  <h4>Thông tin bàn giao</h4>
                  <div class="detail-row">
                    <span class="label">Bàn giao cho:</span>
                    <span class="value">${escapeHtml(
                      shift.handover_to_name || shift.handover_to
                    )}</span>
                  </div>
                  <div class="detail-row">
                    <span class="label">Phương thức:</span>
                    <span class="value">${
                      shift.handover_method === HANDOVER_METHODS.CASH ? 'Tiền mặt' : 'Chuyển khoản'
                    }</span>
                  </div>
                </div>
              `
                  : ''
              }

              ${
                shift.note
                  ? `
                <div class="detail-section full-width">
                  <h4>Ghi chú</h4>
                  <p>${escapeHtml(shift.note)}</p>
                </div>
              `
                  : ''
              }
            </div>

            ${
              shift.transactions && shift.transactions.length > 0
                ? `
              <div class="detail-section full-width">
                <h4>Phiếu thu/chi trong ca</h4>
                <table class="transaction-table">
                  <thead>
                    <tr>
                      <th>Thời gian</th>
                      <th>Loại</th>
                      <th>Số tiền</th>
                      <th>Lý do</th>
                    </tr>
                  </thead>
                  <tbody>
                    ${shift.transactions
                      .map(
                        (t) => `
                      <tr class="transaction-row ${t.type}">
                        <td>${formatDateTime(t.created_at)}</td>
                        <td>
                          <span class="transaction-type-badge ${t.type}">
                            ${t.type === TRANSACTION_TYPES.RECEIPT ? 'Thu' : 'Chi'}
                          </span>
                        </td>
                        <td class="transaction-amount ${t.type}">${formatCurrency(t.amount)}</td>
                        <td>${escapeHtml(t.reason || '-')}</td>
                      </tr>
                    `
                      )
                      .join('')}
                  </tbody>
                </table>
              </div>
            `
                : ''
            }
          </div>
          <div class="shift-modal-footer">
            <button type="button" class="shift-btn shift-btn-secondary shift-modal-close-btn">Đóng</button>
            <button type="button" class="shift-btn shift-btn-primary" id="copyShiftReportBtn" data-shift-id="${
              shift.id
            }">
              <i class="fas fa-copy"></i> Gửi báo cáo
            </button>
          </div>
        </div>
      </div>
    `;

    document.body.insertAdjacentHTML('beforeend', modalHtml);

    // Close button
    const modal = document.getElementById('shiftDetailModal');
    modal
      .querySelectorAll('.shift-modal-close, .shift-modal-close-btn, .shift-modal-overlay')
      .forEach((el) => {
        el.addEventListener('click', () => modal.remove());
      });

    // Copy report button - use copyHistoryShiftReport to fetch full data with transactions
    const copyBtn = modal.querySelector('#copyShiftReportBtn');
    if (copyBtn) {
      copyBtn.addEventListener('click', async () => {
        await copyHistoryShiftReport(shift.id);
      });
    }
  }

  /**
   * Generate shift report as text for copying
   */
  function generateShiftReportText(shift) {
    const openingBalance = parseFloat(shift.opening_balance) || 0;
    const cashRevenue = parseFloat(shift.cash_revenue) || 0;
    const transferRevenue = parseFloat(shift.transfer_revenue) || 0;
    const totalReceipts = parseFloat(shift.total_receipts) || 0;
    const totalPayments = parseFloat(shift.total_payments) || 0;
    const endingCashBalance = openingBalance + cashRevenue + totalReceipts - totalPayments;

    const formatMoney = (amount) => {
      return new Intl.NumberFormat('vi-VN').format(amount) + 'đ';
    };

    const formatTime = (dateStr) => {
      if (!dateStr) return '-';
      const date = new Date(dateStr);
      return date.toLocaleString('vi-VN', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });
    };

    let report = `📊 **BÁO CÁO CA LÀM VIỆC**\n`;
    report += `━━━━━━━━━━━━━━━━━━━━━━\n\n`;

    report += `👤 **Nhân viên:** ${shift.staff_name || '-'}\n`;
    report += `🏪 **Chi nhánh:** ${shift.branch_name || '-'}\n`;
    report += `🕐 **Mở ca:** ${formatTime(shift.opened_at || shift.start_time)}\n`;
    if (shift.closed_at || shift.end_time) {
      report += `🕐 **Đóng ca:** ${formatTime(shift.closed_at || shift.end_time)}\n`;
    }
    report += `\n`;

    report += `💰 **SỐ LIỆU:**\n`;
    report += `├ Số dư đầu ca: ${formatMoney(openingBalance)}\n`;
    report += `├ Tiền mặt (${shift.cash_invoice_count || 0} HĐ): +${formatMoney(cashRevenue)}\n`;
    report += `├ Chuyển khoản (${shift.transfer_invoice_count || 0} HĐ): +${formatMoney(
      transferRevenue
    )}\n`;
    report += `├ Tổng thu: +${formatMoney(totalReceipts)}\n`;
    report += `├ Tổng chi: -${formatMoney(totalPayments)}\n`;
    report += `├ **Số dư TM cuối ca:** ${formatMoney(endingCashBalance)}\n`;

    // Số dư CK cuối ca = Số dư CK đầu ca + Doanh số chuyển khoản
    const openingTransferBalance = parseFloat(shift.opening_transfer_balance) || 0;
    const endingTransferBalance = openingTransferBalance + transferRevenue;
    report += `└ **Số dư CK cuối ca:** ${formatMoney(endingTransferBalance)}\n`;

    if (shift.actual_balance) {
      const difference = parseFloat(shift.actual_balance) - endingCashBalance;
      report += `\n📋 **KIỂM TRA:**\n`;
      report += `├ Số tiền thực tế: ${formatMoney(shift.actual_balance)}\n`;
      report += `└ Chênh lệch: ${difference >= 0 ? '+' : ''}${formatMoney(difference)}\n`;
    }

    if (shift.handover_to) {
      report += `\n🤝 **BÀN GIAO:**\n`;
      report += `├ Người bàn giao: ${shift.staff_name || '-'}\n`;
      report += `├ Người nhận: ${shift.handover_to_name || shift.handover_to}\n`;
      report += `└ Phương thức: ${
        shift.handover_method === HANDOVER_METHODS.CASH ? 'Tiền mặt' : 'Chuyển khoản'
      }\n`;
    }

    if (shift.note) {
      report += `\n📝 **Ghi chú:** ${shift.note}\n`;
    }

    // Transaction summary
    if (shift.transactions && shift.transactions.length > 0) {
      report += `\n💳 **GIAO DỊCH THU CHI:**\n`;
      shift.transactions.forEach((t, index) => {
        const prefix = index === shift.transactions.length - 1 ? '└' : '├';
        const typeLabel = t.type === TRANSACTION_TYPES.RECEIPT ? '➕ Thu' : '➖ Chi';
        const noteText = t.note ? ` (${t.note})` : '';
        report += `${prefix} ${typeLabel}: ${formatMoney(t.amount)} - ${
          t.reason || '-'
        }${noteText}\n`;
      });
    }

    report += `\n━━━━━━━━━━━━━━━━━━━━━━`;

    return report;
  }

  /**
   * Copy shift report to clipboard
   */
  async function copyShiftReportToClipboard(shift) {
    try {
      const reportText = generateShiftReportText(shift);
      await navigator.clipboard.writeText(reportText);

      if (typeof toastSuccess === 'function') {
        toastSuccess('Đã sao chép báo cáo vào clipboard!');
      } else if (typeof showSuccess === 'function') {
        showSuccess('Đã sao chép báo cáo vào clipboard!');
      }
    } catch (error) {
      console.error('Failed to copy report:', error);
      if (typeof toastError === 'function') {
        toastError('Không thể sao chép báo cáo');
      } else if (typeof showError === 'function') {
        showError('Không thể sao chép báo cáo');
      }
    }
  }

  /**
   * Copy shift report from history (fetch full data from API)
   */
  async function copyHistoryShiftReport(shiftId) {
    try {
      // Show loading
      if (window.showPageLoader) {
        window.showPageLoader({ text: 'Đang tải dữ liệu...', subtitle: 'Vui lòng đợi' });
      }

      // Fetch full shift details from API - GET /cash-shifts/{id}
      const shift = await fetchShiftAPI(shiftId);

      if (window.hidePageLoader) {
        window.hidePageLoader();
      }

      if (!shift) {
        throw new Error('Không thể tải thông tin ca');
      }

      // Wait a bit for document to regain focus after hiding loader
      await new Promise((resolve) => setTimeout(resolve, 100));

      await copyShiftReportToClipboard(shift);
    } catch (error) {
      if (window.hidePageLoader) {
        window.hidePageLoader();
      }
      console.error('Error copying history shift report:', error);
      if (typeof showError === 'function') {
        showError(error.message || 'Không thể sao chép báo cáo');
      }
    }
  }

  /**
   * Copy current shift report to clipboard (uses realtime salesData and cashTransactions)
   */
  async function copyCurrentShiftReportToClipboard() {
    if (!currentShift) {
      if (typeof showError === 'function') {
        showError('Không có ca nào đang mở');
      }
      return;
    }

    // Build shift object with realtime data
    const openingBalance = parseFloat(currentShift.opening_balance) || 0;
    const cashRevenue = salesData
      ? parseFloat(salesData.cash_revenue) || 0
      : parseFloat(currentShift.cash_revenue) || 0;
    const transferRevenue = salesData
      ? parseFloat(salesData.transfer_revenue) || 0
      : parseFloat(currentShift.transfer_revenue) || 0;
    const cashInvoiceCount = salesData
      ? parseInt(salesData.cash_invoice_count) || 0
      : parseInt(currentShift.cash_invoice_count) || 0;
    const transferInvoiceCount = salesData
      ? parseInt(salesData.transfer_invoice_count) || 0
      : parseInt(currentShift.transfer_invoice_count) || 0;

    // Calculate totals from realtime transactions
    const totalReceipts = cashTransactions
      .filter((t) => t.type === TRANSACTION_TYPES.RECEIPT)
      .reduce((sum, t) => sum + (parseFloat(t.amount) || 0), 0);
    const totalPayments = cashTransactions
      .filter((t) => t.type === TRANSACTION_TYPES.PAYMENT)
      .reduce((sum, t) => sum + (parseFloat(t.amount) || 0), 0);

    // Get branch name from branchHelper using branch_id
    let branchName = currentShift.branch_name || '';
    if (!branchName && currentShift.branch_id && typeof window.branchHelper !== 'undefined') {
      // Try to get branch by ID first
      if (window.branchHelper?.getBranchById) {
        const branch = window.branchHelper.getBranchById(parseInt(currentShift.branch_id));
        if (branch) {
          branchName = branch.branch_name || branch.location_name || '';
        }
      }
      // Fallback to current branch name
      if (!branchName && window.branchHelper?.getCurrentBranchName) {
        branchName = window.branchHelper.getCurrentBranchName() || '';
      }
    }
    branchName = branchName || '-';

    const shiftDataForReport = {
      ...currentShift,
      branch_name: branchName,
      opening_balance: openingBalance,
      opening_transfer_balance: parseFloat(currentShift.opening_transfer_balance) || 0,
      cash_revenue: cashRevenue,
      transfer_revenue: transferRevenue,
      cash_invoice_count: cashInvoiceCount,
      transfer_invoice_count: transferInvoiceCount,
      total_receipts: totalReceipts,
      total_payments: totalPayments,
      transactions: cashTransactions,
    };

    try {
      const reportText = generateShiftReportText(shiftDataForReport);
      await navigator.clipboard.writeText(reportText);

      if (typeof toastSuccess === 'function') {
        toastSuccess('Đã sao chép báo cáo vào clipboard!');
      } else if (typeof showSuccess === 'function') {
        showSuccess('Đã sao chép báo cáo vào clipboard!');
      }
    } catch (error) {
      console.error('Failed to copy report:', error);
      if (typeof toastError === 'function') {
        toastError('Không thể sao chép báo cáo');
      } else if (typeof showError === 'function') {
        showError('Không thể sao chép báo cáo');
      }
    }
  }

  function attachModalListeners(modalId, confirmHandler) {
    const modal = document.getElementById(modalId);
    if (!modal) return;

    // Close buttons
    modal.querySelectorAll('.shift-modal-close, .shift-modal-overlay').forEach((el) => {
      el.addEventListener('click', () => modal.remove());
    });

    // Cancel buttons
    modal.querySelectorAll('[id^="cancel"]').forEach((el) => {
      el.addEventListener('click', () => modal.remove());
    });

    // Confirm buttons - with button loader
    modal.querySelectorAll('[id^="confirm"]').forEach((el) => {
      el.addEventListener('click', async () => {
        // Set button loading state
        if (window.setButtonLoading) {
          window.setButtonLoading(el, 'Đang xử lý...');
        }

        try {
          await confirmHandler();
          modal.remove();
        } catch (error) {
          console.error('Modal action error:', error);
          if (typeof showError === 'function') {
            showError(error.message);
          }
          // Reset button on error
          if (window.resetButtonLoading) {
            window.resetButtonLoading(el);
          }
        }
      });
    });

    // ESC key to close
    const escHandler = (e) => {
      if (e.key === 'Escape') {
        modal.remove();
        document.removeEventListener('keydown', escHandler);
      }
    };
    document.addEventListener('keydown', escHandler);
  }

  // ============================================
  // Action Handlers
  // ============================================
  async function handleOpenShift() {
    const openingBalance = parseCurrency(document.getElementById('openingBalance').value);
    const note = document.getElementById('openingNote').value.trim();
    const includePreOpenSalesCheckbox = document.getElementById('includePreOpenSales');
    const includePreOpenSales = includePreOpenSalesCheckbox
      ? includePreOpenSalesCheckbox.checked
      : false;

    // Lấy số dư CK đầu ca (nếu có)
    const transferBalanceInput = document.getElementById('openingTransferBalance');
    const openingTransferBalance = transferBalanceInput
      ? parseCurrency(transferBalanceInput.value)
      : 0;

    if (openingBalance < 0) {
      throw new Error('Số dư đầu ca không hợp lệ');
    }

    // Show page loader
    if (window.showPageLoader) {
      window.showPageLoader({ text: 'Đang mở ca...', subtitle: 'Vui lòng đợi' });
    }

    try {
      // Thêm branch_id - luôn gửi để backend xử lý
      const branchId = getCurrentBranchId();

      const requestData = {
        opening_balance: openingBalance,
        opening_transfer_balance: openingTransferBalance,
        note: note,
        branch_id: branchId,
        include_pre_open_sales: includePreOpenSales,
        pre_open_start_time:
          includePreOpenSales && preOpenSalesData ? preOpenSalesData.start_time : null,
      };

      const result = await fetchShiftAPI('open', {
        method: 'POST',
        body: JSON.stringify(requestData),
      });

      currentShift = result;
      cashTransactions = [];
      preOpenSalesData = null; // Reset
      saveCachedData();

      if (typeof showSuccess === 'function') {
        const msg = includePreOpenSales
          ? 'Đã mở ca thành công! Doanh số trước đó đã được gộp vào ca.'
          : 'Đã mở ca thành công!';
        showSuccess(msg);
      }

      // Load lại dữ liệu ca và doanh số từ server
      await refreshShiftData();
      renderShiftManagement();
    } finally {
      if (window.hidePageLoader) {
        window.hidePageLoader();
      }
    }
  }

  async function handleCloseShift() {
    const actualBalance = parseCurrency(document.getElementById('actualBalance').value);
    const closingNote = document.getElementById('closingNote').value.trim();
    const differenceReason = document.getElementById('differenceReason')?.value.trim() || '';

    // Get handover type from active pill
    const isSelfKeep = document.getElementById('pillSelfKeep').classList.contains('active');
    const handoverToSelect = document.getElementById('handoverToSelect');
    const handoverOtherInput = document.getElementById('handoverOtherInput');
    const handoverMethod =
      document.querySelector('input[name="handoverMethod"]:checked')?.value ||
      HANDOVER_METHODS.CASH;

    // Determine handover recipient
    let handoverToValue = 'self';
    let handoverToName = 'Tự giữ';
    let handoverToId = null;

    if (!isSelfKeep) {
      const selectedValue = handoverToSelect?.value || '';
      if (selectedValue === 'other') {
        // Custom name entered
        handoverToName = handoverOtherInput?.value.trim() || '';
        handoverToValue = 'other';
      } else if (selectedValue) {
        // Staff selected from dropdown
        const selectedOption = handoverToSelect.options[handoverToSelect.selectedIndex];
        handoverToId = selectedValue; // This is the user ID
        handoverToName = selectedOption?.dataset?.name || selectedOption?.textContent || '';
        handoverToValue = selectedValue;
      }
    }

    // Validate
    if (!isSelfKeep && !handoverToName) {
      throw new Error('Vui lòng chọn hoặc nhập tên người nhận bàn giao');
    }

    if (!isSelfKeep && !document.querySelector('input[name="handoverMethod"]:checked')) {
      throw new Error('Vui lòng chọn phương thức bàn giao');
    }

    // Calculate expected to check difference
    const totalReceipts = cashTransactions
      .filter((t) => t.type === TRANSACTION_TYPES.RECEIPT)
      .reduce((sum, t) => sum + (parseFloat(t.amount) || 0), 0);
    const totalPayments = cashTransactions
      .filter((t) => t.type === TRANSACTION_TYPES.PAYMENT)
      .reduce((sum, t) => sum + (parseFloat(t.amount) || 0), 0);
    const openingBalance = parseFloat(currentShift.opening_balance) || 0;
    const cashRevenue = salesData?.cash_revenue || 0;
    const expectedBalance = openingBalance + cashRevenue + totalReceipts - totalPayments;

    // Check if difference exists and reason is required
    if (actualBalance !== expectedBalance && !differenceReason) {
      throw new Error('Vui lòng nhập lý do chênh lệch');
    }

    // Show page loader
    if (window.showPageLoader) {
      window.showPageLoader({ text: 'Đang kết ca...', subtitle: 'Vui lòng đợi' });
    }

    try {
      await fetchShiftAPI(`${currentShift.id}/close`, {
        method: 'POST',
        body: JSON.stringify({
          actual_balance: actualBalance,
          handover_to: handoverToValue,
          handover_to_id: handoverToId,
          handover_to_name: handoverToName,
          handover_method: isSelfKeep ? 'cash' : handoverMethod,
          note: closingNote,
          difference_reason: differenceReason,
        }),
      });

      currentShift = null;
      cashTransactions = [];
      salesData = null;
      saveCachedData();

      if (typeof showSuccess === 'function') {
        showSuccess('Đã kết ca thành công!');
      }

      await refreshShiftData();
    } finally {
      if (window.hidePageLoader) {
        window.hidePageLoader();
      }
    }
  }

  async function handleCreateTransaction() {
    const typeElement = document.getElementById('shiftTransactionType');
    const type = typeElement ? typeElement.value : '';
    const amount = parseCurrency(document.getElementById('transactionAmount').value);
    const reasonSelect = document.getElementById('transactionReasonSelect').value;
    const customReason = document.getElementById('transactionCustomReason')?.value.trim() || '';
    const note = document.getElementById('transactionNote').value.trim();

    const reason =
      reasonSelect === 'Khác' || reasonSelect === 'Chi phí khác' ? customReason : reasonSelect;

    if (!type) {
      throw new Error('Loại phiếu không hợp lệ');
    }

    if (amount <= 0) {
      throw new Error('Số tiền không hợp lệ');
    }

    if (!reason) {
      throw new Error('Vui lòng chọn hoặc nhập lý do');
    }

    // Show page loader
    if (window.showPageLoader) {
      window.showPageLoader({ text: 'Đang tạo phiếu...', subtitle: 'Vui lòng đợi' });
    }

    try {
      const result = await fetchShiftAPI(`${currentShift.id}/transactions`, {
        method: 'POST',
        body: JSON.stringify({
          type: type,
          amount: amount,
          reason: reason,
          note: note,
        }),
      });

      // Add to local list
      cashTransactions.unshift(result);
      saveCachedData();

      if (typeof showSuccess === 'function') {
        showSuccess(
          `Đã tạo phiếu ${type === TRANSACTION_TYPES.RECEIPT ? 'thu' : 'chi'} thành công!`
        );
      }

      // Refresh toàn bộ data để cập nhật lịch sử ca và chi tiết ca realtime
      await refreshShiftData();
    } finally {
      if (window.hidePageLoader) {
        window.hidePageLoader();
      }
    }
  }

  async function confirmDeleteTransaction(transactionId) {
    // Use modal confirm instead of native confirm
    const confirmed =
      typeof showConfirm === 'function'
        ? await showConfirm('Bạn có chắc muốn xóa phiếu này?', 'Xác nhận xóa')
        : confirm('Bạn có chắc muốn xóa phiếu này?');
    if (!confirmed) return;

    // Show page loader
    if (window.showPageLoader) {
      window.showPageLoader({ text: 'Đang xóa phiếu...', subtitle: 'Vui lòng đợi' });
    }

    try {
      await fetchShiftAPI(`transactions/${transactionId}`, {
        method: 'DELETE',
      });

      // Remove from local list
      cashTransactions = cashTransactions.filter((t) => t.id != transactionId);
      saveCachedData();

      if (typeof showSuccess === 'function') {
        showSuccess('Đã xóa phiếu thành công!');
      }

      // Refresh toàn bộ data để cập nhật lịch sử ca và chi tiết ca realtime
      await refreshShiftData();
    } catch (error) {
      if (typeof showError === 'function') {
        showError('Lỗi xóa phiếu: ' + error.message);
      }
    } finally {
      if (window.hidePageLoader) {
        window.hidePageLoader();
      }
    }
  }

  async function confirmDeleteShift(shiftId) {
    // Find shift info
    const shift = shiftHistory.find((s) => s.id == shiftId);
    const shiftInfo = shift
      ? `Ca của ${shift.staff_name || 'N/A'} (${formatDateTime(shift.start_time)})`
      : `Ca #${shiftId}`;

    // Use modal confirm instead of native confirm
    const firstConfirm =
      typeof showConfirm === 'function'
        ? await showConfirm(
            `Bạn có chắc muốn xóa ${shiftInfo}?\n\nHành động này sẽ xóa toàn bộ dữ liệu ca làm việc và không thể hoàn tác!`,
            'Xác nhận xóa ca'
          )
        : confirm(
            `Bạn có chắc muốn xóa ${shiftInfo}?\n\nHành động này sẽ xóa toàn bộ dữ liệu ca làm việc và không thể hoàn tác!`
          );
    if (!firstConfirm) return;

    // Double confirm for safety
    const secondConfirm =
      typeof showConfirm === 'function'
        ? await showConfirm('XÁC NHẬN LẦN CUỐI: Bạn thực sự muốn xóa ca này?', '⚠️ Cảnh báo')
        : confirm('XÁC NHẬN LẦN CUỐI: Bạn thực sự muốn xóa ca này?');
    if (!secondConfirm) return;

    // Show page loader
    if (window.showPageLoader) {
      window.showPageLoader({ text: 'Đang xóa ca...', subtitle: 'Vui lòng đợi' });
    }

    try {
      await fetchShiftAPI(shiftId, {
        method: 'DELETE',
      });

      if (typeof showSuccess === 'function') {
        showSuccess('Đã xóa ca thành công!');
      }

      // Refresh data
      await refreshShiftData();
    } catch (error) {
      if (typeof showError === 'function') {
        showError('Lỗi xóa ca: ' + error.message);
      }
    } finally {
      if (window.hidePageLoader) {
        window.hidePageLoader();
      }
    }
  }

  // ============================================
  // Utility Functions
  // ============================================
  function formatCurrency(amount) {
    const num = parseFloat(amount) || 0;
    return new Intl.NumberFormat('vi-VN', {
      style: 'currency',
      currency: 'VND',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(num);
  }

  function parseCurrency(value) {
    if (!value) return 0;
    // Remove all non-digit characters except minus
    const cleaned = String(value).replace(/[^\d-]/g, '');
    return parseInt(cleaned, 10) || 0;
  }

  function formatDateTime(dateStr) {
    if (!dateStr) return '-';
    const date = new Date(dateStr);
    if (isNaN(date.getTime())) return '-';

    return date.toLocaleString('vi-VN', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  }

  function escapeHtml(str) {
    if (!str) return '';
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

  function getStatusLabel(status) {
    const labels = {
      [SHIFT_STATUS.OPEN]: 'Đang mở',
      [SHIFT_STATUS.CLOSED]: 'Đã đóng',
      [SHIFT_STATUS.HANDOVER_PENDING]: 'Chờ bàn giao',
      [SHIFT_STATUS.HANDOVER_COMPLETED]: 'Đã bàn giao',
    };
    return labels[status] || status;
  }

  function setupCurrencyInput(input) {
    if (!input) return;

    input.addEventListener('input', (e) => {
      let value = e.target.value.replace(/[^\d]/g, '');
      if (value) {
        value = parseInt(value, 10).toLocaleString('vi-VN');
      }
      e.target.value = value;
    });

    input.addEventListener('blur', (e) => {
      let value = parseCurrency(e.target.value);
      if (value > 0) {
        e.target.value = value.toLocaleString('vi-VN');
      } else {
        e.target.value = '';
      }
    });
  }

  // ============================================
  // Export Module
  // ============================================
  window.AppThoShiftManagement = {
    init: initShiftManagement,
    refresh: refreshShiftData,
    clearCache: clearCachedData,
    getCurrentShift: () => currentShift,
    isShiftOpen: () => !!currentShift,
  };

  // Auto-init when DOM ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      // Will be initialized when navigating to shifts section
    });
  }
})();
