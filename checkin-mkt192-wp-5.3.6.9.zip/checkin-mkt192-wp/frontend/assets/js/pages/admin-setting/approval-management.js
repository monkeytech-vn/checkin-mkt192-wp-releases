/**
 * Approval Management JavaScript
 * Quản lý duyệt đơn xin phép trong admin
 */

(function () {
  'use strict';

  // Request type configurations
  const REQUEST_TYPES = {
    late_early: {
      label: 'Đi trễ/Về sớm',
      icon: 'fa-clock',
    },
    leave: {
      label: 'Nghỉ phép',
      icon: 'fa-calendar-minus',
    },
    overtime: {
      label: 'Tăng ca',
      icon: 'fa-business-time',
    },
    salary_advance: {
      label: 'Ứng lương',
      icon: 'fa-money-bill-wave',
    },
  };

  const STATUS_LABELS = {
    pending: 'Chờ duyệt',
    approved: 'Đã duyệt',
    rejected: 'Từ chối',
  };

  /**
   * Approval Management Class
   */
  class ApprovalManagement {
    constructor() {
      this.section = document.getElementById('approval-management');
      this.requests = [];
      this.filteredRequests = [];
      this.currentType = 'all';
      this.currentStatus = 'pending';
      this.currentTimeFilter = 'this_month';
      this.currentBranch = 'all';
      this.currentPage = 1;
      this.perPage = 20;
      this.isLoading = false;

      if (this.section) {
        this.init();
      }
    }

    init() {
      this.bindEvents();
      this.checkBranchMode();
    }

    bindEvents() {
      // Tab buttons
      const tabButtons = this.section.querySelectorAll('.approval-tab-btn');
      tabButtons.forEach((btn) => {
        btn.addEventListener('click', () => {
          this.selectTab(btn.dataset.type);
        });
      });

      // Status filter
      const statusFilter = document.getElementById('approval-status-filter');
      if (statusFilter) {
        statusFilter.addEventListener('change', (e) => {
          this.currentStatus = e.target.value;
          this.applyFilters();
        });
      }

      // Time filter
      const timeFilter = document.getElementById('approval-time-filter');
      if (timeFilter) {
        timeFilter.addEventListener('change', (e) => {
          this.currentTimeFilter = e.target.value;
          this.applyFilters();
        });
      }

      // Branch filter
      const branchFilter = document.getElementById('approval-branch-filter');
      if (branchFilter) {
        branchFilter.addEventListener('change', (e) => {
          this.currentBranch = e.target.value;
          this.applyFilters();
        });
      }

      // Refresh button
      const refreshBtn = document.getElementById('refresh-approvals-btn');
      if (refreshBtn) {
        refreshBtn.addEventListener('click', () => this.fetchRequests());
      }

      // Listen for section activation
      document.addEventListener('click', (e) => {
        const link = e.target.closest('a[data-section="approval-management"]');
        if (link) {
          // Fetch data when section is activated
          setTimeout(() => this.fetchRequests(), 100);
        }
      });
    }

    checkBranchMode() {
      // Check if branch mode is enabled
      const branchModeEnabled =
        typeof checkinData !== 'undefined' && checkinData.branchModeEnabled === '1';
      const branchFilterGroup = document.getElementById('approval-branch-filter-group');

      if (branchFilterGroup) {
        branchFilterGroup.style.display = branchModeEnabled ? 'flex' : 'none';

        if (branchModeEnabled) {
          this.loadBranches();
        }
      }
    }

    async loadBranches() {
      try {
        const nonce = typeof checkinData !== 'undefined' ? checkinData.nonce : '';
        const response = await fetch('/wp-json/vg/v1/locations', {
          headers: {
            'X-WP-Nonce': nonce,
          },
        });

        if (response.ok) {
          const result = await response.json();
          const branches = result.data || result || [];
          this.renderBranchOptions(branches);
        }
      } catch (error) {
        console.error('Error loading branches:', error);
      }
    }

    renderBranchOptions(branches) {
      const branchFilter = document.getElementById('approval-branch-filter');
      if (!branchFilter) return;

      branchFilter.innerHTML = '<option value="all">Tất cả</option>';
      branches.forEach((branch) => {
        const option = document.createElement('option');
        option.value = branch.id || branch.location_id;
        option.textContent = branch.name || branch.location_name;
        branchFilter.appendChild(option);
      });
    }

    selectTab(type) {
      this.currentType = type;

      // Update tab buttons
      const tabButtons = this.section.querySelectorAll('.approval-tab-btn');
      tabButtons.forEach((btn) => {
        btn.classList.toggle('active', btn.dataset.type === type);
      });

      this.applyFilters();
    }

    async fetchRequests() {
      if (this.isLoading) return;
      this.isLoading = true;

      const refreshBtn = document.getElementById('refresh-approvals-btn');
      if (refreshBtn) {
        refreshBtn.classList.add('loading');
      }

      try {
        const nonce = typeof checkinData !== 'undefined' ? checkinData.nonce : '';
        const response = await fetch('/wp-json/vg/v1/approval-requests', {
          headers: {
            'X-WP-Nonce': nonce,
          },
        });

        const result = await response.json();

        if (response.ok) {
          this.requests = result.data || [];
          this.applyFilters();
        } else {
          this.showError(result.message || 'Không thể tải dữ liệu');
        }
      } catch (error) {
        console.error('Fetch error:', error);
        this.showError('Lỗi kết nối. Vui lòng thử lại.');
      } finally {
        this.isLoading = false;
        if (refreshBtn) {
          refreshBtn.classList.remove('loading');
        }
      }
    }

    applyFilters() {
      let filtered = [...this.requests];

      // Filter by type
      if (this.currentType !== 'all') {
        filtered = filtered.filter((r) => r.request_type === this.currentType);
      }

      // Filter by status
      if (this.currentStatus !== 'all') {
        filtered = filtered.filter((r) => r.status === this.currentStatus);
      }

      // Filter by time
      filtered = this.filterByTime(filtered);

      // Filter by branch
      if (this.currentBranch !== 'all') {
        filtered = filtered.filter(
          (r) => r.branch_id === this.currentBranch || r.location_id === this.currentBranch
        );
      }

      this.filteredRequests = filtered;
      this.currentPage = 1;
      this.renderTable();
      this.renderPagination();
    }

    filterByTime(requests) {
      const now = new Date();
      const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      const yesterday = new Date(today);
      yesterday.setDate(yesterday.getDate() - 1);
      const sevenDaysAgo = new Date(today);
      sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
      const thisMonthStart = new Date(now.getFullYear(), now.getMonth(), 1);
      const lastMonthStart = new Date(now.getFullYear(), now.getMonth() - 1, 1);
      const lastMonthEnd = new Date(now.getFullYear(), now.getMonth(), 0);

      switch (this.currentTimeFilter) {
        case 'today':
          return requests.filter((r) => new Date(r.created_at) >= today);

        case 'yesterday':
          return requests.filter((r) => {
            const d = new Date(r.created_at);
            return d >= yesterday && d < today;
          });

        case '7days':
          return requests.filter((r) => new Date(r.created_at) >= sevenDaysAgo);

        case 'this_month':
          return requests.filter((r) => new Date(r.created_at) >= thisMonthStart);

        case 'last_month':
          return requests.filter((r) => {
            const d = new Date(r.created_at);
            return d >= lastMonthStart && d <= lastMonthEnd;
          });

        case 'all':
        default:
          return requests;
      }
    }

    renderTable() {
      const tbody = document.getElementById('approval-requests-body');
      if (!tbody) return;

      // Pagination
      const start = (this.currentPage - 1) * this.perPage;
      const end = start + this.perPage;
      const pageRequests = this.filteredRequests.slice(start, end);

      if (pageRequests.length === 0) {
        tbody.innerHTML = `
          <tr>
            <td colspan="8" class="empty-state">
              <i class="fas fa-inbox"></i>
              <p>Không có đơn nào</p>
            </td>
          </tr>
        `;
        return;
      }

      tbody.innerHTML = pageRequests
        .map((request) => {
          const typeConfig = REQUEST_TYPES[request.request_type] || {};
          const statusLabel = STATUS_LABELS[request.status] || request.status;
          const detail = this.getRequestDetail(request);
          const createdDate = new Date(request.created_at).toLocaleString('vi-VN', {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
          });

          const isPending = request.status === 'pending';

          return `
          <tr data-id="${request.id}" data-request-id="${request.request_id}">
            <td><strong>${request.request_id || '#' + request.id}</strong></td>
            <td>
              <div class="approval-employee">
                <span class="approval-employee-name">${
                  request.staff_name || request.sender_name || request.user_name || 'N/A'
                }</span>
                <span class="approval-employee-email">${request.sender_email || ''}</span>
              </div>
            </td>
            <td>
              <span class="approval-type-badge ${request.request_type}">
                <i class="fas ${typeConfig.icon || 'fa-file'}"></i>
                ${typeConfig.label || request.request_type}
              </span>
            </td>
            <td class="approval-detail" title="${detail}">${detail}</td>
            <td class="approval-reason" title="${request.reason || ''}">${
            request.reason || '-'
          }</td>
            <td>${createdDate}</td>
            <td>
              <span class="approval-status-badge ${request.status}">${statusLabel}</span>
            </td>
            <td>
              <div class="approval-actions">
                ${
                  isPending
                    ? `
                  <button type="button" class="approval-action-btn approve" title="Duyệt" onclick="approvalManager.approveRequest('${request.request_id}')">
                    <i class="fas fa-check"></i>
                  </button>
                  <button type="button" class="approval-action-btn reject" title="Từ chối" onclick="approvalManager.rejectRequest('${request.request_id}')">
                    <i class="fas fa-times"></i>
                  </button>
                `
                    : ''
                }
                <button type="button" class="approval-action-btn delete" title="Xóa" onclick="approvalManager.deleteRequest('${
                  request.request_id
                }')">
                  <i class="fas fa-trash"></i>
                </button>
              </div>
            </td>
          </tr>
        `;
        })
        .join('');
    }

    renderPagination() {
      const container = document.getElementById('approval-pagination');
      if (!container) return;

      const totalPages = Math.ceil(this.filteredRequests.length / this.perPage);

      if (totalPages <= 1) {
        container.innerHTML = '';
        return;
      }

      let html = '';

      // Previous button
      html += `<button ${
        this.currentPage === 1 ? 'disabled' : ''
      } onclick="approvalManager.goToPage(${this.currentPage - 1})">
        <i class="fas fa-chevron-left"></i>
      </button>`;

      // Page numbers
      for (let i = 1; i <= totalPages; i++) {
        if (
          i === 1 ||
          i === totalPages ||
          (i >= this.currentPage - 2 && i <= this.currentPage + 2)
        ) {
          html += `<button class="${
            i === this.currentPage ? 'active' : ''
          }" onclick="approvalManager.goToPage(${i})">${i}</button>`;
        } else if (i === this.currentPage - 3 || i === this.currentPage + 3) {
          html += '<span>...</span>';
        }
      }

      // Next button
      html += `<button ${
        this.currentPage === totalPages ? 'disabled' : ''
      } onclick="approvalManager.goToPage(${this.currentPage + 1})">
        <i class="fas fa-chevron-right"></i>
      </button>`;

      container.innerHTML = html;
    }

    goToPage(page) {
      const totalPages = Math.ceil(this.filteredRequests.length / this.perPage);
      if (page < 1 || page > totalPages) return;
      this.currentPage = page;
      this.renderTable();
      this.renderPagination();
    }

    getRequestDetail(request) {
      switch (request.request_type) {
        case 'late_early':
          const typeLabel = request.late_early_type === 'late' ? 'Đi trễ' : 'Về sớm';
          return `${typeLabel} ${request.late_early_minutes || 0} phút - ${
            request.late_early_date || ''
          }`;

        case 'leave':
          const leaveLabels = { annual: 'Phép năm', unpaid: 'Không lương', sick: 'Nghỉ ốm' };
          return `${leaveLabels[request.leave_type] || ''}: ${request.leave_start_date || ''} → ${
            request.leave_end_date || ''
          }`;

        case 'overtime':
          return `${request.overtime_date || ''}: ${request.overtime_start_time || ''} - ${
            request.overtime_end_time || ''
          }`;

        case 'salary_advance':
          const amount = parseFloat(request.advance_amount || 0).toLocaleString('vi-VN');
          return `${amount} VNĐ`;

        default:
          return '-';
      }
    }

    async approveRequest(requestId) {
      if (!confirm('Bạn có chắc muốn DUYỆT đơn này?')) return;

      try {
        const nonce = typeof checkinData !== 'undefined' ? checkinData.nonce : '';
        const response = await fetch(`/wp-json/vg/v1/approval-requests/${requestId}/approve`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-WP-Nonce': nonce,
          },
        });

        const result = await response.json();

        if (response.ok && result.success) {
          this.showSuccess('Đã duyệt đơn thành công!');
          this.fetchRequests();
        } else {
          this.showError(result.message || 'Không thể duyệt đơn');
        }
      } catch (error) {
        console.error('Approve error:', error);
        this.showError('Lỗi kết nối. Vui lòng thử lại.');
      }
    }

    async rejectRequest(requestId) {
      const reason = prompt('Nhập lý do từ chối (tùy chọn):');
      if (reason === null) return; // User cancelled

      try {
        const nonce = typeof checkinData !== 'undefined' ? checkinData.nonce : '';
        const response = await fetch(`/wp-json/vg/v1/approval-requests/${requestId}/reject`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-WP-Nonce': nonce,
          },
          body: JSON.stringify({ reject_reason: reason }),
        });

        const result = await response.json();

        if (response.ok && result.success) {
          this.showSuccess('Đã từ chối đơn!');
          this.fetchRequests();
        } else {
          this.showError(result.message || 'Không thể từ chối đơn');
        }
      } catch (error) {
        console.error('Reject error:', error);
        this.showError('Lỗi kết nối. Vui lòng thử lại.');
      }
    }

    async deleteRequest(requestId) {
      if (!confirm('Bạn có chắc muốn XÓA đơn này? Hành động này không thể hoàn tác!')) return;

      try {
        const nonce = typeof checkinData !== 'undefined' ? checkinData.nonce : '';
        const response = await fetch(`/wp-json/vg/v1/approval-requests/${requestId}`, {
          method: 'DELETE',
          headers: {
            'X-WP-Nonce': nonce,
          },
        });

        const result = await response.json();

        if (response.ok && result.success) {
          this.showSuccess('Đã xóa đơn!');
          this.fetchRequests();
        } else {
          this.showError(result.message || 'Không thể xóa đơn');
        }
      } catch (error) {
        console.error('Delete error:', error);
        this.showError('Lỗi kết nối. Vui lòng thử lại.');
      }
    }

    showSuccess(message) {
      if (typeof showCheckinToast === 'function') {
        showCheckinToast({ message, type: 'success', duration: 3000 });
      } else {
        alert(message);
      }
    }

    showError(message) {
      if (typeof showCheckinToast === 'function') {
        showCheckinToast({ message, type: 'error', duration: 4000 });
      } else {
        alert('Lỗi: ' + message);
      }
    }
  }

  // Initialize when DOM is ready
  document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('approval-management')) {
      window.approvalManager = new ApprovalManagement();
    }
  });
})();
