let newShiftIndex = 0;
let newStaffIndex = 0;
let newPenaltyIndex = 0;
let newSalaryLevelIndex = 0;
let newStaffLevelIndex = 0;
let newKpiSettingIndex = 0;
let newServiceIndex = 0;
let newProductIndex = 0;
let currentTimeFilter = 'today';

// Flags to prevent duplicate data fetching
let staffDataLoaded = false;
let servicesDataLoaded = false;
let productsDataLoaded = false;

let staffList = [];
let managers = [];
let leaveRequests = [];
let salaryLevels = [];
let roles = [];
let serviceGroups = [];
let locations = [];
let kpiSettings = [];
let branchHelper = null;
let currentBranchFilter = null; // Lưu branch filter hiện tại
let isMultiBranchEnabled = false; // Flag kiểm tra chế độ đa chi nhánh

document.addEventListener('DOMContentLoaded', async () => {
  // Lấy trạng thái đa chi nhánh từ checkinData
  if (typeof checkinData !== 'undefined' && checkinData.isMultiBranchEnabled !== undefined) {
    isMultiBranchEnabled = checkinData.isMultiBranchEnabled;
  }

  // Ẩn/hiển thị các cột chi nhánh dựa trên chế độ
  toggleBranchColumns();

  // Khởi tạo BranchHelper với adminMode để lấy tất cả chi nhánh
  if (typeof BranchHelper !== 'undefined') {
    branchHelper = new BranchHelper({ adminMode: true });
    try {
      await branchHelper.initialize();
      renderAdminBranchSelector();
    } catch (err) {
      console.warn('BranchHelper init error:', err);
    }
  }

  // Chặn submit form NGAY từ đầu: các section nằm trong <form method="post">; trước đây chỉ chặn sau khi cả chuỗi
  // fetch xong (mất vài giây, lỗi 1 fetch là không chặn) → bấm tab "Thợ" (button không type) làm trang POST reload về mục đầu.
  handleFormSubmission();
  initializeSidebar();
  initializeSections();
  initializePeriodSelector();

  // Fetch data sau khi branchHelper đã sẵn sàng
  fetchRoles()
    .then(() => fetchStaff())
    .then(() => fetchLocations()) // Fetch locations TRƯỚC salary levels để có dữ liệu chi nhánh
    .then(() => fetchSalaryLevels())
    .then(() => {
      return Promise.all([
        getCurrentUserRole(),
        fetchBookingSettings(),
        fetchShifts(),
        fetchPenaltySettings(),
        fetchKpiSettings(),
        fetchServices(),
        fetchProducts(),
        fetchManagerSchedules(),
        updateAppVersion(),
      ]);
    })
    .then(() => {
      handleFormSubmission();
      initializeAddNewSchedule();
      initializeKpiSettings();
      initializeLeaveRequestsFilters();
    })
    .catch((error) => console.error('Initialization error:', error));

  document.querySelectorAll('.tab-button').forEach((button) => {
    button.addEventListener('click', () => {
      document.querySelectorAll('.tab-button').forEach((btn) => btn.classList.remove('active'));
      document
        .querySelectorAll('.tab-content')
        .forEach((content) => content.classList.remove('active'));
      button.classList.add('active');
      document.getElementById(`kpi-${button.dataset.tab}-container`).classList.add('active');
      fetchKpiSettings();
      renderKpiTable(button.dataset.tab);
    });
  });

  // Xử lý nút Thêm KPI
  document.getElementById('add-kpi-btn').addEventListener('click', () => {
    const tab = document.querySelector('.tab-button.active').dataset.tab;
    showKpiModal(tab, null); // Gọi modal ở chế độ thêm mới
  });
});

/** Escape để nhét chuỗi vào HTML/thuộc tính an toàn. */
function escapeHtml(text) {
  return String(text ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

/**
 * Ẩn/Hiển thị các cột và phần tử liên quan đến chi nhánh
 * dựa trên chế độ đa chi nhánh được bật hay tắt
 */
function toggleBranchColumns() {
  const display = isMultiBranchEnabled ? '' : 'none';

  // Thêm class vào body để có thể sử dụng CSS
  if (isMultiBranchEnabled) {
    document.body.classList.add('multi-branch-enabled');
    document.body.classList.remove('single-branch-mode');
  } else {
    document.body.classList.remove('multi-branch-enabled');
    document.body.classList.add('single-branch-mode');
  }

  // Ẩn/hiển thị cột chi nhánh trong các bảng (header và cell)
  // Staff table
  document.querySelectorAll('.col-branch').forEach((el) => {
    el.style.display = display;
  });

  // Branch filter dropdown ở header
  const branchSelectorContainer = document.getElementById('branch-selector-container');
  if (branchSelectorContainer) {
    branchSelectorContainer.style.display = display;
  }

  // Tìm tất cả các th có nội dung "Chi nhánh" và ẩn/hiển thị cùng với cột tương ứng
  document.querySelectorAll('th').forEach((th) => {
    if (th.textContent.trim() === 'Chi nhánh') {
      th.style.display = display;
      th.classList.add('branch-header'); // Đánh dấu để dễ xử lý sau này
      // Ẩn/hiển thị cột tương ứng trong tbody
      const table = th.closest('table');
      if (table) {
        const thIndex = Array.from(th.parentNode.children).indexOf(th);
        const tbody = table.querySelector('tbody');
        if (tbody) {
          tbody.querySelectorAll('tr').forEach((row) => {
            const cells = row.querySelectorAll('td');
            if (cells[thIndex]) {
              cells[thIndex].style.display = display;
              cells[thIndex].classList.add('branch-cell'); // Đánh dấu
            }
          });
        }
      }
    }
  });

  console.log('toggleBranchColumns: isMultiBranchEnabled =', isMultiBranchEnabled);
}

/**
 * Observer để theo dõi khi DOM thay đổi và ẩn/hiển thị cột chi nhánh
 */
function setupBranchColumnObserver() {
  const observer = new MutationObserver((mutations) => {
    let shouldUpdate = false;
    for (const mutation of mutations) {
      if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
        // Kiểm tra nếu có thêm row mới vào bảng
        for (const node of mutation.addedNodes) {
          if (
            node.nodeType === Node.ELEMENT_NODE &&
            (node.tagName === 'TR' || node.querySelector('tr'))
          ) {
            shouldUpdate = true;
            break;
          }
        }
      }
      if (shouldUpdate) break;
    }
    if (shouldUpdate && !isMultiBranchEnabled) {
      // Chỉ cần ẩn nếu không bật multi-branch
      requestAnimationFrame(() => {
        document.querySelectorAll('.col-branch, .branch-header, .branch-cell').forEach((el) => {
          el.style.display = 'none';
        });
        // Ẩn các th "Chi nhánh" mới
        document.querySelectorAll('th').forEach((th) => {
          if (th.textContent.trim() === 'Chi nhánh') {
            th.style.display = 'none';
            const table = th.closest('table');
            if (table) {
              const thIndex = Array.from(th.parentNode.children).indexOf(th);
              table.querySelectorAll('tbody tr').forEach((row) => {
                const cells = row.querySelectorAll('td');
                if (cells[thIndex]) cells[thIndex].style.display = 'none';
              });
            }
          }
        });
      });
    }
  });

  observer.observe(document.body, { childList: true, subtree: true });
}

// Khởi tạo observer khi chế độ single-branch
document.addEventListener('DOMContentLoaded', () => {
  if (!isMultiBranchEnabled) {
    setupBranchColumnObserver();
  }
});

async function getCurrentUserRole() {
  try {
    const response = await fetch(`${checkinData.restUrl}staff`, {
      method: 'GET',
      headers: { 'X-WP-Nonce': checkinData.nonce },
    });
    const staffData = await response.json();
    const currentUser = checkinData.currentUser;
    const staff = staffData.data.find((s) => s.display_name === currentUser.display_name);

    if (staff) {
      return staff.user_role || 'Unknown';
    } else {
      return checkinData.currentUser.user_role || 'Unknown';
    }
  } catch (error) {
    console.error('Lỗi khi lấy user_role:', error);
    return checkinData.currentUser.user_role || 'Unknown';
  }
}

function initializeKpiSettings() {
  const tabs = ['service', 'product', 'postfb', 'feedback'];
  tabs.forEach((tab) => renderKpiTable(tab));
}

function renderKpiTable(tab) {
  const container = document.querySelector(`#kpi-${tab}-container .kpi-table-container`);
  if (!container) {
    console.error(`Container for tab ${tab} not found!`);
    return;
  }

  const filteredKpis = kpiSettings.filter(
    (kpi) =>
      kpi[
        tab === 'service'
          ? 'service_kpi'
          : tab === 'product'
            ? 'product_kpi_lv1'
            : tab === 'postfb'
              ? 'post_fb_kpi'
              : 'feedback_kpi'
      ] > 0
  );

  let tableHTML = `
    <table class="kpi-table">
      <thead>
        <tr>
          <th>Nhân viên</th>
          ${
            tab === 'product' ? '<th>Loại mục tiêu</th>' : ''
          }  <!-- Thêm cột Loại mục tiêu chỉ cho product -->
          ${tab === 'postfb' ? '<th>Cách tính</th>' : ''}
          <th>Mục tiêu KPI</th>
          <th>Thưởng</th>
          <th>Phạt</th>
          <th>Thời gian</th>
          <th>Hành động</th>
        </tr>
      </thead>
      <tbody>
  `;

  filteredKpis.forEach((kpi) => {
    const kpiTypeDisplay = kpi.product_kpi_type === 'san_pham' ? 'Sản phẩm' : 'Doanh thu'; // Hiển thị loại

    tableHTML += `
      <tr data-id="${kpi.id}" data-tab="${tab}">
        <td>${Array.isArray(kpi.staff_name) ? kpi.staff_name.join(', ') : kpi.staff_name}</td>
        ${
          tab === 'product' ? `<td>${kpiTypeDisplay}</td>` : ''
        }  <!-- Hiển thị loại chỉ cho product -->
        ${tab === 'postfb' ? `<td>${kpi.post_fb_mode === 'workdays' ? 'Theo ngày công' : 'Số bài cố định'}</td>` : ''}
        <td>${tab === 'postfb' && kpi.post_fb_mode === 'workdays' ? `${parseInt(kpi.post_fb_kpi).toLocaleString('vi-VN')} bài/ngày công` : parseInt(
          kpi[
            tab === 'service'
              ? 'service_kpi'
              : tab === 'product'
                ? 'product_kpi_lv1'
                : tab === 'postfb'
                  ? 'post_fb_kpi'
                  : 'feedback_kpi'
          ]
        ).toLocaleString('vi-VN')}</td>
        <td>${
          tab === 'product'
            ? parseInt(
                kpi[
                  tab === 'service'
                    ? 'service_bonus'
                    : tab === 'product'
                      ? 'product_bonus_lv1'
                      : tab === 'postfb'
                        ? 'post_fb_bonus'
                        : 'feedback_bonus'
                ]
              ) + '%'
            : parseInt(
                kpi[
                  tab === 'service'
                    ? 'service_bonus'
                    : tab === 'product'
                      ? 'product_bonus_lv1'
                      : tab === 'postfb'
                        ? 'post_fb_bonus'
                        : 'feedback_bonus'
                ]
              ).toLocaleString('vi-VN')
        }</td>
        <td>${
          tab === 'product'
            ? parseInt(kpi.product_penalty_lv1 || 0) + '%'
            : parseInt(
                kpi[
                  tab === 'service'
                    ? 'service_penalty'
                    : tab === 'postfb'
                      ? 'post_fb_penalty'
                      : 'feedback_penalty'
                ] || 0
              ).toLocaleString('vi-VN')
        }</td>
        <td>${kpi.start_date} đến ${kpi.end_date}</td>
        <td>
          <button type="button" class="edit-kpi-btn" data-id="${kpi.id}" data-tab="${tab}">
            <i class="fas fa-edit"></i>
          </button>
          <button type="button" class="delete-kpi-btn" data-id="${kpi.id}">
            <i class="fas fa-trash"></i>
          </button>
        </td>
      </tr>
    `;
  });

  tableHTML += `
      </tbody>
    </table>
  `;

  container.innerHTML = tableHTML;

  // Thêm sự kiện click cho nút Edit
  container.querySelectorAll('.edit-kpi-btn').forEach((button) => {
    button.addEventListener('click', () => {
      const id = button.dataset.id;
      const tab = button.dataset.tab;
      const kpi = kpiSettings.find((k) => k.id.toString() === id);
      if (kpi) {
        showKpiModal(tab, kpi); // Gọi modal ở chế độ chỉnh sửa
      } else {
        console.error(`KPI with id ${id} not found in kpiSettings:`, kpiSettings);
      }
    });
  });

  // Thêm sự kiện click cho nút Delete
  container.querySelectorAll('.delete-kpi-btn').forEach((button) => {
    button.addEventListener('click', () => {
      const id = button.dataset.id;
      deleteKpi(id); // Gọi hàm xóa KPI
    });
  });
}

function showKpiModal(tab, kpi) {
  const modal = document.getElementById('kpi-modal');
  const container = document.querySelector('#kpi-modal .kpi-form-container');
  const title = document.getElementById('modal-title');
  const sub = document.getElementById('kpi-modal-sub');
  const saveBtn = document.querySelector('#kpi-modal .save-kpi-modal');
  const isEdit = !!kpi;
  const META = {
    service: { name: 'Doanh số dịch vụ', unit: 'đ', targetHint: 'Doanh số dịch vụ tối thiểu trong kỳ', bonusUnit: 'đ', penaltyUnit: 'đ', k: ['service_kpi', 'service_bonus', 'service_penalty'] },
    product: { name: 'Bán sản phẩm', unit: 'SP / đ', targetHint: 'Theo loại mục tiêu bên dưới', bonusUnit: '%', penaltyUnit: '%', k: ['product_kpi_lv1', 'product_bonus_lv1', 'product_penalty_lv1'] },
    postfb: { name: 'Đăng bài Facebook', unit: 'bài', targetHint: 'Số bài đăng tối thiểu trong kỳ', bonusUnit: 'đ', penaltyUnit: 'đ', k: ['post_fb_kpi', 'post_fb_bonus', 'post_fb_penalty'] },
    feedback: { name: 'Đánh giá Google Maps', unit: 'lượt', targetHint: 'Số đánh giá (ảnh) tối thiểu trong kỳ', bonusUnit: 'đ', penaltyUnit: 'đ', k: ['feedback_kpi', 'feedback_bonus', 'feedback_penalty'] },
  };
  const m = META[tab] || META.service;
  // KPI đăng bài: 'workdays' = N bài mỗi ngày công thực tế (mặc định cho KPI mới) · 'count' = số bài cố định trong kỳ
  const postFbMode = tab === 'postfb' ? (kpi && kpi.post_fb_mode === 'count' ? 'count' : 'workdays') : null;
  const val = (key) => (kpi && kpi[key] !== undefined && kpi[key] !== null ? parseInt(kpi[key]) || 0 : '');
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  title.textContent = isEdit ? `Sửa KPI · ${m.name}` : `Thêm KPI · ${m.name}`;
  if (sub) sub.textContent = 'Đạt thì thưởng, không đạt thì phạt · áp cho các nhân viên được chọn trong khoảng thời gian.';

  const selected = kpi && Array.isArray(kpi.staff_name) ? kpi.staff_name : [];
  const staffChips = staffList
    .map((staff) => {
      const id = 'staff-' + String(staff.display_name).replace(/[^a-zA-Z0-9]+/g, '-');
      return `<label class="ps-chip-check" for="${id}"><input type="checkbox" id="${id}" name="staff_name" value="${esc(staff.display_name)}" ${selected.includes(staff.display_name) ? 'checked' : ''}><span>${esc(staff.display_name)}</span></label>`;
    })
    .join('');

  container.innerHTML = `
    <div class="kpi-form ps-kpi-form">
      <fieldset class="ps-fieldset"><legend>Mục tiêu &amp; thưởng phạt</legend>
        <div class="ps-grid-2">
          <label class="ps-field ps-field--wide"><span>Mục tiêu KPI</span><div class="ps-input-wrap"><input type="number" class="kpi-target" min="0" value="${val(m.k[0])}" placeholder="0"><b class="kpi-target-unit">${m.unit}</b></div><small>${m.targetHint}</small></label>
          ${tab === 'postfb' ? `<label class="ps-field ps-field--wide"><span>Cách tính</span><div class="ps-input-wrap"><select class="kpi-postfb-mode"><option value="workdays" ${postFbMode === 'workdays' ? 'selected' : ''}>Theo ngày công của thợ (N bài mỗi ngày công)</option><option value="count" ${postFbMode === 'count' ? 'selected' : ''}>Số bài cố định trong kỳ</option></select></div><small class="kpi-postfb-hint"></small></label>` : ''}
          ${tab === 'product' ? `<label class="ps-field ps-field--wide"><span>Loại mục tiêu</span><div class="ps-input-wrap"><select class="kpi-product-type"><option value="san_pham" ${(kpi ? kpi.product_kpi_type : 'doanh_thu') === 'san_pham' ? 'selected' : ''}>Số sản phẩm bán ra</option><option value="doanh_thu" ${(kpi ? kpi.product_kpi_type : 'doanh_thu') === 'doanh_thu' ? 'selected' : ''}>Doanh thu sản phẩm (đ)</option></select></div></label>` : ''}
          <label class="ps-field"><span>Đạt → thưởng</span><div class="ps-input-wrap"><input type="number" class="kpi-bonus" min="0" value="${val(m.k[1])}" placeholder="0"><b>${m.bonusUnit}</b></div></label>
          <label class="ps-field"><span>Không đạt → phạt</span><div class="ps-input-wrap"><input type="number" class="kpi-penalty" min="0" value="${val(m.k[2])}" placeholder="0"><b>${m.penaltyUnit}</b></div></label>
        </div>
        ${tab === 'product' ? '<small class="ps-help">Thưởng/phạt sản phẩm tính theo % doanh thu sản phẩm. Ngưỡng "bán từ N sản phẩm" và % hoa hồng đặt trong thẻ hoa hồng của thợ.</small>' : ''}
      </fieldset>
      <fieldset class="ps-fieldset"><legend>Áp cho nhân viên</legend>
        <div class="ps-chip-actions"><button type="button" class="ps-link-btn" data-kpi-all="1">Chọn tất cả</button> · <button type="button" class="ps-link-btn" data-kpi-all="0">Bỏ chọn</button> <span class="ps-muted" id="kpi-staff-count"></span></div>
        <div class="ps-chip-list">${staffChips || '<span class="ps-muted">Chưa có nhân viên</span>'}</div>
      </fieldset>
      <fieldset class="ps-fieldset"><legend>Thời gian áp dụng</legend>
        <div class="ps-grid-2">
          <label class="ps-field"><span>Từ ngày</span><div class="ps-input-wrap"><input type="date" class="kpi-start-date" value="${kpi ? esc(kpi.start_date) : ''}"></div></label>
          <label class="ps-field"><span>Đến ngày</span><div class="ps-input-wrap"><input type="date" class="kpi-end-date" value="${kpi ? esc(kpi.end_date) : ''}"></div></label>
        </div>
      </fieldset>
    </div>`;

  const countEl = container.querySelector('#kpi-staff-count');
  const updateCount = () => {
    if (countEl) countEl.textContent = `— ${container.querySelectorAll('input[name="staff_name"]:checked').length}/${staffList.length} đã chọn`;
  };
  container.querySelectorAll('input[name="staff_name"]').forEach((i) => i.addEventListener('change', updateCount));
  container.querySelectorAll('[data-kpi-all]').forEach((b) =>
    b.addEventListener('click', () => {
      container.querySelectorAll('input[name="staff_name"]').forEach((i) => (i.checked = b.dataset.kpiAll === '1'));
      updateCount();
    })
  );
  container.querySelector('.kpi-product-type')?.addEventListener('change', (e) => {
    const u = container.querySelector('.kpi-target-unit');
    if (u) u.textContent = e.target.value === 'san_pham' ? 'SP' : 'đ';
  });
  if (tab === 'product') container.querySelector('.kpi-product-type')?.dispatchEvent(new Event('change'));
  container.querySelector('.kpi-postfb-mode')?.addEventListener('change', (e) => {
    const workdays = e.target.value === 'workdays';
    const u = container.querySelector('.kpi-target-unit');
    const hint = container.querySelector('.kpi-postfb-hint');
    const targetHint = container.querySelector('.kpi-target')?.closest('label')?.querySelector('small');
    if (u) u.textContent = workdays ? 'bài / ngày công' : 'bài';
    if (targetHint) targetHint.textContent = workdays ? 'Số bài mỗi ngày công thực tế (VD 1 → làm 7 ngày phải có 7 bài)' : 'Số bài đăng tối thiểu trong kỳ, không quy theo ngày công';
    if (hint) hint.textContent = workdays ? 'Phải đạt = N × số ngày công thực tế trong kỳ; phiếu lương ghi "7 bài / 7 ngày công".' : 'Phải đạt đúng số bài đã đặt dù thợ làm bao nhiêu ngày.';
  });
  if (tab === 'postfb') container.querySelector('.kpi-postfb-mode')?.dispatchEvent(new Event('change'));
  updateCount();

  modal.style.display = 'flex';
  document.body.classList.add('ps-modal-open');
  const closeModalHandler = () => {
    modal.style.display = 'none';
    document.body.classList.remove('ps-modal-open');
  };
  modal.querySelectorAll('.close-modal, [data-close]').forEach((btn) => (btn.onclick = closeModalHandler));
  modal.onclick = (e) => {
    if (e.target === modal || e.target.classList.contains('ps-modal-backdrop')) closeModalHandler();
  };
  saveBtn.onclick = () => saveKpiModal(tab, isEdit ? kpi.id : null);
}

async function saveKpiModal(tab, id) {
  const container = document.querySelector('#kpi-modal .kpi-form-container');
  const target = container.querySelector('.kpi-target').value;
  const bonus = container.querySelector('.kpi-bonus').value;
  const penalty = container.querySelector('.kpi-penalty').value || 0;
  const staffCheckboxes = container.querySelectorAll('input[name="staff_name"]:checked');
  const startDate = container.querySelector('.kpi-start-date').value;
  const endDate = container.querySelector('.kpi-end-date').value;

  const staffNames = Array.from(staffCheckboxes).map((checkbox) => checkbox.value);

  let productKpiType = 'doanh_thu'; // Mặc định
  if (tab === 'product') {
    productKpiType = container.querySelector('.kpi-product-type')?.value || 'doanh_thu'; // Lấy giá trị từ select
  }

  if (!target || !bonus || !startDate || !endDate) {
    showWarning('Vui lòng điền đầy đủ thông tin!');
    return;
  }

  const kpiData = {
    staff_name: staffNames,
    [tab === 'service'
      ? 'service_kpi'
      : tab === 'product'
        ? 'product_kpi_lv1'
        : tab === 'postfb'
          ? 'post_fb_kpi'
          : 'feedback_kpi']: parseFloat(target),
    [tab === 'service'
      ? 'service_bonus'
      : tab === 'product'
        ? 'product_bonus_lv1'
        : tab === 'postfb'
          ? 'post_fb_bonus'
          : 'feedback_bonus']: parseFloat(bonus),
    [tab === 'service'
      ? 'service_penalty'
      : tab === 'product'
        ? 'product_penalty_lv1'
        : tab === 'postfb'
          ? 'post_fb_penalty'
          : 'feedback_penalty']: parseFloat(penalty),
    product_kpi_type: tab === 'product' ? productKpiType : undefined, // Thêm trường mới chỉ cho product
    post_fb_mode: tab === 'postfb' ? container.querySelector('.kpi-postfb-mode')?.value || 'workdays' : undefined,
    status: 1,
    start_date: startDate,
    end_date: endDate,
  };

  try {
    const url = id
      ? `${checkinData.restUrl}kpi-settings/${id}`
      : `${checkinData.restUrl}kpi-settings`;
    const method = id ? 'PUT' : 'POST';

    const response = await fetch(url, {
      method: method,
      headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': checkinData.nonce },
      body: JSON.stringify(kpiData),
    });

    const result = await response.json();
    if (result.success) {
      toastSuccess('Lưu KPI thành công!');
      fetchKpiSettings();
      renderKpiTable(tab);
      document.getElementById('kpi-modal').style.display = 'none';
    } else {
      showError(`Lỗi: ${result.message}`);
    }
  } catch (error) {
    console.error('Error saving KPI:', error);
    showError('Lỗi hệ thống!');
  }
}

async function deleteKpi(id) {
  const confirmed = await showConfirm('Bạn có chắc muốn xóa KPI này?', 'Xác nhận xóa');
  if (confirmed) {
    try {
      const response = await fetch(`${checkinData.restUrl}kpi-settings/${id}`, {
        method: 'DELETE',
        headers: { 'X-WP-Nonce': checkinData.nonce },
      });
      const result = await response.json();
      if (result.success) {
        toastSuccess('Xóa KPI thành công!');
        fetchKpiSettings();
        const tab = document.querySelector('.tab-button.active').dataset.tab;
        renderKpiTable(tab);
      } else {
        showError(`Lỗi: ${result.message}`);
      }
    } catch (error) {
      console.error('Error deleting KPI:', error);
      showError('Lỗi hệ thống!');
    }
  }
}

async function fetchKpiSettings(kpi_type = '') {
  try {
    const params = new URLSearchParams();
    if (currentUserRole === 'Thu Ngân' || currentUserRole === 'Quản Lý') {
      params.append('current_user_role', currentUserRole);
    } else {
      params.append('staff_name', staffList.length > 0 ? staffList[0].display_name : '');
    }
    if (kpi_type) {
      params.append('kpi_type', kpi_type);
    }
    if (currentBranchFilter) params.append('branch_id', currentBranchFilter); // Add branch filter

    const response = await fetch(`${checkinData.restUrl}kpi-settings?${params.toString()}`, {
      method: 'GET',
      headers: { 'X-WP-Nonce': checkinData.nonce },
    });
    const result = await response.json();
    if (result.success) {
      kpiSettings = result.data.map((kpi) => {
        let staff_name = [];
        try {
          // Nếu staff_name đã là mảng (từ API), sử dụng trực tiếp
          if (Array.isArray(kpi.staff_name)) {
            staff_name = kpi.staff_name;
          } else {
            // Thử parse nếu là chuỗi JSON
            staff_name = JSON.parse(kpi.staff_name) || [kpi.staff_name];
          }
        } catch (e) {
          console.warn(`Error parsing staff_name for KPI id ${kpi.id}:`, e.message);
          // Fallback: xử lý chuỗi không hợp lệ, tách bằng dấu phẩy nếu có
          staff_name = kpi.staff_name
            .split(',')
            .map((name) => name.trim())
            .filter((name) => name);
        }
        return {
          ...kpi,
          id: parseInt(kpi.id),
          staff_name,
        };
      });
      console.log('kpiSettings after fetch:', kpiSettings); // Debug dữ liệu
      // Làm mới bảng cho tab hiện tại
      const activeTab = document.querySelector('.tab-button.active')?.dataset.tab;
      if (activeTab) {
        renderKpiTable(activeTab);
      }
    } else {
      console.error('Error fetching KPI settings:', result.message);
    }
  } catch (error) {
    console.error('Error fetching KPI settings:', error);
  }
}

function triggerPeriodChange(role, period) {
  if (role === 'Thu Ngân') {
    fetchCashierSalary(period);
  } else {
    fetchHairdresserSalary(period);
  }
}

function attachCalculateSalaryEvent() {
  const calculateBtn = document.getElementById('calculate-salary');
  if (!calculateBtn) {
    return;
  }
  calculateBtn.disabled = false;
  calculateBtn.removeEventListener('click', handleCalculateSalaryClick);
  calculateBtn.addEventListener('click', handleCalculateSalaryClick);
}

function handleCalculateSalaryClick() {
  const yearSelect = document.getElementById('year-select');
  const monthSelect = document.getElementById('month-select');
  if (!yearSelect || !monthSelect) {
    console.error('Missing year-select or month-select elements');
    showError('Lỗi: Không tìm thấy bộ chọn tháng/năm.');
    return;
  }
  const period = `${yearSelect.value}-${monthSelect.value}`;

  const activeTab = document.querySelector('.salary-tabs .tab-btn.active');
  if (!activeTab) {
    console.error('No active tab found');
    showError('Lỗi: Không xác định được vai trò nhân viên.');
    return;
  }
  const role = activeTab.id === 'cashier-tab' ? 'Thu Ngân' : 'Thợ';
  const updateEndpoint =
    role === 'Thu Ngân' ? 'update-cashier-salary' : 'update-hairdresser-salary';

  if (!checkinData || !checkinData.restUrl || !checkinData.nonce) {
    console.error('checkinData is not defined or missing required properties', checkinData);
    showError('Lỗi cấu hình hệ thống. Vui lòng liên hệ quản trị viên.');
    return;
  }

  fetch(`${checkinData.restUrl}${updateEndpoint}?period=${encodeURIComponent(period)}`, {
    method: 'POST',
    headers: {
      'X-WP-Nonce': checkinData.nonce,
      'Content-Type': 'application/json',
    },
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      return response.json();
    })
    .then((response) => {
      if (response.success) {
        triggerPeriodChange(role, period);
        toastSuccess(`Cập nhật lương ${role} thành công!`);
      } else {
        console.error(`Error updating ${role} salary:`, response.message);
        showError(`Lỗi khi tính lương: ${response.message}`);
      }
    })
    .catch((error) => {
      console.error(`Error updating ${role} salary:`, error);
      showError(`Lỗi khi tính lương: ${error.message || 'Vui lòng thử lại.'}`);
    });
}

function initializePeriodSelector() {
  const yearSelect = document.getElementById('year-select');
  const monthSelect = document.getElementById('month-select');
  const cashierTab = document.getElementById('cashier-tab');
  const hairdresserTab = document.getElementById('hairdresser-tab');

  if (!yearSelect || !monthSelect || !cashierTab || !hairdresserTab) {
    console.error('Missing required elements for period selector');
    return;
  }

  const currentYear = new Date().getFullYear();

  // Lấy tháng trước (previous month) để làm mặc định
  const now = new Date();
  const previousMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1);
  const defaultYear = previousMonth.getFullYear();
  const defaultMonth = previousMonth.getMonth() + 1;

  const years = [currentYear - 1, currentYear];
  yearSelect.innerHTML = years
    .map(
      (year) => `<option value="${year}" ${year === defaultYear ? 'selected' : ''}>${year}</option>`
    )
    .join('');

  function updateMonthOptions() {
    const months = Array.from({ length: 12 }, (_, i) => i + 1);
    monthSelect.innerHTML = months
      .map(
        (month) => `
                <option value="${month.toString().padStart(2, '0')}"
                        ${
                          month === defaultMonth && yearSelect.value == defaultYear
                            ? 'selected'
                            : ''
                        }>
                    Tháng ${month}
                </option>
            `
      )
      .join('');
  }

  updateMonthOptions();

  function getCurrentPeriod() {
    return `${yearSelect.value}-${monthSelect.value}`;
  }

  yearSelect.addEventListener('change', () => {
    updateMonthOptions();
    const activeTab = document.querySelector('.salary-tabs .tab-btn.active');
    const role = activeTab.id === 'cashier-tab' ? 'Thu Ngân' : 'Thợ';
    triggerPeriodChange(role, getCurrentPeriod());
  });

  monthSelect.addEventListener('change', () => {
    const activeTab = document.querySelector('.salary-tabs .tab-btn.active');
    const role = activeTab.id === 'cashier-tab' ? 'Thu Ngân' : 'Thợ';
    triggerPeriodChange(role, getCurrentPeriod());
  });

  cashierTab.addEventListener('click', () => {
    cashierTab.classList.add('active');
    hairdresserTab.classList.remove('active');
    triggerPeriodChange('Thu Ngân', getCurrentPeriod());
  });

  hairdresserTab.addEventListener('click', () => {
    hairdresserTab.classList.add('active');
    cashierTab.classList.remove('active');
    triggerPeriodChange('Thợ', getCurrentPeriod());
  });

  cashierTab.classList.add('active');
  hairdresserTab.classList.remove('active');
  triggerPeriodChange('Thu Ngân', getCurrentPeriod());

  attachCalculateSalaryEvent();
}

function showSalaryCardModal(salary, role, period) {
  // Phiếu lương là modal (không khung ngoài); đóng không refresh trang — card đổi mới được cập nhật tại chỗ
  if (window.psPayslipModal) return window.psPayslipModal.open(salary, role, period);
  console.error('psPayslipModal chưa nạp (salary-staff.js)');
}

async function fetchCashierSalary(period) {
  const salaryTableBody = document.getElementById('salary-table-body');
  const salaryCardsBody = document.getElementById('salary-cards-body');
  if (!salaryCardsBody) {
    console.error('Missing salary-cards-body element');
    showError('Lỗi: Không tìm thấy container lương.');
    return;
  }
  if (salaryTableBody) salaryTableBody.innerHTML = '';
  salaryCardsBody.innerHTML = '<div class="ps-skeleton"><div></div><div></div><div></div></div>';
  try {
    if (!checkinData || !checkinData.restUrl || !checkinData.nonce) {
      throw new Error('checkinData is not defined or missing required properties');
    }
    const params = new URLSearchParams();
    params.append('type', 'salary');
    params.append('period', period);
    if (currentBranchFilter) params.append('branch_id', currentBranchFilter);
    const response = await fetch(`${checkinData.restUrl}cashier-salary-data?${params.toString()}`, {
      method: 'GET',
      headers: { 'X-WP-Nonce': checkinData.nonce },
    });
    if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
    const responseData = await response.json();
    const rows = responseData.success && Array.isArray(responseData.data) ? responseData.data : [];
    window.psAdminSalaryList.render(salaryCardsBody, rows, 'cashier', {
      period,
      onOpen: (salary) => showSalaryCardModal(salary, 'Thu Ngân', period),
      onProfile: (name) =>
        window.psStaffProfile?.open({
          staffName: name,
          onOpenPeriod: async (p, r, staffName) => {
            try {
              const ep = r === 'Thu Ngân' ? 'cashier-salary-data' : 'hairdresser-salary-data';
              const res = await fetch(`${checkinData.restUrl}${ep}?type=salary&period=${encodeURIComponent(p)}&staff_name=${encodeURIComponent(staffName)}`, { headers: { 'X-WP-Nonce': checkinData.nonce } });
              const j = await res.json();
              if (j.success && j.data && j.data[0]) showSalaryCardModal(j.data[0], r, p);
            } catch (e) {
              console.warn('Không mở được phiếu lương', e);
            }
          },
        }),
      onCalculate: handleCalculateSalaryClick,
    });
  } catch (error) {
    console.error('Error fetching Thu Ngân salary:', error);
    salaryCardsBody.innerHTML = `<div class="ps-admin-empty"><div>Lỗi tải dữ liệu lương: ${error.message}</div><button type="button" id="calculate-salary" class="ps-btn ps-btn--primary">Tính lương</button></div>`;
    attachCalculateSalaryEvent();
  }
}

async function fetchHairdresserSalary(period) {
  const salaryTableBody = document.getElementById('salary-table-body');
  const salaryCardsBody = document.getElementById('salary-cards-body');
  if (!salaryCardsBody) {
    console.error('Missing salary-cards-body element');
    showError('Lỗi: Không tìm thấy container lương.');
    return;
  }
  if (salaryTableBody) salaryTableBody.innerHTML = '';
  salaryCardsBody.innerHTML = '<div class="ps-skeleton"><div></div><div></div><div></div></div>';
  try {
    if (!checkinData || !checkinData.restUrl || !checkinData.nonce) {
      throw new Error('checkinData is not defined or missing required properties');
    }
    const params = new URLSearchParams();
    params.append('type', 'salary');
    params.append('period', period);
    if (currentBranchFilter) params.append('branch_id', currentBranchFilter);
    const response = await fetch(`${checkinData.restUrl}hairdresser-salary-data?${params.toString()}`, {
      method: 'GET',
      headers: { 'X-WP-Nonce': checkinData.nonce },
    });
    if (!response.ok) throw new Error(`HTTP error! Status: ${response.status}`);
    const responseData = await response.json();
    const rows = responseData.success && Array.isArray(responseData.data) ? responseData.data : [];
    window.psAdminSalaryList.render(salaryCardsBody, rows, 'hairdresser', {
      period,
      onOpen: (salary) => showSalaryCardModal(salary, 'Thợ', period),
      onProfile: (name) =>
        window.psStaffProfile?.open({
          staffName: name,
          onOpenPeriod: async (p, r, staffName) => {
            try {
              const ep = r === 'Thu Ngân' ? 'cashier-salary-data' : 'hairdresser-salary-data';
              const res = await fetch(`${checkinData.restUrl}${ep}?type=salary&period=${encodeURIComponent(p)}&staff_name=${encodeURIComponent(staffName)}`, { headers: { 'X-WP-Nonce': checkinData.nonce } });
              const j = await res.json();
              if (j.success && j.data && j.data[0]) showSalaryCardModal(j.data[0], r, p);
            } catch (e) {
              console.warn('Không mở được phiếu lương', e);
            }
          },
        }),
      onCalculate: handleCalculateSalaryClick,
    });
  } catch (error) {
    console.error('Error fetching Thợ salary:', error);
    salaryCardsBody.innerHTML = `<div class="ps-admin-empty"><div>Lỗi tải dữ liệu lương: ${error.message}</div><button type="button" id="calculate-salary" class="ps-btn ps-btn--primary">Tính lương</button></div>`;
    attachCalculateSalaryEvent();
  }
}

// === UNIFORM FEE FUNCTIONS ===
function setupUniformFeeEvents(row, salary, period, role) {
  const createBtn = row.querySelector('.uniform-create-btn');
  const inputContainer = row.querySelector('.uniform-input-container');
  const saveBtn = row.querySelector('.uniform-save-btn');
  const cancelBtn = row.querySelector('.uniform-cancel-btn');
  const input = row.querySelector('.uniform-fee-input');

  if (createBtn) {
    createBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      createBtn.style.display = 'none';
      inputContainer.style.display = 'flex';
      input.focus();
    });
  }

  if (cancelBtn) {
    cancelBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      inputContainer.style.display = 'none';
      createBtn.style.display = 'inline-block';
      input.value = '';
    });
  }

  if (saveBtn) {
    saveBtn.addEventListener('click', async (e) => {
      e.stopPropagation();
      const uniformFee = parseFloat(input.value) || 0;

      if (uniformFee <= 0) {
        showError('Vui lòng nhập số tiền hợp lệ.');
        return;
      }

      try {
        saveBtn.disabled = true;
        const response = await fetch(`${checkinData.restUrl}update-uniform-fee`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-WP-Nonce': checkinData.nonce,
          },
          body: JSON.stringify({
            staff_name: salary.staff_name,
            period: period,
            role: role,
            uniform_fee: uniformFee,
          }),
        });

        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.message || 'Lỗi khi cập nhật phí đồng phục');
        }

        const result = await response.json();
        if (result.success) {
          toastSuccess('Cập nhật phí đồng phục thành công!');
          // Refresh lại danh sách lương
          if (role === 'Thu Ngân') {
            fetchCashierSalary(period);
          } else {
            fetchHairdresserSalary(period);
          }
        } else {
          throw new Error(result.message || 'Lỗi không xác định');
        }
      } catch (error) {
        console.error('Error updating uniform fee:', error);
        showError('Lỗi khi cập nhật phí đồng phục: ' + error.message);
      } finally {
        saveBtn.disabled = false;
      }
    });
  }

  // Ngăn sự kiện click lan truyền từ input
  if (input) {
    input.addEventListener('click', (e) => e.stopPropagation());
  }
}

// === OFF-CANVAS FUNCTIONS ===
function initializeSidebar() {
  const sidebar = document.querySelector('.sidebar');
  const sidebarToggleBtn = document.querySelector('.sidebar-toggle-btn');
  const sidebarCloseBtn = document.querySelector('.sidebar-close-btn');
  const sidebarCollapseBtn = document.querySelector('.sidebar-collapse-btn');
  const sidebarOverlay = document.querySelector('.sidebar-overlay');
  const mainContent = document.querySelector('.main-content');
  const menuItems = document.querySelectorAll('.sidebar-menu a');

  // Xử lý sidebar theo kích thước màn hình
  function handleSidebarDisplay() {
    if (window.innerWidth >= 1024) {
      // Desktop: Sidebar luôn hiển thị, ẩn toggle button
      sidebar.classList.add('active');
      sidebarToggleBtn.style.display = 'none';
      sidebarOverlay.classList.remove('active');
      mainContent.classList.remove('sidebar-open-mobile');
    } else {
      // Mobile: Sidebar ẩn mặc định
      sidebar.classList.remove('active');
      sidebarToggleBtn.style.display = 'block';
      sidebarOverlay.classList.remove('active');
      mainContent.classList.remove('sidebar-open-mobile');
      mainContent.style.marginLeft = '0';
      mainContent.style.width = '100%';
    }
  }

  // Gọi hàm xử lý khi tải trang và khi thay đổi kích thước
  handleSidebarDisplay();
  window.addEventListener('resize', handleSidebarDisplay);

  // Xử lý thu gọn/mở rộng sidebar trên desktop
  if (sidebarCollapseBtn) {
    sidebarCollapseBtn.addEventListener('click', () => {
      sidebar.classList.toggle('collapsed');
      if (window.innerWidth >= 1024) {
        if (sidebar.classList.contains('collapsed')) {
          sidebar.style.width = '80px';
          document
            .querySelectorAll('.sidebar-menu span')
            .forEach((span) => (span.style.display = 'none'));
          document.querySelector('.sidebar-header h4').style.display = 'none';
          mainContent.style.marginLeft = '80px';
          mainContent.style.width = 'calc(100% - 80px)';
        } else {
          sidebar.style.width = '250px';
          document
            .querySelectorAll('.sidebar-menu span')
            .forEach((span) => (span.style.display = 'inline'));
          document.querySelector('.sidebar-header h4').style.display = 'block';
          mainContent.style.marginLeft = '250px';
          mainContent.style.width = 'calc(100% - 250px)';
        }
      }
    });
  }

  // Xử lý toggle sidebar trên mobile
  if (sidebarToggleBtn) {
    sidebarToggleBtn.addEventListener('click', () => {
      sidebar.classList.toggle('active');
      sidebarOverlay.classList.toggle('active');
      mainContent.classList.toggle('sidebar-open-mobile');
      if (sidebar.classList.contains('active')) {
        // Khi sidebar hiển thị trên mobile, sử dụng width hiện tại (thu gọn hoặc mở rộng)
        sidebar.style.width = sidebar.classList.contains('collapsed') ? '80px' : '240px';
        mainContent.style.marginLeft = sidebar.classList.contains('collapsed') ? '80px' : '240px';
        mainContent.style.width = sidebar.classList.contains('collapsed')
          ? 'calc(100% - 80px)'
          : 'calc(100% - 240px)';
      } else {
        // Khi sidebar ẩn trên mobile, reset margin-left về 0
        mainContent.style.marginLeft = '0';
        mainContent.style.width = '100%';
      }
    });
  }

  if (sidebarOverlay) {
    sidebarOverlay.addEventListener('click', () => {
      sidebar.classList.remove('active');
      sidebarOverlay.classList.remove('active');
      mainContent.classList.remove('sidebar-open-mobile');
      mainContent.style.marginLeft = '0';
      mainContent.style.width = '100%';
    });
  }

  // Xử lý chọn menu
  menuItems.forEach((item) => {
    item.addEventListener('click', (e) => {
      e.preventDefault();
      menuItems.forEach((i) => i.classList.remove('active'));
      item.classList.add('active');

      document.querySelectorAll('.settings-section').forEach((section) => {
        section.classList.remove('active');
      });

      const sectionId = item.getAttribute('data-section');
      const section = document.getElementById(sectionId);
      if (section) {
        section.classList.add('active');
      }

      // Ẩn sidebar trên mobile sau khi chọn và reset margin-left
      if (window.innerWidth < 1024) {
        sidebar.classList.remove('active');
        sidebarOverlay.classList.remove('active');
        mainContent.classList.remove('sidebar-open-mobile');
        mainContent.style.marginLeft = '0';
        mainContent.style.width = '100%';
      }
    });
  });
}

// Tải dữ liệu khi section được hiển thị
function initializeSections() {
  const menuItems = document.querySelectorAll('.sidebar-menu a');
  if (menuItems.length === 0) return;

  menuItems.forEach((item) => {
    item.addEventListener('click', (e) => {
      e.preventDefault();
      const sectionId = item.getAttribute('data-section');

      switch (sectionId) {
        case 'manager-schedule':
          showSection(sectionId);
          fetchManagerSchedules();
          break;
        case 'leave-requests':
          showSection(sectionId);
          fetchLeaveRequests(getTimeFilterRange('today'));
          break;
        case 'shift-management':
          showSection(sectionId);
          fetchShifts();
          break;
        case 'shift-location-settings':
          showSection(sectionId);
          fetchLocations();
          break;
        case 'services':
          showSection(sectionId);
          fetchServices();
          break;
        case 'products':
          showSection(sectionId);
          fetchProducts();
          break;
        case 'staff-list':
          showSection(sectionId);
          if (!staffDataLoaded) {
            fetchStaff();
          }
          break;
        case 'penalty-settings':
          showSection(sectionId);
          fetchPenaltySettings();
          break;
        case 'salary-level-settings':
          showSection(sectionId);
          fetchSalaryLevels();
          break;
        case 'staff-level-history':
          showSection(sectionId);
          fetchStaffLevels();
          break;
        case 'kpi-settings':
          showSection(sectionId);
          fetchKpiSettings();
          break;
        case 'roles':
          showSection(sectionId);
          fetchRoles();
          break;
        case 'checkin-dashboard':
          window.location.href = '/checkin-dashboard';
          return;
        default:
          showSection(sectionId);
          break;
      }
    });
  });

  // Mặc định click vào menu đầu tiên
  menuItems[0].click();
}

function updateAppVersion() {
  const versionElement = document.getElementById('appVersion');
  if (versionElement && checkinData && checkinData.version) {
    versionElement.textContent = `Phiên bản ${checkinData.version}`;
  } else {
    console.warn('Không tìm thấy appVersion element hoặc checkinData.version');
    if (versionElement) {
      versionElement.textContent = 'Phiên bản không xác định';
    }
  }
}

function showSection(sectionId) {
  const sections = document.querySelectorAll('.settings-section');
  const menuItems = document.querySelectorAll('.sidebar-menu a');

  menuItems.forEach((item) => item.classList.remove('active'));
  sections.forEach((section) => section.classList.remove('active'));

  if (sectionId !== 'checkin-history' && sectionId !== 'checkin-dashboard') {
    document.getElementById(sectionId).classList.add('active');
    document.querySelector(`.sidebar-menu a[data-section="${sectionId}"]`).classList.add('active');
  }
}

// === MANAGER SCHEDULE FUNCTIONS ===
function initializeAddNewSchedule() {
  const addNewButton = document.getElementById('add-new-schedule');
  if (addNewButton) {
    addNewButton.addEventListener('click', () => {
      const tableBody = document.getElementById('manager-schedule-table-body');
      managers = staffList.filter((staff) => staff.user_role === 'Quản Lý');
      if (!tableBody) return;
      const row = document.createElement('tr');
      row.innerHTML = `
        <td>
          <select name="staff_name[]">
            <option value="">Chọn Quản Lý</option>
            ${managers
              .map(
                (staff) => `<option value="${staff.display_name}">${staff.display_name}</option>`
              )
              .join('')}
          </select>
        </td>
        <td class="col-branch">
          <select name="branch[]">
            <option value="">Chọn chi nhánh</option>
            ${locations
              .map(
                (loc) =>
                  `<option value="${loc.id || loc.branch_id}">${
                    loc.location_name || loc.branch_name
                  }</option>`
              )
              .join('')}
          </select>
        </td>
        <td><input type="date" name="start_date[]" value=""></td>
        <td><input type="date" name="end_date[]" value=""></td>
        <td>
          <button class="save-schedule-btn">💾 Lưu</button>
          <button class="delete-schedule-btn">🗑️ Xóa</button>
        </td>
      `;
      tableBody.appendChild(row);
    });
  }

  document.addEventListener('click', (e) => {
    if (e.target.classList.contains('save-schedule-btn')) {
      const row = e.target.closest('tr');
      const branchSelect = row.querySelector('select[name="branch[]"]');
      // Lấy branch_id trực tiếp từ value của select (đã là branch_id)
      const branchId = parseInt(branchSelect?.value) || 0;

      const schedule = {
        staff_name: row.querySelector('select[name="staff_name[]"]').value,
        branch_id: branchId, // Sử dụng branch_id thay vì branch (tên)
        start_date: row.querySelector('input[name="start_date[]"]').value,
        end_date: row.querySelector('input[name="end_date[]"]').value,
      };

      if (!schedule.staff_name || !branchId || !schedule.start_date || !schedule.end_date) {
        showWarning('Vui lòng điền đầy đủ thông tin lịch làm việc!');
        return;
      }

      fetch(`${checkinData.restUrl}manager-schedules`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': checkinData.nonce },
        body: JSON.stringify([schedule]),
      })
        .then((response) => {
          if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
          }
          return response.json();
        })
        .then((data) => {
          if (data.success) {
            toastSuccess('Cập nhật lịch làm việc thành công!');
            fetchManagerSchedules();
          } else {
            showError('Cập nhật thất bại: ' + (data.message || 'Không có thông tin lỗi'));
          }
        })
        .catch((error) => {
          console.error('Error updating manager schedule:', error);
          showError('Cập nhật thất bại: ' + error.message);
        });
    } else if (e.target.classList.contains('delete-schedule-btn')) {
      const row = e.target.closest('tr');
      const schedule = {
        staff_name: row.querySelector('select[name="staff_name[]"]').value,
        start_date: row.querySelector('input[name="start_date[]"]').value,
      };

      showConfirm('Bạn có chắc muốn xóa lịch làm việc này?').then((confirmed) => {
        if (confirmed) {
          fetch(`${checkinData.restUrl}manager-schedules/delete`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': checkinData.nonce },
            body: JSON.stringify(schedule),
          })
            .then((response) => {
              if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
              }
              return response.json();
            })
            .then((data) => {
              if (data.success) {
                toastSuccess('Xóa lịch làm việc thành công!');
                fetchManagerSchedules();
              } else {
                showError('Xóa thất bại: ' + (data.message || 'Không có thông tin lỗi'));
              }
            })
            .catch((error) => {
              console.error('Error deleting manager schedule:', error);
              showError('Xóa thất bại: ' + error.message);
            });
        }
      });
    } else if (e.target.classList.contains('save-new-role')) {
      const row = e.target.closest('tr');
      const newRoleInput = row.querySelector('.new-role-input');
      const roleSelect = row.querySelector('.role-select');
      const roleName = newRoleInput.value.trim();

      if (!roleName) {
        showWarning('Vui lòng nhập tên vai trò mới!');
        return;
      }

      fetch(`${checkinData.restUrl}roles`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-WP-Nonce': checkinData.nonce,
        },
        body: JSON.stringify({ role_name: roleName }),
      })
        .then((response) => response.json())
        .then((data) => {
          if (data.success) {
            toastSuccess('Thêm vai trò mới thành công!');
            roles.push(roleName);
            roleSelect.innerHTML = fetchRoleOptions(roleName);
            roleSelect.style.display = 'inline-block';
            newRoleInput.style.display = 'none';
            e.target.style.display = 'none';
            row.querySelector('.cancel-new-role').style.display = 'none';
            updateAllRoleSelects();
          } else {
            showError('Thêm vai trò thất bại: ' + (data.message || 'Không có thông tin lỗi'));
          }
        })
        .catch((error) => {
          console.error('Error saving new role:', error);
          showError('Lỗi khi thêm vai trò mới: ' + error.message);
        });
    } else if (e.target.classList.contains('cancel-new-role')) {
      const row = e.target.closest('tr');
      const roleSelect = row.querySelector('.role-select');
      const newRoleInput = row.querySelector('.new-role-input');
      const saveRoleButton = row.querySelector('.save-new-role');
      const cancelRoleButton = row.querySelector('.cancel-new-role');

      roleSelect.style.display = 'inline-block';
      newRoleInput.style.display = 'none';
      newRoleInput.value = '';
      saveRoleButton.style.display = 'none';
      cancelRoleButton.style.display = 'none';
      roleSelect.value = roleSelect.dataset.originalValue || '';
    }
  });
}

function fetchManagerSchedules() {
  return fetch(`${checkinData.restUrl}manager-schedules`, {
    method: 'GET',
    headers: { 'X-WP-Nonce': checkinData.nonce },
  })
    .then((response) => response.json())
    .then((response) => {
      if (response.success && response.data) {
        const tableBody = document.getElementById('manager-schedule-table-body');
        if (!tableBody) return;
        tableBody.innerHTML = '';
        // Lọc danh sách nhân viên có vai trò là Quản Lý
        const managers = staffList.filter((staff) => staff.user_role === 'Quản Lý');
        response.data.forEach((schedule) => {
          // Lấy branch_id từ schedule data
          const scheduleBranchId = parseInt(schedule.branch_id) || 0;
          const row = document.createElement('tr');
          row.innerHTML = `
            <td>
              <select name="staff_name[]">
                <option value="">Chọn Quản Lý</option>
                ${managers
                  .map(
                    (staff) =>
                      `<option value="${staff.display_name}" ${
                        staff.display_name === schedule.staff_name ? 'selected' : ''
                      }>${staff.display_name}</option>`
                  )
                  .join('')}
              </select>
            </td>
            <td class="col-branch">
              <select name="branch[]">
                <option value="">Chọn chi nhánh</option>
                ${locations
                  .map((loc) => {
                    const locBranchId = parseInt(loc.id || loc.branch_id) || 0;
                    return `<option value="${locBranchId}" ${
                      locBranchId === scheduleBranchId ? 'selected' : ''
                    }>${loc.location_name || loc.branch_name}</option>`;
                  })
                  .join('')}
              </select>
            </td>
            <td><input type="date" name="start_date[]" value="${schedule.start_date}"></td>
            <td><input type="date" name="end_date[]" value="${schedule.end_date}"></td>
            <td>
              <button class="save-schedule-btn">💾 Lưu</button>
              <button class="delete-schedule-btn">🗑️ Xóa</button>

            </td>
          `;
          tableBody.appendChild(row);
        });
      } else {
        console.error('Error fetching manager schedules:', response.message);
      }
    })
    .catch((error) => console.error('Error fetching manager schedules:', error));
}

// === FETCH DATA FUNCTIONS ===
function fetchBookingSettings() {
  return fetch(`${checkinData.restUrl}booking-settings`, {
    method: 'GET',
    headers: { 'X-WP-Nonce': checkinData.nonce },
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      return response.json();
    })
    .then((data) => {
      if (data.success && data.data) {
        // Điền dữ liệu vào form
        const overtime = data.data.find((item) => item.type === 'overtime') || {};
        const holiday = data.data.find((item) => item.type === 'holiday') || {};
        const event = data.data.find((item) => item.type === 'event') || {};

        document.getElementById('overtime_start_date').value = overtime.start_date || '';
        document.getElementById('overtime_end_date').value = overtime.end_date || '';
        document.getElementById('overtime_start_time').value = overtime.start_time || '';
        document.getElementById('overtime_end_time').value = overtime.end_time || '';

        document.getElementById('special_start_date').value = holiday.start_date || '';
        document.getElementById('special_end_date').value = holiday.end_date || '';
        document.getElementById('special_start_time').value = holiday.start_time || '';
        document.getElementById('special_end_time').value = holiday.end_time || '';
        document.getElementById('special_message').value = holiday.message || '';

        document.getElementById('year_party_date').value = event.start_date || '';
        document.getElementById('year_party_time').value = event.start_time || '';
      } else {
        console.error('Failed to fetch booking settings:', data.message);
        showError('Lỗi khi tải cài đặt booking: ' + (data.message || 'Không có thông tin lỗi'));
      }
    })
    .catch((error) => {
      console.error('Error fetching booking settings:', error);
      showError('Đã xảy ra lỗi khi tải cài đặt booking: ' + error.message);
    });
}

// Lấy danh sách vai trò từ API
function fetchRoles() {
  return fetch(`${checkinData.restUrl}roles`, {
    method: 'GET',
    headers: { 'X-WP-Nonce': checkinData.nonce },
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        roles = data.data.map((role) => role.role_name) || [];
        updateAllRoleSelects();
        renderRolesTable(); // Thêm dòng này để render table sau khi fetch
      } else {
        console.error('Failed to fetch roles:', data.message);
        roles = [];
      }
    })
    .catch((error) => {
      console.error('Error fetching roles:', error);
      roles = [];
    });
}

function fetchShifts() {
  const params = new URLSearchParams();
  if (currentBranchFilter) params.append('branch_id', currentBranchFilter); // Add branch filter

  return fetch(`${checkinData.restUrl}shifts?${params.toString()}`, {
    method: 'GET',
    headers: { 'X-WP-Nonce': checkinData.nonce },
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        const tbody = document.getElementById('shift-table-body');
        tbody.innerHTML = '';
        data.data.forEach((shift) => tbody.appendChild(createShiftRow(shift)));
      }
    })
    .catch((error) => console.error('Error fetching shifts:', error));
}

function fetchStaff() {
  const params = new URLSearchParams();
  params.append('context', 'admin');
  if (currentBranchFilter) params.append('branch_id', currentBranchFilter); // Add branch filter

  return fetch(`${checkinData.restUrl}staff?${params.toString()}`, {
    method: 'GET',
    headers: { 'X-WP-Nonce': checkinData.nonce },
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        staffList = data.data || [];
        staffDataLoaded = true; // Mark as loaded to prevent duplicate fetches
        console.log('Staff data received:', staffList); // Debug: log staff data
        const tbody = document.getElementById('staff-table-body');
        tbody.innerHTML = '';
        data.data.forEach((staff) => {
          console.log('Creating row for staff:', {
            user_id: staff.user_id,
            branch: staff.branch,
            user_branch: staff.user_branch,
          }); // Debug
          tbody.appendChild(createStaffRow(staff));
        });
      } else {
        console.error('Failed to fetch staff:', data.message);
        staffList = [];
      }
    })
    .catch((error) => console.error('Error fetching staff:', error));
}

function fetchPenaltySettings() {
  const params = new URLSearchParams();
  if (currentBranchFilter) params.append('branch_id', currentBranchFilter); // Add branch filter

  return fetch(`${checkinData.restUrl}penalty-settings?${params.toString()}`, {
    method: 'GET',
    headers: { 'X-WP-Nonce': checkinData.nonce },
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      return response.json();
    })
    .then((data) => {
      if (data.success) {
        populatePenaltySettings(data.data);
      } else {
        console.error('Failed to fetch penalty settings:', data.message);
        showError(
          'Lỗi khi tải cài đặt phạt: ' +
            (data.data?.message || data.message || 'Không có thông tin lỗi')
        );
      }
    })
    .catch((error) => {
      console.error('Error fetching penalty settings:', error);
      showError('Đã xảy ra lỗi khi tải cài đặt phạt: ' + error.message);
    });
}

// Cập nhật fetchSalaryLevels
function fetchSalaryLevels() {
  return fetch(`${checkinData.restUrl}salary-levels`, {
    method: 'GET',
    headers: { 'X-WP-Nonce': checkinData.nonce },
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        salaryLevels = data.data || [];
        const tbody = document.getElementById('salary-level-table-body');
        tbody.innerHTML = '';
        data.data.forEach((level) => tbody.appendChild(createSalaryLevelRow(level)));
      } else {
        console.error('Failed to fetch salary levels:', data.message);
        salaryLevels = [];
      }
    })
    .catch((error) => {
      console.error('Error fetching salary levels:', error);
      salaryLevels = [];
    });
}

function fetchStaffLevels() {
  return fetch(`${checkinData.restUrl}staff-levels`, {
    method: 'GET',
    headers: { 'X-WP-Nonce': checkinData.nonce },
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        staffLevels = data.data || [];
        const tbody = document.getElementById('staff-level-table-body');
        tbody.innerHTML = '';
        data.data.forEach((level) => tbody.appendChild(createStaffLevelRow(level)));
      } else {
        console.error('Failed to fetch staff levels:', data.message);
        staffLevels = [];
      }
    })
    .catch((error) => {
      console.error('Error fetching staff levels:', error);
      staffLevels = [];
    });
}

// === HELPER FUNCTIONS ===
// Hàm chuẩn hóa chuỗi
const normalizeString = (str) => (str ? str.normalize('NFC').trim().toLowerCase() : '');

// Cập nhật tất cả <select> vai trò
function updateAllRoleSelects() {
  // Cập nhật trong bảng nhân viên
  document.querySelectorAll('#staff-table-body .role-select').forEach((select) => {
    const currentValue = select.value === 'add_new' ? '' : select.value;
    select.innerHTML = fetchRoleOptions(currentValue);
    select.style.display = select.value === 'add_new' ? 'none' : 'inline-block';
  });
  // Cập nhật trong bảng cấp lương
  document.querySelectorAll('#salary-level-table-body select[name="role[]"]').forEach((select) => {
    const currentValue = select.value === 'add_new' ? '' : select.value;
    select.innerHTML = fetchRoleOptions(currentValue);
  });
}

function fetchStaffOptions(selectedName = '') {
  return staffList.length > 0
    ? staffList
        .map(
          (staff) =>
            `<option value="${staff.display_name}" ${
              staff.display_name === selectedName ? 'selected' : ''
            }>${staff.display_name}</option>`
        )
        .join('')
    : '<option value="">--Chưa có--</option>';
}

// Cập nhật fetchLevelOptions để lọc theo vai trò
function fetchLevelOptions(selectedLevel = '', staffName = '') {
  const selectedStaff = staffList.find((staff) => staff.display_name === staffName);
  const staffRole = selectedStaff ? selectedStaff.user_role : '';
  const filteredLevels = staffRole
    ? salaryLevels.filter((level) => normalizeString(level.role) === normalizeString(staffRole))
    : salaryLevels;
  const uniqueLevels = [...new Set(filteredLevels.map((level) => level.level_name))]; // Loại bỏ trùng lặp
  return uniqueLevels.length > 0
    ? uniqueLevels
        .map(
          (levelName) =>
            `<option value="${levelName}" ${
              levelName === selectedLevel ? 'selected' : ''
            }>${levelName}</option>`
        )
        .join('')
    : '<option value="">--Chưa có cấp lương--</option>';
}

// Hàm lấy danh sách vai trò cho <select>
function fetchRoleOptions(selectedRole = '') {
  // Chuẩn hóa chuỗi để xử lý encoding
  const normalizeString = (str) => (str ? str.normalize('NFC').trim().toLowerCase() : '');
  const normalizedSelectedRole = normalizeString(selectedRole);
  return roles.length > 0
    ? roles
        .map((role) => {
          const normalizedRole = normalizeString(role);
          return `<option value="${role}" ${
            normalizedRole === normalizedSelectedRole ? 'selected' : ''
          }>${role}</option>`;
        })
        .join('') + '<option value="add_new">Thêm mới</option>'
    : '<option value="">--Chưa có vai trò--</option><option value="add_new">Thêm mới</option>';
}

function updateStaffFields(selectElement) {
  const row = selectElement.closest('tr');
  const staffName = selectElement.value;
  const selectedStaff = staffList.find((staff) => staff.display_name === staffName);
  const staffIdInput = row.querySelector('input[name="staff_id[]"]');
  const roleInput = row.querySelector('input[name="role[]"]');
  const statusInput = row.querySelector('input[name="status[]"]');
  const levelSelect = row.querySelector('select[name="level_name[]"]');
  const currentLevel = levelSelect.value;

  if (selectedStaff) {
    staffIdInput.value = selectedStaff.employee_id || '';
    roleInput.value = selectedStaff.user_role || '';
    statusInput.value = selectedStaff.status || 'Đang làm việc';
    levelSelect.innerHTML = fetchLevelOptions(currentLevel, staffName);
  } else {
    staffIdInput.value = '';
    roleInput.value = '';
    statusInput.value = '';
    levelSelect.innerHTML = '<option value="">--Chưa có cấp lương--</option>';
  }
}

// === CREATE ROW FUNCTIONS ===
function createShiftRow(shift) {
  const row = document.createElement('tr');
  // Sử dụng branch_id thay vì branch name
  const currentBranchId = shift.branch_id || '';
  row.innerHTML = `
        <td class="col-id">${shift.id || 'N/A'}</td>
        <td class="col-shiftgroup"><input type="hidden" name="shift_id[]" value="${
          shift.id || 'new_' + newShiftIndex
        }" disabled><input type="text" name="shift_group[]" value="${
          shift.shift_group || ''
        }" disabled></td>
        <td class="col-shiftname"><input type="text" name="shift_name[]" value="${
          shift.shift_name || ''
        }" disabled></td>
        <td class="col-branch">
            <select name="branch[]" class="branch-select" disabled data-shift-id="${
              shift.id || ''
            }">
                <option value="">-- Chi nhánh --</option>
                ${getBranchOptions(currentBranchId)}
            </select>
        </td>
        <td class="col-start"><input type="time" name="start_time[]" value="${
          shift.start_time || ''
        }" disabled></td>
        <td class="col-end"><input type="time" name="end_time[]" value="${
          shift.end_time || ''
        }" disabled></td>
        <td class="col-early"><input type="number" name="early_checkin[]" value="${
          shift.early_checkin || 0
        }" min="0" disabled></td>
        <td class="col-late-max"><input type="number" name="late_checkin[]" value="${
          shift.late_checkin || 0
        }" min="0" disabled></td>
        <td class="col-late-allowed"><input type="number" name="late_allowed[]" value="${
          shift.late_allowed || 0
        }" min="0" disabled></td>
        <td class="col-early-out"><input type="number" name="early_checkout[]" value="${
          shift.early_checkout || 0
        }" min="0" disabled></td>
        <td class="col-late-out"><input type="number" name="late_checkout[]" value="${
          shift.late_checkout || 0
        }" min="0" disabled></td>
        <td class="col-actions actions">
            <a href="#" class="edit btn-icon" onclick="editShiftRow(this, '${
              shift.id || 'new_' + newShiftIndex
            }'); return false;">✏️</a>
            <a href="#" class="delete btn-icon" onclick="deleteShiftRow(this, '${
              shift.id || 'new_' + newShiftIndex
            }'); return false;">🗑️</a>
            <a href="#" class="save btn-icon" style="display: none;" onclick="saveShiftRow(this, '${
              shift.id || 'new_' + newShiftIndex
            }'); return false;">💾</a>
        </td>
    `;
  if (!shift.id) newShiftIndex++;
  return row;
}

function editShiftRow(element, shiftId) {
  const row = element.closest('tr');
  const saveButton = row.querySelector('.save');
  const editButton = row.querySelector('.edit');

  // Hiển thị nút lưu và ẩn nút sửa
  saveButton.style.display = 'inline';
  editButton.style.display = 'none';

  // Mở khóa các input
  row.querySelectorAll('input:not([type="hidden"])').forEach((input) => {
    input.disabled = false;
  });

  // Mở khóa select (bao gồm branch)
  row.querySelectorAll('select').forEach((select) => {
    select.disabled = false;
  });
}

function saveShiftRow(element, shiftId) {
  const row = element.closest('tr');
  const branchSelect = row.querySelector('select[name="branch[]"]');
  // Lấy branch_id trực tiếp từ value của select (đã là branch_id)
  const branchId = parseInt(branchSelect?.value) || 0;

  const shift = {
    id: row.querySelector('input[name="shift_id[]"]').value,
    shift_group: row.querySelector('input[name="shift_group[]"]').value,
    shift_name: row.querySelector('input[name="shift_name[]"]').value,
    start_time: row.querySelector('input[name="start_time[]"]').value,
    end_time: row.querySelector('input[name="end_time[]"]').value,
    early_checkin: parseInt(row.querySelector('input[name="early_checkin[]"]').value) || 0,
    late_checkin: parseInt(row.querySelector('input[name="late_checkin[]"]').value) || 0,
    late_allowed: parseInt(row.querySelector('input[name="late_allowed[]"]').value) || 0,
    early_checkout: parseInt(row.querySelector('input[name="early_checkout[]"]').value) || 0,
    late_checkout: parseInt(row.querySelector('input[name="late_checkout[]"]').value) || 0,
    branch_id: branchId, // Send branch_id instead of branch name
  };

  if (!shift.shift_name || !shift.start_time || !shift.end_time) {
    showWarning('Vui lòng nhập đầy đủ tên ca, giờ bắt đầu và giờ kết thúc!');
    return;
  }

  const url =
    shift.id && !shift.id.startsWith('new_')
      ? `${checkinData.restUrl}shifts/${shift.id}`
      : `${checkinData.restUrl}shifts`;

  fetch(url, {
    method: shift.id && !shift.id.startsWith('new_') ? 'PUT' : 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-WP-Nonce': checkinData.nonce,
    },
    body: JSON.stringify(shift),
  })
    .then(async (response) => {
      const data = await response.json();
      if (!response.ok) {
        // Extract error message from response
        const errorMsg =
          data.message || data.data?.message || `HTTP error! Status: ${response.status}`;
        throw new Error(errorMsg);
      }
      return data;
    })
    .then((data) => {
      if (data.success) {
        toastSuccess(data.message);
        // Ẩn nút lưu và hiện nút sửa
        row.querySelector('.save').style.display = 'none';
        row.querySelector('.edit').style.display = 'inline';
        // Vô hiệu hóa các input sau khi lưu
        row.querySelectorAll('input').forEach((input) => {
          input.disabled = true;
        });
        // Vô hiệu hóa các select sau khi lưu (bao gồm branch)
        row.querySelectorAll('select').forEach((select) => {
          select.disabled = true;
        });
        // Cập nhật ID trong bảng nếu là ca mới
        if (shift.id.startsWith('new_')) {
          row.querySelector('.col-id').textContent = data.data?.id || 'N/A';
          row.querySelector('input[name="shift_id[]"]').value = data.data?.id || shift.id;
        }
        fetchShifts();
      } else {
        showError(
          'Lưu thất bại: ' + (data.data?.message || data.message || 'Không có thông tin lỗi')
        );
      }
    })
    .catch((error) => {
      console.error('Error saving shift:', error);
      showError('Đã xảy ra lỗi khi lưu ca: ' + error.message);
    });
}

function createStaffLevelRow(level) {
  const isNew = !level.id;
  const row = document.createElement('tr');
  row.innerHTML = `
        <td class="col-emp-id">
            <input type="hidden" name="staff_level_id[]" value="${
              level.id || 'new_' + newStaffLevelIndex
            }">
            <input type="text" name="staff_id[]" value="${level.staff_id || ''}" disabled>
        </td>
        <td class="col-display">
            <select name="staff_name[]" onchange="updateStaffFields(this)" ${
              isNew ? '' : 'disabled'
            }>
                ${fetchStaffOptions(level.staff_name)}
            </select>
        </td>
        <td class="col-role">
            <input type="text" name="role[]" value="${level.role || ''}" disabled>
        </td>
        <td class="col-status">
            <input type="text" name="status[]" value="${level.status || ''}" disabled>
        </td>
        <td class="col-salary-name">
            <select name="level_name[]" onchange="updateLevelFields(this)" ${
              isNew ? '' : 'disabled'
            }>
                ${fetchLevelOptions(level.level_name, level.staff_name)}
            </select>
        </td>
        <td class="col-start">
            <input type="date" name="start_time[]" value="${
              level.start_time ? level.start_time.split('T')[0] : ''
            }" ${isNew ? '' : 'disabled'}>
        </td>
        <td class="col-end">
            <input type="date" name="end_time[]" value="${
              level.end_time ? level.end_time.split('T')[0] : ''
            }" ${isNew ? '' : 'disabled'}>
        </td>
        <td class="col-condition">
            <input type="text" name="condition[]" value="${level.condition || ''}" ${
              isNew ? '' : 'disabled'
            }>
        </td>
        <td class="col-actions actions">
            <a href="#" class="edit btn-icon" onclick="toggleEditStaffLevelRow(this, '${
              level.id || 'new_' + newStaffLevelIndex
            }'); return false;">✏️</a>
            <a href="#" class="save btn-icon" style="display: none;" onclick="saveStaffLevelRow(this, '${
              level.id || 'new_' + newStaffLevelIndex
            }'); return false;">💾</a>
            <a href="#" class="delete btn-icon" onclick="deleteStaffLevelRow(this, '${
              level.id || 'new_' + newStaffLevelIndex
            }'); return false;">🗑️</a>
        </td>
    `;
  if (!level.id) newStaffLevelIndex++;
  if (level.staff_name) {
    const selectElement = row.querySelector('select[name="staff_name[]"]');
    updateStaffFields(selectElement);
  }
  return row;
}

// Cập nhật updateStaffFields
function updateStaffFields(selectElement) {
  const row = selectElement.closest('tr');
  const staffName = selectElement.value;
  const selectedStaff = staffList.find((staff) => staff.display_name === staffName);
  const staffIdInput = row.querySelector('input[name="staff_id[]"]');
  const roleInput = row.querySelector('input[name="role[]"]');
  const statusInput = row.querySelector('input[name="status[]"]');
  const levelSelect = row.querySelector('select[name="level_name[]"]');

  if (selectedStaff) {
    staffIdInput.value = selectedStaff.employee_id || '';
    roleInput.value = selectedStaff.user_role || '';
    statusInput.value = selectedStaff.status || 'Đang làm việc';
    levelSelect.innerHTML = fetchLevelOptions(levelSelect.value, staffName);
  } else {
    staffIdInput.value = '';
    roleInput.value = '';
    statusInput.value = '';
    levelSelect.innerHTML = '<option value="">--Chưa có cấp lương--</option>';
  }
}

// Cập nhật updateLevelFields
function updateLevelFields(selectElement) {
  const row = selectElement.closest('tr');
  const staffName = row.querySelector('select[name="staff_name[]"]').value;
  const currentLevel = selectElement.value;
  selectElement.innerHTML = fetchLevelOptions(currentLevel, staffName);
}

// Chuyển đổi chế độ sửa
function toggleEditStaffLevelRow(link, id) {
  const row = link.closest('tr');
  const inputs = row.querySelectorAll('input:not([type="hidden"]), select');
  const editBtn = row.querySelector('.edit');
  const saveBtn = row.querySelector('.save');
  inputs.forEach((input) => (input.disabled = false));
  editBtn.style.display = 'none';
  saveBtn.style.display = 'inline-block';
}

// Lưu thay đổi cho một dòng
function saveStaffLevelRow(link, id) {
  const row = link.closest('tr');
  const level = {
    id: row.querySelector('input[name="staff_level_id[]"]').value,
    staff_id: row.querySelector('input[name="staff_id[]"]').value,
    staff_name: row.querySelector('select[name="staff_name[]"]').value,
    role: row.querySelector('input[name="role[]"]').value,
    status: row.querySelector('input[name="status[]"]').value,
    level_name: row.querySelector('select[name="level_name[]"]').value,
    start_time: row.querySelector('input[name="start_time[]"]').value,
    end_time: row.querySelector('input[name="end_time[]"]').value,
    condition: row.querySelector('input[name="condition[]"]').value,
  };

  // Kiểm tra dữ liệu
  if (!level.level_name) {
    showWarning('Vui lòng chọn cấp nhân viên!');
    return;
  }

  const url =
    id && !id.startsWith('new_')
      ? `${checkinData.restUrl}staff-levels/${id}`
      : `${checkinData.restUrl}staff-levels`;
  fetch(url, {
    method: id && !id.startsWith('new_') ? 'PUT' : 'POST',
    headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': checkinData.nonce },
    body: JSON.stringify(level),
  })
    .then((response) => response.json())
    .then((data) => {
      if (!data.success) throw new Error(data.message || 'Lỗi từ server');
      toastSuccess('Lưu cấp nhân viên thành công!');
      fetchStaffLevels(); // Làm mới bảng
      const inputs = row.querySelectorAll('input:not([type="hidden"]), select');
      const editBtn = row.querySelector('.edit');
      const saveBtn = row.querySelector('.save');
      inputs.forEach((input) => (input.disabled = true));
      editBtn.style.display = 'inline-block';
      saveBtn.style.display = 'none';
    })
    .catch((error) => {
      console.error('Error saving staff level:', error);
      showError('Lưu thất bại: ' + error.message);
    });
}

// Xóa một dòng
async function deleteStaffRow(element, staffId) {
  const confirmed = await showConfirm('Bạn có chắc muốn xóa nhân viên này?', 'Xác nhận xóa');
  if (!confirmed) return;

  if (!staffId) {
    element.closest('tr').remove();
    return;
  }

  fetch(`${checkinData.restUrl}staff/${staffId}`, {
    method: 'DELETE',
    headers: {
      'Content-Type': 'application/json',
      'X-WP-Nonce': checkinData.nonce,
    },
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        toastSuccess('Xóa nhân viên thành công!');
        element.closest('tr').remove();
      } else {
        showError('Xóa thất bại: ' + (data.message || 'Không có thông tin lỗi'));
      }
    })
    .catch((error) => {
      console.error('Error deleting staff:', error);
      showError('Lỗi khi xóa nhân viên: ' + error.message);
    });
}

function createStaffRow(staff) {
  const row = document.createElement('tr');
  const currentStatus = staff.status || 'ON';
  // Lấy user_branch (mảng branch_ids) từ staff data
  const userBranchIds = staff.user_branch || staff.branch_ids || [];
  row.innerHTML = `
        <td class="col-avatar"><img src="${staff.avatar || ''}" alt="${
          staff.display_name || ''
        }" style="width: 50px; height: 50px; border-radius: 50%; object-fit: cover;"></td>
        <td class="col-staff-id"><input type="text" name="staff_id[]" value="${
          staff.user_id || ''
        }" disabled></td>
        <td class="col-emp-id"><input type="text" name="employee_id[]" value="${
          staff.employee_id || ''
        }" disabled></td>
        <td class="col-username"><input type="text" name="user_login[]" value="${
          staff.user_login || ''
        }" disabled></td>
        <td class="col-display"><input type="text" name="display_name[]" value="${
          staff.display_name || ''
        }" disabled></td>
        <td class="col-email"><input type="email" name="user_email[]" value="${
          staff.user_email || ''
        }" disabled></td>
        <td class="col-role">
      <select name="role[]" class="role-select" onchange="handleRoleSelect(this)" disabled>
        ${fetchRoleOptions(staff.user_role)}
      </select>
      <div class="role-select-additional">
        <input type="text" class="new-role-input" style="display: none;" placeholder="Nhập vai trò mới">
        <button class="save-new-role" style="display: none;">Lưu</button>
        <button class="cancel-new-role" style="display: none;">Hủy</button>
      </div>
    </td>
    <td class="col-branch" data-staff-id="${staff.user_id || ''}">
          ${getBranchMultiSelectHTML(userBranchIds)}
        </td>
    <td class="col-status">
      <select name="status[]" class="status-select" onchange="handleStatusChange(this, '${
        staff.user_id || ''
      }')" data-staff-id="${staff.user_id || ''}" data-staff-name="${staff.display_name || ''}"
        data-phone="${escapeHtml(staff.phone || '')}">
        <option value="ON" ${currentStatus === 'ON' ? 'selected' : ''}>ON — đang làm</option>
        <option value="OFF" ${currentStatus === 'OFF' ? 'selected' : ''}>OFF — nghỉ hôm nay</option>
        <option value="BUSY" ${currentStatus === 'BUSY' ? 'selected' : ''}>BUSY — đang bận</option>
        <option value="PAUSE" ${
          currentStatus === 'PAUSE' ? 'selected' : ''
        }>PAUSE — tạm dừng (vẫn nhận đặt lịch, hiện SĐT)</option>
        <option value="ARCHIVED" ${
          currentStatus === 'ARCHIVED' ? 'selected' : ''
        }>ARCHIVED — nghỉ việc (ẩn khỏi trang chủ)</option>
        <option value="DELETED" ${
          currentStatus === 'DELETED' ? 'selected' : ''
        }>DELETED — xoá khỏi danh sách</option>
      </select>
    </td>
    <td class="col-actions actions">
      ${staff.display_name ? `<a href="#" class="profile btn-icon" title="Hồ sơ nhân viên" onclick="window.psStaffProfile?.open({ staffName: '${(staff.display_name || '').replace(/'/g, "\\'")}' }); return false;">🪪</a>` : ''}
      <a href="#" class="edit btn-icon" onclick="editStaffRow(this, '${
        staff.user_id || `new_${newStaffIndex - 1}`
      }'); return false;">✏️</a>
      <a href="#" class="save btn-icon" style="display: none;" onclick="saveStaffRow(this, '${
        staff.user_id || `new_${newStaffIndex - 1}`
      }'); return false;">💾</a>
      <a href="#" class="delete btn-icon" onclick="deleteStaffRow(this, '${
        staff.user_id || `new_${newStaffIndex - 1}`
      }'); return false;">🗑️</a>
    </td>
    `;
  return row;
}

function handleRoleSelect(selectElement) {
  const row = selectElement.closest('tr');
  const newRoleInput = row.querySelector('.new-role-input');
  const saveRoleButton = row.querySelector('.save-new-role');
  const cancelRoleButton = row.querySelector('.cancel-new-role');

  if (selectElement.value === 'add_new') {
    selectElement.dataset.originalValue = selectElement.value; // Lưu giá trị ban đầu
    selectElement.style.display = 'none';
    newRoleInput.style.display = 'inline-block';
    saveRoleButton.style.display = 'inline-block';
    cancelRoleButton.style.display = 'inline-block';
  } else {
    selectElement.style.display = 'inline-block';
    newRoleInput.style.display = 'none';
    saveRoleButton.style.display = 'none';
    cancelRoleButton.style.display = 'none';
  }
}

/**
 * Hỏi SĐT khi chuyển thợ sang trạng thái tạm dừng.
 * Trả về object dữ liệu, hoặc null nếu người dùng bấm Huỷ.
 */
async function askPausedPhone(selectElement, staffName) {
  const phone = selectElement.dataset.phone || '';

  const ok = await showCheckinModal({
    type: 'confirm',
    title: `Tạm dừng thợ "${staffName}"`,
    message: `
      <div class="staff-status-form">
        <p class="staff-status-form-note">
          Thợ tạm dừng vẫn hiện ở trang chủ và vẫn nhận đặt lịch. Nhập số điện thoại
          để khách gọi trực tiếp trao đổi trước khi đặt.
        </p>
        <label class="staff-status-form-row">
          <span>Số điện thoại <em>(không bắt buộc)</em></span>
          <input type="tel" id="pausedPhoneInput" value="${escapeHtml(phone)}"
                 placeholder="VD: 0901234567" />
        </label>
      </div>
    `,
    buttons: [
      { text: 'Huỷ', value: false },
      { text: 'Lưu', value: true, type: 'primary' },
    ],
  });

  if (!ok) return null;

  // Modal chỉ ẩn đi chứ không xoá nội dung nên vẫn đọc được input ở đây
  return { phone: document.getElementById('pausedPhoneInput')?.value.trim() || '' };
}

async function handleStatusChange(selectElement, staffId) {
  if (!staffId || staffId.startsWith('new_')) {
    return; // Không xử lý cho nhân viên mới chưa lưu
  }

  const newStatus = selectElement.value;
  const staffName = selectElement.dataset.staffName;
  const oldStatus =
    selectElement.dataset.oldStatus ||
    selectElement.options[selectElement.selectedIndex].defaultSelected;

  // Lưu trạng thái hiện tại trước khi thay đổi
  selectElement.dataset.oldStatus = oldStatus;

  // Tạm dừng thì hỏi SĐT để hiện ở trang chủ
  let extra = {};
  if (newStatus === 'PAUSE') {
    const info = await askPausedPhone(selectElement, staffName);
    if (!info) {
      selectElement.value = oldStatus; // huỷ → trả về trạng thái cũ
      return;
    }
    extra = info;
  }

  // Gọi API để cập nhật trạng thái
  fetch(`${checkinData.restUrl}staff-status`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-WP-Nonce': checkinData.nonce,
    },
    body: JSON.stringify({
      staff_name: staffName,
      status: newStatus,
      ...extra,
    }),
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        toastSuccess(`Đã cập nhật trạng thái "${staffName}" thành ${newStatus}`);
        selectElement.dataset.oldStatus = newStatus; // Cập nhật trạng thái cũ
        if (newStatus === 'PAUSE') {
          selectElement.dataset.phone = extra.phone || '';
        }
      } else {
        showError('Lỗi cập nhật trạng thái: ' + (data.message || 'Không rõ lỗi'));
        // Khôi phục trạng thái cũ nếu lỗi
        selectElement.value = oldStatus;
      }
    })
    .catch((error) => {
      console.error('Error updating status:', error);
      showError('Đã xảy ra lỗi khi cập nhật trạng thái: ' + error.message);
      // Khôi phục trạng thái cũ nếu lỗi
      selectElement.value = oldStatus;
    });
}

function toggleRoleInput(select) {
  const row = select.closest('tr');
  const newRoleInput = row.querySelector('.new-role-input');
  newRoleInput.style.display = select.value === 'other' ? 'inline' : 'none';
}

function editStaffRow(element, staffId) {
  const row = element.closest('tr');
  row.querySelectorAll('input:not([type="hidden"]), select').forEach((input) => {
    input.disabled = false;
  });
  // Mở khóa branch pill select và remove buttons
  row.querySelectorAll('.branch-add-select').forEach((select) => {
    select.disabled = false;
  });
  row.querySelectorAll('.branch-pill-remove').forEach((btn) => {
    btn.disabled = false;
  });
  const roleSelect = row.querySelector('.role-select');
  const newRoleInput = row.querySelector('.new-role-input');
  const saveRoleButton = row.querySelector('.save-new-role');
  if (roleSelect.value === 'add_new') {
    roleSelect.style.display = 'none';
    newRoleInput.style.display = 'inline-block';
    saveRoleButton.style.display = 'inline-block';
  }
  row.querySelector('.edit').style.display = 'none';
  row.querySelector('.save').style.display = 'inline';
}

// Hàm helper để lấy ou_id từ Lark API dựa trên display_name
async function getLarkOuId(displayName) {
  try {
    const response = await fetch(`${checkinData.restUrl}lark/get-member-id`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-WP-Nonce': checkinData.nonce,
      },
      body: JSON.stringify({ display_name: displayName }),
    });
    const data = await response.json();
    if (data.success && data.data && data.data.member_id) {
      return data.data.member_id;
    }
    return null;
  } catch (error) {
    console.error('Error getting Lark ou_id:', error);
    return null;
  }
}

function saveStaffRow(element, staffId) {
  const row = element.closest('tr');
  // Lấy tất cả branch_ids đã chọn từ multi-select
  const branchContainer = row.querySelector('.col-branch');
  const selectedBranchIds = getSelectedBranchIds(branchContainer);

  const staff = {
    user_id: row.querySelector('input[name="staff_id[]"]').value,
    employee_id: row.querySelector('input[name="employee_id[]"]').value,
    user_login: row.querySelector('input[name="user_login[]"]').value,
    display_name: row.querySelector('input[name="display_name[]"]').value,
    user_email: row.querySelector('input[name="user_email[]"]').value,
    user_role:
      row.querySelector('.role-select').value === 'add_new'
        ? row.querySelector('.new-role-input').value
        : row.querySelector('.role-select').value,
    branch_ids: selectedBranchIds, // Gửi mảng branch_ids thay vì branch_id đơn
  };

  if (!staff.display_name || !staff.user_role || !staff.user_login || !staff.user_email) {
    showWarning('Vui lòng điền đầy đủ tên hiển thị, vai trò, tên đăng nhập và email!');
    return;
  }

  // Lấy ou_id từ Lark API trước khi lưu
  getLarkOuId(staff.display_name)
    .then((ouId) => {
      if (ouId) {
        staff.ou_id = ouId;
        console.log(`Found Lark ou_id for ${staff.display_name}: ${ouId}`);
      } else {
        console.warn(`Could not find Lark ou_id for ${staff.display_name}, using default value`);
        staff.ou_id = '1'; // Giá trị mặc định nếu không tìm thấy
      }

      // Kiểm tra và lưu vai trò mới nếu cần
      const saveRolePromise =
        staff.user_role && !roles.includes(staff.user_role)
          ? fetch(`${checkinData.restUrl}roles`, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'X-WP-Nonce': checkinData.nonce,
              },
              body: JSON.stringify({ role_name: staff.user_role }),
            }).then((response) => response.json())
          : Promise.resolve({ success: true });

      return saveRolePromise;
    })
    .then((saveRolePromise) => saveRolePromise)
    .then((roleResponse) => {
      if (!roleResponse.success) {
        throw new Error(roleResponse.message || 'Lỗi khi lưu vai trò mới');
      }
      if (roleResponse.data) {
        roles.push(staff.user_role);
        updateAllRoleSelects();
      }

      // Nếu không có user_id (nhân viên mới), tạo người dùng WordPress trước
      const createUserPromise = !staff.user_id
        ? fetch(`${checkinData.restUrl}create-user`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'X-WP-Nonce': checkinData.nonce,
            },
            body: JSON.stringify({
              user_login: staff.user_login,
              user_email: staff.user_email,
              display_name: staff.display_name,
              user_pass: 'temporary_password_' + Math.random().toString(36).slice(2), // Mật khẩu tạm
            }),
          }).then((response) => response.json())
        : Promise.resolve({ success: true, data: { user_id: staff.user_id } });

      return createUserPromise;
    })
    .then((userResponse) => {
      if (!userResponse.success) {
        throw new Error(userResponse.message || 'Lỗi khi tạo người dùng WordPress');
      }
      staff.user_id = userResponse.data.user_id; // Cập nhật user_id từ phản hồi

      const url = staff.user_id
        ? `${checkinData.restUrl}staff/${staff.user_id}`
        : `${checkinData.restUrl}staff`;
      return fetch(url, {
        method: staff.user_id ? 'PUT' : 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-WP-Nonce': checkinData.nonce,
        },
        body: JSON.stringify(staff),
      });
    })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        toastSuccess('Lưu nhân viên thành công!');
        // Cập nhật DOM của dòng hiện tại
        row.querySelector('input[name="staff_id[]"]').value = data.data.user_id || staff.user_id;
        row.querySelector('input[name="employee_id[]"]').value = staff.employee_id;
        row.querySelector('input[name="user_login[]"]').value = staff.user_login;
        row.querySelector('input[name="display_name[]"]').value = staff.display_name;
        // Cập nhật data-staff-name trên status select để handleStatusChange dùng tên mới
        const statusSelect = row.querySelector('.status-select');
        if (statusSelect) {
          statusSelect.dataset.staffName = staff.display_name;
        }
        row.querySelector('input[name="user_email[]"]').value = staff.user_email;
        row.querySelector('.role-select').innerHTML = fetchRoleOptions(staff.user_role);
        row.querySelectorAll('input:not([type="hidden"]), select').forEach((input) => {
          input.disabled = true;
        });
        // Disable lại các checkbox chi nhánh sau khi lưu
        row.querySelectorAll('.branch-multi-select input[type="checkbox"]').forEach((checkbox) => {
          checkbox.disabled = true;
        });
        row.querySelector('.save').style.display = 'none';
        row.querySelector('.edit').style.display = 'inline';
        row.querySelector('.new-role-input').style.display = 'none';
        row.querySelector('.save-new-role').style.display = 'none';
        row.querySelector('.cancel-new-role').style.display = 'none';
        row.querySelector('.role-select').style.display = 'inline-block';
      } else {
        showError('Lưu thất bại: ' + (data.message || 'Không có thông tin lỗi'));
      }
    })
    .catch((error) => {
      console.error('Error saving staff:', error);
      showError('Lỗi khi lưu nhân viên: ' + error.message);
    });
}

/**
 * Get branch multi-select HTML for salary level settings
 * @param {Array|string} selectedBranchIds - Mảng các branch_id được chọn
 * @param {boolean} isNew - Hàng mới hay không
 * @param {string} salaryId - ID của salary level
 */
function getSalaryLevelBranchMultiSelect(selectedBranchIds = [], isNew = true, salaryId = '') {
  const branches = branchHelper?.allBranches || branchHelper?.branches || locations || [];

  if (!branches || branches.length === 0) {
    return `<div class="salary-branch-pill-select"><span class="no-branch">-- Không có chi nhánh --</span></div>`;
  }

  // Parse selectedBranchIds nếu là string JSON
  let branchIdArray = parseBranchIds(selectedBranchIds);

  // Tạo pills cho các chi nhánh đã chọn
  const selectedPills = branchIdArray
    .map((branchId) => {
      const branch = branches.find((b) => parseInt(b.id || b.branch_id) === branchId);
      if (!branch) return '';
      const branchName = branch.branch_name || branch.location_name || branch.name;
      return `<span class="branch-pill" data-branch-id="${branchId}">
        ${branchName}
        <button type="button" class="branch-pill-remove" onclick="removeSalaryBranchPill(this, ${branchId})" ${
          isNew ? '' : 'disabled'
        }>×</button>
      </span>`;
    })
    .filter((p) => p)
    .join('');

  // Tạo select dropdown để thêm chi nhánh mới
  const availableBranches = branches.filter(
    (b) => !branchIdArray.includes(parseInt(b.id || b.branch_id))
  );

  const selectOptions = availableBranches
    .map((b) => {
      const branchId = b.id || b.branch_id;
      const branchName = b.branch_name || b.location_name || b.name;
      return `<option value="${branchId}">${branchName}</option>`;
    })
    .join('');

  return `
    <div class="salary-branch-pill-select" data-salary-id="${salaryId}">
      <div class="branch-pills-container">
        ${selectedPills || '<span class="no-branch-selected">Chưa chọn chi nhánh</span>'}
      </div>
      <select class="branch-add-select" onchange="addSalaryBranchPill(this)" ${
        isNew ? '' : 'disabled'
      }>
        <option value="">+ Thêm chi nhánh</option>
        ${selectOptions}
      </select>
      <input type="hidden" name="salary_branch_ids_json" value='${JSON.stringify(branchIdArray)}'>
    </div>
  `;
}

/**
 * Thêm branch pill trong salary level settings
 */
function addSalaryBranchPill(selectElement) {
  const branchId = parseInt(selectElement.value);
  if (!branchId) return;

  const container = selectElement.closest('.salary-branch-pill-select');
  const pillsContainer = container.querySelector('.branch-pills-container');
  const hiddenInput = container.querySelector('input[name="salary_branch_ids_json"]');

  // Lấy danh sách branch_ids hiện tại
  let currentIds = JSON.parse(hiddenInput.value || '[]');
  if (currentIds.includes(branchId)) return;

  // Thêm branch mới
  currentIds.push(branchId);
  hiddenInput.value = JSON.stringify(currentIds);

  // Lấy branch name
  const branches = branchHelper?.allBranches || branchHelper?.branches || locations || [];
  const branch = branches.find((b) => parseInt(b.id || b.branch_id) === branchId);
  if (!branch) return;
  const branchName = branch.branch_name || branch.location_name || branch.name;

  // Xóa placeholder nếu có
  const placeholder = pillsContainer.querySelector('.no-branch-selected');
  if (placeholder) placeholder.remove();

  // Thêm pill mới
  const pill = document.createElement('span');
  pill.className = 'branch-pill';
  pill.dataset.branchId = branchId;
  pill.innerHTML = `${branchName}<button type="button" class="branch-pill-remove" onclick="removeSalaryBranchPill(this, ${branchId})">×</button>`;
  pillsContainer.appendChild(pill);

  // Xóa option khỏi select
  const option = selectElement.querySelector(`option[value="${branchId}"]`);
  if (option) option.remove();

  // Reset select
  selectElement.value = '';
}

/**
 * Xóa branch pill trong salary level settings
 */
function removeSalaryBranchPill(button, branchId) {
  const container = button.closest('.salary-branch-pill-select');
  const pillsContainer = container.querySelector('.branch-pills-container');
  const hiddenInput = container.querySelector('input[name="salary_branch_ids_json"]');
  const selectElement = container.querySelector('.branch-add-select');

  // Xóa branch khỏi mảng
  let currentIds = JSON.parse(hiddenInput.value || '[]');
  currentIds = currentIds.filter((id) => id !== branchId);
  hiddenInput.value = JSON.stringify(currentIds);

  // Lấy branch name để thêm lại vào select
  const branches = branchHelper?.allBranches || branchHelper?.branches || locations || [];
  const branch = branches.find((b) => parseInt(b.id || b.branch_id) === branchId);
  if (branch) {
    const branchName = branch.branch_name || branch.location_name || branch.name;
    const option = document.createElement('option');
    option.value = branchId;
    option.textContent = branchName;
    selectElement.appendChild(option);
  }

  // Xóa pill
  const pill = button.closest('.branch-pill');
  pill.remove();

  // Thêm placeholder nếu không còn pill nào
  if (pillsContainer.querySelectorAll('.branch-pill').length === 0) {
    pillsContainer.innerHTML = '<span class="no-branch-selected">Chưa chọn chi nhánh</span>';
  }
}

// Cập nhật createSalaryLevelRow để lấy vai trò từ roles
function createSalaryLevelRow(level) {
  const isNew = !level.id;
  const row = document.createElement('tr');
  // Sử dụng branch_ids (mảng) hoặc fallback về branch_id đơn
  const currentBranchIds = level.branch_ids || (level.branch_id ? [level.branch_id] : []);
  row.innerHTML = `
        <td class="col-salary-name">
            <input type="hidden" name="salary_level_id[]" value="${
              level.id || 'new_' + newSalaryLevelIndex
            }">
            <input type="text" name="level_name[]" value="${level.level_name || ''}" ${
              isNew ? '' : 'disabled'
            }>
        </td>
        <td class="col-branch">
            ${getSalaryLevelBranchMultiSelect(
              currentBranchIds,
              isNew,
              level.id || 'new_' + newSalaryLevelIndex
            )}
        </td>
        <td class="col-role">
            <select name="role[]" class="role-select" onchange="toggleRoleInput(this)" ${
              isNew ? '' : 'disabled'
            }>
                ${fetchRoleOptions(level.role)}
            </select>
            <input type="text" name="new_role[]" class="new-role-input" style="display: none;" placeholder="Nhập vai trò mới">
        </td>
        <td class="col-base-salary"><input type="number" name="base_salary[]" value="${
          level.base_salary || 0
        }" min="0" ${isNew ? '' : 'disabled'}></td>
        <td class="col-service-salary"><input type="number" name="service_salary[]" value="${
          level.service_salary || 0
        }" step="0.01" min="0" max="100" ${isNew ? '' : 'disabled'}></td>
        <td class="col-chemical-salary"><input type="number" name="chemical_salary[]" value="${
          level.chemical_salary || 0
        }" step="0.01" min="0" max="100" ${isNew ? '' : 'disabled'}></td>
        <td class="col-hourly-salary"><input type="number" name="hourly_salary[]" value="${
          level.hourly_salary || 0
        }" min="0" ${isNew ? '' : 'disabled'}></td>
        <td class="col-video-salary"><input type="number" name="video_salary[]" value="${
          level.video_salary || 0
        }" min="0" ${isNew ? '' : 'disabled'}></td>
        <td class="col-actions actions">
            <a href="#" class="edit btn-icon" onclick="toggleEditSalaryLevelRow(this, '${
              level.id || 'new_' + newSalaryLevelIndex
            }'); return false;">✏️</a>
            <a href="#" class="save btn-icon" style="display: none;" onclick="saveSalaryLevelRow(this, '${
              level.id || 'new_' + newSalaryLevelIndex
            }'); return false;">💾</a>
            <a href="#" class="delete btn-icon" onclick="deleteSalaryLevelRow(this, '${
              level.id || 'new_' + newSalaryLevelIndex
            }'); return false;">🗑️</a>
        </td>
    `;
  if (!level.id) newSalaryLevelIndex++;
  return row;
}

// Chuyển đổi chế độ sửa
function toggleEditSalaryLevelRow(link, id) {
  const row = link.closest('tr');
  const inputs = row.querySelectorAll('input:not([type="hidden"]), select');
  const editBtn = row.querySelector('.edit');
  const saveBtn = row.querySelector('.save');
  inputs.forEach((input) => (input.disabled = false));

  // Enable branch pill controls
  const branchPillSelect = row.querySelector('.salary-branch-pill-select');
  if (branchPillSelect) {
    branchPillSelect.querySelectorAll('.branch-pill-remove, .branch-add-select').forEach((el) => {
      el.disabled = false;
    });
  }

  editBtn.style.display = 'none';
  saveBtn.style.display = 'inline-block';
}

// Lưu thay đổi cho một dòng
function saveSalaryLevelRow(link, id) {
  const row = link.closest('tr');
  const branchIdsInput = row.querySelector('input[name="salary_branch_ids_json"]');
  // Lấy branch_ids từ hidden input (mảng JSON)
  const branchIds = branchIdsInput ? JSON.parse(branchIdsInput.value || '[]') : [];

  const level = {
    id: row.querySelector('input[name="salary_level_id[]"]').value,
    level_name: row.querySelector('input[name="level_name[]"]').value,
    role:
      row.querySelector('.role-select').value === 'add_new'
        ? row.querySelector('.new-role-input').value
        : row.querySelector('.role-select').value,
    base_salary: row.querySelector('input[name="base_salary[]"]').value,
    service_salary: row.querySelector('input[name="service_salary[]"]').value,
    chemical_salary: row.querySelector('input[name="chemical_salary[]"]').value,
    hourly_salary: row.querySelector('input[name="hourly_salary[]"]').value,
    video_salary: row.querySelector('input[name="video_salary[]"]').value,
    branch_ids: branchIds, // Sử dụng mảng branch_ids
  };

  // Kiểm tra dữ liệu
  if (!level.level_name || !level.role) {
    showWarning('Vui lòng điền đầy đủ tên cấp bậc và vai trò!');
    return;
  }

  // Lưu vai trò mới trước
  const newRolesPromises =
    level.role && !roles.includes(level.role)
      ? [
          fetch(`${checkinData.restUrl}roles`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': checkinData.nonce },
            body: JSON.stringify({ role_name: level.role }),
          }).then((response) => response.json()),
        ]
      : [];

  Promise.all(newRolesPromises)
    .then((responses) => {
      const failed = responses.find((res) => !res.success);
      if (failed) throw new Error(failed.message || 'Lỗi khi lưu vai trò mới');
      return fetchRoles(); // Cập nhật roles và tất cả <select>
    })
    .then(() => {
      // Lưu cấp lương
      const url =
        id && !id.startsWith('new_')
          ? `${checkinData.restUrl}salary-levels/${id}`
          : `${checkinData.restUrl}salary-levels`;
      fetch(url, {
        method: id && !id.startsWith('new_') ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': checkinData.nonce },
        body: JSON.stringify(level),
      })
        .then((response) => response.json())
        .then((data) => {
          if (!data.success) throw new Error(data.message || 'Lỗi từ server');
          toastSuccess('Lưu cấp lương thành công!');
          fetchSalaryLevels(); // Làm mới bảng
          const inputs = row.querySelectorAll('input:not([type="hidden"]), select');
          const editBtn = row.querySelector('.edit');
          const saveBtn = row.querySelector('.save');
          inputs.forEach((input) => (input.disabled = true));
          editBtn.style.display = 'inline-block';
          saveBtn.style.display = 'none';
        })
        .catch((error) => {
          console.error('Error saving salary level:', error);
          showError('Lưu thất bại: ' + error.message);
        });
    })
    .catch((error) => {
      console.error('Error saving new role:', error);
      showError('Lưu vai trò mới thất bại: ' + error.message);
    });
}

// Xử lý hiển thị/ẩn input khi chọn "Thêm mới"
function toggleRoleInput(selectElement) {
  const row = selectElement.closest('tr');
  const newRoleInput = row.querySelector('.new-role-input');
  if (selectElement.value === 'add_new') {
    selectElement.style.display = 'none';
    newRoleInput.style.display = 'inline-block';
    newRoleInput.focus();
  } else {
    selectElement.style.display = 'inline-block';
    newRoleInput.style.display = 'none';
    newRoleInput.value = '';
  }
}

function toggleStatus(checkbox, id) {
  const card = checkbox.closest('.kpi-card');
  const data = {
    id: id,
    status: checkbox.checked ? 1 : 0,
  };
  fetch(`${checkinData.restUrl}kpi-settings/${id}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      'X-WP-Nonce': checkinData.nonce,
    },
    body: JSON.stringify(data),
  })
    .then((response) => response.json())
    .then((result) => {
      if (!result.success) {
        showError('Lỗi: ' + result.message);
        checkbox.checked = !checkbox.checked; // Rollback nếu thất bại
      }
    })
    .catch((error) => {
      console.error('Error toggling status:', error);
      showError('Lỗi hệ thống');
      checkbox.checked = !checkbox.checked; // Rollback nếu thất bại
    });
}
// === ADD ROW FUNCTIONS ===
function addShiftRow() {
  const tbody = document.getElementById('shift-table-body');
  const newShift = {
    shift_group: 'flexible',
    shift_name: `Ca mới ${newShiftIndex + 1}`,
    start_time: '08:00',
    end_time: '12:00',
    early_checkin: 15,
    late_checkin: 0,
    late_allowed: 0,
    early_checkout: 0,
    late_checkout: 0,
  };
  tbody.appendChild(createShiftRow(newShift));
}

function addStaffRow() {
  const tbody = document.getElementById('staff-table-body');
  const newStaff = {
    employee_id: '',
    user_login: '',
    display_name: '',
    user_email: '',
    user_role: 'Thợ Chính',
    custom_avatar: '',
  };
  tbody.appendChild(createStaffRow(newStaff));
}

function addPenaltyRow() {
  const tbody = document.getElementById('penalty-table-body');
  const row = document.createElement('tr');
  row.innerHTML = `
        <td><input type="text" name="penalty_time_range[]" placeholder="Ví dụ: 5-10"></td>
        <td><input type="number" name="penalty_amount[]" step="1000" min="0" placeholder="Ví dụ: 10000"><span></span></td>
        <td class="actions"><a href="#" class="delete" onclick="deletePenaltyRow(this); return false;">🗑️</a></td>
    `;
  tbody.appendChild(row);
}

function addSalaryLevelRow() {
  const tbody = document.getElementById('salary-level-table-body');
  const newLevel = {
    level_name: `Cấp lương ${newSalaryLevelIndex + 1}`,
    base_salary: 0,
    service_salary: 0,
    chemical_salary: 0,
    hourly_salary: 0,
    video_salary: 0,
  };
  tbody.appendChild(createSalaryLevelRow(newLevel));
}

function addStaffLevelRow() {
  const tbody = document.getElementById('staff-level-table-body');
  const newLevel = {
    staff_id: '',
    staff_name: '',
    role: '',
    status: '',
    level_name: '',
    start_time: '',
    end_time: '',
    condition: '',
  };
  tbody.appendChild(createStaffLevelRow(newLevel));
}

// === DELETE ROW FUNCTIONS ===
function deleteShiftRow(element, shiftId) {
  if (!confirm('Bạn có chắc chắn muốn xóa ca này?')) return;
  if (shiftId.startsWith('new_')) {
    element.closest('tr').remove();
    return;
  }

  fetch(`${checkinData.restUrl}shifts/${shiftId}`, {
    method: 'DELETE',
    headers: { 'X-WP-Nonce': checkinData.nonce },
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      return response.json();
    })
    .then((data) => {
      if (data.success) {
        toastSuccess(data.message);
        element.closest('tr').remove();
      } else {
        showError(
          'Xóa thất bại: ' + (data.data?.message || data.message || 'Không có thông tin lỗi')
        );
      }
    })
    .catch((error) => {
      console.error('Error deleting shift:', error);
      showError('Đã xảy ra lỗi khi xóa ca: ' + error.message);
    });
}

async function deleteStaffRow(element, staffId) {
  const confirmed = await showConfirm('Bạn có chắc chắn muốn xóa nhân viên này?', 'Xác nhận xóa');
  if (!confirmed) return;
  if (staffId.startsWith('new_')) {
    element.closest('tr').remove();
    return;
  }
  fetch(`${checkinData.restUrl}staff/${staffId}`, {
    method: 'DELETE',
    headers: { 'X-WP-Nonce': checkinData.nonce },
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        element.closest('tr').remove();
        toastSuccess('Xóa nhân viên thành công!');
      } else showError('Xóa thất bại: ' + data.message);
    })
    .catch((error) => console.error('Error deleting staff:', error));
}

async function deleteSalaryLevelRow(element, levelId) {
  const confirmed = await showConfirm('Bạn có chắc chắn muốn xóa cấp lương này?', 'Xác nhận xóa');
  if (!confirmed) return;
  if (levelId.startsWith('new_')) {
    element.closest('tr').remove();
    return;
  }
  fetch(`${checkinData.restUrl}salary-levels/${levelId}`, {
    method: 'DELETE',
    headers: { 'X-WP-Nonce': checkinData.nonce },
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        element.closest('tr').remove();
        toastSuccess('Xóa cấp lương thành công!');
        fetchSalaryLevels(); // Cập nhật lại danh sách sau khi xóa
      } else showError('Xóa thất bại: ' + data.message);
    })
    .catch((error) => console.error('Error deleting salary level:', error));
}

async function deleteStaffLevelRow(element, levelId) {
  const confirmed = await showConfirm(
    'Bạn có chắc chắn muốn xóa cấp nhân viên này?',
    'Xác nhận xóa'
  );
  if (!confirmed) return;
  if (levelId.startsWith('new_')) {
    element.closest('tr').remove();
    return;
  }
  fetch(`${checkinData.restUrl}staff-levels/${levelId}`, {
    method: 'DELETE',
    headers: { 'X-WP-Nonce': checkinData.nonce },
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        element.closest('tr').remove();
        toastSuccess('Xóa cấp nhân viên thành công!');
      } else showError('Xóa thất bại: ' + data.message);
    })
    .catch((error) => console.error('Error deleting staff level:', error));
}

async function deleteKpiSettingRow(element, settingId) {
  const confirmed = await showConfirm('Bạn có chắc chắn muốn xóa KPI này?', 'Xác nhận xóa');
  if (!confirmed) return;
  if (settingId.startsWith('new_')) {
    element.closest('tr').remove();
    return;
  }
  fetch(`${checkinData.restUrl}kpi-settings/${settingId}`, {
    method: 'DELETE',
    headers: { 'X-WP-Nonce': checkinData.nonce },
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        element.closest('tr').remove();
        toastSuccess('Xóa KPI thành công!');
      } else showError('Xóa thất bại: ' + data.message);
    })
    .catch((error) => console.error('Error deleting KPI setting:', error));
}

// === Service Management ===
function fetchServices() {
  const params = new URLSearchParams();
  if (currentBranchFilter) params.append('branch_id', currentBranchFilter); // Add branch filter

  return fetch(`${checkinData.restUrl}services?${params.toString()}`, {
    method: 'GET',
    headers: { 'X-WP-Nonce': checkinData.nonce },
  })
    .then((response) => response.json())
    .then((data) => {
      const tbody = document.getElementById('service-table-body');
      tbody.innerHTML = '';
      if (data.success && data.data && data.data.length > 0) {
        data.data.forEach((service, index) => tbody.appendChild(createServiceRow(service, index)));
      } else {
        tbody.innerHTML = `
          <tr>
            <td colspan="9" class="no-data">
              <div>Không có dịch vụ nào.</div>
              <button onclick="addServiceRow()">Tạo mới dịch vụ</button>
            </td>
          </tr>`;
      }
    })
    .catch((error) => {
      console.error('Error fetching services:', error);
      document.getElementById('service-table-body').innerHTML = `
        <tr>
          <td colspan="9" class="no-data">
            <div>Lỗi tải dữ liệu dịch vụ: ${error.message}</div>
            <button onclick="addServiceRow()">Tạo mới dịch vụ</button>
          </td>
        </tr>`;
    });
}

function fetchServiceGroupsForRow(selectElement) {
  return fetch(`${checkinData.restUrl}service-groups`, {
    method: 'GET',
    headers: { 'X-WP-Nonce': checkinData.nonce },
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success && data.data) {
        const currentValue = selectElement.value; // Lưu giá trị hiện tại
        selectElement.innerHTML = `<option value="">--- Chọn nhóm dịch vụ ---</option>
                                 <option value="add_new">Thêm tùy chọn...</option>
                                 ${data.data
                                   .map(
                                     (group) => `
                                   <option value="${group.id}" ${
                                     group.id == currentValue ? 'selected' : ''
                                   }>${group.name}</option>
                                 `
                                   )
                                   .join('')}`;
      }
    })
    .catch((error) => console.error('Error fetching service groups:', error));
}

function createServiceRow(service, index) {
  const row = document.createElement('tr');
  // Sử dụng branch_id thay vì branch name
  const currentBranchId = service.branch_id || '';
  row.innerHTML = `
    <td><input type="text" name="service_id[]" value="${
      service.service_id || `new_${newServiceIndex++}`
    }" disabled></td>
    <td><input type="text" name="service_name[]" value="${
      service.service_name || ''
    }" disabled></td>
    <td class="col-branch"><select name="branch[]" class="branch-select" disabled data-service-id="${
      service.service_id || ''
    }">
          <option value="">-- Chi nhánh --</option>
          ${getBranchOptions(currentBranchId)}
        </select></td>
    <td><select name="service_group_id[]" disabled>
          <option value="">--- Chọn nhóm dịch vụ ---</option>
          <option value="add_new">Thêm tùy chọn...</option>
          ${
            service.service_group_id
              ? `<option value="${service.service_group_id}" selected>${service.service_group}</option>`
              : ''
          }
        </select>
        <div class="group-input" style="display: none;">
          <input type="text" class="new-group-input" placeholder="Nhập tên nhóm mới">
          <button onclick="addNewServiceGroup(this)">Thêm</button>
        </div>
    </td>
    <td><select name="service_type[]" disabled>
          <option value="service" ${
            service.service_type === 'service' ? 'selected' : ''
          }>Service</option>
          <option value="chemical" ${
            service.service_type === 'chemical' ? 'selected' : ''
          }>Chemical</option>
        </select></td>
    <td><input type="text" name="service_price[]" value="${
      service.service_price ? Number(service.service_price).toLocaleString('vi-VN') : ''
    }" disabled></td>
    <td><input type="number" name="sort_order[]" value="${
      service.sort_order || ''
    }" min="0" disabled></td>
    <td><input type="text" name="discounted_price[]" value="${
      service.discounted_price ? Number(service.discounted_price).toLocaleString('vi-VN') : ''
    }" disabled></td>
    <td><input type="text" name="service_description[]" value="${
      service.service_description || ''
    }" disabled></td>
    <td class="actions">
      <a href="#" class="edit-btn" onclick="editServiceRow(this, ${index}); return false;">✏️ Sửa</a>
      <a href="#" class="delete-btn" onclick="deleteServiceRow(this); return false;">🗑️ Xóa</a>
      <a href="#" class="save-btn" style="display: none;" onclick="saveServiceRow(this, ${index}); return false;">💾 Lưu</a>
    </td>`;

  // Thêm sự kiện định dạng giá
  const priceInputs = row.querySelectorAll(
    'input[name="service_price[]"], input[name="discounted_price[]"]'
  );
  priceInputs.forEach((input) => {
    input.addEventListener('blur', (e) => {
      const value = e.target.value.replace(/[^0-9]/g, ''); // Loại bỏ ký tự không phải số
      if (value) {
        e.target.value = Number(value).toLocaleString('vi-VN');
      }
    });
    input.addEventListener('focus', (e) => {
      const value = e.target.value.replace(/[^0-9]/g, '');
      e.target.value = value; // Hiển thị số nguyên khi focus
    });
  });

  row.querySelector('select[name="service_group_id[]"]').addEventListener('change', (e) => {
    const inputDiv = e.target.nextElementSibling;
    if (e.target.value === 'add_new') {
      inputDiv.style.display = 'block';
    } else {
      inputDiv.style.display = 'none';
    }
  });
  return row;
}

function addServiceRow() {
  const tbody = document.getElementById('service-table-body');
  if (tbody.querySelector('.no-data')) {
    tbody.innerHTML = '';
  }
  const row = createServiceRow({}, newServiceIndex);
  tbody.appendChild(row);
  fetchServiceGroupsForRow(row.querySelector('select[name="service_group_id[]"]')); // Load groups cho dòng mới
}

function editServiceRow(element, index) {
  const row = element.closest('tr');
  row.querySelectorAll('input, textarea, select').forEach((input) => (input.disabled = false));
  row.querySelector('.save-btn').style.display = 'inline';
  row.querySelector('.edit-btn').style.display = 'none';
  fetchServiceGroupsForRow(row.querySelector('select[name="service_group_id[]"]')); // Làm mới chỉ select của dòng hiện tại
}

function addNewServiceGroup(button) {
  const row = button.closest('tr');
  const newGroupInput = row.querySelector('.new-group-input');
  const groupName = newGroupInput.value.trim();

  if (!groupName) {
    showWarning('Vui lòng nhập tên nhóm dịch vụ!');
    return;
  }

  fetch(`${checkinData.restUrl}service-groups`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-WP-Nonce': checkinData.nonce,
    },
    body: JSON.stringify({ name: groupName }),
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        toastSuccess('Thêm nhóm dịch vụ thành công!');
        fetchServiceGroupsForRow(row.querySelector('select[name="service_group_id[]"]'));
        row.querySelector('select[name="service_group_id[]"]').value = data.data.id;
        row.querySelector('.group-input').style.display = 'none';
      } else {
        showError('Thêm nhóm thất bại: ' + (data.message || 'Không có thông tin lỗi'));
      }
    })
    .catch((error) => {
      console.error('Error adding service group:', error);
      showError('Lỗi khi thêm nhóm dịch vụ: ' + error.message);
    });
}

function saveServiceRow(element, index) {
  const row = element.closest('tr');
  const select = row.querySelector('select[name="service_group_id[]"]');
  const selectedOption = select.options[select.selectedIndex];
  const branchSelect = row.querySelector('select[name="branch[]"]');
  // Lấy branch_id trực tiếp từ value của select (đã là branch_id)
  const branchId = parseInt(branchSelect?.value) || 0;

  const service = {
    service_name: row.querySelector('input[name="service_name[]"]').value,
    service_group_id: select.value !== '' ? parseInt(select.value) : null,
    service_group: select.value !== '' && select.value !== 'add_new' ? selectedOption.text : null,
    service_type: row.querySelector('select[name="service_type[]"]').value,
    service_price:
      parseFloat(row.querySelector('input[name="service_price[]"]').value.replace(/[^0-9]/g, '')) ||
      0,
    sort_order: row.querySelector('input[name="sort_order[]"]').value,
    discounted_price: row
      .querySelector('input[name="discounted_price[]"]')
      .value.replace(/[^0-9]/g, ''),
    service_description: row.querySelector('input[name="service_description[]"]').value,
    branch_id: branchId, // Sử dụng branch_id trực tiếp
  };

  const serviceId = row.querySelector('input[name="service_id[]"]').value;
  const isNewService = serviceId.startsWith('new_');

  if (!service.service_name) {
    showWarning('Vui lòng nhập tên dịch vụ!');
    return;
  }

  if (service.service_group_id && service.service_group_id === 'add_new') {
    showWarning('Vui lòng chọn hoặc tạo nhóm dịch vụ!');
    return;
  }

  fetch(`${checkinData.restUrl}services${!isNewService ? '/' + serviceId : ''}`, {
    method: isNewService ? 'POST' : 'PUT', // POST cho dịch vụ mới, PUT cho cập nhật
    headers: {
      'Content-Type': 'application/json',
      'X-WP-Nonce': checkinData.nonce,
    },
    body: JSON.stringify(service), // Gửi cả service_group_id, service_group, sort_order, và discounted_price
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        toastSuccess('Lưu dịch vụ thành công!');
        row.querySelectorAll('input, textarea, select').forEach((input) => (input.disabled = true));
        row.querySelector('.save-btn').style.display = 'none';
        row.querySelector('.edit-btn').style.display = 'inline';
        if (isNewService) {
          row.querySelector('input[name="service_id[]"]').value = data.data.service_id; // Cập nhật ID mới từ API
        }
        fetchServices();
      } else {
        showError('Lưu thất bại: ' + (data.message || 'Không có thông tin lỗi'));
      }
    })
    .catch((error) => {
      console.error('Error saving service:', error);
      showError('Lỗi khi lưu dịch vụ: ' + error.message);
    });
}

function deleteServiceRow(element) {
  if (!confirm('Bạn có chắc chắn muốn xóa dịch vụ này?')) return;
  const row = element.closest('tr');
  const serviceId = row.querySelector('input[name="service_id[]"]').value;

  if (serviceId.startsWith('new_')) {
    row.remove();
    if (!document.querySelector('#service-table-body tr')) {
      document.getElementById('service-table-body').innerHTML = `
        <tr>
          <td colspan="9" class="no-data">
            <div>Không có dịch vụ nào.</div>
            <button onclick="addServiceRow()">Tạo mới dịch vụ</button>
          </td>
        </tr>`;
    }
    return;
  }

  fetch(`${checkinData.restUrl}services/${serviceId}`, {
    method: 'DELETE',
    headers: { 'X-WP-Nonce': checkinData.nonce },
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        toastSuccess('Xóa dịch vụ thành công!');
        fetchServices();
      } else {
        showError('Xóa thất bại: ' + (data.message || 'Không có thông tin lỗi'));
      }
    })
    .catch((error) => {
      console.error('Error deleting service:', error);
      showError('Lỗi khi xóa dịch vụ: ' + error.message);
    });
}

// === Service Group Management ===
async function deleteServiceGroup(groupId, selectElement) {
  const confirmed = await showConfirm(
    'Bạn có chắc chắn muốn xóa nhóm dịch vụ này?',
    'Xác nhận xóa'
  );
  if (!confirmed) return;

  fetch(`${checkinData.restUrl}service-groups/${groupId}`, {
    method: 'DELETE',
    headers: { 'X-WP-Nonce': checkinData.nonce },
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        toastSuccess('Xóa nhóm dịch vụ thành công!');
        fetchServiceGroupsForRow(
          document.querySelector(`select[name="service_group_id[]"][value="${groupId}"]`)
        );
      } else {
        showError('Xóa thất bại: ' + (data.message || 'Không có thông tin lỗi'));
      }
    })
    .catch((error) => {
      console.error('Error deleting service group:', error);
      showError('Lỗi khi xóa nhóm dịch vụ: ' + error.message);
    });
}

function editServiceGroup(groupId, selectElement) {
  const newName = prompt('Nhập tên mới cho nhóm dịch vụ:');
  if (!newName) return;

  fetch(`${checkinData.restUrl}service-groups/${groupId}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      'X-WP-Nonce': checkinData.nonce,
    },
    body: JSON.stringify({ name: newName }),
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        toastSuccess('Cập nhật nhóm dịch vụ thành công!');
        fetchServiceGroupsForRow(
          document.querySelector(`select[name="service_group_id[]"][value="${groupId}"]`)
        );
      } else {
        showError('Cập nhật thất bại: ' + (data.message || 'Không có thông tin lỗi'));
      }
    })
    .catch((error) => {
      console.error('Error updating service group:', error);
      showError('Lỗi khi cập nhật nhóm dịch vụ: ' + error.message);
    });
}

// === Product Management ===
function fetchProducts() {
  const params = new URLSearchParams();
  if (currentBranchFilter) params.append('branch_id', currentBranchFilter); // Add branch filter

  return fetch(`${checkinData.restUrl}products?${params.toString()}`, {
    method: 'GET',
    headers: { 'X-WP-Nonce': checkinData.nonce },
  })
    .then((response) => response.json())
    .then((data) => {
      const tbody = document.getElementById('product-table-body');
      tbody.innerHTML = '';
      if (data.success && data.data && data.data.length > 0) {
        data.data.forEach((product, index) => {
          // Rename group_code to product_group để frontend có dữ liệu để hiển thị
          if (product.group_code) {
            product.product_group = product.group_code;
          }
          tbody.appendChild(createProductRow(product, index));
        });
      } else {
        tbody.innerHTML = `
          <tr>
            <td colspan="7" class="no-data">
              <div>Không có sản phẩm nào.</div>
              <button onclick="addProductRow()">Tạo mới sản phẩm</button>
            </td>
          </tr>`;
      }
    })
    .catch((error) => {
      console.error('Error fetching products:', error);
      document.getElementById('product-table-body').innerHTML = `
        <tr>
          <td colspan="7" class="no-data">
            <div>Lỗi tải dữ liệu sản phẩm: ${error.message}</div>
            <button onclick="addProductRow()">Tạo mới sản phẩm</button>
          </td>
        </tr>`;
    });
}

function fetchProductGroupsForRow(selectElement) {
  return fetch(`${checkinData.restUrl}product-groups`, {
    method: 'GET',
    headers: { 'X-WP-Nonce': checkinData.nonce },
  })
    .then((response) => response.json())
    .then((data) => {
      console.log('Product groups response:', data); // Debug response
      if (data.success && data.data) {
        const currentValue = selectElement.value;
        selectElement.innerHTML = `<option value="">--- Chọn nhóm sản phẩm ---</option>
                                 <option value="add_new">Thêm tùy chọn...</option>
                                 ${data.data
                                   .map(
                                     (group) => `
                                   <option value="${group.id}" ${
                                     group.id == currentValue ? 'selected' : ''
                                   }>${group.group_code}</option>
                                 `
                                   )
                                   .join('')}`;
      } else {
        console.error('No product groups data:', data);
      }
    })
    .catch((error) => console.error('Error fetching product groups:', error));
}

function createProductRow(product, index) {
  const row = document.createElement('tr');
  // Sử dụng branch_id thay vì branch name
  const currentBranchId = product.branch_id || '';
  row.innerHTML = `
    <td><input type="text" name="id[]" value="${
      product.id || `new_${newProductIndex++}`
    }" disabled></td>
    <td><input type="text" name="product_name[]" value="${
      product.product_name || ''
    }" disabled></td>
    <td class="col-branch"><select name="branch[]" class="branch-select" disabled data-product-id="${
      product.id || ''
    }">
          <option value="">-- Chi nhánh --</option>
          ${getBranchOptions(currentBranchId)}
        </select></td>
    <td><select name="product_group_id[]" disabled>
          <option value="">--- Chọn nhóm sản phẩm ---</option>
          <option value="add_new">Thêm tùy chọn...</option>
          ${
            product.product_group_id
              ? `<option value="${product.product_group_id}" selected>${product.product_group}</option>`
              : ''
          }
        </select>
        <div class="group-input" style="display: none;">
          <input type="text" class="new-group-input" placeholder="Nhập tên nhóm mới">
          <button onclick="addNewProductGroup(this)">Thêm</button>
        </div>
    </td>
    <td><input type="text" name="price[]" value="${
      product.price ? Number(product.price).toLocaleString('vi-VN') : ''
    }" disabled></td>
    <td><input type="number" name="stock[]" min="0" value="${product.stock || 0}" disabled></td>
    <td><input type="text" name="description[]" value="${product.description || ''}" disabled></td>
    <td class="actions">
      <a href="#" class="edit-btn" onclick="editProductRow(this, ${index}); return false;">✏️ Sửa</a>
      <a href="#" class="delete-btn" onclick="deleteProductRow(this); return false;">🗑️ Xóa</a>
      <a href="#" class="save" style="display: none;" onclick="saveProductRow(this, ${index}); return false;">💾 Lưu</a>
    </td>`;

  // Thêm sự kiện định dạng giá
  const priceInput = row.querySelector('input[name="price[]"]');
  priceInput.addEventListener('blur', (e) => {
    const value = e.target.value.replace(/[^0-9]/g, '');
    if (value) {
      e.target.value = Number(value).toLocaleString('vi-VN');
    }
  });
  priceInput.addEventListener('focus', (e) => {
    const value = e.target.value.replace(/[^0-9]/g, '');
    e.target.value = value;
  });

  // Thêm sự kiện kiểm tra số lượng
  const stockInput = row.querySelector('input[name="stock[]"]');
  stockInput.addEventListener('input', (e) => {
    if (e.target.value < 0) {
      e.target.value = 0;
      showWarning('Số lượng không thể âm!');
    }
  });

  // Xử lý sự kiện thay đổi nhóm sản phẩm
  row.querySelector('select[name="product_group_id[]"]').addEventListener('change', (e) => {
    const inputDiv = e.target.nextElementSibling;
    if (e.target.value === 'add_new') {
      inputDiv.style.display = 'block';
    } else {
      inputDiv.style.display = 'none';
    }
  });

  return row;
}

function addProductRow() {
  const tbody = document.getElementById('product-table-body');
  if (tbody.querySelector('.no-data')) {
    tbody.innerHTML = '';
  }
  const row = createProductRow({}, newProductIndex);
  tbody.appendChild(row);
  fetchProductGroupsForRow(row.querySelector('select[name="product_group_id[]"]'));
}

function editProductRow(element, index) {
  const row = element.closest('tr');
  row.querySelectorAll('input, select').forEach((input) => (input.disabled = false));
  row.querySelector('.save').style.display = 'inline';
  row.querySelector('.edit-btn').style.display = 'none';
  fetchProductGroupsForRow(row.querySelector('select[name="product_group_id[]"]'));
}

function addNewProductGroup(button) {
  const row = button.closest('tr');
  const newGroupInput = row.querySelector('.new-group-input');
  const groupName = newGroupInput.value.trim();

  if (!groupName) {
    showWarning('Vui lòng nhập tên nhóm sản phẩm!');
    return;
  }

  fetch(`${checkinData.restUrl}product-groups`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-WP-Nonce': checkinData.nonce,
    },
    body: JSON.stringify({ name: groupName }),
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        toastSuccess('Thêm nhóm sản phẩm thành công!');
        fetchProductGroupsForRow(row.querySelector('select[name="product_group_id[]"]'));
        row.querySelector('select[name="product_group_id[]"]').value = data.data.id;
        row.querySelector('.group-input').style.display = 'none';
      } else {
        showError('Thêm nhóm thất bại: ' + (data.message || 'Không có thông tin lỗi'));
      }
    })
    .catch((error) => {
      console.error('Error adding product group:', error);
      showError('Lỗi khi thêm nhóm sản phẩm: ' + error.message);
    });
}

function saveProductRow(element, index) {
  const row = element.closest('tr');
  const select = row.querySelector('select[name="product_group_id[]"]');
  const branchSelect = row.querySelector('select[name="branch[]"]');
  // Lấy branch_id trực tiếp từ value của select (đã là branch_id)
  const branchId = parseInt(branchSelect?.value) || 0;

  const product = {
    product_name: row.querySelector('input[name="product_name[]"]').value,
    product_group_id:
      select.value !== '' && select.value !== 'add_new' ? parseInt(select.value) : null,
    price: parseFloat(row.querySelector('input[name="price[]"]').value.replace(/[^0-9]/g, '')) || 0,
    stock: parseInt(row.querySelector('input[name="stock[]"]').value) || 0,
    description: row.querySelector('input[name="description[]"]').value,
    branch_id: branchId, // Sử dụng branch_id trực tiếp
  };

  const id = row.querySelector('input[name="id[]"]').value;
  const isNewProduct = id.startsWith('new_');

  if (!product.product_name) {
    showWarning('Vui lòng nhập tên sản phẩm!');
    return;
  }

  if (product.stock < 0) {
    showWarning('Số lượng không thể âm!');
    return;
  }

  fetch(`${checkinData.restUrl}products${!isNewProduct ? '/' + id : ''}`, {
    method: isNewProduct ? 'POST' : 'PUT',
    headers: {
      'Content-Type': 'application/json',
      'X-WP-Nonce': checkinData.nonce,
    },
    body: JSON.stringify(product),
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        toastSuccess('Lưu sản phẩm thành công!');
        row.querySelectorAll('input, select').forEach((input) => (input.disabled = true));
        row.querySelector('.save').style.display = 'none';
        row.querySelector('.edit-btn').style.display = 'inline';
        if (isNewProduct) {
          row.querySelector('input[name="id[]"]').value = data.data.id;
        }
        fetchProducts();
      } else {
        showError('Lưu thất bại: ' + (data.message || 'Không có thông tin lỗi'));
      }
    })
    .catch((error) => {
      console.error('Error saving product:', error);
      showError('Lỗi khi lưu sản phẩm: ' + error.message);
    });
}

async function deleteProductRow(element) {
  const confirmed = await showConfirm('Bạn có chắc chắn muốn xóa sản phẩm này?', 'Xác nhận xóa');
  if (!confirmed) return;
  const row = element.closest('tr');
  const id = row.querySelector('input[name="id[]"]').value;

  if (id.startsWith('new_')) {
    row.remove();
    if (!document.querySelector('#product-table-body tr')) {
      document.getElementById('product-table-body').innerHTML = `
        <tr>
          <td colspan="7" class="no-data">
            <div>Không có sản phẩm nào.</div>
            <button onclick="addProductRow()">Tạo mới sản phẩm</button>
          </td>
        </tr>`;
    }
    return;
  }

  fetch(`${checkinData.restUrl}products/${id}`, {
    method: 'DELETE',
    headers: { 'X-WP-Nonce': checkinData.nonce },
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        toastSuccess('Xóa sản phẩm thành công!');
        fetchProducts();
      } else {
        showError('Xóa thất bại: ' + (data.message || 'Không có thông tin lỗi'));
      }
    })
    .catch((error) => {
      console.error('Error deleting product:', error);
      showError('Lỗi khi xóa sản phẩm: ' + error.message);
    });
}

// === Product Group Management ===
async function deleteProductGroup(groupId, selectElement) {
  const confirmed = await showConfirm(
    'Bạn có chắc chắn muốn xóa nhóm sản phẩm này?',
    'Xác nhận xóa'
  );
  if (!confirmed) return;

  fetch(`${checkinData.restUrl}product-groups/${groupId}`, {
    method: 'DELETE',
    headers: { 'X-WP-Nonce': checkinData.nonce },
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        toastSuccess('Xóa nhóm sản phẩm thành công!');
        fetchProductGroupsForRow(
          document.querySelector(`select[name="product_group_id[]"][value="${groupId}"]`)
        );
      } else {
        showError('Xóa thất bại: ' + (data.message || 'Không có thông tin lỗi'));
      }
    })
    .catch((error) => {
      console.error('Error deleting product group:', error);
      showError('Lỗi khi xóa nhóm sản phẩm: ' + error.message);
    });
}

function editProductGroup(groupId, selectElement) {
  const newName = prompt('Nhập tên mới cho nhóm sản phẩm:');
  if (!newName) return;

  fetch(`${checkinData.restUrl}product-groups/${groupId}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      'X-WP-Nonce': checkinData.nonce,
    },
    body: JSON.stringify({ name: newName }),
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        toastSuccess('Cập nhật nhóm sản phẩm thành công!');
        fetchProductGroupsForRow(
          document.querySelector(`select[name="product_group_id[]"][value="${groupId}"]`)
        );
      } else {
        showError('Cập nhật thất bại: ' + (data.message || 'Không có thông tin lỗi'));
      }
    })
    .catch((error) => {
      console.error('Error updating product group:', error);
      showError('Lỗi khi cập nhật nhóm sản phẩm: ' + error.message);
    });
}

// === LOCATION FUNCTIONS ===
// (Giữ nguyên phần này)
function fetchLocations() {
  const select = document.getElementById('location-select');
  fetch(`${checkinData.restUrl}locations`, {
    method: 'GET',
    headers: { 'X-WP-Nonce': checkinData.nonce },
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        locations = data.data; // Lưu danh sách chi nhánh vào biến toàn cục
        select.innerHTML = '<option value="">Chọn địa điểm</option>';
        data.data.forEach((location) => {
          const option = document.createElement('option');
          option.value = location.id;
          option.textContent = location.location_name;
          select.appendChild(option);
        });
        updateLocationFields(); // Cập nhật các trường khi danh sách thay đổi
      } else {
        console.error('Failed to fetch locations:', data.data?.message);
        showError(
          'Lỗi khi tải danh sách địa điểm: ' + (data.data?.message || 'Không có thông tin lỗi')
        );
      }
    })
    .catch((error) => {
      console.error('Error fetching locations:', error);
      showError('Đã xảy ra lỗi khi tải danh sách địa điểm!');
    });
}

function toggleBranchMode() {
  const toggle = document.getElementById('branch-mode-toggle');
  const label = document.getElementById('branch-mode-label');
  const commonAddressGroup = document.getElementById('common-address-group');
  const branchManagementSection = document.getElementById('branch-management-section');

  if (toggle.checked) {
    // Bật chế độ chi nhánh
    label.textContent = 'Bật';
    commonAddressGroup.style.display = 'none';
    branchManagementSection.style.display = 'block';
  } else {
    // Tắt chế độ chi nhánh
    label.textContent = 'Tắt';
    commonAddressGroup.style.display = 'block';
    branchManagementSection.style.display = 'none';
  }
}

function addNewLocation() {
  const input = document.getElementById('location-input').value.trim();
  if (!input) {
    showWarning('Vui lòng nhập tên chi nhánh!');
    return;
  }

  fetch(`${checkinData.restUrl}locations`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-WP-Nonce': checkinData.nonce,
    },
    body: JSON.stringify({ location_name: input }),
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        toastSuccess(data.message);
        document.getElementById('location-input').value = '';
        fetchLocations();
      } else {
        showError('Thêm thất bại: ' + (data.data?.message || 'Không có thông tin lỗi'));
      }
    })
    .catch((error) => {
      console.error('Error adding location:', error);
      showError('Đã xảy ra lỗi khi thêm địa điểm!');
    });
}

function updateLocationFields() {
  const select = document.getElementById('location-select');
  const branchNameInput = document.getElementById('branch-name');
  const branchAddressInput = document.getElementById('branch-address');
  const googleMapLinkInput = document.getElementById('google-map-link');
  const latitudeInput = document.getElementById('latitude');
  const longitudeInput = document.getElementById('longitude');
  const radiusInput = document.getElementById('radius');
  const isMainBranchCheckbox = document.getElementById('is-main-branch');

  if (!select.value) {
    branchNameInput.value = '';
    branchAddressInput.value = '';
    googleMapLinkInput.value = '';
    latitudeInput.value = '';
    longitudeInput.value = '';
    radiusInput.value = '50';
    isMainBranchCheckbox.checked = false;
    return;
  }

  fetch(`${checkinData.restUrl}locations/${select.value}`, {
    method: 'GET',
    headers: { 'X-WP-Nonce': checkinData.nonce },
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        branchNameInput.value = data.data.location_name || '';
        branchAddressInput.value = data.data.address || '';
        googleMapLinkInput.value = data.data.google_map_link || '';
        latitudeInput.value = data.data.latitude || '';
        longitudeInput.value = data.data.longitude || '';
        radiusInput.value = data.data.radius || '50';
        isMainBranchCheckbox.checked = data.data.is_main_branch == 1;
      } else {
        console.error('Failed to fetch location:', data.data?.message);
        branchNameInput.value = '';
        branchAddressInput.value = '';
        googleMapLinkInput.value = '';
        latitudeInput.value = '';
        longitudeInput.value = '';
        radiusInput.value = '50';
        isMainBranchCheckbox.checked = false;
        showError(
          'Lỗi khi tải dữ liệu địa điểm: ' + (data.data?.message || 'Không có thông tin lỗi')
        );
      }
    })
    .catch((error) => {
      console.error('Error fetching location data:', error);
      branchNameInput.value = '';
      branchAddressInput.value = '';
      googleMapLinkInput.value = '';
      latitudeInput.value = '';
      longitudeInput.value = '';
      radiusInput.value = '50';
      isMainBranchCheckbox.checked = false;
      showError('Đã xảy ra lỗi khi tải dữ liệu địa điểm!');
    });
}

function saveLocation() {
  const select = document.getElementById('location-select');
  const branchName = document.getElementById('branch-name').value.trim();
  const branchAddress = document.getElementById('branch-address').value.trim();
  const googleMapLink = document.getElementById('google-map-link').value.trim();
  const latitude = document.getElementById('latitude').value.trim();
  const longitude = document.getElementById('longitude').value.trim();
  const radius = document.getElementById('radius').value.trim();
  const isMainBranch = document.getElementById('is-main-branch').checked ? 1 : 0;

  if (!select.value) {
    showWarning('Vui lòng chọn chi nhánh!');
    return;
  }

  if (!branchName || !branchAddress || !latitude || !longitude || !radius) {
    showWarning('Vui lòng nhập đầy đủ thông tin!');
    return;
  }

  const locationData = {
    location_name: branchName,
    address: branchAddress,
    google_map_link: googleMapLink,
    latitude: parseFloat(latitude),
    longitude: parseFloat(longitude),
    radius: parseInt(radius, 10),
    is_main_branch: isMainBranch,
  };

  fetch(`${checkinData.restUrl}locations/${select.value}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      'X-WP-Nonce': checkinData.nonce,
    },
    body: JSON.stringify(locationData),
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        toastSuccess(data.message);
        fetchLocations();
      } else {
        showError(
          'Lưu thất bại: ' + (data.data?.message || data.message || 'Không có thông tin lỗi')
        );
      }
    })
    .catch((error) => {
      console.error('Error saving location:', error);
      showError('Đã xảy ra lỗi khi lưu địa điểm!');
    });
}

async function deleteLocation() {
  const select = document.getElementById('location-select');
  if (!select.value) {
    showWarning('Vui lòng chọn địa điểm để xóa!');
    return;
  }

  const confirmed = await showConfirm('Bạn có chắc chắn muốn xóa địa điểm này?', 'Xác nhận xóa');
  if (!confirmed) return;

  fetch(`${checkinData.restUrl}locations/${select.value}`, {
    method: 'DELETE',
    headers: { 'X-WP-Nonce': checkinData.nonce },
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        toastSuccess(data.message);
        // Clear all fields
        document.getElementById('branch-name').value = '';
        document.getElementById('branch-address').value = '';
        document.getElementById('google-map-link').value = '';
        document.getElementById('latitude').value = '';
        document.getElementById('longitude').value = '';
        document.getElementById('radius').value = '50';
        document.getElementById('is-main-branch').checked = false;
        fetchLocations();
      } else {
        showError(
          'Xóa thất bại: ' + (data.data?.message || data.message || 'Không có thông tin lỗi')
        );
      }
    })
    .catch((error) => {
      console.error('Error deleting location:', error);
      showError('Đã xảy ra lỗi khi xóa địa điểm!');
    });
}

// Hàm lấy danh sách ngày off từ API
async function fetchLeaveRequests(filters = {}) {
  try {
    const params = new URLSearchParams();
    if (filters.start_date) params.append('start_date', filters.start_date);
    if (filters.end_date) params.append('end_date', filters.end_date);
    if (filters.hairdresser_name) params.append('hairdresser_name', filters.hairdresser_name);
    if (currentBranchFilter) params.append('branch_id', currentBranchFilter); // Add branch filter

    const response = await fetch(`${checkinData.restUrl}leave-requests?${params.toString()}`, {
      method: 'GET',
      headers: { 'X-WP-Nonce': checkinData.nonce },
    });
    const result = await response.json();
    if (result.success && result.data) {
      leaveRequests = result.data;
      renderLeaveRequests(leaveRequests);
    } else {
      console.error('Lỗi khi lấy danh sách ngày off:', result.message);
      document.getElementById('leave-requests-table-body').innerHTML = `
        <tr><td colspan="6" class="no-data">Không có dữ liệu ngày off</td></tr>
      `;
    }
  } catch (error) {
    console.error('Lỗi khi lấy danh sách ngày off:', error);
    document.getElementById('leave-requests-table-body').innerHTML = `
      <tr><td colspan="6" class="no-data">Lỗi hệ thống khi tải dữ liệu</td></tr>
    `;
  }
}

// Hàm render bảng danh sách ngày off
function renderLeaveRequests(requests) {
  const tableBody = document.getElementById('leave-requests-table-body');
  if (!tableBody) return;

  if (requests.length === 0) {
    tableBody.innerHTML = `
      <tr><td colspan="6" class="no-data">Không có dữ liệu ngày off</td></tr>
    `;
    return;
  }

  tableBody.innerHTML = requests
    .map(
      (request) => `
        <tr>
          <td>${request.request_id || '-'}</td>
          <td>${request.hairdresser_name}</td>
          <td>${request.leave_start_date}</td>
          <td>${request.leave_end_date}</td>
          <td>${request.leave_total_date}</td>
          <td>${getLeaveStatusDisplay(request.leave_status)}</td>
        </tr>
      `
    )
    .join('');
}

// Hàm hiển thị trạng thái ngày off
function getLeaveStatusDisplay(status) {
  switch (status.toLowerCase()) {
    case 'pending':
      return '<span class="status status-pending">Chờ duyệt</span>';
    case 'approved':
      return '<span class="status status-approved">Đã duyệt</span>';
    case 'rejected':
      return '<span class="status status-rejected">Bị từ chối</span>';
    default:
      return '<span class="status status-unknown">Không xác định</span>';
  }
}

// Hàm tính toán khoảng thời gian dựa trên tab
function getTimeFilterRange(timeType) {
  const today = new Date();
  const formatDate = (date) => date.toISOString().split('T')[0];

  switch (timeType) {
    case 'today':
      return { start_date: formatDate(today), end_date: formatDate(today) };
    case 'future':
      const tomorrow = new Date(today);
      tomorrow.setDate(today.getDate() + 1);
      return { start_date: formatDate(tomorrow), end_date: '' };
    case 'this-month':
      const firstDayThisMonth = new Date(today.getFullYear(), today.getMonth(), 1);
      const lastDayThisMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0);
      return { start_date: formatDate(firstDayThisMonth), end_date: formatDate(lastDayThisMonth) };
    case 'last-month':
      const firstDayLastMonth = new Date(today.getFullYear(), today.getMonth() - 1, 1);
      const lastDayLastMonth = new Date(today.getFullYear(), today.getMonth(), 0);
      return { start_date: formatDate(firstDayLastMonth), end_date: formatDate(lastDayLastMonth) };
    case 'custom':
      return { start_date: '', end_date: '' };
    default:
      return { start_date: '', end_date: '' };
  }
}

// Hàm khởi tạo bộ lọc và sắp xếp
function initializeLeaveRequestsFilters() {
  const filterStaff = document.getElementById('filter-staff');
  const filterStartDate = document.getElementById('filter-start-date');
  const filterEndDate = document.getElementById('filter-end-date');
  const applyFilterBtn = document.getElementById('apply-filter');
  const sortButtons = document.querySelectorAll('.filter-tab');
  const timeTabs = document.querySelectorAll('.time-tab');
  const timeFilterInput = document.querySelector('.time-filter-input');

  // Điền danh sách nhân viên vào select box
  if (filterStaff && staffList.length > 0) {
    filterStaff.innerHTML = `
      <option value="">Tất cả nhân viên</option>
      ${staffList
        .map((staff) => `<option value="${staff.display_name}">${staff.display_name}</option>`)
        .join('')}
    `;
  }

  // Xử lý sự kiện sắp xếp
  sortButtons.forEach((button) => {
    button.addEventListener('click', () => {
      sortButtons.forEach((btn) => btn.classList.remove('active'));
      button.classList.add('active');

      const sortType = button.dataset.sort;
      let sortedRequests = [...leaveRequests];

      if (sortType === 'latest') {
        sortedRequests.sort((a, b) => new Date(b.leave_start_date) - new Date(a.leave_start_date));
      } else if (sortType === 'name') {
        sortedRequests.sort((a, b) => a.hairdresser_name.localeCompare(b.hairdresser_name));
      }

      renderLeaveRequests(sortedRequests);
    });
  });

  // Xử lý sự kiện tab thời gian
  timeTabs.forEach((tab) => {
    tab.addEventListener('click', () => {
      timeTabs.forEach((t) => t.classList.remove('active'));
      tab.classList.add('active');

      currentTimeFilter = tab.dataset.time;
      timeFilterInput.style.display = currentTimeFilter === 'custom' ? 'block' : 'none';

      if (currentTimeFilter !== 'custom') {
        const timeRange = getTimeFilterRange(currentTimeFilter);
        fetchLeaveRequests({
          ...timeRange,
          hairdresser_name: filterStaff.value,
        });
      }
    });
  });

  // Xử lý sự kiện áp dụng bộ lọc
  applyFilterBtn.addEventListener('click', () => {
    const filters = {
      hairdresser_name: filterStaff.value,
    };

    if (currentTimeFilter === 'custom') {
      filters.start_date = filterStartDate.value;
      filters.end_date = filterEndDate.value;

      if (filters.start_date && filters.end_date && filters.start_date > filters.end_date) {
        showWarning('Ngày bắt đầu phải nhỏ hơn hoặc bằng ngày kết thúc!');
        return;
      }
    } else {
      const timeRange = getTimeFilterRange(currentTimeFilter);
      filters.start_date = timeRange.start_date;
      filters.end_date = timeRange.end_date;
    }

    fetchLeaveRequests(filters);
  });
}

// === PENALTY SETTINGS FUNCTIONS ===
// (Giữ nguyên phần này)
function populatePenaltySettings(settings) {
  if (!settings) {
    console.error('No penalty settings data provided');
    return;
  }

  document.getElementById('penalty_enabled').checked = settings.penalty_enabled == 1;
  document.getElementById('fine_amount').value = settings.fine_amount || 0;
  document.getElementById('fine_by_time').checked = settings.fine_by_time == 1;
  document.getElementById('report_enabled').checked = settings.report_enabled == 1;
  document.getElementById('late_count_for_report').value = settings.late_count_for_report || 1;
  document.getElementById('report_penalty_type').value = settings.report_penalty_type || 'fixed';
  document.getElementById('report_penalty_value').value = settings.report_penalty_value || 0;

  const type = settings.report_penalty_type || 'fixed';
  const value = settings.report_penalty_value || 0;
  document.getElementById('report-penalty-value-label').textContent =
    type === 'percent' ? 'Phần trăm lương (%)' : 'Số tiền phạt (VNĐ)';

  const tbody = document.getElementById('penalty-table-body');
  tbody.innerHTML = '';
  JSON.parse(settings.fine_levels || '[]').forEach((level, index) => {
    const row = document.createElement('tr');
    row.innerHTML = `
            <td><input type="text" name="penalty_time_range[]" value="${
              level.range || ''
            }" disabled></td>
            <td><input type="number" name="penalty_amount[]" value="${
              level.amount || 0
            }" step="1000" min="0" disabled><span>${Number(level.amount || 0).toLocaleString(
              'vi-VN'
            )} VNĐ</span></td>
            <td class="actions">
                <a href="#" class="edit" onclick="editPenaltyRow(this, ${index}); return false;">✏️</a>
                <a href="#" class="delete" onclick="deletePenaltyRow(this); return false;">🗑️</a>
                <a href="#" class="save" style="display: none;" onclick="savePenaltyRow(this, ${index}); return false;">💾</a>
            </td>
        `;
    tbody.appendChild(row);
  });

  toggleFineOptions();
  toggleFineByTime();
  toggleReportOptions();
}

function editPenaltyRow(element, index) {
  const row = element.closest('tr');
  const saveButton = row.querySelector('.save');
  const editButton = row.querySelector('.edit');

  // Hiển thị nút lưu và ẩn nút sửa
  saveButton.style.display = 'inline';
  editButton.style.display = 'none';

  // Mở khóa các input
  row.querySelectorAll('input').forEach((input) => {
    input.disabled = false;
  });
}

function savePenaltyRow(element, index) {
  const row = element.closest('tr');
  const timeRange = row.querySelector('input[name="penalty_time_range[]"]').value;
  const amount = parseFloat(row.querySelector('input[name="penalty_amount[]"]').value) || 0;

  if (!timeRange || amount <= 0) {
    showWarning('Vui lòng nhập đầy đủ khoảng thời gian và số tiền phạt hợp lệ!');
    return;
  }

  // Thu thập tất cả fine_levels
  const fineLevels = Array.from(document.querySelectorAll('#penalty-table-body tr')).map((row) => ({
    range: row.querySelector('input[name="penalty_time_range[]"]').value,
    amount: parseFloat(row.querySelector('input[name="penalty_amount[]"]').value) || 0,
  }));

  // Cập nhật fine_level tại index
  fineLevels[index] = { range: timeRange, amount };

  // Thu thập dữ liệu cài đặt phạt
  const settings = {
    penalty_enabled: document.getElementById('penalty_enabled').checked ? 1 : 0,
    fine_amount: parseFloat(document.getElementById('fine_amount').value) || 0,
    fine_by_time: document.getElementById('fine_by_time').checked ? 1 : 0,
    fine_levels: fineLevels,
    report_enabled: document.getElementById('report_enabled').checked ? 1 : 0,
    late_count_for_report: parseInt(document.getElementById('late_count_for_report').value) || 1,
    report_penalty_type: document.getElementById('report_penalty_type').value,
    report_penalty_value: parseFloat(document.getElementById('report_penalty_value').value) || 0,
  };

  fetch(`${checkinData.restUrl}penalty-settings`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-WP-Nonce': checkinData.nonce,
    },
    body: JSON.stringify(settings),
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      return response.json();
    })
    .then((data) => {
      if (data.success) {
        toastSuccess(data.message);
        // Ẩn nút lưu và hiện nút sửa
        row.querySelector('.save').style.display = 'none';
        row.querySelector('.edit').style.display = 'inline';
        // Khóa lại các input
        row.querySelectorAll('input').forEach((input) => {
          input.disabled = true;
        });
        // Cập nhật lại span tiền phạt
        row.querySelector('span').textContent = Number(amount).toLocaleString('vi-VN') + ' VNĐ';
        fetchPenaltySettings();
      } else {
        showError(
          'Lưu thất bại: ' + (data.data?.message || data.message || 'Không có thông tin lỗi')
        );
      }
    })
    .catch((error) => {
      console.error('Error saving penalty settings:', error);
      showError('Đã xảy ra lỗi khi lưu cài đặt phạt: ' + error.message);
    });
}

async function deletePenaltyRow(element) {
  const confirmed = await showConfirm('Bạn có chắc chắn muốn xóa mức phạt này?', 'Xác nhận xóa');
  if (!confirmed) return;
  element.closest('tr').remove();

  // Cập nhật lại fine_levels sau khi xóa
  const fineLevels = Array.from(document.querySelectorAll('#penalty-table-body tr')).map((row) => ({
    range: row.querySelector('input[name="penalty_time_range[]"]').value,
    amount: parseFloat(row.querySelector('input[name="penalty_amount[]"]').value) || 0,
  }));

  const settings = {
    penalty_enabled: document.getElementById('penalty_enabled').checked ? 1 : 0,
    fine_amount: parseFloat(document.getElementById('fine_amount').value) || 0,
    fine_by_time: document.getElementById('fine_by_time').checked ? 1 : 0,
    fine_levels: fineLevels,
    report_enabled: document.getElementById('report_enabled').checked ? 1 : 0,
    late_count_for_report: parseInt(document.getElementById('late_count_for_report').value) || 1,
    report_penalty_type: document.getElementById('report_penalty_type').value,
    report_penalty_value: parseFloat(document.getElementById('report_penalty_value').value) || 0,
  };

  fetch(`${checkinData.restUrl}penalty-settings`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-WP-Nonce': checkinData.nonce,
    },
    body: JSON.stringify(settings),
  })
    .then((response) => {
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      return response.json();
    })
    .then((data) => {
      if (data.success) {
        toastSuccess(data.message);
        fetchPenaltySettings();
      } else {
        showError(
          'Xóa thất bại: ' + (data.data?.message || data.message || 'Không có thông tin lỗi')
        );
      }
    })
    .catch((error) => {
      console.error('Error deleting penalty level:', error);
      showError('Đã xảy ra lỗi khi xóa mức phạt: ' + error.message);
    });
}

function toggleFineOptions() {
  const penaltyEnabled = document.getElementById('penalty_enabled').checked;
  document.getElementById('fine-options').style.display = penaltyEnabled ? 'table-row' : 'none';
  toggleFineByTime();
}

function toggleFineByTime() {
  const fineByTime = document.getElementById('fine_by_time').checked;
  document.getElementById('fine-amount-row').style.display = fineByTime ? 'none' : 'table-row';
  document.getElementById('fine-by-time-row').style.display = fineByTime ? 'table-row' : 'none';
}

function toggleReportOptions() {
  const reportEnabled = document.getElementById('report_enabled').checked;
  document.getElementById('report-options').style.display = reportEnabled ? 'table-row' : 'none';
  document.getElementById('report-penalty-type-row').style.display = reportEnabled
    ? 'table-row'
    : 'none';
  document.getElementById('report-penalty-value-row').style.display = reportEnabled
    ? 'table-row'
    : 'none';
  toggleReportPenaltyValueLabel();
}

function toggleReportPenaltyValueLabel() {
  const type = document.getElementById('report_penalty_type').value;
  document.getElementById('report-penalty-value-label').textContent =
    type === 'percent' ? 'Phần trăm lương (%)' : 'Số tiền phạt (VNĐ)';
}

// === FORM SUBMISSION ===
function handleFormSubmission() {
  const main = document.getElementById('settings-form');
  if (!main || main.dataset.submitBound) return; // gọi 2 lần (đầu trang + sau fetch) chỉ gắn 1 listener
  main.dataset.submitBound = '1';
  main.addEventListener('submit', (e) => {
    e.preventDefault();
    const submitter = e.submitter;
    if (!submitter || !submitter.name) return; // submit ngầm (Enter/nút không type) → chỉ chặn, không xử lý

    if (submitter.name === 'submit_shifts') {
      const shifts = Array.from(document.querySelectorAll('#shift-table-body tr')).map((row) => ({
        id: row.querySelector('input[name="shift_id[]"]').value,
        shift_name: row.querySelector('input[name="shift_name[]"]').value,
        start_time: row.querySelector('input[name="start_time[]"]').value,
        end_time: row.querySelector('input[name="end_time[]"]').value,
        early_checkin: row.querySelector('input[name="early_checkin[]"]').value,
        late_checkin: row.querySelector('input[name="late_checkin[]"]').value,
        late_allowed: row.querySelector('input[name="late_allowed[]"]').value,
        early_checkout: row.querySelector('input[name="early_checkout[]"]').value,
        late_checkout: row.querySelector('input[name="late_checkout[]"]').value,
      }));

      Promise.all(
        shifts.map((shift) =>
          fetch(
            `${checkinData.restUrl}shifts${
              shift.id && !shift.id.startsWith('new_') ? '/' + shift.id : ''
            }`,
            {
              method: shift.id && !shift.id.startsWith('new_') ? 'PUT' : 'POST',
              headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': checkinData.nonce },
              body: JSON.stringify(shift),
            }
          ).then((response) => response.json())
        )
      )
        .then((responses) => {
          const failed = responses.find((res) => !res.success);
          if (failed) throw new Error(failed.message || 'Lỗi khi cập nhật ca làm việc');
          toastSuccess('Cập nhật ca làm việc thành công!');
          fetchShifts();
        })
        .catch((error) => {
          console.error('Error updating shifts:', error);
          showError('Cập nhật thất bại: ' + error.message);
        });
    }

    if (submitter.name === 'submit_services') {
      const services = Array.from(document.querySelectorAll('#service-table-body tr')).map(
        (row) => ({
          id: row.querySelector('input[name="service_id[]"]').value,
          name: row.querySelector('input[name="service_name[]"]').value,
          price: parseFloat(row.querySelector('input[name="service_price[]"]').value) || 0,
          description: row.querySelector('textarea[name="service_description[]"]').value,
        })
      );

      const invalidService = services.find((service) => !service.name);
      if (invalidService) {
        showWarning('Vui lòng điền đầy đủ tên dịch vụ!');
        return;
      }

      Promise.all(
        services.map((service) =>
          fetch(
            `${checkinData.restUrl}services${
              service.id && !service.id.startsWith('new_') ? '/' + service.id : ''
            }`,
            {
              method: service.id && !service.id.startsWith('new_') ? 'PUT' : 'POST',
              headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': checkinData.nonce },
              body: JSON.stringify(service),
            }
          ).then((response) => response.json())
        )
      )
        .then(() => {
          toastSuccess('Cập nhật dịch vụ thành công!');
          fetchServices();
        })
        .catch((error) => {
          console.error('Error updating services:', error);
          showError('Cập nhật thất bại: ' + error.message);
        });
    }

    if (submitter.name === 'submit_products') {
      const products = Array.from(document.querySelectorAll('#product-table-body tr')).map(
        (row) => ({
          id: row.querySelector('input[name="id[]"]').value,
          name: row.querySelector('input[name="product_name[]"]').value,
          price: parseFloat(row.querySelector('input[name="product_price[]"]').value) || 0,
          description: row.querySelector('textarea[name="description[]"]').value,
        })
      );

      const invalidProduct = products.find((product) => !product.name);
      if (invalidProduct) {
        showWarning('Vui lòng điền đầy đủ tên sản phẩm!');
        return;
      }

      Promise.all(
        products.map((product) =>
          fetch(
            `${checkinData.restUrl}products${
              product.id && !product.id.startsWith('new_') ? '/' + product.id : ''
            }`,
            {
              method: product.id && !product.id.startsWith('new_') ? 'PUT' : 'POST',
              headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': checkinData.nonce },
              body: JSON.stringify(product),
            }
          ).then((response) => response.json())
        )
      )
        .then(() => {
          toastSuccess('Cập nhật sản phẩm thành công!');
          fetchProducts();
        })
        .catch((error) => {
          console.error('Error updating products:', error);
          showError('Cập nhật thất bại: ' + error.message);
        });
    }

    if (submitter.name === 'submit_staff') {
      const staffData = Array.from(document.querySelectorAll('#staff-table-body tr')).map(
        (row) => ({
          user_id: row.querySelector('input[name="staff_id[]"]').value,
          employee_id: row.querySelector('input[name="employee_id[]"]').value,
          user_login: row.querySelector('input[name="user_login[]"]').value,
          display_name: row.querySelector('input[name="display_name[]"]').value,
          user_email: row.querySelector('input[name="user_email[]"]').value,
          user_role:
            row.querySelector('.role-select').value === 'add_new'
              ? row.querySelector('.new-role-input').value
              : row.querySelector('.role-select').value,
        })
      );

      const invalidStaff = staffData.find(
        (staff) => !staff.display_name || !staff.user_role || !staff.user_login || !staff.user_email
      );
      if (invalidStaff) {
        showWarning('Vui lòng điền đầy đủ tên hiển thị, vai trò, tên đăng nhập và email!');
        return;
      }

      const newRolesPromises = staffData
        .filter((staff) => staff.user_role && !roles.includes(staff.user_role))
        .map((staff) =>
          fetch(`${checkinData.restUrl}roles`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': checkinData.nonce },
            body: JSON.stringify({ role_name: staff.user_role }),
          }).then((response) => response.json())
        );

      Promise.all(newRolesPromises)
        .then((responses) => {
          const failed = responses.find((res) => !res.success);
          if (failed) throw new Error(failed.message || 'Lỗi khi lưu vai trò mới');
          return fetchRoles();
        })
        .then(() => {
          const staffPromises = staffData.map((staff) => {
            if (staff.user_id) {
              return fetch(`${checkinData.restUrl}staff/${staff.user_id}`, {
                method: 'PUT',
                headers: {
                  'Content-Type': 'application/json',
                  'X-WP-Nonce': checkinData.nonce,
                },
                body: JSON.stringify(staff),
              }).then((response) => response.json());
            } else {
              return fetch(`${checkinData.restUrl}create-user`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': checkinData.nonce },
                body: JSON.stringify({
                  user_login: staff.user_login,
                  user_email: staff.user_email,
                  display_name: staff.display_name,
                  user_pass: 'temporary_password_' + Math.random().toString(36).slice(2),
                }),
              })
                .then((response) => response.json())
                .then((res) => {
                  if (!res.success) throw new Error(res.message || 'Lỗi khi tạo người dùng');
                  staff.user_id = res.data.user_id;
                  return fetch(`${checkinData.restUrl}staff`, {
                    method: 'POST',
                    headers: {
                      'Content-Type': 'application/json',
                      'X-WP-Nonce': checkinData.nonce,
                    },
                    body: JSON.stringify(staff),
                  }).then((response) => response.json());
                });
            }
          });

          return Promise.all(staffPromises);
        })
        .then((responses) => {
          const failed = responses.find((res) => !res.success);
          if (failed) throw new Error(failed.message || 'Lỗi khi lưu nhân viên');
          toastSuccess('Cập nhật nhân viên thành công!');
          const tableBody = document.getElementById('staff-table-body');
          tableBody.innerHTML = '';
          staffData.forEach((staff) => {
            const row = createStaffRow(staff);
            tableBody.appendChild(row);
          });
        })
        .catch((error) => {
          console.error('Error updating staff:', error);
          showError('Cập nhật thất bại: ' + error.message);
        });
    }

    if (submitter.name === 'submit_salary_levels') {
      const levels = Array.from(document.querySelectorAll('#salary-level-table-body tr')).map(
        (row) => ({
          id: row.querySelector('input[name="salary_level_id[]"]').value,
          level_name: row.querySelector('input[name="level_name[]"]').value,
          role:
            row.querySelector('.role-select').value === 'add_new'
              ? row.querySelector('.new-role-input').value
              : row.querySelector('.role-select').value,
          base_salary: row.querySelector('input[name="base_salary[]"]').value,
          service_salary: row.querySelector('input[name="service_salary[]"]').value,
          chemical_salary: row.querySelector('input[name="chemical_salary[]"]').value,
          hourly_salary: row.querySelector('input[name="hourly_salary[]"]').value,
          video_salary: row.querySelector('input[name="video_salary[]"]').value,
        })
      );

      const invalidLevel = levels.find((level) => !level.level_name || !level.role);
      if (invalidLevel) {
        showWarning('Vui lòng điền đầy đủ tên cấp bậc và vai trò!');
        return;
      }

      const newRolesPromises = levels
        .filter((level) => level.role && !roles.includes(level.role))
        .map((level) =>
          fetch(`${checkinData.restUrl}roles`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': checkinData.nonce },
            body: JSON.stringify({ role_name: level.role }),
          }).then((response) => response.json())
        );

      Promise.all(newRolesPromises)
        .then((responses) => {
          const failed = responses.find((res) => !res.success);
          if (failed) throw new Error(failed.message || 'Lỗi khi lưu vai trò mới');
          return fetchRoles();
        })
        .then(() => {
          Promise.all(
            levels.map((level) =>
              fetch(
                `${checkinData.restUrl}salary-levels${
                  level.id && !level.id.startsWith('new_') ? '/' + level.id : ''
                }`,
                {
                  method: level.id && !level.id.startsWith('new_') ? 'PUT' : 'POST',
                  headers: {
                    'Content-Type': 'application/json',
                    'X-WP-Nonce': checkinData.nonce,
                  },
                  body: JSON.stringify(level),
                }
              ).then((response) => response.json())
            )
          )
            .then(() => {
              toastSuccess('Cập nhật cấp lương thành công!');
              fetchSalaryLevels();
            })
            .catch((error) => {
              console.error('Error updating salary levels:', error);
              showError('Cập nhật thất bại: ' + error.message);
            });
        })
        .catch((error) => {
          console.error('Error saving new roles:', error);
          showError('Lưu vai trò mới thất bại: ' + error.message);
        });
    }

    if (submitter.name === 'submit_penalty_settings') {
      const fineLevels = Array.from(document.querySelectorAll('#penalty-table-body tr')).map(
        (row) => ({
          range: row.querySelector('input[name="penalty_time_range[]"]').value,
          amount: row.querySelector('input[name="penalty_amount[]"]').value,
        })
      );
      const penaltySettings = {
        penalty_enabled: document.getElementById('penalty_enabled').checked ? 1 : 0,
        fine_amount: document.getElementById('fine_amount').value,
        fine_by_time: document.getElementById('fine_by_time').checked ? 1 : 0,
        fine_levels: JSON.stringify(fineLevels),
        report_enabled: document.getElementById('report_enabled').checked ? 1 : 0,
        late_count_for_report: document.getElementById('late_count_for_report').value,
        report_penalty_type: document.getElementById('report_penalty_type').value,
        report_penalty_value: document.getElementById('report_penalty_value').value,
      };

      fetch(`${checkinData.restUrl}penalty-settings`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': checkinData.nonce },
        body: JSON.stringify(penaltySettings),
      })
        .then((response) => response.json())
        .then((data) => {
          if (data.success) {
            toastSuccess('Cập nhật cài đặt phạt thành công!');
            fetchPenaltySettings();
          } else {
            showError('Cập nhật thất bại: ' + (data.message || 'Không có thông tin lỗi'));
          }
        })
        .catch((error) => {
          console.error('Error updating penalty settings:', error);
          showError('Cập nhật thất bại: ' + error.message);
        });
    }

    if (submitter.name === 'submit_staff_levels') {
      const levels = Array.from(document.querySelectorAll('#staff-level-table-body tr')).map(
        (row) => ({
          id: row.querySelector('input[name="staff_level_id[]"]').value,
          staff_id: row.querySelector('input[name="staff_id[]"]').value,
          staff_name: row.querySelector('select[name="staff_name[]"]').value,
          role: row.querySelector('input[name="role[]"]').value,
          status: row.querySelector('input[name="status[]"]').value,
          level_name: row.querySelector('select[name="level_name[]"]').value,
          start_time: row.querySelector('input[name="start_time[]"]').value,
          end_time: row.querySelector('input[name="end_time[]"]').value,
          condition: row.querySelector('input[name="condition[]"]').value,
        })
      );

      const invalidLevel = levels.find((level) => !level.level_name);
      if (invalidLevel) {
        showWarning('Vui lòng chọn cấp nhân viên!');
        return;
      }

      Promise.all(
        levels.map((level) =>
          fetch(
            `${checkinData.restUrl}staff-levels${
              level.id && !level.id.startsWith('new_') ? '/' + level.id : ''
            }`,
            {
              method: level.id && !level.id.startsWith('new_') ? 'PUT' : 'POST',
              headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': checkinData.nonce },
              body: JSON.stringify(level),
            }
          ).then((response) => response.json())
        )
      )
        .then(() => {
          toastSuccess('Cập nhật cấp nhân viên thành công!');
          fetchStaffLevels();
        })
        .catch((error) => {
          console.error('Error updating staff levels:', error);
          showError('Cập nhật thất bại: ' + error.message);
        });
    }

    if (submitter.name === 'submit_manager_schedules') {
      const schedules = Array.from(
        document.querySelectorAll('#manager-schedule-table-body tr')
      ).map((row) => {
        const branchSelect = row.querySelector('select[name="branch[]"]');
        // Lấy branch_id trực tiếp từ value của select (đã là branch_id)
        const branchId = parseInt(branchSelect?.value) || 0;
        return {
          staff_name: row.querySelector('select[name="staff_name[]"]').value,
          branch_id: branchId, // Sử dụng branch_id thay vì branch (tên)
          start_date: row.querySelector('input[name="start_date[]"]').value,
          end_date: row.querySelector('input[name="end_date[]"]').value,
        };
      });

      const invalidSchedule = schedules.find(
        (schedule) =>
          !schedule.staff_name || !schedule.branch_id || !schedule.start_date || !schedule.end_date
      );
      if (invalidSchedule) {
        showWarning('Vui lòng điền đầy đủ thông tin lịch làm việc!');
        return;
      }

      fetch(`${checkinData.restUrl}manager-schedules`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': checkinData.nonce },
        body: JSON.stringify(schedules),
      })
        .then((response) => {
          if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
          }
          return response.json();
        })
        .then((data) => {
          if (data.success) {
            toastSuccess('Cập nhật lịch làm việc của Quản Lý thành công!');
            fetchManagerSchedules();
          } else {
            showError('Cập nhật thất bại: ' + (data.message || 'Không có thông tin lỗi'));
          }
        })
        .catch((error) => {
          console.error('Error updating manager schedules:', error);
          showError('Cập nhật thất bại: ' + error.message);
        });
    } else if (submitter.name === 'submit_booking') {
      const bookingData = {
        overtime: {
          start_date: document.getElementById('overtime_start_date').value,
          end_date: document.getElementById('overtime_end_date').value,
          start_time: document.getElementById('overtime_start_time').value,
          end_time: document.getElementById('overtime_end_time').value,
          type: 'overtime',
        },
        holiday: {
          start_date: document.getElementById('special_start_date').value,
          end_date: document.getElementById('special_end_date').value,
          start_time: document.getElementById('special_start_time').value,
          end_time: document.getElementById('special_end_time').value,
          message: document.getElementById('special_message').value,
          type: 'holiday',
        },
        event: {
          start_date: document.getElementById('year_party_date').value,
          start_time: document.getElementById('year_party_time').value,
          type: 'event',
        },
      };

      fetch(`${checkinData.restUrl}booking-settings`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': checkinData.nonce },
        body: JSON.stringify(Object.values(bookingData)),
      })
        .then((response) => {
          if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
          }
          return response.json();
        })
        .then((data) => {
          if (data.success) {
            toastSuccess('Cập nhật cài đặt booking thành công!');
            fetchBookingSettings();
          } else {
            showError('Cập nhật thất bại: ' + (data.message || 'Không có thông tin lỗi'));
          }
        })
        .catch((error) => {
          console.error('Error updating booking settings:', error);
          showError('Cập nhật thất bại: ' + error.message);
        });
    }
  });
}

document.addEventListener('DOMContentLoaded', () => {
  // Fetch staff data to update avatar and display name
  async function fetchCurrentUser() {
    try {
      if (!checkinData || !checkinData.restUrl || !checkinData.nonce) {
        throw new Error('checkinData is not defined or missing required properties');
      }

      const response = await fetch(`${checkinData.restUrl}staff?context=admin`, {
        method: 'GET',
        headers: { 'X-WP-Nonce': checkinData.nonce },
      });

      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }

      const responseData = await response.json();
      if (responseData.success && responseData.data && responseData.data.length > 0) {
        // Assuming the current user is the first in the list or identified by some logic
        // You may need to adjust this to match the actual current user
        const currentUser = responseData.data.find((staff) => staff.status !== 'DELETED'); // Example: First non-deleted user
        if (currentUser) {
          const userAvatar = document.getElementById('userAvatar');
          const headerUserDisplayName = document.getElementById('headerUserDisplayName');

          if (userAvatar && currentUser.avatar) {
            userAvatar.src = currentUser.avatar;
            userAvatar.alt = `Avatar of ${currentUser.display_name}`;
          }

          if (headerUserDisplayName && currentUser.display_name) {
            headerUserDisplayName.textContent = `Hi, ${currentUser.display_name}`;
          }
        } else {
          console.error('No valid user found in staff data');
        }
      } else {
        console.error('No staff data found:', responseData.message);
      }
    } catch (error) {
      console.error('Error fetching current user:', error);
    }
  }

  // Call fetchCurrentUser when the page loads
  fetchCurrentUser();

  // Existing user menu toggle logic
  const userAvatar = document.getElementById('userAvatar');
  const userMenu = document.getElementById('userMenu');

  if (userAvatar && userMenu) {
    userAvatar.addEventListener('click', (e) => {
      e.stopPropagation();
      userMenu.classList.toggle('hidden');
      userMenu.classList.toggle('show');
    });

    document.addEventListener('click', (e) => {
      if (!userMenu.contains(e.target) && !userAvatar.contains(e.target)) {
        userMenu.classList.add('hidden');
        userMenu.classList.remove('show');
      }
    });

    userMenu.querySelectorAll('.user-menu-item').forEach((item) => {
      item.addEventListener('click', () => {
        userMenu.classList.add('hidden');
        userMenu.classList.remove('show');
      });
    });
  }
});

// === ROLES MANAGEMENT FUNCTIONS ===
function renderRolesTable() {
  return fetch(`${checkinData.restUrl}roles`, {
    method: 'GET',
    headers: { 'X-WP-Nonce': checkinData.nonce },
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success && data.data) {
        const tbody = document.getElementById('roles-table-body');
        tbody.innerHTML = '';
        data.data.forEach((role) => tbody.appendChild(createRoleRow(role)));
      } else {
        console.error('Failed to fetch roles:', data.message);
      }
    })
    .catch((error) => console.error('Error fetching roles:', error));
}

function createRoleRow(role) {
  const row = document.createElement('tr');

  // Parse permissions from JSON string if needed
  let permissions = role.permissions || {};
  if (typeof permissions === 'string') {
    try {
      permissions = JSON.parse(permissions);
    } catch (e) {
      console.warn('Failed to parse permissions:', e);
      permissions = {};
    }
  }

  const description = role.description || '';
  const isActive = role.is_active !== false; // default true

  // Get access_permissions (can be array or JSON string)
  let accessPermissions = role.access_permissions || [];
  if (typeof accessPermissions === 'string') {
    try {
      accessPermissions = JSON.parse(accessPermissions);
    } catch (e) {
      console.warn('Failed to parse access_permissions:', e);
      accessPermissions = [];
    }
  }
  // Ensure it's an array
  if (!Array.isArray(accessPermissions)) {
    accessPermissions = [];
  }

  const paidLeaveDays = role.paid_leave_days || 0; // Tính toán quyền tóm gọn
  const totalModules = 20; // Updated: Phase 5 Session 2 added 7 new modules
  const modulesWithPermissions = Object.keys(permissions).length;
  const totalActions = Object.values(permissions).reduce(
    (sum, actions) => sum + (Array.isArray(actions) ? actions.length : 0),
    0
  );

  let permissionSummary = '';
  if (modulesWithPermissions === 0) {
    permissionSummary = '<span class="permission-badge permission-none">Không có quyền</span>';
  } else if (modulesWithPermissions === totalModules && totalActions >= totalModules * 2) {
    permissionSummary = '<span class="permission-badge permission-full">Toàn quyền</span>';
  } else {
    const moduleNames = {
      invoice: 'Hóa đơn',
      booking: 'Booking',
      service: 'Dịch vụ',
      product: 'Sản phẩm',
      staff: 'Nhân viên',
      salary: 'Lương',
      kpi: 'KPI',
      penalty: 'Phạt',
      location: 'Chi nhánh',
      shift: 'Ca làm việc',
      leave: 'Nghỉ phép',
      dashboard: 'Báo cáo',
      role: 'Vai trò',
      schedule: 'Lịch làm việc',
      // Phase 5 Session 2 - New modules
      settings: 'Cài đặt',
      promotion: 'Khuyến mãi',
      inventory: 'Kho hàng',
      product_group: 'Nhóm SP',
      service_group: 'Nhóm DV',
      salary_level: 'Cấp bậc lương',
      staff_level: 'Cấp bậc NV',
      approval_request: 'Đơn xin phép',
    };

    const moduleList = Object.keys(permissions).slice(0, 3);
    permissionSummary = `<span class="permission-badge permission-limited">${moduleList
      .map((m) => moduleNames[m] || m)
      .join(', ')}${modulesWithPermissions > 3 ? '...' : ''}</span>`;
  }

  const statusText = isActive
    ? '<span class="status-active">Đang hoạt động</span>'
    : '<span class="status-inactive">Không hoạt động</span>';

  // Map access permissions to display names
  const accessMap = {
    admin: 'Admin',
    app_tho: 'App Thợ',
    diem_danh: 'Điểm Danh',
    profile: 'Profile',
  };

  const accessDisplay =
    accessPermissions.length > 0
      ? accessPermissions.map((perm) => accessMap[perm] || perm).join(', ')
      : 'Không có';

  row.innerHTML = `
    <td>${role.id}</td>
    <td>${role.role_name}</td>
    <td class="description-cell">${description || 'Không có'}</td>
    <td class="access-cell">${accessDisplay}</td>
    <td>${statusText}</td>
    <td class="actions">
      <button class="btn btn-primary edit-role-btn" onclick="editRole('${
        role.id
      }', '${role.role_name.replace(/'/g, "\\'")}', ${JSON.stringify(permissions).replace(
        /"/g,
        '&quot;'
      )}, '${description.replace(/'/g, "\\'")}', ${isActive}, ${JSON.stringify(
        accessPermissions
      ).replace(/"/g, '&quot;')}, ${paidLeaveDays})">
        <i class="fas fa-edit"></i> Sửa
      </button>
      <button class="btn btn-secondary copy-role-btn" onclick="copyRole('${
        role.id
      }', '${role.role_name.replace(/'/g, "\\'")}', ${JSON.stringify(permissions).replace(
        /"/g,
        '&quot;'
      )}, '${description.replace(/'/g, "\\'")}', ${isActive}, ${JSON.stringify(
        accessPermissions
      ).replace(/"/g, '&quot;')}, ${paidLeaveDays})">
        <i class="fas fa-copy"></i> Sao chép
      </button>
      <button class="btn btn-danger delete-role-btn" onclick="deleteRole('${role.id}')">
        <i class="fas fa-trash"></i> Xóa
      </button>
    </td>
  `;
  return row;
}

function addRoleRow() {
  const tbody = document.getElementById('roles-table-body');
  const row = document.createElement('tr');
  row.innerHTML = `
    <td><input type="text" id="new-role-name" placeholder="Nhập tên vai trò"></td>
    <td>Chưa có quyền</td>
    <td class="actions">
      <button onclick="saveNewRole()">💾 Lưu</button>
      <button onclick="cancelAddRole(this)">❌ Hủy</button>
    </td>
  `;
  tbody.appendChild(row);
  document.getElementById('new-role-name').focus();
}

function saveNewRole() {
  const roleName = document.getElementById('new-role-name').value.trim();
  if (!roleName) {
    showWarning('Vui lòng nhập tên vai trò!');
    return;
  }

  fetch(`${checkinData.restUrl}roles`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-WP-Nonce': checkinData.nonce,
    },
    body: JSON.stringify({ role_name: roleName }),
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        toastSuccess('Thêm vai trò thành công!');
        renderRolesTable();
      } else {
        showError('Thêm vai trò thất bại: ' + (data.message || 'Không có thông tin lỗi'));
      }
    })
    .catch((error) => {
      console.error('Error saving new role:', error);
      showError('Lỗi khi thêm vai trò: ' + error.message);
    });
}

function cancelAddRole(button) {
  button.closest('tr').remove();
}

function editRole(
  roleId,
  roleName,
  permissions,
  description = '',
  isActive = true,
  accessPermissions = [],
  paidLeaveDays = 0
) {
  // Parse permissions from JSON string if needed
  if (typeof permissions === 'string') {
    try {
      permissions = JSON.parse(permissions);
    } catch (e) {
      console.warn('Failed to parse permissions:', e);
      permissions = {};
    }
  }

  // Parse access_permissions from JSON string if needed
  if (typeof accessPermissions === 'string') {
    try {
      accessPermissions = JSON.parse(accessPermissions);
    } catch (e) {
      console.warn('Failed to parse access_permissions:', e);
      accessPermissions = [];
    }
  }
  if (!Array.isArray(accessPermissions)) {
    accessPermissions = [];
  }

  document.getElementById('role-modal').style.display = 'block';
  document.getElementById('role-name').value = roleName;
  document.getElementById('role-description').value = description;
  document.getElementById('role-active').checked = isActive;
  document.getElementById('role-id').value = roleId;
  document.getElementById('role-paid-leave-days').value = paidLeaveDays || 0;
  const title = document.getElementById('role-modal-title');
  if (title) title.textContent = 'Cập nhật vai trò';

  // Set access permissions
  // Nếu là Administrator, Admin, Quản Lý -> tự động tick tất cả trang
  const isAdministrator =
    roleName &&
    (roleName.toLowerCase().includes('admin') ||
      roleName.toLowerCase() === 'administrator' ||
      roleName.toLowerCase() === 'quản trị' ||
      roleName.toLowerCase() === 'quản lý');

  if (isAdministrator) {
    // Luôn tick tất cả 4 trang cho Admin/Quản Lý (dù có hay chưa có accessPermissions)
    accessPermissions = ['admin', 'app_tho', 'diem_danh', 'profile'];
  }

  document.getElementById('access-admin').checked = accessPermissions.includes('admin');
  document.getElementById('access-app-tho').checked = accessPermissions.includes('app_tho');
  document.getElementById('access-diem-danh').checked = accessPermissions.includes('diem_danh');
  document.getElementById('access-profile').checked = accessPermissions.includes('profile');

  // Reset all permissions
  document
    .querySelectorAll('.permission-dropdown input[type="checkbox"]')
    .forEach((cb) => (cb.checked = false));

  // Reset toggle checkboxes
  document.querySelectorAll('.full-access-checkbox').forEach((cb) => (cb.checked = false));
  document.querySelectorAll('.no-access-checkbox').forEach((cb) => (cb.checked = false));

  // Set permissions from data
  if (permissions) {
    Object.entries(permissions).forEach(([module, actions]) => {
      if (Array.isArray(actions)) {
        actions.forEach((action) => {
          const checkbox = document.querySelector(
            `input[data-module="${module}"][data-action="${action}"]`
          );
          if (checkbox) checkbox.checked = true;
        });
      }
    });
  }

  updatePermissionText();
  updatePermissionPills();

  // Initialize module visibility based on access permissions
  setTimeout(() => {
    if (typeof initializeAccessPermissionListeners === 'function') {
      initializeAccessPermissionListeners();
    }
  }, 50);
}

// Mở modal thêm mới vai trò (có thể kèm sao chép quyền)
function openCreateRoleModal(
  initialName = '',
  permissions = {},
  description = '',
  isActive = true,
  accessPermissions = [],
  paidLeaveDays = 0
) {
  // Parse permissions from JSON string if needed
  if (typeof permissions === 'string') {
    try {
      permissions = JSON.parse(permissions);
    } catch (e) {
      console.warn('Failed to parse permissions:', e);
      permissions = {};
    }
  }

  // Parse access_permissions from JSON string if needed
  if (typeof accessPermissions === 'string') {
    try {
      accessPermissions = JSON.parse(accessPermissions);
    } catch (e) {
      console.warn('Failed to parse access_permissions:', e);
      accessPermissions = [];
    }
  }
  if (!Array.isArray(accessPermissions)) {
    accessPermissions = [];
  }

  document.getElementById('role-modal').style.display = 'block';
  document.getElementById('role-name').value = initialName || '';
  document.getElementById('role-description').value = description;
  document.getElementById('role-active').checked = isActive;
  document.getElementById('role-id').value = '';
  document.getElementById('role-paid-leave-days').value = paidLeaveDays || 0;
  const title = document.getElementById('role-modal-title');
  if (title) title.textContent = 'Thêm mới vai trò';

  // Set access permissions
  // Nếu là Administrator, Admin, Quản Lý -> tự động tick tất cả trang
  const isAdministrator =
    initialName &&
    (initialName.toLowerCase().includes('admin') ||
      initialName.toLowerCase() === 'administrator' ||
      initialName.toLowerCase() === 'quản trị' ||
      initialName.toLowerCase() === 'quản lý');

  if (isAdministrator) {
    // Luôn tick tất cả 4 trang cho Admin/Quản Lý (dù có hay chưa có accessPermissions)
    accessPermissions = ['admin', 'app_tho', 'diem_danh', 'profile'];
  }

  document.getElementById('access-admin').checked = accessPermissions.includes('admin');
  document.getElementById('access-app-tho').checked = accessPermissions.includes('app_tho');
  document.getElementById('access-diem-danh').checked = accessPermissions.includes('diem_danh');
  document.getElementById('access-profile').checked = accessPermissions.includes('profile');

  // Reset tất cả checkbox
  document
    .querySelectorAll('.permission-dropdown input[type="checkbox"]')
    .forEach((cb) => (cb.checked = false));
  document.querySelectorAll('.full-access-checkbox').forEach((cb) => (cb.checked = false));
  document.querySelectorAll('.no-access-checkbox').forEach((cb) => (cb.checked = false));

  // Áp permissions nếu có (sao chép)
  if (permissions) {
    Object.entries(permissions).forEach(([module, actions]) => {
      if (Array.isArray(actions)) {
        actions.forEach((action) => {
          const checkbox = document.querySelector(
            `input[data-module="${module}"][data-action="${action}"]`
          );
          if (checkbox) checkbox.checked = true;
        });
      }
    });
  }

  updatePermissionText();
  updatePermissionPills();

  // Initialize module visibility based on access permissions
  setTimeout(() => {
    if (typeof initializeAccessPermissionListeners === 'function') {
      initializeAccessPermissionListeners();
    }
  }, 50);
}

// Tạo bản sao vai trò -> mở modal tạo mới với quyền đã sao chép
function copyRole(
  roleId,
  roleName,
  permissions,
  description,
  isActive,
  accessPermissions,
  paidLeaveDays
) {
  const suggestedName = `${roleName} (sao chép)`;
  openCreateRoleModal(
    suggestedName,
    permissions,
    description,
    isActive,
    accessPermissions,
    paidLeaveDays
  );
}

function saveRoleModal() {
  const roleId = document.getElementById('role-id').value;
  const roleName = document.getElementById('role-name').value.trim();
  const description = document.getElementById('role-description').value.trim();
  const isActive = document.getElementById('role-active').checked;
  const paidLeaveDays = parseInt(document.getElementById('role-paid-leave-days').value) || 0;

  if (!roleName) {
    showWarning('Vui lòng nhập tên vai trò!');
    return;
  }

  // Collect access permissions
  const accessPermissions = [];
  if (document.getElementById('access-admin').checked) accessPermissions.push('admin');
  if (document.getElementById('access-app-tho').checked) accessPermissions.push('app_tho');
  if (document.getElementById('access-diem-danh').checked) accessPermissions.push('diem_danh');
  if (document.getElementById('access-profile').checked) accessPermissions.push('profile');

  // Collect permissions
  const permissions = {};
  const modules = [
    'invoice',
    'booking',
    'service',
    'product',
    'staff',
    'salary',
    'kpi',
    'penalty',
    'location',
    'shift',
    'leave',
    'checkin',
    'customer',
    'payment',
    'review',
    'dashboard',
    'role',
    'schedule',
    // Phase 5 Session 2 - New modules
    'settings',
    'promotion',
    'inventory',
    'product_group',
    'service_group',
    'salary_level',
    'staff_level',
    'approval_request',
  ];

  modules.forEach((module) => {
    const actions = [];
    [
      'view',
      'add',
      'edit',
      'delete',
      'delete_history',
      'view_personal',
      'view_all',
      'penalty',
      'send_message',
      'calculate',
      'confirm',
      'payment',
      'notify',
      'evaluate',
      'reset',
      'set',
      'approve',
      'reject',
      'request',
      'config',
      'manage',
      'record',
      'process',
      'moderate',
      'update_status',
      'resend',
      'check',
      'transaction',
    ].forEach((action) => {
      const checkbox = document.querySelector(
        `input[data-module="${module}"][data-action="${action}"]`
      );
      if (checkbox && checkbox.checked) {
        actions.push(action);
      }
    });
    if (actions.length > 0) {
      permissions[module] = actions;
    }
  });

  const roleData = {
    role_name: roleName,
    description,
    is_active: isActive,
    paid_leave_days: paidLeaveDays,
    access_permissions: accessPermissions,
    permissions,
  };

  // Nếu có roleId => cập nhật, ngược lại => tạo mới
  const isUpdate = !!roleId;
  const url = isUpdate ? `${checkinData.restUrl}roles/${roleId}` : `${checkinData.restUrl}roles`;
  const method = isUpdate ? 'PUT' : 'POST';

  // Thử lưu dạng form-encoded (một số backend custom WP yêu cầu)
  const attemptForm = (payload) => {
    const form = new URLSearchParams();
    if (isUpdate) form.append('id', roleId);
    form.append('role_name', payload.role_name || '');
    form.append('description', payload.description || '');
    form.append('is_active', payload.is_active ? '1' : '0');
    form.append('paid_leave_days', payload.paid_leave_days || '0');
    form.append('access_permissions', JSON.stringify(payload.access_permissions || []));
    form.append(
      'permissions',
      typeof payload.permissions === 'string'
        ? payload.permissions
        : JSON.stringify(payload.permissions || {})
    );

    console.warn('[roles] retry with form-encoded permissions');
    return fetch(url, {
      method,
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'X-WP-Nonce': checkinData.nonce,
        Accept: 'application/json',
      },
      body: form.toString(),
    }).then(async (response) => {
      let data = null;
      try {
        data = await response.clone().json();
      } catch (e) {
        data = { success: false, message: await response.text() };
      }
      if (!response.ok) {
        const msg = data?.message || `HTTP ${response.status}`;
        throw new Error(msg);
      }
      return data;
    });
  };

  // Helper: thử lưu, nếu 500 sẽ fallback string hóa permissions 1 lần, sau đó thử form-encoded
  const attemptSave = (payload, stringifyPermissions = false) => {
    const body = JSON.stringify(
      stringifyPermissions
        ? { ...payload, permissions: JSON.stringify(payload.permissions || {}) }
        : payload
    );

    console.debug('[roles] save attempt', { method, url, stringifyPermissions, payload });

    return fetch(url, {
      method,
      headers: {
        'Content-Type': 'application/json',
        'X-WP-Nonce': checkinData.nonce,
        Accept: 'application/json',
      },
      body,
    }).then(async (response) => {
      let data = null;
      try {
        data = await response.clone().json();
      } catch (e) {
        // not JSON, try text
        data = { success: false, message: await response.text() };
      }

      if (!response.ok) {
        // 500 fallback: thử gửi permissions dạng chuỗi nếu chưa thử, nếu đã thử thì thử form-encoded
        if (response.status === 500) {
          if (!stringifyPermissions) {
            console.warn('[roles] 500 received, retrying with stringified permissions');
            return attemptSave(payload, true);
          } else {
            return attemptForm(payload);
          }
        }

        const msg = data?.message || `HTTP ${response.status}`;
        throw new Error(msg);
      }

      return data;
    });
  };

  attemptSave(roleData)
    .then((data) => {
      if (data && data.success) {
        toastSuccess(isUpdate ? 'Cập nhật vai trò thành công!' : 'Thêm vai trò thành công!');
        closeRoleModal();
        renderRolesTable();
      } else {
        showError(
          (isUpdate ? 'Cập nhật' : 'Thêm') +
            ' thất bại: ' +
            (data?.message || 'Không có thông tin lỗi từ máy chủ')
        );
      }
    })
    .catch((error) => {
      console.error('Error saving role:', error);
      showError(
        'Lỗi khi ' + (isUpdate ? 'cập nhật' : 'thêm') + ' vai trò: ' + (error.message || error)
      );
    });
}

async function deleteRole(roleId) {
  const confirmed = await showConfirm('Bạn có chắc muốn xóa vai trò này?', 'Xác nhận xóa');
  if (!confirmed) return;

  fetch(`${checkinData.restUrl}roles/${roleId}`, {
    method: 'DELETE',
    headers: { 'X-WP-Nonce': checkinData.nonce },
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        toastSuccess('Xóa vai trò thành công!');
        renderRolesTable();
      } else {
        showError('Xóa thất bại: ' + (data.message || 'Không có thông tin lỗi'));
      }
    })
    .catch((error) => {
      console.error('Error deleting role:', error);
      showError('Lỗi khi xóa vai trò: ' + error.message);
    });
}

function togglePermissionDropdown(moduleName) {
  const dropdown = document.getElementById(`${moduleName}-dropdown`);
  if (!dropdown) return; // Safety check

  const isActive = dropdown.classList.contains('active');

  // Close all dropdowns
  document.querySelectorAll('.permission-dropdown').forEach((d) => d.classList.remove('active'));

  // Toggle current dropdown
  if (!isActive) {
    dropdown.classList.add('active');
  }
}

function updatePermissionText() {
  const modules = [
    'invoice',
    'booking',
    'service',
    'product',
    'staff',
    'salary',
    'kpi',
    'penalty',
    'location',
    'shift',
    'leave',
    'checkin',
    'customer',
    'payment',
    'review',
    'dashboard',
    'role',
    'schedule',
    // Phase 5 Session 2 - New modules
    'settings',
    'promotion',
    'inventory',
    'product_group',
    'service_group',
    'salary_level',
    'staff_level',
    'approval_request',
  ];

  modules.forEach((module) => {
    const allModuleCheckboxes = Array.from(
      document.querySelectorAll(`.permission-dropdown input[data-module="${module}"]`)
    ).filter(
      (cb) =>
        !cb.classList.contains('full-access-checkbox') &&
        !cb.classList.contains('no-access-checkbox')
    );

    const checkedModuleCheckboxes = allModuleCheckboxes.filter((cb) => cb.checked);

    const btn = document.querySelector(
      `button[onclick*="togglePermissionDropdown"][onclick*="'${module}'"]`
    );
    if (btn) {
      let text = 'Không có quyền';
      if (
        checkedModuleCheckboxes.length === allModuleCheckboxes.length &&
        allModuleCheckboxes.length > 0
      ) {
        text = 'Toàn quyền';
      } else if (checkedModuleCheckboxes.length > 0) {
        text = `Đã chọn ${checkedModuleCheckboxes.length}`;
      }
      btn.querySelector('span').textContent = text;
    }

    // Sync toggle checkboxes
    const fullAccess = document.querySelector(`.full-access-checkbox[data-module="${module}"]`);
    const noAccess = document.querySelector(`.no-access-checkbox[data-module="${module}"]`);
    if (fullAccess) {
      fullAccess.checked =
        allModuleCheckboxes.length > 0 &&
        checkedModuleCheckboxes.length === allModuleCheckboxes.length;
    }
    if (noAccess) {
      noAccess.checked = checkedModuleCheckboxes.length === 0;
    }
  });
}

function updatePermissionPills() {
  const modules = [
    'invoice',
    'booking',
    'service',
    'product',
    'staff',
    'salary',
    'kpi',
    'penalty',
    'location',
    'shift',
    'leave',
    'checkin',
    'customer',
    'payment',
    'review',
    'zalo',
    'dashboard',
    'role',
    'schedule',
    // Phase 5 Session 2 - New modules
    'settings',
    'promotion',
    'inventory',
    'product_group',
    'service_group',
    'salary_level',
    'staff_level',
    'staff_level',
    'approval_request',
  ];

  const actionLabels = {
    view: 'Xem',
    add: 'Thêm',
    edit: 'Sửa',
    delete: 'Xóa',
    view_personal: 'Xem CN',
    view_all: 'Xem tất cả',
    charge: 'Truy thu',
    penalty: 'Truy thu',
    send_message: 'Gửi tin',
    calculate: 'Tính lương',
    confirm: 'Xác nhận',
    payment: 'Thanh toán',
    notify: 'Thông báo',
    evaluate: 'Đánh giá',
    reset: 'Reset',
    set: 'Thiết lập',
    approve: 'Duyệt',
    request: 'Đăng ký',
    config: 'Cấu hình',
    manage: 'Quản lý',
    record: 'Chấm công',
    process: 'Xử lý',
    moderate: 'Kiểm duyệt',
    update_status: 'Cập nhật TT',
    resend: 'Gửi lại',
    check: 'Kiểm kê',
    transaction: 'Xuất/Nhập',
    reject: 'Từ chối',
  };

  modules.forEach((module) => {
    // Tập tất cả action checkbox của module
    const allActionCheckboxes = Array.from(
      document.querySelectorAll(
        `input[data-module="${module}"]:not(.full-access-checkbox):not(.no-access-checkbox)`
      )
    );
    const selectedActions = [];
    [
      'view',
      'add',
      'edit',
      'delete',
      'view_personal',
      'view_all',
      'penalty',
      'send_message',
      'calculate',
      'confirm',
      'payment',
      'notify',
      'evaluate',
      'reset',
      'set',
      'delete_history',
      'approve',
      'reject',
      'request',
      'config',
      'manage',
      'record',
      'process',
      'moderate',
      'update_status',
      'resend',
      'check',
      'transaction',
    ].forEach((action) => {
      const checkbox = document.querySelector(
        `input[data-module="${module}"][data-action="${action}"]`
      );
      if (checkbox && checkbox.checked) {
        selectedActions.push(actionLabels[action] || action);
      }
    });

    const pillsContainer = document.getElementById(`${module}-pills`);
    if (pillsContainer) {
      pillsContainer.innerHTML = '';
      pillsContainer.dataset.module = module;

      const isFullAccess =
        allActionCheckboxes.length > 0 && selectedActions.length === allActionCheckboxes.length;

      if (isFullAccess) {
        const pill = document.createElement('span');
        pill.className = 'permission-pill permission-pill--full';
        pill.textContent = 'Toàn quyền';
        pillsContainer.appendChild(pill);
      } else if (selectedActions.length === 0) {
        const pill = document.createElement('span');
        pill.className = 'permission-pill permission-pill--none';
        pill.textContent = 'Không có quyền';
        pillsContainer.appendChild(pill);
      } else {
        selectedActions.forEach((label) => {
          const pill = document.createElement('span');
          pill.className = 'permission-pill';
          pill.textContent = label;
          const removeBtn = document.createElement('span');
          removeBtn.className = 'pill-remove';
          removeBtn.textContent = '×';
          removeBtn.onclick = (e) => {
            e.stopPropagation();
            const actionKey = Object.keys(actionLabels).find((key) => actionLabels[key] === label);
            const checkbox = document.querySelector(
              `input[data-module="${module}"][data-action="${actionKey}"]`
            );
            if (checkbox) {
              checkbox.checked = false;
              updatePermissionPills();
              updatePermissionText();
            }
          };
          pill.appendChild(removeBtn);
          pillsContainer.appendChild(pill);
        });
      }
    }
  });
}

function closeRoleModal() {
  document.getElementById('role-modal').style.display = 'none';
  document.getElementById('role-name').value = '';
  document.getElementById('role-description').value = '';
  document.getElementById('role-active').checked = true;
  document.getElementById('role-id').value = '';
  const title = document.getElementById('role-modal-title');
  if (title) title.textContent = 'Thêm mới vai trò';

  // Reset access permissions
  document.getElementById('access-admin').checked = false;
  document.getElementById('access-app-tho').checked = false;
  document.getElementById('access-diem-danh').checked = false;
  document.getElementById('access-profile').checked = false;

  document
    .querySelectorAll('.permission-dropdown input[type="checkbox"]')
    .forEach((cb) => (cb.checked = false));
  document.querySelectorAll('.permission-dropdown').forEach((d) => d.classList.remove('active'));
  // Reset permission text
  const modules = [
    'invoice',
    'booking',
    'service',
    'product',
    'staff',
    'salary',
    'kpi',
    'penalty',
    'location',
    'shift',
    'leave',
    'checkin',
    'customer',
    'payment',
    'review',
    'dashboard',
    'role',
    'schedule',
    // Phase 5 Session 2 - New modules
    'settings',
    'promotion',
    'inventory',
    'product_group',
    'service_group',
    'salary_level',
    'staff_level',
    'approval_request',
  ];
  modules.forEach((module) => {
    const span = document.getElementById(`${module}-text`);
    if (span) {
      span.textContent = 'Không có quyền';
    }
    const pillsContainer = document.getElementById(`${module}-pills`);
    if (pillsContainer) {
      pillsContainer.innerHTML = '';
    }
  });
}

// Initialize permission event listeners
document.addEventListener('DOMContentLoaded', () => {
  // Add event listeners for permission checkboxes (individual actions)
  document
    .querySelectorAll(
      '.permission-dropdown input[type="checkbox"]:not(.full-access-checkbox):not(.no-access-checkbox)'
    )
    .forEach((checkbox) => {
      checkbox.addEventListener('change', (e) => {
        const module = e.target.dataset.module;
        // When any action changes, ensure "No access" is unchecked if any action is checked
        const anyChecked = Array.from(
          document.querySelectorAll(
            `.permission-dropdown input[data-module="${module}"]:not(.full-access-checkbox):not(.no-access-checkbox)`
          )
        ).some((cb) => cb.checked);
        const noAccess = document.querySelector(`.no-access-checkbox[data-module="${module}"]`);
        if (noAccess) noAccess.checked = !anyChecked;

        updatePermissionText();
        updatePermissionPills();
      });
    });

  // Add event listeners for "Toàn quyền" checkboxes
  document.querySelectorAll('.full-access-checkbox').forEach((checkbox) => {
    checkbox.addEventListener('change', (e) => {
      const module = e.target.dataset.module;
      const isChecked = e.target.checked;

      // Get all action checkboxes for this module
      const moduleCheckboxes = document.querySelectorAll(
        `input[data-module="${module}"]:not(.full-access-checkbox):not(.no-access-checkbox)`
      );

      moduleCheckboxes.forEach((cb) => {
        cb.checked = isChecked;
      });

      // Uncheck no-access when full access is toggled on
      const noAccess = document.querySelector(`.no-access-checkbox[data-module="${module}"]`);
      if (noAccess && isChecked) noAccess.checked = false;

      updatePermissionText();
      updatePermissionPills();
    });
  });

  // Add event listeners for "Không có quyền" checkboxes
  document.querySelectorAll('.no-access-checkbox').forEach((checkbox) => {
    checkbox.addEventListener('change', (e) => {
      const module = e.target.dataset.module;
      const isChecked = e.target.checked;

      // Uncheck all actions and full-access if "no access" is checked
      const moduleCheckboxes = document.querySelectorAll(
        `input[data-module="${module}"]:not(.no-access-checkbox):not(.full-access-checkbox)`
      );
      if (isChecked) {
        moduleCheckboxes.forEach((cb) => (cb.checked = false));
        const fullAccess = document.querySelector(`.full-access-checkbox[data-module="${module}"]`);
        if (fullAccess) fullAccess.checked = false;
      }

      updatePermissionText();
      updatePermissionPills();
    });
  });

  // Cho phép click vào hàng pills để mở lại menu (đối với mọi module)
  document.querySelectorAll('.permission-pills').forEach((container) => {
    container.addEventListener('click', (e) => {
      // Bỏ qua nếu click vào nút xóa pill
      if (e.target && e.target.classList.contains('pill-remove')) return;
      const id = container.getAttribute('id') || '';
      const module = id.replace('-pills', '');
      if (module) {
        togglePermissionDropdown(module);
      }
    });
  });

  // Đóng menu quyền khi click ra ngoài
  document.addEventListener('click', (e) => {
    const insideSelector = e.target.closest('.permission-selector');
    if (!insideSelector) {
      document
        .querySelectorAll('.permission-dropdown.active')
        .forEach((d) => d.classList.remove('active'));
    }
  });

  // Initialize character counter for role description
  const roleDescTextarea = document.getElementById('role-description');
  if (roleDescTextarea) {
    roleDescTextarea.addEventListener('input', updateCharacterCount);
    // Initialize count on load
    updateCharacterCount();
  }
});

// ============================================
// MODERN INPUT UTILITY FUNCTIONS
// ============================================

/**
 * Tăng số ngày nghỉ có phép
 */
function increasePaidLeaveDays() {
  const input = document.getElementById('role-paid-leave-days');
  const currentValue = parseInt(input.value) || 0;
  const maxValue = parseInt(input.getAttribute('max')) || 365;

  if (currentValue < maxValue) {
    input.value = currentValue + 1;
    // Trigger input validation if exists
    input.dispatchEvent(new Event('input', { bubbles: true }));
  }
}

/**
 * Giảm số ngày nghỉ có phép
 */
function decreasePaidLeaveDays() {
  const input = document.getElementById('role-paid-leave-days');
  const currentValue = parseInt(input.value) || 0;
  const minValue = parseInt(input.getAttribute('min')) || 0;

  if (currentValue > minValue) {
    input.value = currentValue - 1;
    // Trigger input validation if exists
    input.dispatchEvent(new Event('input', { bubbles: true }));
  }
}

/**
 * Cập nhật bộ đếm ký tự cho textarea mô tả vai trò
 */
function updateCharacterCount() {
  const textarea = document.getElementById('role-description');
  const charCountElement = document.querySelector('.char-count');

  if (!textarea || !charCountElement) return;

  const currentLength = textarea.value.length;
  const maxLength = parseInt(textarea.getAttribute('maxlength')) || 500;
  const remaining = maxLength - currentLength;

  // Update text
  charCountElement.textContent = `${currentLength}/${maxLength}`;

  // Update styling based on remaining characters
  charCountElement.classList.remove('warning', 'danger');

  if (remaining <= 50 && remaining > 20) {
    charCountElement.classList.add('warning');
  } else if (remaining <= 20) {
    charCountElement.classList.add('danger');
  }

  // Add visual feedback when limit reached
  if (remaining === 0) {
    textarea.classList.add('shake');
    setTimeout(() => textarea.classList.remove('shake'), 500);
  }
}

// ============================================
// SEND SALARY NOTIFICATION FUNCTIONALITY
// ============================================

/**
 * Khởi tạo nút gửi phiếu lương
 */
function initSendSalaryNotificationButton() {
  const sendBtn = document.getElementById('send-salary-notification-btn');
  if (!sendBtn) return;

  // Kiểm tra trạng thái đã gửi từ localStorage
  checkNotificationSentStatus();

  // Click vào nút sẽ mở modal thay vì gửi trực tiếp
  sendBtn.addEventListener('click', openSalaryNotificationModal);

  // Khởi tạo modal events
  initSalaryNotificationModal();
}

/**
 * Khởi tạo modal gửi thông báo lương
 */
function initSalaryNotificationModal() {
  const modal = document.getElementById('salary-notification-modal');
  if (!modal) return;

  const closeBtn = modal.querySelector('.salary-modal-close');
  const cancelBtn = document.getElementById('notification-cancel-btn');
  const confirmBtn = document.getElementById('notification-confirm-btn');
  const cashierToggle = document.getElementById('notify-cashier-toggle');
  const hairdresserToggle = document.getElementById('notify-hairdresser-toggle');

  // Close modal events
  closeBtn?.addEventListener('click', closeSalaryNotificationModal);
  cancelBtn?.addEventListener('click', closeSalaryNotificationModal);
  modal.addEventListener('click', (e) => {
    if (e.target === modal) closeSalaryNotificationModal();
  });

  // Toggle events
  cashierToggle?.addEventListener('change', () => {
    toggleRoleSelection('cashier', cashierToggle.checked);
    updateNotificationSummary();
  });

  hairdresserToggle?.addEventListener('change', () => {
    toggleRoleSelection('hairdresser', hairdresserToggle.checked);
    updateNotificationSummary();
  });

  // Confirm button
  confirmBtn?.addEventListener('click', handleConfirmSendNotification);

  // ESC key to close
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modal.classList.contains('show')) {
      closeSalaryNotificationModal();
    }
  });
}

/**
 * Mở modal gửi thông báo lương
 */
function openSalaryNotificationModal() {
  const modal = document.getElementById('salary-notification-modal');
  const yearSelect = document.getElementById('year-select');
  const monthSelect = document.getElementById('month-select');

  if (!modal || !yearSelect || !monthSelect) return;

  // Cập nhật period display
  const periodDisplay = document.getElementById('notification-period-display');
  if (periodDisplay) {
    periodDisplay.textContent = `${monthSelect.value}/${yearSelect.value}`;
  }

  // Render branch pills
  renderBranchPills();

  // Reset toggles trước
  const cashierToggle = document.getElementById('notify-cashier-toggle');
  const hairdresserToggle = document.getElementById('notify-hairdresser-toggle');
  if (cashierToggle) {
    cashierToggle.checked = true;
    cashierToggle.disabled = false;
  }
  if (hairdresserToggle) {
    hairdresserToggle.checked = true;
    hairdresserToggle.disabled = false;
  }

  // Reset role sent states
  document.querySelectorAll('.notification-role-item').forEach((item) => {
    item.classList.remove('sent');
  });
  document.querySelectorAll('.branch-pill').forEach((pill) => {
    pill.classList.remove('sent');
  });

  // Reset role states
  toggleRoleSelection('cashier', true);
  toggleRoleSelection('hairdresser', true);

  // Render history và đánh dấu đã gửi
  renderNotificationHistory();

  // Update summary
  updateNotificationSummary();

  // Show modal
  modal.classList.add('show');
  document.body.style.overflow = 'hidden';
}

/**
 * Đóng modal
 */
function closeSalaryNotificationModal() {
  const modal = document.getElementById('salary-notification-modal');
  if (!modal) return;

  modal.classList.remove('show');
  document.body.style.overflow = '';
}

/**
 * Toggle hiển thị branch select cho role
 */
function toggleRoleSelection(role, enabled) {
  const roleItem = document.querySelector(`.notification-role-item[data-role="${role}"]`);
  if (!roleItem) return;

  if (enabled) {
    roleItem.classList.remove('disabled');
  } else {
    roleItem.classList.add('disabled');
  }
}

/**
 * Render branch pills cho cả 2 roles
 */
function renderBranchPills() {
  const branches = branchHelper?.allBranches || branchHelper?.branches || [];
  const isMultiBranch = checkinData?.isMultiBranchEnabled || branches.length > 1;

  const cashierContainer = document.getElementById('cashier-branch-container');
  const hairdresserContainer = document.getElementById('hairdresser-branch-container');
  const cashierPills = document.getElementById('cashier-branch-pills');
  const hairdresserPills = document.getElementById('hairdresser-branch-pills');

  // Ẩn branch selection nếu không có đa chi nhánh
  if (!isMultiBranch || branches.length === 0) {
    if (cashierContainer) cashierContainer.style.display = 'none';
    if (hairdresserContainer) hairdresserContainer.style.display = 'none';
    return;
  }

  // Hiển thị branch selection
  if (cashierContainer) cashierContainer.style.display = 'block';
  if (hairdresserContainer) hairdresserContainer.style.display = 'block';

  // Tạo pills HTML
  const createPillsHTML = (prefix) => {
    let html = `
      <div class="branch-pill all-branches selected" data-branch-id="all" data-prefix="${prefix}">
        <span class="pill-check"><i class="fas fa-check"></i></span>
        <span>Tất cả chi nhánh</span>
      </div>
    `;

    branches.forEach((branch) => {
      const branchId = branch.id || branch.branch_id;
      const branchName = branch.branch_name || branch.location_name || `Chi nhánh ${branchId}`;
      html += `
        <div class="branch-pill" data-branch-id="${branchId}" data-prefix="${prefix}">
          <span class="pill-check"><i class="fas fa-check"></i></span>
          <span>${branchName}</span>
        </div>
      `;
    });

    return html;
  };

  if (cashierPills) {
    cashierPills.innerHTML = createPillsHTML('cashier');
    attachPillEvents(cashierPills);
  }

  if (hairdresserPills) {
    hairdresserPills.innerHTML = createPillsHTML('hairdresser');
    attachPillEvents(hairdresserPills);
  }
}

/**
 * Attach click events cho pills
 */
function attachPillEvents(container) {
  const pills = container.querySelectorAll('.branch-pill');

  pills.forEach((pill) => {
    pill.addEventListener('click', () => {
      const branchId = pill.dataset.branchId;
      const prefix = pill.dataset.prefix;
      const allPills = container.querySelectorAll('.branch-pill');

      if (branchId === 'all') {
        // Chọn "Tất cả" thì bỏ chọn các chi nhánh riêng lẻ
        allPills.forEach((p) => {
          if (p.dataset.branchId === 'all') {
            p.classList.add('selected');
          } else {
            p.classList.remove('selected');
          }
        });
      } else {
        // Chọn chi nhánh riêng lẻ
        const allBranchPill = container.querySelector('[data-branch-id="all"]');
        allBranchPill?.classList.remove('selected');

        pill.classList.toggle('selected');

        // Nếu không có pill nào được chọn, tự động chọn lại "Tất cả"
        const selectedPills = container.querySelectorAll(
          '.branch-pill.selected:not([data-branch-id="all"])'
        );
        if (selectedPills.length === 0) {
          allBranchPill?.classList.add('selected');
        }
      }

      updateNotificationSummary();
    });
  });
}

/**
 * Lấy các branch đã chọn cho role
 */
function getSelectedBranches(role) {
  const container = document.getElementById(`${role}-branch-pills`);
  if (!container) return [];

  const allSelected = container.querySelector('[data-branch-id="all"].selected');
  if (allSelected) return []; // Trả về mảng rỗng nghĩa là tất cả

  const selectedPills = container.querySelectorAll(
    '.branch-pill.selected:not([data-branch-id="all"])'
  );
  return Array.from(selectedPills).map((pill) => pill.dataset.branchId);
}

/**
 * Cập nhật summary text
 */
function updateNotificationSummary() {
  const summaryText = document.getElementById('notification-summary-text');
  const summaryContainer = summaryText?.parentElement;
  if (!summaryText) return;

  const cashierToggle = document.getElementById('notify-cashier-toggle');
  const hairdresserToggle = document.getElementById('notify-hairdresser-toggle');

  // Kiểm tra nếu toggle bị disabled (đã gửi hết)
  const cashierDisabled = cashierToggle?.disabled;
  const hairdresserDisabled = hairdresserToggle?.disabled;

  const cashierEnabled = cashierToggle?.checked && !cashierDisabled;
  const hairdresserEnabled = hairdresserToggle?.checked && !hairdresserDisabled;

  const confirmBtn = document.getElementById('notification-confirm-btn');

  // Nếu cả hai đều đã gửi hết
  if (cashierDisabled && hairdresserDisabled) {
    summaryText.textContent = 'Đã gửi thông báo cho tất cả nhân viên trong kỳ này';
    summaryContainer?.classList.add('all-sent');
    if (confirmBtn) confirmBtn.disabled = true;
    return;
  }

  summaryContainer?.classList.remove('all-sent');

  if (!cashierEnabled && !hairdresserEnabled) {
    summaryText.textContent = 'Vui lòng chọn ít nhất một vai trò để gửi thông báo';
    if (confirmBtn) confirmBtn.disabled = true;
    return;
  }

  if (confirmBtn) confirmBtn.disabled = false;

  const parts = [];
  const branches = branchHelper?.allBranches || branchHelper?.branches || [];
  const isMultiBranch = checkinData?.isMultiBranchEnabled || branches.length > 1;

  if (cashierEnabled) {
    const cashierBranches = getSelectedBranches('cashier');
    if (!isMultiBranch || cashierBranches.length === 0) {
      parts.push('Tất cả Thu Ngân');
    } else {
      const branchNames = cashierBranches.map((id) => {
        const branch = branches.find((b) => String(b.id || b.branch_id) === String(id));
        return branch?.branch_name || branch?.location_name || `Chi nhánh ${id}`;
      });
      parts.push(`Thu Ngân (${branchNames.join(', ')})`);
    }
  }

  if (hairdresserEnabled) {
    const hairdresserBranches = getSelectedBranches('hairdresser');
    if (!isMultiBranch || hairdresserBranches.length === 0) {
      parts.push('Tất cả Thợ');
    } else {
      const branchNames = hairdresserBranches.map((id) => {
        const branch = branches.find((b) => String(b.id || b.branch_id) === String(id));
        return branch?.branch_name || branch?.location_name || `Chi nhánh ${id}`;
      });
      parts.push(`Thợ (${branchNames.join(', ')})`);
    }
  }

  summaryText.textContent = `Sẽ gửi thông báo cho: ${parts.join(' và ')}`;
}

/**
 * Lấy history từ localStorage
 */
function getNotificationHistory(period) {
  const key = `salary_notification_history_${period}`;
  const data = localStorage.getItem(key);
  return data ? JSON.parse(data) : [];
}

/**
 * Lưu history vào localStorage
 */
function saveNotificationHistory(period, historyItem) {
  const key = `salary_notification_history_${period}`;
  const history = getNotificationHistory(period);
  history.push(historyItem);
  localStorage.setItem(key, JSON.stringify(history));
}

/**
 * Render history trong modal
 */
function renderNotificationHistory() {
  const yearSelect = document.getElementById('year-select');
  const monthSelect = document.getElementById('month-select');
  if (!yearSelect || !monthSelect) return;

  const period = `${yearSelect.value}-${monthSelect.value.padStart(2, '0')}`;
  const history = getNotificationHistory(period);

  const historyContainer = document.getElementById('notification-history');
  const historyList = document.getElementById('notification-history-list');

  if (!historyContainer || !historyList) return;

  if (history.length === 0) {
    historyContainer.classList.remove('has-history');
    return;
  }

  historyContainer.classList.add('has-history');

  historyList.innerHTML = history
    .map((item) => {
      const roleBadges = item.roles
        .map((role) => {
          const roleName = role === 'cashier' ? 'Thu Ngân' : 'Thợ';
          return `<span class="history-role-badge">${roleName}</span>`;
        })
        .join('');

      return `
      <div class="history-item">
        <div class="history-item-info">
          <i class="fas fa-check-circle"></i>
          <div class="history-item-roles">${roleBadges}</div>
        </div>
        <span class="history-item-time">${item.time}</span>
      </div>
    `;
    })
    .join('');

  // Mark sent roles/branches
  markSentRolesAndBranches(history);
}

/**
 * Đánh dấu vai trò và chi nhánh đã gửi
 */
function markSentRolesAndBranches(history) {
  const sentRoles = new Set();
  const sentBranches = {
    cashier: new Set(),
    hairdresser: new Set(),
  };

  history.forEach((item) => {
    item.roles.forEach((role) => {
      const branches = item.branchFilters?.[role] || [];
      if (branches.length === 0 || branches.includes('all')) {
        // Gửi tất cả chi nhánh = đánh dấu role đã gửi hoàn toàn
        sentRoles.add(role);
      } else {
        branches.forEach((branchId) => sentBranches[role].add(String(branchId)));
      }
    });
  });

  // Disable sent roles
  ['cashier', 'hairdresser'].forEach((role) => {
    const roleItem = document.querySelector(`.notification-role-item[data-role="${role}"]`);
    const toggle = document.getElementById(`notify-${role}-toggle`);

    if (sentRoles.has(role)) {
      roleItem?.classList.add('sent');
      if (toggle) {
        toggle.checked = false;
        toggle.disabled = true;
      }
    } else {
      roleItem?.classList.remove('sent');
      if (toggle) toggle.disabled = false;
    }
  });

  // Disable sent branches
  ['cashier', 'hairdresser'].forEach((role) => {
    const pillsContainer = document.getElementById(`${role}-branch-pills`);
    if (!pillsContainer) return;

    const pills = pillsContainer.querySelectorAll('.branch-pill');
    pills.forEach((pill) => {
      const branchId = pill.dataset.branchId;
      if (branchId !== 'all' && sentBranches[role].has(branchId)) {
        pill.classList.add('sent');
        pill.classList.remove('selected');
      } else {
        pill.classList.remove('sent');
      }
    });
  });
}

/**
 * Xử lý xác nhận gửi thông báo
 */
async function handleConfirmSendNotification() {
  const yearSelect = document.getElementById('year-select');
  const monthSelect = document.getElementById('month-select');
  const cashierToggle = document.getElementById('notify-cashier-toggle');
  const hairdresserToggle = document.getElementById('notify-hairdresser-toggle');
  const confirmBtn = document.getElementById('notification-confirm-btn');

  if (!yearSelect || !monthSelect) return;

  const period = `${yearSelect.value}-${monthSelect.value.padStart(2, '0')}`;

  // Collect data
  const roles = [];
  const branchFilters = {};

  if (cashierToggle?.checked) {
    roles.push('cashier');
    branchFilters.cashier = getSelectedBranches('cashier');
  }

  if (hairdresserToggle?.checked) {
    roles.push('hairdresser');
    branchFilters.hairdresser = getSelectedBranches('hairdresser');
  }

  if (roles.length === 0) {
    showWarning('Vui lòng chọn ít nhất một vai trò');
    return;
  }

  // Set loading state
  if (confirmBtn) {
    confirmBtn.classList.add('loading');
    confirmBtn.disabled = true;
    confirmBtn.innerHTML = '<i class="fas fa-spinner"></i> Đang gửi...';
  }

  try {
    const response = await fetch(`${checkinData.restUrl}send-salary-notification`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-WP-Nonce': checkinData.nonce,
      },
      body: JSON.stringify({
        period: period,
        roles: roles,
        branch_filters: branchFilters,
      }),
    });

    const data = await response.json();

    if (response.ok && data.success) {
      // Lưu history
      const now = new Date();
      const timeStr = now.toLocaleString('vi-VN', {
        hour: '2-digit',
        minute: '2-digit',
        day: '2-digit',
        month: '2-digit',
      });
      saveNotificationHistory(period, {
        roles: roles,
        branchFilters: branchFilters,
        time: timeStr,
        count: data.count || 0,
      });

      // Render lại branch pills để cập nhật trạng thái
      renderBranchPills();

      // Refresh history và disable đã gửi
      renderNotificationHistory();

      // Cập nhật summary
      updateNotificationSummary();

      // Hiển thị thông báo thành công
      toastSuccess(`Đã gửi thông báo phiếu lương cho ${data.count || 0} nhân viên thành công!`);
    } else {
      if (data.already_sent) {
        showInfo(data.message);
      } else {
        throw new Error(data.message || 'Không thể gửi thông báo');
      }
    }
  } catch (error) {
    console.error('Error sending salary notification:', error);
    showError(`Lỗi: ${error.message}`);
  } finally {
    // Reset button state
    if (confirmBtn) {
      confirmBtn.classList.remove('loading');
      confirmBtn.disabled = false;
      confirmBtn.innerHTML = '<i class="fas fa-paper-plane"></i> Gửi Thông Báo';
    }
  }
}

/**
 * Kiểm tra trạng thái đã gửi thông báo (từ server)
 */
async function checkNotificationSentStatus() {
  const sendBtn = document.getElementById('send-salary-notification-btn');
  if (!sendBtn) return;

  const yearSelect = document.getElementById('year-select');
  const monthSelect = document.getElementById('month-select');

  if (!yearSelect || !monthSelect) return;

  const period = `${yearSelect.value}-${monthSelect.value.padStart(2, '0')}`;

  try {
    const response = await fetch(
      `${checkinData.restUrl}check-salary-notification-status?period=${period}`,
      {
        headers: {
          'X-WP-Nonce': checkinData.nonce,
        },
      }
    );

    const data = await response.json();

    if (data.success && data.sent) {
      updateButtonToSentState(sendBtn, data.sent_at);
    } else {
      updateButtonToDefaultState(sendBtn);
    }
  } catch (error) {
    console.error('Error checking notification status:', error);
    updateButtonToDefaultState(sendBtn);
  }
}

/**
 * Cập nhật nút sang trạng thái "Đã thông báo" - vẫn cho phép bấm tiếp
 */
function updateButtonToSentState(btn, sentAt) {
  btn.classList.remove('loading');
  btn.classList.add('sent');
  // Không disable nút - vẫn cho phép bấm để gửi thêm
  btn.disabled = false;
  btn.innerHTML = '<i class="fas fa-paper-plane"></i><span class="btn-text">Gửi Thông Báo</span>';
  btn.title = 'Mở modal gửi thông báo phiếu lương';
}

/**
 * Cập nhật nút sang trạng thái mặc định
 */
function updateButtonToDefaultState(btn) {
  btn.classList.remove('sent', 'loading');
  btn.disabled = false;
  btn.innerHTML = '<i class="fas fa-paper-plane"></i><span class="btn-text">Gửi Thông Báo</span>';
  btn.title = 'Gửi thông báo phiếu lương cho nhân viên';
}

/**
 * Xử lý gửi thông báo phiếu lương
 */
async function handleSendSalaryNotification() {
  const sendBtn = document.getElementById('send-salary-notification-btn');
  const yearSelect = document.getElementById('year-select');
  const monthSelect = document.getElementById('month-select');

  if (!yearSelect || !monthSelect) {
    showWarning('Vui lòng chọn tháng/năm');
    return;
  }

  const period = `${yearSelect.value}-${monthSelect.value.padStart(2, '0')}`;

  // Confirm trước khi gửi
  const confirmed = await showConfirm(
    `Bạn có chắc muốn gửi thông báo phiếu lương cho TẤT CẢ nhân viên (Thu Ngân & Thợ) tháng ${monthSelect.value}/${yearSelect.value}?\n\nSau khi gửi, không thể gửi lại cho tháng này!`,
    'Xác nhận gửi thông báo'
  );
  if (!confirmed) return;

  // Set loading state
  sendBtn.classList.add('loading');
  sendBtn.disabled = true;
  sendBtn.innerHTML = '<i class="fas fa-spinner"></i><span class="btn-text">Đang gửi...</span>';

  try {
    const response = await fetch(`${checkinData.restUrl}send-salary-notification`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-WP-Nonce': checkinData.nonce,
      },
      body: JSON.stringify({
        period: period,
      }),
    });

    const data = await response.json();

    if (response.ok && data.success) {
      // Tắt loading và cập nhật UI thành trạng thái "Đã gửi"
      updateButtonToSentState(sendBtn, data.sent_at);

      // Hiển thị thông báo thành công
      toastSuccess(`Đã gửi thông báo phiếu lương cho ${data.count || 0} nhân viên thành công!`);
    } else {
      if (data.already_sent) {
        // Đã gửi rồi - tắt loading
        updateButtonToSentState(sendBtn, data.sent_at || null);
        showInfo(data.message);
      } else {
        throw new Error(data.message || 'Không thể gửi thông báo');
      }
    }
  } catch (error) {
    console.error('Error sending salary notification:', error);
    showError(`Lỗi: ${error.message}`);
    // Phục hồi trạng thái ban đầu nếu có lỗi
    updateButtonToDefaultState(sendBtn);
  }
}

// Khởi tạo khi DOM ready
document.addEventListener('DOMContentLoaded', function () {
  // Khởi tạo nút gửi phiếu lương
  initSendSalaryNotificationButton();

  // Cập nhật trạng thái nút khi thay đổi tháng (không cần theo dõi tab)
  const yearSelect = document.getElementById('year-select');
  const monthSelect = document.getElementById('month-select');

  if (yearSelect) yearSelect.addEventListener('change', checkNotificationSentStatus);
  if (monthSelect) monthSelect.addEventListener('change', checkNotificationSentStatus);
});

// ===== MODULE VISIBILITY BASED ON ACCESS PERMISSION =====
// Mapping access permission → modules (không trùng lặp)
const ACCESS_MODULE_MAPPING = {
  // Điểm Danh: Chấm công, Chi nhánh, Ca làm việc
  diem_danh: ['checkin', 'location', 'shift'],

  // Profile: Nhân viên, Lương, Cấp bậc lương, Cấp bậc NV, KPI, Đơn xin phép
  profile: ['staff', 'salary', 'salary_level', 'staff_level', 'kpi', 'approval_request'],

  // App Thợ: Booking, Dịch vụ, Sản phẩm, Hóa đơn, Khách hàng, Khuyến mãi, Đánh giá, Kho hàng
  app_tho: [
    'booking',
    'service',
    'product',
    'invoice',
    'customer',
    'promotion',
    'review',
    'inventory',
  ],

  // Admin: Tất cả modules còn lại (không thuộc 3 trang trên)
  admin: [
    'penalty',
    'leave',
    'payment',
    'dashboard',
    'role',
    'schedule',
    'settings',
    'product_group',
    'service_group',
  ],
};

// Mapping tên hiển thị → module key
const DISPLAY_NAME_TO_MODULE_KEY = {
  'Hóa đơn': 'invoice',
  'Đặt lịch': 'booking',
  'Dịch vụ': 'service',
  'Sản phẩm': 'product',
  'Nhân viên': 'staff',
  Lương: 'salary',
  KPI: 'kpi',
  Phạt: 'penalty',
  'Chi nhánh': 'location',
  'Ca làm việc': 'shift',
  'Nghỉ phép': 'leave',
  'Chấm công': 'checkin',
  'Khách hàng': 'customer',
  'Thanh toán': 'payment',
  'Đánh giá': 'review',
  'Bảng điều khiển': 'dashboard',
  'Vai trò': 'role',
  'Lịch làm việc': 'schedule',
  'Cài đặt hệ thống': 'settings',
  'Khuyến mãi': 'promotion',
  'Kho hàng': 'inventory',
  'Nhóm sản phẩm': 'product_group',
  'Nhóm dịch vụ': 'service_group',
  'Cấp bậc lương': 'salary_level',
  'Cấp bậc nhân viên': 'staff_level',
  'Đơn xin phép': 'approval_request',
};

function getModuleKey(displayName) {
  return DISPLAY_NAME_TO_MODULE_KEY[displayName] || displayName.toLowerCase().replace(/\s+/g, '_');
}

function updateModuleVisibility() {
  const accessChecked = {
    admin: document.getElementById('access-admin')?.checked || false,
    app_tho: document.getElementById('access-app-tho')?.checked || false,
    diem_danh: document.getElementById('access-diem-danh')?.checked || false,
    profile: document.getElementById('access-profile')?.checked || false,
  };

  // Collect tất cả modules cần hiện
  const visibleModules = new Set();
  Object.keys(accessChecked).forEach((access) => {
    if (accessChecked[access]) {
      ACCESS_MODULE_MAPPING[access].forEach((mod) => visibleModules.add(mod));
    }
  });

  // Show/hide các permission items
  document.querySelectorAll('.permission-item').forEach((item) => {
    const nameElement = item.querySelector('.permission-name');
    if (!nameElement) return;

    const moduleName = nameElement.textContent.trim();
    const moduleKey = getModuleKey(moduleName);

    if (visibleModules.size === 0) {
      // Nếu không có access nào được chọn → Ẩn tất cả
      item.style.display = 'none';
    } else {
      // Chỉ hiện modules thuộc access được chọn
      item.style.display = visibleModules.has(moduleKey) ? '' : 'none';
    }
  });

  // Log để debug
  console.log('[Module Visibility] Access checked:', accessChecked);
  console.log('[Module Visibility] Visible modules:', Array.from(visibleModules));
}

// Initialize event listeners khi modal được mở
function initializeAccessPermissionListeners() {
  const accessCheckboxes = ['access-admin', 'access-app-tho', 'access-diem-danh', 'access-profile'];

  accessCheckboxes.forEach((id) => {
    const checkbox = document.getElementById(id);
    if (checkbox) {
      // Remove old listener if exists
      checkbox.removeEventListener('change', updateModuleVisibility);
      // Add new listener
      checkbox.addEventListener('change', updateModuleVisibility);
    }
  });

  // Chạy lần đầu để set trạng thái ban đầu
  updateModuleVisibility();
}

// ============================================
// BRANCH SYSTEM FUNCTIONS - CHI NHÁNH
// ============================================

/**
 * Get branch-filtered rows for display
 * @param {Array} rows - All rows
 * @param {string} branchValue - Branch value (optional)
 * @return {Array} Filtered rows
 */
function filterRowsByBranch(rows, branchValue = null) {
  if (!rows || rows.length === 0) return rows;

  // Use current filter if not specified
  branchValue = branchValue || currentBranchFilter;

  if (!branchValue) return rows; // No filter

  // Note: In practice, we'd need to check row data for branch field
  // This is simplified - actual implementation depends on row structure
  return rows.filter((row) => {
    // Would need to implement actual branch field checking
    return true; // For now, return all
  });
}

/**
 * Add branch column to staff row (when editing)
 * Note: Hàm này không còn dùng vì staff dùng multi-select branch (getBranchMultiSelectHTML)
 * Giữ lại để tương thích ngược
 */
function addBranchToStaffRow(row, staffData) {
  if (!row || !staffData) return;

  const branchCell = row.querySelector('.col-branch');
  if (branchCell) {
    // Lấy branch_id đầu tiên từ user_branch array
    const userBranchIds = staffData.user_branch || [];
    const currentBranchId = userBranchIds.length > 0 ? parseInt(userBranchIds[0]) : 0;
    const branches = branchHelper?.allBranches || branchHelper?.branches || [];

    branchCell.innerHTML = `
      <select name="branch[]" class="branch-select" data-staff-id="${staffData.user_id}">
        <option value="">-- Chọn chi nhánh --</option>
        ${branches
          .map((b) => {
            const branchId = parseInt(b.id || b.branch_id) || 0;
            const branchName = b.branch_name || b.location_name || '';
            return `<option value="${branchId}" ${
              currentBranchId === branchId ? 'selected' : ''
            }>${branchName}</option>`;
          })
          .join('')}
      </select>
    `;
  }
}

/**
 * Get branch options for select dropdown (single select)
 * @param {number|string} selectedBranchId - branch_id được chọn
 */
function getBranchOptions(selectedBranchId = '') {
  // Lấy từ allBranches (adminMode) hoặc branches
  const branches = branchHelper?.allBranches || branchHelper?.branches || locations || [];

  if (!branches || branches.length === 0) {
    return '<option value="">-- Không có chi nhánh --</option>';
  }

  // Chuyển đổi selectedBranchId thành số để so sánh
  const selectedId = parseInt(selectedBranchId) || 0;

  return branches
    .map((b) => {
      const branchId = b.id || b.branch_id;
      const branchName = b.branch_name || b.location_name || b.name;
      return `<option value="${branchId}" ${
        selectedId === parseInt(branchId) ? 'selected' : ''
      }>${branchName}</option>`;
    })
    .join('');
}

/**
 * Get branch multi-select HTML for staff với pill style
 * @param {Array|string} selectedBranchIds - Mảng các branch_id được chọn
 */
function getBranchMultiSelectHTML(selectedBranchIds = []) {
  // Lấy từ allBranches (adminMode) hoặc branches hoặc locations
  const branches = branchHelper?.allBranches || branchHelper?.branches || locations || [];

  if (!branches || branches.length === 0) {
    return '<div class="branch-pill-select"><span class="no-branch">-- Không có chi nhánh --</span></div>';
  }

  // Parse selectedBranchIds nếu là string JSON
  let branchIdArray = parseBranchIds(selectedBranchIds);

  // Tạo pills cho các chi nhánh đã chọn
  const selectedPills = branchIdArray
    .map((branchId) => {
      const branch = branches.find((b) => parseInt(b.id || b.branch_id) === branchId);
      if (!branch) return '';
      const branchName = branch.branch_name || branch.location_name || branch.name;
      return `<span class="branch-pill" data-branch-id="${branchId}">
        ${branchName}
        <button type="button" class="branch-pill-remove" onclick="removeBranchPill(this, ${branchId})" disabled>×</button>
      </span>`;
    })
    .filter((p) => p)
    .join('');

  // Tạo select dropdown để thêm chi nhánh mới
  const availableBranches = branches.filter(
    (b) => !branchIdArray.includes(parseInt(b.id || b.branch_id))
  );

  const selectOptions = availableBranches
    .map((b) => {
      const branchId = b.id || b.branch_id;
      const branchName = b.branch_name || b.location_name || b.name;
      return `<option value="${branchId}">${branchName}</option>`;
    })
    .join('');

  return `
    <div class="branch-pill-select">
      <div class="branch-pills-container">
        ${selectedPills || '<span class="no-branch-selected">Chưa chọn chi nhánh</span>'}
      </div>
      <select class="branch-add-select" onchange="addBranchPill(this)" disabled>
        <option value="">+ Thêm chi nhánh</option>
        ${selectOptions}
      </select>
      <input type="hidden" name="branch_ids_json" value='${JSON.stringify(branchIdArray)}'>
    </div>
  `;
}

/**
 * Parse branch IDs từ nhiều định dạng khác nhau
 */
function parseBranchIds(selectedBranchIds) {
  let branchIdArray = [];
  if (typeof selectedBranchIds === 'string') {
    try {
      branchIdArray = JSON.parse(selectedBranchIds);
    } catch (e) {
      branchIdArray = selectedBranchIds
        .split(',')
        .map((id) => parseInt(id.trim()))
        .filter((id) => !isNaN(id));
    }
  } else if (Array.isArray(selectedBranchIds)) {
    branchIdArray = selectedBranchIds.map((id) => parseInt(id)).filter((id) => !isNaN(id));
  }
  return branchIdArray;
}

/**
 * Thêm branch pill khi chọn từ dropdown
 */
function addBranchPill(selectElement) {
  const branchId = parseInt(selectElement.value);
  if (!branchId) return;

  const container = selectElement.closest('.branch-pill-select');
  const pillsContainer = container.querySelector('.branch-pills-container');
  const hiddenInput = container.querySelector('input[name="branch_ids_json"]');

  // Lấy danh sách branch_ids hiện tại
  let currentIds = JSON.parse(hiddenInput.value || '[]');
  if (currentIds.includes(branchId)) return;

  // Thêm branch mới
  currentIds.push(branchId);
  hiddenInput.value = JSON.stringify(currentIds);

  // Lấy tên chi nhánh - dùng allBranches hoặc branches hoặc locations
  const branches = branchHelper?.allBranches || branchHelper?.branches || locations || [];
  const branch = branches.find((b) => parseInt(b.id || b.branch_id) === branchId);
  const branchName = branch ? branch.branch_name || branch.location_name || branch.name : '';

  // Xóa placeholder nếu có
  const placeholder = pillsContainer.querySelector('.no-branch-selected');
  if (placeholder) placeholder.remove();

  // Thêm pill mới
  const pill = document.createElement('span');
  pill.className = 'branch-pill';
  pill.dataset.branchId = branchId;
  pill.innerHTML = `${branchName}<button type="button" class="branch-pill-remove" onclick="removeBranchPill(this, ${branchId})">×</button>`;
  pillsContainer.appendChild(pill);

  // Xóa option đã chọn khỏi select
  selectElement.querySelector(`option[value="${branchId}"]`).remove();
  selectElement.value = '';
}

/**
 * Xóa branch pill
 */
function removeBranchPill(button, branchId) {
  const container = button.closest('.branch-pill-select');
  const pillsContainer = container.querySelector('.branch-pills-container');
  const hiddenInput = container.querySelector('input[name="branch_ids_json"]');
  const selectElement = container.querySelector('.branch-add-select');

  // Xóa khỏi danh sách
  let currentIds = JSON.parse(hiddenInput.value || '[]');
  currentIds = currentIds.filter((id) => id !== branchId);
  hiddenInput.value = JSON.stringify(currentIds);

  // Xóa pill
  const pill = button.closest('.branch-pill');
  pill.remove();

  // Thêm lại option vào select - dùng allBranches hoặc branches hoặc locations
  const branches = branchHelper?.allBranches || branchHelper?.branches || locations || [];
  const branch = branches.find((b) => parseInt(b.id || b.branch_id) === branchId);
  if (branch) {
    const branchName = branch.branch_name || branch.location_name || branch.name;
    const option = document.createElement('option');
    option.value = branchId;
    option.textContent = branchName;
    selectElement.appendChild(option);
  }

  // Hiển thị placeholder nếu không còn chi nhánh nào
  if (currentIds.length === 0) {
    const placeholder = document.createElement('span');
    placeholder.className = 'no-branch-selected';
    placeholder.textContent = 'Chưa chọn chi nhánh';
    pillsContainer.appendChild(placeholder);
  }
}

/**
 * Get selected branch IDs from multi-select
 * @param {HTMLElement} container - Container chứa pills
 * @returns {Array} Mảng các branch_id được chọn
 */
function getSelectedBranchIds(container) {
  const hiddenInput = container.querySelector('input[name="branch_ids_json"]');
  if (hiddenInput && hiddenInput.value) {
    try {
      return JSON.parse(hiddenInput.value);
    } catch (e) {
      return [];
    }
  }
  return [];
}

/**
 * Update staff row with branch column (multi-select)
 */
function updateStaffRowWithBranch(staffRow, staff) {
  // Find or create branch cell
  let branchCell = staffRow.querySelector('.col-branch');
  if (!branchCell) {
    // Create new branch cell before actions
    const actionsCell = staffRow.querySelector('.col-actions, .actions');
    if (actionsCell) {
      branchCell = document.createElement('td');
      branchCell.className = 'col-branch';
      actionsCell.parentNode.insertBefore(branchCell, actionsCell);
    }
  }

  if (branchCell) {
    // Sử dụng user_branch (mảng branch_ids) thay vì branch name
    const userBranchIds = staff.user_branch || staff.branch_ids || [];
    branchCell.innerHTML = getBranchMultiSelectHTML(userBranchIds);
    branchCell.setAttribute('data-staff-id', staff.user_id || '');
  }
}

/**
 * Render branch selector trong admin header
 * Cho phép lọc dữ liệu theo chi nhánh
 */
function renderAdminBranchSelector() {
  const select = document.getElementById('admin-branch-select');
  if (!select) {
    console.warn('Branch selector element not found');
    return;
  }

  // Lấy danh sách chi nhánh từ branchHelper
  const branches = branchHelper?.allBranches || branchHelper?.branches || [];

  if (branches.length === 0) {
    console.warn('No branches available for admin selector');
    return;
  }

  // Clear và rebuild options
  select.innerHTML = '<option value="">-- Tất cả chi nhánh --</option>';

  branches.forEach((branch) => {
    const option = document.createElement('option');
    option.value = branch.id || branch.branch_id || '';
    option.textContent = branch.branch_name || branch.location_name || `Chi nhánh ${option.value}`;
    select.appendChild(option);
  });

  // Add event listener
  select.addEventListener('change', (e) => handleAdminBranchChange(e.target.value));

  // Set default value nếu có
  if (currentBranchFilter) {
    select.value = currentBranchFilter;
  }
}

/**
 * Xử lý khi thay đổi chi nhánh trong admin
 * @param {string} branchId - ID chi nhánh được chọn (empty = tất cả)
 */
async function handleAdminBranchChange(branchId) {
  currentBranchFilter = branchId || null;

  console.log('Admin branch changed:', branchId || 'Tất cả chi nhánh');

  // Show loading indicator
  if (window.showPageLoader) {
    const branchName = branchId
      ? (branchHelper?.allBranches || branchHelper?.branches || []).find(
          (b) => String(b.id || b.branch_id) === String(branchId)
        )?.branch_name
      : 'Tất cả chi nhánh';
    window.showPageLoader({
      text: 'Đang lọc dữ liệu...',
      subtitle: branchName,
    });
  }

  // Reload data với branch filter mới
  // Các function fetch đã tự render khi hoàn thành
  try {
    await Promise.all([fetchStaff(), fetchServices(), fetchProducts(), fetchShifts()]);

    // Reload salary data nếu đang ở tab bảng lương
    reloadSalaryDataWithBranchFilter();

    if (window.toastSuccess) {
      const branchName = branchId
        ? (branchHelper?.allBranches || branchHelper?.branches || []).find(
            (b) => String(b.id || b.branch_id) === String(branchId)
          )?.branch_name
        : 'Tất cả chi nhánh';
      window.toastSuccess(`Đã lọc theo: ${branchName}`);
    }
  } catch (error) {
    console.error('Error reloading data:', error);
    if (window.toastError) {
      window.toastError('Lỗi khi tải dữ liệu');
    }
  } finally {
    if (window.hidePageLoader) {
      window.hidePageLoader();
    }
  }
}

/**
 * Reload dữ liệu bảng lương khi thay đổi chi nhánh
 * Lấy period và role hiện tại để fetch lại data
 */
function reloadSalaryDataWithBranchFilter() {
  const yearSelect = document.getElementById('year-select');
  const monthSelect = document.getElementById('month-select');
  const activeTab = document.querySelector('.salary-tabs .tab-btn.active');

  // Kiểm tra xem các element bảng lương có tồn tại không
  if (!yearSelect || !monthSelect || !activeTab) {
    // Không ở tab bảng lương, không cần reload
    return;
  }

  const period = `${yearSelect.value}-${monthSelect.value}`;
  const role = activeTab.id === 'cashier-tab' ? 'Thu Ngân' : 'Thợ';

  console.log('Reloading salary data with branch filter:', { period, role, currentBranchFilter });

  // Gọi fetch salary theo role hiện tại
  if (role === 'Thu Ngân') {
    fetchCashierSalary(period);
  } else {
    fetchHairdresserSalary(period);
  }
}

/**
 * Helper để lấy branch filter params cho API calls
 * @returns {Object} Object chứa branch_id nếu có filter
 */
function getBranchFilterParams() {
  if (currentBranchFilter) {
    return { branch_id: currentBranchFilter };
  }
  return {};
}
