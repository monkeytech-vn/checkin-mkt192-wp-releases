/**
 * Notifications Management Module
 * Manages homepage notifications and staff push notifications
 * Following Semi Design standards and project conventions
 *
 * @package Checkin_MKT192_WP
 * @since 7.0.0
 */

// ============================================================================
// STATE MANAGEMENT
// ============================================================================

let notificationsState = {
  notifications: [],
  currentType: 'all', // 'all' | 'homepage' | 'staff'
  currentFilter: 'active',
  currentPage: 1,
  totalPages: 1,
  isLoading: false,
  editingNotification: null,
  mediaFile: null,
  mediaPreviewUrl: null,
};

// ============================================================================
// INITIALIZATION
// ============================================================================

document.addEventListener('DOMContentLoaded', () => {
  initNotificationsManagement();
});

function initNotificationsManagement() {
  // Initialize event listeners
  initNotificationModalEvents();
  initMediaUploadEvents();
  initFilterEvents();
  initFormValidation();
  initAspectRatioSelector();
  initNewTypeSelector();
  initContentEditorToolbar();
  initPreviewButton();

  // Load initial data when section becomes visible
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          loadNotifications();
          initBranchSelector();
          observer.disconnect();
        }
      });
    },
    { threshold: 0.1 }
  );

  const section = document.getElementById('notifications-management');
  if (section) {
    observer.observe(section);
  }
}

function updateModalForType(type) {
  const pushOptions = document.getElementById('notification-push-options');
  const typeInput = document.getElementById('notification-type-input');
  const typeHidden = document.getElementById('notification-type-hidden');

  if (pushOptions) {
    pushOptions.style.display = type === 'staff' ? 'block' : 'none';
  }
  if (typeInput) {
    typeInput.value = type;
  }
  if (typeHidden) {
    typeHidden.value = type;
  }

  // Update horizontal tabs (new layout)
  const typeTabs = document.querySelectorAll('.noti-type-tab');
  typeTabs.forEach((tab) => {
    tab.classList.toggle('active', tab.dataset.type === type);
  });

  // Update legacy type selector in modal
  const typeOptions = document.querySelectorAll('.notification-type-option');
  typeOptions.forEach((option) => {
    option.classList.toggle('active', option.dataset.type === type);
    const radio = option.querySelector('input[type="radio"]');
    if (radio) {
      radio.checked = option.dataset.type === type;
    }
  });

  // Update new type selector in modal (legacy labels)
  const newTypeOptions = document.querySelectorAll('.noti-type-option');
  newTypeOptions.forEach((option) => {
    option.classList.toggle('active', option.dataset.type === type);
    const radio = option.querySelector('input[type="radio"]');
    if (radio) {
      radio.checked = option.dataset.type === type;
    }
  });
}

// ============================================================================
// MODAL EVENTS
// ============================================================================

function initNotificationModalEvents() {
  const createBtn = document.getElementById('btn-create-notification');
  const refreshBtn = document.getElementById('btn-refresh-notifications');
  const closeBtn = document.getElementById('noti-mgmt-modal-close');
  const cancelBtn = document.getElementById('notification-cancel-btn');
  const draftBtn = document.getElementById('notification-draft-btn');
  const publishBtn = document.getElementById('notification-publish-btn');
  const previewCloseBtn = document.getElementById('preview-close-btn');

  if (createBtn) {
    createBtn.addEventListener('click', () => openNotificationModal());
  }

  if (refreshBtn) {
    refreshBtn.addEventListener('click', () => {
      refreshBtn.classList.add('loading');
      loadNotifications().finally(() => {
        refreshBtn.classList.remove('loading');
      });
    });
  }

  if (closeBtn) {
    closeBtn.addEventListener('click', closeNotificationModal);
  }

  if (cancelBtn) {
    cancelBtn.addEventListener('click', closeNotificationModal);
  }

  if (draftBtn) {
    draftBtn.addEventListener('click', () => saveNotification('draft'));
  }

  if (publishBtn) {
    publishBtn.addEventListener('click', () => saveNotification('active'));
  }

  if (previewCloseBtn) {
    previewCloseBtn.addEventListener('click', closePreviewModal);
  }

  // Close modals on overlay click
  const modalOverlay = document.getElementById('noti-mgmt-modal');
  if (modalOverlay) {
    modalOverlay.addEventListener('click', (e) => {
      if (e.target === modalOverlay) closeNotificationModal();
    });
  }

  const previewOverlay = document.getElementById('notification-preview-modal');
  if (previewOverlay) {
    previewOverlay.addEventListener('click', (e) => {
      if (e.target === previewOverlay) closePreviewModal();
    });
  }

  // Type option selection in modal
  const typeOptions = document.querySelectorAll('.notification-type-option');
  typeOptions.forEach((option) => {
    option.addEventListener('click', () => {
      typeOptions.forEach((o) => o.classList.remove('active'));
      option.classList.add('active');
      const type = option.dataset.type;
      updateModalForType(type);
    });
  });

  // Keyboard events
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeNotificationModal();
      closePreviewModal();
    }
  });
}

function openNotificationModal(notification = null) {
  const modal = document.getElementById('noti-mgmt-modal');
  const title = document.getElementById('noti-mgmt-modal-title');
  const form = document.getElementById('notification-form');

  if (!modal || !form) return;

  // Reset form
  form.reset();
  resetMediaUpload();

  // IMPORTANT: Explicitly clear notification ID to prevent update instead of create
  const notificationIdField = document.getElementById('notification-id');
  if (notificationIdField) {
    notificationIdField.value = '';
  }

  // Clear contenteditable editor
  const contentEditor = document.getElementById('notification-content');
  if (contentEditor) {
    contentEditor.innerHTML = '';
    updateEditorCharCounter();
  }

  // Set mode
  notificationsState.editingNotification = notification;

  if (notification) {
    // Edit mode
    title.innerHTML = '<i class="fas fa-edit"></i><span>Chỉnh sửa thông báo</span>';
    populateFormWithNotification(notification);
  } else {
    // Create mode
    title.innerHTML = '<i class="fas fa-bell"></i><span>Tạo thông báo mới</span>';
    updateModalForType(
      notificationsState.currentType === 'all' ? 'homepage' : notificationsState.currentType
    );

    // Reset schedule toggle to OFF (send immediately by default)
    const scheduleToggle = document.getElementById('notification-schedule-toggle');
    if (scheduleToggle) {
      scheduleToggle.checked = false;
    }
    updateScheduleUI();

    // Set default dates
    const now = new Date();
    const startDate = document.getElementById('notification-start-date');
    if (startDate) {
      startDate.value = formatDateTimeLocal(now);
    }
  }

  // Show modal with animation
  modal.classList.add('active');
  document.body.style.overflow = 'hidden';

  // Focus first input
  setTimeout(() => {
    const titleInput = document.getElementById('notification-title');
    if (titleInput) titleInput.focus();
  }, 300);
}

function closeNotificationModal() {
  const modal = document.getElementById('noti-mgmt-modal');
  if (!modal) return;

  modal.classList.remove('active');
  document.body.style.overflow = '';
  notificationsState.editingNotification = null;
  resetMediaUpload();

  // Clear notification ID to prevent issues when reopening modal
  const notificationIdField = document.getElementById('notification-id');
  if (notificationIdField) {
    notificationIdField.value = '';
  }
}

function populateFormWithNotification(notification) {
  document.getElementById('notification-id').value = notification.id || '';
  document.getElementById('notification-title').value = notification.title || '';

  // Content editor is contenteditable div - use innerHTML
  const contentEditor = document.getElementById('notification-content');
  if (contentEditor) {
    contentEditor.innerHTML = notification.content || '';
    updateEditorCharCounter();
  }

  document.getElementById('notification-link').value = notification.link || '';
  document.getElementById('notification-status').value = notification.status || 'active';

  // Slideshow settings
  const sortOrderInput = document.getElementById('notification-sort-order');
  const slideDurationInput = document.getElementById('notification-slide-duration');
  if (sortOrderInput) sortOrderInput.value = parseInt(notification.sort_order || 0);
  if (slideDurationInput) slideDurationInput.value = parseInt(notification.slide_duration || 5);

  // Set schedule toggle based on status
  const scheduleToggle = document.getElementById('notification-schedule-toggle');
  if (scheduleToggle) {
    // If status is 'scheduled', toggle should be ON
    scheduleToggle.checked = notification.status === 'scheduled';
    updateScheduleUI();
  }

  if (notification.start_date) {
    document.getElementById('notification-start-date').value = formatDateTimeLocal(
      new Date(notification.start_date)
    );
  }
  if (notification.end_date) {
    document.getElementById('notification-end-date').value = formatDateTimeLocal(
      new Date(notification.end_date)
    );
  }

  // Update type
  const type = notification.type || 'homepage';
  updateModalForType(type);

  // Show existing media and set preview URL for preview button
  if (notification.media_url) {
    showMediaPreview(notification.media_url, notification.media_type);
    // Set mediaPreviewUrl for preview button to work
    notificationsState.mediaPreviewUrl = notification.media_url;
    notificationsState.existingMediaType = notification.media_type;
    notificationsState.mediaFromUrl = true; // Existing media is from URL

    // Hide URL input wrapper when existing media is shown
    const urlWrapper = document.getElementById('media-url-input-wrapper');
    if (urlWrapper) {
      urlWrapper.classList.add('hidden');
    }

    // Show aspect ratio selector when media exists
    showAspectRatioSelector();
  }

  // Set aspect ratio if available
  if (notification.aspect_ratio) {
    const aspectOption = document.querySelector(
      `.aspect-ratio-option input[value="${notification.aspect_ratio}"]`
    );
    if (aspectOption) {
      document
        .querySelectorAll('.aspect-ratio-option')
        .forEach((opt) => opt.classList.remove('active'));
      aspectOption.closest('.aspect-ratio-option').classList.add('active');
      aspectOption.checked = true;
    }
  }

  // Update character counters
  updateCharCounter('notification-title', 'title-counter', 100);
  updateCharCounter('notification-content', 'content-counter', 1000);

  // Push options for staff notifications
  if (type === 'staff') {
    const sendPush = document.getElementById('send-push-notification');
    const showInApp = document.getElementById('show-in-app');
    if (sendPush) sendPush.checked = notification.send_push !== false;
    if (showInApp) showInApp.checked = notification.show_in_app !== false;
  }

  // Branch selection
  if (notification.branches && notification.branches.length > 0) {
    notification.branches.forEach((branchId) => {
      const checkbox = document.querySelector(
        `#notification-branch-list input[value="${branchId}"]`
      );
      if (checkbox) {
        checkbox.checked = true;
        checkbox.closest('label').classList.add('selected');
      }
    });
  }
}

// ============================================================================
// MEDIA UPLOAD
// ============================================================================

function initMediaUploadEvents() {
  const uploadZone = document.getElementById('media-upload-zone');
  const uploadPlaceholder = document.getElementById('upload-placeholder');
  const fileInput = document.getElementById('notification-media');
  const removeBtn = document.getElementById('btn-remove-media');
  const editBtn = document.getElementById('btn-edit-media');
  const mediaUrlInput = document.getElementById('notification-media-url');

  if (!uploadZone || !fileInput) return;

  // Click to upload
  uploadPlaceholder?.addEventListener('click', () => fileInput.click());

  // Drag and drop
  uploadZone.addEventListener('dragover', (e) => {
    e.preventDefault();
    uploadZone.classList.add('dragover');
  });

  uploadZone.addEventListener('dragleave', () => {
    uploadZone.classList.remove('dragover');
  });

  uploadZone.addEventListener('drop', (e) => {
    e.preventDefault();
    uploadZone.classList.remove('dragover');
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      handleMediaFile(files[0]);
    }
  });

  // File input change
  fileInput.addEventListener('change', (e) => {
    if (e.target.files.length > 0) {
      handleMediaFile(e.target.files[0]);
    }
  });

  // Remove media
  removeBtn?.addEventListener('click', resetMediaUpload);

  // Edit media - show URL input and allow changing image
  editBtn?.addEventListener('click', showEditMediaOptions);

  // Media URL input - load preview when URL is entered
  mediaUrlInput?.addEventListener('blur', handleMediaUrlInput);
  mediaUrlInput?.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleMediaUrlInput();
    }
  });
}

function showEditMediaOptions() {
  // Show the URL input wrapper when edit is clicked
  const urlWrapper = document.getElementById('media-url-input-wrapper');
  if (urlWrapper) {
    urlWrapper.classList.remove('hidden');
  }

  // Also allow selecting a new file
  const fileInput = document.getElementById('notification-media');
  if (fileInput) {
    fileInput.click();
  }
}

function handleMediaUrlInput() {
  const urlInput = document.getElementById('notification-media-url');
  const url = urlInput?.value?.trim();

  if (!url) return;

  // Validate URL format
  try {
    new URL(url);
  } catch {
    toastError('URL không hợp lệ');
    return;
  }

  // Check if it's an image URL
  const isImage = /\.(jpg|jpeg|png|gif|webp|svg)(\?.*)?$/i.test(url);
  const isVideo = /\.(mp4|webm|ogg)(\?.*)?$/i.test(url);

  if (!isImage && !isVideo) {
    // Try to load as image anyway
    showMediaPreviewFromUrl(url, 'image');
  } else {
    showMediaPreviewFromUrl(url, isVideo ? 'video' : 'image');
  }
}

function showMediaPreviewFromUrl(url, type) {
  // Clear any uploaded file
  notificationsState.mediaFile = null;

  // Set preview URL from input
  notificationsState.mediaPreviewUrl = url;
  notificationsState.mediaFromUrl = true; // Flag to indicate media is from URL

  // Show preview
  showMediaPreview(url, type);

  // Hide URL input wrapper after successfully loading
  const urlWrapper = document.getElementById('media-url-input-wrapper');
  if (urlWrapper) {
    urlWrapper.classList.add('hidden');
  }

  // Show aspect ratio selector for images
  if (type !== 'video') {
    showAspectRatioSelector();
  }
}

function handleMediaFile(file) {
  // Validate file type
  const validTypes = [
    'image/jpeg',
    'image/png',
    'image/gif',
    'image/webp',
    'video/mp4',
    'video/webm',
  ];
  if (!validTypes.includes(file.type)) {
    toastError('Định dạng file không được hỗ trợ');
    return;
  }

  // Validate file size (10MB max)
  const maxSize = 10 * 1024 * 1024;
  if (file.size > maxSize) {
    toastError('File quá lớn. Tối đa 10MB');
    return;
  }

  notificationsState.mediaFile = file;
  notificationsState.mediaFromUrl = false; // Clear URL flag when file is uploaded

  // Create preview URL
  if (notificationsState.mediaPreviewUrl) {
    URL.revokeObjectURL(notificationsState.mediaPreviewUrl);
  }
  notificationsState.mediaPreviewUrl = URL.createObjectURL(file);

  // Show preview
  const isVideo = file.type.startsWith('video/');
  showMediaPreview(notificationsState.mediaPreviewUrl, isVideo ? 'video' : 'image');

  // Hide URL input wrapper when file is uploaded
  const urlWrapper = document.getElementById('media-url-input-wrapper');
  if (urlWrapper) {
    urlWrapper.classList.add('hidden');
  }

  // Clear URL input
  const urlInput = document.getElementById('notification-media-url');
  if (urlInput) {
    urlInput.value = '';
  }

  // Show aspect ratio selector for images
  if (!isVideo) {
    showAspectRatioSelector();
  }
}

function showMediaPreview(url, type) {
  const placeholder = document.getElementById('upload-placeholder');
  const preview = document.getElementById('media-preview');
  const container = document.getElementById('preview-container');

  if (!placeholder || !preview || !container) return;

  placeholder.style.display = 'none';
  preview.style.display = 'block';

  if (type === 'video') {
    container.innerHTML = `
      <video src="${url}" controls playsinline>
        Your browser does not support the video tag.
      </video>
    `;
  } else {
    container.innerHTML = `<img src="${url}" alt="Preview" />`;
  }
}

function resetMediaUpload() {
  const placeholder = document.getElementById('upload-placeholder');
  const preview = document.getElementById('media-preview');
  const container = document.getElementById('preview-container');
  const fileInput = document.getElementById('notification-media');
  const aspectRatioSelector = document.getElementById('aspect-ratio-selector');
  const urlWrapper = document.getElementById('media-url-input-wrapper');
  const urlInput = document.getElementById('notification-media-url');

  if (placeholder) placeholder.style.display = 'flex';
  if (preview) preview.style.display = 'none';
  if (container) container.innerHTML = '';
  if (fileInput) fileInput.value = '';
  if (aspectRatioSelector) aspectRatioSelector.style.display = 'none';

  // Show URL input wrapper again and clear it
  if (urlWrapper) urlWrapper.classList.remove('hidden');
  if (urlInput) urlInput.value = '';

  if (notificationsState.mediaPreviewUrl) {
    URL.revokeObjectURL(notificationsState.mediaPreviewUrl);
  }
  notificationsState.mediaFile = null;
  notificationsState.mediaPreviewUrl = null;
  notificationsState.mediaFromUrl = false;
}

// ============================================================================
// ASPECT RATIO SELECTOR
// ============================================================================

function initAspectRatioSelector() {
  const aspectOptions = document.querySelectorAll('.aspect-ratio-option');
  aspectOptions.forEach((option) => {
    option.addEventListener('click', () => {
      aspectOptions.forEach((o) => o.classList.remove('active'));
      option.classList.add('active');

      // Update preview container aspect ratio in realtime
      const ratio = option.dataset.ratio || option.querySelector('input')?.value;
      updatePreviewAspectRatio(ratio);
    });
  });
}

function updatePreviewAspectRatio(ratio) {
  const previewContainer = document.getElementById('preview-container');
  const previewWrapper = previewContainer?.closest('.preview-wrapper');
  if (!previewContainer) return;

  // Remove all ratio classes
  previewContainer.classList.remove('ratio-16-9', 'ratio-1-1', 'ratio-9-16', 'ratio-4-3');

  // Add the selected ratio class
  const ratioClass = 'ratio-' + ratio.replace(':', '-');
  previewContainer.classList.add(ratioClass);

  // Update preview wrapper max-width for portrait ratio
  if (previewWrapper) {
    if (ratio === '9:16') {
      previewWrapper.style.maxWidth = '180px';
    } else {
      previewWrapper.style.maxWidth = '280px';
    }
  }
}

// Show aspect ratio selector when media is uploaded
function showAspectRatioSelector() {
  const aspectRatioSelector = document.getElementById('aspect-ratio-selector');
  if (aspectRatioSelector) {
    aspectRatioSelector.style.display = 'block';
  }
}

// ============================================================================
// TYPE TABS (Horizontal layout)
// ============================================================================

const TYPE_DESCRIPTIONS = {
  homepage: 'Hiển thị popup thông báo trên trang chủ cho tất cả khách truy cập website.',
  staff: 'Gửi thông báo đến nhân viên qua ứng dụng App-Thợ và thông báo đẩy (Push Notification).',
};

function initNewTypeSelector() {
  // New tabs layout
  const typeTabs = document.querySelectorAll('.noti-type-tab');
  typeTabs.forEach((tab) => {
    tab.addEventListener('click', () => {
      typeTabs.forEach((t) => t.classList.remove('active'));
      tab.classList.add('active');
      const type = tab.dataset.type;

      // Update hidden inputs
      const typeInput = document.getElementById('notification-type-input');
      const typeHidden = document.getElementById('notification-type-hidden');
      if (typeInput) typeInput.value = type;
      if (typeHidden) typeHidden.value = type;

      // Update description
      updateTypeDescription(type);

      updateModalForType(type);
    });
  });

  // Legacy selector support
  const typeOptions = document.querySelectorAll('.noti-type-option');
  typeOptions.forEach((option) => {
    option.addEventListener('click', () => {
      typeOptions.forEach((o) => o.classList.remove('active'));
      option.classList.add('active');
      const type = option.dataset.type;
      updateTypeDescription(type);
      updateModalForType(type);
    });
  });
}

function updateTypeDescription(type) {
  const descText = document.getElementById('noti-type-desc-text');
  if (descText && TYPE_DESCRIPTIONS[type]) {
    descText.textContent = TYPE_DESCRIPTIONS[type];
  }
}

// ============================================================================
// CONTENT EDITOR TOOLBAR - WYSIWYG with contenteditable
// ============================================================================

function initContentEditorToolbar() {
  const toolbarBtns = document.querySelectorAll('.content-editor-toolbar .toolbar-btn');
  const contentEditor = document.getElementById('notification-content');

  if (!contentEditor) return;

  toolbarBtns.forEach((btn) => {
    btn.addEventListener('click', () => {
      const format = btn.dataset.format;
      applyFormat(format, btn);
    });
  });

  // Keyboard shortcuts
  contentEditor.addEventListener('keydown', (e) => {
    if (e.ctrlKey || e.metaKey) {
      if (e.key === 'b') {
        e.preventDefault();
        applyFormat('bold');
      } else if (e.key === 'i') {
        e.preventDefault();
        applyFormat('italic');
      } else if (e.key === 'u') {
        e.preventDefault();
        applyFormat('underline');
      }
    }
  });

  // Update character counter on input
  contentEditor.addEventListener('input', () => {
    updateEditorCharCounter();
  });

  // Handle paste - strip formatting if needed
  contentEditor.addEventListener('paste', (e) => {
    e.preventDefault();
    const text = (e.clipboardData || window.clipboardData).getData('text/plain');
    document.execCommand('insertText', false, text);
  });
}

function applyFormat(format, btn = null) {
  const contentEditor = document.getElementById('notification-content');
  if (!contentEditor) return;

  contentEditor.focus();

  switch (format) {
    case 'bold':
      document.execCommand('bold', false, null);
      break;
    case 'italic':
      document.execCommand('italic', false, null);
      break;
    case 'underline':
      document.execCommand('underline', false, null);
      break;
    case 'align-left':
      document.execCommand('justifyLeft', false, null);
      toggleToolbarBtn('align-left');
      break;
    case 'align-center':
      document.execCommand('justifyCenter', false, null);
      toggleToolbarBtn('align-center');
      break;
    case 'align-right':
      document.execCommand('justifyRight', false, null);
      toggleToolbarBtn('align-right');
      break;
    case 'list':
      document.execCommand('insertUnorderedList', false, null);
      break;
    case 'emoji':
      showEmojiPicker(contentEditor);
      return;
    default:
      return;
  }

  updateEditorCharCounter();
  updateToolbarActiveState();
}

function updateToolbarActiveState() {
  // Update bold, italic, underline buttons
  const boldBtn = document.querySelector('.toolbar-btn[data-format="bold"]');
  const italicBtn = document.querySelector('.toolbar-btn[data-format="italic"]');
  const underlineBtn = document.querySelector('.toolbar-btn[data-format="underline"]');

  if (boldBtn) boldBtn.classList.toggle('active', document.queryCommandState('bold'));
  if (italicBtn) italicBtn.classList.toggle('active', document.queryCommandState('italic'));
  if (underlineBtn)
    underlineBtn.classList.toggle('active', document.queryCommandState('underline'));
}

function updateEditorCharCounter() {
  const contentEditor = document.getElementById('notification-content');
  const counter = document.getElementById('content-counter');
  if (contentEditor && counter) {
    const textLength = contentEditor.innerText.length;
    counter.textContent = textLength;

    // Visual feedback if approaching limit
    const counterParent = counter.parentElement;
    if (textLength > 900) {
      counterParent.style.color = '#ef4444';
    } else if (textLength > 750) {
      counterParent.style.color = '#f59e0b';
    } else {
      counterParent.style.color = '';
    }
  }
}

function toggleToolbarBtn(activeFormat) {
  const alignBtns = document.querySelectorAll('.toolbar-btn[data-format^="align-"]');
  alignBtns.forEach((b) => {
    b.classList.toggle('active', b.dataset.format === activeFormat);
  });
}

function showEmojiPicker(editor) {
  const emojis = [
    '😊',
    '🎉',
    '🔥',
    '✨',
    '💯',
    '👍',
    '❤️',
    '🎊',
    '🌟',
    '💪',
    '🙏',
    '📢',
    '📌',
    '⚡',
    '🎁',
    '🏆',
  ];

  // Remove existing picker
  const existingPicker = document.querySelector('.emoji-picker-popup');
  if (existingPicker) {
    existingPicker.remove();
    return;
  }

  const picker = document.createElement('div');
  picker.className = 'emoji-picker-popup';
  picker.innerHTML = emojis
    .map((e) => `<button type="button" class="emoji-btn">${e}</button>`)
    .join('');

  // Position near emoji button
  const emojiBtn = document.querySelector('.toolbar-btn[data-format="emoji"]');
  if (emojiBtn) {
    const rect = emojiBtn.getBoundingClientRect();
    picker.style.cssText = `
      position: fixed;
      top: ${rect.bottom + 8}px;
      left: ${rect.left}px;
      display: flex;
      flex-wrap: wrap;
      gap: 4px;
      padding: 8px;
      background: white;
      border-radius: 8px;
      box-shadow: 0 4px 20px rgba(0,0,0,0.15);
      z-index: 10000;
      max-width: 200px;
    `;
  }

  document.body.appendChild(picker);

  picker.querySelectorAll('.emoji-btn').forEach((btn) => {
    btn.style.cssText =
      'font-size: 20px; padding: 4px 8px; background: none; border: none; cursor: pointer; border-radius: 4px;';
    btn.addEventListener('mouseenter', () => (btn.style.background = '#f0f0f0'));
    btn.addEventListener('mouseleave', () => (btn.style.background = 'none'));
    btn.addEventListener('click', () => {
      // Insert emoji at cursor in contenteditable
      editor.focus();
      document.execCommand('insertText', false, btn.textContent);
      picker.remove();
      updateEditorCharCounter();
    });
  });

  // Close on outside click
  setTimeout(() => {
    document.addEventListener(
      'click',
      (e) => {
        if (!picker.contains(e.target) && e.target !== emojiBtn) {
          picker.remove();
        }
      },
      { once: true }
    );
  }, 100);
}

// ============================================================================
// PREVIEW BUTTON - Uses same popup style as homepage
// ============================================================================

function initPreviewButton() {
  const previewBtn = document.getElementById('notification-preview-btn');
  if (previewBtn) {
    previewBtn.addEventListener('click', showFormPreview);
  }
}

let previewPopupElement = null;

function showFormPreview() {
  const title = document.getElementById('notification-title')?.value.trim() || 'Tiêu đề thông báo';
  const contentEditor = document.getElementById('notification-content');
  const rawContent = contentEditor?.innerHTML.trim() || 'Nội dung thông báo...';
  // Normalize content to match what will be saved and displayed in popup
  const content = normalizeEditorContent(rawContent);
  const mediaPreviewUrl = notificationsState.mediaPreviewUrl;
  const link = document.getElementById('notification-link')?.value.trim() || '';

  // Get aspect ratio
  const selectedAspectRatio =
    document.querySelector('.aspect-ratio-option.active input')?.value ||
    document.querySelector('.aspect-ratio-option input:checked')?.value ||
    '16:9';

  // Create or update preview popup (same style as homepage)
  if (!previewPopupElement) {
    createPreviewPopup();
  }

  // Determine media type - from new file or existing
  let mediaType = 'image';
  if (notificationsState.mediaFile) {
    mediaType = notificationsState.mediaFile.type?.startsWith('video/') ? 'video' : 'image';
  } else if (notificationsState.existingMediaType) {
    mediaType = notificationsState.existingMediaType;
  }

  // Update popup content
  updatePreviewPopup({
    title,
    content,
    media_url: mediaPreviewUrl,
    media_type: mediaType,
    aspect_ratio: selectedAspectRatio,
    link,
  });

  // Show popup
  previewPopupElement.classList.add('active');
  document.body.style.overflow = 'hidden';
}

function addPreviewPopupStyles() {
  // Always remove and re-add styles to ensure latest version
  const existingStyle = document.getElementById('admin-preview-popup-styles');
  if (existingStyle) {
    existingStyle.remove();
  }

  const style = document.createElement('style');
  style.id = 'admin-preview-popup-styles';
  style.textContent = `
    .homepage-notification-overlay {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      bottom: 0;
      background: rgba(0, 0, 0, 0.75);
      backdrop-filter: blur(8px);
      -webkit-backdrop-filter: blur(8px);
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 99999;
      padding: 20px;
      opacity: 0;
      visibility: hidden;
      transition: opacity 0.3s ease, visibility 0.3s ease;
    }

    .homepage-notification-overlay.active {
      opacity: 1;
      visibility: visible;
    }

    .homepage-notification-container {
      position: relative;
      max-width: 420px;
      width: 100%;
      max-height: calc(100vh - 40px);
      background: #fff;
      border-radius: 20px;
      overflow: hidden;
      box-shadow: 0 25px 80px rgba(0, 0, 0, 0.3);
      transform: scale(0.9) translateY(20px);
      transition: transform 0.4s cubic-bezier(0.34, 1.56, 0.64, 1);
      display: flex;
      flex-direction: column;
    }

    .homepage-notification-overlay.active .homepage-notification-container {
      transform: scale(1) translateY(0);
    }

    .notification-popup-close {
      position: absolute;
      top: 12px;
      right: 12px;
      width: 36px;
      height: 36px;
      display: flex;
      align-items: center;
      justify-content: center;
      background: rgba(0, 0, 0, 0.5);
      border: none;
      border-radius: 50%;
      color: #fff;
      cursor: pointer;
      z-index: 10;
      transition: all 0.2s ease;
    }

    .notification-popup-close:hover {
      background: rgba(0, 0, 0, 0.7);
      transform: rotate(90deg);
    }

    .notification-popup-content {
      flex: 1;
      overflow-y: auto;
      overflow-x: hidden;
      max-height: calc(100vh - 140px);
    }

    .notification-popup-media {
      position: relative;
      width: 100%;
      height: 0;
      padding-bottom: 56.25%;
      background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
      overflow: hidden;
      flex-shrink: 0;
    }

    .notification-popup-media img,
    .notification-popup-media video {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      object-fit: contain;
      background: #000;
    }

    .notification-popup-default-media {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
      color: rgba(255, 255, 255, 0.6);
    }

    .notification-popup-body {
      padding: 24px;
      text-align: center;
    }

    .notification-popup-title {
      font-size: 22px;
      font-weight: 700;
      color: #1a1a2e;
      margin: 0 0 12px;
      line-height: 1.3;
    }

    .notification-popup-text {
      font-size: 15px;
      color: #4a5568;
      line-height: 1.6;
      text-align: left;
    }

    .notification-popup-text p,
    .notification-popup-text div {
      margin: 0 0 0.5em;
      text-align: inherit;
    }

    .notification-popup-text p:last-child,
    .notification-popup-text div:last-child {
      margin-bottom: 0;
    }

    .notification-popup-text br:last-child {
      display: none;
    }

    .notification-popup-text strong {
      font-weight: 600;
      color: #1a1a2e;
    }

    .notification-popup-text em {
      font-style: italic;
    }

    .notification-popup-text u {
      text-decoration: underline;
    }

    .notification-popup-cta {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 12px 24px;
      background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
      color: #fff;
      text-decoration: none;
      border-radius: 50px;
      font-size: 15px;
      font-weight: 600;
      transition: all 0.3s ease;
      box-shadow: 0 4px 15px rgba(99, 102, 241, 0.4);
    }

    .notification-popup-cta:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgba(99, 102, 241, 0.5);
      color: #fff;
    }

    .notification-popup-footer {
      padding: 14px 20px;
      background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
      border-top: 1px solid #e2e8f0;
      flex-shrink: 0;
    }

    .notification-dismiss-checkbox {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 10px;
      cursor: pointer;
      font-size: 13px;
      color: #64748b;
      padding: 10px 16px;
      background: white;
      border: 1px solid #e2e8f0;
      border-radius: 50px;
      transition: all 0.2s ease;
      margin: 0 auto;
      max-width: fit-content;
    }

    .notification-dismiss-checkbox:hover {
      border-color: #0ea5e9;
      background: #f0f9ff;
      color: #0284c7;
    }

    .notification-dismiss-checkbox input[type="checkbox"] {
      position: relative;
      width: 18px;
      height: 18px;
      appearance: none;
      -webkit-appearance: none;
      background: white;
      border: 2px solid #cbd5e1;
      border-radius: 4px;
      cursor: pointer;
      transition: all 0.2s ease;
      flex-shrink: 0;
    }

    .notification-dismiss-checkbox span {
      user-select: none;
      font-weight: 500;
      white-space: nowrap;
    }
  `;
  document.head.appendChild(style);
}

function createPreviewPopup() {
  // Inject styles first
  addPreviewPopupStyles();

  previewPopupElement = document.createElement('div');
  previewPopupElement.className = 'homepage-notification-overlay admin-preview-mode';
  previewPopupElement.innerHTML = `
    <div class="homepage-notification-container">
      <button type="button" class="notification-popup-close" aria-label="Đóng">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <line x1="18" y1="6" x2="6" y2="18"></line>
          <line x1="6" y1="6" x2="18" y2="18"></line>
        </svg>
      </button>

      <div class="notification-popup-content">
        <div class="notification-popup-media" data-aspect="16:9">
          <!-- Media content will be inserted here -->
        </div>
        <div class="notification-popup-body">
          <h2 class="notification-popup-title"></h2>
          <div class="notification-popup-text"></div>
          <a href="#" class="notification-popup-cta" target="_blank" rel="noopener" style="display: none;">
            Xem chi tiết
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M5 12h14M12 5l7 7-7 7"></path>
            </svg>
          </a>
        </div>
      </div>

      <div class="notification-popup-footer">
        <label class="notification-dismiss-checkbox">
          <input type="checkbox" />
          <span>Không hiển thị lại trong 24 giờ</span>
        </label>
      </div>
    </div>
  `;

  // Add preview badge
  const badge = document.createElement('div');
  badge.className = 'preview-mode-badge';
  badge.innerHTML = '<i class="fas fa-eye"></i> Chế độ xem trước';
  badge.style.cssText = `
    position: absolute;
    top: 20px;
    left: 50%;
    transform: translateX(-50%);
    background: linear-gradient(135deg, #0ea5e9 0%, #0284c7 100%);
    color: white;
    padding: 8px 16px;
    border-radius: 50px;
    font-size: 13px;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 8px;
    box-shadow: 0 4px 15px rgba(14, 165, 233, 0.4);
    z-index: 10;
  `;
  previewPopupElement.appendChild(badge);

  document.body.appendChild(previewPopupElement);

  // Event listeners
  const closeBtn = previewPopupElement.querySelector('.notification-popup-close');
  closeBtn?.addEventListener('click', closePreviewPopup);

  previewPopupElement.addEventListener('click', (e) => {
    if (e.target === previewPopupElement) {
      closePreviewPopup();
    }
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && previewPopupElement?.classList.contains('active')) {
      closePreviewPopup();
    }
  });
}

function updatePreviewPopup(notification) {
  if (!previewPopupElement) return;

  // Update media
  const mediaContainer = previewPopupElement.querySelector('.notification-popup-media');
  if (mediaContainer) {
    const aspectRatio = notification.aspect_ratio || '16:9';
    mediaContainer.setAttribute('data-aspect', aspectRatio);

    let paddingBottom = '56.25%';
    if (aspectRatio === '1:1') paddingBottom = '100%';
    else if (aspectRatio === '9:16') paddingBottom = '177.78%';
    else if (aspectRatio === '4:3') paddingBottom = '75%';
    mediaContainer.style.paddingBottom = paddingBottom;

    if (notification.media_url) {
      if (notification.media_type === 'video') {
        mediaContainer.innerHTML = `<video src="${notification.media_url}" autoplay muted loop playsinline></video>`;
      } else {
        mediaContainer.innerHTML = `<img src="${notification.media_url}" alt="${escapeHtml(
          notification.title
        )}" />`;
      }
    } else {
      mediaContainer.innerHTML = `
        <div class="notification-popup-default-media">
          <svg width="60" height="60" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
            <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
            <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
          </svg>
        </div>
      `;
    }
  }

  // Update title and content
  const titleEl = previewPopupElement.querySelector('.notification-popup-title');
  const textEl = previewPopupElement.querySelector('.notification-popup-text');
  const ctaEl = previewPopupElement.querySelector('.notification-popup-cta');

  if (titleEl) titleEl.textContent = notification.title;
  if (textEl) textEl.innerHTML = formatContentForPreview(notification.content);

  // Update CTA button
  if (ctaEl) {
    if (notification.link) {
      ctaEl.href = notification.link;
      ctaEl.style.display = 'inline-flex';
    } else {
      ctaEl.style.display = 'none';
    }
  }
}

function closePreviewPopup() {
  if (previewPopupElement) {
    previewPopupElement.classList.remove('active');
    document.body.style.overflow = '';
  }
}

function formatContentForPreview(content) {
  if (!content) return '';

  // Clean up trailing empty elements and line breaks
  let cleaned = content
    .replace(/(<br\s*\/?>)+$/gi, '') // Remove trailing <br>
    .replace(/(<div><br\s*\/?><\/div>)+$/gi, '') // Remove trailing empty divs with br
    .replace(/(<p><br\s*\/?><\/p>)+$/gi, '') // Remove trailing empty paragraphs with br
    .replace(/(<div>\s*<\/div>)+$/gi, '') // Remove trailing empty divs
    .replace(/(<p>\s*<\/p>)+$/gi, '') // Remove trailing empty paragraphs
    .replace(/\s+$/g, ''); // Trim trailing whitespace

  return cleaned;
}

/**
 * Normalize HTML content from contenteditable for consistent storage
 * Browsers create different HTML when pressing Enter (div, br, p...)
 * This function normalizes it to use <br> for line breaks while preserving formatting
 */
function normalizeEditorContent(html) {
  if (!html) return '';

  let normalized = html;

  // First, protect aligned divs by replacing them temporarily
  const alignedDivs = [];
  normalized = normalized.replace(
    /<div style="text-align:\s*(center|right|left);?">([\s\S]*?)<\/div>/gi,
    (match, align, content) => {
      const placeholder = `__ALIGN_${alignedDivs.length}__`;
      alignedDivs.push({ align, content });
      return placeholder;
    }
  );

  // Remove empty tags at start/end
  normalized = normalized.replace(/^(<div><br><\/div>|<br\s*\/?>)+/gi, '');
  normalized = normalized.replace(/(<div><br><\/div>|<br\s*\/?>)+$/gi, '');

  // Convert <div><br></div> -> <br>
  normalized = normalized.replace(/<div><br\s*\/?><\/div>/gi, '<br>');

  // Handle <div>content</div> -> content<br>
  // Use a loop to handle nested content properly
  let prevNormalized;
  do {
    prevNormalized = normalized;
    normalized = normalized.replace(/<div>([^<]*(?:<(?!div)[^<]*)*)<\/div>/gi, '$1<br>');
  } while (normalized !== prevNormalized);

  // Convert <p> to <br>
  normalized = normalized.replace(/<p><br\s*\/?><\/p>/gi, '<br>');
  normalized = normalized.replace(/<p>([\s\S]*?)<\/p>/gi, '$1<br>');

  // Clean up multiple consecutive <br>
  normalized = normalized.replace(/(<br\s*\/?>){3,}/gi, '<br><br>');

  // Restore aligned divs
  alignedDivs.forEach((item, index) => {
    const placeholder = `__ALIGN_${index}__`;
    normalized = normalized.replace(
      placeholder,
      `<div style="text-align:${item.align}">${item.content}</div>`
    );
  });

  // Remove trailing <br>
  normalized = normalized.replace(/(<br\s*\/?>)+$/gi, '');

  // Clean up empty style attributes
  normalized = normalized.replace(/\s*style=""\s*/gi, '');

  // Remove &nbsp; at start/end of content
  normalized = normalized.replace(/^(&nbsp;|\s)+/gi, '');
  normalized = normalized.replace(/(&nbsp;|\s)+$/gi, '');

  return normalized.trim();
}

// ============================================================================
// FORM VALIDATION & SUBMISSION
// ============================================================================

function initFormValidation() {
  const titleInput = document.getElementById('notification-title');

  if (titleInput) {
    titleInput.addEventListener('input', () => {
      updateCharCounter('notification-title', 'title-counter', 100);
    });
  }

  // Initialize schedule toggle
  initScheduleToggle();

  // Content editor char counter is handled by initContentEditorToolbar
}

function initScheduleToggle() {
  const scheduleToggle = document.getElementById('notification-schedule-toggle');
  const datetimeRow = document.getElementById('schedule-datetime-row');
  const scheduleHint = document.getElementById('schedule-hint');

  if (scheduleToggle) {
    scheduleToggle.addEventListener('change', () => {
      updateScheduleUI();
    });
  }
}

function updateScheduleUI() {
  const scheduleToggle = document.getElementById('notification-schedule-toggle');
  const datetimeRow = document.getElementById('schedule-datetime-row');
  const scheduleHint = document.getElementById('schedule-hint');
  const publishBtn = document.getElementById('notification-publish-btn');

  const isScheduled = scheduleToggle?.checked || false;

  // Show/hide datetime fields based on toggle (always show for end date visibility)
  // Just update the hint and button text
  if (scheduleHint) {
    scheduleHint.textContent = isScheduled
      ? 'Thông báo sẽ được lên lịch và tự động gửi vào thời điểm bắt đầu.'
      : 'Tắt = Gửi ngay lập tức khi lưu. Bật = Lên lịch gửi vào thời điểm đã chọn.';
  }

  // Update publish button text
  if (publishBtn) {
    publishBtn.innerHTML = isScheduled
      ? '<i class="fas fa-clock"></i><span>Lên lịch</span>'
      : '<i class="fas fa-paper-plane"></i><span>Gửi ngay</span>';
  }
}

function updateCharCounter(inputId, counterId, maxLength) {
  const input = document.getElementById(inputId);
  const counter = document.getElementById(counterId);
  if (input && counter) {
    const length = input.value?.length || 0;
    counter.textContent = length;
    counter.parentElement.style.color = length > maxLength * 0.9 ? 'var(--semi-color-warning)' : '';
  }
}

async function saveNotification(status) {
  const form = document.getElementById('notification-form');
  if (!form) return;

  // Basic validation
  const title = document.getElementById('notification-title').value.trim();
  const contentEditor = document.getElementById('notification-content');
  const rawContent = contentEditor ? contentEditor.innerHTML.trim() : '';
  const contentText = contentEditor ? contentEditor.innerText.trim() : '';

  // Normalize HTML content for consistent storage and display
  const content = normalizeEditorContent(rawContent);

  if (!title) {
    toastError('Vui lòng nhập tiêu đề thông báo');
    document.getElementById('notification-title').focus();
    return;
  }

  if (!contentText) {
    toastError('Vui lòng nhập nội dung thông báo');
    contentEditor?.focus();
    return;
  }

  // Determine final status based on schedule toggle
  const scheduleToggle = document.getElementById('notification-schedule-toggle');
  const isScheduled = scheduleToggle?.checked || false;

  // If publishing and schedule is enabled, set status to 'scheduled'
  // If publishing and schedule is disabled, set status to 'active' (immediate)
  // If saving as draft, keep 'draft'
  let finalStatus = status;
  if (status === 'active' && isScheduled) {
    finalStatus = 'scheduled';
  }

  // Collect form data
  const formData = new FormData();
  formData.append('title', title);
  formData.append('content', content);
  formData.append('type', document.getElementById('notification-type-input').value);
  formData.append('status', finalStatus);
  formData.append('link', document.getElementById('notification-link').value.trim());
  formData.append('start_date', document.getElementById('notification-start-date').value);
  formData.append('end_date', document.getElementById('notification-end-date').value);

  // Slideshow settings
  formData.append('sort_order', document.getElementById('notification-sort-order')?.value || '0');
  formData.append(
    'slide_duration',
    document.getElementById('notification-slide-duration')?.value || '5'
  );

  // Add notification ID if editing
  const notificationId = document.getElementById('notification-id').value;
  if (notificationId) {
    formData.append('id', notificationId);
  }

  // Always add aspect ratio if there's media (new upload, URL, or existing)
  const hasMedia = notificationsState.mediaFile || notificationsState.mediaPreviewUrl;
  if (hasMedia) {
    const selectedAspectRatio =
      document.querySelector('.aspect-ratio-option.active input')?.value ||
      document.querySelector('.aspect-ratio-option input:checked')?.value ||
      '16:9';
    formData.append('aspect_ratio', selectedAspectRatio);
  }

  // Add media file or URL
  if (notificationsState.mediaFile) {
    formData.append('media', notificationsState.mediaFile);
  } else if (notificationsState.mediaFromUrl && notificationsState.mediaPreviewUrl) {
    // Media is from URL input - send the URL
    formData.append('media_url', notificationsState.mediaPreviewUrl);
  }

  // Add push options for staff notifications
  const type = document.getElementById('notification-type-input').value;
  if (type === 'staff') {
    formData.append(
      'send_push',
      document.getElementById('send-push-notification')?.checked ? '1' : '0'
    );
    formData.append('show_in_app', document.getElementById('show-in-app')?.checked ? '1' : '0');
  }

  // Collect selected branches
  const branchCheckboxes = document.querySelectorAll('#notification-branch-list input:checked');
  const branches = Array.from(branchCheckboxes).map((cb) => cb.value);
  formData.append('branches', JSON.stringify(branches));

  // Show loading state
  const publishBtn = document.getElementById('notification-publish-btn');
  const draftBtn = document.getElementById('notification-draft-btn');
  const originalPublishText = publishBtn?.innerHTML;
  const originalDraftText = draftBtn?.innerHTML;

  if (status === 'active' && publishBtn) {
    publishBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Đang lưu...';
    publishBtn.disabled = true;
  } else if (status === 'draft' && draftBtn) {
    draftBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Đang lưu...';
    draftBtn.disabled = true;
  }

  try {
    const endpoint = notificationId
      ? `${checkinData.restUrl}notifications/${notificationId}`
      : `${checkinData.restUrl}notifications`;

    // Determine if we have file upload
    const hasFileUpload = notificationsState.mediaFile !== null;

    let fetchOptions = {
      method: notificationId ? 'PUT' : 'POST',
      headers: {
        'X-WP-Nonce': checkinData.nonce,
      },
    };

    if (hasFileUpload) {
      // Use FormData for file uploads (multipart)
      fetchOptions.body = formData;
    } else {
      // Use JSON for non-file updates (better parsing in WordPress REST API)
      const jsonData = {
        title,
        content,
        type: document.getElementById('notification-type-input').value,
        status: finalStatus,
        link: document.getElementById('notification-link').value.trim(),
        start_date: document.getElementById('notification-start-date').value,
        end_date: document.getElementById('notification-end-date').value,
        sort_order: document.getElementById('notification-sort-order')?.value || '0',
        slide_duration: document.getElementById('notification-slide-duration')?.value || '5',
        aspect_ratio:
          document.querySelector('.aspect-ratio-option.active input')?.value ||
          document.querySelector('.aspect-ratio-option input:checked')?.value ||
          '16:9',
        branches: JSON.stringify(
          Array.from(document.querySelectorAll('#notification-branch-list input:checked')).map(
            (cb) => cb.value
          )
        ),
      };

      if (notificationsState.mediaPreviewUrl && notificationsState.mediaFromUrl) {
        jsonData.media_url = notificationsState.mediaPreviewUrl;
      }

      if (type === 'staff') {
        jsonData.send_push = document.getElementById('send-push-notification')?.checked ? '1' : '0';
        jsonData.show_in_app = document.getElementById('show-in-app')?.checked ? '1' : '0';
      }

      fetchOptions.headers['Content-Type'] = 'application/json';
      fetchOptions.body = JSON.stringify(jsonData);
    }

    const response = await fetch(endpoint, fetchOptions);

    const result = await response.json();

    if (result.success) {
      toastSuccess(notificationId ? 'Cập nhật thông báo thành công!' : 'Tạo thông báo thành công!');
      closeNotificationModal();
      loadNotifications();
    } else {
      throw new Error(result.message || 'Có lỗi xảy ra');
    }
  } catch (error) {
    console.error('Error saving notification:', error);
    toastError(error.message || 'Không thể lưu thông báo');
  } finally {
    if (publishBtn) {
      publishBtn.innerHTML = originalPublishText;
      publishBtn.disabled = false;
    }
    if (draftBtn) {
      draftBtn.innerHTML = originalDraftText;
      draftBtn.disabled = false;
    }
  }
}

// ============================================================================
// FILTER EVENTS
// ============================================================================

function initFilterEvents() {
  const typeFilter = document.getElementById('notification-type-filter');
  const statusFilter = document.getElementById('notification-status-filter');
  const branchFilter = document.getElementById('notification-branch-filter');

  if (typeFilter) {
    typeFilter.addEventListener('change', (e) => {
      notificationsState.currentType = e.target.value;
      notificationsState.currentPage = 1;
      loadNotifications();
    });
  }

  if (statusFilter) {
    statusFilter.addEventListener('change', (e) => {
      notificationsState.currentFilter = e.target.value;
      notificationsState.currentPage = 1;
      loadNotifications();
    });
  }

  if (branchFilter) {
    branchFilter.addEventListener('change', () => {
      notificationsState.currentPage = 1;
      loadNotifications();
    });
  }
}

// ============================================================================
// BRANCH SELECTOR
// ============================================================================

function initBranchSelector() {
  // Check if multi-branch mode is enabled
  const branchModeEnabled =
    (typeof checkinData !== 'undefined' &&
      (checkinData.branchModeEnabled === '1' ||
        checkinData.branchModeEnabled === true ||
        checkinData.isMultiBranchEnabled === true)) ||
    (typeof isMultiBranchEnabled !== 'undefined' && isMultiBranchEnabled);

  if (branchModeEnabled) {
    const branchGroup = document.getElementById('notification-branch-group');
    const branchFilterGroup = document.getElementById('notification-branch-filter-group');

    if (branchGroup) branchGroup.style.display = 'block';
    if (branchFilterGroup) branchFilterGroup.style.display = 'flex';

    // Get branches from available sources
    let branches = [];
    if (
      typeof checkinData !== 'undefined' &&
      checkinData.branches &&
      Array.isArray(checkinData.branches) &&
      checkinData.branches.length > 0
    ) {
      branches = checkinData.branches;
    } else if (
      typeof branchHelper !== 'undefined' &&
      branchHelper?.branches &&
      Array.isArray(branchHelper.branches)
    ) {
      branches = branchHelper.branches;
    } else if (typeof locations !== 'undefined' && Array.isArray(locations)) {
      branches = locations;
    }

    // Filter out invalid branches (no id or name)
    branches = branches.filter((b) => b && b.id && (b.name || b.branch_name));

    if (branches.length > 0) {
      populateBranchOptions(branches);
    }
  } else {
    // Hide branch selector when multi-branch is disabled
    const branchGroup = document.getElementById('notification-branch-group');
    const branchFilterGroup = document.getElementById('notification-branch-filter-group');
    if (branchGroup) branchGroup.style.display = 'none';
    if (branchFilterGroup) branchFilterGroup.style.display = 'none';
  }
}

function populateBranchOptions(branches) {
  const branchList = document.getElementById('notification-branch-list');
  const branchFilter = document.getElementById('notification-branch-filter');

  if (branchList && branches.length > 0) {
    branchList.innerHTML = branches
      .map(
        (branch) => `
        <label>
          <input type="checkbox" value="${branch.id}" />
          <span>${branch.name || branch.branch_name || 'Chi nhánh ' + branch.id}</span>
        </label>
      `
      )
      .join('');

    // Add click event for visual toggle
    branchList.querySelectorAll('label').forEach((label) => {
      label.addEventListener('click', () => {
        const checkbox = label.querySelector('input');
        setTimeout(() => {
          label.classList.toggle('selected', checkbox.checked);
        }, 0);
      });
    });
  }

  if (branchFilter && branches.length > 0) {
    // Clear existing options except first one (All)
    while (branchFilter.options.length > 1) {
      branchFilter.remove(1);
    }

    branches.forEach((branch) => {
      const option = document.createElement('option');
      option.value = branch.id;
      option.textContent = branch.name || branch.branch_name || 'Chi nhánh ' + branch.id;
      branchFilter.appendChild(option);
    });
  }
}

// ============================================================================
// DATA LOADING
// ============================================================================

async function loadNotifications() {
  if (notificationsState.isLoading) return;
  notificationsState.isLoading = true;

  const listContainer = document.getElementById('notification-list');
  if (!listContainer) return;

  // Show loading state
  listContainer.innerHTML = `
    <div class="notification-loading-state" style="grid-column: 1 / -1; text-align: center; padding: 40px;">
      <i class="fas fa-spinner fa-spin" style="font-size: 32px; color: var(--semi-color-primary);"></i>
      <p style="margin-top: 16px; color: var(--semi-color-text-2);">Đang tải thông báo...</p>
    </div>
  `;

  try {
    const params = new URLSearchParams({
      status: notificationsState.currentFilter,
      page: notificationsState.currentPage,
      per_page: 12,
    });

    // Only add type filter if not 'all'
    if (notificationsState.currentType !== 'all') {
      params.append('type', notificationsState.currentType);
    }

    const branchFilter = document.getElementById('notification-branch-filter');
    if (branchFilter && branchFilter.value !== 'all') {
      params.append('branch_id', branchFilter.value);
    }

    const response = await fetch(`${checkinData.restUrl}notifications?${params.toString()}`, {
      headers: {
        'X-WP-Nonce': checkinData.nonce,
      },
    });

    const result = await response.json();

    if (result.success) {
      notificationsState.notifications = result.data || [];
      notificationsState.totalPages = result.total_pages || 1;
      renderNotificationList();
      renderPagination();
    } else {
      throw new Error(result.message || 'Failed to load notifications');
    }
  } catch (error) {
    console.error('Error loading notifications:', error);
    listContainer.innerHTML = `
      <div class="notification-empty-state">
        <i class="fas fa-exclamation-triangle"></i>
        <p>Không thể tải danh sách thông báo</p>
        <span>${error.message}</span>
      </div>
    `;
  } finally {
    notificationsState.isLoading = false;
  }
}

function renderNotificationList() {
  const listContainer = document.getElementById('notification-list');
  if (!listContainer) return;

  if (notificationsState.notifications.length === 0) {
    listContainer.innerHTML = `
      <div class="notification-empty-state">
        <i class="fas fa-bell-slash"></i>
        <p>Chưa có thông báo nào</p>
        <span>Nhấn "Tạo thông báo mới" để bắt đầu</span>
      </div>
    `;
    return;
  }

  // Group by type if showing all types
  const isShowingAllTypes = notificationsState.currentType === 'all';

  if (isShowingAllTypes) {
    // Group notifications by type
    const groupedByType = {};
    notificationsState.notifications.forEach((notification) => {
      const type = notification.type || 'homepage';
      if (!groupedByType[type]) {
        groupedByType[type] = [];
      }
      groupedByType[type].push(notification);
    });

    // Render grouped HTML
    const typeLabels = {
      homepage: '<i class="fas fa-home"></i> Trang chủ',
      staff: '<i class="fas fa-users"></i> Nhân viên',
    };

    let html = '';
    Object.keys(groupedByType).forEach((type) => {
      const label = typeLabels[type] || type;
      html += `
        <div class="notification-group">
          <div class="notification-group-header">${label}</div>
          <div class="notification-group-list" data-type="${type}">
            ${groupedByType[type]
              .map((notification) => createNotificationCard(notification))
              .join('')}
          </div>
        </div>
      `;
    });

    listContainer.innerHTML = html;
  } else {
    // Flat list when filtering by specific type
    listContainer.innerHTML = notificationsState.notifications
      .map((notification) => createNotificationCard(notification))
      .join('');
  }

  // Add event listeners to action buttons
  listContainer.querySelectorAll('.btn-preview').forEach((btn) => {
    btn.addEventListener('click', () => {
      const id = btn.dataset.id;
      const notification = notificationsState.notifications.find((n) => n.id == id);
      if (notification) openPreviewModal(notification);
    });
  });

  listContainer.querySelectorAll('.btn-edit').forEach((btn) => {
    btn.addEventListener('click', () => {
      const id = btn.dataset.id;
      const notification = notificationsState.notifications.find((n) => n.id == id);
      if (notification) openNotificationModal(notification);
    });
  });

  listContainer.querySelectorAll('.btn-delete').forEach((btn) => {
    btn.addEventListener('click', () => {
      const id = btn.dataset.id;
      confirmDeleteNotification(id);
    });
  });

  // Event handler cho views link
  listContainer.querySelectorAll('.notification-views-link').forEach((link) => {
    link.addEventListener('click', (e) => {
      e.stopPropagation();
      const id = link.dataset.id;
      openViewersModal(id);
    });
  });

  // Initialize drag-drop sorting
  initDragDropSorting(listContainer);
}

function createNotificationCard(notification) {
  const statusLabels = {
    active: 'Đang hoạt động',
    scheduled: 'Đã lên lịch',
    expired: 'Đã hết hạn',
    draft: 'Bản nháp',
  };

  const typeLabels = {
    homepage: '<i class="fas fa-home"></i> Trang chủ',
    staff: '<i class="fas fa-users"></i> Nhân viên',
  };

  const mediaHtml = notification.media_url
    ? notification.media_type === 'video'
      ? `<video src="${notification.media_url}" muted></video>`
      : `<img src="${notification.media_url}" alt="${notification.title}" />`
    : `<div class="no-media-placeholder"><i class="fas fa-image"></i></div>`;

  const startDate = notification.start_date
    ? new Date(notification.start_date).toLocaleDateString('vi-VN')
    : 'Không giới hạn';
  const endDate = notification.end_date
    ? new Date(notification.end_date).toLocaleDateString('vi-VN')
    : 'Không giới hạn';

  const sortOrder = notification.sort_order ?? 0;

  return `
    <div class="notification-card" data-id="${
      notification.id
    }" data-sort="${sortOrder}" draggable="true">
      <div class="notification-card-drag-handle" title="Kéo để sắp xếp thứ tự">
        <span class="sort-order-badge">${sortOrder}</span>
      </div>
      <div class="notification-card-media">
        ${mediaHtml}
        <span class="notification-card-status ${notification.status}">${
    statusLabels[notification.status] || notification.status
  }</span>
        <span class="notification-card-type">${
          typeLabels[notification.type] || notification.type
        }</span>
      </div>
      <div class="notification-card-content">
        <h4 class="notification-card-title">${escapeHtml(notification.title)}</h4>
        <p class="notification-card-text">${escapeHtml(stripHtml(notification.content))}</p>
        <div class="notification-card-meta">
          <span><i class="fas fa-calendar-alt"></i> ${startDate} - ${endDate}</span>
          ${
            notification.type === 'staff' && notification.views
              ? `<span class="notification-views-link" data-id="${notification.id}" title="Click để xem danh sách người đã xem"><i class="fas fa-eye"></i> ${notification.views} lượt xem</span>`
              : notification.views
              ? `<span><i class="fas fa-eye"></i> ${notification.views} lượt xem</span>`
              : ''
          }
        </div>
        <div class="notification-card-actions">
          <button type="button" class="btn-preview" data-id="${notification.id}">
            <i class="fas fa-eye"></i> Xem trước
          </button>
          <button type="button" class="btn-edit" data-id="${notification.id}">
            <i class="fas fa-edit"></i> Sửa
          </button>
          <button type="button" class="btn-delete" data-id="${notification.id}">
            <i class="fas fa-trash-alt"></i> Xóa
          </button>
        </div>
      </div>
    </div>
  `;
}

// ============================================================================
// PREVIEW MODAL
// ============================================================================

function openPreviewModal(notification) {
  // Use shared preview popup instead of separate modal
  if (!previewPopupElement) {
    createPreviewPopup();
  }

  updatePreviewPopup({
    title: notification.title,
    content: notification.content,
    media_url: notification.media_url,
    media_type: notification.media_type || 'image',
    aspect_ratio: notification.aspect_ratio || '16:9',
    link: notification.link,
  });

  previewPopupElement.classList.add('active');
  document.body.style.overflow = 'hidden';
}

function closePreviewModal() {
  // Use shared preview popup
  if (previewPopupElement) {
    previewPopupElement.classList.remove('active');
    document.body.style.overflow = '';

    // Stop video if playing
    const video = previewPopupElement.querySelector('video');
    if (video) video.pause();
  }
}

// ============================================================================
// DELETE NOTIFICATION
// ============================================================================

async function confirmDeleteNotification(id) {
  const confirmed = await showConfirm('Bạn có chắc chắn muốn xóa thông báo này?', 'Xác nhận xóa');
  if (!confirmed) return;
  deleteNotification(id);
}

async function deleteNotification(id) {
  try {
    const response = await fetch(`${checkinData.restUrl}notifications/${id}`, {
      method: 'DELETE',
      headers: {
        'X-WP-Nonce': checkinData.nonce,
        'Content-Type': 'application/json',
      },
    });

    const result = await response.json();

    if (result.success) {
      toastSuccess('Đã xóa thông báo thành công');
      loadNotifications();
    } else {
      throw new Error(result.message || 'Có lỗi xảy ra');
    }
  } catch (error) {
    console.error('Error deleting notification:', error);
    toastError(error.message || 'Không thể xóa thông báo');
  }
}

// ============================================================================
// VIEWERS MODAL - Xem danh sách người đã xem thông báo
// ============================================================================

let viewersModalElement = null;

function createViewersModal() {
  viewersModalElement = document.createElement('div');
  viewersModalElement.className = 'viewers-modal';
  viewersModalElement.innerHTML = `
    <div class="viewers-modal-overlay"></div>
    <div class="viewers-modal-content">
      <div class="viewers-modal-header">
        <h3><i class="fas fa-users"></i> Danh sách người đã xem</h3>
        <button type="button" class="viewers-modal-close"><i class="fas fa-times"></i></button>
      </div>
      <div class="viewers-modal-body">
        <div class="viewers-loading">
          <i class="fas fa-spinner fa-spin"></i> Đang tải...
        </div>
        <div class="viewers-stats"></div>
        <div class="viewers-list"></div>
        <div class="viewers-empty" style="display: none;">
          <i class="fas fa-eye-slash"></i>
          <p>Chưa có người xem thông báo này</p>
        </div>
      </div>
    </div>
  `;
  document.body.appendChild(viewersModalElement);

  // Event listeners
  viewersModalElement
    .querySelector('.viewers-modal-overlay')
    .addEventListener('click', closeViewersModal);
  viewersModalElement
    .querySelector('.viewers-modal-close')
    .addEventListener('click', closeViewersModal);
}

function closeViewersModal() {
  if (viewersModalElement) {
    viewersModalElement.classList.remove('active');
    document.body.style.overflow = '';
  }
}

async function openViewersModal(notificationId) {
  if (!viewersModalElement) {
    createViewersModal();
  }

  // Show modal with loading state
  viewersModalElement.classList.add('active');
  document.body.style.overflow = 'hidden';

  const loadingEl = viewersModalElement.querySelector('.viewers-loading');
  const statsEl = viewersModalElement.querySelector('.viewers-stats');
  const listEl = viewersModalElement.querySelector('.viewers-list');
  const emptyEl = viewersModalElement.querySelector('.viewers-empty');

  loadingEl.style.display = 'flex';
  statsEl.innerHTML = '';
  listEl.innerHTML = '';
  emptyEl.style.display = 'none';

  try {
    const response = await fetch(`${checkinData.restUrl}notifications/${notificationId}/viewers`, {
      headers: {
        'X-WP-Nonce': checkinData.nonce,
      },
    });

    const result = await response.json();
    loadingEl.style.display = 'none';

    if (result.success) {
      const { total_views, unique_views, viewers } = result.data;

      // Hiển thị thống kê
      statsEl.innerHTML = `
        <div class="viewers-stats-item">
          <span class="viewers-stats-value">${total_views}</span>
          <span class="viewers-stats-label">Tổng lượt xem</span>
        </div>
        <div class="viewers-stats-item">
          <span class="viewers-stats-value">${unique_views}</span>
          <span class="viewers-stats-label">Người xem</span>
        </div>
      `;

      if (viewers && viewers.length > 0) {
        listEl.innerHTML = viewers
          .map(
            (viewer) => `
          <div class="viewer-item">
            <div class="viewer-avatar">
              ${
                viewer.avatar
                  ? `<img src="${viewer.avatar}" alt="${escapeHtml(viewer.display_name)}" />`
                  : `<span class="viewer-avatar-placeholder">${viewer.display_name
                      .charAt(0)
                      .toUpperCase()}</span>`
              }
            </div>
            <div class="viewer-info">
              <div class="viewer-name">${escapeHtml(viewer.display_name)}</div>
              <div class="viewer-meta">
                <span class="viewer-role">${escapeHtml(viewer.role)}</span>
                <span class="viewer-time"><i class="fas fa-clock"></i> ${formatRelativeTime(
                  viewer.viewed_at
                )}</span>
              </div>
            </div>
          </div>
        `
          )
          .join('');
      } else {
        emptyEl.style.display = 'flex';
      }
    } else {
      throw new Error(result.message || 'Có lỗi xảy ra');
    }
  } catch (error) {
    loadingEl.style.display = 'none';
    console.error('Error loading viewers:', error);
    listEl.innerHTML = `<div class="viewers-error"><i class="fas fa-exclamation-circle"></i> ${
      error.message || 'Không thể tải danh sách người xem'
    }</div>`;
  }
}

function formatRelativeTime(dateString) {
  const date = new Date(dateString);
  const now = new Date();
  const diffMs = now - date;
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);

  if (diffMins < 1) return 'Vừa xong';
  if (diffMins < 60) return `${diffMins} phút trước`;
  if (diffHours < 24) return `${diffHours} giờ trước`;
  if (diffDays < 7) return `${diffDays} ngày trước`;
  return date.toLocaleDateString('vi-VN');
}

// ============================================================================
// PAGINATION
// ============================================================================

function renderPagination() {
  const container = document.getElementById('notification-pagination');
  if (!container) return;

  if (notificationsState.totalPages <= 1) {
    container.innerHTML = '';
    return;
  }

  let html = '';

  // Previous button
  html += `
    <button type="button" ${notificationsState.currentPage === 1 ? 'disabled' : ''} data-page="${
    notificationsState.currentPage - 1
  }">
      <i class="fas fa-chevron-left"></i>
    </button>
  `;

  // Page numbers
  const maxVisible = 5;
  let startPage = Math.max(1, notificationsState.currentPage - Math.floor(maxVisible / 2));
  let endPage = Math.min(notificationsState.totalPages, startPage + maxVisible - 1);

  if (endPage - startPage < maxVisible - 1) {
    startPage = Math.max(1, endPage - maxVisible + 1);
  }

  if (startPage > 1) {
    html += `<button type="button" data-page="1">1</button>`;
    if (startPage > 2) {
      html += `<button type="button" disabled>...</button>`;
    }
  }

  for (let i = startPage; i <= endPage; i++) {
    html += `
      <button type="button" class="${
        i === notificationsState.currentPage ? 'active' : ''
      }" data-page="${i}">
        ${i}
      </button>
    `;
  }

  if (endPage < notificationsState.totalPages) {
    if (endPage < notificationsState.totalPages - 1) {
      html += `<button type="button" disabled>...</button>`;
    }
    html += `<button type="button" data-page="${notificationsState.totalPages}">${notificationsState.totalPages}</button>`;
  }

  // Next button
  html += `
    <button type="button" ${
      notificationsState.currentPage === notificationsState.totalPages ? 'disabled' : ''
    } data-page="${notificationsState.currentPage + 1}">
      <i class="fas fa-chevron-right"></i>
    </button>
  `;

  container.innerHTML = html;

  // Add click events
  container.querySelectorAll('button[data-page]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const page = parseInt(btn.dataset.page);
      if (page && page !== notificationsState.currentPage) {
        notificationsState.currentPage = page;
        loadNotifications();
      }
    });
  });
}

// ============================================================================
// UTILITY FUNCTIONS
// ============================================================================

function formatDateTimeLocal(date) {
  const pad = (n) => String(n).padStart(2, '0');
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(
    date.getHours()
  )}:${pad(date.getMinutes())}`;
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

function stripHtml(html) {
  if (!html) return '';
  const div = document.createElement('div');
  div.innerHTML = html;
  return div.textContent || div.innerText || '';
}

// ============================================================================
// DRAG & DROP SORTING
// ============================================================================

let draggedCard = null;
let dragPlaceholder = null;

function initDragDropSorting(container) {
  if (!container) return;

  // Add CSS for drag-drop if not already added
  addDragDropStyles();

  const isGrouped = container.querySelector('.notification-group') !== null;
  let dragSourceType = null;

  const cards = container.querySelectorAll('.notification-card');

  cards.forEach((card) => {
    // Drag start
    card.addEventListener('dragstart', (e) => {
      draggedCard = card;
      card.classList.add('dragging');

      // Track source group type for grouped layout
      if (isGrouped) {
        const groupList = card.closest('.notification-group-list');
        dragSourceType = groupList ? groupList.dataset.type : null;
      }

      // Create placeholder
      dragPlaceholder = document.createElement('div');
      dragPlaceholder.className = 'notification-card drag-placeholder';
      dragPlaceholder.style.height = card.offsetHeight + 'px';

      // Set drag image
      e.dataTransfer.effectAllowed = 'move';
      e.dataTransfer.setData('text/plain', card.dataset.id);

      // Delay adding placeholder class for visual effect
      setTimeout(() => {
        card.style.opacity = '0.5';
      }, 0);
    });

    // Drag end
    card.addEventListener('dragend', () => {
      card.classList.remove('dragging');
      card.style.opacity = '';
      draggedCard = null;
      dragSourceType = null;

      // Remove placeholder
      if (dragPlaceholder && dragPlaceholder.parentNode) {
        dragPlaceholder.parentNode.removeChild(dragPlaceholder);
      }
      dragPlaceholder = null;

      // Save new order
      saveNewSortOrder(container);
    });

    // Drag over
    card.addEventListener('dragover', (e) => {
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';

      if (!draggedCard || card === draggedCard) return;

      // If grouped, only allow drag within same group
      if (isGrouped) {
        const targetGroupList = card.closest('.notification-group-list');
        const targetType = targetGroupList ? targetGroupList.dataset.type : null;
        if (targetType !== dragSourceType) {
          e.dataTransfer.dropEffect = 'none';
          return;
        }
      }

      const rect = card.getBoundingClientRect();
      const midX = rect.left + rect.width / 2;

      // Determine if mouse is on left or right half
      if (e.clientX < midX) {
        // Insert before this card
        card.parentNode.insertBefore(draggedCard, card);
      } else {
        // Insert after this card
        card.parentNode.insertBefore(draggedCard, card.nextSibling);
      }
    });

    // Prevent default on dragenter
    card.addEventListener('dragenter', (e) => {
      e.preventDefault();
    });
  });

  // Allow dropping on container
  container.addEventListener('dragover', (e) => {
    e.preventDefault();
  });
}

async function saveNewSortOrder(container) {
  const items = [];

  // Check if layout is grouped
  const isGrouped = container.querySelector('.notification-group') !== null;

  if (isGrouped) {
    // Handle grouped layout - each group has independent sort order
    const groups = container.querySelectorAll('.notification-group');
    groups.forEach((group) => {
      const cards = group.querySelectorAll('.notification-card');
      cards.forEach((card, index) => {
        const id = parseInt(card.dataset.id);
        const newSortOrder = index;

        items.push({ id, sort_order: newSortOrder });
        card.dataset.sort = newSortOrder;

        // Update state
        const notification = notificationsState.notifications.find((n) => n.id == id);
        if (notification) {
          notification.sort_order = newSortOrder;
        }

        // Update DOM badge immediately
        const badge = card.querySelector('.sort-order-badge');
        if (badge) {
          badge.textContent = newSortOrder;
        }
      });
    });
  } else {
    // Handle flat layout - global sort order
    const cards = container.querySelectorAll('.notification-card');
    cards.forEach((card, index) => {
      const id = parseInt(card.dataset.id);
      const newSortOrder = index;

      items.push({ id, sort_order: newSortOrder });
      card.dataset.sort = newSortOrder;

      // Update state
      const notification = notificationsState.notifications.find((n) => n.id == id);
      if (notification) {
        notification.sort_order = newSortOrder;
      }

      // Update DOM badge immediately
      const badge = card.querySelector('.sort-order-badge');
      if (badge) {
        badge.textContent = newSortOrder;
      }
    });
  }

  // Save to server
  try {
    const response = await fetch(`${checkinData.restUrl}notifications/reorder`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-WP-Nonce': checkinData.nonce,
      },
      body: JSON.stringify({ items }),
    });

    const result = await response.json();
    if (result.success) {
      toastSuccess('Đã cập nhật thứ tự hiển thị');
    } else {
      throw new Error(result.message || 'Lỗi cập nhật thứ tự');
    }
  } catch (error) {
    console.error('Error saving sort order:', error);
    toastError('Không thể lưu thứ tự. Vui lòng thử lại.');
    // Reload to restore original order
    loadNotifications();
  }
}

function addDragDropStyles() {
  if (document.getElementById('notification-dragdrop-styles')) return;

  const style = document.createElement('style');
  style.id = 'notification-dragdrop-styles';
  style.textContent = `
    .notification-card {
      cursor: default;
      transition: transform 0.15s ease, box-shadow 0.15s ease;
      position: relative;
    }

    .notification-card:hover {
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    }

    .notification-card:hover .notification-card-media {
      filter: brightness(0.85);
    }

    .notification-card-drag-handle {
      position: absolute;
      top: 0;
      left: 50%;
      transform: translateX(-50%);
      width: auto;
      min-width: 50px;
      height: 32px;
      padding: 4px 12px;
      background: transparent;
      display: flex;
      align-items: center;
      justify-content: center;
      cursor: grab;
      z-index: 5;
      opacity: 0;
      transition: opacity 0.2s ease;
      border-radius: 0 0 6px 6px;
    }

    .notification-card:hover .notification-card-drag-handle {
      opacity: 1;
      background: rgba(0, 119, 250, 0.1);
      backdrop-filter: blur(4px);
    }

    .notification-card-drag-handle:hover {
      opacity: 1;
    }

    .notification-card-drag-handle:active {
      cursor: grabbing;
    }

    .sort-order-badge {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-width: 28px;
      height: 28px;
      background: var(--semi-color-primary);
      color: white;
      border-radius: 50%;
      font-size: 14px;
      font-weight: var(--semi-font-weight-semibold);
      box-shadow: 0 2px 6px rgba(0, 119, 250, 0.3);
    }

    .notification-card.dragging {
      opacity: 0.5;
      transform: scale(1.02);
      box-shadow: 0 8px 24px rgba(0, 0, 0, 0.2);
      z-index: 100;
    }

    .notification-card.drag-placeholder {
      background: var(--semi-color-fill-1, #f5f5f5);
      border: 2px dashed var(--semi-color-primary, #0066FF);
      opacity: 0.5;
    }

    .notification-list {
      min-height: 150px;
    }

    /* Ensure cards are positioned relatively for drag handle */
    .notification-card {
      position: relative;
    }

    /* Adjust media area padding for drag handle */
    .notification-card-media {
      position: relative;
    }

    .notification-card-status {
      right: 8px !important;
      left: auto !important;
    }
  `;
  document.head.appendChild(style);
}
