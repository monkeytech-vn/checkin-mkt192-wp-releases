let lateComparisonChart, penaltyComparisonChart;
let currentPage = 0;
const itemsPerPage = 10;
let currentFilter = 'today';

jQuery(document).ready(function ($) {
  // Lấy user_id của người dùng hiện tại từ biến WordPress
  var currentUserId = checkinData.current_user_id;

  // Gọi API để lấy danh sách nhân viên và kiểm tra vai trò
  $.ajax({
    url: 'https://vangroupbarbershop.store/wp-json/vg/v1/staff',
    method: 'GET',
    success: function (response) {
      if (response.success && response.data) {
        var currentStaff = response.data.find(function (staff) {
          return staff.user_id == currentUserId;
        });

        if (currentStaff) {
          var userRole = currentStaff.user_role;
          if (userRole === 'Quản Lý') {
            $('.checkin-mkt-nav-item[data-section="admin"]').show();
          } else {
            $('.checkin-mkt-nav-item[data-section="admin"]').hide();
            $('.checkin-mkt-nav-item[data-section="profile"]').show();
          }
        } else {
          console.log('Không tìm thấy thông tin người dùng trong danh sách nhân viên');
          $('.checkin-mkt-nav-item[data-section="admin"]').hide();
          $('.checkin-mkt-nav-item[data-section="profile"]').show();
        }
      } else {
        console.log('Lỗi khi lấy dữ liệu từ API:', response);
        $('.checkin-mkt-nav-item[data-section="admin"]').hide();
        $('.checkin-mkt-nav-item[data-section="profile"]').show();
      }
    },
    error: function (xhr, status, error) {
      console.log('Lỗi kết nối API:', error);
      $('.checkin-mkt-nav-item[data-section="admin"]').hide();
      $('.checkin-mkt-nav-item[data-section="profile"]').show();
    },
  });
});

document.addEventListener('DOMContentLoaded', () => {
  // Ẩn thanh admin bar của WordPress
  const adminBar = document.getElementById('wpadminbar');
  if (adminBar) {
    adminBar.style.display = 'none';
    document.body.style.marginTop = '0';
  }

  // Kiểm tra các phần tử cần thiết trong DOM
  const requiredElements = [
    'total-checkins',
    'late-count',
    'total-penalty',
    'completion-rate',
    'late-employees-body',
    'late-comparison-chart',
    'penalty-comparison-chart',
    'history-table-body',
    'employee-cards',
  ];
  for (let id of requiredElements) {
    if (!document.getElementById(id)) {
      console.error(`Element with ID '${id}' not found in DOM`);
      return;
    }
  }

  // Tải dữ liệu ban đầu
  fetchDashboardStats();
  fetchCheckinHistory();
  fetchEmployeeList();

  // Sự kiện cho tab lọc thời gian
  document.querySelectorAll('.tab-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab-btn').forEach((b) => b.classList.remove('active'));
      btn.classList.add('active');
      currentFilter = btn.getAttribute('data-filter');
      currentPage = 0;
      fetchDashboardStats();
      fetchCheckinHistory();
      fetchEmployeeList(); // Gọi lại để lọc danh sách nhân viên theo thời gian
    });
  });

  // Sự kiện tìm kiếm
  document.getElementById('search-btn').addEventListener('click', () => {
    currentPage = 0;
    fetchCheckinHistory();
  });

  document.getElementById('search-input').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      currentPage = 0;
      fetchCheckinHistory();
    }
  });

  // Phân trang
  document.getElementById('prev-page').addEventListener('click', () => {
    if (currentPage > 0) {
      currentPage--;
      fetchCheckinHistory();
    }
  });

  document.getElementById('next-page').addEventListener('click', () => {
    currentPage++;
    fetchCheckinHistory();
  });

  // Sự kiện cho modal chi tiết nhân viên
  document.getElementById('close-details').addEventListener('click', () => {
    document.getElementById('employee-details').style.display = 'none';
  });
});

// Tải dữ liệu Dashboard
function fetchDashboardStats() {
  const lateCount = document.getElementById('late-count');
  if (!lateCount) {
    console.error('DOM not ready, retrying in 500ms...');
    setTimeout(() => fetchDashboardStats(), 500);
    return;
  }

  fetch(`${checkinData.restUrl}dashboard-stats?filter=${currentFilter}`, {
    method: 'GET',
    headers: { 'X-WP-Nonce': checkinData.nonce },
  })
    .then((response) => {
      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
      return response.json();
    })
    .then((data) => {
      console.log('Dashboard data:', data);
      if (data.success && data.data) {
        updateWidgets(data.data);
        updateCharts(data.data);
        updateLateEmployees(data.data.late_employees);
      } else {
        console.error('API response invalid:', data.message || 'No success/data field');
      }
    })
    .catch((error) => console.error('Fetch error:', error));
}

function updateWidgets(data) {
  const elements = {
    'total-checkins': data.total_checkins || 0,
    'late-count': `${data.late_count || 0} (Tổng: ${data.total_late_minutes || 0} phút)`,
    'total-penalty': `${Number(data.total_penalty || 0).toLocaleString('vi-VN')} VNĐ`,
    'completion-rate': `${data.completion_rate || 0}%`,
  };

  for (const [id, value] of Object.entries(elements)) {
    const element = document.getElementById(id);
    if (element) element.textContent = value;
    else console.error(`Element with ID '${id}' is null in updateWidgets`);
  }

  const totalLateMinutes = document.getElementById('total-late-minutes');
  if (totalLateMinutes) totalLateMinutes.textContent = data.total_late_minutes || 0;

  const calculatedPenalty = data.late_employees.reduce(
    (sum, emp) => sum + Number(emp.penalty_amount || 0),
    0
  );
  const reportedPenalty = Number(data.total_penalty || 0);
  if (calculatedPenalty !== reportedPenalty) {
    console.warn(
      `Penalty mismatch: Table total = ${calculatedPenalty.toLocaleString(
        'vi-VN'
      )} VNĐ, Dashboard total = ${reportedPenalty.toLocaleString('vi-VN')} VNĐ`
    );
    console.log('Late employees:', data.late_employees);
  }
}

function updateCharts(data) {
  console.log('Chart data:', { late_employees: data.late_employees });

  const aggregatedData = {};
  data.late_employees.forEach((emp) => {
    const name = emp.display_name || 'N/A';
    if (!aggregatedData[name]) {
      aggregatedData[name] = {
        late_minutes: 0,
        penalty_amount: 0,
      };
    }
    aggregatedData[name].late_minutes += Number(emp.late_minutes || 0);
    aggregatedData[name].penalty_amount += Number(emp.penalty_amount || 0);
  });

  const aggregatedEmployees = Object.keys(aggregatedData).map((name) => ({
    display_name: name,
    late_minutes: aggregatedData[name].late_minutes,
    penalty_amount: aggregatedData[name].penalty_amount,
  }));

  aggregatedEmployees.sort((a, b) => b.late_minutes - a.late_minutes);

  if (lateComparisonChart) lateComparisonChart.destroy();
  const lateComparisonCtx = document.getElementById('late-comparison-chart');
  if (lateComparisonCtx) {
    lateComparisonChart = new Chart(lateComparisonCtx, {
      type: 'bar',
      data: {
        labels:
          aggregatedEmployees.length > 0
            ? aggregatedEmployees.map((emp) => emp.display_name)
            : ['Không có dữ liệu'],
        datasets: [
          {
            label: 'Số phút đi trễ',
            data:
              aggregatedEmployees.length > 0
                ? aggregatedEmployees.map((emp) => emp.late_minutes)
                : [0],
            backgroundColor: '#f1c40f',
          },
        ],
      },
      options: {
        scales: {
          y: { beginAtZero: true, ticks: { color: '#ffffff' } },
          x: { ticks: { color: '#ffffff' } },
        },
        plugins: {
          legend: { labels: { color: '#ffffff' } },
        },
      },
    });
  }

  aggregatedEmployees.sort((a, b) => b.penalty_amount - a.penalty_amount);

  if (penaltyComparisonChart) penaltyComparisonChart.destroy();
  const penaltyComparisonCtx = document.getElementById('penalty-comparison-chart');
  if (penaltyComparisonCtx) {
    penaltyComparisonChart = new Chart(penaltyComparisonCtx, {
      type: 'bar',
      data: {
        labels:
          aggregatedEmployees.length > 0
            ? aggregatedEmployees.map((emp) => emp.display_name)
            : ['Không có dữ liệu'],
        datasets: [
          {
            label: 'Số tiền phạt (VNĐ)',
            data:
              aggregatedEmployees.length > 0
                ? aggregatedEmployees.map((emp) => emp.penalty_amount)
                : [0],
            backgroundColor: '#ff6384',
          },
        ],
      },
      options: {
        scales: {
          y: { beginAtZero: true, ticks: { color: '#ffffff' } },
          x: { ticks: { color: '#ffffff' } },
        },
        plugins: {
          legend: { labels: { color: '#ffffff' } },
        },
      },
    });
  }
}

function updateLateEmployees(employees) {
  const tbody = document.getElementById('late-employees-body');
  if (!tbody) {
    console.error('late-employees-body not found');
    return;
  }
  tbody.innerHTML = '';
  if (employees && employees.length > 0) {
    const statusTranslations = {
      'Đi trễ có phép': 'Đi trễ có phép',
      'Đi trễ không phép': 'Đi trễ không phép',
      Pending: 'Chờ duyệt',
      Rejected: 'Bị từ chối',
    };

    employees.forEach((emp) => {
      const row = document.createElement('tr');
      row.innerHTML = `
                <td>${emp.display_name || 'N/A'}</td>
                <td>${emp.shift || 'N/A'}</td>
                <td>${emp.checkin_time || 'N/A'}</td>
                <td>${emp.late_minutes || 0}</td>
                <td>${Number(emp.penalty_amount || 0).toLocaleString('vi-VN')}</td>
                <td>${
                  statusTranslations[emp.late_status] || emp.late_status || 'Đi trễ không phép'
                }</td>
            `;
      tbody.appendChild(row);
    });

    const totalPenalty = employees.reduce((sum, emp) => sum + Number(emp.penalty_amount || 0), 0);
    const totalRow = document.createElement('tr');
    totalRow.innerHTML = `
            <td><strong>Tổng cộng</strong></td>
            <td></td>
            <td></td>
            <td></td>
            <td><strong>${totalPenalty.toLocaleString('vi-VN')}</strong></td>
            <td></td>
        `;
    tbody.appendChild(totalRow);
  } else {
    tbody.innerHTML = '<tr><td colspan="6">Không có nhân viên đi trễ</td></tr>';
  }
}

// Tải dữ liệu Lịch Sử
function fetchCheckinHistory() {
  const search = document.getElementById('search-input').value.trim();
  const offset = currentPage * itemsPerPage;

  fetch(
    `${
      checkinData.restUrl
    }all-checkin-logs?limit=${itemsPerPage}&offset=${offset}&search=${encodeURIComponent(
      search
    )}&filter=${currentFilter}`,
    {
      method: 'GET',
      headers: { 'X-WP-Nonce': checkinData.nonce },
    }
  )
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        populateHistoryTable(data.data);
        updatePagination(data.total, data.limit, data.offset);
      } else {
        console.error('Error fetching checkin history:', data.message);
        showError('Lỗi: ' + data.message);
      }
    })
    .catch((error) => console.error('Error:', error));
}

function fetchEmployeeList() {
  // Sử dụng API /all-checkin-logs để lấy danh sách nhân viên có bản ghi check-in trong khoảng thời gian
  fetch(`${checkinData.restUrl}all-checkin-logs?limit=1000&offset=0&filter=${currentFilter}`, {
    method: 'GET',
    headers: { 'X-WP-Nonce': checkinData.nonce },
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success && data.data) {
        const container = document.getElementById('employee-cards');
        container.innerHTML = '';

        // Lấy danh sách nhân viên duy nhất (distinct) dựa trên employee_id
        const uniqueEmployees = {};
        data.data.forEach((log) => {
          const empId = log.employee_id;
          if (!uniqueEmployees[empId]) {
            uniqueEmployees[empId] = {
              employee_id: log.employee_id,
              display_name: log.display_name,
            };
          }
        });

        // Chuyển danh sách nhân viên duy nhất thành mảng và sắp xếp theo tên
        const employees = Object.values(uniqueEmployees).sort((a, b) =>
          a.display_name.localeCompare(b.display_name)
        );

        // Hiển thị danh sách nhân viên
        if (employees.length > 0) {
          employees.forEach((staff) => {
            const card = document.createElement('div');
            card.className = 'employee-card';
            card.innerHTML = `
                            <strong>${staff.display_name}</strong><br>
                            Mã NV: ${staff.employee_id}
                        `;
            card.addEventListener('click', () => showEmployeeDetails(staff.employee_id));
            container.appendChild(card);
          });
        } else {
          container.innerHTML =
            '<div class="no-employees-message">Không có nhân viên nào điểm danh trong khoảng thời gian này</div>';
        }
      } else {
        console.error('Error fetching employee list:', data.message);
        document.getElementById('employee-cards').innerHTML = '<p>Lỗi tải danh sách nhân viên</p>';
      }
    })
    .catch((error) => {
      console.error('Error fetching employee list:', error);
      document.getElementById('employee-cards').innerHTML = '<p>Lỗi tải danh sách nhân viên</p>';
    });
}

function fetchEmployeeLogs(employeeId, startDate = '', endDate = '') {
  // Nếu không có startDate/endDate, mặc định lấy tháng hiện tại
  if (!startDate || !endDate) {
    const now = new Date();
    const year = now.getFullYear();
    const month = now.getMonth();
    // Định dạng YYYY-MM-DD theo múi giờ cục bộ
    startDate = `${year}-${String(month + 1).padStart(2, '0')}-01`; // Ngày đầu tháng
    endDate = `${year}-${String(month + 1).padStart(2, '0')}-${new Date(
      year,
      month + 1,
      0
    ).getDate()}`; // Ngày cuối tháng
  }

  const query = `?start_date=${startDate}&end_date=${endDate}`;
  fetch(`${checkinData.restUrl}employee-checkin-logs/${encodeURIComponent(employeeId)}${query}`, {
    method: 'GET',
    headers: { 'X-WP-Nonce': checkinData.nonce },
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
        const logsContainer = document.getElementById('employee-logs');
        logsContainer.innerHTML = '';
        if (data.data.length === 0) {
          logsContainer.innerHTML = '<p>Không có dữ liệu điểm danh trong khoảng thời gian này.</p>';
          return;
        }
        data.data.forEach((log) => {
          const entry = document.createElement('div');
          entry.className = 'log-entry';
          const statusClass = log.late_minutes > 0 ? 'status-late' : 'status-pending';
          entry.innerHTML = `
                        <div class="log-labels">
                            <p>Ca:</p>
                            <p>Check-in:</p>
                            <p>Check-out:</p>
                            <p>Trạng thái:</p>
                            <p>Đi trễ:</p>
                            <p>Phạt:</p>
                        </div>
                        <div class="log-values">
                            <p>${log.shift || 'N/A'}</p>
                            <p>${new Date(log.checkin_time).toLocaleString('vi-VN')}</p>
                            <p>${
                              log.checkout_time === '0000-00-00 00:00:00'
                                ? 'Chưa checkout'
                                : new Date(log.checkout_time).toLocaleString('vi-VN')
                            }</p>
                            <p>${log.status === 'success' ? 'Hoàn thành' : 'Đang chờ'}</p>
                            <p class="${statusClass}">${log.late_minutes || 0} phút</p>
                            <p>${Number(log.penalty_amount || 0).toLocaleString('vi-VN')} VNĐ</p>
                        </div>
                    `;
          logsContainer.appendChild(entry);
        });
      } else {
        console.error('API response error:', data.message);
        document.getElementById('employee-logs').innerHTML =
          '<p>Lỗi khi tải dữ liệu: ' + data.message + '</p>';
      }
    })
    .catch((error) => {
      console.error('Error fetching employee logs:', error);
      document.getElementById('employee-logs').innerHTML = '<p>Lỗi khi tải dữ liệu điểm danh.</p>';
    });
}

// Xử lý sự kiện nút lọc theo khoảng thời gian
document.getElementById('filter-by-date').addEventListener('click', function () {
  const startDate = document.getElementById('start-date-filter').value;
  const endDate = document.getElementById('end-date-filter').value;
  const employeeId = document.getElementById('employee-details').dataset.employeeId; // Giả sử bạn lưu employeeId trong dataset
  if (startDate && endDate) {
    if (new Date(startDate) > new Date(endDate)) {
      showWarning('Ngày bắt đầu phải nhỏ hơn hoặc bằng ngày kết thúc!');
      return;
    }
    fetchEmployeeLogs(employeeId, startDate, endDate);
  } else {
    showWarning('Vui lòng chọn cả ngày bắt đầu và ngày kết thúc.');
  }
});

// Xử lý hiển thị chi tiết nhân viên
function showEmployeeDetails(employeeId) {
  document.getElementById('employee-details').style.display = 'block';
  document.getElementById('employee-details').dataset.employeeId = employeeId;
  // Reset bộ lọc thời gian
  document.getElementById('start-date-filter').value = '';
  document.getElementById('end-date-filter').value = '';
  // Lấy dữ liệu tháng hiện tại mặc định
  fetchEmployeeLogs(employeeId);
}

function populateHistoryTable(logs) {
  const tbody = document.getElementById('history-table-body');
  tbody.innerHTML = '';

  logs.forEach((log) => {
    const row = document.createElement('tr');
    row.innerHTML = `
            <td>${log.display_name || 'N/A'}</td>
            <td>${log.location_name || 'N/A'}</td>
            <td>${log.shift || 'N/A'}</td>
            <td>${new Date(log.checkin_time).toLocaleString('vi-VN')}</td>
            <td>${
              log.checkout_time === '0000-00-00 00:00:00'
                ? 'Chưa checkout'
                : new Date(log.checkout_time).toLocaleString('vi-VN')
            }</td>
            <td>${log.status === 'success' ? 'Hoàn thành' : 'Đang chờ'}</td>
        `;
    tbody.appendChild(row);
  });
}

function updatePagination(total, limit, offset) {
  const totalPages = Math.ceil(total / limit);
  const currentPageDisplay = currentPage + 1;

  document.getElementById('page-info').textContent = `Trang ${currentPageDisplay} / ${totalPages}`;
  document.getElementById('prev-page').disabled = currentPage === 0;
  document.getElementById('next-page').disabled = offset + limit >= total;
}
