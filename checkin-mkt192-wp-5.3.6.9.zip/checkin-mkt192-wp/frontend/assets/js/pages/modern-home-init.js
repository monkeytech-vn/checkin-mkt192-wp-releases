/**
 * Modern Home 2025 - Initialization Script
 * Handles animations, interactions, and dynamic behaviors
 */

document.addEventListener('DOMContentLoaded', function () {
  // ==================== PRELOADER ====================
  const preloader = document.querySelector('.preloader-modern');
  if (preloader) {
    setTimeout(() => {
      preloader.style.opacity = '0';
      setTimeout(() => {
        preloader.style.display = 'none';
      }, 300);
    }, 800);
  }

  // ==================== MOBILE MENU TOGGLE ====================
  const menuToggle = document.querySelector('.menu-toggle-modern');
  const mobileMenu = document.querySelector('.mobile-menu-modern');
  const mobileMenuClose = document.querySelector('.mobile-menu-close');
  const body = document.body;

  if (menuToggle && mobileMenu) {
    menuToggle.addEventListener('click', function (e) {
      e.preventDefault();
      mobileMenu.classList.add('active');
      body.style.overflow = 'hidden';
    });
  }

  if (mobileMenuClose) {
    mobileMenuClose.addEventListener('click', function (e) {
      e.preventDefault();
      mobileMenu.classList.remove('active');
      body.style.overflow = '';
    });
  }

  // Close mobile menu when clicking on a link
  const mobileMenuLinks = document.querySelectorAll('.mobile-menu-modern .mobile-nav-link');
  mobileMenuLinks.forEach((link) => {
    link.addEventListener('click', function () {
      mobileMenu.classList.remove('active');
      body.style.overflow = '';
    });
  });

  // ==================== SMOOTH SCROLL ====================
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener('click', function (e) {
      const href = this.getAttribute('href');
      if (href !== '#' && href !== '#bookingPopup') {
        e.preventDefault();
        const target = document.querySelector(href);
        if (target) {
          const headerHeight = document.querySelector('.modern-header')?.offsetHeight || 0;
          const targetPosition = target.offsetTop - headerHeight - 20;
          window.scrollTo({
            top: targetPosition,
            behavior: 'smooth',
          });
        }
      }
    });
  });

  // ==================== HEADER SCROLL STATE ====================
  const header = document.querySelector('.modern-header');
  let lastScroll = 0;

  window.addEventListener('scroll', function () {
    const currentScroll = window.pageYOffset;

    // Add scrolled class for styling
    if (currentScroll > 100) {
      header?.classList.add('scrolled');
    } else {
      header?.classList.remove('scrolled');
    }

    lastScroll = currentScroll;
  });

  // ==================== BACK TO TOP BUTTON ====================
  const backToTop = document.querySelector('.back-to-top-modern');

  if (backToTop) {
    window.addEventListener('scroll', function () {
      if (window.pageYOffset > 300) {
        backToTop.style.opacity = '1';
        backToTop.style.visibility = 'visible';
        backToTop.style.transform = 'translateY(0)';
      } else {
        backToTop.style.opacity = '0';
        backToTop.style.visibility = 'hidden';
        backToTop.style.transform = 'translateY(20px)';
      }
    });

    backToTop.addEventListener('click', function (e) {
      e.preventDefault();
      window.scrollTo({
        top: 0,
        behavior: 'smooth',
      });
    });
  }

  // ==================== SCROLL REVEAL ANIMATIONS ====================
  const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px',
  };

  const observer = new IntersectionObserver(function (entries) {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add('revealed');
        observer.unobserve(entry.target);
      }
    });
  }, observerOptions);

  // Observe all sections
  const sections = document.querySelectorAll(
    '.about-modern, .services-modern, .team-modern, .gallery-modern, .reviews-modern, .contact-modern, .newsletter-modern'
  );
  sections.forEach((section) => {
    section.style.opacity = '0';
    section.style.transform = 'translateY(30px)';
    section.style.transition = 'opacity 0.8s ease, transform 0.8s ease';
    observer.observe(section);
  });

  // Add revealed styles
  const style = document.createElement('style');
  style.textContent = `
        .revealed {
            opacity: 1 !important;
            transform: translateY(0) !important;
        }
    `;
  document.head.appendChild(style);

  // ==================== STAGGERED CARD ANIMATIONS ====================
  const observeCards = new IntersectionObserver(function (entries) {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        const cards = entry.target.querySelectorAll(
          '.service-card-modern, .team-card-modern, .gallery-item-modern'
        );
        cards.forEach((card, index) => {
          setTimeout(() => {
            card.style.opacity = '1';
            card.style.transform = 'translateY(0)';
          }, index * 100);
        });
        observeCards.unobserve(entry.target);
      }
    });
  }, observerOptions);

  const cardContainers = document.querySelectorAll(
    '.services-grid-modern, .team-grid-modern, .gallery-grid-modern'
  );
  cardContainers.forEach((container) => {
    const cards = container.querySelectorAll(
      '.service-card-modern, .team-card-modern, .gallery-item-modern'
    );
    cards.forEach((card) => {
      card.style.opacity = '0';
      card.style.transform = 'translateY(20px)';
      card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
    });
    observeCards.observe(container);
  });

  // ==================== STATS COUNTER ANIMATION ====================
  const statsObserver = new IntersectionObserver(function (entries) {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        const numbers = entry.target.querySelectorAll('.stat-number, .card-metric');
        numbers.forEach((num) => {
          const target = parseInt(num.textContent.replace(/[^0-9]/g, ''));
          if (target) {
            animateCounter(num, 0, target, 2000);
          }
        });
        statsObserver.unobserve(entry.target);
      }
    });
  }, observerOptions);

  function animateCounter(element, start, end, duration) {
    const startTime = performance.now();
    const suffix = element.textContent.replace(/[0-9]/g, '');

    function update(currentTime) {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const current = Math.floor(progress * (end - start) + start);
      element.textContent = current + suffix;

      if (progress < 1) {
        requestAnimationFrame(update);
      }
    }

    requestAnimationFrame(update);
  }

  const aboutSection = document.querySelector('.about-stats-overlay, .hero-stats');
  if (aboutSection) {
    statsObserver.observe(aboutSection);
  }

  // ==================== BOOKING MODAL ENHANCEMENTS ====================
  const bookingModal = document.getElementById('bookingPopup');

  if (bookingModal) {
    // Add glassmorphic styling dynamically
    bookingModal.style.backdropFilter = 'blur(8px)';
    bookingModal.style.background = 'rgba(0, 0, 0, 0.7)';

    const modalContent = bookingModal.querySelector('.modal-content, .booking-modal');
    if (modalContent) {
      modalContent.style.background = 'rgba(255, 255, 255, 0.95)';
      modalContent.style.backdropFilter = 'blur(20px)';
      modalContent.style.borderRadius = '24px';
      modalContent.style.boxShadow = '0 20px 60px rgba(0, 0, 0, 0.3)';
    }
  }

  // ==================== IMAGE LAZY LOADING ====================
  const images = document.querySelectorAll('img[data-src]');
  const imageObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        const img = entry.target;
        img.src = img.dataset.src;
        img.removeAttribute('data-src');
        imageObserver.unobserve(img);
      }
    });
  });

  images.forEach((img) => imageObserver.observe(img));

  // ==================== PARALLAX EFFECT FOR HERO ====================
  const hero = document.querySelector('.hero-modern');
  if (hero) {
    window.addEventListener('scroll', function () {
      const scrolled = window.pageYOffset;
      const parallaxSpeed = 0.5;
      hero.style.transform = `translateY(${scrolled * parallaxSpeed}px)`;
    });
  }

  // ==================== CONSOLE LOG ====================
  console.log('🎨 Modern Home 2025 initialized successfully');
});
