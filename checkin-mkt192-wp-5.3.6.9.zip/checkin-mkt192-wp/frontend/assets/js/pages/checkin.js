document.addEventListener('DOMContentLoaded', async () => {
  // Khởi tạo các phần tử DOM
  const elements = {
    checkinTimeIn: document.getElementById('checkin-time-in'),
    checkinTimeOut: document.getElementById('checkin-time-out'),
    locationStatus: document.getElementById('location-status'),
    clockInBtn: document.getElementById('clock-in-btn'),
    clockOutBtn: document.getElementById('clock-out-btn'),
    userHeader: document.getElementById('user-header'),
    checkinSection: document.getElementById('checkin-section'),
    checkinContainer: document.getElementById('checkin-container'),
    locationDropdown: document.getElementById('location-dropdown'),
    shiftDropdown: document.getElementById('shift-dropdown'),
    dateDisplay: document.getElementById('date-display'),
    displayName: document.getElementById('display-name'),
    userRole: document.getElementById('user-role'),
    userAvatar: document.getElementById('user-avatar'),
    loadingOverlay: document.getElementById('loading-overlay'),
    clock: document.getElementById('clock'),
    viewLogBtn: document.getElementById('view-log-btn'),
    logModal: document.getElementById('log-modal'),
    logText: document.getElementById('log-text'),
    closeModal: document.querySelector('.close-modal'),
    adminBtn: document.getElementById('admin-btn'),
  };

  // Kiểm tra các phần tử DOM cần thiết
  if (Object.values(elements).some((el) => !el)) {
    console.error('One or more critical elements are missing in DOM:', {
      checkinTimeIn: !elements.checkinTimeIn,
      checkinTimeOut: !elements.checkinTimeOut,
      locationStatus: !elements.locationStatus,
      clockInBtn: !elements.clockInBtn,
      clockOutBtn: !elements.clockOutBtn,
      userHeader: !elements.userHeader,
      checkinSection: !elements.checkinSection,
      checkinContainer: !elements.checkinContainer,
      locationDropdown: !elements.locationDropdown,
      shiftDropdown: !elements.shiftDropdown,
      dateDisplay: !elements.dateDisplay,
      displayName: !elements.displayName,
      userRole: !elements.userRole,
      userAvatar: !elements.userAvatar,
      loadingOverlay: !elements.loadingOverlay,
      clock: !elements.clock,
      viewLogBtn: !elements.viewLogBtn,
      logModal: !elements.logModal,
      logText: !elements.logText,
      closeModal: !elements.closeModal,
    });
    // Hide page loader if initialization fails
    if (window.hidePageLoader) {
      window.hidePageLoader();
    }
    return;
  }

  // Show page loader using new component
  if (window.showPageLoader) {
    window.showPageLoader({
      text: 'Đang tải dữ liệu điểm danh...',
      subtitle: 'Vui lòng đợi trong giây lát',
    });
  } else {
    // Fallback to old loading overlay if page loader not available
    elements.checkinContainer.classList.add('loading');
    if (elements.loadingOverlay) {
      elements.loadingOverlay.style.display = 'flex';
    }
  }

  // Confetti Effect for successful checkin
  function launchConfetti() {
    const duration = 2000;
    const end = Date.now() + duration;
    const colors = ['#667eea', '#764ba2', '#10b981', '#ffd700', '#3b82f6', '#f59e0b'];

    (function frame() {
      // Create multiple confetti pieces
      for (let i = 0; i < 3; i++) {
        const confetti = document.createElement('div');
        confetti.className = 'confetti-piece';
        confetti.style.left = Math.random() * 100 + '%';
        confetti.style.background = colors[Math.floor(Math.random() * colors.length)];
        confetti.style.animationDuration = Math.random() * 2 + 1 + 's';
        confetti.style.animationDelay = Math.random() * 0.5 + 's';
        document.body.appendChild(confetti);

        setTimeout(() => confetti.remove(), 3000);
      }

      if (Date.now() < end) {
        requestAnimationFrame(frame);
      }
    })();
  }

  // Use existing showCheckinToast from modals.js
  let lastToastTime = 0;
  const TOAST_THROTTLE_MS = 500; // Đảm bảo toast không bị gọi liên tiếp trong 500ms

  function showToast(message, type = 'info') {
    const now = Date.now();
    // Throttle toast để tránh hiển thị nhiều toast cùng lúc
    if (now - lastToastTime < TOAST_THROTTLE_MS) {
      console.log(`[THROTTLED ${type.toUpperCase()}] ${message}`);
      return;
    }
    lastToastTime = now;

    if (typeof showCheckinToast === 'function') {
      showCheckinToast({ message, type, duration: 3000 });
    } else {
      console.log(`[${type.toUpperCase()}] ${message}`);
    }
  }

  // Convenience functions
  function toastSuccess(message) {
    launchConfetti();
    setTimeout(() => showToast(message, 'success'), 800);
  }

  function toastError(message) {
    showToast(message, 'error');
  }

  function toastWarning(message) {
    showToast(message, 'warning');
  }

  function toastInfo(message) {
    showToast(message, 'info');
  }

  // Legacy compatibility
  function showError(message) {
    toastError(message);
  }

  function showWarning(message) {
    toastWarning(message);
  }

  function showSuccess(message) {
    toastSuccess(message);
  }

  // Danh sách câu chúc
  const motivationalQuotes = [
    'Từng bước nhỏ hôm nay sẽ dẫn bạn đến những thành công lớn!',
    'Hãy làm việc với đam mê, thành quả sẽ đến với bạn!',
    'Mỗi ngày là một cơ hội để bạn tỏa sáng!',
    'Cố lên, bạn đang làm rất tốt!',
    'Thành công bắt đầu từ những nỗ lực không ngừng nghỉ!',
  ];

  // Cache dữ liệu
  let cachedLocations = [];
  let cachedShifts = [];
  let userData = null;
  let userActionLogs = []; // Mảng lưu log thao tác người dùng

  // Hàm ghi log thao tác
  function logUserAction(action, message, status = 'info') {
    const now = new Date();
    const timestamp = now.toLocaleString('vi-VN', {
      timeZone: 'Asia/Ho_Chi_Minh',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
    userActionLogs.push({ timestamp, action, message, status });
    // Giới hạn số lượng log để tránh tràn bộ nhớ
    if (userActionLogs.length > 100) {
      userActionLogs.shift();
    }
  }

  // Hàm hiển thị log trong modal
  function displayLogs() {
    elements.logText.textContent = userActionLogs
      .map(
        (log) => `[${log.timestamp}] [${log.status.toUpperCase()}] ${log.action}: ${log.message}`
      )
      .join('\n');
    elements.logModal.style.display = 'block';
  }

  // Hàm đặt lại thông báo mặc định
  function resetToDefaultMessage(hasCheckedIn = false, locationName = '') {
    elements.locationStatus.textContent = hasCheckedIn
      ? motivationalQuotes[Math.floor(Math.random() * motivationalQuotes.length)]
      : locationName
      ? 'Hãy bắt đầu ca làm việc của bạn.'
      : 'Bạn không nằm trong phạm vi chi nhánh nào, vui lòng chọn chi nhánh thủ công.';
    updateStatusStyle(elements.locationStatus.textContent);
  }

  // Hàm cập nhật màu sắc thông báo
  function updateStatusStyle(message, isLate = false) {
    if (message.includes('thành công')) {
      elements.locationStatus.style.color = '#008000';
      elements.locationStatus.style.backgroundColor = '#e6ffe6';
    } else if (message.includes('trễ') || isLate) {
      elements.locationStatus.style.color = '#ff4500';
      elements.locationStatus.style.backgroundColor = '#fff3e6';
    } else if (
      message.includes('Không thể') ||
      message.includes('không nằm trong') ||
      message.includes('lỗi hệ thống')
    ) {
      elements.locationStatus.style.color = '#800080';
      elements.locationStatus.style.backgroundColor = '#f2e6ff';
    } else {
      elements.locationStatus.style.color = '#0066cc';
      elements.locationStatus.style.backgroundColor = '#cce5ff';
    }
  }

  // Hàm cập nhật đồng hồ
  function updateClock() {
    const now = new Date();
    elements.clock.textContent = now.toLocaleTimeString('vi-VN', {
      hour12: false,
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
  }

  // Hàm cập nhật giao diện
  function updateCheckinUI(statuses, showDate = false) {
    console.log('[updateCheckinUI] Statuses received:', statuses, 'showDate:', showDate);
    elements.checkinTimeIn.innerHTML = '';
    elements.checkinTimeOut.style.display = 'none';
    elements.clockInBtn.classList.add('disabled'); // Khóa Clock In mặc định
    elements.clockOutBtn.classList.add('disabled'); // Khóa Clock Out mặc định

    let hasCheckedIn = false;
    let canClockOut = false;

    statuses.forEach((status) => {
      console.log('[updateCheckinUI] Processing status:', status);
      const logDiv = document.createElement('div');
      logDiv.classList.add('checkin-log-item');

      // Tags Row (container for date and shift tags)
      const tagsRow = document.createElement('div');
      tagsRow.classList.add('tags-row');

      // Date Tag (hiển thị khi xem lịch sử nhiều ngày)
      if (showDate && status.checkin_time) {
        const checkinDate = new Date(status.checkin_time);
        const dateTag = document.createElement('span');
        dateTag.classList.add('date-tag');
        dateTag.innerHTML = `<i class="fas fa-calendar-alt"></i>${checkinDate.toLocaleDateString(
          'vi-VN',
          {
            weekday: 'short',
            day: '2-digit',
            month: '2-digit',
            year: 'numeric',
          }
        )}`;
        tagsRow.appendChild(dateTag);
      }

      // Shift Tag
      const shiftTag = document.createElement('span');
      shiftTag.classList.add('shift-tag');
      shiftTag.innerHTML = `<i class="fas fa-briefcase"></i>${status.shift}`;
      tagsRow.appendChild(shiftTag);

      logDiv.appendChild(tagsRow);

      // Time Row
      const timeRow = document.createElement('div');
      timeRow.classList.add('time-row');

      // Kiểm tra nếu đã có cả clock in và clock out (checkout_time có giá trị và không phải null)
      if (status.checkin_time && status.checkout_time && status.checkout_time !== null) {
        console.log('[updateCheckinUI] Case: Đã clock in và clock out');

        // Clock In Time
        const clockInItem = document.createElement('div');
        clockInItem.classList.add('time-item');
        clockInItem.innerHTML = `
          <i class="fas fa-check-circle"></i>
          <span class="time-label">Clock In:</span>
          <span class="time-value">${new Date(status.checkin_time).toLocaleTimeString('vi-VN', {
            hour12: false,
            hour: '2-digit',
            minute: '2-digit',
          })}</span>
        `;

        // Clock Out Time
        const clockOutItem = document.createElement('div');
        clockOutItem.classList.add('time-item');
        clockOutItem.innerHTML = `
          <i class="fas fa-check-circle"></i>
          <span class="time-label">Clock Out:</span>
          <span class="time-value">${new Date(status.checkout_time).toLocaleTimeString('vi-VN', {
            hour12: false,
            hour: '2-digit',
            minute: '2-digit',
          })}</span>
        `;

        timeRow.appendChild(clockInItem);
        timeRow.appendChild(clockOutItem);
        elements.clockInBtn.classList.remove('disabled'); // Mở Clock In vì đã Clock Out
      } else if (status.checkin_time) {
        // Đã clock in nhưng chưa clock out (checkout_time là null)
        console.log('[updateCheckinUI] Case: Đã clock in, chưa clock out');

        // Clock In Time với icon
        const clockInItem = document.createElement('div');
        clockInItem.classList.add('time-item');
        clockInItem.innerHTML = `
          <i class="fas fa-check-circle"></i>
          <span class="time-label">Clock In:</span>
          <span class="time-value">${new Date(status.checkin_time).toLocaleTimeString('vi-VN', {
            hour12: false,
            hour: '2-digit',
            minute: '2-digit',
          })}</span>
        `;

        timeRow.appendChild(clockInItem);
        hasCheckedIn = true;

        // Kiểm tra thời gian có nằm trong khoảng Clock Out không
        const now = new Date();
        const checkinTime = new Date(status.checkin_time);
        const shift = cachedShifts.find((s) => s.shift_name === status.shift);

        console.log('[updateCheckinUI] Clock Out check:', {
          status_shift: status.shift,
          cachedShifts_count: cachedShifts.length,
          shift_found: !!shift,
          now: now.toLocaleString('vi-VN'),
        });

        if (shift) {
          console.log('[updateCheckinUI] Shift details:', shift);
          const [endHour, endMinute] = shift.end_time.split(':').map(Number);
          const endTime = new Date(checkinTime);
          endTime.setHours(endHour, endMinute, 0, 0);
          const earlyCheckout = parseInt(shift.early_checkout, 10) || 0;
          const lateCheckout = parseInt(shift.late_checkout, 10) || 0;
          const checkoutWindowStart = new Date(endTime.getTime() - earlyCheckout * 60000);
          const checkoutWindowEnd = new Date(endTime.getTime() + lateCheckout * 60000);

          console.log('[updateCheckinUI] Clock Out window:', {
            endTime: endTime.toLocaleString('vi-VN'),
            earlyCheckout: earlyCheckout + ' minutes',
            lateCheckout: lateCheckout + ' minutes',
            windowStart: checkoutWindowStart.toLocaleString('vi-VN'),
            windowEnd: checkoutWindowEnd.toLocaleString('vi-VN'),
            currentTime: now.toLocaleString('vi-VN'),
            canClockOut: now >= checkoutWindowStart && now <= checkoutWindowEnd,
          });

          if (now >= checkoutWindowStart && now <= checkoutWindowEnd) {
            canClockOut = true;
            elements.clockOutBtn.classList.remove('disabled');
            console.log('[updateCheckinUI] ✅ Clock Out button ENABLED');
          } else {
            console.log('[updateCheckinUI] ❌ Clock Out button DISABLED - outside time window');
          }
        } else {
          console.log('[updateCheckinUI] ⚠️ Shift not found in cachedShifts');
        }
      }

      logDiv.appendChild(timeRow);

      // Create status tags container
      const statusTagsContainer = document.createElement('div');
      statusTagsContainer.classList.add('status-tags');

      // Determine status and add appropriate tags
      if (status.checkin_time && status.checkout_time && status.checkout_time !== null) {
        // Complete - both clock in and clock out done
        if (status.status_late === true || status.late_minutes > 0) {
          // Late but completed
          const lateTag = document.createElement('span');
          lateTag.classList.add('status-tag', 'late');
          lateTag.innerHTML = `<i class="fas fa-clock"></i> Đi trễ ${status.late_minutes} phút`;
          statusTagsContainer.appendChild(lateTag);

          if (status.penalty_amount > 0) {
            const penaltyTag = document.createElement('span');
            penaltyTag.classList.add('status-tag', 'penalty');
            const penaltyFormatted = Number(status.penalty_amount).toLocaleString('vi-VN');

            // Check if there's a late request that reduces penalty (you can add this logic based on API)
            const hasLateRequest = status.has_late_request || false;
            if (hasLateRequest) {
              penaltyTag.classList.add('reduced');
              penaltyTag.innerHTML = `<i class="fas fa-dollar-sign"></i> <span class="penalty-amount">${penaltyFormatted} VNĐ</span> <span class="reduced-info">(Có đơn)</span>`;
            } else {
              penaltyTag.innerHTML = `<i class="fas fa-dollar-sign"></i> Phạt: ${penaltyFormatted} VNĐ`;
            }
            statusTagsContainer.appendChild(penaltyTag);
          }

          const completeTag = document.createElement('span');
          completeTag.classList.add('status-tag', 'complete');
          completeTag.innerHTML = `<i class="fas fa-check-double"></i> Hoàn thành`;
          statusTagsContainer.appendChild(completeTag);
        } else {
          // On time and complete
          const completeTag = document.createElement('span');
          completeTag.classList.add('status-tag', 'complete');
          completeTag.innerHTML = `<i class="fas fa-check-double"></i> Hoàn thành`;
          statusTagsContainer.appendChild(completeTag);
        }
      } else if (status.checkin_time && !status.checkout_time) {
        // Missing clock out
        const pendingTag = document.createElement('span');
        pendingTag.classList.add('status-tag', 'pending');
        pendingTag.innerHTML = `<i class="fas fa-exclamation-circle"></i> Quên Clock Out`;
        statusTagsContainer.appendChild(pendingTag);

        if (status.status_late === true || status.late_minutes > 0) {
          const lateTag = document.createElement('span');
          lateTag.classList.add('status-tag', 'late');
          lateTag.innerHTML = `<i class="fas fa-clock"></i> Đi trễ ${status.late_minutes} phút`;
          statusTagsContainer.appendChild(lateTag);

          if (status.penalty_amount > 0) {
            const penaltyTag = document.createElement('span');
            penaltyTag.classList.add('status-tag', 'penalty');
            const penaltyFormatted = Number(status.penalty_amount).toLocaleString('vi-VN');

            const hasLateRequest = status.has_late_request || false;
            if (hasLateRequest) {
              penaltyTag.classList.add('reduced');
              penaltyTag.innerHTML = `<i class="fas fa-dollar-sign"></i> <span class="penalty-amount">${penaltyFormatted} VNĐ</span> <span class="reduced-info">(Có đơn)</span>`;
            } else {
              penaltyTag.innerHTML = `<i class="fas fa-dollar-sign"></i> Phạt: ${penaltyFormatted} VNĐ`;
            }
            statusTagsContainer.appendChild(penaltyTag);
          }
        }
      } else if (!status.checkin_time && status.checkout_time) {
        // Missing clock in (unusual case)
        const pendingTag = document.createElement('span');
        pendingTag.classList.add('status-tag', 'pending');
        pendingTag.innerHTML = `<i class="fas fa-exclamation-circle"></i> Quên Clock In`;
        statusTagsContainer.appendChild(pendingTag);
      }

      if (statusTagsContainer.children.length > 0) {
        logDiv.appendChild(statusTagsContainer);
      }

      elements.checkinTimeIn.appendChild(logDiv);
    });

    if (!hasCheckedIn) {
      elements.clockInBtn.classList.remove('disabled'); // Mở Clock In nếu chưa Clock In
    }

    if (elements.checkinTimeIn.children.length > 0) {
      elements.checkinTimeIn.style.display = 'flex';
    } else {
      elements.checkinTimeIn.style.display = 'none';
    }
  }

  // Hàm lấy thông tin người dùng
  async function fetchUserProfile() {
    if (userData) return userData;
    try {
      const response = await fetch(`${checkinData.restUrl}user-profile`, {
        headers: { 'X-WP-Nonce': checkinData.nonce },
      });
      const result = await response.json();
      if (result.success) {
        userData = result.data;
        logUserAction('Fetch User Profile', 'Lấy thông tin người dùng thành công', 'success');
        return userData;
      } else {
        logUserAction('Fetch User Profile', 'Không thể lấy thông tin người dùng', 'error');
        showError('Lỗi khi lấy thông tin người dùng. Vui lòng thử lại.');
        return null;
      }
    } catch (error) {
      console.error('Error fetching user profile:', error);
      logUserAction('Fetch User Profile', `Lỗi hệ thống: ${error.message}`, 'error');
      showError('Lỗi khi lấy thông tin người dùng. Vui lòng thử lại.');
      return null;
    }
  }

  // Hàm lấy danh sách địa điểm
  async function fetchLocations() {
    if (cachedLocations.length > 0) return cachedLocations;
    try {
      const response = await fetch(`${checkinData.restUrl}locations`, {
        headers: { 'X-WP-Nonce': checkinData.nonce },
      });
      const result = await response.json();
      cachedLocations = result.success ? result.data : [];
      return cachedLocations;
    } catch (error) {
      console.error('Error fetching locations:', error);
      return [];
    }
  }

  // Hàm lấy danh sách ca làm việc
  async function fetchShifts() {
    if (cachedShifts.length > 0) return cachedShifts;
    try {
      const response = await fetch(`${checkinData.restUrl}shifts`, {
        headers: { 'X-WP-Nonce': checkinData.nonce },
      });
      const result = await response.json();
      cachedShifts = result.success ? result.data : [];
      return cachedShifts;
    } catch (error) {
      console.error('Error fetching shifts:', error);
      return [];
    }
  }

  // Hàm khởi tạo trạng thái
  async function initializeCheckinStatus() {
    const user = await fetchUserProfile();
    if (!user) return;

    // Hiển thị nút Admin nếu user là administrator
    if (checkinData.userRole && checkinData.userRole.toLowerCase() === 'administrator') {
      elements.adminBtn.style.display = 'flex';
      logUserAction('Admin Check', 'Hiển thị nút Admin cho Administrator', 'info');
    }

    elements.userHeader.style.display = 'block';
    elements.checkinSection.style.display = 'block';
    elements.userAvatar.src = user.avatar_url || '';
    elements.displayName.textContent = `Hi, ${user.display_name}`;
    elements.userRole.textContent = user.user_role;

    // Cập nhật dropdown địa điểm
    const locations = await fetchLocations();
    elements.locationDropdown.innerHTML = '<option value="">Chọn chi nhánh</option>';
    locations.forEach((loc) => {
      const option = document.createElement('option');
      option.value = loc.location_name;
      option.textContent = loc.location_name;
      elements.locationDropdown.appendChild(option);
    });

    // Auto-detect branch from GPS if BranchHelper available
    if (typeof BranchHelper !== 'undefined') {
      try {
        const branchHelper = new BranchHelper();
        await branchHelper.initialize();
        const detected = await branchHelper.detectBranch();
        if (detected && detected.branch_name) {
          // Set detected branch in dropdown
          elements.locationDropdown.value = detected.branch_name;
          logUserAction(
            'Branch Auto-detect',
            `Phát hiện chi nhánh: ${detected.branch_name}`,
            'success'
          );
        }
      } catch (e) {
        logUserAction('Branch Auto-detect', 'Không thể phát hiện chi nhánh tự động', 'warning');
      }
    }

    // Cập nhật dropdown ca làm việc
    const shifts = await fetchShifts();
    elements.shiftDropdown.innerHTML = '<option value="">Chọn ca làm việc</option>';
    shifts.forEach((shift) => {
      if (shift.shift_group === user.user_role) {
        const option = document.createElement('option');
        option.value = shift.shift_name;
        option.textContent = shift.shift_name;
        elements.shiftDropdown.appendChild(option);
      }
    });

    // Cập nhật ngày hiện tại
    const today = new Date();
    const formatted = today.toLocaleDateString('vi-VN', {
      timeZone: 'Asia/Ho_Chi_Minh',
      weekday: 'long',
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    });
    elements.dateDisplay.textContent = formatted.charAt(0).toUpperCase() + formatted.slice(1);

    // Kiểm tra trạng thái điểm danh
    navigator.geolocation.getCurrentPosition(
      async (position) => {
        logUserAction('Geolocation', 'Lấy vị trí thành công', 'success');
        await updateCheckinStatus(user, position.coords.latitude, position.coords.longitude);
      },
      async () => {
        logUserAction('Geolocation', 'Không thể lấy vị trí', 'warning');
        await updateCheckinStatus(user);
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );
  }

  // Hàm cập nhật trạng thái điểm danh
  async function updateCheckinStatus(user, latitude = null, longitude = null) {
    try {
      const params = new URLSearchParams({ employee_id: encodeURIComponent(user.employee_id) });
      if (latitude && longitude) {
        params.append('latitude', latitude);
        params.append('longitude', longitude);
      }
      if (elements.locationDropdown.value) {
        params.append('selected_location', encodeURIComponent(elements.locationDropdown.value));
      }
      if (elements.shiftDropdown.value) {
        params.append('selected_shift', encodeURIComponent(elements.shiftDropdown.value));
      }

      console.log('[updateCheckinStatus] Request params:', {
        employee_id: user.employee_id,
        latitude,
        longitude,
        selected_location: elements.locationDropdown.value,
        selected_shift: elements.shiftDropdown.value,
      });

      const url = `${checkinData.restUrl}checkin-status?${params.toString()}`;
      console.log('[updateCheckinStatus] API URL:', url);

      const response = await fetch(url, {
        headers: { 'X-WP-Nonce': checkinData.nonce },
      });
      const result = await response.json();

      console.log('[updateCheckinStatus] API Response:', result);

      if (result.success) {
        console.log('[updateCheckinStatus] Data array length:', result.data.length);
        updateCheckinUI(result.data);
        resetToDefaultMessage(result.data.length > 0, result.location_name);
        if (result.location_name) {
          elements.locationDropdown.value = result.location_name.trim();
        }
        if (result.data.length > 0 && result.data[0].status === 'pending') {
          elements.shiftDropdown.value = result.data[0].shift.trim();
          logUserAction(
            'Update Checkin Status',
            `Ca đang Clock In: ${result.data[0].shift}`,
            'info'
          );
        } else {
          const now = new Date();
          const currentTime = now
            .toLocaleTimeString('vi-VN', {
              timeZone: 'Asia/Ho_Chi_Minh',
              hour: '2-digit',
              minute: '2-digit',
            })
            .split(':')
            .map(Number);
          const currentMinutes = currentTime[0] * 60 + currentTime[1];

          let nearestShift = null;
          let minTimeDiff = Infinity;
          const shifts = await fetchShifts();

          // Tìm ca trong khoảng thời gian hợp lệ
          shifts.forEach((shift) => {
            if (shift.shift_group === user.user_role) {
              const [hours, minutes] = shift.start_time.split(':').map(Number);
              const shiftStartTime = hours * 60 + minutes;
              const earlyCheckin = parseInt(shift.early_checkin) || 0;
              const lateCheckin = parseInt(shift.late_checkin) || 0;

              if (
                currentMinutes >= shiftStartTime - earlyCheckin &&
                currentMinutes <= shiftStartTime + lateCheckin
              ) {
                const timeDiff = Math.abs(currentMinutes - shiftStartTime);
                if (timeDiff < minTimeDiff) {
                  minTimeDiff = timeDiff;
                  nearestShift = shift;
                }
              }
            }
          });

          // Nếu không có ca hợp lệ, chọn ca có start_time gần nhất trong tương lai
          if (!nearestShift) {
            shifts.forEach((shift) => {
              if (shift.shift_group === user.user_role) {
                const [hours, minutes] = shift.start_time.split(':').map(Number);
                const shiftStartTime = hours * 60 + minutes;
                if (shiftStartTime >= currentMinutes) {
                  const timeDiff = shiftStartTime - currentMinutes;
                  if (timeDiff < minTimeDiff) {
                    minTimeDiff = timeDiff;
                    nearestShift = shift;
                  }
                }
              }
            });
          }

          if (nearestShift) {
            elements.shiftDropdown.value = nearestShift.shift_name;
            logUserAction(
              'Update Checkin Status',
              `Chọn ca tự động: ${nearestShift.shift_name}`,
              'info'
            );
          } else if (result.shift_name) {
            elements.shiftDropdown.value = result.shift_name.trim();
            logUserAction(
              'Update Checkin Status',
              `Chọn ca từ server: ${result.shift_name}`,
              'info'
            );
          } else {
            // Không tìm được ca phù hợp - cho phép user chọn thủ công
            // Lấy tất cả ca có thể của user và để rỗng dropdown
            elements.shiftDropdown.innerHTML = '<option value="">Chọn ca làm việc</option>';
            shifts.forEach((shift) => {
              if (shift.shift_group === user.user_role) {
                const option = document.createElement('option');
                option.value = shift.shift_name;
                option.textContent = shift.shift_name;
                elements.shiftDropdown.appendChild(option);
              }
            });

            elements.shiftDropdown.value = '';
            logUserAction(
              'Update Checkin Status',
              'Không có ca làm việc phù hợp với thời gian hiện tại',
              'warning'
            );

            // Delay toast để tránh bị che bởi loader
            setTimeout(() => {
              toastWarning(
                'Bạn đã đi trễ quá thời gian cho phép! Vui lòng chọn ca làm việc thủ công.'
              );
            }, 300);
          }
        }
        const date = result.current_date ? new Date(result.current_date) : new Date();
        const formattedDate = date.toLocaleDateString('vi-VN', {
          timeZone: 'Asia/Ho_Chi_Minh',
          weekday: 'long',
          year: 'numeric',
          month: '2-digit',
          day: '2-digit',
        });
        elements.dateDisplay.textContent =
          formattedDate.charAt(0).toUpperCase() + formattedDate.slice(1);
        logUserAction(
          'Update Checkin Status',
          'Cập nhật trạng thái điểm danh thành công',
          'success'
        );
      } else {
        resetToDefaultMessage(false, elements.locationDropdown.value);
        if (result.location_name) {
          elements.locationDropdown.value = result.location_name.trim();
        }
        if (result.shift_name) {
          elements.shiftDropdown.value = result.shift_name.trim();
          logUserAction('Update Checkin Status', `Chọn ca từ server: ${result.shift_name}`, 'info');
        }
        if (result.nearest_location) {
          setTimeout(() => {
            elements.locationDropdown.value = result.nearest_location.trim();
            resetToDefaultMessage(false, result.nearest_location);
          }, 5000);
        }
        showWarning(result.message);
      }
    } catch (error) {
      console.error('Error fetching check-in status:', error);
      showError('Lỗi hệ thống khi kiểm tra trạng thái. Vui lòng thử lại.');
      logUserAction('Update Checkin Status', `Lỗi hệ thống: ${error.message}`, 'error');
    } finally {
      // Hide page loader
      if (window.hidePageLoader) {
        window.hidePageLoader();
      } else if (elements.loadingOverlay) {
        elements.loadingOverlay.style.display = 'none';
      }
      elements.checkinContainer.classList.remove('loading');
    }
  }

  // Hàm xử lý check-in/out
  async function handleCheckin(type) {
    const user = await fetchUserProfile();
    if (!user || !user.employee_id) {
      showError('Vui lòng đăng nhập để thực hiện điểm danh.');
      if (window.hidePageLoader) {
        window.hidePageLoader();
      }
      elements.checkinContainer.classList.remove('loading');
      return;
    }

    if (!elements.shiftDropdown.value) {
      // Hide loader nếu đang hiển
      if (window.hidePageLoader) {
        window.hidePageLoader();
      }
      elements.checkinContainer.classList.remove('loading');

      // Delay toast để đảm bảo hiển thị
      setTimeout(() => {
        showWarning('Vui lòng chọn ca làm việc trước khi điểm danh.');
      }, 300);
      return;
    }

    // Show page loader
    if (window.showPageLoader) {
      window.showPageLoader({
        text: type === 'Clock In' ? 'Đang điểm danh vào...' : 'Đang điểm danh ra...',
        subtitle: 'Vui lòng đợi trong giây lát',
      });
    }
    elements.checkinContainer.classList.add('loading');

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        try {
          const response = await fetch(`${checkinData.restUrl}checkin`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'X-WP-Nonce': checkinData.nonce,
            },
            body: JSON.stringify({
              employee_id: user.employee_id,
              display_name: user.display_name,
              latitude: position.coords.latitude,
              longitude: position.coords.longitude,
              type,
              selected_location: elements.locationDropdown.value,
              selected_shift: elements.shiftDropdown.value,
              employee_role: user.user_role,
            }),
          });
          const result = await response.json();

          if (result.success) {
            updateCheckinUI(result.data);

            // Hide loader trước khi hiển toast
            if (window.hidePageLoader) {
              window.hidePageLoader();
            }
            elements.checkinContainer.classList.remove('loading');

            // Delay toast để đảm bảo hiển thị sau khi loader ẩn
            setTimeout(() => {
              if (result.status_late) {
                toastWarning(
                  `Clock In thành công tại ${result.location_name}! Bạn đã đi trễ ${
                    result.late_minutes
                  } phút, mức phạt: ${result.penalty_amount.toLocaleString('vi-VN')} VNĐ.`
                );
              } else {
                toastSuccess(`${type} thành công tại ${result.location_name}!`);
              }
            }, 400);
            if (result.location_name) {
              elements.locationDropdown.value = result.location_name.trim();
            }
            if (result.shift_name) {
              elements.shiftDropdown.value = result.shift_name.trim();
            }
            const today = new Date();
            const formatted = today.toLocaleDateString('vi-VN', {
              weekday: 'long',
              year: 'numeric',
              month: '2-digit',
              day: '2-digit',
            });
            elements.dateDisplay.textContent =
              formatted.charAt(0).toUpperCase() + formatted.slice(1);
          } else {
            // Hide loader trước
            if (window.hidePageLoader) {
              window.hidePageLoader();
            }
            elements.checkinContainer.classList.remove('loading');

            // Delay toast
            setTimeout(() => {
              showWarning(result.message);
            }, 400);

            if (result.nearest_location) {
              setTimeout(() => {
                elements.locationDropdown.value = result.nearest_location.trim();
                resetToDefaultMessage(false, result.nearest_location);
              }, 5000);
            } else {
              setTimeout(
                () => resetToDefaultMessage(false, elements.locationDropdown.value),
                10000
              );
            }
          }
        } catch (error) {
          console.error(`Error during ${type}:`, error);

          // Hide loader trước
          if (window.hidePageLoader) {
            window.hidePageLoader();
          }
          elements.checkinContainer.classList.remove('loading');

          // Delay toast
          setTimeout(() => {
            showError('Lỗi hệ thống khi thực hiện điểm danh. Vui lòng thử lại.');
          }, 400);

          setTimeout(() => resetToDefaultMessage(false, elements.locationDropdown.value), 10000);
        }
      },
      () => {
        // Hide page loader
        if (window.hidePageLoader) {
          window.hidePageLoader();
        } else if (elements.loadingOverlay) {
          elements.loadingOverlay.style.display = 'none';
        }
        elements.checkinContainer.classList.remove('loading');

        // Delay toast để tránh bị che bởi loader
        setTimeout(() => {
          showWarning('Không thể lấy vị trí. Vui lòng chọn chi nhánh thủ công và thử lại.');
        }, 300);
        setTimeout(() => resetToDefaultMessage(false, elements.locationDropdown.value), 5000);
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );
  }

  // Sự kiện cho nút Clock In
  elements.clockInBtn.addEventListener('click', () => handleCheckin('Clock In'));

  // Sự kiện cho nút Clock Out
  elements.clockOutBtn.addEventListener('click', () => handleCheckin('Clock Out'));

  // Sự kiện khi thay đổi dropdown
  async function handleDropdownChange(event) {
    const user = await fetchUserProfile();
    if (!user || !user.employee_id) return;

    const target = event.target === elements.locationDropdown ? 'Chi nhánh' : 'Ca làm việc';
    const value = event.target.value;
    logUserAction('Change Dropdown', `Thay đổi ${target}: ${value}`, 'info');

    // Show page loader
    if (window.showPageLoader) {
      window.showPageLoader({
        text: `Đang cập nhật ${target.toLowerCase()}...`,
        subtitle: value,
      });
    }
    elements.checkinContainer.classList.add('loading');

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        await updateCheckinStatus(user, position.coords.latitude, position.coords.longitude);
      },
      async () => {
        await updateCheckinStatus(user);
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );
  }

  elements.locationDropdown.addEventListener('change', handleDropdownChange);
  elements.shiftDropdown.addEventListener('change', handleDropdownChange);

  // Sự kiện cho nút Xem Log
  elements.viewLogBtn.addEventListener('click', (e) => {
    e.preventDefault();
    displayLogs();
    logUserAction('View Log', 'Mở modal xem log', 'info');
  });

  // Sự kiện đóng modal
  elements.closeModal.addEventListener('click', () => {
    elements.logModal.style.display = 'none';
    logUserAction('Close Log Modal', 'Đóng modal xem log', 'info');
  });

  // Dark Mode Toggle
  const themeToggle = document.getElementById('theme-toggle');
  const savedTheme = localStorage.getItem('theme') || 'light';
  document.documentElement.setAttribute('data-theme', savedTheme);

  if (themeToggle) {
    const icon = themeToggle.querySelector('i');
    icon.className = savedTheme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';

    themeToggle.addEventListener('click', () => {
      const currentTheme = document.documentElement.getAttribute('data-theme');
      const newTheme = currentTheme === 'dark' ? 'light' : 'dark';

      document.documentElement.setAttribute('data-theme', newTheme);
      localStorage.setItem('theme', newTheme);
      icon.className = newTheme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';

      logUserAction(
        'Theme Toggle',
        `Chuyển sang chế độ ${newTheme === 'dark' ? 'tối' : 'sáng'}`,
        'info'
      );
      toastInfo(`Đã chuyển sang chế độ ${newTheme === 'dark' ? 'tối' : 'sáng'}`);
    });
  }

  // Logout Button
  const logoutBtn = document.getElementById('logout-btn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', (e) => {
      e.preventDefault();
      logUserAction('Logout', 'Người dùng đăng xuất', 'info');
      window.location.href = '/wp-login.php?action=logout';
    });
  }

  // Đóng modal khi nhấn ra ngoài
  window.addEventListener('click', (event) => {
    if (event.target === elements.logModal) {
      elements.logModal.style.display = 'none';
      logUserAction('Close Log Modal', 'Đóng modal xem log bằng cách nhấn bên ngoài', 'info');
    }
  });

  // Thêm sự kiện cho nút Admin
  elements.adminBtn.addEventListener('click', (e) => {
    e.preventDefault();
    logUserAction('Admin Navigation', 'Chuyển hướng đến trang Admin', 'info');
    window.location.href = '/admin';
  });

  // Filter functionality
  let currentFilter = 'today';
  const historyTitle = document.getElementById('history-title');
  const filterPills = document.querySelectorAll('.filter-pill');

  const filterTitles = {
    today: 'hôm nay',
    yesterday: 'hôm qua',
    'this-month': 'tháng này',
    'last-month': 'tháng trước',
  };

  async function loadFilteredHistory(filter) {
    const user = await fetchUserProfile();
    if (!user || !user.employee_id) return;

    // Show page loader
    if (window.showPageLoader) {
      window.showPageLoader({
        text: `Đang tải lịch sử ${filterTitles[filter]}...`,
        subtitle: 'Vui lòng đợi trong giây lát',
      });
    }

    // Determine if we should show date on cards (for filters other than today/yesterday)
    const showDateOnCards = filter === 'this-month' || filter === 'last-month';

    // Convert filter format for API
    let apiFilter = filter;
    if (filter === 'this-month') apiFilter = 'this_month';
    if (filter === 'last-month') apiFilter = 'last_month';

    try {
      const response = await fetch(
        `${checkinData.restUrl}checkin-logs?employee_id=${encodeURIComponent(
          user.employee_id
        )}&filter=${apiFilter}&limit=100`,
        {
          headers: { 'X-WP-Nonce': checkinData.nonce },
        }
      );
      const result = await response.json();

      console.log('[loadFilteredHistory] API Response:', result);

      if (result.success && result.data && result.data.length > 0) {
        // Convert data format to match updateCheckinUI expectations
        const formattedData = result.data.map((log) => ({
          shift: log.shift,
          checkin_time: log.checkin_time,
          checkout_time: log.checkout_time,
          status: log.status,
          status_late: Boolean(log.status_late),
          late_minutes: parseInt(log.late_minutes) || 0,
          penalty_amount: parseFloat(log.penalty_amount) || 0,
          has_late_request: log.has_late_request || false,
        }));

        updateCheckinUI(formattedData, showDateOnCards);

        // Hide loader
        if (window.hidePageLoader) {
          window.hidePageLoader();
        }

        // Update title
        if (historyTitle) {
          historyTitle.textContent = `Lịch sử điểm danh ${filterTitles[filter]}`;
        }

        logUserAction('Filter History', `Lọc lịch sử: ${filterTitles[filter]}`, 'info');
      } else {
        // Hide loader
        if (window.hidePageLoader) {
          window.hidePageLoader();
        }

        elements.checkinTimeIn.innerHTML = `
          <div style="text-align: center; padding: 2rem; color: var(--text-muted);">
            <i class="fas fa-inbox" style="font-size: 3rem; opacity: 0.3; margin-bottom: 1rem;"></i>
            <p>Không có dữ liệu điểm danh ${filterTitles[filter]}</p>
          </div>
        `;

        if (historyTitle) {
          historyTitle.textContent = `Lịch sử điểm danh ${filterTitles[filter]}`;
        }
      }
    } catch (error) {
      console.error('[loadFilteredHistory] Error:', error);

      // Hide loader
      if (window.hidePageLoader) {
        window.hidePageLoader();
      }

      setTimeout(() => {
        showError('Lỗi khi tải lịch sử điểm danh. Vui lòng thử lại.');
      }, 300);

      logUserAction('Filter History', `Lỗi khi lọc: ${error.message}`, 'error');
    }
  }

  // Add event listeners to filter pills
  filterPills.forEach((pill) => {
    pill.addEventListener('click', async (e) => {
      const filter = e.currentTarget.dataset.filter;

      if (filter === currentFilter) return; // Already selected

      // Update active state
      filterPills.forEach((p) => p.classList.remove('active'));
      e.currentTarget.classList.add('active');

      currentFilter = filter;

      // For "today" filter, use updateCheckinStatus to enable Clock In/Out buttons
      if (filter === 'today') {
        const user = await fetchUserProfile();
        if (!user || !user.employee_id) return;

        // Show page loader
        if (window.showPageLoader) {
          window.showPageLoader({
            text: `Đang tải lịch sử ${filterTitles[filter]}...`,
            subtitle: 'Vui lòng đợi trong giây lát',
          });
        }

        // Update title
        if (historyTitle) {
          historyTitle.textContent = `Lịch sử điểm danh ${filterTitles[filter]}`;
        }

        navigator.geolocation.getCurrentPosition(
          async (position) => {
            await updateCheckinStatus(user, position.coords.latitude, position.coords.longitude);
            logUserAction('Filter History', `Lọc lịch sử: ${filterTitles[filter]}`, 'info');
          },
          async () => {
            await updateCheckinStatus(user);
            logUserAction(
              'Filter History',
              `Lọc lịch sử: ${filterTitles[filter]} (không có GPS)`,
              'info'
            );
          },
          { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
        );
      } else {
        // Load filtered data for other filters
        await loadFilteredHistory(filter);
      }
    });
  });

  // Khởi tạo
  elements.checkinContainer.style.display = 'block';
  const clockInterval = setInterval(updateClock, 1000);
  updateClock();
  await initializeCheckinStatus();
});
