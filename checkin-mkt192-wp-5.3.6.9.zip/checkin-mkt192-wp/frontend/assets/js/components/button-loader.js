/**
 * Button Loader Utility - Reusable JavaScript utility
 * Version: 1.0.0
 * Description: Standardized button loading states for all buttons
 */

(function (window) {
  'use strict';

  /**
   * Button loading state manager
   * Stores original HTML for each button to restore later
   */
  const buttonStates = new WeakMap();

  /**
   * Set button to loading state
   * @param {HTMLElement} button - The button element
   * @param {string} loadingText - Text to display during loading (default: '...')
   * @returns {void}
   */
  function setButtonLoading(button, loadingText = '...') {
    if (!button) {
      console.warn('ButtonLoader: Invalid button element');
      return;
    }

    // Store original HTML if not already stored
    if (!buttonStates.has(button)) {
      buttonStates.set(button, {
        originalHTML: button.innerHTML,
        originalDisabled: button.disabled,
      });
    }

    // Set loading state
    button.disabled = true;
    button.innerHTML = `<i class="fas fa-spinner fa-spin"></i> ${loadingText}`;
  }

  /**
   * Reset button to original state
   * @param {HTMLElement} button - The button element
   * @param {string} customHTML - Optional custom HTML to set (if not using stored original)
   * @returns {void}
   */
  function resetButtonLoading(button, customHTML = null) {
    if (!button) {
      console.warn('ButtonLoader: Invalid button element');
      return;
    }

    const state = buttonStates.get(button);

    if (customHTML !== null) {
      // Use custom HTML if provided
      button.innerHTML = customHTML;
      button.disabled = false;
    } else if (state) {
      // Restore original state
      button.innerHTML = state.originalHTML;
      button.disabled = state.originalDisabled;
      // Clean up stored state
      buttonStates.delete(button);
    } else {
      // Fallback: just enable the button
      button.disabled = false;
      console.warn('ButtonLoader: No stored state found for button, only enabling it');
    }
  }

  /**
   * Get original button HTML (useful for manual restoration)
   * @param {HTMLElement} button - The button element
   * @returns {string|null} Original HTML or null if not found
   */
  function getOriginalHTML(button) {
    const state = buttonStates.get(button);
    return state ? state.originalHTML : null;
  }

  // Expose to window
  window.ButtonLoader = {
    setLoading: setButtonLoading,
    reset: resetButtonLoading,
    getOriginalHTML: getOriginalHTML,
  };

  // Also expose as standalone functions for convenience
  window.setButtonLoading = setButtonLoading;
  window.resetButtonLoading = resetButtonLoading;
})(window);
