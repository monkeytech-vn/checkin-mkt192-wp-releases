/**
 * Branch Helper Module - Quản lý chi nhánh (Branch System)
 *
 * Module reusable cho phép quản lý chi nhánh, auto-detect địa điểm,
 * và lọc dữ liệu theo chi nhánh.
 *
 * Usage:
 *   const branchHelper = new BranchHelper();
 *   branchHelper.initialize();
 */

class BranchHelper {
  /**
   * Constructor
   * @param {Object} options - Cấu hình
   * @param {boolean} options.adminMode - Nếu true, lấy tất cả chi nhánh (không lọc theo user)
   */
  constructor(options = {}) {
    this.apiUrl = '/wp-json/vg/v1';
    this.storageKey = 'checkin_current_branch';
    this.storageKeyId = 'checkin_current_branch_id';
    this.storageKeyManual = 'checkin_branch_manual'; // Track if user manually selected
    this.storageKeyGPS = 'checkin_last_gps'; // Store last GPS coordinates
    this.branches = []; // Danh sách chi nhánh user được phép làm (hoặc tất cả nếu adminMode)
    this.allBranches = []; // Danh sách tất cả chi nhánh (luôn load)
    this.currentBranch = null; // branch name for display
    this.currentBranchId = null; // branch ID for API calls
    this.primaryBranchId = null; // Primary branch từ staff table
    this.todayCheckinBranch = null; // Chi nhánh điểm danh hôm nay
    this.isAutoDetected = false;
    this.isManualSelection = false; // User manually selected branch
    this.adminMode = options.adminMode || false; // Admin mode: lấy tất cả chi nhánh
    this.callbacks = {
      onBranchChange: null,
      onDetected: null,
      onError: null,
    };
  }

  /**
   * Khởi tạo Branch Helper
   * - Lấy danh sách chi nhánh user được phép làm (hoặc tất cả nếu adminMode)
   * - Phát hiện chi nhánh hiện tại dựa trên GPS hoặc điểm danh
   * - Load chi nhánh từ storage/server
   */
  async initialize() {
    try {
      // Luôn lấy tất cả chi nhánh trước để lưu vào allBranches
      await this.getAllBranches();

      // Nếu adminMode, dùng allBranches làm branches
      // Nếu không, lấy user branches (lọc theo user_branch trong staff table)
      if (this.adminMode) {
        this.branches = [...this.allBranches];
      } else {
        await this.getUserBranches();
      }

      // CRITICAL FIX: Clear legacy localStorage with branch_name
      // Xóa key cũ trước khi init để tránh dùng dữ liệu cũ
      const legacyBranch = localStorage.getItem(this.storageKey);
      if (legacyBranch && typeof legacyBranch === 'string' && !legacyBranch.match(/^\d+$/)) {
        // Nếu value là string (branch_name) thay vì number (branch_id), xóa nó
        console.log('Clearing legacy branch_name from localStorage:', legacyBranch);
        localStorage.removeItem(this.storageKey);
        localStorage.removeItem(this.storageKeyId);
      }

      // Validate cache: Đảm bảo chi nhánh trong cache thuộc danh sách user được phép
      const cachedBranchId = parseInt(localStorage.getItem(this.storageKeyId));
      if (cachedBranchId && this.branches.length > 0) {
        const isBranchAllowed = this.branches.some((b) => b.id === cachedBranchId);
        if (!isBranchAllowed) {
          console.log('⚠️ Cached branch not in allowed list, clearing cache');
          localStorage.removeItem(this.storageKey);
          localStorage.removeItem(this.storageKeyId);
          localStorage.removeItem(this.storageKeyManual);
        }
      }

      // SIMPLE Priority: Try cache first (fast), then GPS, then checkin, then primary
      // 1. Try cache (instant if exists)
      const cachedBranch = await this.loadFromCache();
      if (cachedBranch) {
        console.log('✅ Using cached branch (skip GPS & server API)');
        this.isManualSelection = localStorage.getItem(this.storageKeyManual) === 'true';
        return true;
      }

      // 2. Try GPS detection - chỉ trong danh sách chi nhánh user được phép
      const detectedBranch = await this.detectBranchFromUserBranches();

      // 3. Fallback to today's checkin branch
      if (!detectedBranch && this.todayCheckinBranch) {
        const checkinBranch = this.branches.find((b) => b.id === this.todayCheckinBranch);
        if (checkinBranch) {
          this.currentBranchId = checkinBranch.id;
          this.currentBranch = checkinBranch.branch_name;
          this.isAutoDetected = true;
          this.saveBranchToCache(checkinBranch);
          console.log('✅ Using today checkin branch:', checkinBranch);
        }
      }

      // 4. Fallback to primary branch
      if (!this.currentBranchId && this.primaryBranchId) {
        const primaryBranch = this.branches.find((b) => b.id === this.primaryBranchId);
        if (primaryBranch) {
          this.currentBranchId = primaryBranch.id;
          this.currentBranch = primaryBranch.branch_name;
          this.isAutoDetected = true;
          this.saveBranchToCache(primaryBranch);
        }
      }

      // 5. Fallback to first branch in list
      if (!this.currentBranchId && this.branches.length > 0) {
        const firstBranch = this.branches[0];
        this.currentBranchId = firstBranch.id;
        this.currentBranch = firstBranch.branch_name;
        this.isAutoDetected = true;
        this.saveBranchToCache(firstBranch);
      }

      return true;
    } catch (error) {
      console.error('BranchHelper initialization failed:', error);
      this.triggerCallback('onError', error);
      return false;
    }
  }

  /**
   * Lấy danh sách chi nhánh user được phép làm việc từ API
   * Dựa trên cột 'branch' trong staff table
   */
  async getUserBranches() {
    try {
      // Kiểm tra nonce trước khi gọi API
      if (!window.checkinData?.nonce) {
        console.warn('⚠️ getUserBranches: No nonce available, user might not be logged in');
        this.branches = [...this.allBranches];
        return this.branches;
      }

      const response = await fetch(`${this.apiUrl}/user-branches`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'X-WP-Nonce': window.checkinData.nonce,
        },
      });

      // Check if response is JSON before parsing
      const contentType = response.headers.get('content-type');
      if (!contentType || !contentType.includes('application/json')) {
        const text = await response.text();
        console.error(
          '❌ API returned non-JSON response (HTML error page?):',
          text.substring(0, 300)
        );
        console.error('Response status:', response.status, 'URL:', `${this.apiUrl}/user-branches`);
        // Fallback to all branches
        this.branches = [...this.allBranches];
        return this.branches;
      }

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        console.error('❌ API error:', response.status, errorData.message || 'Unknown error');
        this.branches = [...this.allBranches];
        return this.branches;
      }

      const data = await response.json();

      if (data.success && data.data) {
        this.branches = data.data;
        this.primaryBranchId = data.primary_branch_id || null;
        this.todayCheckinBranch = data.today_checkin_branch || null;
        return this.branches;
      } else {
        // Fallback to all branches if user-branches fails
        this.branches = [...this.allBranches];
        return this.branches;
      }
    } catch (error) {
      console.error('Error fetching user branches:', error);
      // Fallback to all branches
      this.branches = [...this.allBranches];
      return this.branches;
    }
  }

  /**
   * Lấy danh sách tất cả chi nhánh từ API và lưu vào allBranches
   */
  async getAllBranches() {
    try {
      const response = await fetch(`${this.apiUrl}/branches`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'X-WP-Nonce': window.checkinData?.nonce || '',
        },
      });

      if (!response.ok) {
        throw new Error(`API error: ${response.status}`);
      }

      const data = await response.json();

      if (data.success && data.data) {
        this.allBranches = data.data;
        return this.allBranches;
      } else {
        throw new Error(data.message || 'Failed to fetch all branches');
      }
    } catch (error) {
      console.error('Error fetching all branches:', error);
      this.triggerCallback('onError', error);
      return [];
    }
  }

  /**
   * Lấy danh sách tất cả chi nhánh từ API (legacy - dùng getAllBranches thay thế)
   */
  async getBranches() {
    try {
      const response = await fetch(`${this.apiUrl}/branches`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'X-WP-Nonce': window.checkinData?.nonce || '',
        },
      });

      if (!response.ok) {
        throw new Error(`API error: ${response.status}`);
      }

      const data = await response.json();

      if (data.success && data.data) {
        this.branches = data.data;
        return this.branches;
      } else {
        throw new Error(data.message || 'Failed to fetch branches');
      }
    } catch (error) {
      console.error('Error fetching branches:', error);
      this.triggerCallback('onError', error);
      return [];
    }
  }

  /**
   * Load branch từ localStorage cache (nhanh hơn API call)
   * @return {object|null} Cached branch info hoặc null
   */
  async loadFromCache() {
    const cachedBranchId = localStorage.getItem(this.storageKeyId);
    const cachedBranchName = localStorage.getItem(this.storageKey);

    if (!cachedBranchId || !cachedBranchName) {
      return null;
    }

    // Use cache immediately - no validation (trust cache for speed)
    this.currentBranchId = parseInt(cachedBranchId);
    this.currentBranch = cachedBranchName;
    this.isAutoDetected = false;

    return {
      id: this.currentBranchId,
      branch_name: this.currentBranch,
      cached: true,
    };
  }

  /**
   * Clear localStorage cache
   */
  clearCache() {
    localStorage.removeItem(this.storageKey);
    localStorage.removeItem(this.storageKeyId);
    localStorage.removeItem(this.storageKeyManual);
  }

  /**
   * Save branch to cache only (no API call)
   */
  saveBranchToCache(branchData) {
    const branchName = branchData.branch_name || branchData.location_name;
    const branchId = branchData.id;

    localStorage.setItem(this.storageKey, branchName);
    localStorage.setItem(this.storageKeyId, String(branchId));
    localStorage.removeItem(this.storageKeyManual); // Not manual selection
  }

  /**
   * Phát hiện chi nhánh gần nhất từ GPS trong danh sách user được phép
   * Chỉ xét các chi nhánh trong this.branches (không phải tất cả)
   * @return {object|null} Detected branch hoặc null
   */
  async detectBranchFromUserBranches() {
    try {
      // Nếu user chỉ có 1 chi nhánh, không cần detect GPS
      if (this.branches.length === 1) {
        const onlyBranch = this.branches[0];
        this.currentBranchId = onlyBranch.id;
        this.currentBranch = onlyBranch.branch_name;
        this.isAutoDetected = true;
        this.saveBranchToCache(onlyBranch);
        console.log('✅ User has only 1 branch, auto-selecting:', onlyBranch);
        return onlyBranch;
      }

      // Kiểm tra browser support cho Geolocation API
      if (!navigator.geolocation) {
        console.warn('Trình duyệt không hỗ trợ Geolocation');
        return null;
      }

      // Lấy vị trí GPS hiện tại
      const position = await new Promise((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject, {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 0,
        });
      });

      const userLat = position.coords.latitude;
      const userLon = position.coords.longitude;

      // Tính khoảng cách đến từng chi nhánh trong danh sách user được phép
      let nearestBranch = null;
      let minDistance = Infinity;

      for (const branch of this.branches) {
        if (!branch.latitude || !branch.longitude) continue;

        const distance = this.calculateDistance(
          userLat,
          userLon,
          parseFloat(branch.latitude),
          parseFloat(branch.longitude)
        );

        // Kiểm tra nếu trong bán kính
        const radius = branch.radius || 500; // Default 500m
        if (distance <= radius) {
          // Nếu trong bán kính và gần hơn chi nhánh trước
          if (distance < minDistance) {
            minDistance = distance;
            nearestBranch = branch;
          }
        }
      }

      // Nếu tìm thấy chi nhánh trong bán kính
      if (nearestBranch) {
        this.currentBranchId = nearestBranch.id;
        this.currentBranch = nearestBranch.branch_name;
        this.isAutoDetected = true;
        this.saveBranchToCache(nearestBranch);
        this.triggerCallback('onDetected', nearestBranch);
        return nearestBranch;
      }

      // Không tìm thấy trong bán kính - return null để fallback
      return null;
    } catch (error) {
      console.warn('GPS detection failed:', error.message);
      return null;
    }
  }

  /**
   * Phát hiện chi nhánh dựa trên vị trí GPS của user (old method - dùng API)
   * @return {object|null} Detected branch hoặc null
   */
  async detectBranch() {
    try {
      // Kiểm tra browser support cho Geolocation API
      if (!navigator.geolocation) {
        throw new Error('Trình duyệt không hỗ trợ Geolocation');
      }

      // Lấy vị trí GPS hiện tại
      const position = await new Promise((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject, {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 0,
        });
      });

      const latitude = position.coords.latitude;
      const longitude = position.coords.longitude;

      // Call API để detect chi nhánh dựa trên GPS
      const response = await fetch(
        `${this.apiUrl}/branch-by-location?latitude=${latitude}&longitude=${longitude}`,
        {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            'X-WP-Nonce': window.checkinData?.nonce || '',
          },
        }
      );

      if (!response.ok) {
        throw new Error(`API error: ${response.status}`);
      }

      const data = await response.json();

      if (data.success && data.detected_branch) {
        this.currentBranch = data.detected_branch.branch_name;
        this.currentBranchId = data.detected_branch.id;
        this.isAutoDetected = true;

        // Lưu chi nhánh được phát hiện vào cache
        this.saveBranchToCache(data.detected_branch);

        this.triggerCallback('onDetected', data.detected_branch);

        return data.detected_branch;
      } else if (data.success) {
        console.warn('No branch detected for coordinates:', { latitude, longitude });
        return null;
      } else {
        throw new Error(data.message || 'Detection failed');
      }
    } catch (error) {
      console.warn('Branch auto-detection failed:', error.message);
      this.triggerCallback('onError', error);
      return null;
    }
  }

  /**
   * Lấy chi nhánh hiện tại của user từ staff table (không dùng localStorage khi init)
   * @param {boolean} useStorage - có dùng localStorage hay không (default: false khi init)
   */
  async getCurrentBranch(useStorage = false) {
    try {
      // Nếu đã có currentBranchId trong memory, return luôn (đã fetch từ initialize)
      if (this.currentBranchId && this.currentBranch) {
        console.log('Using cached branch from memory:', {
          id: this.currentBranchId,
          name: this.currentBranch,
        });
        return this.currentBranch;
      }

      // Chỉ check localStorage nếu useStorage = true (không dùng khi init)
      if (useStorage) {
        const storedBranchId = localStorage.getItem(this.storageKeyId);
        const storedBranchName = localStorage.getItem(this.storageKey);
        if (storedBranchId && storedBranchName) {
          this.currentBranchId = parseInt(storedBranchId);
          this.currentBranch = storedBranchName;
          console.log('Using cached branch from localStorage:', {
            id: this.currentBranchId,
            name: this.currentBranch,
          });
          return this.currentBranch;
        }
      }

      // CRITICAL FIX: Luôn lấy từ server (staff table) để đảm bảo đúng branch_id
      console.log('Fetching current branch from staff table...');
      const response = await fetch(`${this.apiUrl}/user-current-branch`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'X-WP-Nonce': window.checkinData?.nonce || '',
        },
      });

      if (!response.ok) {
        throw new Error(`API error: ${response.status}`);
      }

      const data = await response.json();

      if (data.success && data.current_branch_id) {
        this.currentBranch = data.current_branch;
        this.currentBranchId = data.current_branch_id;

        // Lưu vào localStorage với branch_id (không phải branch_name)
        localStorage.setItem(this.storageKey, data.current_branch);
        localStorage.setItem(this.storageKeyId, String(data.current_branch_id));

        console.log('Branch loaded from staff table:', {
          id: this.currentBranchId,
          name: this.currentBranch,
        });

        return data.current_branch;
      } else {
        console.warn('No branch found in staff table for current user');
        return null;
      }
    } catch (error) {
      console.error('Error getting current branch:', error);
      this.triggerCallback('onError', error);
      return null;
    }
  }

  /**
   * Thiết lập chi nhánh hiện tại
   * @param {string|object} branchData Branch name string or branch object with id and name
   */
  async setCurrentBranch(branchData) {
    try {
      // Handle both string (legacy) and object (new) input
      let branchName, branchId;
      if (typeof branchData === 'object' && branchData !== null) {
        branchName = branchData.branch_name || branchData.location_name;
        branchId = branchData.id;
      } else {
        branchName = String(branchData).trim();
        // Find branch ID from branches array
        const branch = this.branches.find((b) => (b.branch_name || b.location_name) === branchName);
        branchId = branch ? branch.id : null;
      }

      if (!branchName) {
        throw new Error('Branch name cannot be empty');
      }

      // Update state immediately (no server call for speed!)
      const oldBranch = this.currentBranch;
      const oldBranchId = this.currentBranchId;
      this.currentBranch = branchName;
      this.currentBranchId = branchId;
      this.isAutoDetected = false;
      this.isManualSelection = true;

      // Save to localStorage cache only
      localStorage.setItem(this.storageKey, branchName);
      if (branchId) {
        localStorage.setItem(this.storageKeyId, String(branchId));
      }
      localStorage.setItem(this.storageKeyManual, 'true');

      console.log('✋ Branch updated (MANUAL, cache-only):', { name: branchName, id: branchId });
      this.triggerCallback('onBranchChange', {
        oldBranch: oldBranch,
        newBranch: branchName,
        oldBranchId: oldBranchId,
        newBranchId: branchId,
        isManual: true,
      });

      // Async save to server (fire-and-forget, don't wait)
      fetch(`${this.apiUrl}/user-current-branch`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-WP-Nonce': window.checkinData?.nonce || '',
        },
        body: JSON.stringify({
          branch_name: branchName,
          branch_id: branchId,
        }),
      }).catch((error) => {
        console.warn('Background save to server failed:', error);
      });

      return true;
    } catch (error) {
      console.error('Error setting current branch:', error);
      this.triggerCallback('onError', error);
      return false;
    }
  }

  /**
   * Lọc mảng dữ liệu theo chi nhánh hiện tại
   * @param {array} data Dữ liệu cần lọc
   * @param {string} branchField Tên field chứa branch (default: 'branch')
   * @param {string} branchValue Chi nhánh cần lọc (default: currentBranch)
   * @return {array} Dữ liệu đã lọc
   */
  filterByBranch(data, branchField = 'branch', branchValue = null) {
    if (!Array.isArray(data)) {
      console.warn('BranchHelper.filterByBranch: data is not an array');
      return [];
    }

    branchValue = branchValue || this.currentBranch;

    if (!branchValue) {
      console.warn('BranchHelper.filterByBranch: no branch value to filter');
      return data; // Trả về tất cả nếu không có branch
    }

    return data.filter((item) => {
      return String(item[branchField] || '') === String(branchValue);
    });
  }

  /**
   * Lấy danh sách chi nhánh để hiển thị trong dropdown/select
   * @return {array} Danh sách branch_name
   */
  getBranchList() {
    return this.branches.map((branch) => branch.branch_name);
  }

  /**
   * Get current branch ID
   * @return {number|null} Current branch ID
   */
  getCurrentBranchId() {
    return this.currentBranchId;
  }

  /**
   * Get current branch name
   * @return {string|null} Current branch name
   */
  getCurrentBranchName() {
    return this.currentBranch;
  }

  /**
   * Get branch object by ID
   * @param {number|string} branchId Branch ID
   * @return {object|null} Branch object
   */
  getBranchById(branchId) {
    const id = parseInt(branchId);
    return this.branches.find((b) => parseInt(b.id) === id) || null;
  }

  /**
   * Get branch object by name
   * @param {string} branchName Branch name
   * @return {object|null} Branch object
   */
  getBranchByName(branchName) {
    return this.branches.find((b) => (b.branch_name || b.location_name) === branchName) || null;
  }

  /**
   * Kiểm tra xem user có nằm trong bán kính của chi nhánh nào không
   * @param {number} latitude User latitude
   * @param {number} longitude User longitude
   * @return {object|null} Chi nhánh nếu trong bán kính, null nếu ngoài
   */
  checkIfInRange(latitude, longitude) {
    if (!this.currentBranch) {
      return null;
    }

    const branch = this.branches.find((b) => b.branch_name === this.currentBranch);
    if (!branch) {
      return null;
    }

    const distance = this.calculateDistance(latitude, longitude, branch.latitude, branch.longitude);

    if (distance <= branch.radius_m) {
      return {
        ...branch,
        distance_m: Math.round(distance),
        in_range: true,
      };
    }

    return {
      ...branch,
      distance_m: Math.round(distance),
      in_range: false,
    };
  }

  /**
   * Tính khoảng cách giữa hai điểm sử dụng Haversine formula
   * @param {number} lat1 Latitude 1
   * @param {number} lon1 Longitude 1
   * @param {number} lat2 Latitude 2
   * @param {number} lon2 Longitude 2
   * @return {number} Khoảng cách tính bằng mét
   */
  calculateDistance(lat1, lon1, lat2, lon2) {
    const earthRadius = 6371000; // Mét

    const lat1Rad = this.toRad(lat1);
    const lat2Rad = this.toRad(lat2);
    const deltaLat = this.toRad(lat2 - lat1);
    const deltaLon = this.toRad(lon2 - lon1);

    const a =
      Math.sin(deltaLat / 2) * Math.sin(deltaLat / 2) +
      Math.cos(lat1Rad) * Math.cos(lat2Rad) * Math.sin(deltaLon / 2) * Math.sin(deltaLon / 2);

    const c = 2 * Math.asin(Math.sqrt(a));

    return earthRadius * c;
  }

  /**
   * Chuyển đổi độ sang radian
   * @param {number} degrees Góc độ
   * @return {number} Radian
   */
  toRad(degrees) {
    return degrees * (Math.PI / 180);
  }

  /**
   * Đăng ký callback cho các sự kiện
   * @param {string} eventName Tên sự kiện (onBranchChange, onDetected, onError)
   * @param {function} callback Hàm callback
   */
  on(eventName, callback) {
    if (this.callbacks.hasOwnProperty(eventName)) {
      this.callbacks[eventName] = callback;
    } else {
      console.warn(`Unknown event: ${eventName}`);
    }
  }

  /**
   * Kích hoạt callback
   * @private
   */
  triggerCallback(eventName, data) {
    if (typeof this.callbacks[eventName] === 'function') {
      try {
        this.callbacks[eventName](data);
      } catch (error) {
        console.error(`Error in callback ${eventName}:`, error);
      }
    }
  }

  /**
   * Lấy chi nhánh hiện tại
   * @return {string|null}
   */
  getCurrentBranchName() {
    return this.currentBranch;
  }

  /**
   * Kiểm tra xem chi nhánh đã được auto-detect hay không
   * @return {boolean}
   */
  isAutoDetectedBranch() {
    return this.isAutoDetected;
  }

  /**
   * Reset chi nhánh - xóa storage và state
   */
  reset() {
    this.currentBranch = null;
    this.isAutoDetected = false;
    localStorage.removeItem(this.storageKey);
    console.log('BranchHelper reset');
  }

  /**
   * Lấy thông tin chi nhánh
   * @param {string} branchName Tên chi nhánh (optional, default: currentBranch)
   * @return {object|null}
   */
  getBranchInfo(branchName = null) {
    branchName = branchName || this.currentBranch;

    if (!branchName) {
      return null;
    }

    return this.branches.find((b) => b.branch_name === branchName) || null;
  }

  /**
   * Lấy tất cả chi nhánh dưới dạng object để tra cứu
   * @return {object} Key: branch_name, Value: branch info
   */
  getBranchesAsMap() {
    const map = {};
    this.branches.forEach((branch) => {
      map[branch.branch_name] = branch;
    });
    return map;
  }
}

// Export cho sử dụng trong các file khác
if (typeof module !== 'undefined' && module.exports) {
  module.exports = BranchHelper;
}
