/**
 * Homepage Notification Popup
 * Displays beautiful promotional-style popup notifications on the homepage
 *
 * @package Checkin_MKT192_WP
 * @since 7.0.0
 */

(function () {
  'use strict';

  // Configuration
  const CONFIG = {
    storageKey: 'checkin_viewed_notifications',
    apiEndpoint: '/wp-json/vg/v1/notifications/active',
    dismissDuration: 24 * 60 * 60 * 1000, // 24 hours in ms
    showDelay: 2000, // Delay before showing popup (ms)
    type: 'homepage',
  };

  // State
  let notifications = [];
  let currentIndex = 0;
  let popupElement = null;
  let slideshowTimer = null;

  // ============================================================================
  // INITIALIZATION
  // ============================================================================

  document.addEventListener('DOMContentLoaded', () => {
    // Only run on homepage
    if (!isHomepage()) return;

    // Wait for page to fully load before showing popup
    setTimeout(initNotificationPopup, CONFIG.showDelay);
  });

  function isHomepage() {
    // Check if on homepage by looking for specific elements or path
    return (
      window.location.pathname === '/' ||
      window.location.pathname === '/home' ||
      document.querySelector('[data-page="home"]') !== null ||
      document.body.classList.contains('home')
    );
  }

  async function initNotificationPopup() {
    try {
      // Get branch ID if available
      let branchId = '';
      if (typeof window.selectedBranchId !== 'undefined') {
        branchId = window.selectedBranchId;
      }

      // Fetch active notifications
      const response = await fetch(
        `${CONFIG.apiEndpoint}?type=${CONFIG.type}&branch_id=${branchId}&limit=5`
      );
      const result = await response.json();

      if (result.success && result.data && result.data.length > 0) {
        // Filter out already viewed notifications
        notifications = filterUnviewedNotifications(result.data);

        if (notifications.length > 0) {
          createPopupStructure();
          showNotification(0);
        }
      }
    } catch (error) {
      console.error('[NotificationPopup] Error loading notifications:', error);
    }
  }

  // ============================================================================
  // VIEWED NOTIFICATIONS TRACKING
  // ============================================================================

  function filterUnviewedNotifications(notificationList) {
    const viewedData = getViewedNotifications();
    const now = Date.now();

    return notificationList.filter((notification) => {
      const viewedAt = viewedData[notification.id];
      // Show if never viewed or viewed more than dismissDuration ago
      return !viewedAt || now - viewedAt > CONFIG.dismissDuration;
    });
  }

  function getViewedNotifications() {
    try {
      const data = localStorage.getItem(CONFIG.storageKey);
      return data ? JSON.parse(data) : {};
    } catch {
      return {};
    }
  }

  function markNotificationAsViewed(notificationId) {
    try {
      const viewedData = getViewedNotifications();
      viewedData[notificationId] = Date.now();
      localStorage.setItem(CONFIG.storageKey, JSON.stringify(viewedData));

      // Track view via API
      trackNotificationView(notificationId);
    } catch (error) {
      console.error('[NotificationPopup] Error saving viewed status:', error);
    }
  }

  async function trackNotificationView(notificationId) {
    try {
      await fetch(`/wp-json/vg/v1/notifications/${notificationId}/view`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
      });
    } catch {
      // Silent fail
    }
  }

  // ============================================================================
  // POPUP UI CREATION
  // ============================================================================

  function createPopupStructure() {
    // Create overlay
    popupElement = document.createElement('div');
    popupElement.className = 'homepage-notification-overlay';
    popupElement.innerHTML = `
      <div class="homepage-notification-container">
        <button type="button" class="notification-popup-close" aria-label="Đóng">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <line x1="18" y1="6" x2="6" y2="18"></line>
            <line x1="6" y1="6" x2="18" y2="18"></line>
          </svg>
        </button>

        <div class="notification-popup-content">
          <div class="notification-popup-media" data-aspect="16:9">
            <!-- Media content will be inserted here -->
          </div>
          <div class="notification-popup-body">
            <h2 class="notification-popup-title"></h2>
            <div class="notification-popup-text"></div>
            <a href="#" class="notification-popup-cta" target="_blank" rel="noopener" style="display: none;">
              Xem chi tiết
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M5 12h14M12 5l7 7-7 7"></path>
              </svg>
            </a>
          </div>
        </div>

        <div class="notification-popup-footer">
          <label class="notification-dismiss-checkbox">
            <input type="checkbox" id="notification-dismiss-24h" />
            <span>Không hiển thị lại trong 24 giờ</span>
          </label>
        </div>

        <div class="notification-popup-nav" style="display: none;">
          <button type="button" class="popup-nav-prev" aria-label="Trước">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M15 18l-6-6 6-6"></path>
            </svg>
          </button>
          <div class="popup-nav-dots"></div>
          <button type="button" class="popup-nav-next" aria-label="Sau">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M9 18l6-6-6-6"></path>
            </svg>
          </button>
        </div>
      </div>
    `;

    // Add styles
    addPopupStyles();

    // Add to DOM
    document.body.appendChild(popupElement);

    // Add event listeners
    setupEventListeners();
  }

  function setupEventListeners() {
    // Close button
    const closeBtn = popupElement.querySelector('.notification-popup-close');
    closeBtn?.addEventListener('click', closePopup);

    // Overlay click
    popupElement.addEventListener('click', (e) => {
      if (e.target === popupElement) {
        closePopup();
      }
    });

    // Navigation
    const prevBtn = popupElement.querySelector('.popup-nav-prev');
    const nextBtn = popupElement.querySelector('.popup-nav-next');

    prevBtn?.addEventListener('click', () => {
      if (currentIndex > 0) {
        showNotification(currentIndex - 1);
      }
    });

    nextBtn?.addEventListener('click', () => {
      if (currentIndex < notifications.length - 1) {
        showNotification(currentIndex + 1);
      }
    });

    // Keyboard navigation
    document.addEventListener('keydown', handleKeydown);

    // Swipe support for mobile
    setupSwipeSupport();
  }

  function handleKeydown(e) {
    if (!popupElement || !popupElement.classList.contains('active')) return;

    switch (e.key) {
      case 'Escape':
        closePopup();
        break;
      case 'ArrowLeft':
        if (currentIndex > 0) showNotification(currentIndex - 1);
        break;
      case 'ArrowRight':
        if (currentIndex < notifications.length - 1) showNotification(currentIndex + 1);
        break;
    }
  }

  function setupSwipeSupport() {
    let touchStartX = 0;
    let touchEndX = 0;
    const container = popupElement.querySelector('.homepage-notification-container');

    container?.addEventListener('touchstart', (e) => {
      touchStartX = e.changedTouches[0].screenX;
    });

    container?.addEventListener('touchend', (e) => {
      touchEndX = e.changedTouches[0].screenX;
      handleSwipe();
    });

    function handleSwipe() {
      const swipeThreshold = 50;
      const diff = touchStartX - touchEndX;

      if (Math.abs(diff) > swipeThreshold) {
        if (diff > 0 && currentIndex < notifications.length - 1) {
          // Swipe left - next
          showNotification(currentIndex + 1);
        } else if (diff < 0 && currentIndex > 0) {
          // Swipe right - previous
          showNotification(currentIndex - 1);
        }
      }
    }
  }

  // ============================================================================
  // POPUP DISPLAY
  // ============================================================================

  function showNotification(index) {
    if (!popupElement || index < 0 || index >= notifications.length) return;

    currentIndex = index;
    const notification = notifications[index];

    // Update media with aspect ratio
    const mediaContainer = popupElement.querySelector('.notification-popup-media');
    if (mediaContainer) {
      // Set aspect ratio from notification data or default to 16:9
      const aspectRatio = notification.aspect_ratio || '16:9';
      mediaContainer.setAttribute('data-aspect', aspectRatio);

      // Set padding-bottom based on aspect ratio
      let paddingBottom = '56.25%'; // default 16:9
      if (aspectRatio === '1:1') paddingBottom = '100%';
      else if (aspectRatio === '9:16') paddingBottom = '177.78%';
      else if (aspectRatio === '4:3') paddingBottom = '75%';
      mediaContainer.style.paddingBottom = paddingBottom;

      if (notification.media_url) {
        if (notification.media_type === 'video') {
          mediaContainer.innerHTML = `
            <video src="${notification.media_url}" autoplay muted loop playsinline></video>
          `;
        } else {
          mediaContainer.innerHTML = `
            <img src="${notification.media_url}" alt="${escapeHtml(notification.title)}" />
          `;
        }
      } else {
        // Default gradient background with icon
        mediaContainer.innerHTML = `
          <div class="notification-popup-default-media">
            <svg width="60" height="60" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
              <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
              <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
            </svg>
          </div>
        `;
      }
    }

    // Update content - render as markdown/formatted text
    const titleEl = popupElement.querySelector('.notification-popup-title');
    const textEl = popupElement.querySelector('.notification-popup-text');
    const ctaEl = popupElement.querySelector('.notification-popup-cta');

    if (titleEl) titleEl.textContent = notification.title;
    if (textEl) {
      // Convert simple markdown to HTML
      textEl.innerHTML = formatContent(notification.content);
    }

    if (ctaEl) {
      if (notification.link) {
        ctaEl.href = notification.link;
        ctaEl.style.display = 'inline-flex';
      } else {
        ctaEl.style.display = 'none';
      }
    }

    // Update navigation
    updateNavigation();

    // Show popup with animation
    requestAnimationFrame(() => {
      popupElement.classList.add('active');
      document.body.style.overflow = 'hidden';
    });

    // Track view for analytics (but don't mark as dismissed)
    trackNotificationView(notification.id);

    // Start auto slideshow if there are multiple notifications
    startSlideshow();
  }

  function startSlideshow() {
    // Clear any existing timer
    if (slideshowTimer) {
      clearTimeout(slideshowTimer);
      slideshowTimer = null;
    }

    // Only auto-advance if there are multiple notifications
    if (notifications.length <= 1) return;

    // Get slide duration from current notification (default 5 seconds)
    const currentNotification = notifications[currentIndex];
    const duration = (parseInt(currentNotification.slide_duration) || 5) * 1000;

    slideshowTimer = setTimeout(() => {
      // Advance to next notification, loop back to first if at end
      const nextIndex = (currentIndex + 1) % notifications.length;
      showNotification(nextIndex);
    }, duration);
  }

  function stopSlideshow() {
    if (slideshowTimer) {
      clearTimeout(slideshowTimer);
      slideshowTimer = null;
    }
  }

  function updateNavigation() {
    const nav = popupElement.querySelector('.notification-popup-nav');
    const dotsContainer = popupElement.querySelector('.popup-nav-dots');
    const prevBtn = popupElement.querySelector('.popup-nav-prev');
    const nextBtn = popupElement.querySelector('.popup-nav-next');

    if (notifications.length <= 1) {
      if (nav) nav.style.display = 'none';
      return;
    }

    if (nav) nav.style.display = 'flex';

    // Update dots
    if (dotsContainer) {
      dotsContainer.innerHTML = notifications
        .map(
          (_, i) =>
            `<button type="button" class="popup-nav-dot ${
              i === currentIndex ? 'active' : ''
            }" data-index="${i}"></button>`
        )
        .join('');

      // Add dot click handlers
      dotsContainer.querySelectorAll('.popup-nav-dot').forEach((dot) => {
        dot.addEventListener('click', () => {
          const index = parseInt(dot.dataset.index);
          showNotification(index);
        });
      });
    }

    // Update button states
    if (prevBtn) prevBtn.disabled = currentIndex === 0;
    if (nextBtn) nextBtn.disabled = currentIndex === notifications.length - 1;
  }

  function closePopup() {
    if (!popupElement) return;

    // Stop auto slideshow
    stopSlideshow();

    // Check if user wants to dismiss for 24h
    const dismissCheckbox = popupElement.querySelector('#notification-dismiss-24h');
    if (dismissCheckbox && dismissCheckbox.checked) {
      // Mark ALL current notifications as viewed with 24h dismiss
      notifications.forEach((notification) => {
        markNotificationAsViewed(notification.id);
      });
    }

    popupElement.classList.remove('active');
    document.body.style.overflow = '';

    // Clean up after animation
    setTimeout(() => {
      document.removeEventListener('keydown', handleKeydown);
      popupElement?.remove();
      popupElement = null;
    }, 300);
  }

  // ============================================================================
  // CONTENT FORMATTING
  // ============================================================================

  function formatContent(content) {
    if (!content) return '';

    // Content is now stored as HTML from contenteditable editor
    // Clean up trailing empty elements and line breaks
    let cleaned = content
      .replace(/(<br\s*\/?>)+$/gi, '') // Remove trailing <br>
      .replace(/(<div><br\s*\/?><\/div>)+$/gi, '') // Remove trailing empty divs with br
      .replace(/(<p><br\s*\/?><\/p>)+$/gi, '') // Remove trailing empty paragraphs with br
      .replace(/(<div>\s*<\/div>)+$/gi, '') // Remove trailing empty divs
      .replace(/(<p>\s*<\/p>)+$/gi, '') // Remove trailing empty paragraphs
      .replace(/\s+$/g, ''); // Trim trailing whitespace

    return cleaned;
  }

  // ============================================================================
  // STYLES
  // ============================================================================

  function addPopupStyles() {
    if (document.getElementById('homepage-notification-styles')) return;

    const style = document.createElement('style');
    style.id = 'homepage-notification-styles';
    style.textContent = `
      .homepage-notification-overlay {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0, 0, 0, 0.75);
        backdrop-filter: blur(8px);
        -webkit-backdrop-filter: blur(8px);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 99999;
        padding: 20px;
        opacity: 0;
        visibility: hidden;
        transition: opacity 0.3s ease, visibility 0.3s ease;
      }

      .homepage-notification-overlay.active {
        opacity: 1;
        visibility: visible;
      }

      .homepage-notification-container {
        position: relative;
        max-width: 420px;
        width: 100%;
        max-height: calc(100vh - 40px);
        background: #fff;
        border-radius: 20px;
        overflow: hidden;
        box-shadow: 0 25px 80px rgba(0, 0, 0, 0.3);
        transform: scale(0.9) translateY(20px);
        transition: transform 0.4s cubic-bezier(0.34, 1.56, 0.64, 1);
        display: flex;
        flex-direction: column;
      }

      .homepage-notification-overlay.active .homepage-notification-container {
        transform: scale(1) translateY(0);
      }

      .notification-popup-close {
        position: absolute;
        top: 12px;
        right: 12px;
        width: 36px;
        height: 36px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: rgba(0, 0, 0, 0.5);
        border: none;
        border-radius: 50%;
        color: #fff;
        cursor: pointer;
        z-index: 10;
        transition: all 0.2s ease;
      }

      .notification-popup-close:hover {
        background: rgba(0, 0, 0, 0.7);
        transform: rotate(90deg);
      }

      .notification-popup-content {
        flex: 1;
        overflow-y: auto;
        overflow-x: hidden;
        max-height: calc(100vh - 140px);
      }

      .notification-popup-media {
        position: relative;
        width: 100%;
        height: 0;
        padding-bottom: 56.25%;
        background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
        overflow: hidden;
        flex-shrink: 0;
      }

      .notification-popup-media img,
      .notification-popup-media video {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        object-fit: contain;
        background: #000;
      }

      .notification-popup-default-media {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: rgba(255, 255, 255, 0.6);
      }

      .notification-popup-body {
        padding: 24px;
        text-align: center;
      }

      .notification-popup-title {
        font-size: 22px;
        font-weight: 700;
        color: #1a1a2e;
        margin: 0 0 12px;
        line-height: 1.3;
      }

      .notification-popup-text {
        font-size: 15px;
        color: #4a5568;
        line-height: 1.6;
        text-align: left;
      }

      .notification-popup-cta {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 12px 24px;
        background: linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%);
        color: #fff;
        text-decoration: none;
        border-radius: 50px;
        font-size: 15px;
        font-weight: 600;
        transition: all 0.3s ease;
        box-shadow: 0 4px 15px rgba(99, 102, 241, 0.4);
      }

      .notification-popup-cta:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 20px rgba(99, 102, 241, 0.5);
      }

      .notification-popup-nav {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 16px;
        padding: 0 24px 20px;
      }

      .popup-nav-prev,
      .popup-nav-next {
        width: 36px;
        height: 36px;
        display: flex;
        align-items: center;
        justify-content: center;
        background: #f3f4f6;
        border: none;
        border-radius: 50%;
        color: #374151;
        cursor: pointer;
        transition: all 0.2s ease;
      }

      .popup-nav-prev:hover:not(:disabled),
      .popup-nav-next:hover:not(:disabled) {
        background: #e5e7eb;
        color: #111827;
      }

      .popup-nav-prev:disabled,
      .popup-nav-next:disabled {
        opacity: 0.4;
        cursor: not-allowed;
      }

      .popup-nav-dots {
        display: flex;
        gap: 8px;
      }

      .popup-nav-dot {
        width: 8px;
        height: 8px;
        background: #d1d5db;
        border: none;
        border-radius: 50%;
        cursor: pointer;
        padding: 0;
        transition: all 0.2s ease;
      }

      .popup-nav-dot:hover {
        background: #9ca3af;
      }

      .popup-nav-dot.active {
        background: #6366f1;
        width: 24px;
        border-radius: 4px;
      }

      /* Footer with dismiss checkbox */
      .notification-popup-footer {
        padding: 14px 20px;
        background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
        border-top: 1px solid #e2e8f0;
        flex-shrink: 0;
      }

      .notification-dismiss-checkbox {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 10px;
        cursor: pointer;
        font-size: 13px;
        color: #64748b;
        padding: 10px 16px;
        background: white;
        border: 1px solid #e2e8f0;
        border-radius: 50px;
        transition: all 0.2s ease;
        margin: 0 auto;
        max-width: fit-content;
      }

      .notification-dismiss-checkbox:hover {
        border-color: #0ea5e9;
        background: #f0f9ff;
        color: #0284c7;
      }

      .notification-dismiss-checkbox:has(input:checked) {
        background: linear-gradient(135deg, #e0f2fe 0%, #bae6fd 100%);
        border-color: #38bdf8;
        color: #0369a1;
        box-shadow: 0 2px 8px rgba(14, 165, 233, 0.2);
      }

      .notification-dismiss-checkbox input[type="checkbox"] {
        position: relative;
        width: 18px;
        height: 18px;
        appearance: none;
        -webkit-appearance: none;
        background: white;
        border: 2px solid #cbd5e1;
        border-radius: 4px;
        cursor: pointer;
        transition: all 0.2s ease;
        flex-shrink: 0;
      }

      .notification-dismiss-checkbox input[type="checkbox"]:checked {
        background: #0284c7;
        border-color: #0284c7;
      }

      .notification-dismiss-checkbox input[type="checkbox"]:checked::after {
        content: '';
        position: absolute;
        top: 2px;
        left: 5px;
        width: 5px;
        height: 9px;
        border: solid white;
        border-width: 0 2px 2px 0;
        transform: rotate(45deg);
      }

      .notification-dismiss-checkbox:has(input:checked) input[type="checkbox"]::after {
        border-color: white;
      }

      .notification-dismiss-checkbox span {
        user-select: none;
        font-weight: 500;
        white-space: nowrap;
      }

      .notification-dismiss-checkbox:hover span {
      }

      .notification-dismiss-checkbox:hover span {
        color: #4b5563;
      }

      /* Formatted text styles */
      .notification-popup-text strong {
        font-weight: 600;
        color: #1a1a2e;
      }

      .notification-popup-text em {
        font-style: italic;
      }

      /* Reset margins for content elements */
      .notification-popup-text p,
      .notification-popup-text div {
        margin: 0 0 0.5em;
        text-align: inherit;
      }

      .notification-popup-text p:last-child,
      .notification-popup-text div:last-child {
        margin-bottom: 0;
      }

      .notification-popup-text br:last-child {
        display: none;
      }

      @media (max-width: 480px) {
        .homepage-notification-overlay {
          padding: 12px;
        }

        .homepage-notification-container {
          max-width: 100%;
          max-height: 90vh;
          border-radius: 16px;
        }

        .notification-popup-content {
          max-height: 90vh;
        }

        .notification-popup-body {
          padding: 20px 16px;
        }

        .notification-popup-title {
          font-size: 18px;
        }

        .notification-popup-text {
          font-size: 14px;
        }

        .notification-popup-cta {
          padding: 10px 20px;
          font-size: 14px;
        }

        .notification-popup-footer {
          padding: 10px 16px 14px;
        }

        .notification-dismiss-checkbox {
          font-size: 12px;
        }
      }

      /* Animation for content change */
      @keyframes fadeInUp {
        from {
          opacity: 0;
          transform: translateY(10px);
        }
        to {
          opacity: 1;
          transform: translateY(0);
        }
      }

      .homepage-notification-overlay.active .notification-popup-content {
        animation: fadeInUp 0.4s ease 0.1s both;
      }
    `;

    document.head.appendChild(style);
  }

  // ============================================================================
  // UTILITIES
  // ============================================================================

  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }
})();
