/**
 * Push Notification Manager - OneSignal Web SDK v16
 *
 * Modern push notification management for WordPress PWA
 * Based on official documentation: https://documentation.onesignal.com/docs/en/web-sdk-reference
 *
 * @package Checkin_MKT192
 */

(function () {
  'use strict';

  // Prevent multiple initialization
  if (window.PushNotificationManager) {
    return;
  }

  /**
   * OneSignal Web SDK v16 Push Notification Manager
   */
  class PushNotificationManager {
    // SDK URL là cố định từ CDN OneSignal, không cần config
    static SDK_URL = 'https://cdn.onesignal.com/sdks/web/v16/OneSignalSDK.page.js';

    // Lấy version từ config (checkinData.version) hoặc fallback
    static getVersion() {
      return window.checkinData?.version || window.checkinMkt192?.version || '3.0.0';
    }

    constructor(options = {}) {
      // Get WordPress REST API settings
      const wpApiSettings = window.wpApiSettings || window.checkinApiSettings || {};

      // apiBase should be the full REST URL including namespace (e.g., /wp-json/vg/v1/)
      // Remove trailing slash for consistency
      let apiBase = options.apiBase || wpApiSettings.root || '/wp-json/vg/v1';
      apiBase = apiBase.replace(/\/$/, '');

      // If apiBase doesn't include namespace, add it
      if (!apiBase.includes('/vg/v1')) {
        apiBase = apiBase + '/vg/v1';
      }

      this.options = {
        apiBase: apiBase,
        nonce: options.nonce || wpApiSettings.nonce || '',
        onStatusChange: options.onStatusChange || null,
        onSubscribe: options.onSubscribe || null,
        onUnsubscribe: options.onUnsubscribe || null,
        onError: options.onError || null,
        debug: options.debug || false,
      };

      this.appId = null;
      this.userId = null;
      this.isInitialized = false;
      this.isSupported = this._checkSupport();
      this.currentStatus = 'unknown';
      this._isSyncing = false; // Lock to prevent duplicate sync requests
      this._lastSyncTime = 0; // Track last sync time
      this._isSubscribing = false; // Lock during subscribe flow to prevent UI flicker
      this._pendingStatusUpdate = null; // Debounce status updates

      this._log('PushNotificationManager created', {
        version: PushNotificationManager.getVersion(),
      });
    }

    // =========================================================================
    // PRIVATE METHODS
    // =========================================================================

    _log(message, data = null) {
      if (this.options.debug || window.PUSH_DEBUG) {
        console.log(`[Push] ${message}`, data || '');
      }
    }

    _error(message, error = null) {
      console.error(`[Push Error] ${message}`, error || '');
      if (this.options.onError) {
        this.options.onError(error || new Error(message));
      }
    }

    _checkSupport() {
      const hasServiceWorker = 'serviceWorker' in navigator;
      const hasPushManager = 'PushManager' in window;
      const hasNotification = 'Notification' in window;

      const isSupported = hasServiceWorker && hasPushManager && hasNotification;

      this._log('Browser support check', {
        serviceWorker: hasServiceWorker,
        pushManager: hasPushManager,
        notification: hasNotification,
        isSupported,
      });

      return isSupported;
    }

    _isIOS() {
      return (
        /iPad|iPhone|iPod/.test(navigator.userAgent) ||
        (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1)
      );
    }

    _isPWA() {
      return (
        window.matchMedia('(display-mode: standalone)').matches ||
        window.navigator.standalone === true
      );
    }

    _getIOSVersion() {
      const match = navigator.userAgent.match(/OS (\d+)_(\d+)/);
      return match ? parseFloat(`${match[1]}.${match[2]}`) : 0;
    }

    _getPlatform() {
      const ua = navigator.userAgent;
      if (/android/i.test(ua)) return 'android';
      if (/iPad|iPhone|iPod/.test(ua)) return this._isPWA() ? 'ios_pwa' : 'ios';
      if (/Macintosh/.test(ua)) return 'mac';
      if (/Windows/.test(ua)) return 'windows';
      if (/Linux/.test(ua)) return 'linux';
      return 'web';
    }

    async _loadSDK() {
      if (window.OneSignal) {
        this._log('OneSignal SDK already loaded');
        return true;
      }

      return new Promise((resolve) => {
        const script = document.createElement('script');
        script.src = PushNotificationManager.SDK_URL;
        script.defer = true;
        script.onload = () => {
          this._log('OneSignal SDK loaded');
          window.OneSignalDeferred = window.OneSignalDeferred || [];
          resolve(true);
        };
        script.onerror = () => {
          this._error('Failed to load OneSignal SDK');
          resolve(false);
        };
        document.head.appendChild(script);
      });
    }

    async _waitForOneSignal(timeout = 10000) {
      const startTime = Date.now();

      while (!window.OneSignal && Date.now() - startTime < timeout) {
        await new Promise((resolve) => setTimeout(resolve, 100));
      }

      return !!window.OneSignal;
    }

    // =========================================================================
    // PUBLIC METHODS - INITIALIZATION
    // =========================================================================

    /**
     * Initialize OneSignal SDK
     * Based on: https://documentation.onesignal.com/docs/en/web-sdk-reference#init
     *
     * @param {string} appId - OneSignal App ID
     * @param {object} config - Configuration options
     * @returns {Promise<boolean>}
     */
    async init(appId, config = {}) {
      this._log('init() called', { appId, userId: config.userId });

      if (!appId) {
        this._error('App ID is required');
        return false;
      }

      if (!this.isSupported) {
        this._error('Push notifications not supported');
        return false;
      }

      this.appId = appId;
      this.userId = config.userId || null;

      try {
        // Load SDK
        const loaded = await this._loadSDK();
        if (!loaded) return false;

        // Wait for SDK ready
        await new Promise((resolve) => setTimeout(resolve, 300));

        return new Promise((resolve) => {
          window.OneSignalDeferred = window.OneSignalDeferred || [];
          window.OneSignalDeferred.push(async (OneSignal) => {
            try {
              // Initialize with options per SDK v16 documentation
              const initOptions = {
                appId: appId,
                allowLocalhostAsSecureOrigin: true,
                serviceWorkerParam: { scope: '/' },
                serviceWorkerPath: '/OneSignalSDKWorker.js',
                notifyButton: { enable: false },
                welcomeNotification: {
                  disable: false,
                  title: 'Chào mừng!',
                  message: 'Cảm ơn bạn đã đăng ký nhận thông báo.',
                },
              };

              // Add Safari Web ID if provided
              if (config.safariWebId) {
                initOptions.safari_web_id = config.safariWebId;
              }

              this._log('Calling OneSignal.init()', initOptions);
              await OneSignal.init(initOptions);
              this._log('OneSignal.init() completed');

              // Set up event listeners per SDK v16 documentation
              this._setupEventListeners(OneSignal);

              this.isInitialized = true;

              // Set External ID if user is logged in
              // Per docs: Call login() to set External ID
              if (this.userId) {
                await this._setExternalId(this.userId);
              }

              // Update status
              await this.updateStatus();

              // Sync existing subscription if already subscribed
              await this._syncExistingSubscription();

              resolve(true);
            } catch (error) {
              this._error('OneSignal init error', error);
              resolve(false);
            }
          });
        });
      } catch (error) {
        this._error('Init error', error);
        return false;
      }
    }

    _setupEventListeners(OneSignal) {
      // Permission change listener
      // https://documentation.onesignal.com/docs/en/web-sdk-reference#addeventlistener-notifications
      OneSignal.Notifications.addEventListener('permissionChange', (permission) => {
        this._log('Permission changed', permission);
        this.updateStatus();
      });

      // Push subscription change listener
      // https://documentation.onesignal.com/docs/en/web-sdk-reference#addeventlistener-push-subscription-changes
      OneSignal.User.PushSubscription.addEventListener('change', async (event) => {
        this._log('Subscription changed', {
          optedIn: event.current.optedIn,
          id: event.current.id,
          hasToken: !!event.current.token,
          isSubscribing: this._isSubscribing,
        });

        // If subscribe() is in progress, skip - it will handle everything
        if (this._isSubscribing) {
          this._log('Subscribe in progress, skipping change handler');
          return;
        }

        // When subscription changes and user is logged in, set External ID
        // Only sync if not already syncing and hasn't synced recently (5 seconds debounce)
        const now = Date.now();
        if (event.current.optedIn && event.current.id && this.userId) {
          await this._setExternalId(this.userId);

          // Debounce: only sync if last sync was more than 5 seconds ago
          if (now - this._lastSyncTime > 5000) {
            await this._syncSubscriptionWithServer(event.current.id);
          } else {
            this._log('Skipping sync - recently synced');
          }
        }

        this._debouncedUpdateStatus();
      });

      // Notification click listener
      OneSignal.Notifications.addEventListener('click', (event) => {
        this._log('Notification clicked', event);

        // Handle notification click - navigate to the URL in launchURL or data
        const notification = event.notification;
        let targetUrl = notification.launchURL;

        // Fallback to custom data URL
        if (!targetUrl && notification.data) {
          targetUrl = notification.data.url;
        }

        if (targetUrl) {
          this._log('Navigating to', targetUrl);
          window.location.href = targetUrl;
        }
      });

      // Foreground notification listener - show toast when app is open
      // iOS PWA doesn't show native notifications when app is in foreground
      OneSignal.Notifications.addEventListener('foregroundWillDisplay', (event) => {
        this._log('Foreground notification received', event.notification);

        // Show in-app notification toast
        const notification = event.notification;
        this._showInAppNotification(notification.title, notification.body, notification.launchURL);

        // Prevent default behavior (let OneSignal handle it)
        // event.preventDefault(); // Uncomment to completely suppress native notification
      });

      this._log('Event listeners set up');
    }

    /**
     * Show in-app notification when app is in foreground
     * This is especially useful for iOS PWA where notifications don't show in foreground
     */
    _showInAppNotification(title, body, url) {
      // Remove existing notification toast
      document.getElementById('push-inapp-notification')?.remove();

      const toast = document.createElement('div');
      toast.id = 'push-inapp-notification';
      toast.style.cssText = `
        position: fixed;
        top: 10px;
        left: 10px;
        right: 10px;
        padding: 14px 16px;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        font-size: 14px;
        border-radius: 12px;
        z-index: 999999;
        box-shadow: 0 8px 32px rgba(102, 126, 234, 0.4);
        cursor: pointer;
        animation: slideDown 0.3s ease-out;
      `;

      toast.innerHTML = `
        <style>
          @keyframes slideDown {
            from { transform: translateY(-100%); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
          }
        </style>
        <div style="display: flex; align-items: flex-start; gap: 12px;">
          <div style="font-size: 24px;">🔔</div>
          <div style="flex: 1; min-width: 0;">
            <div style="font-weight: 600; margin-bottom: 4px;">${title || 'Thông báo'}</div>
            <div style="opacity: 0.9; font-size: 13px; line-height: 1.4;">${body || ''}</div>
          </div>
          <div style="font-size: 18px; opacity: 0.7;" onclick="event.stopPropagation(); this.parentElement.parentElement.remove();">✕</div>
        </div>
      `;

      // Click to open URL
      if (url) {
        toast.addEventListener('click', () => {
          window.location.href = url;
        });
      }

      document.body.appendChild(toast);

      // Auto remove after 8 seconds
      setTimeout(() => toast.remove(), 8000);
    }

    async _syncExistingSubscription() {
      if (!window.OneSignal) return;

      const optedIn = window.OneSignal.User.PushSubscription.optedIn;
      const subscriptionId = window.OneSignal.User.PushSubscription.id;
      const token = window.OneSignal.User.PushSubscription.token;

      this._log('Checking existing subscription', { optedIn, subscriptionId, hasToken: !!token });

      if (optedIn && subscriptionId && token) {
        await this._syncSubscriptionWithServer(subscriptionId);
      }
    }

    // =========================================================================
    // PUBLIC METHODS - EXTERNAL ID
    // =========================================================================

    /**
     * Set External User ID
     * Per SDK v16 docs: Use login() to set External ID
     * https://documentation.onesignal.com/docs/en/web-sdk-reference#loginexternal_id
     *
     * @param {string|number} userId
     * @returns {Promise<boolean>}
     */
    async _setExternalId(userId) {
      if (!window.OneSignal || !window.OneSignal.login) {
        this._log('OneSignal.login not available');
        return false;
      }

      try {
        const externalId = String(userId);
        this._log('Setting External ID via login()', externalId);

        await window.OneSignal.login(externalId);

        // Wait for OneSignal to process
        await new Promise((resolve) => setTimeout(resolve, 1000));

        const currentExternalId = window.OneSignal.User?.externalId;
        this._log('External ID result', { expected: externalId, current: currentExternalId });

        return currentExternalId === externalId;
      } catch (error) {
        this._error('Failed to set External ID', error);
        return false;
      }
    }

    /**
     * Get current External ID
     */
    getExternalId() {
      return window.OneSignal?.User?.externalId || null;
    }

    /**
     * Logout - remove External ID
     * https://documentation.onesignal.com/docs/en/web-sdk-reference#logout
     */
    async logout() {
      if (!window.OneSignal || !window.OneSignal.logout) {
        return false;
      }

      try {
        await window.OneSignal.logout();
        this._log('Logged out');
        return true;
      } catch (error) {
        this._error('Logout error', error);
        return false;
      }
    }

    // =========================================================================
    // PUBLIC METHODS - SUBSCRIPTION
    // =========================================================================

    /**
     * Subscribe to push notifications
     * https://documentation.onesignal.com/docs/en/web-sdk-reference#optout-optin-optedin
     *
     * @returns {Promise<boolean>}
     */
    async subscribe() {
      this._log('subscribe() called');

      if (!this.isInitialized) {
        this._error('Not initialized');
        return false;
      }

      // Set lock to prevent event listener from interfering
      this._isSubscribing = true;

      try {
        // Per docs: Call login() before optIn() to ensure External ID is set
        if (this.userId) {
          await this._setExternalId(this.userId);
        }

        // Request permission and subscribe
        // https://documentation.onesignal.com/docs/en/web-sdk-reference#optout-optin-optedin
        this._log('Calling optIn()...');
        await window.OneSignal.User.PushSubscription.optIn();
        this._log('optIn() completed');

        // Wait for subscription to be processed
        await new Promise((resolve) => setTimeout(resolve, 1500));

        const isSubscribed = await this.isSubscribed();
        this._log('Subscription result', { isSubscribed });

        if (isSubscribed) {
          const subscriptionId = this.getSubscriptionId();

          if (subscriptionId) {
            // Sync with server
            await this._syncSubscriptionWithServer(subscriptionId);

            if (this.options.onSubscribe) {
              this.options.onSubscribe(subscriptionId);
            }
          }
        }

        // Release lock before final status update
        this._isSubscribing = false;
        await this.updateStatus();
        return isSubscribed;
      } catch (error) {
        this._isSubscribing = false;
        this._error('Subscribe error', error);
        return false;
      }
    }

    /**
     * Unsubscribe from push notifications
     * https://documentation.onesignal.com/docs/en/web-sdk-reference#optout-optin-optedin
     *
     * @returns {Promise<boolean>}
     */
    async unsubscribe() {
      this._log('unsubscribe() called');

      if (!this.isInitialized) {
        return false;
      }

      try {
        const subscriptionId = this.getSubscriptionId();

        await window.OneSignal.User.PushSubscription.optOut();
        this._log('optOut() completed');

        if (subscriptionId) {
          await this._removeSubscriptionFromServer(subscriptionId);
        }

        if (this.options.onUnsubscribe) {
          this.options.onUnsubscribe();
        }

        await this.updateStatus();
        return true;
      } catch (error) {
        this._error('Unsubscribe error', error);
        return false;
      }
    }

    /**
     * Toggle subscription state
     */
    async toggle() {
      if (await this.isSubscribed()) {
        return await this.unsubscribe();
      } else {
        return await this.subscribe();
      }
    }

    /**
     * Check if user is subscribed
     */
    async isSubscribed() {
      if (!window.OneSignal?.User?.PushSubscription) {
        return false;
      }

      const optedIn = window.OneSignal.User.PushSubscription.optedIn;
      const hasId = !!window.OneSignal.User.PushSubscription.id;

      return optedIn === true && hasId;
    }

    /**
     * Get current subscription ID
     * https://documentation.onesignal.com/docs/en/web-sdk-reference#userpushsubscriptionid
     */
    getSubscriptionId() {
      return window.OneSignal?.User?.PushSubscription?.id || null;
    }

    /**
     * Get OneSignal User ID
     * https://documentation.onesignal.com/docs/en/web-sdk-reference#onesignaluseronesignalid
     */
    getOneSignalId() {
      return window.OneSignal?.User?.onesignalId || null;
    }

    // =========================================================================
    // PUBLIC METHODS - PERMISSION
    // =========================================================================

    /**
     * Get current permission status
     * https://documentation.onesignal.com/docs/en/web-sdk-reference#onesignalnotificationspermission
     */
    getPermission() {
      if (window.OneSignal?.Notifications?.permission) {
        return 'granted';
      }
      return Notification.permission || 'default';
    }

    /**
     * Check if we can show permission prompt
     */
    canShowPrompt() {
      return this.getPermission() === 'default';
    }

    /**
     * Request notification permission
     * https://documentation.onesignal.com/docs/en/web-sdk-reference#requestpermission
     */
    async requestPermission() {
      if (!window.OneSignal?.Notifications?.requestPermission) {
        return false;
      }

      try {
        await window.OneSignal.Notifications.requestPermission();
        return this.getPermission() === 'granted';
      } catch (error) {
        this._error('Request permission error', error);
        return false;
      }
    }

    // =========================================================================
    // PUBLIC METHODS - STATUS
    // =========================================================================

    /**
     * Debounced status update to prevent UI flicker
     */
    _debouncedUpdateStatus() {
      if (this._pendingStatusUpdate) {
        clearTimeout(this._pendingStatusUpdate);
      }
      this._pendingStatusUpdate = setTimeout(() => {
        this._pendingStatusUpdate = null;
        this.updateStatus();
      }, 300);
    }

    /**
     * Update current status
     */
    async updateStatus() {
      // Skip if subscribe is in progress (let subscribe() handle final update)
      if (this._isSubscribing) {
        this._log('Status update skipped - subscribe in progress');
        return this.currentStatus;
      }

      if (!this.isInitialized) {
        this.currentStatus = 'not-initialized';
        return this.currentStatus;
      }

      const permission = this.getPermission();
      const isSubscribed = await this.isSubscribed();

      const newStatus =
        permission === 'denied'
          ? 'denied'
          : isSubscribed
          ? 'subscribed'
          : permission === 'default'
          ? 'not-asked'
          : 'unsubscribed';

      // Only trigger callback if status actually changed
      const statusChanged = this.currentStatus !== newStatus;
      this.currentStatus = newStatus;

      this._log('Status updated', {
        status: this.currentStatus,
        permission,
        isSubscribed,
        statusChanged,
      });

      if (statusChanged && this.options.onStatusChange) {
        this.options.onStatusChange(this.currentStatus, {
          permission,
          isSubscribed,
          subscriptionId: this.getSubscriptionId(),
          externalId: this.getExternalId(),
        });
      }

      return this.currentStatus;
    }

    /**
     * Get current status
     */
    getStatus() {
      return this.currentStatus;
    }

    /**
     * Get status text for display
     */
    getStatusText(lang = 'vi') {
      const texts = {
        vi: {
          subscribed: 'Đã bật thông báo',
          unsubscribed: 'Đã tắt thông báo',
          denied: 'Thông báo bị chặn',
          'not-asked': 'Chưa cấp quyền',
          'not-initialized': 'Chưa khởi tạo',
          unknown: 'Không xác định',
        },
        en: {
          subscribed: 'Notifications enabled',
          unsubscribed: 'Notifications disabled',
          denied: 'Notifications blocked',
          'not-asked': 'Permission not granted',
          'not-initialized': 'Not initialized',
          unknown: 'Unknown',
        },
      };

      const langTexts = texts[lang] || texts.en;
      return langTexts[this.currentStatus] || langTexts.unknown;
    }

    // =========================================================================
    // PUBLIC METHODS - TAGS
    // =========================================================================

    /**
     * Add tags to user
     * https://documentation.onesignal.com/docs/en/web-sdk-reference#addtag-addtags
     */
    async addTags(tags) {
      if (!window.OneSignal?.User?.addTags) {
        return false;
      }

      try {
        await window.OneSignal.User.addTags(tags);
        this._log('Tags added', tags);
        return true;
      } catch (error) {
        this._error('Add tags error', error);
        return false;
      }
    }

    /**
     * Remove tags from user
     * https://documentation.onesignal.com/docs/en/web-sdk-reference#removetag-removetags
     */
    async removeTags(tagKeys) {
      if (!window.OneSignal?.User?.removeTags) {
        return false;
      }

      try {
        await window.OneSignal.User.removeTags(tagKeys);
        this._log('Tags removed', tagKeys);
        return true;
      } catch (error) {
        this._error('Remove tags error', error);
        return false;
      }
    }

    /**
     * Get user tags
     * https://documentation.onesignal.com/docs/en/web-sdk-reference#gettags
     */
    getTags() {
      return window.OneSignal?.User?.getTags?.() || {};
    }

    // =========================================================================
    // PUBLIC METHODS - SLIDEDOWN PROMPTS
    // =========================================================================

    /**
     * Show push slidedown prompt
     * https://documentation.onesignal.com/docs/en/web-sdk-reference#promptpush
     */
    async promptPush(options = {}) {
      if (!window.OneSignal?.Slidedown?.promptPush) {
        return false;
      }

      try {
        await window.OneSignal.Slidedown.promptPush(options);
        return true;
      } catch (error) {
        this._error('Prompt push error', error);
        return false;
      }
    }

    // =========================================================================
    // SERVER SYNC
    // =========================================================================

    async _syncSubscriptionWithServer(subscriptionId) {
      // Prevent duplicate sync requests
      if (this._isSyncing) {
        this._log('Sync already in progress, skipping');
        return false;
      }

      this._isSyncing = true;
      this._lastSyncTime = Date.now();

      this._log('Syncing with server', { subscriptionId, userId: this.userId });

      // Build URL
      const syncUrl = `${this.options.apiBase}/push/subscribe`;

      if (!subscriptionId || !this.userId) {
        this._log('Missing data for sync', { subscriptionId, userId: this.userId });
        this._isSyncing = false;
        return false;
      }

      try {
        const headers = { 'Content-Type': 'application/json' };

        // Add WordPress nonce if available
        if (this.options.nonce) {
          headers['X-WP-Nonce'] = this.options.nonce;
        }

        const payload = {
          subscription_id: subscriptionId,
          onesignal_id: this.getOneSignalId(),
          external_id: this.getExternalId(),
          user_id: this.userId,
          platform: this._getPlatform(),
        };

        this._log('Sync request', { url: syncUrl, payload });

        const response = await fetch(syncUrl, {
          method: 'POST',
          headers: headers,
          credentials: 'include',
          body: JSON.stringify(payload),
        });

        // Log response status
        this._log('Sync response status', { status: response.status, ok: response.ok });

        const responseText = await response.text();
        let data;
        try {
          data = JSON.parse(responseText);
        } catch (e) {
          this._error('Invalid JSON response', responseText.substring(0, 100));
          this._isSyncing = false;
          return false;
        }

        if (!response.ok) {
          this._error('Sync failed', { status: response.status, message: data.message });
          this._isSyncing = false;
          return false;
        }

        this._log('Sync response data', data);

        if (data.success) {
          localStorage.setItem('push_last_sync', Date.now().toString());
          localStorage.setItem('push_subscription_id', subscriptionId);
          this._log('Subscription saved to DB', { user_id: data.user_id });
          this._isSyncing = false;
          return true;
        } else {
          this._error('Sync API returned false', data.message);
        }

        this._isSyncing = false;
        return false;
      } catch (error) {
        this._error('Sync exception', error.message);
        this._isSyncing = false;
        return false;
      }
    }

    /**
     * Send test notification to current user
     * @returns {Promise<object>} Result with success and message
     */
    async sendTestNotification() {
      this._log('Sending test notification');

      try {
        const headers = { 'Content-Type': 'application/json' };

        // Add WordPress nonce if available
        if (this.options.nonce) {
          headers['X-WP-Nonce'] = this.options.nonce;
        }

        const response = await fetch(`${this.options.apiBase}/push/test`, {
          method: 'POST',
          headers: headers,
          credentials: 'include',
        });

        const data = await response.json();
        this._log('Test notification response', data);

        return data;
      } catch (error) {
        this._error('Send test notification error', error);
        return { success: false, message: error.message };
      }
    }

    async _removeSubscriptionFromServer(subscriptionId) {
      this._log('Removing from server', { subscriptionId });

      try {
        const response = await fetch(`${this.options.apiBase}/push/unsubscribe`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'include',
          body: JSON.stringify({
            subscription_id: subscriptionId,
          }),
        });

        const data = await response.json();
        this._log('Remove response', data);
        return data.success;
      } catch (error) {
        this._error('Remove error', error);
        return false;
      }
    }

    // =========================================================================
    // DEBUG
    // =========================================================================

    /**
     * Get debug info
     */
    async getDebugInfo() {
      return {
        version: PushNotificationManager.getVersion(),
        isSupported: this.isSupported,
        isInitialized: this.isInitialized,
        currentStatus: this.currentStatus,
        appId: this.appId,
        userId: this.userId,
        permission: this.getPermission(),
        isSubscribed: await this.isSubscribed(),
        subscriptionId: this.getSubscriptionId(),
        onesignalId: this.getOneSignalId(),
        externalId: this.getExternalId(),
        platform: this._getPlatform(),
        isIOS: this._isIOS(),
        isPWA: this._isPWA(),
        iosVersion: this._getIOSVersion(),
        lastSync: localStorage.getItem('push_last_sync'),
      };
    }

    /**
     * Enable debug logging
     */
    enableDebug() {
      this.options.debug = true;
      if (window.OneSignal?.Debug?.setLogLevel) {
        window.OneSignal.Debug.setLogLevel('trace');
      }
    }

    /**
     * Disable debug logging
     */
    disableDebug() {
      this.options.debug = false;
      if (window.OneSignal?.Debug?.setLogLevel) {
        window.OneSignal.Debug.setLogLevel('error');
      }
    }
  }

  // Export to window
  window.PushNotificationManager = PushNotificationManager;

  // =========================================================================
  // AUTO INITIALIZATION
  // =========================================================================

  document.addEventListener('DOMContentLoaded', async function () {
    // Skip if auto-init is disabled
    if (window.PUSH_MANAGER_NO_AUTO_INIT) {
      return;
    }

    // Get config from WordPress
    const globalConfig = window.checkinData || window.checkinMkt192;

    if (!globalConfig?.push?.appId) {
      console.log('[Push] No push config found, skipping auto-init');
      return;
    }

    const config = globalConfig.push;

    // restUrl from checkinData already includes /vg/v1/ so use it directly
    // Remove trailing slash for consistency
    let apiBase = config.apiBase || globalConfig.restUrl || '/wp-json/vg/v1';
    apiBase = apiBase.replace(/\/$/, '');

    // Log config for debugging
    console.log('[Push] Config:', {
      apiBase,
      'config.apiBase': config.apiBase,
      'globalConfig.restUrl': globalConfig.restUrl,
      userId: config.userId,
      nonce: config.nonce ? 'YES' : 'NO',
    });

    // Create instance with proper API settings
    window.pushManager = new PushNotificationManager({
      apiBase: apiBase,
      nonce: config.nonce || globalConfig.nonce || '',
      debug: config.debug || false,
      onStatusChange: function (status, info) {
        document.dispatchEvent(
          new CustomEvent('pushStatusChange', {
            detail: { status, info },
          })
        );
      },
      onSubscribe: function (subscriptionId) {
        document.dispatchEvent(
          new CustomEvent('pushSubscribed', {
            detail: { subscriptionId },
          })
        );
      },
      onUnsubscribe: function () {
        document.dispatchEvent(new CustomEvent('pushUnsubscribed'));
      },
      onError: function (error) {
        document.dispatchEvent(
          new CustomEvent('pushError', {
            detail: { error },
          })
        );
      },
    });

    // Get user ID
    const userId = config.userId || globalConfig.userId || globalConfig.currentUser?.id || null;

    // Initialize
    const initialized = await window.pushManager.init(config.appId, {
      safariWebId: config.safariWebId || config.safari_web_id || null,
      userId: userId,
    });

    if (initialized) {
      console.log('[Push] Initialized successfully');

      // Set tags if provided
      if (config.tags) {
        await window.pushManager.addTags(config.tags);
      }
    } else {
      console.warn('[Push] Initialization failed');
    }
  });
})();
