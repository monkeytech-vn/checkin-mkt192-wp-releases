/**
 * Account Linking Module - Liên kết tài khoản mạng xã hội mới với tài khoản hiện có
 *
 * Use case: User mất tài khoản Google/Facebook cũ, tạo tài khoản mới
 * và muốn liên kết với tài khoản WordPress + Staff hiện tại
 *
 * @package Checkin_MKT192_WP
 * @since 5.3.1
 */

(function () {
  'use strict';

  // ============================================
  // Configuration & State
  // ============================================
  const AccountLinking = {
    isOpen: false,
    provider: 'google',
    newEmail: '',
    onSuccess: null,
    onSkip: null,

    // SVG Icons (inline để tránh phụ thuộc thêm)
    icons: {
      close: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>`,
      info: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>`,
      user: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>`,
      id: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="16" rx="2"></rect><line x1="7" y1="8" x2="17" y2="8"></line><line x1="7" y1="12" x2="13" y2="12"></line></svg>`,
      calendar: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>`,
      check: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>`,
      alert: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>`,
      google: `<svg viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>`,
      facebook: `<svg viewBox="0 0 24 24" fill="#1877F2"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>`,
    },

    // ============================================
    // Initialize
    // ============================================
    init() {
      this.injectStyles();
      this.createModal();
      this.bindEvents();
    },

    // ============================================
    // Inject CSS if not loaded
    // ============================================
    injectStyles() {
      if (document.getElementById('account-linking-styles')) return;

      // Check if CSS is already loaded via PHP
      const existingLink = document.querySelector('link[href*="account-linking.css"]');
      if (existingLink) return;

      // Load CSS dynamically
      const link = document.createElement('link');
      link.id = 'account-linking-styles';
      link.rel = 'stylesheet';
      link.href =
        (window.checkinData?.pluginUrl || '') +
        'frontend/assets/css/components/account-linking.css';
      document.head.appendChild(link);
    },

    // ============================================
    // Create Modal HTML
    // ============================================
    createModal() {
      if (document.getElementById('account-linking-overlay')) return;

      const modal = document.createElement('div');
      modal.id = 'account-linking-overlay';
      modal.className = 'account-linking-overlay';
      modal.innerHTML = this.getModalHTML();

      document.body.appendChild(modal);
    },

    getModalHTML() {
      return `
        <div class="account-linking-modal" role="dialog" aria-modal="true" aria-labelledby="account-linking-title">
          <!-- Header -->
          <div class="account-linking-header">
            <div class="account-linking-header-content">
              <div class="account-linking-icon" id="account-linking-provider-icon">
                ${this.icons.google}
              </div>
              <h2 class="account-linking-title" id="account-linking-title">Liên kết tài khoản</h2>
            </div>
            <button class="account-linking-close" id="account-linking-close" aria-label="Đóng">
              ${this.icons.close}
            </button>
          </div>

          <!-- Body -->
          <div class="account-linking-body">
            <!-- Steps Indicator -->
            <div class="account-linking-steps">
              <div class="account-linking-step active" data-step="1">
                <span class="account-linking-step-number">1</span>
                <span class="account-linking-step-label">Nhập thông tin</span>
              </div>
              <div class="account-linking-step-connector"></div>
              <div class="account-linking-step" data-step="2">
                <span class="account-linking-step-number">2</span>
                <span class="account-linking-step-label">Hoàn tất</span>
              </div>
            </div>

            <!-- Form Content -->
            <div id="account-linking-form-content">
              <!-- Info Banner -->
              <div class="account-linking-info">
                <div class="account-linking-info-icon">
                  ${this.icons.info}
                </div>
                <div class="account-linking-info-text">
                  <strong>Bạn đã có tài khoản?</strong><br>
                  Nhập thông tin tài khoản cũ để liên kết với tài khoản <span id="account-linking-provider-name">Google</span> mới.
                </div>
              </div>

              <!-- Error Alert -->
              <div class="account-linking-alert error" id="account-linking-error" style="display: none;">
                <div class="account-linking-alert-icon">
                  ${this.icons.alert}
                </div>
                <div class="account-linking-alert-content">
                  <p class="account-linking-alert-title">Xác minh thất bại</p>
                  <p class="account-linking-alert-message" id="account-linking-error-message"></p>
                </div>
              </div>

              <!-- Username Field -->
              <div class="account-linking-form-group">
                <label class="account-linking-label" for="account-linking-username">
                  Tên đăng nhập <span class="required">*</span>
                </label>
                <div class="account-linking-input-wrapper">
                  <div class="account-linking-input-icon">
                    ${this.icons.user}
                  </div>
                  <input
                    type="text"
                    id="account-linking-username"
                    class="account-linking-input"
                    placeholder="Nhập username tài khoản cũ"
                    autocomplete="username"
                    required
                  />
                </div>
                <p class="account-linking-helper">Username bạn dùng để đăng nhập trước đây</p>
              </div>

              <!-- Divider -->
              <div class="account-linking-divider">
                <div class="account-linking-divider-line"></div>
                <span class="account-linking-divider-text">Xác minh bằng 1 trong 2</span>
                <div class="account-linking-divider-line"></div>
              </div>

              <!-- Employee ID Field -->
              <div class="account-linking-form-group">
                <label class="account-linking-label" for="account-linking-employee-id">
                  Mã nhân viên
                </label>
                <div class="account-linking-input-wrapper">
                  <div class="account-linking-input-icon">
                    ${this.icons.id}
                  </div>
                  <input
                    type="text"
                    id="account-linking-employee-id"
                    class="account-linking-input"
                    placeholder="VD: NV001"
                    autocomplete="off"
                  />
                </div>
              </div>

              <!-- Birthday Field -->
              <div class="account-linking-form-group">
                <label class="account-linking-label" for="account-linking-birthday">
                  Hoặc ngày sinh
                </label>
                <div class="account-linking-input-wrapper">
                  <div class="account-linking-input-icon">
                    ${this.icons.calendar}
                  </div>
                  <input
                    type="date"
                    id="account-linking-birthday"
                    class="account-linking-input"
                    placeholder="DD/MM/YYYY"
                  />
                </div>
              </div>

              <!-- Update Primary Email Option -->
              <div class="account-linking-form-group account-linking-checkbox-group">
                <label class="account-linking-checkbox-label">
                  <input
                    type="checkbox"
                    id="account-linking-update-email"
                    class="account-linking-checkbox"
                    checked
                  />
                  <span class="account-linking-checkbox-custom"></span>
                  <span class="account-linking-checkbox-text">
                    Đặt email mới làm email chính
                    <span class="account-linking-checkbox-hint">(Khuyến nghị)</span>
                  </span>
                </label>
              </div>

              <!-- Skip Option -->
              <div class="account-linking-skip">
                <span class="account-linking-skip-text">
                  Chưa có tài khoản?
                  <a class="account-linking-skip-link" id="account-linking-skip">
                    Tạo tài khoản mới
                  </a>
                </span>
              </div>
            </div>

            <!-- Success Content -->
            <div id="account-linking-success-content" style="display: none;">
              <div class="account-linking-success">
                <div class="account-linking-success-icon">
                  ${this.icons.check}
                </div>
                <h3 class="account-linking-success-title">Liên kết thành công!</h3>
                <p class="account-linking-success-message">
                  Tài khoản <span id="account-linking-provider-success">Google</span> mới đã được liên kết.
                  Lần sau bạn có thể đăng nhập trực tiếp mà không cần xác minh lại.
                </p>
              </div>
            </div>
          </div>

          <!-- Footer -->
          <div class="account-linking-footer" id="account-linking-footer">
            <div class="account-linking-footer-actions">
              <button type="button" class="account-linking-btn account-linking-btn-secondary" id="account-linking-cancel">
                Hủy
              </button>
              <button type="button" class="account-linking-btn account-linking-btn-primary" id="account-linking-submit">
                <span id="account-linking-submit-text">Xác minh & Liên kết</span>
                <div class="account-linking-spinner" id="account-linking-spinner" style="display: none;"></div>
              </button>
            </div>
          </div>
        </div>
      `;
    },

    // ============================================
    // Bind Events
    // ============================================
    bindEvents() {
      const overlay = document.getElementById('account-linking-overlay');
      if (!overlay) return;

      // Close button
      document
        .getElementById('account-linking-close')
        ?.addEventListener('click', () => this.close());

      // Cancel button
      document
        .getElementById('account-linking-cancel')
        ?.addEventListener('click', () => this.close());

      // Submit button
      document
        .getElementById('account-linking-submit')
        ?.addEventListener('click', () => this.submit());

      // Skip link
      document.getElementById('account-linking-skip')?.addEventListener('click', (e) => {
        e.preventDefault();
        this.skip();
      });

      // Close on overlay click
      overlay.addEventListener('click', (e) => {
        if (e.target === overlay) this.close();
      });

      // Close on Escape key
      document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && this.isOpen) this.close();
      });

      // Enter key to submit
      const inputs = overlay.querySelectorAll('.account-linking-input');
      inputs.forEach((input) => {
        input.addEventListener('keydown', (e) => {
          if (e.key === 'Enter') this.submit();
        });

        // Clear error on input
        input.addEventListener('input', () => {
          input.classList.remove('error');
          this.hideError();
        });
      });
    },

    // ============================================
    // Open Modal
    // ============================================
    open(options = {}) {
      this.provider = options.provider || 'google';
      this.newEmail = options.newEmail || '';
      this.onSuccess = options.onSuccess || null;
      this.onSkip = options.onSkip || null;

      // Update provider UI
      this.updateProviderUI();

      // Reset form
      this.resetForm();

      // Show modal
      const overlay = document.getElementById('account-linking-overlay');
      if (overlay) {
        overlay.classList.add('active');
        this.isOpen = true;
        document.body.style.overflow = 'hidden';

        // Focus first input
        setTimeout(() => {
          document.getElementById('account-linking-username')?.focus();
        }, 300);
      }
    },

    // ============================================
    // Close Modal
    // ============================================
    close() {
      const overlay = document.getElementById('account-linking-overlay');
      if (overlay) {
        overlay.classList.remove('active');
        this.isOpen = false;
        document.body.style.overflow = '';
      }
    },

    // ============================================
    // Update Provider UI
    // ============================================
    updateProviderUI() {
      const providerIcon = document.getElementById('account-linking-provider-icon');
      const providerName = document.getElementById('account-linking-provider-name');
      const providerSuccess = document.getElementById('account-linking-provider-success');

      const providerDisplay = this.provider.charAt(0).toUpperCase() + this.provider.slice(1);

      if (providerIcon) {
        providerIcon.className = `account-linking-icon ${this.provider}`;
        providerIcon.innerHTML = this.icons[this.provider] || this.icons.google;
      }

      if (providerName) {
        providerName.textContent = providerDisplay;
      }

      if (providerSuccess) {
        providerSuccess.textContent = providerDisplay;
      }
    },

    // ============================================
    // Reset Form
    // ============================================
    resetForm() {
      // Clear inputs
      document.getElementById('account-linking-username').value = '';
      document.getElementById('account-linking-employee-id').value = '';
      document.getElementById('account-linking-birthday').value = '';

      // Hide error
      this.hideError();

      // Reset steps
      this.setStep(1);

      // Show form, hide success
      document.getElementById('account-linking-form-content').style.display = 'block';
      document.getElementById('account-linking-success-content').style.display = 'none';
      document.getElementById('account-linking-footer').style.display = 'block';

      // Reset button
      this.setLoading(false);
    },

    // ============================================
    // Set Step
    // ============================================
    setStep(step) {
      const steps = document.querySelectorAll('.account-linking-step');
      const connector = document.querySelector('.account-linking-step-connector');

      steps.forEach((el, index) => {
        el.classList.remove('active', 'completed');
        if (index + 1 < step) {
          el.classList.add('completed');
        } else if (index + 1 === step) {
          el.classList.add('active');
        }
      });

      if (connector) {
        connector.classList.toggle('completed', step > 1);
      }
    },

    // ============================================
    // Validate Form
    // ============================================
    validate() {
      const username = document.getElementById('account-linking-username').value.trim();
      const employeeId = document.getElementById('account-linking-employee-id').value.trim();
      const birthday = document.getElementById('account-linking-birthday').value.trim();

      // Username required
      if (!username) {
        this.showError('Vui lòng nhập tên đăng nhập.');
        document.getElementById('account-linking-username').classList.add('error');
        document.getElementById('account-linking-username').focus();
        return false;
      }

      // Need at least one verification method
      if (!employeeId && !birthday) {
        this.showError('Vui lòng nhập mã nhân viên hoặc ngày sinh để xác minh.');
        return false;
      }

      return true;
    },

    // ============================================
    // Submit Form
    // ============================================
    async submit() {
      if (!this.validate()) return;

      const username = document.getElementById('account-linking-username').value.trim();
      const employeeId = document.getElementById('account-linking-employee-id').value.trim();
      const birthday = document.getElementById('account-linking-birthday').value.trim();
      const updateEmail = document.getElementById('account-linking-update-email')?.checked ?? true;

      this.setLoading(true);
      this.hideError();

      try {
        const response = await fetch(
          `${window.checkinData?.restUrl || '/wp-json/vg/v1/'}account-linking/verify`,
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'X-WP-Nonce': window.checkinData?.nonce || '',
            },
            credentials: 'include',
            body: JSON.stringify({
              username: username,
              employee_id: employeeId,
              birthday: birthday,
              new_email: this.newEmail,
              provider: this.provider,
              remember: true,
              update_primary_email: updateEmail,
            }),
          }
        );

        const result = await response.json();

        if (result.success) {
          // Update nonce
          if (result.nonce && window.checkinData) {
            window.checkinData.nonce = result.nonce;
          }

          // Show success
          this.showSuccess(result);

          // Callback
          if (typeof this.onSuccess === 'function') {
            setTimeout(() => {
              this.onSuccess(result);
              this.close();
            }, 2000);
          }
        } else {
          this.showError(result.message || 'Xác minh thất bại. Vui lòng kiểm tra lại thông tin.');
        }
      } catch (error) {
        console.error('Account linking error:', error);
        this.showError('Có lỗi xảy ra. Vui lòng thử lại sau.');
      } finally {
        this.setLoading(false);
      }
    },

    // ============================================
    // Skip - Create new account
    // ============================================
    skip() {
      if (typeof this.onSkip === 'function') {
        this.onSkip();
      }
      this.close();
    },

    // ============================================
    // Show Success
    // ============================================
    showSuccess(result) {
      // Update step
      this.setStep(2);

      // Hide form, show success
      document.getElementById('account-linking-form-content').style.display = 'none';
      document.getElementById('account-linking-success-content').style.display = 'block';
      document.getElementById('account-linking-footer').style.display = 'none';
    },

    // ============================================
    // Show/Hide Error
    // ============================================
    showError(message) {
      const errorEl = document.getElementById('account-linking-error');
      const messageEl = document.getElementById('account-linking-error-message');

      if (errorEl && messageEl) {
        messageEl.textContent = message;
        errorEl.style.display = 'flex';

        // Scroll to error
        errorEl.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }
    },

    hideError() {
      const errorEl = document.getElementById('account-linking-error');
      if (errorEl) {
        errorEl.style.display = 'none';
      }
    },

    // ============================================
    // Set Loading State
    // ============================================
    setLoading(loading) {
      const submitBtn = document.getElementById('account-linking-submit');
      const submitText = document.getElementById('account-linking-submit-text');
      const spinner = document.getElementById('account-linking-spinner');
      const cancelBtn = document.getElementById('account-linking-cancel');

      if (loading) {
        submitBtn?.setAttribute('disabled', 'true');
        cancelBtn?.setAttribute('disabled', 'true');
        if (submitText) submitText.style.display = 'none';
        if (spinner) spinner.style.display = 'block';
      } else {
        submitBtn?.removeAttribute('disabled');
        cancelBtn?.removeAttribute('disabled');
        if (submitText) submitText.style.display = 'inline';
        if (spinner) spinner.style.display = 'none';
      }
    },
  };

  // ============================================
  // Initialize on DOM ready
  // ============================================
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => AccountLinking.init());
  } else {
    AccountLinking.init();
  }

  // ============================================
  // Expose to global scope
  // ============================================
  window.AccountLinking = AccountLinking;
})();
