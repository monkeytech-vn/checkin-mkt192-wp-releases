let currentUserRole = null;
let currentUserDisplayName = null;

async function getCurrentUserRole() {
  try {
    // Kiểm tra nếu chưa login
    if (!checkinData.currentUser?.is_logged_in) {
      return 'unauthorized'; // Báo hiệu chưa đăng nhập
    }

    const response = await fetch(`${checkinData.restUrl}staff`, {
      method: 'GET',
      headers: {
        'X-WP-Nonce': checkinData.nonce,
      },
    });

    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }

    const staffData = await response.json();
    if (!staffData.success || !staffData.data) {
      throw new Error(staffData.message || 'Không tìm thấy dữ liệu nhân viên');
    }

    const currentUser = checkinData.currentUser;
    const staff = staffData.data.find((s) => s.display_name === currentUser.display_name);

    currentUserRole = staff?.user_role || 'Unknown';
    currentUserDisplayName = staff?.display_name || 'Unknown';
    return currentUserRole;
  } catch (error) {
    console.error('Lỗi khi lấy user_role:', error);

    // Nếu currentUser không tồn tại thì redirect
    if (!checkinData.currentUser || !checkinData.currentUser.display_name) {
      window.location.href = '/diem-danh';
      return;
    }

    currentUserRole = checkinData.currentUser.user_role || 'Unknown';
    currentUserDisplayName = checkinData.currentUser.display_name || 'Unknown';
    return currentUserRole;
  }
}

/* ============================================================
   PHIẾU LƯƠNG — helpers dùng chung cho card thợ & thu ngân (ps-*)
   ============================================================ */
const psEsc = (v) =>
  String(v ?? '').replace(
    /[&<>"']/g,
    (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]
  );
const psNum = (v) => {
  const n = parseFloat(v);
  return Number.isFinite(n) ? n : 0;
};
const psMoney = (v) => Math.round(psNum(v)).toLocaleString('vi-VN') + ' đ';
const psPct = (v) => psNum(v).toLocaleString('vi-VN', { maximumFractionDigits: 2 }) + '%';
const psQty = (v, digits = 2) =>
  psNum(v).toLocaleString('vi-VN', { maximumFractionDigits: digits });
const psDate = (d) => (d ? new Date(d).toLocaleDateString('vi-VN') : '—');
const psPeriodLabel = (period) =>
  period && period.includes('-') ? `Tháng ${period.split('-')[1]}/${period.split('-')[0]}` : 'Kỳ —';
const psInitials = (name) =>
  String(name || '?')
    .trim()
    .split(/\s+/)
    .slice(-2)
    .map((w) => w[0] || '')
    .join('')
    .toUpperCase();

// Tỷ lệ hiệu lực: ưu tiên API trả về; thiếu thì suy từ số tiền / doanh số; cuối cùng dùng fallback.
const psRate = (apiValue, amount, base, fallback = 0) => {
  if (apiValue !== undefined && apiValue !== null && apiValue !== '') return psNum(apiValue);
  const b = psNum(base);
  if (b > 0) return Math.round((psNum(amount) / b) * 10000) / 100;
  return psNum(fallback);
};

// Trạng thái phiếu → badge (không còn là nút).
const psStatus = (s, isPersonalPage = false) => {
  const agreed = s.xac_nhan_luong === 'Đồng ý';
  const reviewing = s.xac_nhan_luong === 'Xin xét lại';
  const paid = !!s.payment;
  const received = s.status === 'received' || s.xac_nhan_thanh_toan === 'Đã nhận đủ';
  if (received) return { cls: 'done', text: 'Đã nhận đủ' };
  if (s.status === 'disputed') return { cls: 'warn', text: 'Chưa nhận được' };
  if (paid) return { cls: 'paid', text: 'Đã thanh toán' };
  if (reviewing) return { cls: 'warn', text: 'Xin xét lại' };
  if (agreed) return { cls: 'ok', text: isPersonalPage ? 'Chờ thanh toán' : 'Đã xác nhận' };
  return { cls: 'pending', text: 'Chờ xác nhận' };
};

// Nút nào được hiện — chỉ hiện thao tác đúng thời điểm, còn lại ẩn.
const psActions = (s, isPersonalPage) => {
  const agreed = s.xac_nhan_luong === 'Đồng ý';
  const paid = !!s.payment;
  const received = s.status === 'received' || s.xac_nhan_thanh_toan === 'Đã nhận đủ';
  if (isPersonalPage) {
    return {
      history: true,
      avg: false,
      refresh: false,
      kpi: false,
      upload: false,
      confirm: !agreed && !received, // chưa đồng ý (kể cả đang xin xét lại) → còn được Đồng ý
      review: !s.xac_nhan_luong && !received, // chỉ khi chưa phản hồi gì
      received: paid && !received, // admin đã thanh toán thì mới xác nhận nhận đủ
    };
  }
  return {
    history: true,
    avg: true,
    refresh: !agreed && !paid && !received,
    kpi: !agreed && !paid && !received,
    upload: agreed && !paid && !received,
    confirm: false,
    review: false,
    received: false,
  };
};

const psActionButtons = (s, isPersonalPage, roleKey, period) => {
  const a = psActions(s, isPersonalPage);
  const d = `data-staff="${psEsc(s.staff_name || 'N/A')}" data-period="${psEsc(period)}"`;
  const primary = [];
  const secondary = [];
  if (a.confirm) primary.push(`<button type="button" class="confirm-btn" ${d}>Đồng ý phiếu lương</button>`);
  if (a.received)
    primary.push(`<button type="button" class="payment-confirmed-btn" ${d}>Đã nhận đủ lương</button>`);
  if (a.upload)
    primary.push(
      `<button type="button" class="upload-payment-btn" ${d}>Thanh toán lương</button>` +
        `<input type="file" class="upload-payment-input" multiple style="display: none;" accept="image/*">`
    );
  if (a.review) secondary.push(`<button type="button" class="review-btn" ${d}>Xin xét lại</button>`);
  if (a.refresh) secondary.push(`<button type="button" class="refresh-salary-btn" ${d}>Làm mới</button>`);
  if (a.kpi && roleKey === 'hairdresser')
    secondary.push(`<button type="button" class="evaluate-kpi-btn" ${d}>Xem KPI</button>`);
  if (!isPersonalPage && roleKey === 'hairdresser')
    secondary.push(`<button type="button" class="period-rates-btn" ${d}>Hoa hồng kỳ</button>`);
  if (!isPersonalPage)
    secondary.push(`<button type="button" class="adjustments-btn" ${d}>Thưởng / Trừ</button>`);
  secondary.push(`<button type="button" class="checkin-history-btn" ${d}>Xem lịch sử</button>`);
  if (a.avg)
    secondary.push(`<button type="button" class="avg-salary-btn" ${d} data-role="${roleKey}">Lương TB</button>`);
  return `
  <div class="card-actions ps-actions">
    ${primary.length ? `<div class="ps-actions-primary">${primary.join('')}</div>` : ''}
    <div class="ps-actions-secondary">${secondary.join('')}</div>
  </div>`;
};


// Trạng thái loading cho nút: giữ chữ, thêm icon xoay tại chỗ (không dùng ::after cũ)
const psBtnLoading = (btn, on, text) => {
  if (!btn) return;
  if (on) {
    btn.dataset.psLabel = btn.dataset.psLabel || btn.innerHTML;
    btn.disabled = true;
    btn.classList.add('is-loading');
    btn.innerHTML = `<i class="fas fa-circle-notch fa-spin" aria-hidden="true"></i> ${text || btn.textContent.trim()}`;
  } else {
    btn.disabled = false;
    btn.classList.remove('is-loading');
    if (btn.dataset.psLabel) btn.innerHTML = btn.dataset.psLabel;
  }
};

const psLine = ({ name, amount, sub = '', muted = false, negative = false, note = '' }) => `
  <div class="ps-line${muted ? ' ps-line--muted' : ''}">
    <div class="ps-line-main">
      <span class="ps-line-name">${name}</span>
      <span class="ps-line-amount${negative ? ' ps-neg' : ''}">${negative ? '− ' : ''}${psMoney(
        amount
      )}</span>
    </div>
    ${sub ? `<div class="ps-line-sub">${sub}</div>` : ''}
    ${note ? `<div class="ps-line-note">${note}</div>` : ''}
  </div>`;

const psTotal = (name, amount, cls = '') => `
  <div class="ps-line ps-line--total ${cls}">
    <span class="ps-line-name">${name}</span>
    <span class="ps-line-amount">${psMoney(amount)}</span>
  </div>`;

const psMeta = (items) => `
  <dl class="ps-meta">
    ${items
      .filter(Boolean)
      .map(([k, v]) => `<div class="ps-meta-item"><dt>${k}</dt><dd>${v}</dd></div>`)
      .join('')}
  </dl>`;

// 4 ô thống kê chấm công kiểu app native: Ngày công · Nghỉ phép · Đi trễ · Tăng ca
const psStats = (items) => `
  <div class="ps-stats">
    ${items
      .filter(Boolean)
      .map(
        ([label, value, unit, tone]) => `
      <div class="ps-stat${tone ? ` ps-stat--${tone}` : ''}">
        <div class="ps-stat-value">${value}<small>${unit || ''}</small></div>
        <div class="ps-stat-label">${label}</div>
      </div>`
      )
      .join('')}
  </div>`;

// Hàng hoa hồng: DV 45% · HC 15% · SP 10% · TC 10%
const psRates = (title, chips) => `
  <div class="ps-rates">
    <span class="ps-rates-title">${title}</span>
    <div class="ps-rates-chips">
      ${chips
        .filter(Boolean)
        .map(([k, v, hint]) => `<span class="ps-rate-chip"><b>${k}</b>${v}${hint ? `<small>${hint}</small>` : ''}</span>`)
        .join('')}
    </div>
  </div>`;

const psAvatar = (name, url, cls = 'ps-avatar') =>
  url
    ? `<div class="${cls} ps-avatar--img" aria-hidden="true" style="background-image:url('${psEsc(url)}')"></div>`
    : `<div class="${cls}" aria-hidden="true">${psEsc(psInitials(name))}</div>`;

const psHeader = ({ period, status, name, roleLabel, meta, stats, rates, avatar }) => `
  <header class="ps-head">
    <div class="ps-head-top">
      <span class="ps-eyebrow">Phiếu lương</span>
      <span class="ps-period" data-ps-period-slot>${psPeriodLabel(period)}</span>
    </div>
    <div class="ps-identity">
      ${psAvatar(name, avatar)}
      <div class="ps-who">
        <div class="ps-who-top">
          <div class="ps-name">${psEsc(name || 'N/A')}</div>
          <span class="ps-status ps-status--${status.cls}">${status.text}</span>
        </div>
        <div class="ps-role">${roleLabel}</div>
      </div>
    </div>
    ${stats ? psStats(stats) : ''}
    ${rates ? psRates(rates.title, rates.chips) : ''}
    ${meta ? psMeta(meta) : ''}
  </header>`;

const psHero = ({ actual, total, deductions }) => `
  <section class="ps-hero" aria-label="Thực nhận">
    <div class="ps-hero-label">Thực nhận</div>
    <div class="ps-hero-value">${psMoney(actual)}</div>
    <div class="ps-equation">
      <span class="ps-eq-item"><small>Tổng lương</small><b>${psMoney(total)}</b></span>
      <span class="ps-eq-op">−</span>
      <span class="ps-eq-item"><small>Khấu trừ</small><b class="${
        psNum(deductions) > 0 ? 'ps-neg' : ''
      }">${psMoney(deductions)}</b></span>
    </div>
  </section>`;

// Phiếu thưởng / phiếu trừ đã áp (salary.adjustments từ API)
const psAdj = (s) => (s.adjustments && typeof s.adjustments === 'object' ? s.adjustments : { bonus_total: 0, deduction_total: 0, items: [] });
const psAdjSub = (it) =>
  [
    psNum(it.quantity) !== 1 || psNum(it.unit_price) !== psNum(it.amount)
      ? `${psMoney(it.unit_price)} × ${psQty(it.quantity)}`
      : '',
    it.note ? psEsc(it.note) : '',
  ]
    .filter(Boolean)
    .join(' · ');
const psAdjLines = (s, kind) =>
  (psAdj(s).items || [])
    .filter((it) => it.kind === kind)
    .map((it) =>
      psLine({
        name: `${kind === 'bonus' ? '<i class="fas fa-gift ps-line-ico"></i>' : it.source === 'review' ? '<i class="fas fa-star-half-alt ps-line-ico"></i>' : '<i class="fas fa-receipt ps-line-ico"></i>'}${psEsc(it.title)}`,
        amount: it.amount,
        sub: psAdjSub(it),
        negative: kind === 'deduction',
      })
    )
    .join('');

// Chú thích dưới số KPI đăng bài FB theo cách tính: workdays (N bài/ngày công) · count (số bài cố định) · legacy (KPI/tháng quy theo ngày công)
const psKpiPostNote = (it) => {
  if (it.key !== 'post_fb' || it.no_target) return '';
  if (it.mode === 'workdays') {
    const rate = psNum(it.target);
    const days = it.working_days != null ? psQty(it.working_days, 0) : null;
    // Số phải đạt đã hiện "N ngày công" ở trước → chú thích chỉ ghi cách tính, không lặp lại số ngày
    return rate === 1 && days !== null
      ? ' <small>(KPI theo ngày công)</small>'
      : ` <small>(KPI ${psQty(rate, 0)} bài/ngày công)</small>`;
  }
  if (it.mode === 'legacy' && it.required != null && it.required !== it.target) return ` <small>(KPI ${psQty(it.target, 0)}/tháng, quy theo ngày công)</small>`;
  return '';
};
// Số phải đạt hiển thị: KPI theo ngày công với 1 bài/ngày → "N ngày công" thay cho "N bài"
const psKpiTargetText = (it, target, val) => (it.key === 'post_fb' && it.mode === 'workdays' && psNum(it.target) === 1 && it.working_days != null ? `${psQty(it.working_days, 0)} ngày công` : val(target));

// Trạng thái KPI: tự động "Đạt / Chưa đạt"; admin ghi đè tay → "Admin duyệt đạt / Admin duyệt không đạt" (không icon cho gọn)
const psKpiStateText = (it) => {
  if (it.no_target) return 'Không yêu cầu';
  const manual = it.manual !== null && it.manual !== undefined;
  if (manual) return it.achieved ? 'Admin duyệt đạt' : 'Admin duyệt không đạt';
  return it.achieved ? 'Đạt' : 'Chưa đạt';
};

// Khối KPI kỳ này trên phiếu (dữ liệu salary.kpi từ API); provisional = kỳ đang chạy, KPI chỉ để theo dõi
const psKpiBlock = (k, { canEdit = false, provisional = false } = {}) => {
  if (!k) {
    return `<section class="ps-block ps-block--kpi"><h4 class="ps-block-title">KPI kỳ này</h4>
      <div class="ps-kpi-empty">Chưa đánh giá KPI kỳ này${canEdit ? ' — bấm <b>Xem KPI → Làm mới</b> để tính.' : '.'}</div></section>`;
  }
  const rows = (k.items || [])
    .map((it) => {
      const pct = Math.max(0, Math.min(100, psNum(it.percent)));
      const target = it.required != null ? it.required : it.target;
      const val = (v) => (it.unit === 'đ' ? psMoney(v) : `${psQty(v, 0)} ${it.unit}`);
      const state = it.no_target ? 'free' : it.achieved ? 'ok' : 'fail';
      return `<div class="ps-kpi-row ps-kpi-row--${state}">
        <div class="ps-kpi-head"><span class="ps-kpi-label">${psEsc(it.label)}</span>
          <span class="ps-kpi-state${it.manual !== null && it.manual !== undefined ? ' ps-kpi-state--manual' : ''}">${psKpiStateText(it)}</span></div>
        <div class="ps-kpi-bar"><span style="width:${it.no_target ? 100 : pct}%"></span></div>
        <div class="ps-kpi-nums">${it.actual === null ? '—' : val(it.actual)}${it.no_target ? '' : ` / ${psKpiTargetText(it, target, val)}${psKpiPostNote(it)}`}</div>
      </div>`;
    })
    .join('');
  return `<section class="ps-block ps-block--kpi"><h4 class="ps-block-title">KPI kỳ này${k.updated_at ? ` <small class="ps-muted">· ${psDate(k.updated_at)}</small>` : ''}${provisional ? ' <span class="ps-tag ps-tag--level">tạm tính · chưa áp vào lương</span>' : ''}</h4>
    <div class="ps-kpi-grid">${rows}</div>${k.manual_note ? `<div class="ps-line-note">Ghi chú admin: ${psEsc(k.manual_note)}</div>` : ''}${provisional ? '<div class="ps-line-note">Kỳ đang chạy: KPI chỉ để theo dõi tiến độ, áp vào lương (trừ % hoa hồng, thưởng sản phẩm) khi hết kỳ.</div>' : ''}</section>`;
};

const psDeductions = (s, totalSalary) => {
  const penaltyPct = psNum(s.penalty_percent);
  const penaltyAmt =
    s.penalty_amount !== undefined && s.penalty_amount !== null
      ? psNum(s.penalty_amount)
      : Math.round(psNum(totalSalary) * (penaltyPct / 100));
  return `
  <section class="ps-block">
    <h4 class="ps-block-title">Khấu trừ</h4>
    ${psLine({ name: 'Ứng lương', amount: s.advance_salary, muted: psNum(s.advance_salary) === 0, negative: psNum(s.advance_salary) > 0 })}
    ${psLine({ name: 'Phí đồng phục', amount: s.uniform_fee, muted: psNum(s.uniform_fee) === 0, negative: psNum(s.uniform_fee) > 0 })}
    ${psLine({
      name: 'Tiền phạt',
      amount: penaltyAmt,
      sub: penaltyPct > 0 ? `${psPct(penaltyPct)} × tổng lương ${psMoney(totalSalary)}` : 'Không bị phạt kỳ này',
      muted: penaltyAmt === 0,
      negative: penaltyAmt > 0,
    })}
    ${psAdjLines(s, 'deduction')}
    ${psTotal('Tổng trừ', s.total_of_deductions, 'ps-line--deduct')}
  </section>`;
};

const psPaymentImages = (paymentImages) =>
  paymentImages.length
    ? `<div class="payment-image-container ps-proof">
         <div class="ps-proof-title">Chứng từ thanh toán</div>
         <div class="ps-proof-grid">
           ${paymentImages
             .map(
               (url) =>
                 `<a href="${psEsc(url)}" target="_blank" rel="noopener"><img src="${psEsc(
                   url
                 )}" alt="Hình ảnh thanh toán" loading="lazy"></a>`
             )
             .join('')}
         </div>
       </div>`
    : '';

const psParsePayment = (payment) => {
  if (!payment) return [];
  try {
    const parsed = typeof payment === 'string' ? JSON.parse(payment) : payment;
    return Array.isArray(parsed) ? parsed : [];
  } catch (error) {
    console.error('Error parsing payment images:', error);
    return [];
  }
};


function createHairdresserSalaryCard(salary, isPersonalPage = false, role = 'Unknown') {
  if (!salary || typeof salary !== 'object') {
    console.error('Invalid salary data:', salary);
    const errorCard = document.createElement('div');
    errorCard.className = 'salary-card error';
    errorCard.innerHTML = '<div class="no-data">Lỗi: Dữ liệu lương không hợp lệ.</div>';
    return errorCard;
  }

  const yearSelect =
    document.getElementById('year-select') || document.getElementById('salary-year-select');
  const monthSelect =
    document.getElementById('month-select') || document.getElementById('salary-month-select');
  const period =
    yearSelect && monthSelect ? `${yearSelect.value}-${monthSelect.value}` : salary.period || '';

  const card = document.createElement('article');
  card.className = 'salary-card ps-card';
  card.dataset.staff = salary.staff_name; // Thêm data-staff để dễ tìm card
  card.dataset.period = period; // Thêm data-period để dễ tìm card

  // Giữ tên cũ cho phần handler phía dưới
  const formatCurrency = psMoney;

  // % hoa hồng: API trả `*_commission_percent` (tính từ số đã lưu / cài đặt bậc).
  // Bản API cũ không có → suy từ tiền / doanh số ngay tại client.
  const serviceBase = psNum(salary.service_total) - psNum(salary.penalty_service);
  const chemicalBase = psNum(salary.chemical_total) - psNum(salary.penalty_chemical);
  const serviceRate = psRate(
    salary.service_commission_percent,
    salary.service_salary,
    serviceBase,
    salary.level_service_percent
  );
  const chemicalRate = psRate(
    salary.chemical_commission_percent,
    salary.chemical_salary,
    chemicalBase,
    salary.level_chemical_percent
  );
  const productRate = psRate(
    salary.product_commission_percent,
    salary.product_salary,
    salary.product_total,
    10
  );
  const overtimeRate = psRate(
    salary.overtime_commission_percent,
    salary.overtime_salary,
    salary.overtime_total,
    10
  );

  const levelServicePct =
    salary.level_service_percent !== undefined && salary.level_service_percent !== null
      ? psNum(salary.level_service_percent)
      : serviceRate;
  const levelChemicalPct =
    salary.level_chemical_percent !== undefined && salary.level_chemical_percent !== null
      ? psNum(salary.level_chemical_percent)
      : chemicalRate;

  // Truy thu kỳ này: HĐ admin đánh dấu tay (penalty_invoices) · phiếu trừ tự động (source review/no_image) · HĐ admin đã bỏ qua (marker ignored)
  const adjItems = psAdj(salary).items || [];
  const autoDeductions = adjItems.filter((it) => it.kind === 'deduction' && (it.source === 'review' || it.source === 'no_image'));
  // Truy thu kiểu %: trừ khỏi doanh số dịch vụ/hoá chất (kind base_penalty), gom theo hoá đơn
  const baseRows = adjItems.filter((it) => it.kind === 'base_penalty');
  const baseByInv = [...baseRows.reduce((m, it) => {
    const g = m.get(it.ref_id) || { ref_id: it.ref_id, id: it.id, source: it.source, note: it.note, service: 0, chemical: 0 };
    g[it.category === 'chemical' ? 'chemical' : 'service'] += psNum(it.amount);
    m.set(it.ref_id, g);
    return m;
  }, new Map()).values()];
  const ignoredMarkers = adjItems.filter((it) => it.kind === 'marker' && it.category === 'ignored');
  const autoMarkers = adjItems.filter((it) => it.kind === 'marker' && it.category !== 'ignored');
  const penaltyInvoices = Array.isArray(salary.penalty_invoices) ? salary.penalty_invoices : [];
  const hasPenalty =
    psNum(salary.penalty_service) > 0 ||
    psNum(salary.penalty_chemical) > 0 ||
    autoMarkers.length > 0 ||
    autoDeductions.length > 0 ||
    baseRows.length > 0 ||
    ignoredMarkers.length > 0 ||
    (salary.penalty_note && String(salary.penalty_note).trim() !== '');
  const penaltyReason = (it) => (it.source === 'review' ? 'khách đánh giá thấp' : it.source === 'no_image' ? 'hoá đơn không ảnh' : 'truy thu');

  // Thẻ hoa hồng đã áp cho kỳ này (bản 5.3.4.7+), null nếu vẫn tính theo bậc
  const applied = salary.rates_applied && typeof salary.rates_applied === 'object' ? salary.rates_applied : null;
  const kpiLabel = { feedback: 'KPI đánh giá', post_fb: 'KPI đăng bài', service: 'KPI dịch vụ', product: 'KPI sản phẩm' };
  const kpiFailedText = applied && Array.isArray(applied.kpi_failed) && applied.kpi_failed.length
    ? applied.kpi_failed.map((k) => kpiLabel[k] || k).join(', ')
    : '';

  // Giải thích %: "27.930.000 đ × 40% (45% − 5% KPI đăng bài)"
  const rateText = (rate, basePct, penaltyPts) =>
    penaltyPts > 0
      ? `${psPct(rate)} <span class="ps-rate-why">(${psPct(basePct)} − ${psPct(penaltyPts)} ${kpiFailedText})</span>`
      : psPct(rate);
  const svcPenalty = applied && ['service', 'both'].includes(applied.kpi_penalty_scope) ? psNum(applied.kpi_penalty_applied) : 0;
  const chemPenalty = applied && ['chemical', 'both'].includes(applied.kpi_penalty_scope) ? psNum(applied.kpi_penalty_applied) : 0;

  const commissionSub = (total, penalty, rate, basePct, penaltyPts) => {
    const t = psNum(total);
    const p = psNum(penalty);
    if (t === 0) return 'Không có doanh số kỳ này';
    const r = rateText(rate, basePct, penaltyPts);
    if (p > 0) return `(${psMoney(t)} − truy thu ${psMoney(p)}) × ${r}`;
    return `${psMoney(t)} × ${r}`;
  };

  const productNote = applied
    ? !applied.product_threshold_met && psNum(salary.product_count_total) > 0
      ? `Cần bán từ ${psQty(applied.product_min_qty, 0)} sản phẩm mới hưởng ${psPct(applied.product_percent)}`
      : ''
    : salary.product_bonus_source === 'kpi'
      ? `Áp % thưởng theo KPI đạt`
      : salary.product_bonus_source === 'kpi_failed'
        ? `KPI sản phẩm không đạt — không tính thưởng`
        : '';

  const att = salary.attendance && typeof salary.attendance === 'object' ? salary.attendance : {};
  const ratesMetaLabel = applied ? 'Hoa hồng kỳ này' : 'Hoa hồng theo bậc';
  const ratesMetaValue = applied
    ? `DV ${psPct(applied.service_percent)} · HC ${psPct(applied.chemical_percent)}${
        applied.source === 'carried' && applied.from_period ? ` <small>(kế thừa ${applied.from_period.split('-').reverse().join('/')})</small>` : ''
      }`
    : `DV ${psPct(levelServicePct)} · HC ${psPct(levelChemicalPct)}`;

  const paymentImages = psParsePayment(salary.payment);
  const status = psStatus(salary, isPersonalPage);
  const actions = psActions(salary, isPersonalPage);

  card.innerHTML = `
    ${psHeader({
      period,
      status,
      name: salary.staff_name,
      avatar: salary.avatar,
      roleLabel: `Thợ · ${psEsc(salary.level_name || 'Chưa có bậc')}${
        salary.level_start_date ? ` · từ ${psDate(salary.level_start_date)}` : ''
      }`,
      stats: [
        ['Ngày công', psQty(att.working_days ?? salary.working_days), ''],
        ['Nghỉ phép', psQty(att.leave_days ?? 0), '', psNum(att.leave_days) > 0 ? 'muted' : ''],
        ['Đi trễ', psQty(att.late_days ?? 0), '', psNum(att.late_days) > 0 ? 'warn' : ''],
        ['Tăng ca', psQty(att.overtime_days ?? 0), '', psNum(att.overtime_days) > 0 ? 'pos' : ''],
      ],
      rates: {
        title: ratesMetaLabel,
        chips: [
          ['DV', psPct(applied ? applied.service_percent : levelServicePct), svcPenalty ? `−${psPct(svcPenalty)} KPI` : ''],
          ['HC', psPct(applied ? applied.chemical_percent : levelChemicalPct), chemPenalty ? `−${psPct(chemPenalty)} KPI` : ''],
          ['SP', psPct(applied ? applied.product_percent : productRate), applied && applied.product_min_qty > 1 ? `≥${psQty(applied.product_min_qty, 0)} SP` : ''],
          ['TC', psPct(applied ? applied.overtime_percent : overtimeRate), ''],
          applied && applied.source === 'carried' && applied.from_period
            ? ['', `kế thừa ${applied.from_period.split('-').reverse().join('/')}`, '']
            : null,
        ],
      },
    })}

    ${psHero({
      actual: salary.actual_salary,
      total: salary.total_salary,
      deductions: salary.total_of_deductions,
    })}

    ${psKpiBlock(salary.kpi, { canEdit: !isPersonalPage, provisional: !!salary.kpi_provisional })}

    <section class="ps-block">
      <h4 class="ps-block-title">Thu nhập</h4>
      ${psLine({
        name: 'Dịch vụ',
        amount: salary.service_salary,
        sub: commissionSub(salary.service_total, salary.penalty_service, serviceRate, applied ? applied.service_percent : serviceRate, svcPenalty),
        muted: psNum(salary.service_salary) === 0,
      })}
      ${psLine({
        name: 'Hoá chất',
        amount: salary.chemical_salary,
        sub: commissionSub(salary.chemical_total, salary.penalty_chemical, chemicalRate, applied ? applied.chemical_percent : chemicalRate, chemPenalty),
        muted: psNum(salary.chemical_salary) === 0,
      })}
      ${psLine({
        name: 'Bán sản phẩm',
        amount: salary.product_salary,
        sub:
          psNum(salary.product_total) === 0
            ? 'Không bán sản phẩm kỳ này'
            : `${psMoney(salary.product_total)} × ${psPct(productRate)} · ${psQty(
                salary.product_count_total,
                0
              )} sản phẩm`,
        note: productNote,
        muted: psNum(salary.product_salary) === 0,
      })}
      ${psLine({
        name: 'Tăng ca',
        amount: salary.overtime_salary,
        sub:
          psNum(salary.overtime_total) === 0
            ? 'Không có tăng ca kỳ này'
            : `${psMoney(salary.overtime_total)} × ${psPct(overtimeRate)}`,
        muted: psNum(salary.overtime_salary) === 0,
      })}
      ${psAdjLines(salary, 'bonus')}
      ${psTotal('Tổng lương', salary.total_salary, 'ps-line--income')}
    </section>

    ${psDeductions(salary, salary.total_salary)}

    ${
      kpiFailedText
        ? `
      <aside class="ps-note ps-note--warn">
        <div class="ps-note-title">Không đạt KPI kỳ này</div>
        <div class="ps-note-body">${psEsc(kpiFailedText)} — hoa hồng ${
          applied.kpi_penalty_scope === 'both' ? 'dịch vụ và hoá chất' : applied.kpi_penalty_scope === 'chemical' ? 'hoá chất' : 'dịch vụ'
        } bị trừ ${psPct(applied.kpi_penalty_applied)}.</div>
      </aside>`
        : ''
    }
    ${
      hasPenalty
        ? `
      <aside class="ps-note ps-note--warn ps-note--penalty">
        <div class="ps-note-title">Truy thu kỳ này${autoDeductions.length ? ` <b class="ps-neg">− ${psMoney(autoDeductions.reduce((a, it) => a + psNum(it.amount), 0))}</b>` : ''}</div>
        ${salary.penalty_note && String(salary.penalty_note).trim() !== '' ? `<div class="ps-note-body">${psEsc(salary.penalty_note)}</div>` : ''}
        ${
          penaltyInvoices.length || autoMarkers.length
            ? `<div class="ps-note-body">Doanh số bị trừ trước khi tính hoa hồng: ${
                psNum(salary.penalty_service) > 0 ? `dịch vụ − ${psMoney(salary.penalty_service)}` : ''
              }${psNum(salary.penalty_service) > 0 && psNum(salary.penalty_chemical) > 0 ? ' · ' : ''}${
                psNum(salary.penalty_chemical) > 0 ? `hoá chất − ${psMoney(salary.penalty_chemical)}` : ''
              }</div>
              <ul class="ps-note-list">${penaltyInvoices
                .map((pi) => `<li>HĐ ${psEsc(pi.invoice_id)} · ${psDate(pi.date)} · ${pi.service_type === 'chemical' ? 'hoá chất' : 'dịch vụ'} ${psMoney(pi.total)} · admin truy thu</li>`)
                .join('')}${autoMarkers.map((m) => `<li>${psEsc(m.title)}</li>`).join('')}</ul>`
            : psNum(salary.penalty_service) > 0 || psNum(salary.penalty_chemical) > 0
              ? `<div class="ps-note-figures">${psNum(salary.penalty_service) > 0 ? `<span>Dịch vụ − ${psMoney(salary.penalty_service)}</span>` : ''}${psNum(salary.penalty_chemical) > 0 ? `<span>Hoá chất − ${psMoney(salary.penalty_chemical)}</span>` : ''}</div>`
              : ''
        }
        ${
          baseByInv.length
            ? `<div class="ps-note-body">Tự động theo <i>Cài đặt lương</i> — trừ khỏi doanh số (sản phẩm vẫn tính):</div>
              <ul class="ps-note-rows">${baseByInv
                .map(
                  (g) => `<li><span class="ps-note-row-main"><b>HĐ ${psEsc(g.ref_id)}</b> · ${penaltyReason(g)}${g.note ? ` · ${psEsc(g.note)}` : ''}</span><span class="ps-neg">${
                    [g.service ? `DV − ${psMoney(g.service)}` : '', g.chemical ? `HC − ${psMoney(g.chemical)}` : ''].filter(Boolean).join(' · ')
                  }</span>${
                    !isPersonalPage ? `<button type="button" class="ps-link-btn" data-ps-adj-ignore="${g.id}" title="Không truy thu hoá đơn này, tính lại lương">Bỏ qua</button>` : ''
                  }</li>`
                )
                .join('')}</ul>`
            : ''
        }
        ${
          autoDeductions.length
            ? `<div class="ps-note-body">Tự động theo <i>Cài đặt lương</i>, đã tính vào Khấu trừ:</div>
              <ul class="ps-note-rows">${autoDeductions
                .map(
                  (it) => `<li><span class="ps-note-row-main"><b>${psEsc(it.ref_id ? 'HĐ ' + it.ref_id : it.title)}</b> · ${penaltyReason(it)}${it.note ? ` · ${psEsc(it.note)}` : ''}</span><span class="ps-neg">− ${psMoney(it.amount)}</span>${
                    !isPersonalPage ? `<button type="button" class="ps-link-btn" data-ps-adj-ignore="${it.id}" title="Không truy thu hoá đơn này, tính lại lương">Bỏ qua</button>` : ''
                  }</li>`
                )
                .join('')}</ul>`
            : ''
        }
        ${
          ignoredMarkers.length
            ? `<ul class="ps-note-rows ps-note-rows--muted">${ignoredMarkers
                .map(
                  (it) => `<li><span class="ps-note-row-main">${psEsc(it.title)}</span><span class="ps-tag ps-tag--level">đã bỏ qua</span>${
                    !isPersonalPage ? `<button type="button" class="ps-link-btn" data-ps-adj-restore="${it.id}" title="Truy thu lại hoá đơn này">Khôi phục</button>` : ''
                  }</li>`
                )
                .join('')}</ul>`
            : ''
        }
      </aside>`
        : ''
    }

    ${psActionButtons(salary, isPersonalPage, 'hairdresser', period)}
    ${psPaymentImages(paymentImages)}
  `;


  // Xử lý nút "Xem lịch sử"
  const historyButton = card.querySelector('.checkin-history-btn');
  historyButton.addEventListener('click', () => {
    showHistoryModalHairdresser(salary.staff_name, period, isPersonalPage);
  });

  // Admin: "Bỏ qua" truy thu tự động một hoá đơn (đổi thành marker, sync không tạo lại) / "Khôi phục"
  card.querySelectorAll('[data-ps-adj-ignore], [data-ps-adj-restore]').forEach((btn) => {
    btn.addEventListener('click', async () => {
      const id = btn.dataset.psAdjIgnore || btn.dataset.psAdjRestore;
      const isIgnore = !!btn.dataset.psAdjIgnore;
      if (!confirm(isIgnore ? 'Bỏ qua truy thu hoá đơn này và tính lại lương?' : 'Truy thu lại hoá đơn này và tính lại lương?')) return;
      psBtnLoading(btn, true);
      try {
        const r = await fetch(`${checkinData.restUrl}salary-adjustments`, {
          method: 'DELETE',
          headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': checkinData.nonce },
          credentials: 'include',
          body: JSON.stringify({ id: parseInt(id, 10) }),
        });
        const j = await r.json().catch(() => ({}));
        if (!r.ok || j.success === false) throw new Error(j.message || `HTTP ${r.status}`);
        (window.toastSuccess || alert)(j.message || 'Đã cập nhật');
        await refreshSalaryCard(salary.staff_name, period);
      } catch (e) {
        psBtnLoading(btn, false);
        (window.showError || alert)('Không cập nhật được: ' + e.message);
      }
    });
  });

  // Xử lý nút "Lương TB" (admin only)
  const avgSalaryBtn = card.querySelector('.avg-salary-btn');
  if (avgSalaryBtn) {
    avgSalaryBtn.addEventListener('click', () => {
      showAverageSalaryModal(avgSalaryBtn.dataset.staff, avgSalaryBtn.dataset.role, avgSalaryBtn.dataset.period);
    });
  }

  // Hàm làm mới card lương và bảng
  const refreshSalaryCard = async (staffName, period) => {
    try {
      const response = await fetch(
        `${checkinData.restUrl}hairdresser-salary-data?type=salary&staff_name=${encodeURIComponent(
          staffName
        )}&period=${period}`,
        {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            'X-WP-Nonce': checkinData.nonce,
          },
        }
      );

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(
          `HTTP error! Status: ${response.status}, Message: ${errorData.message || 'Unknown error'}`
        );
      }

      const responseData = await response.json();
      if (responseData.success && responseData.data && responseData.data.length > 0) {
        const newSalaryData = responseData.data[0];

        // 1. Cập nhật card trong modal
        const newCard = createHairdresserSalaryCard(newSalaryData, isPersonalPage, role);
        const currentCard = document.querySelector(
          `.salary-card[data-staff="${staffName}"][data-period="${period}"]`
        );
        if (currentCard && currentCard.parentNode) {
          currentCard.parentNode.replaceChild(newCard, currentCard);
          window.dispatchEvent(new CustomEvent('ps:salary-updated', { detail: { staff: staffName, period, role, row: newSalaryData } }));
        } else {
          console.warn('Không tìm thấy card hiện tại để thay thế, thêm card mới vào container');
          const container = document.querySelector('.salary-card-container');
          if (container) {
            container.appendChild(newCard);
          } else {
            throw new Error('Không tìm thấy container .salary-card-container');
          }
        }

        // 2. Cập nhật bảng lương nếu đang ở trang admin
        if (!isPersonalPage) {
          const salaryRow = document.querySelector(
            `.salary-row[data-staff="${staffName}"][data-period="${period}"]`
          );
          if (salaryRow) {
            const formatCurrency = (value) => parseFloat(value || 0).toLocaleString('vi-VN') + ' đ';
            const getStatusDisplay = (status) => {
              switch (status) {
                case 'confirm pending':
                  return '<span class="status status-pending">Chờ xác nhận</span>';
                case 'confirmed':
                  return '<span class="status status-confirmed">Đã xác nhận</span>';
                case 'payment pending':
                  return '<span class="status status-payment-pending">Đã thanh toán</span>';
                case 'received':
                  return '<span class="status status-received">Đã nhận đủ</span>';
                default:
                  return '<span class="status status-pending">Chờ xác nhận</span>';
              }
            };

            // Cập nhật các cột trong bảng
            const cells = salaryRow.querySelectorAll('td');
            if (cells.length >= 8) {
              cells[1].textContent = newSalaryData.level_name || 'N/A';
              cells[2].textContent = formatCurrency(newSalaryData.total_salary);
              cells[3].textContent = formatCurrency(newSalaryData.total_of_deductions);
              cells[4].textContent = formatCurrency(newSalaryData.actual_salary);
              cells[5].innerHTML = getStatusDisplay(newSalaryData.status);
              cells[6].textContent = newSalaryData.xac_nhan_luong || 'N/A';
            }
          }
        }
      } else {
        throw new Error(responseData.message || 'Không tìm thấy dữ liệu lương mới');
      }
    } catch (error) {
      console.error('Error fetching updated salary:', error.message);
      alert('Lỗi khi tải dữ liệu lương mới: ' + error.message);
    }
  };

  // Nút "Hoa hồng kỳ" (admin): mở thẻ hoa hồng của thợ cho kỳ này
  card.querySelector('.period-rates-btn')?.addEventListener('click', () => {
    if (!window.psRatesModal) return;
    window.psRatesModal.open({
      staffName: salary.staff_name,
      period,
      onSaved: () => refreshSalaryCard(salary.staff_name, period),
    });
  });

  // Nút "Thưởng / Trừ" (admin): phiếu thưởng, phiếu trừ, truy thu đánh giá thấp
  card.querySelector('.adjustments-btn')?.addEventListener('click', () => {
    window.psAdjustModal?.open({
      staffName: salary.staff_name,
      role: 'Thợ',
      period,
      onSaved: () => refreshSalaryCard(salary.staff_name, period),
    });
  });

  // Xử lý nút "Làm mới phiếu lương" với hiệu ứng loading
  if (actions.refresh) {
    const refreshButton = card.querySelector('.refresh-salary-btn');
    if (refreshButton) {
      refreshButton.addEventListener('click', async () => {
        psBtnLoading(refreshButton, true, 'Đang làm mới…');

        try {
          const updateResponse = await fetch(`${checkinData.restUrl}update-hairdresser-salary`, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'X-WP-Nonce': checkinData.nonce,
            },
            body: JSON.stringify({
              period: period,
              staff_name: salary.staff_name,
            }),
          });

          if (!updateResponse.ok) {
            const errorData = await updateResponse.json();
            throw new Error(
              `HTTP error! Status: ${updateResponse.status}, Message: ${
                errorData.message || 'Unknown error'
              }`
            );
          }

          const updateData = await updateResponse.json();
          if (updateData.success) {
            toastSuccess('Làm mới phiếu lương thành công!');
            await refreshSalaryCard(salary.staff_name, period);
          } else {
            throw new Error(updateData.message || 'Lỗi không xác định từ server');
          }
        } catch (error) {
          console.error('Refresh salary error:', error.message);
          showError('Lỗi khi làm mới phiếu lương: ' + error.message);
        } finally {
          psBtnLoading(refreshButton, false);
        }
      });
    }
  }

  // Nút "Xem KPI" (admin): modal thanh tiến trình KPI + Làm mới / Sửa tay
  if (actions.kpi) {
    card.querySelector('.evaluate-kpi-btn')?.addEventListener('click', () => {
      window.psKpiModal?.open({
        staffName: salary.staff_name,
        period,
        canEdit: true,
        onChanged: () => refreshSalaryCard(salary.staff_name, period),
      });
    });
  }

  // Xử lý nút "Đồng ý" (chỉ trên trang cá nhân)
  if (actions.confirm) {
    const confirmButton = card.querySelector('.confirm-btn');
    confirmButton.addEventListener('click', async () => {
      try {
        const response = await fetch(`${checkinData.restUrl}confirm-salary`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-WP-Nonce': checkinData.nonce,
          },
          body: JSON.stringify({
            staff_name: salary.staff_name,
            period: period,
            role: role,
            action: 'approve',
          }),
        });

        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(
            `HTTP error! Status: ${response.status}, Message: ${
              errorData.message || 'Unknown error'
            }`
          );
        }

        const responseData = await response.json();
        if (responseData.success) {
          toastSuccess('Xác nhận lương thành công!');
          await refreshSalaryCard(salary.staff_name, period);
        } else {
          throw new Error(responseData.message || 'Lỗi không xác định từ server');
        }
      } catch (error) {
        console.error('Confirm salary error:', error.message);
        showError('Lỗi khi xác nhận lương: ' + error.message);
      }
    });
  }

  // Xử lý nút "Xin xét lại" (chỉ trên trang cá nhân)
  if (actions.review) {
    const reviewButton = card.querySelector('.review-btn');
    reviewButton?.addEventListener('click', async () => {
      try {
        const response = await fetch(`${checkinData.restUrl}confirm-salary`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-WP-Nonce': checkinData.nonce,
          },
          body: JSON.stringify({
            staff_name: salary.staff_name,
            period: period,
            role: role,
            action: 'reconsider',
          }),
        });

        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(
            `HTTP error! Status: ${response.status}, Message: ${
              errorData.message || 'Unknown error'
            }`
          );
        }

        const responseData = await response.json();
        if (responseData.success) {
          toastSuccess('Yêu cầu xét lại lương đã được gửi!');
          await refreshSalaryCard(salary.staff_name, period);
        } else {
          throw new Error(responseData.message || 'Lỗi không xác định từ server');
        }
      } catch (error) {
        console.error('Request review error:', error.message);
        showError('Lỗi khi gửi yêu cầu xét lại: ' + error.message);
      }
    });
  }

  // Xử lý nút "Đã nhận đủ" (chỉ trên trang cá nhân)
  if (actions.received) {
    const paymentConfirmedButton = card.querySelector('.payment-confirmed-btn');
    paymentConfirmedButton.addEventListener('click', async () => {
      try {
        const response = await fetch(`${checkinData.restUrl}confirm-salary-payment`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-WP-Nonce': checkinData.nonce,
          },
          body: JSON.stringify({
            staff_name: salary.staff_name,
            period: period,
            role: role,
            payment_confirmed: 'received',
          }),
        });

        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(
            `HTTP error! Status: ${response.status}, Message: ${
              errorData.message || 'Unknown error'
            }`
          );
        }

        const responseData = await response.json();
        if (responseData.success) {
          toastSuccess('Xác nhận đã nhận đủ thành công!');
          await refreshSalaryCard(salary.staff_name, period);
        } else {
          throw new Error(responseData.message || 'Lỗi không xác định từ server');
        }
      } catch (error) {
        console.error('Payment confirmation error:', error.message);
        showError('Lỗi khi xác nhận thanh toán: ' + error.message);
      }
    });
  }

  // Xử lý upload nhiều hình ảnh thanh toán (chỉ dành cho admin)
  if (actions.upload) {
    const uploadButton = card.querySelector('.upload-payment-btn');
    const fileInput = card.querySelector('.upload-payment-input');

    uploadButton.addEventListener('click', () => {
      fileInput.click();
    });

    fileInput.addEventListener('change', async () => {
      const files = fileInput.files;
      if (!files || files.length === 0) {
        alert('Vui lòng chọn ít nhất một hình ảnh thanh toán.');
        return;
      }

      const formData = new FormData();
      for (let i = 0; i < files.length; i++) {
        formData.append('payment_images[]', files[i]);
      }
      formData.append('staff_name', salary.staff_name);
      formData.append('period', period);
      formData.append('role', role);

      try {
        const response = await fetch(`${checkinData.restUrl}upload-payment-images`, {
          method: 'POST',
          headers: { 'X-WP-Nonce': checkinData.nonce },
          body: formData,
        });

        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(
            `HTTP error! Status: ${response.status}, Message: ${
              errorData.message || 'Unknown error'
            }`
          );
        }

        const responseData = await response.json();
        if (responseData.success) {
          alert('Ảnh thanh toán đã được tải lên thành công!');
          await refreshSalaryCard(salary.staff_name, period);
        } else {
          throw new Error(responseData.message || 'Lỗi không xác định từ server');
        }
      } catch (error) {
        console.error('Fetch error:', error.message);
        alert('Lỗi khi tải ảnh thanh toán: ' + error.message);
      }
    });
  }

  return card;
}

async function fetchCheckinHistory(staffName, period, isPersonalPage = false) {
  try {
    const [year, month] = period.split('-'); // period = "2025-06"
    const startDate = `${year}-${month}-01`;

    // Lấy ngày cuối cùng của tháng hiện tại:
    const endDay = new Date(year, parseInt(month), 0).getDate();
    const endDate = `${year}-${month}-${String(endDay).padStart(2, '0')}`;

    const currentUserRole = await getCurrentUserRole(isPersonalPage);

    const checkinResponse = await fetch(
      `${checkinData.restUrl}employee-checkin-logs/0?display_name=${encodeURIComponent(
        currentUserDisplayName
      )}&start_date=${encodeURIComponent(startDate)}&end_date=${encodeURIComponent(
        endDate
      )}&current_user_role=${encodeURIComponent(currentUserRole)}`,
      {
        method: 'GET',
        headers: {
          'X-WP-Nonce': checkinData.nonce,
        },
      }
    );

    if (!checkinResponse.ok) {
      throw new Error(`Lỗi khi lấy dữ liệu chấm công: ${checkinResponse.status}`);
    }

    const checkinHistoryData = await checkinResponse.json();
    if (!checkinHistoryData.success || !checkinHistoryData.data) {
      throw new Error(checkinHistoryData.message || 'Không tìm thấy dữ liệu chấm công');
    }

    const levelResponse = await fetch(
      `${checkinData.restUrl}staff-levels?staff_name=${encodeURIComponent(
        staffName
      )}&date=${encodeURIComponent(endDate)}`,
      {
        method: 'GET',
        headers: {
          'X-WP-Nonce': checkinData.nonce,
        },
      }
    );

    if (!levelResponse.ok) {
      throw new Error(`Lỗi khi lấy dữ liệu cấp bậc: ${levelResponse.status}`);
    }

    const levelData = await levelResponse.json();
    if (!levelData.success || !levelData.data) {
      throw new Error(levelData.message || 'Không tìm thấy dữ liệu cấp bậc');
    }

    const level = levelData.data;

    const salarySettingsResponse = await fetch(
      `${checkinData.restUrl}salary-levels?level_name=${encodeURIComponent(level.level_name)}`,
      {
        method: 'GET',
        headers: {
          'X-WP-Nonce': checkinData.nonce,
        },
      }
    );

    if (!salarySettingsResponse.ok) {
      throw new Error(`Lỗi khi lấy cấu hình lương: ${salarySettingsResponse.status}`);
    }

    const salarySettings = await salarySettingsResponse.json();
    if (!salarySettings.success || !salarySettings.data) {
      throw new Error(salarySettings.message || 'Không tìm thấy cấu hình lương');
    }

    const invoicesResponse = await fetch(
      `${checkinData.restUrl}staff-invoices?staff_name=${encodeURIComponent(
        staffName
      )}&current_user_role=${encodeURIComponent(
        currentUserRole
      )}&filter=custom&start_date=${encodeURIComponent(startDate)}&end_date=${encodeURIComponent(
        endDate
      )}`,
      {
        method: 'GET',
        headers: {
          'X-WP-Nonce': checkinData.nonce,
        },
      }
    );

    if (!invoicesResponse.ok) {
      throw new Error(`Lỗi khi lấy dữ liệu hóa đơn: ${invoicesResponse.status}`);
    }

    const invoicesData = await invoicesResponse.json();
    if (!invoicesData.success || !invoicesData.data) {
      throw new Error(invoicesData.message || 'Không tìm thấy dữ liệu hóa đơn');
    }

    const dailyData = {};
    const invoiceDetails = invoicesData.data;

    console.log('Invoice Data:', invoiceDetails);

    const currentDate = new Date(startDate);
    const lastDate = new Date(endDate);
    while (currentDate <= lastDate) {
      const dateKey = currentDate.toISOString().slice(0, 10);
      dailyData[dateKey] = {
        date: dateKey,
        customerCount: 0,
        serviceTotal: 0,
        penaltyService: 0,
        chemicalTotal: 0,
        penaltyChemical: 0,
        productTotal: 0,
        serviceSalary: 0,
        chemicalSalary: 0,
      };
      currentDate.setDate(currentDate.getDate() + 1);
    }

    invoiceDetails.forEach((invoice) => {
      let createdAt = invoice.created_at;
      if (!createdAt) {
        console.warn('Invoice missing created_at:', invoice);
        return;
      }
      const date = new Date(createdAt);
      if (isNaN(date)) {
        console.warn('Invalid created_at format:', createdAt);
        return;
      }
      const dateKey = date.toISOString().slice(0, 10);
      if (!dailyData[dateKey]) {
        console.warn('Date key not found in dailyData:', dateKey);
        return;
      }
      (invoice.services || []).forEach((service) => {
        if (service.staff_name === staffName) {
          const total = parseFloat(service.total || 0);
          if (isNaN(total)) {
            console.warn('Invalid total value for service:', service);
            return;
          }
          if (service.service_type === 'service' && service.is_penalty === false) {
            dailyData[dateKey].serviceTotal += total;
            dailyData[dateKey].customerCount += parseInt(service.quantity || 1);
          } else if (service.service_type === 'service' && service.is_penalty === true) {
            dailyData[dateKey].penaltyService += total;
          } else if (service.service_type === 'chemical' && service.is_penalty === false) {
            dailyData[dateKey].chemicalTotal += total;
          } else if (service.service_type === 'chemical' && service.is_penalty === true) {
            dailyData[dateKey].penaltyChemical += total;
          } else if (service.type === 'product') {
            dailyData[dateKey].productTotal += total;
          }
        }
      });
    });

    Object.keys(dailyData).forEach((date) => {
      const data = dailyData[date];
      const serviceRate = parseFloat(salarySettings.data.service_salary || 0);
      const chemicalRate = parseFloat(salarySettings.data.chemical_salary || 0);

      if (isNaN(serviceRate) || isNaN(chemicalRate)) {
        console.warn('Invalid salary settings for date:', date, salarySettings);
      }

      data.serviceSalary = data.serviceTotal * (serviceRate / 100) - data.penaltyService;
      data.chemicalSalary = data.chemicalTotal * (chemicalRate / 100) - data.penaltyChemical;
    });

    console.log('Daily Data:', dailyData);

    const result = Object.values(dailyData);

    return {
      success: true,
      data: result,
    };
  } catch (error) {
    console.error('Lỗi khi lấy lịch sử chấm công:', error.message);
    return {
      success: false,
      message: error.message || 'Lỗi không xác định khi lấy dữ liệu lịch sử',
    };
  }
}

async function showHistoryModalHairdresser(staffName, period, isPersonalPage = false) {
  // Tạo modal
  const modal = document.createElement('div');
  modal.style.zIndex = '1300'; // nổi trên modal phiếu lương (1100) và ps-modal (1200)
  modal.className = 'modal';
  modal.style.display = 'none'; // Ẩn ban đầu để thêm animation

  // Format tiền tệ
  const formatCurrency = (value) => parseFloat(value || 0).toLocaleString('vi-VN') + ' đ';

  // Tạo nội dung modal với loading spinner
  modal.innerHTML = `
        <div class="modal-content">
            <button class="close-modal-btn">x</button>
            <h2>${staffName} - Tháng ${period.split('-')[1]}/${period.split('-')[0]}</h2>
            <div class="checkin-history-cards loading">
                <p>Đang tải dữ liệu...</p>
            </div>
        </div>
    `;

  // Thêm modal vào body
  document.body.appendChild(modal);

  // Hiển thị modal với animation
  setTimeout(() => {
    modal.style.display = 'block';
    requestAnimationFrame(() => {
      modal.classList.add('show');
    });
  }, 10);

  // Xử lý nút đóng
  const closeModal = () => {
    modal.classList.remove('show');
    setTimeout(() => modal.remove(), 300); // Đợi animation hoàn tất
  };

  const closeBtn = modal.querySelector('button');
  closeBtn.addEventListener('click', closeModal);

  modal.addEventListener('click', (e) => {
    if (e.target === modal) closeModal();
  });

  // Gọi API
  try {
    const response = await fetchCheckinHistory(staffName, period, isPersonalPage);
    const cardsContainer = modal.querySelector('.checkin-history-cards');
    cardsContainer.classList.remove('loading');

    if (!response.success) {
      cardsContainer.innerHTML = `<p>Lỗi: ${response.message}</p>`;
      return;
    }

    let modalContent = '';
    if (response.data.length === 0) {
      modalContent = `
                <div class="salary-card">
                    <div class="salary-section">
                        <h4 class="section-title gray-bg">THÔNG BÁO</h4>
                        <div class="card-field">
                            <span class="label">Thông tin:</span>
                            <span class="value">Không có dữ liệu chấm công cho tháng này.</span>
                        </div>
                    </div>
                </div>
            `;
    } else {
      response.data.forEach((row) => {
        modalContent += `
                    <div class="salary-card">
                        <h3 class="salary-card-title">NGÀY ${new Date(row.date).toLocaleDateString(
                          'vi-VN'
                        )}</h3>
                        <div class="salary-section">
                            <div class="card-field">
                                <span class="label">Số khách/ ngày:</span>
                                <span class="section-total highlight">${row.customerCount}</span>
                            </div>
                        </div>
                        <div class="salary-section">
                            <div class="card-field">
                                <h4 class="label">Doanh số dịch vụ</h4>
                                <span class="section-service highlight">${formatCurrency(
                                  row.serviceTotal
                                )}</span>
                            </div>
                            <div class="card-field">
                                <span class="label">Truy thu:</span>
                                <span class="value">${formatCurrency(row.penaltyService)}</span>
                            </div>
                            <div class="section-header gray-bg">
                                <span class="section-title">Lương dịch vụ:</span>
                                <span class="section-total highlight">${formatCurrency(
                                  row.serviceSalary
                                )}</span>
                            </div>
                        </div>
                        <div class="salary-section">
                            <div class="card-field">
                                <h4 class="label">Doanh số hóa chất</h4>
                                <span class="section-service highlight">${formatCurrency(
                                  row.chemicalTotal
                                )}</span>
                            </div>
                            <div class="card-field">
                                <span class="label">Truy thu:</span>
                                <span class="value">${formatCurrency(row.penaltyChemical)}</span>
                            </div>
                            <div class="section-header gray-bg">
                                <span class="section-title">Lương hóa chất:</span>
                                <span class="section-total highlight">${formatCurrency(
                                  row.chemicalSalary
                                )}</span>
                            </div>
                        </div>
                        <div class="salary-section">
                            <div class="card-field">
                                <h4 class="label">Doanh số bán hàng</h4>
                                <span class="section-service highlight">${formatCurrency(
                                  row.productTotal
                                )}</span>
                            </div>
                        </div>
                    </div>
                `;
      });
    }

    cardsContainer.innerHTML = modalContent;
  } catch (error) {
    console.error('Error fetching check-in history:', error);
    const cardsContainer = modal.querySelector('.checkin-history-cards');
    cardsContainer.classList.remove('loading');
    cardsContainer.innerHTML = '<p>Có lỗi xảy ra khi tải dữ liệu.</p>';
  }
}

function createCashierSalaryCard(salary, isPersonalPage = false, role = 'Thu Ngân') {
  // Kiểm tra dữ liệu đầu vào
  if (!salary || typeof salary !== 'object') {
    console.error('Invalid salary data:', salary);
    const errorCard = document.createElement('div');
    errorCard.className = 'salary-card error';
    errorCard.innerHTML = '<div class="no-data">Lỗi: Dữ liệu lương không hợp lệ.</div>';
    return errorCard;
  }
  const yearSelect =
    document.getElementById('year-select') || document.getElementById('salary-year-select');
  const monthSelect =
    document.getElementById('month-select') || document.getElementById('salary-month-select');
  const period =
    yearSelect && monthSelect ? `${yearSelect.value}-${monthSelect.value}` : salary.period || '';
  const card = document.createElement('article');
  card.className = 'salary-card ps-card';
  card.setAttribute('data-staff', salary.staff_name || 'N/A');
  card.setAttribute('data-period', period);

  // Giữ tên cũ cho phần handler phía dưới
  const formatCurrency = psMoney;

  const paymentImages = psParsePayment(salary.payment);

  // Lương giờ công = giờ thử việc × lương giờ thử việc + giờ chính thức × lương giờ chính thức
  const probationHours = psNum(salary.probation_hours);
  const officialHours = psNum(salary.official_hours);
  const probationHourSalary = psNum(salary.probation_hourly_salary) * probationHours;
  const officialHourSalary = psNum(salary.official_hourly_salary) * officialHours;
  const hourSalaryTotal = probationHourSalary + officialHourSalary;
  // Fallback nếu không có dữ liệu mới
  const fallbackHourSalary = psNum(salary.total_salary) - psNum(salary.product_salary);
  const finalHourSalary =
    probationHourSalary > 0 || officialHourSalary > 0 ? hourSalaryTotal : fallbackHourSalary;
  // Tổng lương bao gồm product_salary
  const totalSalary = finalHourSalary + psNum(salary.product_salary) + psNum(psAdj(salary).bonus_total);
  const productRate = psRate(undefined, salary.product_salary, salary.product_total, 10);
  const cAtt = salary.attendance && typeof salary.attendance === 'object' ? salary.attendance : {};
  const status = psStatus(salary, isPersonalPage);
  const actions = psActions(salary, isPersonalPage);

  card.innerHTML = `
    ${psHeader({
      period,
      status,
      name: salary.staff_name,
      avatar: salary.avatar,
      roleLabel: `Thu ngân · ${psEsc(salary.level_name || 'Chưa có bậc')}${
        salary.level_start_date ? ` · từ ${psDate(salary.level_start_date)}` : ''
      }`,
      stats: [
        ['Giờ công', psQty(salary.total_hours), 'h'],
        ['Nghỉ phép', psQty(cAtt.leave_days ?? 0), '', psNum(cAtt.leave_days) > 0 ? 'muted' : ''],
        ['Đi trễ', psQty(cAtt.late_days ?? 0), '', psNum(cAtt.late_days) > 0 ? 'warn' : ''],
        ['Tăng ca', psQty(cAtt.overtime_days ?? 0), '', psNum(cAtt.overtime_days) > 0 ? 'pos' : ''],
      ],
      rates: {
        title: 'Mức lương',
        chips: [
          ['Giờ', `${psMoney(salary.hourly_salary)}/h`, ''],
          psNum(salary.standard_hours) > 0 ? ['Chuẩn', `${psQty(salary.standard_hours)}h`, ''] : null,
          ['SP', psPct(productRate), ''],
        ],
      },
    })}

    ${psHero({
      actual: salary.actual_salary,
      total: totalSalary,
      deductions: salary.total_of_deductions,
    })}

    <section class="ps-block">
      <h4 class="ps-block-title">Thu nhập</h4>
      ${
        probationHourSalary > 0 || officialHourSalary > 0
          ? `
        ${psLine({
          name: 'Giờ công thử việc',
          amount: probationHourSalary,
          sub:
            probationHours > 0
              ? `${psQty(probationHours)} giờ × ${psMoney(salary.probation_hourly_salary)}/giờ`
              : 'Không có giờ thử việc kỳ này',
          muted: probationHourSalary === 0,
        })}
        ${psLine({
          name: 'Giờ công chính thức',
          amount: officialHourSalary,
          sub:
            officialHours > 0
              ? `${psQty(officialHours)} giờ × ${psMoney(salary.official_hourly_salary)}/giờ`
              : 'Không có giờ chính thức kỳ này',
          muted: officialHourSalary === 0,
        })}`
          : psLine({
              name: 'Lương giờ công',
              amount: finalHourSalary,
              sub: `${psQty(salary.total_hours)} giờ × ${psMoney(salary.hourly_salary)}/giờ`,
              muted: finalHourSalary === 0,
            })
      }
      ${psLine({
        name: 'Bán sản phẩm',
        amount: salary.product_salary,
        sub:
          psNum(salary.product_total) === 0
            ? 'Không bán sản phẩm kỳ này'
            : `${psMoney(salary.product_total)} × ${psPct(productRate)}${
                salary.product_count_total !== undefined
                  ? ` · ${psQty(salary.product_count_total, 0)} sản phẩm`
                  : ''
              }`,
        muted: psNum(salary.product_salary) === 0,
      })}
      ${psAdjLines(salary, 'bonus')}
      ${psTotal('Tổng lương', totalSalary, 'ps-line--income')}
    </section>

    ${psDeductions(salary, totalSalary)}

    ${psActionButtons(salary, isPersonalPage, 'cashier', period)}
    ${psPaymentImages(paymentImages)}
  `;


  // Xử lý nút "Xem lịch sử"
  const historyButton = card.querySelector('.checkin-history-btn');
  historyButton.addEventListener('click', () => {
    showHistoryModalCashier(salary.staff_name, period, isPersonalPage);
  });

  // Xử lý nút "Lương TB" (admin only)
  const avgSalaryBtn = card.querySelector('.avg-salary-btn');
  if (avgSalaryBtn) {
    avgSalaryBtn.addEventListener('click', () => {
      showAverageSalaryModal(avgSalaryBtn.dataset.staff, avgSalaryBtn.dataset.role, avgSalaryBtn.dataset.period);
    });
  }

  // Hàm làm mới card lương và bảng
  const refreshSalaryCard = async (staffName, period) => {
    try {
      const response = await fetch(
        `${checkinData.restUrl}cashier-salary-data?type=salary&staff_name=${encodeURIComponent(
          staffName
        )}&period=${period}`,
        {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            'X-WP-Nonce': checkinData.nonce,
          },
        }
      );

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(
          `HTTP error! Status: ${response.status}, Message: ${errorData.message || 'Unknown error'}`
        );
      }

      const responseData = await response.json();
      if (responseData.success && responseData.data && responseData.data.length > 0) {
        const newSalaryData = responseData.data[0];

        // 1. Cập nhật card trong modal
        const newCard = createCashierSalaryCard(newSalaryData, isPersonalPage, role);
        const currentCard = document.querySelector(
          `.salary-card[data-staff="${staffName}"][data-period="${period}"]`
        );
        if (currentCard && currentCard.parentNode) {
          currentCard.parentNode.replaceChild(newCard, currentCard);
          window.dispatchEvent(new CustomEvent('ps:salary-updated', { detail: { staff: staffName, period, role, row: newSalaryData } }));
        } else {
          console.warn('Không tìm thấy card hiện tại để thay thế');
          const container = document.querySelector('.salary-card-container');
          if (container) container.appendChild(newCard);
        }

        // 2. Cập nhật bảng lương nếu đang ở trang admin
        if (!isPersonalPage) {
          const salaryRow = document.querySelector(
            `.salary-row[data-staff="${staffName}"][data-period="${period}"]`
          );
          if (salaryRow) {
            const formatCurrency = (value) => parseFloat(value || 0).toLocaleString('vi-VN') + ' đ';
            const getStatusDisplay = (status) => {
              switch (status) {
                case 'confirm pending':
                  return '<span class="status status-pending">Chờ xác nhận</span>';
                case 'confirmed':
                  return '<span class="status status-confirmed">Đã xác nhận</span>';
                case 'payment pending':
                  return '<span class="status status-payment-pending">Đã thanh toán</span>';
                case 'received':
                  return '<span class="status status-received">Đã nhận đủ</span>';
                default:
                  return '<span class="status status-pending">Chờ xác nhận</span>';
              }
            };

            // Cập nhật các cột trong bảng
            const cells = salaryRow.querySelectorAll('td');
            if (cells.length >= 8) {
              cells[1].textContent = newSalaryData.level_name || 'N/A';
              cells[2].textContent = formatCurrency(newSalaryData.total_salary);
              cells[3].textContent = formatCurrency(newSalaryData.total_of_deductions);
              cells[4].textContent = formatCurrency(newSalaryData.actual_salary);
              cells[5].innerHTML = getStatusDisplay(newSalaryData.status);
              cells[6].textContent = newSalaryData.xac_nhan_luong || 'N/A';
            }
          }
        }
      } else {
        throw new Error(responseData.message || 'Không tìm thấy dữ liệu lương mới');
      }
    } catch (error) {
      console.error('Error fetching updated salary:', error.message);
      showError('Lỗi khi tải dữ liệu lương mới: ' + error.message);
    }
  };

  // Nút "Thưởng / Trừ" (admin)
  card.querySelector('.adjustments-btn')?.addEventListener('click', () => {
    window.psAdjustModal?.open({
      staffName: salary.staff_name,
      role: 'Thu Ngân',
      period,
      onSaved: () => refreshSalaryCard(salary.staff_name, period),
    });
  });

  // Xử lý nút "Làm mới phiếu lương" với hiệu ứng loading
  if (actions.refresh) {
    const refreshButton = card.querySelector('.refresh-salary-btn');
    refreshButton?.addEventListener('click', async () => {
      psBtnLoading(refreshButton, true, 'Đang làm mới…');

      try {
        const updateResponse = await fetch(`${checkinData.restUrl}update-cashier-salary`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-WP-Nonce': checkinData.nonce,
          },
          body: JSON.stringify({
            period: period,
            staff_name: salary.staff_name,
          }),
        });

        if (!updateResponse.ok) {
          const errorData = await updateResponse.json();
          throw new Error(
            `HTTP error! Status: ${updateResponse.status}, Message: ${
              errorData.message || 'Unknown error'
            }`
          );
        }

        const updateData = await updateResponse.json();
        if (updateData.success) {
          toastSuccess('Làm mới phiếu lương thành công!');
          await refreshSalaryCard(salary.staff_name, period);
        } else {
          throw new Error(updateData.message || 'Lỗi không xác định từ server');
        }
      } catch (error) {
        console.error('Refresh salary error:', error.message);
        showError('Lỗi khi làm mới phiếu lương: ' + error.message);
      } finally {
        psBtnLoading(refreshButton, false);
      }
    });
  }

  // Xử lý nút "Đồng ý" (chỉ trên trang cá nhân)
  if (actions.confirm) {
    const confirmButton = card.querySelector('.confirm-btn');
    confirmButton?.addEventListener('click', async () => {
      try {
        const response = await fetch(`${checkinData.restUrl}confirm-salary`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-WP-Nonce': checkinData.nonce,
          },
          body: JSON.stringify({
            staff_name: salary.staff_name || 'N/A',
            period: period,
            role: role,
            action: 'approve',
          }),
        });

        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(
            `HTTP error! Status: ${response.status}, Message: ${
              errorData.message || 'Unknown error'
            }`
          );
        }

        const responseData = await response.json();
        if (responseData.success) {
          toastSuccess('Xác nhận lương thành công!');
          await refreshSalaryCard(salary.staff_name, period);
        } else {
          throw new Error(responseData.message || 'Lỗi không xác định từ server');
        }
      } catch (error) {
        console.error('Confirm salary error:', error.message);
        showError('Lỗi khi xác nhận lương: ' + error.message);
      }
    });
  }

  // Xử lý nút "Xin xét lại" (chỉ trên trang cá nhân)
  if (actions.review) {
    const reviewButton = card.querySelector('.review-btn');
    reviewButton?.addEventListener('click', async () => {
      try {
        const response = await fetch(`${checkinData.restUrl}confirm-salary`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-WP-Nonce': checkinData.nonce,
          },
          body: JSON.stringify({
            staff_name: salary.staff_name || 'N/A',
            period: period,
            role: role,
            action: 'reconsider',
          }),
        });

        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(
            `HTTP error! Status: ${response.status}, Message: ${
              errorData.message || 'Unknown error'
            }`
          );
        }

        const responseData = await response.json();
        if (responseData.success) {
          toastSuccess('Yêu cầu xét lại lương đã được gửi!');
          // Gọi hàm làm mới card với dữ liệu mới
          await refreshSalaryCard(salary.staff_name, period);
        } else {
          throw new Error(responseData.message || 'Lỗi không xác định từ server');
        }
      } catch (error) {
        console.error('Request review error:', error.message);
        showError('Lỗi khi gửi yêu cầu xét lại: ' + error.message);
      }
    });
  }

  // Xử lý nút "Đã nhận đủ" (chỉ trên trang cá nhân)
  if (actions.received) {
    const paymentConfirmedButton = card.querySelector('.payment-confirmed-btn');
    paymentConfirmedButton.addEventListener('click', async () => {
      try {
        const response = await fetch(`${checkinData.restUrl}confirm-salary-payment`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-WP-Nonce': checkinData.nonce,
          },
          body: JSON.stringify({
            staff_name: salary.staff_name || 'N/A',
            period: period,
            role: role,
            payment_confirmed: 'received',
          }),
        });

        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(
            `HTTP error! Status: ${response.status}, Message: ${
              errorData.message || 'Unknown error'
            }`
          );
        }

        const responseData = await response.json();
        if (responseData.success) {
          toastSuccess('Xác nhận đã nhận đủ thành công!');
          // Gọi hàm làm mới card với dữ liệu mới
          await refreshSalaryCard(salary.staff_name, period);
          paymentConfirmedButton.remove();
          // Thêm nút Đã thanh toán
          const actionsDiv = card.querySelector('.card-actions');
          const paidBtn = document.createElement('button');
          paidBtn.className = 'paid-btn';
          paidBtn.disabled = true;
          paidBtn.textContent = 'Đã thanh toán';
          actionsDiv.appendChild(paidBtn);
        } else {
          throw new Error(responseData.message || 'Lỗi không xác định từ server');
        }
      } catch (error) {
        console.error('Payment confirmation error:', error.message);
        showError('Lỗi khi xác nhận thanh toán: ' + error.message);
      }
    });
  }

  // Xử lý upload hình ảnh thanh toán (chỉ dành cho admin)
  if (actions.upload) {
    const uploadButton = card.querySelector('.upload-payment-btn');
    const fileInput = card.querySelector('.upload-payment-input');

    uploadButton.addEventListener('click', () => {
      fileInput.click();
    });

    fileInput.addEventListener('change', async () => {
      const files = fileInput.files;
      if (!files || files.length === 0) {
        showWarning('Vui lòng chọn ít nhất một hình ảnh thanh toán.');
        return;
      }

      const formData = new FormData();
      for (let i = 0; i < files.length; i++) {
        formData.append('payment_images[]', files[i]);
      }
      formData.append('staff_name', salary.staff_name);
      formData.append('period', period);
      formData.append('role', role);

      try {
        const response = await fetch(`${checkinData.restUrl}upload-payment-images`, {
          method: 'POST',
          headers: { 'X-WP-Nonce': checkinData.nonce },
          body: formData,
        });

        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(
            `HTTP error! Status: ${response.status}, Message: ${
              errorData.message || 'Unknown error'
            }`
          );
        }

        const responseData = await response.json();
        if (responseData.success) {
          alert('Ảnh thanh toán đã được tải lên thành công!');
          await refreshSalaryCard(salary.staff_name, period);
        } else {
          throw new Error(responseData.message || 'Lỗi không xác định từ server');
        }
      } catch (error) {
        console.error('Fetch error:', error.message);
        alert('Lỗi khi tải ảnh thanh toán: ' + error.message);
      }
    });
  }

  return card;
}

async function showHistoryModalCashier(staffName, period, isPersonalPage = false) {
  // Tạo modal
  const modal = document.createElement('div');
  modal.style.zIndex = '1300'; // nổi trên modal phiếu lương (1100) và ps-modal (1200)
  modal.className = 'checkin-mkt-popup';
  modal.id = 'checkin-mkt-staff-checkin-popup';
  modal.style.display = 'none'; // Ẩn ban đầu để thêm animation

  // Tính start_date và end_date từ period
  const [year, month] = period.split('-');
  const startDate = `${year}-${month}-01`;
  const endDay = new Date(year, parseInt(month), 0).getDate();
  const endDate = `${year}-${month}-${String(endDay).padStart(2, '0')}`;

  // Tạo nội dung modal với loading spinner
  modal.innerHTML = `
        <div class="modal-content">
            <button class="close-modal-btn">x</button>
            <h2>${staffName} - Tháng ${period.split('-')[1]}/${period.split('-')[0]}</h2>
            <div class="checkin-history-cards loading">
                <p>Đang tải dữ liệu...</p>
            </div>
        </div>
    `;

  // Thêm modal vào body
  document.body.appendChild(modal);

  // Hiển thị modal với animation
  setTimeout(() => {
    modal.style.display = 'block';
    requestAnimationFrame(() => {
      modal.classList.add('show');
    });
  }, 10);

  // Xử lý nút đóng
  const closeModal = () => {
    modal.classList.remove('show');
    setTimeout(() => modal.remove(), 300); // Đợi animation hoàn tất
  };

  const closeBtn = modal.querySelector('button');
  closeBtn.addEventListener('click', closeModal);

  modal.addEventListener('click', (e) => {
    if (e.target === modal) closeModal();
  });

  // Gọi API
  try {
    const currentUserRole = await getCurrentUserRole(isPersonalPage);
    const response = await fetch(
      `${checkinData.restUrl}employee-checkin-logs/0?display_name=${encodeURIComponent(
        staffName
      )}&start_date=${encodeURIComponent(startDate)}&end_date=${encodeURIComponent(
        endDate
      )}&current_user_role=${encodeURIComponent(currentUserRole)}`,
      {
        method: 'GET',
        headers: { 'X-WP-Nonce': checkinData.nonce },
      }
    ).then((res) => res.json());

    const cardsContainer = modal.querySelector('.checkin-history-cards');
    cardsContainer.classList.remove('loading');

    if (response.success) {
      const checkinHistory =
        response.data
          .map((log) => {
            const checkinDate = log.checkin_time ? new Date(log.checkin_time) : null;
            const dateDisplay =
              checkinDate && !isNaN(checkinDate) ? checkinDate.toLocaleDateString('vi-VN') : 'N/A';
            const checkinTimeDisplay =
              checkinDate && !isNaN(checkinDate)
                ? checkinDate.toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' })
                : 'N/A';
            const checkoutTimeDisplay =
              log.checkout_time && log.checkout_time !== 'N/A'
                ? new Date(log.checkout_time).toLocaleTimeString('vi-VN', {
                    hour: '2-digit',
                    minute: '2-digit',
                  })
                : '-';
            const standardHours = parseFloat(log.standard_hours || 0);
            const standardHoursDisplay = !isNaN(standardHours) ? standardHours.toFixed(2) : '0.00';
            const totalHours = parseFloat(log.total_hours || 0);
            const totalHoursDisplay = !isNaN(totalHours) ? totalHours.toFixed(2) : '0.00';
            const overtimeMinutes = parseInt(log.overtime_minutes || 0);
            const overtimeDisplay = overtimeMinutes > 0 ? `${overtimeMinutes} phút` : '0 phút';
            const overtimeStatusDisplay =
              log.approval_ot === 'Approved'
                ? 'Duyệt'
                : log.approval_ot
                  ? 'Không duyệt'
                  : 'Không có';
            const lateStatusDisplay =
              log.approval_late === 'Approved'
                ? 'Có phép'
                : log.approval_late
                  ? 'Không phép'
                  : 'Không có';

            return `
                    <div class="checkin-card">
                        <div><span class="label">Ngày:</span><span class="value">${dateDisplay}</span></div>
                        <div><span class="label">Ca làm:</span><span class="value">${
                          log.shift || 'N/A'
                        }</span></div>
                        <div><span class="label">Giờ vào:</span><span class="value">${checkinTimeDisplay}</span></div>
                        <div><span class="label">Giờ ra:</span><span class="value">${checkoutTimeDisplay}</span></div>
                        <div><span class="label">Tổng giờ tạm tính:</span><span class="value">${standardHoursDisplay} giờ</span></div>
                        <div><span class="label">Tăng ca:</span><span class="value">${overtimeDisplay}</span></div>
                        <div><span class="label">Đơn tăng ca:</span><span class="value">${overtimeStatusDisplay}</span></div>
                        <div><span class="label">Tổng giờ (đã tính tăng ca):</span><span class="total-hours">${totalHoursDisplay} giờ</span></div>
                        <div><span class="label">Đơn đi trễ:</span><span class="value">${lateStatusDisplay}</span></div>
                        <div><span class="label">Trạng thái:</span><span class="value">${
                          log.status_late == 1
                            ? `<span class="status-late">Trễ ${log.late_minutes} phút</span>`
                            : log.status_early == 1
                              ? '<span class="status-early">Tăng ca</span>'
                              : '<span class="status-normal">Đúng giờ</span>'
                        }</span></div>
                        <div><span class="label">Phạt:</span><span class="value">${
                          parseFloat(log.penalty_amount) > 0
                            ? Math.floor(parseFloat(log.penalty_amount)).toLocaleString('vi-VN') +
                              ' VNĐ'
                            : '0 VNĐ'
                        }</span></div>
                        <div><span class="label">Địa điểm:</span><span class="value">${
                          log.location_name || 'N/A'
                        }</span></div>
                    </div>
                `;
          })
          .join('') || '<p>Không có dữ liệu điểm danh cho tháng này.</p>';
      cardsContainer.innerHTML = checkinHistory;
    } else {
      cardsContainer.innerHTML = `<p>Lỗi: ${response.message}</p>`;
    }
  } catch (error) {
    console.error('Error fetching check-in history:', error);
    const cardsContainer = modal.querySelector('.checkin-history-cards');
    cardsContainer.classList.remove('loading');
    cardsContainer.innerHTML = '<p>Có lỗi xảy ra khi tải dữ liệu.</p>';
  }
}

/**
 * Modal lương trung bình 12 tháng (Admin only)
 * Hiển thị bảng lịch sử lương + phép tính trung bình
 */
async function showAverageSalaryModal(staffName, role, period) {
  const year = period ? period.split('-')[0] : new Date().getFullYear();
  const formatCurrency = (value) => parseFloat(value || 0).toLocaleString('vi-VN') + ' đ';

  // Tạo modal container
  const existingModal = document.querySelector('.avg-salary-modal');
  if (existingModal) existingModal.remove();

  const modal = document.createElement('div');
  modal.style.zIndex = '1300'; // nổi trên modal phiếu lương (1100) và ps-modal (1200)
  modal.className = 'avg-salary-modal';
  modal.innerHTML = `
    <div class="avg-salary-modal-overlay"></div>
    <div class="avg-salary-modal-content">
      <div class="avg-salary-modal-header">
        <h3><span class="avg-icon">📊</span> Lương trung bình</h3>
        <span class="avg-staff-name">${staffName}</span>
        <button class="avg-salary-close-btn" title="Đóng">✕</button>
      </div>
      <div class="avg-salary-modal-body">
        <div class="avg-salary-loading">
          <div class="avg-salary-spinner"></div>
          <p>Đang tải dữ liệu...</p>
        </div>
      </div>
    </div>
  `;

  document.body.appendChild(modal);

  // Animation: show
  requestAnimationFrame(() => {
    modal.classList.add('show');
  });

  // Close handlers
  const closeModal = () => {
    modal.classList.remove('show');
    modal.classList.add('hiding');
    setTimeout(() => modal.remove(), 300);
  };

  modal.querySelector('.avg-salary-close-btn').addEventListener('click', closeModal);
  modal.querySelector('.avg-salary-modal-overlay').addEventListener('click', closeModal);

  // Fetch data
  try {
    const response = await fetch(
      `${checkinData.restUrl}average-salary?staff_name=${encodeURIComponent(staffName)}&role=${role}&year=${year}`,
      {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'X-WP-Nonce': checkinData.nonce,
        },
      }
    );

    if (!response.ok) {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }

    const data = await response.json();

    if (!data.success) {
      throw new Error(data.message || 'Không tìm thấy dữ liệu');
    }

    const { monthly_data, months_count, total_actual, average_salary } = data;

    // Format tháng hiển thị
    const formatPeriod = (period) => {
      const [y, m] = period.split('-');
      return `T${parseInt(m)}/${y}`;
    };

    // Build bảng dữ liệu
    const tableRows = monthly_data.map((item, index) => `
      <tr class="avg-salary-row" style="animation-delay: ${index * 0.04}s">
        <td class="avg-td-index">${index + 1}</td>
        <td class="avg-td-period">${formatPeriod(item.period)}</td>
        <td class="avg-td-total">${formatCurrency(item.total_salary)}</td>
        <td class="avg-td-deductions">${formatCurrency(item.total_of_deductions)}</td>
        <td class="avg-td-actual">${formatCurrency(item.actual_salary)}</td>
      </tr>
    `).join('');

    // Build phép tính
    const salaryParts = monthly_data.map(item => formatCurrency(item.actual_salary)).join(' + ');

    const body = modal.querySelector('.avg-salary-modal-body');
    body.innerHTML = `
      <div class="avg-salary-table-wrap">
        <table class="avg-salary-table">
          <thead>
            <tr>
              <th>#</th>
              <th>Tháng</th>
              <th>Tổng lương</th>
              <th>Khấu trừ</th>
              <th>Thực nhận</th>
            </tr>
          </thead>
          <tbody>
            ${tableRows}
          </tbody>
          <tfoot>
            <tr class="avg-salary-total-row">
              <td colspan="4"><strong>Tổng cộng (${months_count} tháng)</strong></td>
              <td><strong>${formatCurrency(total_actual)}</strong></td>
            </tr>
          </tfoot>
        </table>
      </div>

      <div class="avg-salary-formula">
        <div class="avg-formula-label">Phép tính:</div>
        <div class="avg-formula-expression">
          <span class="avg-formula-parts">${salaryParts}</span>
          <span class="avg-formula-divider">÷ ${months_count} tháng</span>
        </div>
      </div>

      <div class="avg-salary-result">
        <div class="avg-result-label">LƯƠNG TRUNG BÌNH</div>
        <div class="avg-result-value">${formatCurrency(average_salary)}</div>
        <div class="avg-result-note">${months_count} tháng gần nhất</div>
      </div>
    `;

  } catch (error) {
    console.error('Average salary error:', error);
    const body = modal.querySelector('.avg-salary-modal-body');
    body.innerHTML = `
      <div class="avg-salary-error">
        <span class="avg-error-icon">⚠️</span>
        <p>${error.message || 'Không thể tải dữ liệu lương'}</p>
      </div>
    `;
  }
}

// Hàm fetchAPI tiện ích
async function fetchAPI(endpoint, options = {}) {
  const defaultOptions = {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
      'X-WP-Nonce': checkinData.nonce,
    },
  };

  const mergedOptions = { ...defaultOptions, ...options };
  const response = await fetch(`${checkinData.restUrl}${endpoint}`, mergedOptions);

  if (!response.ok) {
    throw new Error(`HTTP error! Status: ${response.status}`);
  }

  return response.json();
}


/* ============================================================
   TRANG PHIẾU LƯƠNG (trang cá nhân, ?view=salary) — psSalaryPage
   Chọn kỳ → tự tải, mặc định kỳ hiện tại; server tự tính kỳ đang chạy.
   ============================================================ */
window.psSalaryPage = (() => {
  const MONTHS_BACK = 12;
  const state = { staff: '', role: '', period: '', open: false, pushed: false, loading: null };

  const el = (id) => document.getElementById(id);
  const pad2 = (n) => String(n).padStart(2, '0');
  const curPeriod = () => {
    const d = new Date();
    return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}`;
  };
  const isPeriod = (p) => /^\d{4}-(0[1-9]|1[0-2])$/.test(p || '');
  const listPeriods = () => {
    const out = [];
    const d = new Date();
    d.setDate(1);
    for (let i = 0; i < MONTHS_BACK; i++) {
      out.push(`${d.getFullYear()}-${pad2(d.getMonth() + 1)}`);
      d.setMonth(d.getMonth() - 1);
    }
    return out;
  };
  const urlFor = (period) => {
    const u = new URL(window.location.href);
    u.searchParams.set('view', 'salary');
    u.searchParams.set('period', period);
    return u.pathname + u.search;
  };
  const endpointFor = (role) =>
    role === 'Thu Ngân' ? 'cashier-salary-data' : 'hairdresser-salary-data';

  const YEARS_BACK = 5;

  function renderPicker() {
    const monthSel = el('salary-month-select');
    const yearSel = el('salary-year-select');
    if (!monthSel || !yearSel) return;
    const [y, m] = state.period.split('-');
    if (!monthSel.options.length) {
      monthSel.innerHTML = Array.from({ length: 12 }, (_, i) => {
        const mm = pad2(i + 1);
        return `<option value="${mm}">Tháng ${i + 1}</option>`;
      }).join('');
      monthSel.addEventListener('change', onPick);
    }
    const thisYear = new Date().getFullYear();
    const minYear = Math.min(thisYear - YEARS_BACK, parseInt(y, 10));
    const wanted = [];
    for (let yy = thisYear; yy >= minYear; yy--) wanted.push(String(yy));
    const have = [...yearSel.options].map((o) => o.value).join(',');
    if (have !== wanted.join(',')) {
      yearSel.innerHTML = wanted.map((yy) => `<option value="${yy}">${yy}</option>`).join('');
      if (!yearSel.dataset.bound) {
        yearSel.addEventListener('change', onPick);
        yearSel.dataset.bound = '1';
      }
    }
    monthSel.value = m;
    yearSel.value = y;
    el('salary-period-picker')?.classList.toggle('is-current', state.period === curPeriod());
    fitSelect(monthSel);
    fitSelect(yearSel);
    requestAnimationFrame(() => {
      fitSelect(monthSel);
      fitSelect(yearSel);
    });
  }

  // Picker sống ở thanh trên; có phiếu thì chui vào chỗ "Tháng MM/YYYY" của phiếu cho khỏi lặp.
  function parkPicker() {
    const picker = el('salary-period-picker');
    const bar = el('salary-page-bar');
    if (picker && bar && picker.parentElement !== bar) bar.appendChild(picker);
    picker?.classList.remove('ps-period-picker--inline');
    requestAnimationFrame(() => {
      fitSelect(el('salary-month-select'));
      fitSelect(el('salary-year-select'));
    });
  }

  function mountPickerInCard(card) {
    const picker = el('salary-period-picker');
    const slot = card?.querySelector('[data-ps-period-slot]');
    if (!picker || !slot) return;
    slot.textContent = '';
    slot.appendChild(picker);
    picker.classList.add('ps-period-picker--inline');
    fitSelect(el('salary-month-select'));
    fitSelect(el('salary-year-select'));
    requestAnimationFrame(() => {
      fitSelect(el('salary-month-select'));
      fitSelect(el('salary-year-select'));
    });
  }

  // Select gốc rộng theo option dài nhất ("Tháng 12") → đo chữ đang chọn để mũi tên sát chữ
  function fitSelect(sel) {
    if (!sel || !sel.options.length) return;
    const probe = document.createElement('span');
    const cs = getComputedStyle(sel);
    probe.style.cssText = `position:absolute;visibility:hidden;white-space:nowrap;font:${cs.font};letter-spacing:${cs.letterSpacing}`;
    probe.textContent = sel.options[sel.selectedIndex]?.text || '';
    document.body.appendChild(probe);
    const pad = parseFloat(cs.paddingLeft) + parseFloat(cs.paddingRight);
    sel.style.width = `${Math.ceil(probe.getBoundingClientRect().width + pad + 3)}px`;
    probe.remove();
  }

  function onPick() {
    const m = el('salary-month-select')?.value;
    const y = el('salary-year-select')?.value;
    if (m && y) select(`${y}-${m}`);
  }

  function setNote(html, kind = 'info') {
    const note = el('salary-page-note');
    if (!note) return;
    if (!html) {
      note.hidden = true;
      note.innerHTML = '';
      return;
    }
    note.className = `ps-page-note ps-page-note--${kind}`;
    note.innerHTML = html;
    note.hidden = false;
  }

  async function load(period) {
    const body = el('salary-cards-body');
    if (!body || !state.staff) return;
    const token = (state.loading = Symbol('load'));
    parkPicker(); // body.innerHTML sắp bị thay — picker phải rời khỏi phiếu cũ trước
    body.innerHTML = `<div class="ps-skeleton" aria-busy="true"><div></div><div></div><div></div></div>`;
    setNote('');
    try {
      const res = await fetch(
        `${checkinData.restUrl}${endpointFor(state.role)}?type=salary&period=${encodeURIComponent(
          period
        )}&staff_name=${encodeURIComponent(state.staff)}`,
        { method: 'GET', headers: { 'X-WP-Nonce': checkinData.nonce }, credentials: 'include' }
      );
      const result = await res.json();
      if (state.loading !== token) return; // đã chuyển kỳ khác
      body.innerHTML = '';
      const rows = result && result.success && Array.isArray(result.data) ? result.data : [];
      if (!rows.length) {
        body.innerHTML = `<div class="ps-empty">
            <div class="ps-empty-title">Chưa có phiếu lương ${psPeriodLabel(period).toLowerCase()}</div>
            <div class="ps-empty-sub">${
              period > curPeriod()
                ? 'Kỳ này chưa bắt đầu.'
                : 'Chưa có hoá đơn hoặc chấm công nào trong kỳ, hoặc bạn chưa được gán bậc lương.'
            }</div>
          </div>`;
        return;
      }
      rows.forEach((salary) => {
        const card =
          state.role === 'Thu Ngân'
            ? createCashierSalaryCard(salary, true, state.role)
            : createHairdresserSalaryCard(salary, true, state.role);
        body.appendChild(card);
      });
      if (rows.length === 1) mountPickerInCard(body.firstElementChild);
      const locked = rows.some((r) => r.xac_nhan_luong === 'Đồng ý' || r.payment);
      if (period === curPeriod() && !locked) {
        setNote(
          '<i class="fas fa-sync-alt"></i><span><b>Kỳ đang chạy.</b> Số liệu tạm tính, tự cập nhật theo hoá đơn và chấm công mỗi lần bạn mở phiếu.</span>'
        );
      } else if (!locked && result.auto_computed) {
        setNote('<i class="fas fa-sync-alt"></i><span>Phiếu vừa được tính lại theo dữ liệu mới nhất.</span>');
      }
    } catch (error) {
      if (state.loading !== token) return;
      console.error('Error fetching salary:', error);
      body.innerHTML = `<div class="ps-empty ps-empty--error"><div class="ps-empty-title">Không tải được phiếu lương</div><div class="ps-empty-sub">Kiểm tra kết nối rồi thử lại.</div></div>`;
    }
  }

  function select(period) {
    if (!isPeriod(period) || period === state.period) return;
    state.period = period;
    renderPicker();
    if (state.pushed) window.history.replaceState({ psSalary: true }, '', urlFor(period));
    load(period);
  }

  function toggleProfile(show) {
    document.querySelectorAll('.checkin-mkt-user-profile-container').forEach((c) => {
      c.classList.toggle('ps-hidden', !show);
    });
  }

  function open({ staff, role, period, push = true } = {}) {
    const page = el('salary-page');
    if (!page || !staff) return;
    state.staff = staff;
    state.role = role || '';
    state.period = isPeriod(period) ? period : curPeriod();
    state.open = true;
    toggleProfile(false);
    page.hidden = false;
    window.scrollTo({ top: 0 });
    if (push) {
      window.history.pushState({ psSalary: true }, '', urlFor(state.period));
      state.pushed = true;
    } else {
      window.history.replaceState({ psSalary: true }, '', urlFor(state.period));
      state.pushed = true;
    }
    renderPicker();
    load(state.period);
  }

  function close({ fromPop = false } = {}) {
    const page = el('salary-page');
    if (!page) return;
    state.open = false;
    page.hidden = true;
    toggleProfile(true);
    if (!fromPop) {
      if (state.pushed && window.history.state && window.history.state.psSalary) {
        window.history.back();
      } else {
        window.history.replaceState({}, '', window.location.pathname);
      }
    }
    state.pushed = false;
  }

  window.addEventListener('popstate', () => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('view') === 'salary') {
      if (state.staff) {
        state.pushed = true;
        if (!state.open) open({ staff: state.staff, role: state.role, period: params.get('period'), push: false });
        else select(params.get('period'));
      }
    } else if (state.open) {
      close({ fromPop: true });
    }
  });

  return { open, close, select, curPeriod, isOpen: () => state.open };
})();


/* ============================================================
   THẺ HOA HỒNG THEO KỲ (admin) — psRatesModal
   GET/POST/DELETE vg/v1/salary-period-rates
   ============================================================ */
window.psRatesModal = (() => {
  const KPI = [
    ['feedback', 'Đánh giá Google Maps'],
    ['post_fb', 'Đăng bài Facebook'],
    ['service', 'Doanh số dịch vụ'],
    ['product', 'Bán sản phẩm'],
  ];
  const SCOPE = [
    ['service', 'Dịch vụ cắt'],
    ['chemical', 'Hoá chất'],
    ['both', 'Cả dịch vụ và hoá chất'],
  ];
  const SOURCE_TEXT = {
    manual: 'Thẻ riêng của kỳ này',
    carried: 'Kế thừa từ kỳ trước',
    level: 'Chưa có thẻ — đang tính theo cấp bậc',
  };
  let root = null;
  let ctx = null;

  const api = (method, body) =>
    fetch(`${checkinData.restUrl}salary-period-rates${method === 'GET' ? `?period=${encodeURIComponent(body.period)}&staff_name=${encodeURIComponent(body.staff_name)}` : ''}`, {
      method,
      headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': checkinData.nonce },
      credentials: 'include',
      body: method === 'GET' ? undefined : JSON.stringify(body),
    }).then(async (r) => {
      const j = await r.json().catch(() => ({}));
      if (!r.ok || j.success === false) throw new Error(j.message || `HTTP ${r.status}`);
      return j;
    });

  const num = (id) => parseFloat(root.querySelector(`#${id}`).value || 0);

  function ensureRoot() {
    if (root) return root;
    root = document.createElement('div');
    root.className = 'ps-modal';
    root.hidden = true;
    root.innerHTML = `
      <div class="ps-modal-backdrop" data-close></div>
      <div class="ps-modal-sheet" role="dialog" aria-modal="true" aria-labelledby="ps-rates-title">
        <div class="ps-modal-head">
          <div>
            <div class="ps-eyebrow">Thẻ hoa hồng</div>
            <h3 id="ps-rates-title" class="ps-modal-title">—</h3>
            <div class="ps-modal-sub" id="ps-rates-source"></div>
          </div>
          <button type="button" class="ps-modal-close" data-close aria-label="Đóng">×</button>
        </div>
        <div class="ps-modal-body" id="ps-rates-body"></div>
        <div class="ps-modal-foot" id="ps-rates-foot"></div>
      </div>`;
    document.body.appendChild(root);
    root.addEventListener('click', (e) => {
      if (e.target.closest('[data-close]')) close();
    });
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && !root.hidden) close();
    });
    return root;
  }

  function fieldPct(id, label, value, hint = '') {
    return `<label class="ps-field"><span>${label}</span>
      <div class="ps-input-wrap"><input type="number" id="${id}" min="0" max="100" step="0.5" value="${value}"><b>%</b></div>
      ${hint ? `<small>${hint}</small>` : ''}</label>`;
  }

  function render(entry) {
    const r = entry.rates;
    const locked = entry.locked;
    root.querySelector('#ps-rates-title').textContent = `${entry.staff_name} · ${psPeriodLabel(entry.period)}`;
    root.querySelector('#ps-rates-source').innerHTML = `<span class="ps-tag ps-tag--${entry.source}">${SOURCE_TEXT[entry.source] || entry.source}</span>${
      entry.source === 'carried' && r.from_period ? ` <span class="ps-muted">từ ${r.from_period.split('-').reverse().join('/')}</span>` : ''
    }${locked ? ' <span class="ps-tag ps-tag--locked">Phiếu đã chốt · chỉ xem</span>' : ''}`;

    root.querySelector('#ps-rates-body').innerHTML = `
      <fieldset class="ps-fieldset" ${locked ? 'disabled' : ''}>
        <legend>Hoa hồng</legend>
        <div class="ps-grid-2">
          ${fieldPct('psr-service', 'Dịch vụ cắt', r.service_percent)}
          ${fieldPct('psr-chemical', 'Hoá chất', r.chemical_percent)}
          ${fieldPct('psr-product', 'Bán sản phẩm', r.product_percent)}
          <label class="ps-field"><span>Bán từ … sản phẩm mới hưởng</span>
            <div class="ps-input-wrap"><input type="number" id="psr-minqty" min="0" step="1" value="${r.product_min_qty}"><b>SP</b></div>
            <small>Dưới ngưỡng thì hoa hồng sản phẩm = 0</small></label>
          ${fieldPct('psr-overtime', 'Tăng ca', r.overtime_percent)}
        </div>
      </fieldset>
      <fieldset class="ps-fieldset" ${locked ? 'disabled' : ''}>
        <legend>KPI bắt buộc</legend>
        <div class="ps-checks">
          ${KPI.map(([k, label]) => `<label class="ps-check"><input type="checkbox" name="psr-kpi" value="${k}" ${r.kpi_required.includes(k) ? 'checked' : ''}><span>${label}</span></label>`).join('')}
        </div>
        <div class="ps-grid-2">
          ${fieldPct('psr-penalty', 'Không đạt thì trừ', r.kpi_penalty_percent, 'Điểm % trừ khỏi hoa hồng')}
          <label class="ps-field"><span>Trừ trên</span>
            <div class="ps-input-wrap"><select id="psr-scope">${SCOPE.map(([v, l]) => `<option value="${v}" ${r.kpi_penalty_scope === v ? 'selected' : ''}>${l}</option>`).join('')}</select></div>
            <small>Chỉ áp khi kỳ đã được "Đánh giá KPI"</small></label>
          <label class="ps-field ps-field--wide"><span>Trượt nhiều KPI</span>
            <div class="ps-input-wrap"><select id="psr-mode">
              <option value="once" ${r.kpi_penalty_mode !== 'each' ? 'selected' : ''}>Trừ một lần (mặc định)</option>
              <option value="each" ${r.kpi_penalty_mode === 'each' ? 'selected' : ''}>Cộng dồn theo số KPI trượt</option>
            </select></div></label>
        </div>
      </fieldset>
      <fieldset class="ps-fieldset" ${locked ? 'disabled' : ''}>
        <legend>Ghi chú</legend>
        <input type="text" id="psr-note" class="ps-text" maxlength="255" placeholder="VD: tăng hoá chất +5% tháng đẩy nhuộm" value="${psEsc(r.note || '')}">
        <label class="ps-check ps-check--apply"><input type="checkbox" id="psr-apply-all"><span>Áp thẻ này cho <b>tất cả thợ</b> kỳ ${psPeriodLabel(entry.period).toLowerCase()} (bỏ qua phiếu đã chốt)</span></label>
      </fieldset>
      <p class="ps-help">Kỳ sau không có thẻ riêng sẽ <b>kế thừa</b> thẻ này. Lưu xong lương kỳ này được tính lại ngay.</p>`;

    root.querySelector('#ps-rates-foot').innerHTML = locked
      ? `<span class="ps-help ps-help--inline">Kỳ đã trả lương không sửa được — thay đổi chỉ áp từ kỳ sau.</span><span class="ps-spacer"></span>
         <button type="button" class="ps-btn ps-btn--ghost" data-close>Đóng</button>
         <button type="button" class="ps-btn ps-btn--primary" id="psr-next">Mở thẻ kỳ sau</button>`
      : `${entry.source !== 'level' ? `<button type="button" class="ps-btn ps-btn--danger" id="psr-delete">Xoá thẻ kỳ này</button>` : ''}
         <span class="ps-spacer"></span>
         <button type="button" class="ps-btn ps-btn--ghost" data-close>Huỷ</button>
         <button type="button" class="ps-btn ps-btn--primary" id="psr-save">Lưu &amp; tính lại lương</button>`;

    root.querySelector('#psr-save')?.addEventListener('click', save);
    root.querySelector('#psr-delete')?.addEventListener('click', remove);
    root.querySelector('#psr-next')?.addEventListener('click', () => {
      const [y, m] = entry.period.split('-').map((v) => parseInt(v, 10));
      const d = new Date(y, m, 1); // tháng kế tiếp
      open({ staffName: ctx.staffName, period: `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`, onSaved: ctx.onSaved });
    });
  }

  async function save() {
    const btn = root.querySelector('#psr-save');
    psBtnLoading(btn, true, 'Đang lưu…');
    try {
      const body = {
        staff_name: ctx.staffName,
        period: ctx.period,
        service_percent: num('psr-service'),
        chemical_percent: num('psr-chemical'),
        product_percent: num('psr-product'),
        product_min_qty: parseInt(root.querySelector('#psr-minqty').value || 0, 10),
        overtime_percent: num('psr-overtime'),
        kpi_required: [...root.querySelectorAll('input[name="psr-kpi"]:checked')].map((i) => i.value),
        kpi_penalty_percent: num('psr-penalty'),
        kpi_penalty_scope: root.querySelector('#psr-scope').value,
        kpi_penalty_mode: root.querySelector('#psr-mode')?.value || 'once',
        note: root.querySelector('#psr-note').value.trim(),
        apply_all: root.querySelector('#psr-apply-all').checked,
      };
      const res = await api('POST', body);
      (window.toastSuccess || alert)(res.message || 'Đã lưu thẻ hoa hồng');
      close();
      ctx.onSaved?.(res);
    } catch (e) {
      (window.showError || alert)('Không lưu được: ' + e.message);
      psBtnLoading(btn, false);
    }
  }

  async function remove() {
    if (!confirm('Xoá thẻ hoa hồng kỳ này? Lương sẽ tính lại theo kỳ trước (hoặc cấp bậc nếu không có).')) return;
    try {
      const res = await api('DELETE', { staff_name: ctx.staffName, period: ctx.period });
      (window.toastSuccess || alert)(res.message || 'Đã xoá thẻ');
      close();
      ctx.onSaved?.(res);
    } catch (e) {
      (window.showError || alert)('Không xoá được: ' + e.message);
    }
  }

  async function open({ staffName, period, onSaved }) {
    ensureRoot();
    ctx = { staffName, period, onSaved };
    root.hidden = false;
    document.body.classList.add('ps-modal-open');
    root.querySelector('#ps-rates-title').textContent = `${staffName} · ${psPeriodLabel(period)}`;
    root.querySelector('#ps-rates-source').textContent = 'Đang tải…';
    root.querySelector('#ps-rates-body').innerHTML = '<div class="ps-skeleton"><div></div><div></div><div></div></div>';
    root.querySelector('#ps-rates-foot').innerHTML = '';
    try {
      const res = await api('GET', { staff_name: staffName, period });
      const entry = (res.data || [])[0];
      if (!entry) throw new Error('Không tìm thấy thợ này');
      render(entry);
    } catch (e) {
      root.querySelector('#ps-rates-source').textContent = '';
      root.querySelector('#ps-rates-body').innerHTML = `<div class="ps-empty ps-empty--error"><div class="ps-empty-title">Không tải được thẻ hoa hồng</div><div class="ps-empty-sub">${psEsc(e.message)}</div></div>`;
      root.querySelector('#ps-rates-foot').innerHTML = `<button type="button" class="ps-btn ps-btn--ghost" data-close>Đóng</button>`;
    }
  }

  function close() {
    if (!root) return;
    root.hidden = true;
    document.body.classList.remove('ps-modal-open');
  }

  return { open, close };
})();


/* ============================================================
   PHIẾU THƯỞNG / PHIẾU TRỪ (admin) — psAdjustModal
   GET/POST/DELETE vg/v1/salary-adjustments · GET/POST vg/v1/salary-review-penalty
   ============================================================ */
window.psAdjustModal = (() => {
  const CATS = {
    bonus: [
      ['hot_bonus', 'Thưởng nóng'],
      ['holiday_bonus', 'Thưởng lễ / Tết'],
      ['kpi_bonus', 'Thưởng KPI'],
      ['other', 'Thưởng khác'],
    ],
    deduction: [
      ['uniform', 'Đồng phục'],
      ['penalty', 'Phạt vi phạm'],
      ['damage', 'Bồi thường / hư hỏng'],
      ['other', 'Trừ khác'],
    ],
  };
  let root = null;
  let ctx = null;
  let data = null;

  const call = (path, method, body) =>
    fetch(`${checkinData.restUrl}${path}${method === 'GET' && body ? '?' + new URLSearchParams(body).toString() : ''}`, {
      method,
      headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': checkinData.nonce },
      credentials: 'include',
      body: method === 'GET' ? undefined : JSON.stringify(body || {}),
    }).then(async (r) => {
      const j = await r.json().catch(() => ({}));
      if (!r.ok || j.success === false) throw new Error(j.message || `HTTP ${r.status}`);
      return j;
    });

  function ensureRoot() {
    if (root) return root;
    root = document.createElement('div');
    root.className = 'ps-modal';
    root.hidden = true;
    root.innerHTML = `
      <div class="ps-modal-backdrop" data-close></div>
      <div class="ps-modal-sheet" role="dialog" aria-modal="true" aria-labelledby="ps-adj-title">
        <div class="ps-modal-head">
          <div>
            <div class="ps-eyebrow">Phiếu thưởng · phiếu trừ</div>
            <h3 id="ps-adj-title" class="ps-modal-title">—</h3>
            <div class="ps-modal-sub" id="ps-adj-sub"></div>
          </div>
          <button type="button" class="ps-modal-close" data-close aria-label="Đóng">×</button>
        </div>
        <div class="ps-modal-body" id="ps-adj-body"></div>
        <div class="ps-modal-foot" id="ps-adj-foot"></div>
      </div>`;
    document.body.appendChild(root);
    root.addEventListener('click', (e) => {
      if (e.target.closest('[data-close]')) close();
    });
    return root;
  }

  const catOptions = (kind, selected) =>
    CATS[kind].map(([v, l]) => `<option value="${v}" ${v === selected ? 'selected' : ''}>${l}</option>`).join('');

  function renderList() {
    const items = data.items || [];
    if (!items.length) return `<div class="ps-empty ps-empty--sm">Chưa có phiếu nào trong kỳ.</div>`;
    return `<div class="ps-adj-list">${items
      .map(
        (it) => `
      <div class="ps-adj-row ps-adj-row--${it.kind}">
        <div class="ps-adj-main">
          <div class="ps-adj-title">${it.source === 'review' ? '<i class="fas fa-star-half-alt"></i> ' : ''}${psEsc(it.title)}</div>
          <div class="ps-adj-sub">${psAdjSub(it) || (it.source === 'review' ? 'Tự động theo đánh giá' : '')}</div>
        </div>
        <div class="ps-adj-amount">${it.kind === 'marker' ? '<span class="ps-tag ps-tag--level">truy thu HĐ</span>' : `${it.kind === 'bonus' ? '+' : '−'} ${psMoney(it.amount)}`}</div>
        ${!data.locked && !['review', 'no_image'].includes(it.source) ? `<button type="button" class="ps-adj-del" data-id="${it.id}" aria-label="Xoá phiếu">×</button>` : ''}
      </div>`
      )
      .join('')}
      <div class="ps-adj-totals"><span>Thưởng <b class="ps-pos-text">+ ${psMoney(data.bonus_total)}</b></span><span>Trừ <b class="ps-neg">− ${psMoney(data.deduction_total)}</b></span></div>
    </div>`;
  }

  function renderForm() {
    if (data.locked) return `<p class="ps-help">Phiếu lương kỳ này đã chốt — không thêm/xoá phiếu được. Tạo ở kỳ sau.</p>`;
    return `
      <fieldset class="ps-fieldset">
        <legend>Thêm phiếu</legend>
        <div class="ps-kind-toggle" role="tablist">
          <button type="button" class="is-active" data-kind="bonus"><i class="fas fa-gift"></i> Thưởng</button>
          <button type="button" data-kind="deduction"><i class="fas fa-receipt"></i> Trừ</button>
        </div>
        <div class="ps-grid-2">
          <label class="ps-field"><span>Loại</span><div class="ps-input-wrap"><select id="psa-cat">${catOptions('bonus', 'hot_bonus')}</select></div></label>
          <label class="ps-field"><span>Tên phiếu</span><div class="ps-input-wrap"><input type="text" id="psa-title" maxlength="191" value="Thưởng nóng"></div></label>
          <label class="ps-field"><span>Đơn giá</span><div class="ps-input-wrap"><input type="number" id="psa-price" min="0" step="1000" inputmode="numeric" placeholder="0"><b>đ</b></div></label>
          <label class="ps-field"><span>Số lượng</span><div class="ps-input-wrap"><input type="number" id="psa-qty" min="0.01" step="1" value="1"></div></label>
          <label class="ps-field ps-field--wide"><span>Thành tiền</span><div class="ps-input-wrap"><input type="number" id="psa-amount" min="0" step="1000" inputmode="numeric" placeholder="tự tính = đơn giá × số lượng"><b>đ</b></div><small>Để trống thì tự tính. Sửa tay được.</small></label>
          <label class="ps-field ps-field--wide"><span>Ghi chú</span><div class="ps-input-wrap"><input type="text" id="psa-note" maxlength="255" placeholder="VD: đồng phục áo đen size L"></div></label>
        </div>
      </fieldset>`;
  }

  function renderReview() {
    if (ctx.role !== 'Thợ') return '';
    const c = data.review_penalty;
    if (!c || !c.enabled) return '';
    return `<p class="ps-help"><i class="fas fa-star-half-alt"></i> Truy thu đánh giá thấp đang <b>bật</b> (≤ ${c.threshold}★, ${
      c.mode === 'percent' ? `${psPct(c.value)} giá trị hoá đơn` : `phạt ${psMoney(c.value)}`
    }) — chỉnh ở <b>Cài đặt lương</b>.</p>`;
  }

  function render() {
    root.querySelector('#ps-adj-title').textContent = `${ctx.staffName} · ${psPeriodLabel(ctx.period)}`;
    root.querySelector('#ps-adj-sub').innerHTML = data.locked ? '<span class="ps-tag ps-tag--locked">Phiếu đã chốt · chỉ xem</span>' : `<span class="ps-tag">${(data.items || []).length} phiếu</span>`;
    root.querySelector('#ps-adj-body').innerHTML = `${renderList()}${renderForm()}${renderReview()}`;
    root.querySelector('#ps-adj-foot').innerHTML = data.locked
      ? `<button type="button" class="ps-btn ps-btn--ghost" data-close>Đóng</button>`
      : `<span class="ps-spacer"></span><button type="button" class="ps-btn ps-btn--ghost" data-close>Đóng</button><button type="button" class="ps-btn ps-btn--primary" id="psa-save">Thêm phiếu &amp; tính lại</button>`;

    // kind toggle → đổi danh mục + tên mặc định
    root.querySelectorAll('.ps-kind-toggle button').forEach((b) =>
      b.addEventListener('click', () => {
        root.querySelectorAll('.ps-kind-toggle button').forEach((x) => x.classList.toggle('is-active', x === b));
        const kind = b.dataset.kind;
        const cat = root.querySelector('#psa-cat');
        cat.innerHTML = catOptions(kind, CATS[kind][0][0]);
        root.querySelector('#psa-title').value = CATS[kind][0][1];
      })
    );
    root.querySelector('#psa-cat')?.addEventListener('change', (e) => {
      const kind = root.querySelector('.ps-kind-toggle .is-active').dataset.kind;
      const label = (CATS[kind].find(([v]) => v === e.target.value) || [])[1] || '';
      root.querySelector('#psa-title').value = label;
    });
    const recalc = () => {
      const price = parseFloat(root.querySelector('#psa-price').value || 0);
      const qty = parseFloat(root.querySelector('#psa-qty').value || 1);
      const amt = root.querySelector('#psa-amount');
      if (!amt.dataset.touched) amt.placeholder = price ? `${Math.round(price * qty).toLocaleString('vi-VN')} đ` : 'tự tính = đơn giá × số lượng';
    };
    root.querySelector('#psa-price')?.addEventListener('input', recalc);
    root.querySelector('#psa-qty')?.addEventListener('input', recalc);
    root.querySelector('#psa-amount')?.addEventListener('input', (e) => (e.target.dataset.touched = e.target.value ? '1' : ''));

    root.querySelectorAll('.ps-adj-del').forEach((b) => b.addEventListener('click', () => remove(b.dataset.id)));
    root.querySelector('#psa-save')?.addEventListener('click', add);
  }

  async function add() {
    const btn = root.querySelector('#psa-save');
    psBtnLoading(btn, true, 'Đang thêm…');
    try {
      const kind = root.querySelector('.ps-kind-toggle .is-active').dataset.kind;
      const amountRaw = root.querySelector('#psa-amount').value;
      const res = await call('salary-adjustments', 'POST', {
        staff_name: ctx.staffName,
        role: ctx.role,
        period: ctx.period,
        kind,
        category: root.querySelector('#psa-cat').value,
        title: root.querySelector('#psa-title').value.trim(),
        unit_price: parseFloat(root.querySelector('#psa-price').value || 0),
        quantity: parseFloat(root.querySelector('#psa-qty').value || 1),
        amount: amountRaw === '' ? null : parseFloat(amountRaw),
        note: root.querySelector('#psa-note').value.trim(),
      });
      (window.toastSuccess || alert)(res.message || 'Đã thêm phiếu');
      await reload();
      ctx.onSaved?.(res);
    } catch (e) {
      (window.showError || alert)('Không thêm được: ' + e.message);
    } finally {
      psBtnLoading(btn, false);
    }
  }

  async function remove(id) {
    if (!confirm('Xoá phiếu này và tính lại lương?')) return;
    try {
      const res = await call('salary-adjustments', 'DELETE', { id });
      (window.toastSuccess || alert)(res.message || 'Đã xoá');
      await reload();
      ctx.onSaved?.(res);
    } catch (e) {
      (window.showError || alert)('Không xoá được: ' + e.message);
    }
  }

  async function reload() {
    const res = await call('salary-adjustments', 'GET', { period: ctx.period, staff_name: ctx.staffName, role: ctx.role });
    data = res.data || { items: [] };
    render();
  }

  async function open({ staffName, role = 'Thợ', period, onSaved }) {
    ensureRoot();
    ctx = { staffName, role, period, onSaved };
    root.hidden = false;
    document.body.classList.add('ps-modal-open');
    root.querySelector('#ps-adj-title').textContent = `${staffName} · ${psPeriodLabel(period)}`;
    root.querySelector('#ps-adj-sub').textContent = 'Đang tải…';
    root.querySelector('#ps-adj-body').innerHTML = '<div class="ps-skeleton"><div></div><div></div><div></div></div>';
    root.querySelector('#ps-adj-foot').innerHTML = '';
    try {
      await reload();
    } catch (e) {
      root.querySelector('#ps-adj-sub').textContent = '';
      root.querySelector('#ps-adj-body').innerHTML = `<div class="ps-empty ps-empty--error"><div class="ps-empty-title">Không tải được</div><div class="ps-empty-sub">${psEsc(e.message)}</div></div>`;
      root.querySelector('#ps-adj-foot').innerHTML = `<button type="button" class="ps-btn ps-btn--ghost" data-close>Đóng</button>`;
    }
  }

  function close() {
    if (!root) return;
    root.hidden = true;
    document.body.classList.remove('ps-modal-open');
  }

  return { open, close };
})();


/* ============================================================
   ADMIN — CÀI ĐẶT LƯƠNG TOÀN SALON (psSalaryConfig)
   GET/POST vg/v1/salary-settings
   ============================================================ */
window.psSalaryConfig = (() => {
  const KPI = [['feedback', 'Đánh giá Google Maps'], ['post_fb', 'Đăng bài Facebook'], ['service', 'Doanh số dịch vụ'], ['product', 'Bán sản phẩm']];
  let root = null;
  let data = null;

  const api = (method, body) =>
    fetch(`${checkinData.restUrl}salary-settings`, {
      method,
      headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': checkinData.nonce },
      credentials: 'include',
      body: method === 'GET' ? undefined : JSON.stringify(body),
    }).then(async (r) => {
      const j = await r.json().catch(() => ({}));
      if (!r.ok || j.success === false) throw new Error(j.message || `HTTP ${r.status}`);
      return j;
    });

  const pct = (id, label, value, hint = '', unit = '%') => `<label class="ps-field"><span>${label}</span>
      <div class="ps-input-wrap"><input type="number" id="${id}" min="0" step="0.5" value="${value}"><b>${unit}</b></div>${hint ? `<small>${hint}</small>` : ''}</label>`;

  const NI_REASONS = ['Khách khó tính', 'Khách vãng lai', 'Khách vội đi về', 'Em quên chụp hình', 'Khách ko cắt tóc', 'Khách lớn tuổi'];
  // Kiểu tính truy thu: % giá trị hoá đơn (phần của thợ) hoặc số tiền cố định mỗi hoá đơn — Kent bỏ kiểu "truy thu hoa hồng" 10/09/2026
  const modeOptions = (m) =>
    [['percent', '% doanh số DV/HC của hoá đơn'], ['fixed', 'Số tiền cố định / hoá đơn']]
      .map(([v, l]) => `<option value="${v}" ${(m === 'fixed' ? 'fixed' : 'percent') === v ? 'selected' : ''}>${l}</option>`)
      .join('');

  function render() {
    const d = data;
    const rp = d.review_penalty;
    const ni = d.no_image_penalty || { enabled: false, mode: 'percent', value: 0, skip_guest: true, valid_reasons: [] };
    const cd = d.card_defaults;
    root.innerHTML = `
      <fieldset class="ps-fieldset"><legend>Kỳ thanh toán</legend>
        <div class="ps-radio-list">
          <label class="ps-radio"><input type="radio" name="psc-period" value="month" checked><div><b>Theo tháng</b><small>Kỳ lương = tháng dương lịch, chốt và trả sau khi hết tháng.</small></div></label>
          <label class="ps-radio is-disabled"><input type="radio" name="psc-period" value="week" disabled><div><b>Theo tuần <span class="ps-tag ps-tag--soon">sắp có</span></b><small>Cần đổi toàn bộ chu kỳ tính lương, KPI và phiếu — chưa mở ở bản này.</small></div></label>
        </div>
      </fieldset>

      <fieldset class="ps-fieldset"><legend>Nhân viên xem phiếu lương</legend>
        <div class="ps-radio-list">
          <label class="ps-radio"><input type="radio" name="psc-view" value="always" ${d.staff_view === 'always' ? 'checked' : ''}><div><b>Xem tạm tính ngay</b><small>Kỳ đang chạy hiện số tạm tính, tự cập nhật theo hoá đơn.</small></div></label>
          <label class="ps-radio"><input type="radio" name="psc-view" value="after_day" ${d.staff_view === 'after_day' ? 'checked' : ''}><div><b>Ẩn đến ngày chốt</b><small>Phiếu kỳ T chỉ hiện từ ngày <input type="number" id="psc-view-day" min="1" max="28" value="${d.staff_view_day}" class="ps-inline-num"> của tháng T+1. Admin luôn xem được.</small></div></label>
        </div>
      </fieldset>

      <fieldset class="ps-fieldset"><legend>Truy thu đánh giá thấp</legend>
        <label class="ps-check"><input type="checkbox" id="psc-rv-on" ${rp.enabled ? 'checked' : ''}><span>Tự tạo phiếu trừ khi khách chấm <b>từ mức sao này trở xuống</b> trên hoá đơn của thợ</span></label>
        <input type="hidden" id="psc-rv-th" value="${rp.threshold}">
        <div class="ps-stars" role="radiogroup" aria-label="Ngưỡng sao">
          ${[1, 2, 3, 4, 5].map((n) => `<button type="button" class="ps-star${n <= rp.threshold ? ' is-on' : ''}${n === rp.threshold ? ' is-th' : ''}" data-star="${n}" aria-pressed="${n === rp.threshold}"><i class="fas fa-star"></i><span>${n}★</span></button>`).join('')}
        </div>
        <small class="ps-help" id="psc-rv-th-help">Hoá đơn bị chấm <b>≤ ${rp.threshold}★</b> (dịch vụ hoặc thợ) sẽ bị truy thu.</small>
        <div class="ps-grid-2">
          <label class="ps-field"><span>Cách tính</span><div class="ps-input-wrap"><select id="psc-rv-mode">${modeOptions(rp.mode)}</select></div></label>
          <label class="ps-field" id="psc-rv-value-wrap"><span>Mức</span><div class="ps-input-wrap"><input type="number" id="psc-rv-value" min="0" step="1" value="${rp.value}" placeholder="0"><b id="psc-rv-unit">${rp.mode === 'fixed' ? 'đ' : '%'}</b></div></label>
        </div>
        <small class="ps-help">Áp khi tính lại lương các phiếu chưa chốt, mỗi hoá đơn vi phạm một dòng. Kiểu <b>%</b> = trừ N% doanh số <b>dịch vụ / hoá chất</b> của hoá đơn đó khỏi doanh số trước khi nhân hoa hồng (<b>100% = bỏ hẳn hoá đơn</b>, như admin truy thu tay; sản phẩm vẫn tính). Hoá đơn thuộc kỳ đã trả lương → truy thu bù ở kỳ đang chạy. Trên phiếu lương admin có thể <i>Bỏ qua</i> từng hoá đơn.</small>
      </fieldset>

      <fieldset class="ps-fieldset"><legend>Truy thu hoá đơn không ảnh</legend>
        <label class="ps-check"><input type="checkbox" id="psc-ni-on" ${ni.enabled ? 'checked' : ''}><span>Tự truy thu hoá đơn <b>không có ảnh khách</b> trong kỳ</span></label>
        <label class="ps-check"><input type="checkbox" id="psc-ni-guest" ${ni.skip_guest ? 'checked' : ''}><span>Bỏ qua <b>khách vãng lai</b></span></label>
        <div class="ps-grid-2">
          <label class="ps-field"><span>Cách tính</span><div class="ps-input-wrap"><select id="psc-ni-mode">${modeOptions(ni.mode)}</select></div></label>
          <label class="ps-field" id="psc-ni-value-wrap"><span>Mức</span><div class="ps-input-wrap"><input type="number" id="psc-ni-value" min="0" step="1" value="${ni.value}" placeholder="0"><b id="psc-ni-unit">${ni.mode === 'fixed' ? 'đ' : '%'}</b></div></label>
        </div>
        <div class="ps-field" style="margin-top:8px"><span>Lý do "Not Image" <b>hợp lệ</b> (không truy thu)</span>
          <div class="ps-chip-list" style="margin-top:6px">${NI_REASONS.map((r) => `<label class="ps-chip-check"><input type="checkbox" name="psc-ni-reason" value="${psEsc(r)}" ${ni.valid_reasons.includes(r) ? 'checked' : ''}><span>${psEsc(r)}</span></label>`).join('')}</div>
          <small>Thợ chọn lý do trong app khi không có ảnh; lý do không tick (vd "Em quên chụp hình") vẫn bị truy thu.</small></div>
      </fieldset>

      <fieldset class="ps-fieldset"><legend>Mặc định thẻ hoa hồng mới</legend>
        <div class="ps-grid-2">
          ${pct('psc-cd-product', 'Bán sản phẩm', cd.product_percent)}
          <label class="ps-field"><span>Bán từ … sản phẩm</span><div class="ps-input-wrap"><input type="number" id="psc-cd-minqty" min="0" step="1" value="${cd.product_min_qty}"><b>SP</b></div></label>
          ${pct('psc-cd-overtime', 'Tăng ca', cd.overtime_percent)}
          ${pct('psc-cd-penalty', 'Trượt KPI trừ', cd.kpi_penalty_percent)}
          <label class="ps-field"><span>Trừ trên</span><div class="ps-input-wrap"><select id="psc-cd-scope">${[['service', 'Dịch vụ cắt'], ['chemical', 'Hoá chất'], ['both', 'Cả hai']].map(([v, l]) => `<option value="${v}" ${cd.kpi_penalty_scope === v ? 'selected' : ''}>${l}</option>`).join('')}</select></div></label>
          <label class="ps-field"><span>Trượt nhiều KPI</span><div class="ps-input-wrap"><select id="psc-cd-mode"><option value="once" ${cd.kpi_penalty_mode !== 'each' ? 'selected' : ''}>Trừ một lần</option><option value="each" ${cd.kpi_penalty_mode === 'each' ? 'selected' : ''}>Cộng dồn</option></select></div></label>
        </div>
        <div class="ps-checks" style="margin-top:10px">${KPI.map(([k, l]) => `<label class="ps-check"><input type="checkbox" name="psc-cd-kpi" value="${k}" ${cd.kpi_required.includes(k) ? 'checked' : ''}><span>${l}</span></label>`).join('')}</div>
        <small class="ps-help">Dùng khi thợ chưa có thẻ nào (thẻ đầu tiên điền sẵn từ đây). Thẻ đã có không đổi.</small>
      </fieldset>

      <fieldset class="ps-fieldset"><legend>Phạt đi trễ / về sớm</legend>
        <div class="ps-penalty-row">
          <div class="ps-penalty-summary" id="psc-penalty-summary">…</div>
          <button type="button" class="ps-btn ps-btn--ghost" id="psc-penalty-open"><i class="fas fa-sliders-h"></i> Sửa cấu hình</button>
        </div>
        <small class="ps-help">Mức phạt theo phút đi trễ / về sớm, tự trừ vào phiếu chấm công. Thưởng/phạt lẻ theo kỳ: phiếu lương → <i>Thưởng / Trừ</i>.</small>
      </fieldset>

      <fieldset class="ps-fieldset"><legend>Cấp bậc</legend>
        <label class="ps-check"><input type="checkbox" id="psc-kpi-level" ${d.kpi_changes_level ? 'checked' : ''}><span>KPI tự hạ / khôi phục cấp bậc theo tháng <small class="ps-muted">(cơ chế cũ; tắt thì hạng chỉ đổi khi admin đổi ở Cài đặt cấp bậc)</small></span></label>
      </fieldset>

      <div class="ps-config-foot">
        <span class="ps-help" id="psc-status"></span>
        <button type="button" class="ps-btn ps-btn--primary" id="psc-save">Lưu cài đặt lương</button>
      </div>`;
    const bindMode = (sel, unit) =>
      root.querySelector(sel).addEventListener('change', (e) => {
        root.querySelector(unit).textContent = e.target.value === 'fixed' ? 'đ' : '%';
      });
    bindMode('#psc-rv-mode', '#psc-rv-unit');
    bindMode('#psc-ni-mode', '#psc-ni-unit');
    root.querySelectorAll('.ps-star').forEach((b) =>
      b.addEventListener('click', () => {
        const th = parseInt(b.dataset.star, 10);
        root.querySelector('#psc-rv-th').value = th;
        root.querySelectorAll('.ps-star').forEach((x) => {
          const n = parseInt(x.dataset.star, 10);
          x.classList.toggle('is-on', n <= th);
          x.classList.toggle('is-th', n === th);
          x.setAttribute('aria-pressed', n === th);
        });
        root.querySelector('#psc-rv-th-help').innerHTML = `Hoá đơn bị chấm <b>≤ ${th}★</b> (dịch vụ hoặc thợ) sẽ bị truy thu.`;
      })
    );
    root.querySelector('#psc-save').addEventListener('click', saveAll);
    root.querySelector('#psc-penalty-open')?.addEventListener('click', openPenaltyModal);
    refreshPenaltySummary();
  }

  // ---- Cài đặt phạt đi trễ/về sớm: gộp vào đây, sửa trong modal (dùng lại form #penalty-settings có sẵn) ----
  let penaltyModal = null;
  let penaltyHome = null;
  function refreshPenaltySummary() {
    const el = root?.querySelector('#psc-penalty-summary');
    if (!el) return;
    const on = document.getElementById('penalty_enabled')?.checked;
    const byTime = document.getElementById('fine_by_time')?.checked;
    const amount = parseFloat(document.getElementById('fine_amount')?.value || 0);
    el.innerHTML = on
      ? `<span class="ps-tag ps-tag--manual">Đang bật</span> ${byTime ? 'phạt theo mốc thời gian' : `phạt cố định <b>${psMoney(amount)}</b> mỗi lần`}`
      : '<span class="ps-tag">Đang tắt</span> chưa phạt đi trễ / về sớm';
  }
  function openPenaltyModal() {
    const form = document.getElementById('penalty-settings-form') || document.getElementById('penalty-settings');
    if (!form) return;
    if (!penaltyModal) {
      penaltyModal = document.createElement('div');
      penaltyModal.className = 'ps-modal';
      penaltyModal.innerHTML = `<div class="ps-modal-backdrop" data-close></div>
        <div class="ps-modal-sheet ps-modal-sheet--wide" role="dialog" aria-modal="true">
          <div class="ps-modal-head"><div><div class="ps-eyebrow">Cài đặt lương</div><h3 class="ps-modal-title">Phạt đi trễ / về sớm</h3><div class="ps-modal-sub">Áp toàn salon, mọi kỳ. Lưu bằng nút trong form.</div></div><button type="button" class="ps-modal-close" data-close aria-label="Đóng">×</button></div>
          <div class="ps-modal-body" id="psc-penalty-body"></div>
          <div class="ps-modal-foot"><span class="ps-spacer"></span><button type="button" class="ps-btn ps-btn--ghost" data-close>Đóng</button></div>
        </div>`;
      document.body.appendChild(penaltyModal);
      penaltyModal.addEventListener('click', (e) => {
        if (e.target.closest('[data-close]')) closePenaltyModal();
      });
    }
    penaltyHome = penaltyHome || document.createComment('penalty-settings-home');
    if (!penaltyHome.parentNode) form.parentNode.insertBefore(penaltyHome, form);
    penaltyModal.querySelector('#psc-penalty-body').appendChild(form);
    form.querySelectorAll('.settings-section').forEach((sec) => (sec.style.display = 'block'));
    if (form.classList.contains('settings-section')) form.style.display = 'block';
    penaltyModal.hidden = false;
    document.body.classList.add('ps-modal-open');
    if (typeof window.fetchPenaltySettings === 'function') {
      try { window.fetchPenaltySettings(); } catch (e) { /* form vẫn dùng được với dữ liệu đã có */ }
    }
  }
  function closePenaltyModal() {
    const form = penaltyModal?.querySelector('#psc-penalty-body')?.firstElementChild;
    if (form && penaltyHome?.parentNode) {
      penaltyHome.parentNode.insertBefore(form, penaltyHome);
      form.querySelectorAll('.settings-section').forEach((sec) => (sec.style.display = ''));
      if (form.classList.contains('settings-section')) form.style.display = '';
    }
    penaltyModal.hidden = true;
    document.body.classList.remove('ps-modal-open');
    refreshPenaltySummary();
  }

  async function saveAll() {
    const btn = root.querySelector('#psc-save');
    psBtnLoading(btn, true, 'Đang lưu…');
    try {
      const body = {
        staff_view: root.querySelector('input[name="psc-view"]:checked')?.value || 'always',
        staff_view_day: parseInt(root.querySelector('#psc-view-day').value || 5, 10),
        kpi_changes_level: root.querySelector('#psc-kpi-level').checked,
        review_penalty: {
          enabled: root.querySelector('#psc-rv-on').checked,
          mode: root.querySelector('#psc-rv-mode').value,
          value: parseFloat(root.querySelector('#psc-rv-value').value || 0),
          threshold: parseInt(root.querySelector('#psc-rv-th').value, 10),
        },
        no_image_penalty: {
          enabled: root.querySelector('#psc-ni-on').checked,
          skip_guest: root.querySelector('#psc-ni-guest').checked,
          mode: root.querySelector('#psc-ni-mode').value,
          value: parseFloat(root.querySelector('#psc-ni-value').value || 0),
          valid_reasons: [...root.querySelectorAll('input[name="psc-ni-reason"]:checked')].map((i) => i.value),
        },
        card_defaults: {
          product_percent: parseFloat(root.querySelector('#psc-cd-product').value || 0),
          product_min_qty: parseInt(root.querySelector('#psc-cd-minqty').value || 0, 10),
          overtime_percent: parseFloat(root.querySelector('#psc-cd-overtime').value || 0),
          kpi_penalty_percent: parseFloat(root.querySelector('#psc-cd-penalty').value || 0),
          kpi_penalty_scope: root.querySelector('#psc-cd-scope').value,
          kpi_penalty_mode: root.querySelector('#psc-cd-mode').value,
          kpi_required: [...root.querySelectorAll('input[name="psc-cd-kpi"]:checked')].map((i) => i.value),
        },
      };
      const res = await api('POST', body);
      data = res.data;
      (window.toastSuccess || alert)(res.message || 'Đã lưu');
      root.querySelector('#psc-status').textContent = `Đã lưu lúc ${new Date().toLocaleTimeString('vi-VN')}`;
    } catch (e) {
      (window.showError || alert)('Không lưu được: ' + e.message);
    } finally {
      psBtnLoading(btn, false);
    }
  }

  async function mount(el) {
    root = el;
    root.innerHTML = '<div class="ps-skeleton"><div></div><div></div><div></div></div>';
    try {
      const res = await api('GET');
      data = res.data;
      render();
      renderTiers(res.tiers || []);
    } catch (e) {
      root.innerHTML = `<div class="ps-empty ps-empty--error"><div class="ps-empty-title">Không tải được cài đặt</div><div class="ps-empty-sub">${psEsc(e.message)}</div></div>`;
    }
  }

  function renderTiers(tiers) {
    const strip = document.getElementById('ps-tiers-strip');
    if (!strip || !tiers.length) return;
    strip.innerHTML = tiers
      .map((t) => `<div class="ps-tier ps-tier--${t.order}"><b>${psEsc(t.name)}</b><small>Hạng ${t.order}</small></div>`)
      .join('');
  }

  return { mount };
})();

document.addEventListener('DOMContentLoaded', () => {
  const el = document.getElementById('salary-config-body');
  if (el && window.checkinData) window.psSalaryConfig.mount(el);
});

/* ============================================================
   ADMIN — DANH SÁCH LƯƠNG DẠNG CARD (psAdminSalaryList)
   ============================================================ */
window.psAdminSalaryList = (() => {
  function summary(rows, isPersonalPage = false) {
    const total = rows.reduce((a, r) => a + psNum(r.actual_salary), 0);
    const counts = {};
    rows.forEach((r) => {
      const st = psStatus(r, isPersonalPage);
      counts[st.text] = counts[st.text] || { n: 0, cls: st.cls };
      counts[st.text].n++;
    });
    const locked = rows.filter((r) => r.xac_nhan_thanh_toan === 'Đã nhận đủ' || r.status === 'received').length;
    return `
      <div class="ps-admin-summary">
        <div class="ps-sum ps-sum--total"><div class="ps-sum-label">Tổng thực nhận · ${rows.length} nhân viên</div><div class="ps-sum-value">${psMoney(total)}</div></div>
        <div class="ps-sum"><div class="ps-sum-label">Đã nhận đủ</div><div class="ps-sum-value">${locked}/${rows.length}</div></div>
        <div class="ps-sum"><div class="ps-sum-label">Trạng thái</div><div class="ps-sum-chips">${Object.entries(counts)
          .map(([t, c]) => `<span class="ps-status ps-status--${c.cls}">${c.n} ${t}</span>`)
          .join('')}</div></div>
      </div>`;
  }

  function card(r, roleKey) {
    const st = psStatus(r, false);
    const att = r.attendance || {};
    const adj = psAdj(r);
    const locked = r.xac_nhan_luong === 'Đồng ý' || r.payment || r.status === 'received';
    const applied = r.rates_applied;
    const rates =
      roleKey === 'hairdresser'
        ? `DV ${psPct(applied ? applied.service_percent_effective : r.service_commission_percent)} · HC ${psPct(applied ? applied.chemical_percent_effective : r.chemical_commission_percent)}`
        : `${psMoney(r.hourly_salary)}/h · ${psQty(r.total_hours)}h`;
    return `
      <button type="button" class="ps-staff-card${locked ? ' ps-staff-card--locked' : ''}" data-staff="${psEsc(r.staff_name)}">
        <div class="ps-staff-top">
          ${psAvatar(r.staff_name, r.avatar)}
          <div class="ps-staff-who">
            <div class="ps-staff-name">${psEsc(r.staff_name || 'N/A')}</div>
            <div class="ps-staff-tier">${psEsc(r.level_name || 'Chưa có bậc')} · ${rates}</div>
          </div>
          <span class="ps-status ps-status--${st.cls}">${st.text}</span>
        </div>
        <div class="ps-staff-money"><span class="ps-lbl">Thực nhận</span><span class="ps-val">${psMoney(r.actual_salary)}</span></div>
        <div class="ps-staff-meta">
          <span>Tổng lương <b>${psMoney(r.total_salary)}</b></span>
          ${psNum(r.total_of_deductions) > 0 ? `<span>Khấu trừ <b class="ps-neg">− ${psMoney(r.total_of_deductions)}</b></span>` : ''}
          ${psNum(r.advance_salary) > 0 ? `<span>Ứng <b>${psMoney(r.advance_salary)}</b></span>` : ''}
          ${adj.items && adj.items.length ? `<span><b>${adj.items.length}</b> phiếu thưởng/trừ</span>` : ''}
        </div>
        <div class="ps-staff-foot">
          <span class="ps-mini">${att.working_days !== undefined ? `${psQty(att.working_days)} công` : ''}${att.late_days ? ` · <span class="ps-neg">${att.late_days} trễ</span>` : ''}${att.leave_days ? ` · ${att.leave_days} phép` : ''}${att.overtime_days ? ` · ${att.overtime_days} tăng ca` : ''}</span>
          <span class="ps-icon-btn" data-profile="${psEsc(r.staff_name)}" title="Hồ sơ nhân viên" role="button"><i class="fas fa-id-badge"></i></span>
        </div>
      </button>`;
  }

  let ctx = null; // { container, rows, roleKey, opts }

  // Cập nhật đúng một card + phần tổng quan, không vẽ lại cả danh sách
  function updateRow(row) {
    if (!ctx || !row || !ctx.container.isConnected) return false;
    const i = ctx.rows.findIndex((r) => r.staff_name === row.staff_name);
    if (i < 0) return false;
    ctx.rows[i] = row;
    const old = ctx.container.querySelector(`.ps-staff-card[data-staff="${CSS.escape(row.staff_name)}"]`);
    if (!old) return false;
    const tmp = document.createElement('div');
    tmp.innerHTML = card(row, ctx.roleKey);
    const fresh = tmp.firstElementChild;
    old.replaceWith(fresh);
    bindCard(fresh);
    fresh.classList.add('ps-staff-card--updated');
    setTimeout(() => fresh.classList.remove('ps-staff-card--updated'), 1600);
    const sum = ctx.container.querySelector('.ps-admin-summary');
    if (sum) {
      const t = document.createElement('div');
      t.innerHTML = summary(ctx.rows);
      sum.replaceWith(t.firstElementChild);
    }
    return true;
  }

  function bindCard(el) {
    el.addEventListener('click', (e) => {
      const byName = {};
      ctx.rows.forEach((r) => (byName[r.staff_name] = r));
      const prof = e.target.closest('[data-profile]');
      if (prof) {
        e.stopPropagation();
        ctx.opts.onProfile?.(prof.dataset.profile, byName[prof.dataset.profile]);
        return;
      }
      ctx.opts.onOpen?.(byName[el.dataset.staff]);
    });
  }

  window.addEventListener('ps:salary-updated', (e) => {
    if (ctx && e.detail?.row) updateRow(e.detail.row);
  });

  function render(container, rows, roleKey, { onOpen, onProfile, onCalculate, period } = {}) {
    if (!container) return;
    ctx = { container, rows: rows || [], roleKey, opts: { onOpen, onProfile, onCalculate, period } };
    if (!rows || !rows.length) {
      container.innerHTML = `<div class="ps-admin-empty"><div>Chưa có dữ liệu lương ${psPeriodLabel(period).toLowerCase()}.</div>${
        onCalculate ? '<button type="button" id="calculate-salary" class="ps-btn ps-btn--primary">Tính lương kỳ này</button>' : ''
      }</div>`;
      if (onCalculate) container.querySelector('#calculate-salary')?.addEventListener('click', onCalculate);
      return;
    }
    container.innerHTML = summary(rows) + `<div class="ps-admin-list">${rows.map((r) => card(r, roleKey)).join('')}</div>`;
    container.querySelectorAll('.ps-staff-card').forEach(bindCard);
  }

  return { render, updateRow };
})();

/* ============================================================
   MODAL PHIẾU LƯƠNG (admin) — psPayslipModal
   Không khung ngoài: chính phiếu là modal. Đóng → chỉ cập nhật card đã đổi.
   ============================================================ */
window.psPayslipModal = (() => {
  function open(salary, role, period) {
    if (!salary) return;
    const card =
      role === 'Thu Ngân'
        ? createCashierSalaryCard(salary, false, role)
        : createHairdresserSalaryCard(salary, false, role);
    const overlay = document.createElement('div');
    overlay.className = 'ps-payslip-modal';
    overlay.innerHTML = `
      <div class="ps-payslip-dialog" role="dialog" aria-modal="true">
        <button type="button" class="ps-payslip-close" aria-label="Đóng">×</button>
        <div class="ps-payslip-body salary-card-container"></div>
        <div class="ps-payslip-foot ps-card"></div>
      </div>`;
    const dialog = overlay.querySelector('.ps-payslip-dialog');
    const body = overlay.querySelector('.ps-payslip-body');
    const foot = overlay.querySelector('.ps-payslip-foot');
    // Hàng nút tách khỏi phiếu → footer cố định của modal; phiếu cuộn bên dưới. Listener đã gắn vào nút nên di chuyển DOM không mất.
    const mountActions = (c) => {
      const actions = c?.querySelector('.card-actions');
      if (!actions) return; // phiếu mới chưa có hàng nút → giữ footer hiện tại
      foot.innerHTML = '';
      foot.appendChild(actions);
      foot.hidden = false;
    };
    body.appendChild(card);
    mountActions(card);
    document.body.appendChild(overlay);
    document.body.classList.add('ps-modal-open');
    overlay.getBoundingClientRect(); // ép reflow để transition chạy, không phụ thuộc rAF (tab ẩn vẫn mở đúng)
    overlay.classList.add('is-open');

    let changed = false;
    let latest = null;
    const onUpdated = (e) => {
      const d = e.detail || {};
      if (d.staff === salary.staff_name && d.period === period) {
        changed = true;
        latest = d.row;
        const fresh = body.querySelector('.salary-card'); // refreshSalaryCard đã thay phiếu mới vào body
        if (fresh) mountActions(fresh);
      }
    };
    window.addEventListener('ps:salary-updated', onUpdated);

    const close = () => {
      window.removeEventListener('ps:salary-updated', onUpdated);
      document.removeEventListener('keydown', onKey);
      overlay.classList.remove('is-open');
      document.body.classList.remove('ps-modal-open');
      setTimeout(() => overlay.remove(), 200);
      // Có thay đổi → card ngoài danh sách đã được cập nhật qua sự kiện; không có → không đụng gì, không chớp trang.
      if (changed && latest && window.psAdminSalaryList) window.psAdminSalaryList.updateRow(latest);
    };
    const onKey = (e) => {
      if (e.key === 'Escape') close();
    };
    document.addEventListener('keydown', onKey);
    overlay.querySelector('.ps-payslip-close').addEventListener('click', close);
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) close();
    });
    return { close };
  }
  return { open };
})();

/* ============================================================
   HỒ SƠ THỢ (psStaffProfile) — GET vg/v1/staff-profile
   ============================================================ */
window.psStaffProfile = (() => {
  let root = null;
  const TIER_ICON = { 1: 'fa-seedling', 2: 'fa-cut', 3: 'fa-star', 4: 'fa-crown' };

  function ensureRoot() {
    if (root) return root;
    root = document.createElement('div');
    root.className = 'ps-modal';
    root.hidden = true;
    root.innerHTML = `
      <div class="ps-modal-backdrop" data-close></div>
      <div class="ps-modal-sheet" role="dialog" aria-modal="true">
        <div class="ps-modal-head">
          <div class="ps-profile-head" id="ps-pf-head"></div>
          <button type="button" class="ps-modal-close" data-close aria-label="Đóng">×</button>
        </div>
        <div class="ps-modal-body" id="ps-pf-body"></div>
        <div class="ps-modal-foot"><span class="ps-spacer"></span><button type="button" class="ps-btn ps-btn--ghost" data-close>Đóng</button></div>
      </div>`;
    document.body.appendChild(root);
    root.addEventListener('click', (e) => {
      if (e.target.closest('[data-close]')) close();
    });
    return root;
  }

  const fmtDate = (d) => (d ? new Date(d).toLocaleDateString('vi-VN') : '—');
  const periodLabel = (p) => (p ? p.split('-').reverse().join('/') : '—');
  const tierOrder = (tiers, name) => (tiers.find((t) => t.name === name) || {}).order || 0;

  function render(d, opts) {
    const s = d.staff;
    const tiers = d.tiers || [];
    const cur = d.current_level;
    const rates = d.current_rates;
    const att = d.attendance || {};
    root.querySelector('#ps-pf-head').innerHTML = `
      <div class="ps-avatar" ${s.avatar ? `style="background-image:url('${psEsc(s.avatar)}')"` : ''}>${s.avatar ? '' : psEsc(psInitials(s.display_name))}</div>
      <div><div class="ps-profile-name">${psEsc(s.display_name)}</div><div class="ps-profile-sub">${psEsc(s.user_role || '')}${s.branch ? ` · ${psEsc(s.branch)}` : ''}${cur ? ` · <b>${psEsc(cur.level_name)}</b>` : ''}</div></div>`;

    const info = `
      <div class="ps-section"><div class="ps-section-title"><i class="fas fa-briefcase"></i> Thông tin công việc</div>
        <div class="ps-info-grid">
          <div class="ps-info-row"><span>Mã NV</span><b>${psEsc(s.employee_id || '—')}</b></div>
          <div class="ps-info-row"><span>Trạng thái</span><b>${psEsc(s.status || '—')}</b></div>
          <div class="ps-info-row"><span>Ngày gia nhập</span><b>${fmtDate(s.joined_at)}</b></div>
          <div class="ps-info-row"><span>Hạng hiện tại</span><b>${cur ? psEsc(cur.level_name) : 'Chưa có'}</b></div>
          <div class="ps-info-row"><span>Đổi hạng lần cuối</span><b>${cur ? fmtDate(cur.start_time) : '—'}</b></div>
          ${rates ? `<div class="ps-info-row"><span>Hoa hồng kỳ này</span><b>DV ${psPct(rates.service_percent)} · HC ${psPct(rates.chemical_percent)} · SP ${psPct(rates.product_percent)}${rates.product_min_qty > 1 ? ` (≥${rates.product_min_qty})` : ''}</b></div>` : ''}
          <div class="ps-info-row"><span>Tháng này</span><b>${psQty(att.working_days || 0)} công · ${psQty(att.late_days || 0)} trễ · ${psQty(att.leave_days || 0)} phép</b></div>
        </div>
      </div>`;

    const levelTl = d.level_history && d.level_history.length
      ? `<ul class="ps-timeline">${d.level_history
          .map(
            (l, i) => `<li class="ps-tl-item${l.is_active ? ' is-current' : ''}">
              <div class="ps-tl-dot"><i class="fas ${TIER_ICON[tierOrder(tiers, l.level_name)] || 'fa-layer-group'}"></i></div>
              <div class="ps-tl-head"><span class="ps-tl-title">${psEsc(l.level_name)}${l.is_active ? ' <span class="ps-tag ps-tag--carried">hiện tại</span>' : ''}</span><span class="ps-tl-date">${fmtDate(l.start_time)}${l.end_time && !l.is_active && l.end_time < '2099' ? ` → ${fmtDate(l.end_time)}` : ''}</span></div>
              <div class="ps-tl-body">${l.legacy_level_name ? `<span class="ps-muted">Tên bậc cũ: ${psEsc(l.legacy_level_name)}</span>` : ''}${l.condition ? `<div>${psEsc(l.condition)}</div>` : ''}</div>
            </li>`
          )
          .join('')}</ul>`
      : '<div class="ps-empty ps-empty--sm">Chưa có lịch sử cấp bậc</div>';

    const commTl = !d.is_hairdresser
      ? ''
      : d.commission_history && d.commission_history.length
        ? `<ul class="ps-timeline">${d.commission_history
            .map(
              (c, i) => `<li class="ps-tl-item${i === 0 ? ' is-current' : ''}">
              <div class="ps-tl-dot"><i class="fas fa-percent"></i></div>
              <div class="ps-tl-head"><span class="ps-tl-title">DV ${psPct(c.rates.service_percent)} · HC ${psPct(c.rates.chemical_percent)} · SP ${psPct(c.rates.product_percent)}${c.rates.product_min_qty > 1 ? ` (≥${c.rates.product_min_qty} SP)` : ''} <span class="ps-tag ps-tag--${c.source}">${{ manual: 'admin đặt', carried: 'kế thừa', migrated: 'chuyển từ bậc', level: 'theo bậc' }[c.source] || c.source}</span></span><span class="ps-tl-date">Kỳ ${periodLabel(c.period)}</span></div>
              <div class="ps-tl-body">${c.changes && c.changes.length ? `<div class="ps-tl-changes">${c.changes.map((x) => `<span>${psEsc(x)}</span>`).join('')}</div>` : '<span class="ps-muted">Thẻ đầu tiên</span>'}${c.note ? `<div>${psEsc(c.note)}</div>` : ''}<div class="ps-muted">Người sửa: ${psEsc(c.updated_by || '—')}${c.updated_at ? ` · ${fmtDate(c.updated_at)}` : ''}</div></div>
            </li>`
            )
            .join('')}</ul>`
        : '<div class="ps-empty ps-empty--sm">Chưa có thẻ hoa hồng — đang tính theo bậc</div>';

    const salaryRows = d.salary_history && d.salary_history.length
      ? `<div class="ps-salary-rows">${d.salary_history
          .map((r) => {
            const st = psStatus(r, false);
            return `<button type="button" class="ps-salary-row" data-period="${r.period}"><span>${periodLabel(r.period)} <span class="ps-status ps-status--${st.cls}" style="margin-left:6px">${st.text}</span></span><b>${psMoney(r.actual_salary)}</b></button>`;
          })
          .join('')}</div>`
      : '<div class="ps-empty ps-empty--sm">Chưa có phiếu lương</div>';

    root.querySelector('#ps-pf-body').innerHTML = `
      ${info}
      <div class="ps-section"><div class="ps-section-title"><i class="fas fa-layer-group"></i> Lịch sử cấp bậc</div>${levelTl}</div>
      ${d.is_hairdresser ? `<div class="ps-section"><div class="ps-section-title"><i class="fas fa-percent"></i> Lịch sử hoa hồng</div>${commTl}</div>` : ''}
      <div class="ps-section"><div class="ps-section-title"><i class="fas fa-file-invoice-dollar"></i> Phiếu lương 12 kỳ gần nhất</div>${salaryRows}</div>`;
    root.querySelectorAll('.ps-salary-row').forEach((b) =>
      b.addEventListener('click', () => {
        close();
        opts.onOpenPeriod?.(b.dataset.period, d.is_hairdresser ? 'Thợ' : 'Thu Ngân', s.display_name);
      })
    );
  }

  async function open({ staffName, onOpenPeriod } = {}) {
    ensureRoot();
    root.hidden = false;
    document.body.classList.add('ps-modal-open');
    root.querySelector('#ps-pf-head').innerHTML = `<div class="ps-avatar">${psEsc(psInitials(staffName))}</div><div><div class="ps-profile-name">${psEsc(staffName)}</div><div class="ps-profile-sub">Đang tải hồ sơ…</div></div>`;
    root.querySelector('#ps-pf-body').innerHTML = '<div class="ps-skeleton"><div></div><div></div><div></div></div>';
    try {
      const r = await fetch(`${checkinData.restUrl}staff-profile?staff_name=${encodeURIComponent(staffName)}`, {
        headers: { 'X-WP-Nonce': checkinData.nonce },
        credentials: 'include',
      });
      const j = await r.json();
      if (!r.ok || !j.success) throw new Error(j.message || `HTTP ${r.status}`);
      render(j.data, { onOpenPeriod });
    } catch (e) {
      root.querySelector('#ps-pf-body').innerHTML = `<div class="ps-empty ps-empty--error"><div class="ps-empty-title">Không tải được hồ sơ</div><div class="ps-empty-sub">${psEsc(e.message)}</div></div>`;
    }
  }

  function close() {
    if (!root) return;
    root.hidden = true;
    document.body.classList.remove('ps-modal-open');
  }

  return { open, close };
})();


/* ============================================================
   XEM KPI (psKpiModal) — thanh tiến trình từng KPI, Làm mới (đánh giá lại), Sửa tay (admin)
   GET vg/v1/kpi-result · POST vg/v1/evaluate-kpi · POST vg/v1/kpi-result/manual
   ============================================================ */
window.psKpiModal = (() => {
  let root = null;
  let ctx = null;
  let data = null;
  let editing = false;

  const call = (path, method, body) =>
    fetch(`${checkinData.restUrl}${path}${method === 'GET' && body ? '?' + new URLSearchParams(body).toString() : ''}`, {
      method,
      headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': checkinData.nonce },
      credentials: 'include',
      body: method === 'GET' ? undefined : JSON.stringify(body || {}),
    }).then(async (r) => {
      const j = await r.json().catch(() => ({}));
      if (!r.ok || j.success === false) throw new Error(j.message || `HTTP ${r.status}`);
      return j;
    });

  function ensureRoot() {
    if (root) return root;
    root = document.createElement('div');
    root.className = 'ps-modal';
    root.hidden = true;
    root.innerHTML = `
      <div class="ps-modal-backdrop" data-close></div>
      <div class="ps-modal-sheet" role="dialog" aria-modal="true">
        <div class="ps-modal-head">
          <div><div class="ps-eyebrow">KPI kỳ lương</div><h3 class="ps-modal-title" id="ps-kpi-title">—</h3><div class="ps-modal-sub" id="ps-kpi-sub"></div></div>
          <button type="button" class="ps-modal-close" data-close aria-label="Đóng">×</button>
        </div>
        <div class="ps-modal-body" id="ps-kpi-body"></div>
        <div class="ps-modal-foot" id="ps-kpi-foot"></div>
      </div>`;
    document.body.appendChild(root);
    root.addEventListener('click', (e) => {
      if (e.target.closest('[data-close]')) close();
    });
    return root;
  }

  const val = (it, v) => (it.unit === 'đ' ? psMoney(v) : `${psQty(v, 0)} ${it.unit}`);

  function render() {
    root.querySelector('#ps-kpi-title').textContent = `${ctx.staffName} · ${psPeriodLabel(ctx.period)}`;
    const k = data;
    if (!k) {
      root.querySelector('#ps-kpi-sub').innerHTML = '<span class="ps-tag ps-tag--level">Chưa đánh giá</span>';
      root.querySelector('#ps-kpi-body').innerHTML = `<div class="ps-empty ps-empty--sm">Chưa có kết quả KPI kỳ này. Bấm <b>Làm mới</b> để đánh giá theo cài đặt KPI hiện có.</div>`;
    } else {
      root.querySelector('#ps-kpi-sub').innerHTML = `${k.is_evaluated ? '<span class="ps-tag ps-tag--carried">Đã đánh giá</span>' : '<span class="ps-tag ps-tag--level">Chưa đánh giá</span>'} ${k.updated_at ? `<span class="ps-muted">· ${psDate(k.updated_at)}</span>` : ''}${k.manual_note ? ` <span class="ps-muted">· ${psEsc(k.manual_note)}</span>` : ''}`;
      root.querySelector('#ps-kpi-body').innerHTML = `
        <div class="ps-kpi-cards">
          ${(k.items || [])
            .map((it) => {
              const pct = Math.max(0, Math.min(100, psNum(it.percent)));
              const state = it.no_target ? 'free' : it.achieved ? 'ok' : 'fail';
              const target = it.required != null ? it.required : it.target;
              return `<div class="ps-kpi-card ps-kpi-row--${state}">
                <div class="ps-kpi-head"><span class="ps-kpi-label">${psEsc(it.label)}</span><span class="ps-kpi-state${it.manual !== null && it.manual !== undefined ? ' ps-kpi-state--manual' : ''}">${psKpiStateText(it)}</span></div>
                <div class="ps-kpi-bar ps-kpi-bar--lg"><span style="width:${it.no_target ? 100 : pct}%"></span><b>${it.no_target ? '' : pct + '%'}</b></div>
                <div class="ps-kpi-nums">${it.actual === null ? 'Chưa có số' : val(it, it.actual)}${it.no_target ? '' : ` / ${psKpiTargetText(it, target, (v) => val(it, v))}${psKpiPostNote(it)}`}</div>
                ${!it.no_target && (it.bonus || it.penalty) ? `<div class="ps-kpi-money">${it.bonus ? `<span class="ps-pos-text">+ ${psMoney(it.bonus)} thưởng</span>` : ''}${it.penalty ? `<span class="ps-neg">− ${psMoney(it.penalty)} phạt</span>` : ''}</div>` : ''}
                ${editing ? `<label class="ps-field ps-kpi-edit"><span>Ghi đè</span><div class="ps-input-wrap"><select data-kpi-key="${it.key}"><option value="auto" ${it.manual === null || it.manual === undefined ? 'selected' : ''}>Tự động (theo số liệu)</option><option value="1" ${it.manual === 1 ? 'selected' : ''}>Đạt</option><option value="0" ${it.manual === 0 ? 'selected' : ''}>Không đạt</option></select></div></label>` : ''}
              </div>`;
            })
            .join('')}
        </div>
        ${editing ? `<label class="ps-field" style="margin-top:10px"><span>Ghi chú</span><div class="ps-input-wrap"><input type="text" id="ps-kpi-note" maxlength="255" value="${psEsc(k.manual_note || '')}" placeholder="VD: khách xác nhận đã đánh giá nhưng chưa lên Maps"></div></label>` : ''}
        <p class="ps-help">Đăng bài FB tính theo cách đặt ở <i>Cài đặt KPI</i>: theo ngày công (N bài mỗi ngày công thực tế) hoặc số bài cố định trong kỳ. Đánh giá Google Maps = số hoá đơn của thợ có ảnh đánh giá. KPI trượt sẽ trừ hoa hồng theo thẻ hoa hồng của thợ; sản phẩm đạt thì hưởng % thưởng sản phẩm.</p>`;
    }
    root.querySelector('#ps-kpi-foot').innerHTML = `
      <button type="button" class="ps-btn ps-btn--ghost" id="ps-kpi-refresh"><i class="fas fa-sync-alt"></i> Làm mới</button>
      ${ctx.canEdit ? (editing ? `<button type="button" class="ps-btn ps-btn--primary" id="ps-kpi-save">Lưu ghi đè</button><button type="button" class="ps-btn ps-btn--ghost" id="ps-kpi-cancel">Huỷ sửa</button>` : `<button type="button" class="ps-btn ps-btn--ghost" id="ps-kpi-edit"><i class="fas fa-pen"></i> Sửa</button>`) : ''}
      <span class="ps-spacer"></span>
      <button type="button" class="ps-btn ps-btn--ghost" data-close>Đóng</button>`;
    root.querySelector('#ps-kpi-refresh').addEventListener('click', refresh);
    root.querySelector('#ps-kpi-edit')?.addEventListener('click', () => { editing = true; render(); });
    root.querySelector('#ps-kpi-cancel')?.addEventListener('click', () => { editing = false; render(); });
    root.querySelector('#ps-kpi-save')?.addEventListener('click', saveManual);
  }

  async function load() {
    const res = await call('kpi-result', 'GET', { staff_name: ctx.staffName, period: ctx.period });
    data = res.data || null;
    render();
  }

  async function refresh() {
    const btn = root.querySelector('#ps-kpi-refresh');
    psBtnLoading(btn, true, 'Đang đánh giá…');
    try {
      await call('evaluate-kpi', 'POST', { period: ctx.period, staff_name: ctx.staffName });
      await load();
      (window.toastSuccess || alert)('Đã đánh giá lại KPI và tính lại lương.');
      ctx.onChanged?.();
    } catch (e) {
      (window.showError || alert)('Không đánh giá được: ' + e.message);
    } finally {
      psBtnLoading(btn, false);
    }
  }

  async function saveManual() {
    const overrides = {};
    root.querySelectorAll('[data-kpi-key]').forEach((sel) => (overrides[sel.dataset.kpiKey] = sel.value));
    try {
      const res = await call('kpi-result/manual', 'POST', { staff_name: ctx.staffName, period: ctx.period, overrides, note: root.querySelector('#ps-kpi-note')?.value || '' });
      data = res.data || data;
      editing = false;
      render();
      (window.toastSuccess || alert)(res.message || 'Đã lưu');
      ctx.onChanged?.();
    } catch (e) {
      (window.showError || alert)('Không lưu được: ' + e.message);
    }
  }

  async function open({ staffName, period, canEdit = false, onChanged }) {
    ensureRoot();
    ctx = { staffName, period, canEdit, onChanged };
    editing = false;
    root.hidden = false;
    document.body.classList.add('ps-modal-open');
    root.querySelector('#ps-kpi-title').textContent = `${staffName} · ${psPeriodLabel(period)}`;
    root.querySelector('#ps-kpi-body').innerHTML = '<div class="ps-skeleton"><div></div><div></div><div></div></div>';
    root.querySelector('#ps-kpi-foot').innerHTML = '';
    try {
      await load();
    } catch (e) {
      root.querySelector('#ps-kpi-body').innerHTML = `<div class="ps-empty ps-empty--error"><div class="ps-empty-title">Không tải được KPI</div><div class="ps-empty-sub">${psEsc(e.message)}</div></div>`;
      root.querySelector('#ps-kpi-foot').innerHTML = `<button type="button" class="ps-btn ps-btn--ghost" data-close>Đóng</button>`;
    }
  }

  function close() {
    if (!root) return;
    root.hidden = true;
    document.body.classList.remove('ps-modal-open');
  }

  return { open, close };
})();
