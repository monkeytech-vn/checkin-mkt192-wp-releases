/**
 * Staff Notifications Component for App Thợ
 * Displays staff notifications in the app with a notification bell and list
 *
 * @package Checkin_MKT192_WP
 * @since 7.0.0
 */

(function () {
  'use strict';

  // Configuration
  const CONFIG = {
    apiEndpoint: '/wp-json/vg/v1/notifications/active',
    storageKey: 'checkin_staff_read_notifications',
    pollInterval: 30000, // Check for new notifications every 30 seconds
    type: 'staff',
  };

  // State
  let notifications = [];
  let unreadCount = 0;
  let containerElement = null;
  let isOpen = false;
  let pollIntervalId = null;

  // ============================================================================
  // INITIALIZATION
  // ============================================================================

  document.addEventListener('DOMContentLoaded', () => {
    // Only run on app-tho page
    if (!isAppThoPage()) return;

    // Wait for page to load
    setTimeout(initStaffNotifications, 1000);
  });

  function isAppThoPage() {
    // Check for app-tho or user-profile page (both use staff notifications)
    return (
      window.location.pathname.includes('app-tho') ||
      window.location.pathname.includes('user-profile') ||
      document.querySelector('[data-page="app-tho"]') !== null ||
      document.querySelector('[data-page="user-profile"]') !== null ||
      document.body.classList.contains('app-tho') ||
      document.getElementById('notification-bell-container') !== null
    );
  }

  async function initStaffNotifications() {
    // Create notification bell UI
    createNotificationBell();

    // Load notifications
    await loadNotifications();

    // Set up polling for new notifications
    pollIntervalId = setInterval(loadNotifications, CONFIG.pollInterval);

    // Reload notifications when page becomes visible (PWA/tab switch)
    document.addEventListener('visibilitychange', handleVisibilityChange);

    // Listen for focus events (when app regains focus)
    window.addEventListener('focus', handleWindowFocus);

    // Check for notification from URL param
    checkUrlNotification();

    // Expose refresh function globally for external calls
    window.refreshStaffNotifications = loadNotifications;
  }

  // Handle page visibility change (important for PWA)
  function handleVisibilityChange() {
    if (document.visibilityState === 'visible') {
      // Reload notifications when page becomes visible
      loadNotifications();
    }
  }

  // Handle window focus (tab/window switch)
  let lastFocusTime = 0;
  function handleWindowFocus() {
    const now = Date.now();
    // Only refresh if more than 5 seconds since last focus
    if (now - lastFocusTime > 5000) {
      lastFocusTime = now;
      loadNotifications();
    }
  }

  function checkUrlNotification() {
    const urlParams = new URLSearchParams(window.location.search);
    const notificationId = urlParams.get('notification');

    if (notificationId) {
      // Find and show the notification
      const notification = notifications.find((n) => n.id == notificationId);
      if (notification) {
        openNotificationDetail(notification);
      }
      // Clean up URL
      const url = new URL(window.location);
      url.searchParams.delete('notification');
      window.history.replaceState({}, '', url);
    }
  }

  // ============================================================================
  // UI CREATION
  // ============================================================================

  function createNotificationBell() {
    // Add styles first
    addStyles();

    // Create notification bell button
    const bellButton = document.createElement('button');
    bellButton.className = 'staff-notification-bell';
    bellButton.innerHTML = `
      <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
        <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
      </svg>
      <span class="notification-badge" style="display: none;">0</span>
    `;
    bellButton.setAttribute('aria-label', 'Thông báo');
    bellButton.addEventListener('click', toggleNotificationPanel);

    // Create notification panel
    containerElement = document.createElement('div');
    containerElement.className = 'staff-notification-panel';
    containerElement.innerHTML = `
      <div class="notification-panel-header">
        <h3>
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
            <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
          </svg>
          Thông báo
        </h3>
        <div class="notification-panel-actions">
          <button type="button" class="mark-all-read-btn" title="Đánh dấu tất cả đã đọc">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <polyline points="20 6 9 17 4 12"></polyline>
            </svg>
          </button>
          <button type="button" class="notification-panel-close" title="Đóng">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <line x1="18" y1="6" x2="6" y2="18"></line>
              <line x1="6" y1="6" x2="18" y2="18"></line>
            </svg>
          </button>
        </div>
      </div>
      <div class="notification-panel-list"></div>
    `;

    // Find a good place to insert the bell
    // Find a good place to insert the bell - prioritize notification-bell-container
    const bellContainer = document.getElementById('notification-bell-container');
    const header = document.querySelector('.sidebar-header, .header, .navbar');

    if (bellContainer) {
      bellContainer.appendChild(bellButton);
    } else if (header) {
      header.style.position = 'relative';
      header.appendChild(bellButton);
    } else {
      document.body.appendChild(bellButton);
    }

    document.body.appendChild(containerElement);

    // Event listeners
    containerElement.querySelector('.mark-all-read-btn').addEventListener('click', markAllAsRead);
    containerElement
      .querySelector('.notification-panel-close')
      .addEventListener('click', closeNotificationPanel);

    // Close panel when clicking outside
    document.addEventListener('click', (e) => {
      if (isOpen && !containerElement.contains(e.target) && !bellButton.contains(e.target)) {
        closeNotificationPanel();
      }
    });

    // Close on escape
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && isOpen) {
        closeNotificationPanel();
      }
    });
  }

  function toggleNotificationPanel() {
    if (isOpen) {
      closeNotificationPanel();
    } else {
      openNotificationPanel();
    }
  }

  function openNotificationPanel() {
    containerElement.classList.add('active');
    isOpen = true;
    renderNotificationList();
  }

  function closeNotificationPanel() {
    containerElement.classList.remove('active');
    isOpen = false;
  }

  // ============================================================================
  // NOTIFICATIONS LOADING
  // ============================================================================

  async function loadNotifications() {
    try {
      // Get branch ID if available
      let branchId = '';
      if (typeof checkinData !== 'undefined' && checkinData.currentUser?.branch_id) {
        branchId = checkinData.currentUser.branch_id;
      }

      const response = await fetch(
        `${CONFIG.apiEndpoint}?type=${CONFIG.type}&branch_id=${branchId}&limit=20`,
        {
          headers: {
            'X-WP-Nonce': typeof checkinData !== 'undefined' ? checkinData.nonce : '',
          },
        }
      );

      const result = await response.json();

      if (result.success && result.data) {
        notifications = result.data;
        updateUnreadCount();

        if (isOpen) {
          renderNotificationList();
        }
      }
    } catch (error) {
      console.error('[StaffNotifications] Error loading:', error);
    }
  }

  function updateUnreadCount() {
    const readNotifications = getReadNotifications();
    unreadCount = notifications.filter((n) => !readNotifications.includes(String(n.id))).length;

    const badge = document.querySelector('.staff-notification-bell .notification-badge');
    if (badge) {
      badge.textContent = unreadCount > 9 ? '9+' : unreadCount;
      badge.style.display = unreadCount > 0 ? 'flex' : 'none';
    }
  }

  function renderNotificationList() {
    const listContainer = containerElement.querySelector('.notification-panel-list');
    if (!listContainer) return;

    if (notifications.length === 0) {
      listContainer.innerHTML = `
        <div class="notification-empty">
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1">
            <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
            <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
            <line x1="1" y1="1" x2="23" y2="23"></line>
          </svg>
          <p>Không có thông báo mới</p>
        </div>
      `;
      return;
    }

    const readNotifications = getReadNotifications();

    listContainer.innerHTML = notifications
      .map((notification) => {
        const isRead = readNotifications.includes(String(notification.id));
        const timeAgo = getTimeAgo(notification.created_at);

        return `
          <div class="notification-item ${isRead ? 'read' : 'unread'}" data-id="${notification.id}">
            <div class="notification-item-indicator"></div>
            <div class="notification-item-content">
              <h4>${escapeHtml(notification.title)}</h4>
              <p>${escapeHtml(truncateText(notification.content, 80))}</p>
              <span class="notification-time">${timeAgo}</span>
            </div>
            ${
              notification.media_url
                ? '<div class="notification-item-media"><img src="' +
                  notification.media_url +
                  '" alt="" /></div>'
                : ''
            }
          </div>
        `;
      })
      .join('');

    // Add click handlers
    listContainer.querySelectorAll('.notification-item').forEach((item) => {
      item.addEventListener('click', () => {
        const id = item.dataset.id;
        const notification = notifications.find((n) => n.id == id);
        if (notification) {
          markAsRead(id);
          openNotificationDetail(notification);
        }
      });
    });
  }

  // ============================================================================
  // NOTIFICATION DETAIL
  // ============================================================================

  function openNotificationDetail(notification) {
    closeNotificationPanel();

    // Create detail modal
    const modal = document.createElement('div');
    modal.className = 'staff-notification-detail-modal active';
    modal.innerHTML = `
      <div class="notification-detail-container">
        <button type="button" class="notification-detail-close" aria-label="Đóng">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <line x1="18" y1="6" x2="6" y2="18"></line>
            <line x1="6" y1="6" x2="18" y2="18"></line>
          </svg>
        </button>

        ${
          notification.media_url
            ? notification.media_type === 'video'
              ? `<div class="notification-detail-media"><video src="${notification.media_url}" controls playsinline></video></div>`
              : `<div class="notification-detail-media"><img src="${
                  notification.media_url
                }" alt="${escapeHtml(notification.title)}" /></div>`
            : ''
        }

        <div class="notification-detail-body">
          <h2>${escapeHtml(notification.title)}</h2>
          <div class="notification-detail-content">${formatContent(notification.content)}</div>
          <span class="notification-detail-time">${formatDate(notification.created_at)}</span>

          ${
            notification.link
              ? `<a href="${notification.link}" class="notification-detail-link" target="_blank" rel="noopener">
                  Xem chi tiết
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path>
                    <polyline points="15 3 21 3 21 9"></polyline>
                    <line x1="10" y1="14" x2="21" y2="3"></line>
                  </svg>
                </a>`
              : ''
          }
        </div>
      </div>
    `;

    document.body.appendChild(modal);
    document.body.style.overflow = 'hidden';

    // Close handlers
    const closeModal = () => {
      modal.classList.remove('active');
      document.body.style.overflow = '';
      setTimeout(() => modal.remove(), 300);
    };

    modal.querySelector('.notification-detail-close').addEventListener('click', closeModal);
    modal.addEventListener('click', (e) => {
      if (e.target === modal) closeModal();
    });

    document.addEventListener('keydown', function escHandler(e) {
      if (e.key === 'Escape') {
        closeModal();
        document.removeEventListener('keydown', escHandler);
      }
    });

    // Track view
    trackView(notification.id);
  }

  // ============================================================================
  // READ STATE MANAGEMENT
  // ============================================================================

  function getReadNotifications() {
    try {
      const data = localStorage.getItem(CONFIG.storageKey);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  }

  function markAsRead(notificationId) {
    try {
      const readNotifications = getReadNotifications();
      if (!readNotifications.includes(String(notificationId))) {
        readNotifications.push(String(notificationId));
        localStorage.setItem(CONFIG.storageKey, JSON.stringify(readNotifications));
        updateUnreadCount();

        // Update UI
        const item = containerElement.querySelector(
          `.notification-item[data-id="${notificationId}"]`
        );
        if (item) {
          item.classList.remove('unread');
          item.classList.add('read');
        }
      }
    } catch (error) {
      console.error('[StaffNotifications] Error marking as read:', error);
    }
  }

  function markAllAsRead() {
    try {
      const allIds = notifications.map((n) => String(n.id));
      localStorage.setItem(CONFIG.storageKey, JSON.stringify(allIds));
      updateUnreadCount();
      renderNotificationList();
    } catch (error) {
      console.error('[StaffNotifications] Error marking all as read:', error);
    }
  }

  async function trackView(notificationId) {
    try {
      await fetch(`/wp-json/vg/v1/notifications/${notificationId}/view`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-WP-Nonce': typeof checkinData !== 'undefined' ? checkinData.nonce : '',
        },
      });
    } catch {
      // Silent fail
    }
  }

  // ============================================================================
  // STYLES
  // ============================================================================

  function addStyles() {
    // CSS is loaded from staff-notifications.css file
    // This function is kept for backward compatibility but does nothing
    // All styles are now in: frontend/assets/css/components/staff-notifications.css
  }

  // ============================================================================
  // UTILITIES
  // ============================================================================

  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  /**
   * Format content để hiển thị trong notification detail
   * Giữ lại các thẻ định dạng an toàn (bold, italic, underline, br, list)
   */
  function formatContent(html) {
    if (!html) return '';

    // Danh sách các thẻ HTML được phép (an toàn)
    const allowedTags = {
      strong: true,
      b: true, // Bold
      em: true,
      i: true, // Italic
      u: true, // Underline
      s: true,
      strike: true,
      del: true, // Strikethrough
      br: true, // Line break
      p: true,
      div: true, // Paragraphs
      ul: true,
      ol: true,
      li: true, // Lists
      a: true, // Links
      span: true, // Spans (for styling)
    };

    // Tạo DOM parser để xử lý HTML an toàn
    const doc = new DOMParser().parseFromString(html, 'text/html');

    // Hàm đệ quy để sanitize nodes
    function sanitizeNode(node) {
      if (node.nodeType === Node.TEXT_NODE) {
        return document.createTextNode(node.textContent);
      }

      if (node.nodeType === Node.ELEMENT_NODE) {
        const tagName = node.tagName.toLowerCase();

        if (allowedTags[tagName]) {
          const newElement = document.createElement(tagName);

          // Chỉ cho phép href cho thẻ a
          if (tagName === 'a' && node.hasAttribute('href')) {
            const href = node.getAttribute('href');
            // Chỉ cho phép http, https URLs
            if (href.startsWith('http://') || href.startsWith('https://')) {
              newElement.setAttribute('href', href);
              newElement.setAttribute('target', '_blank');
              newElement.setAttribute('rel', 'noopener noreferrer');
            }
          }

          // Xử lý children
          for (const child of node.childNodes) {
            const sanitizedChild = sanitizeNode(child);
            if (sanitizedChild) {
              newElement.appendChild(sanitizedChild);
            }
          }

          return newElement;
        } else {
          // Thẻ không được phép - chỉ lấy nội dung text
          const fragment = document.createDocumentFragment();
          for (const child of node.childNodes) {
            const sanitizedChild = sanitizeNode(child);
            if (sanitizedChild) {
              fragment.appendChild(sanitizedChild);
            }
          }
          return fragment;
        }
      }

      return null;
    }

    // Sanitize body content
    const fragment = document.createDocumentFragment();
    for (const child of doc.body.childNodes) {
      const sanitizedChild = sanitizeNode(child);
      if (sanitizedChild) {
        fragment.appendChild(sanitizedChild);
      }
    }

    // Convert fragment to HTML string
    const container = document.createElement('div');
    container.appendChild(fragment);

    return container.innerHTML;
  }

  function truncateText(text, maxLength) {
    if (text.length <= maxLength) return text;
    return text.substring(0, maxLength) + '...';
  }

  function getTimeAgo(dateString) {
    if (!dateString) return '';

    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMins / 60);
    const diffDays = Math.floor(diffHours / 24);

    if (diffMins < 1) return 'Vừa xong';
    if (diffMins < 60) return `${diffMins} phút trước`;
    if (diffHours < 24) return `${diffHours} giờ trước`;
    if (diffDays < 7) return `${diffDays} ngày trước`;

    return formatDate(dateString);
  }

  function formatDate(dateString) {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString('vi-VN', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  }
})();
