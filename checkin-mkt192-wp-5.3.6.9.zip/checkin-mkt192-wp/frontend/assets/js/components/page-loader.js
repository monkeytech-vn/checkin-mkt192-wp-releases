/**
 * Page Loader Helper - Reusable JavaScript utility
 * Version: 1.0.0
 * Description: Simple API for showing/hiding page loader
 */

(function (window) {
  'use strict';

  /**
   * PageLoader class
   */
  class PageLoader {
    constructor() {
      this.loader = null;
      this.text = null;
      this.subtitle = null;
      this.isVisible = false;
      this.initPromise = null;

      // Wait for DOM to be ready before initializing
      if (document.readyState === 'loading') {
        this.initPromise = new Promise((resolve) => {
          document.addEventListener('DOMContentLoaded', () => {
            this.init();
            resolve();
          });
        });
      } else {
        this.init();
        this.initPromise = Promise.resolve();
      }
    }

    /**
     * Initialize loader
     */
    init() {
      // Check if loader already exists
      this.loader = document.getElementById('mkt192-page-loader');

      if (!this.loader) {
        // Create loader if not exists
        this.createLoader();
      }

      if (this.loader) {
        this.text = this.loader.querySelector('.mkt192-page-loader-text');
        this.subtitle = this.loader.querySelector('.mkt192-page-loader-subtitle');
        // Hide loader initially
        this.hide();
      }
    }

    /**
     * Create loader HTML
     */
    createLoader() {
      // Safety check: ensure body exists
      if (!document.body) {
        console.warn('PageLoader: document.body not available yet');
        return;
      }

      const loaderHTML = `
        <div id="mkt192-page-loader" class="mkt192-page-loader hidden" role="status" aria-live="polite">
          <div class="mkt192-page-loader-container">
            <div class="mkt192-page-loader-spinner" aria-hidden="true">
              <div class="mkt192-spinner-inner"></div>
            </div>
            <div class="mkt192-page-loader-text">Đang tải dữ liệu</div>
            <div class="mkt192-page-loader-subtitle"></div>
          </div>
        </div>
      `;

      // Insert at the beginning of body
      document.body.insertAdjacentHTML('afterbegin', loaderHTML);
      this.loader = document.getElementById('mkt192-page-loader');
    }

    /**
     * Show loader
     * @param {Object} options - Options for showing loader
     * @param {string} options.text - Main loading text
     * @param {string} options.subtitle - Subtitle text (optional)
     */
    async show(options = {}) {
      // Wait for initialization if needed
      if (this.initPromise) {
        await this.initPromise;
      }

      if (!this.loader) {
        console.warn('PageLoader: Loader element not found');
        return;
      }

      // Update text if provided
      if (options.text && this.text) {
        this.text.textContent = options.text;
      }

      // Update subtitle if provided
      if (options.subtitle && this.subtitle) {
        this.subtitle.textContent = options.subtitle;
      } else if (this.subtitle) {
        this.subtitle.textContent = '';
      }

      // Show loader
      this.loader.classList.remove('hidden');
      this.loader.setAttribute('aria-hidden', 'false');
      this.isVisible = true;

      // Prevent body scroll
      if (document.body) {
        document.body.style.overflow = 'hidden';
      }
    }

    /**
     * Hide loader
     * @param {number} delay - Delay before hiding (ms)
     */
    hide(delay = 0) {
      if (!this.loader) return;

      const hideAction = () => {
        this.loader.classList.add('hidden');
        this.loader.setAttribute('aria-hidden', 'true');
        this.isVisible = false;

        // Restore body scroll
        document.body.style.overflow = '';
      };

      if (delay > 0) {
        setTimeout(hideAction, delay);
      } else {
        hideAction();
      }
    }

    /**
     * Update loading text
     * @param {string} text - New text
     */
    updateText(text) {
      if (this.text && text) {
        this.text.textContent = text;
      }
    }

    /**
     * Update subtitle
     * @param {string} subtitle - New subtitle
     */
    updateSubtitle(subtitle) {
      if (this.subtitle) {
        this.subtitle.textContent = subtitle || '';
      }
    }

    /**
     * Check if loader is visible
     * @returns {boolean}
     */
    isShowing() {
      return this.isVisible;
    }
  }

  // Create global instance
  window.MKT192PageLoader = new PageLoader();

  // Expose simple API (with async support)
  window.showPageLoader = async function (options) {
    await window.MKT192PageLoader.show(options);
  };

  window.hidePageLoader = function (delay) {
    window.MKT192PageLoader.hide(delay);
  };
})(window);
