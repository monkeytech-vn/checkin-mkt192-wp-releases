/**
 * Modern Image Loader 2025+
 * Ultra-fast, smooth loading with GPU acceleration
 * No canvas processing - instant load for performance
 */

class ModernImageLoader {
  constructor(options = {}) {
    this.options = {
      rootMargin: '200px 0px', // Preload khi còn cách 200px
      threshold: 0.01,
      ...options,
    };
    this.observer = null;
    this.init();
  }

  init() {
    // Use IntersectionObserver for lazy loading
    if ('IntersectionObserver' in window) {
      this.observer = new IntersectionObserver(this.handleIntersection.bind(this), {
        rootMargin: this.options.rootMargin,
        threshold: this.options.threshold,
      });
    }
  }

  /**
   * Handle intersection - load image when visible
   */
  handleIntersection(entries) {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        this.loadImage(entry.target);
        this.observer.unobserve(entry.target);
      }
    });
  }

  /**
   * Fast image loading with instant fade-in
   */
  loadImage(container) {
    const img = container.querySelector('img[data-src]');
    if (!img) return;

    const src = img.dataset.src;
    if (!src) return;

    // Preload image in background
    const preloadImg = new Image();

    preloadImg.onload = () => {
      // Use requestAnimationFrame for smooth frame timing
      requestAnimationFrame(() => {
        img.src = src;
        img.removeAttribute('data-src');

        // Trigger GPU-accelerated fade-in
        requestAnimationFrame(() => {
          container.classList.add('loaded');
        });
      });
    };

    preloadImg.onerror = () => {
      console.warn('Failed to load:', src);
      container.classList.add('load-error');
    };

    // Start loading
    preloadImg.src = src;
  }

  /**
   * Observe elements for lazy loading
   */
  observe(elements) {
    if (!this.observer) {
      // Fallback for browsers without IntersectionObserver
      this.loadAllImmediately(elements);
      return;
    }

    if (typeof elements === 'string') {
      elements = document.querySelectorAll(elements);
    }
    if (elements instanceof NodeList) {
      elements = Array.from(elements);
    }
    if (!Array.isArray(elements)) {
      elements = [elements];
    }
    elements.forEach((el) => this.observer.observe(el));
  }

  /**
   * Immediately load images (for above-the-fold content)
   */
  loadImmediately(containers) {
    if (!Array.isArray(containers)) {
      containers = [containers];
    }
    containers.forEach((container) => {
      const img = container.querySelector('img[data-src]');
      if (img && img.dataset.src) {
        img.src = img.dataset.src;
        img.removeAttribute('data-src');
        img.onload = () => {
          container.classList.add('loaded');
        };
      }
    });
  }

  /**
   * Load all immediately (fallback)
   */
  loadAllImmediately(elements) {
    if (typeof elements === 'string') {
      elements = document.querySelectorAll(elements);
    }
    if (elements instanceof NodeList) {
      elements = Array.from(elements);
    }
    if (!Array.isArray(elements)) {
      elements = [elements];
    }
    elements.forEach((el) => this.loadImage(el));
  }

  /**
   * Disconnect observer
   */
  disconnect() {
    if (this.observer) {
      this.observer.disconnect();
    }
  }
}

// Export for global use
window.ModernImageLoader = ModernImageLoader;
