// === MODAL CORE FUNCTION ===
function showCheckinModal({ type = 'info', title = 'Thông báo', message = '', buttons = [] }) {
  return new Promise((resolve) => {
    const modal = document.getElementById('notificationModal');
    const modalTitle = document.getElementById('notificationModalTitle');
    const modalMessage = document.getElementById('notificationModalMessage');
    const modalIcon = document.getElementById('notificationModalIcon');
    const modalButtons = document.getElementById('notificationModalButtons');

    modalTitle.textContent = title;
    // Sử dụng innerHTML để render HTML thay vì textContent
    modalMessage.innerHTML = message;
    modalButtons.innerHTML = '';

    // Gán icon class theo kiểu modal
    if (type === 'confirm') {
      modalIcon.className = 'fas fa-question-circle notification-modal-icon text-blue-600';
    } else if (type === 'error') {
      modalIcon.className = 'fas fa-exclamation-circle notification-modal-icon text-red-600';
    } else if (type === 'warning') {
      modalIcon.className = 'fas fa-exclamation-triangle notification-modal-icon text-yellow-500';
    } else {
      modalIcon.className = 'fas fa-info-circle notification-modal-icon text-blue-600';
    }

    // Tạo nút bấm với class tĩnh, không dùng Tailwind
    buttons.forEach((btn) => {
      const button = document.createElement('button');
      button.textContent = btn.text;
      button.className = `notification-modal-button ${
        btn.type === 'primary'
          ? 'notification-modal-button-primary'
          : 'notification-modal-button-secondary'
      }`;
      button.onclick = () => {
        closeCheckinModal(modal);
        resolve(btn.value);
      };
      modalButtons.appendChild(button);
    });

    modal.classList.add('active');
  });
}

function closeCheckinModal(modal) {
  modal.classList.remove('active');
}

// === TOAST CORE FUNCTION ===
function showCheckinToast({ message = '', type = 'success', duration = 3000 }) {
  const toastContainer = document.getElementById('checkinToastContainer');
  const toast = document.createElement('div');
  // Class names preserved — only visual changed
  toast.className = `checkin-toast-message checkin-toast-${type}`;

  // SVG icons by type (replaces FontAwesome)
  const icons = {
    success: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M20 6L9 17l-5-5"/></svg>',
    error: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="10"/><path d="M15 9l-6 6M9 9l6 6"/></svg>',
    warning: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0zM12 9v4M12 17h.01"/></svg>',
    info: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/></svg>'
  };

  toast.innerHTML = `
    <span class="checkin-toast-icon">${icons[type] || icons.info}</span>
    <span class="checkin-toast-body">
      <span class="checkin-toast-text">${message}</span>
      <button type="button" class="checkin-toast-close" aria-label="Close">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
      </button>
    </span>
    <span class="checkin-toast-progress" style="animation: checkin-toast-progress ${duration}ms linear forwards;"></span>
  `;

  // Close button handler
  toast.querySelector('.checkin-toast-close').addEventListener('click', () => {
    toast.classList.remove('active');
    setTimeout(() => toast.remove(), 350);
  });

  toastContainer.appendChild(toast);

  // Slide-down animation (like _reconcileToast)
  setTimeout(() => toast.classList.add('active'), 50);

  // Auto dismiss
  setTimeout(() => {
    toast.classList.remove('active');
    setTimeout(() => toast.remove(), 350);
  }, duration);
}

// === MODAL WRAPPERS ===
function showWarning(message, title = 'Cảnh báo') {
  return showCheckinModal({
    type: 'warning',
    title,
    message,
    buttons: [{ text: 'Đóng', value: false }],
  });
}

function showError(message, title = 'Lỗi') {
  return showCheckinModal({
    type: 'error',
    title,
    message,
    buttons: [{ text: 'Đóng', value: false }],
  });
}

function showInfo(message, title = 'Thông báo') {
  return showCheckinModal({
    type: 'info',
    title,
    message,
    buttons: [{ text: 'OK', value: true }],
  });
}

function showConfirm(message, title = 'Xác nhận') {
  return showCheckinModal({
    type: 'confirm',
    title,
    message,
    buttons: [
      { text: 'Hủy', value: false },
      { text: 'Đồng ý', value: true, type: 'primary' },
    ],
  });
}

// === TOAST WRAPPERS ===
function toastSuccess(message, duration = 3000) {
  showCheckinToast({ message, type: 'success', duration });
}

function toastError(message, duration = 3000) {
  showCheckinToast({ message, type: 'error', duration });
}

function toastWarning(message, duration = 3000) {
  showCheckinToast({ message, type: 'warning', duration });
}

function toastInfo(message, duration = 3000) {
  showCheckinToast({ message, type: 'info', duration });
}
