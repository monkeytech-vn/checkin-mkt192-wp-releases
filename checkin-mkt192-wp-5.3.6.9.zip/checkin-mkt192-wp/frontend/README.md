# 🎨 FRONTEND STRUCTURE

Thư mục này chứa tất cả tài nguyên frontend của plugin Checkin MKT192.

## 📁 Cấu trúc thư mục

```
frontend/
├── assets/                    # Tài nguyên tĩnh (CSS, JS, Images)
│   ├── css/
│   │   ├── components/        # CSS cho các component tái sử dụng
│   │   │   ├── modals.css     # Modal & Toast notifications
│   │   │   └── salary-staff.css # Salary staff component
│   │   └── pages/             # CSS cho từng trang cụ thể
│   │       ├── checkin.css
│   │       ├── checkin-dashboard.css
│   │       ├── customer-member.css
│   │       ├── customer-registration.css
│   │       ├── customer-review-offline.css
│   │       ├── customer-review-online.css
│   │       ├── admin-setting-frontend.css
│   │       ├── home.css
│   │       ├── app-tho/       # App Tho module
│   │       │   ├── app-tho.css
│   │       │   ├── sidebar.css
│   │       │   ├── invoice-services.css
│   │       │   ├── inventory.css
│   │       │   └── dark-mode.css
│   │       └── user/          # User profile pages
│   │           └── user-profile.css
│   ├── js/
│   │   ├── components/        # JavaScript components tái sử dụng
│   │   │   ├── modals.js      # Modal & Toast functionality
│   │   │   └── salary-staff.js # Salary staff functionality
│   │   └── pages/             # JavaScript cho từng trang
│   │       ├── checkin.js
│   │       ├── checkin-dashboard.js
│   │       ├── customer-member.js
│   │       ├── customer-registration.js
│   │       ├── customer-review-offline.js
│   │       ├── customer-review-online.js
│   │       ├── admin-setting-frontend.js
│   │       ├── home.js
│   │       ├── app-tho.js
│   │       └── user-profile.js
│   └── images/                # Images, icons, logos
├── pages/                     # HTML/PHP templates cho frontend
│   ├── checkin.html
│   ├── checkin-dashboard.html
│   ├── customer-member.html
│   ├── customer-registration.php
│   ├── customer-review-offline.html
│   ├── customer-review-online.html
│   ├── admin-setting-frontend.html
│   ├── home.php
│   ├── app-tho.html
│   ├── user-profile.html
│   ├── modals.html
│   ├── policy.html
│   └── terms-and-service.html
└── components/                # Reusable HTML/PHP components
    └── (Reserved for future use)

```

## 🎯 Mục đích

### 📂 `assets/`

Chứa tất cả tài nguyên tĩnh (CSS, JavaScript, Images) cho frontend.

#### `assets/css/`

- **components/**: CSS cho các component được sử dụng lại nhiều nơi (modals, forms, alerts)
- **pages/**: CSS riêng cho từng trang/module cụ thể

#### `assets/js/`

- **components/**: JavaScript modules độc lập, có thể import/reuse
- **pages/**: JavaScript logic cho từng trang cụ thể

#### `assets/images/`

- Icons, logos, illustrations
- Placeholder images
- Background images

### 📄 `pages/`

Chứa các file template HTML/PHP cho frontend pages.

- Các file được render thông qua shortcodes
- Có thể include components từ thư mục `components/`

### 🧩 `components/`

Chứa các UI components có thể tái sử dụng.

- Header/Footer components
- Form components
- Card components
- Navigation components

## 🔄 Asset Loading

Assets được load tự động thông qua:

- **File**: `includes/class-checkin-mkt192-assets.php`
- **Method**: `enqueue_frontend_assets()`

### Quy tắc load:

1. ✅ Chỉ load khi shortcode tương ứng xuất hiện
2. ✅ Dependencies được quản lý tự động
3. ✅ Version được cache-bust tự động
4. ✅ CSS load trong `<head>`
5. ✅ JS load trong footer (trừ critical scripts)

## 📝 Naming Convention

### CSS Files:

- Page CSS: `{page-name}.css` (e.g., `checkin.css`)
- Component CSS: `{component-name}.css` (e.g., `modals.css`)

### JS Files:

- Page JS: `{page-name}.js` (e.g., `checkin.js`)
- Module JS: `{module-name}.js` (e.g., `modals.js`)

### HTML/PHP Files:

- Template: `{page-name}.html` hoặc `{page-name}.php`

## 🚀 Development Guidelines

### Khi thêm page mới:

1. **Tạo CSS** trong `assets/css/pages/your-page.css`
2. **Tạo JS** trong `assets/js/pages/your-page.js`
3. **Tạo Template** trong `pages/your-page.html`
4. **Đăng ký trong** `includes/class-checkin-mkt192-assets.php`:

```php
'your_shortcode' => [
    'styles' => [
        ['handle' => 'your-page-style', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/css/pages/your-page.css', 'deps' => [], 'ver' => CHECKIN_MKT192_VERSION],
    ],
    'scripts' => [
        ['handle' => 'your-page-script', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/js/pages/your-page.js', 'deps' => ['modals-script'], 'ver' => CHECKIN_MKT192_VERSION, 'in_footer' => true],
    ],
    'localize' => [
        'handle' => 'your-page-script',
        'object_name' => 'checkinData',
        'data' => function() {
            return self::get_common_localize_data();
        },
    ],
],
```

### Best Practices:

#### CSS:

- ✅ Sử dụng CSS Variables cho colors, spacing
- ✅ BEM naming convention
- ✅ Mobile-first responsive design
- ✅ Avoid `!important` unless necessary

#### JavaScript:

- ✅ Use vanilla JS hoặc jQuery (đã có sẵn)
- ✅ Namespace các functions để tránh conflicts
- ✅ Use `checkinData` global object cho config
- ✅ Handle errors properly

#### Performance:

- ✅ Minify CSS/JS trong production
- ✅ Optimize images (WebP, compression)
- ✅ Lazy load images khi cần
- ✅ Bundle và concatenate khi có thể

## 🔧 Utilities Available

### Global JavaScript Object: `checkinData`

Mỗi page có access đến:

```javascript
checkinData.nonce; // WordPress nonce
checkinData.restUrl; // REST API URL
checkinData.pluginUrl; // Plugin URL
checkinData.logoUrl; // Brand logo
checkinData.brandName; // Brand name
checkinData.primaryColor; // Primary color
checkinData.secondaryColor; // Secondary color
checkinData.currentUser; // Current user data
// ... và nhiều hơn
```

### Modals & Notifications

File `components/modals.js` cung cấp:

```javascript
showNotification(message, type, duration);
showModal(config);
showToast(message, type, duration);
```

## 📚 Related Files

- **Asset Manager**: `includes/class-checkin-mkt192-assets.php`
- **Shortcodes**: `includes/class-checkin-mkt192-shortcodes.php`
- **Settings**: `admin/pages/class-brand-settings-page.php`

## 🎨 Design System

### Colors:

- Primary: Configurable via admin (default: `#000000`)
- Secondary: Configurable via admin (default: `#ffd700`)
- Success: `#00a32a`
- Warning: `#f0b849`
- Error: `#d63638`

### Typography:

- Font Family: Montserrat, system fonts
- Base Size: 14px
- Headings: 16px, 20px, 24px, 30px

### Spacing:

- Small: 8px
- Medium: 16px
- Large: 24px
- XLarge: 32px

### Breakpoints:

- Mobile: < 640px
- Tablet: 640px - 1024px
- Desktop: > 1024px

---

**Last Updated**: 14/11/2025
**Maintainer**: Checkin MKT192 Team
