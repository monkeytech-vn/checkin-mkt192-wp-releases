<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes" />
    <meta name="format-detection" content="telephone=no" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
    <meta name="mobile-web-app-capable" content="yes" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title>
        <?php echo esc_html(get_option('checkin_brand_name', 'Default Shop')); ?>
        - Barber Chuyên Nghiệp
    </title>
    <meta name="description"
        content="<?php echo esc_html(get_option('checkin_brand_name', 'Default Shop')); ?> - Địa chỉ cắt tóc nam đẹp và chuyên nghiệp nhất trong khu vực. Dịch vụ cắt tóc nam, barber shop, tư vấn và tạo kiểu với phong cách hoàn hảo." />
    <style>
    :root {
        --primary-color:
            <?php echo esc_html(get_option('checkin_primary_color', '#00d4aa'));
        ?>;
        --secondary-color:
            <?php echo esc_html(get_option('checkin_secondary_color', '#ff6b6b'));
        ?>;
    }

    /* Trang home: ẩn chrome mặc định của theme (header/tiêu đề trang) và khoảng trống
       phía trên vì plugin đã có header + hero riêng. Scoped nên không ảnh hưởng trang khác. */
    body:has(#hero-widget) .wp-site-blocks > header.wp-block-template-part,
    body:has(#hero-widget) .wp-block-post-title,
    body:has(#hero-widget) .wp-block-query-title,
    body:has(#hero-widget) .entry-title {
        display: none !important;
    }

    body:has(#hero-widget) .wp-site-blocks > main,
    body:has(#hero-widget) main.wp-block-group,
    body:has(#hero-widget) main > .wp-block-group,
    body:has(#hero-widget) .entry-content,
    body:has(#hero-widget) #app-root {
        margin-top: 0 !important;
        padding-top: 0 !important;
    }
    </style>
</head>

<body>
    <!-- Preloader -->
    <div class="preloader">
        <div class="preloader-icon">
            <i class="fas fa-scissors"></i>
        </div>
        <p>Loading...</p>
    </div>

    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="logo">
                <img id="logo-img" class="logo-url" src="<?php echo esc_url(get_option('checkin_logo_url', '')); ?>"
                    alt="Logo" />
            </div>
            <nav class="main-nav">
                <ul>
                    <li><a href="#home">Trang chủ</a></li>
                    <li><a href="#services-widget-menu">Dịch vụ</a></li>
                    <li><a href="#team-widget-ads">Đội ngũ</a></li>
                    <li><a href="/customer-member">Thành viên</a></li>
                    <li><a href="#gallery-sidebar-widget">Hình ảnh</a></li>
                    <li><a href="#reviews-widget-ads">Đánh giá</a></li>
                    <li><a href="#contact-widget-menu">Liên hệ</a></li>
                </ul>
            </nav>
            <div class="header-mobile-spacer">
                <div class="header-cta">
                    <a href="#team-widget-ads" class="btn btn-outline">Đặt lịch</a>
                </div>
                <div class="mobile-menu-btn">
                    <i class="fas fa-bars"></i>
                </div>
            </div>
        </div>
    </header>

    <!-- Mobile Menu (Canvas) -->
    <div class="mobile-menu">
        <div class="mobile-menu-header">
            <div class="logo">
                <img id="logo-img" class="logo-url" src="<?php echo esc_url(get_option('checkin_logo_url', '')); ?>"
                    alt="Logo" />
            </div>
            <div class="mobile-menu-close">
                <i class="fas fa-times"></i>
            </div>
        </div>
        <ul>
            <li><a href="#home">Trang chủ</a></li>
            <li><a href="#services-widget-menu">Dịch vụ</a></li>
            <li><a href="#team-widget-ads">Đội ngũ</a></li>
            <li><a href="/customer-member">Thành viên</a></li>
            <li><a href="#gallery-sidebar-widget">Hình ảnh</a></li>
            <li><a href="#reviews-widget-ads">Đánh giá</a></li>
            <li><a href="#contact-widget-menu">Liên hệ</a></li>
        </ul>
        <div class="mobile-menu-footer">
            <a href="tel:<?php echo esc_attr(get_option('checkin_phone', '+84939248305')); ?>" class="phone-link">
                <i class="fas fa-phone"></i>
                <?php echo esc_html(get_option('checkin_phone', '0939 248 305')); ?>
            </a>
            <div class="social-links">
                <?php if (get_option('checkin_fanpage')) : ?>
                <a href="<?php echo esc_url(get_option('checkin_fanpage')); ?>"><i class="fab fa-facebook-f"></i></a>
                <?php endif; ?>
                <?php if (get_option('checkin_tiktok')) : ?>
                <a href="<?php echo esc_url(get_option('checkin_tiktok')); ?>"><i class="fab fa-tiktok"></i></a>
                <?php endif; ?>
                <?php if (get_option('checkin_youtube')) : ?>
                <a href="<?php echo esc_url(get_option('checkin_youtube')); ?>"><i class="fab fa-youtube"></i></a>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div id="app-root" class="app-container webapp-layout">
        <!-- Hero Widget: showcase kiểu tóc theo cuộn trang -->
        <?php
        // Ảnh hero đặt trong uploads (không đóng gói vào plugin cho nhẹ):
        // wp-content/uploads/checkin-mkt192-wp/home/hero/{char-1..3.webp, hair-1..3.png}
        $checkin_hero_upload = wp_upload_dir();
        $checkin_hero_img = trailingslashit($checkin_hero_upload['baseurl']) . 'checkin-mkt192-wp/home/hero/';
        $checkin_hero_dir = trailingslashit($checkin_hero_upload['basedir']) . 'checkin-mkt192-wp/home/hero/';
        // Thêm ?v=mtime để tự cache-bust khi đổi ảnh (cùng tên file)
        if (!function_exists('checkin_hero_src')) {
            function checkin_hero_src($file, $baseurl, $basedir)
            {
                $url = $baseurl . $file;
                $fp = $basedir . $file;
                if (is_file($fp)) {
                    $url .= '?v=' . filemtime($fp);
                }
                return $url;
            }
        }
        ?>
        <div id="hero-widget" class="hero hero-cinema widget-dynamic app-component" data-widget="hero">
            <div class="hero-sticky">
                <div class="hero-intro-panels" aria-hidden="true">
                    <span class="hero-panel"></span>
                    <span class="hero-panel"></span>
                    <span class="hero-panel"></span>
                </div>
                <div class="hero-backdrop" aria-hidden="true"></div>
                <div class="container hero-stage">
                    <div class="hero-content hero-copy">
                        <span class="subtitle">Chào mừng đến với</span>
                        <h1><?php echo esc_html(get_option('checkin_brand_name', 'Default Shop')); ?>
                        </h1>
                        <p class="hero-tagline">💈 Tóc Đẹp Cho Quý Ông 💈</p>
                        <div class="hero-btns">
                            <a href="#services-widget-menu" class="btn btn-primary">Dịch vụ của chúng tôi</a>
                            <a href="#team-widget-ads" class="btn btn-outline">Đặt lịch ngay</a>
                        </div>
                        <div class="hero-scroll-hint" aria-hidden="true">
                            <span class="hero-scroll-hint-text">Cuộn để xem kiểu tóc</span>
                            <span class="hero-scroll-hint-line"></span>
                        </div>
                    </div>
                    <div class="hero-figure">
                        <div class="hero-char-wrap">
                            <img class="hero-char is-active" data-style="1"
                                src="<?php echo esc_url(checkin_hero_src('char-1.webp', $checkin_hero_img, $checkin_hero_dir)); ?>"
                                alt="Kiểu tóc Natural Quiff" fetchpriority="high" />
                            <img class="hero-char" data-style="2"
                                src="<?php echo esc_url(checkin_hero_src('char-2.webp', $checkin_hero_img, $checkin_hero_dir)); ?>"
                                alt="Kiểu tóc Side Part" />
                            <img class="hero-char" data-style="3"
                                src="<?php echo esc_url(checkin_hero_src('char-3.webp', $checkin_hero_img, $checkin_hero_dir)); ?>"
                                alt="Kiểu tóc Texture Fade" />
                        </div>
                        <div class="hero-hair-rail" aria-label="Chọn kiểu tóc">
                            <button type="button" class="hero-hair-thumb is-current" data-style="1"
                                aria-label="Sidepart">
                                <span class="hero-hair-name">Sidepart</span>
                                <img src="<?php echo esc_url(checkin_hero_src('hair-1.png', $checkin_hero_img, $checkin_hero_dir)); ?>" alt="" />
                            </button>
                            <button type="button" class="hero-hair-thumb" data-style="2" aria-label="Undercut">
                                <span class="hero-hair-name">Undercut</span>
                                <img src="<?php echo esc_url(checkin_hero_src('hair-2.png', $checkin_hero_img, $checkin_hero_dir)); ?>" alt="" />
                            </button>
                            <button type="button" class="hero-hair-thumb" data-style="3" aria-label="Ivy League">
                                <span class="hero-hair-name">Ivy League</span>
                                <img src="<?php echo esc_url(checkin_hero_src('hair-3.png', $checkin_hero_img, $checkin_hero_dir)); ?>" alt="" />
                            </button>
                        </div>
                    </div>
                </div>
                <div class="hero-dots" aria-hidden="true">
                    <span class="hero-dot is-current" data-style="1"></span>
                    <span class="hero-dot" data-style="2"></span>
                    <span class="hero-dot" data-style="3"></span>
                </div>
            </div>
        </div>

        <!-- About Widget -->
        <div id="about-widget-ads" class="section about-section widget-container app-module" data-widget="about">
            <div class="container">
                <div class="section-header">
                    <span class="subtitle">Về chúng tôi</span>
                    <h2 class="section-title">
                        <?php echo esc_html(get_option('checkin_brand_name', 'Default Shop')); ?>
                    </h2>
                    <div class="divider">
                        <div class="divider-line"></div>
                        <div class="divider-icon"><i class="fas fa-scissors"></i></div>
                        <div class="divider-line"></div>
                    </div>
                </div>
                <div class="about-modern-grid">
                    <div class="about-stats-cards">
                        <div class="stat-card">
                            <div class="stat-icon">
                                <i class="fas fa-cut"></i>
                            </div>
                            <div class="stat-content">
                                <h3 class="stat-number">1000 +</h3>
                                <p class="stat-label">Khách hàng đã trải nghiệm</p>
                            </div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-icon">
                                <i class="fas fa-award"></i>
                            </div>
                            <div class="stat-content">
                                <h3 class="stat-number">100 +</h3>
                                <p class="stat-label">Khách hàng hài lòng và review trên Google/ Fb</p>
                            </div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-icon">
                                <i class="fas fa-user-tie"></i>
                            </div>
                            <div class="stat-content">
                                <h3 class="stat-number">10 +</h3>
                                <p class="stat-label">Dịch vụ chất lượng</p>
                            </div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-icon">
                                <i class="fas fa-clock"></i>
                            </div>
                            <div class="stat-content">
                                <h3 class="stat-number">5 +</h3>
                                <p class="stat-label">Thợ chuyên nghiệp</p>
                            </div>
                        </div>
                    </div>
                    <div class="about-image-modern">
                        <img src="https://vangroupbarbershop.store/wp-content/uploads/2025/06/pexels-maksgelatin-4422102-scaled.jpg"
                            alt="Barber Shop <?php echo esc_html(get_option('checkin_brand_name', 'Default Shop')); ?>" />
                        <div class="about-cta-overlay">
                            <a href="#team-widget-ads" class="btn btn-primary">Đặt lịch ngay</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Features Widget -->
        <div id="features-sidebar" class="section features-section widget-dynamic app-module" data-widget="features">
            <div class="container">
                <div class="section-header">
                    <span class="subtitle">Ưu Điểm Vượt Trội</span>
                    <h2 class="section-title">
                        Tại sao chọn
                        <?php echo esc_html(get_option('checkin_brand_name', 'Default Shop')); ?>?
                    </h2>
                    <div class="divider">
                        <div class="divider-line"></div>
                        <div class="divider-icon"><i class="fas fa-scissors"></i></div>
                        <div class="divider-line"></div>
                    </div>
                </div>
                <div class="features-modern-grid">
                    <div class="feature-card-modern">
                        <div class="feature-icon-wrapper">
                            <i class="fas fa-calendar-check"></i>
                        </div>
                        <h3 class="feature-title">Tiện ích đặt lịch</h3>
                        <p class="feature-desc">Đặt lịch nhanh chóng, nhắc lịch hẹn tự động, không lo chờ đợi</p>
                    </div>
                    <div class="feature-card-modern">
                        <div class="feature-icon-wrapper">
                            <i class="fas fa-user-tie"></i>
                        </div>
                        <h3 class="feature-title">Chọn Thợ yêu thích</h3>
                        <p class="feature-desc">Tự do lựa chọn Thợ phục vụ theo ý thích</p>
                    </div>
                    <div class="feature-card-modern">
                        <div class="feature-icon-wrapper">
                            <i class="fas fa-cut"></i>
                        </div>
                        <h3 class="feature-title">Kỹ thuật chuyên nghiệp</h3>
                        <p class="feature-desc">Đào tạo bài bản, tay nghề cao</p>
                    </div>
                    <div class="feature-card-modern">
                        <div class="feature-icon-wrapper">
                            <i class="fas fa-star"></i>
                        </div>
                        <h3 class="feature-title">Ưu đãi thành viên</h3>
                        <p class="feature-desc">Giảm giá đặc biệt cho HS-SV, Thành viên</p>
                    </div>
                    <div class="feature-card-modern">
                        <div class="feature-icon-wrapper">
                            <i class="fas fa-shield-alt"></i>
                        </div>
                        <h3 class="feature-title">Bảo hành dịch vụ</h3>
                        <p class="feature-desc">Cam kết chất lượng, bảo hành nếu sản phẩm lỗi</p>
                    </div>
                    <div class="feature-card-modern">
                        <div class="feature-icon-wrapper">
                            <i class="fas fa-award"></i>
                        </div>
                        <h3 class="feature-title">Thương hiệu uy tín</h3>
                        <p class="feature-desc">Top Tiệm tóc nam tại khu vực</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Services Widget -->
        <div id="services-widget-menu" class="section services-section widget-container app-module"
            data-widget="services">
            <div class="container">
                <div class="section-header">
                    <span class="subtitle">Dịch vụ</span>
                    <h2 class="section-title">Dịch vụ của chúng tôi</h2>
                    <div class="divider">
                        <div class="divider-line"></div>
                        <div class="divider-icon"><i class="fas fa-scissors"></i></div>
                        <div class="divider-line"></div>
                    </div>
                    <p class="section-description">
                        Chúng tôi cung cấp các dịch vụ chăm sóc tóc và làm đẹp nam giới chuyên nghiệp với chất lượng
                        hàng đầu.
                    </p>
                </div>
                <div class="services-grid">
                    <div class="service-card">
                        <div class="service-image">
                            <?php
                            $haircut_images = [
                                CHECKIN_PLUGIN_URL . 'frontend/assets/images/service-section/cat-toc.jpg',
                                CHECKIN_PLUGIN_URL . 'frontend/assets/images/service-section/cat-toc-1.png',
                                CHECKIN_PLUGIN_URL . 'frontend/assets/images/service-section/cat-toc-2.png',
                                CHECKIN_PLUGIN_URL . 'frontend/assets/images/service-section/cat-toc-3.png'
                            ];
                            $haircut_images_json = htmlspecialchars(json_encode($haircut_images), ENT_QUOTES, 'UTF-8');
                            ?>
                            <img class="service-img-carousel" data-images="<?php echo $haircut_images_json; ?>" src="<?php echo $haircut_images[0]; ?>" alt="Cắt tóc" loading="lazy" />
                        </div>
                        <h3>Cắt tóc</h3>
                        <p>Dịch vụ cắt tóc nam với nhiều kiểu dáng phù hợp cho từng khuôn mặt và phong cách cá nhân.</p>
                        <span class="service-price"></span>
                    </div>
                    <div class="service-card">
                        <div class="service-image">
                            <?php
                            $shave_images = [
                                CHECKIN_PLUGIN_URL . 'frontend/assets/images/service-section/cao-mat-1.png',
                                CHECKIN_PLUGIN_URL . 'frontend/assets/images/service-section/cao-mat.jpg'
                            ];
                            $shave_images_json = htmlspecialchars(json_encode($shave_images), ENT_QUOTES, 'UTF-8');
                            ?>
                            <img class="service-img-carousel" data-images="<?php echo $shave_images_json; ?>" src="<?php echo $shave_images[0]; ?>" alt="Cạo mặt" loading="lazy" />
                        </div>
                        <h3>Cạo mặt</h3>
                        <p>Dịch vụ cạo mặt truyền thống với dao cạo chuyên dụng giúp da mặt sạch sẽ và mịn màng.</p>
                        <span class="service-price"></span>
                    </div>
                    <div class="service-card">
                        <div class="service-image">
                            <?php
                            $ear_images = [
                                CHECKIN_PLUGIN_URL . 'frontend/assets/images/service-section/ray-tai.jpg',
                                CHECKIN_PLUGIN_URL . 'frontend/assets/images/service-section/ray-tai-1.png',
                                CHECKIN_PLUGIN_URL . 'frontend/assets/images/service-section/ray-tai-2.png'
                            ];
                            $ear_images_json = htmlspecialchars(json_encode($ear_images), ENT_QUOTES, 'UTF-8');
                            ?>
                            <img class="service-img-carousel" data-images="<?php echo $ear_images_json; ?>" src="<?php echo $ear_images[0]; ?>" alt="Ráy tai" loading="lazy" />
                        </div>
                        <h3>Ráy tai</h3>
                        <p>Dịch vụ vệ sinh tai chuyên nghiệp giúp thư giãn và loại bỏ ráy tai một cách an toàn.</p>
                        <span class="service-price"></span>
                    </div>
                    <div class="service-card">
                        <div class="service-image">
                            <?php
                            $massage_images = [
                                CHECKIN_PLUGIN_URL . 'frontend/assets/images/service-section/massage-mat-1.png',
                                CHECKIN_PLUGIN_URL . 'frontend/assets/images/service-section/massage-mat.jpg'
                            ];
                            $massage_images_json = htmlspecialchars(json_encode($massage_images), ENT_QUOTES, 'UTF-8');
                            ?>
                            <img class="service-img-carousel" data-images="<?php echo $massage_images_json; ?>" src="<?php echo $massage_images[0]; ?>" alt="Massage mặt" loading="lazy" />
                        </div>
                        <h3>Massage mặt</h3>
                        <p>Massage mặt giúp thư giãn, giảm căng thẳng và cải thiện tuần hoàn máu cho da mặt.</p>
                        <span class="service-price"></span>
                    </div>
                    <div class="service-card">
                        <div class="service-image">
                            <?php
                            $dye_images = [
                                CHECKIN_PLUGIN_URL . 'frontend/assets/images/service-section/nhuom-toc.jpg',
                                CHECKIN_PLUGIN_URL . 'frontend/assets/images/service-section/nhuom-toc-1.png',
                                CHECKIN_PLUGIN_URL . 'frontend/assets/images/service-section/nhuom-toc-2.png'
                            ];
                             $dye_images_json = htmlspecialchars(json_encode($dye_images), ENT_QUOTES, 'UTF-8');
                            ?>
                            <img class="service-img-carousel" data-images="<?php echo $dye_images_json; ?>" src="<?php echo $dye_images[0]; ?>" alt="Nhuộm tóc" loading="lazy" />
                        </div>
                        <h3>Nhuộm tóc</h3>
                        <p>Dịch vụ nhuộm tóc với các màu sắc thời thượng và sản phẩm nhuộm an toàn cho tóc.</p>
                        <span class="service-price"></span>
                    </div>
                    <div class="service-card">
                        <div class="service-image">
                            <?php
                            $perm_images = [
                                CHECKIN_PLUGIN_URL . 'frontend/assets/images/service-section/uon-toc.jpg',
                                CHECKIN_PLUGIN_URL . 'frontend/assets/images/service-section/uon-toc-1.png'
                            ];
                            $perm_images_json = htmlspecialchars(json_encode($perm_images), ENT_QUOTES, 'UTF-8');
                            ?>
                            <img class="service-img-carousel" data-images="<?php echo $perm_images_json; ?>" src="<?php echo $perm_images[0]; ?>" alt="Uốn tóc" loading="lazy" />
                        </div>
                        <h3>Uốn tóc</h3>
                        <p>Dịch vụ uốn tóc giúp bạn có kiểu tóc bồng bềnh, phong cách và dễ tạo kiểu.</p>
                        <span class="service-price"></span>
                    </div>
                </div>
                <div class="text-center">
                    <a href="#team-widget-ads" class="btn btn-primary">Đặt lịch ngay</a>
                </div>
            </div>
        </div>

        <!-- Team Widget -->
        <div id="team-widget-ads" class="section team-section widget-dynamic app-module" data-widget="team">
            <div class="container">
                <div class="section-header">
                    <span class="subtitle">Đội ngũ</span>
                    <h2 class="section-title">Barber của chúng tôi</h2>
                    <div class="divider">
                        <div class="divider-line"></div>
                        <div class="divider-icon"><i class="fas fa-scissors"></i></div>
                        <div class="divider-line"></div>
                    </div>
                    <p class="section-description">
                        Đội ngũ barber chuyên nghiệp, giàu kinh nghiệm và luôn tận tâm với nghề.
                    </p>
                </div>
                <div class="team-grid">
                    <!-- Team members will be dynamically loaded here by JavaScript -->
                </div>
            </div>
        </div>

        <!-- Gallery Widget -->
        <div id="gallery-sidebar-widget" class="section gallery-section widget-container app-module"
            data-widget="gallery">
            <div class="container">
                <div class="section-header">
                    <span class="subtitle">Hình ảnh</span>
                    <h2 class="section-title">Không gian & Phong cách</h2>
                    <div class="divider">
                        <div class="divider-line"></div>
                        <div class="divider-icon"><i class="fas fa-scissors"></i></div>
                        <div class="divider-line"></div>
                    </div>
                    <p class="section-description">Một số hình ảnh về không gian tiệm và các tác phẩm của chúng tôi.</p>
                </div>
                <div class="gallery-grid">
                    <!-- Gallery items will be dynamically loaded here by JavaScript -->
                </div>
                <div class="gallery-controls mobile-only">
                    <button class="gallery-nav prev"><i class="fas fa-chevron-left"></i></button>
                    <button class="gallery-nav next"><i class="fas fa-chevron-right"></i></button>
                </div>
            </div>
        </div>

        <!-- Reviews Widget -->
        <?php
        // Check if review plugin is enabled
        $platforms_settings = get_option('checkin_mkt192_platforms_settings', []);
        $review_enabled     = isset($platforms_settings['wpsocial_ninja_enabled']) && $platforms_settings['wpsocial_ninja_enabled'] === 'yes';

        if ($review_enabled) :
        ?>
        <div id="reviews-widget-ads" class="section reviews-section widget-dynamic app-module" data-widget="reviews">
            <div class="container">
                <div class="section-header">
                    <span class="subtitle"><?php _e('Đánh giá', 'checkin-mkt192'); ?></span>
                    <h2 class="section-title">
                        <?php _e('Khách hàng nói gì về chúng tôi?', 'checkin-mkt192'); ?>
                    </h2>
                    <div class="divider">
                        <div class="divider-line"></div>
                        <div class="divider-icon"><i class="fas fa-scissors"></i></div>
                        <div class="divider-line"></div>
                    </div>
                    <p class="section-description">
                        <?php _e('Mọi phản hồi đều rất quý giá!', 'checkin-mkt192'); ?>
                    </p>
                </div>

                <!-- Dynamic shortcode for review plugin -->
                <div class="reviews-placeholder">
                    <div class="shortcode-box">
                        <?php
                $review_shortcode = get_option('checkin_review_plugin_shortcode', '[wp_social_ninja id="1921" platform="reviews"]');
                echo do_shortcode($review_shortcode);
                ?>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- FAQ Widget -->
        <div id="faq-widget-ads" class="section faq-section widget-dynamic app-module" data-widget="faq">
            <div class="container">
                <div class="section-header">
                    <span class="subtitle">Giải đáp</span>
                    <h2 class="section-title">Câu hỏi thường gặp</h2>
                    <div class="divider">
                        <div class="divider-line"></div>
                        <div class="divider-icon"><i class="fas fa-scissors"></i></div>
                        <div class="divider-line"></div>
                    </div>
                    <p class="section-description">
                        Những thắc mắc phổ biến trước khi ghé shop. Chưa thấy câu trả lời? Nhắn shop một tiếng nhé.
                    </p>
                </div>
                <div class="faq-list">
                    <div class="faq-item">
                        <button type="button" class="faq-question" aria-expanded="false">
                            <span>Tôi có cần đặt lịch trước không?</span>
                            <span class="faq-icon"><i class="fas fa-chevron-down"></i></span>
                        </button>
                        <div class="faq-answer">
                            <div>
                                <p>Bạn có thể ghé trực tiếp, nhưng đặt lịch trước giúp không phải chờ và được chọn đúng thợ mình thích. Đặt lịch chỉ mất chưa tới một phút ngay trên web.</p>
                            </div>
                        </div>
                    </div>
                    <div class="faq-item">
                        <button type="button" class="faq-question" aria-expanded="false">
                            <span>Một lần cắt tóc mất bao lâu?</span>
                            <span class="faq-icon"><i class="fas fa-chevron-down"></i></span>
                        </button>
                        <div class="faq-answer">
                            <div>
                                <p>Cắt tóc cơ bản khoảng 30 đến 45 phút. Nếu làm thêm gội, cạo mặt hay uốn nhuộm thì lâu hơn, thợ sẽ báo thời gian dự kiến trước khi bắt đầu.</p>
                            </div>
                        </div>
                    </div>
                    <div class="faq-item">
                        <button type="button" class="faq-question" aria-expanded="false">
                            <span>Tôi có được chọn thợ cắt cho mình không?</span>
                            <span class="faq-icon"><i class="fas fa-chevron-down"></i></span>
                        </button>
                        <div class="faq-answer">
                            <div>
                                <p>Được. Khi đặt lịch bạn chọn thợ yêu thích; nếu chưa quen thợ nào, quản lý sẽ gợi ý thợ phù hợp với kiểu tóc bạn muốn.</p>
                            </div>
                        </div>
                    </div>
                    <div class="faq-item">
                        <button type="button" class="faq-question" aria-expanded="false">
                            <span>Lỡ không ưng kiểu tóc thì sao?</span>
                            <span class="faq-icon"><i class="fas fa-chevron-down"></i></span>
                        </button>
                        <div class="faq-answer">
                            <div>
                                <p>Cứ nói ngay với thợ trong lúc cắt để chỉnh theo ý bạn. Nếu về nhà thấy chưa vừa, quay lại trong vài ngày shop chỉnh lại miễn phí.</p>
                            </div>
                        </div>
                    </div>
                    <div class="faq-item">
                        <button type="button" class="faq-question" aria-expanded="false">
                            <span>Giá dịch vụ tính như thế nào?</span>
                            <span class="faq-icon"><i class="fas fa-chevron-down"></i></span>
                        </button>
                        <div class="faq-answer">
                            <div>
                                <p>Bảng giá niêm yết rõ theo từng dịch vụ. Bạn xem và chọn dịch vụ ngay khi đặt lịch, không phát sinh phí ẩn.</p>
                            </div>
                        </div>
                    </div>
                    <div class="faq-item">
                        <button type="button" class="faq-question" aria-expanded="false">
                            <span>Shop nhận thanh toán chuyển khoản chứ?</span>
                            <span class="faq-icon"><i class="fas fa-chevron-down"></i></span>
                        </button>
                        <div class="faq-answer">
                            <div>
                                <p>Có. Shop nhận cả tiền mặt và chuyển khoản qua mã QR, thanh toán sau khi hoàn tất dịch vụ.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <script>
            /* FAQ accordion — mở/đóng, mỗi lúc chỉ mở 1 câu; animation max-height do CSS. */
            (function () {
                var items = document.querySelectorAll('#faq-widget-ads .faq-item');
                if (!items.length) return;
                function closeItem(it) {
                    it.classList.remove('is-open');
                    var a = it.querySelector('.faq-answer');
                    if (a) a.style.maxHeight = null;
                    var b = it.querySelector('.faq-question');
                    if (b) b.setAttribute('aria-expanded', 'false');
                }
                function openItem(it) {
                    it.classList.add('is-open');
                    var a = it.querySelector('.faq-answer');
                    if (a) a.style.maxHeight = a.scrollHeight + 'px';
                    var b = it.querySelector('.faq-question');
                    if (b) b.setAttribute('aria-expanded', 'true');
                }
                items.forEach(function (item) {
                    var btn = item.querySelector('.faq-question');
                    if (!btn) return;
                    btn.addEventListener('click', function () {
                        var willOpen = !item.classList.contains('is-open');
                        items.forEach(closeItem);
                        if (willOpen) openItem(item);
                    });
                });
                window.addEventListener('resize', function () {
                    var open = document.querySelector('#faq-widget-ads .faq-item.is-open .faq-answer');
                    if (open) open.style.maxHeight = open.scrollHeight + 'px';
                });
            })();
            </script>
        </div>

        <!-- Contact Widget -->
        <div id="contact-widget-menu" class="section contact-section widget-container app-module" data-widget="contact">
            <div class="container">
                <div class="section-header">
                    <span class="subtitle">Liên hệ</span>
                    <h2 class="section-title">Liên hệ với chúng tôi</h2>
                    <div class="divider">
                        <div class="divider-line"></div>
                        <div class="divider-icon"><i class="fas fa-scissors"></i></div>
                        <div class="divider-line"></div>
                    </div>
                    <p class="section-description">Hãy ghé thăm Shop hoặc đặt lịch hẹn ngay nhé!</p>
                </div>
                <div class="contact-container">
                    <div class="contact-info">
                        <div class="contact-item">
                            <div class="contact-icon">
                                <i class="fas fa-map-marker-alt"></i>
                            </div>
                            <div class="contact-text">
                                <h3>Địa chỉ</h3>
                                <?php
                                $branch_mode = get_option('checkin_branch_mode_enabled', '0');
                                if ($branch_mode == '1') {
                                    // Show all branch addresses
                                    global $wpdb;
                                    $table_name = $wpdb->prefix . 'checkin_mkt192_locations';
                                    $branches   = $wpdb->get_results("SELECT location_name, address, google_map_link FROM $table_name WHERE address IS NOT NULL AND address != '' ORDER BY is_main_branch DESC, id ASC");

                                    if (!empty($branches)) {
                                        echo '<ul class="address-list" style="list-style: none; padding: 0; margin: 0;">';
                                        foreach ($branches as $branch) {
                                            echo '<li style="position: relative; padding-left: 15px; margin-bottom: 10px; line-height: 1.7;">';
                                            echo '<span style="position: absolute; left: 0; color: var(--secondary-color); font-weight: bold;"></span>';
                                            echo '<strong>' . esc_html($branch->location_name) . ':</strong> ';
                                            if (!empty($branch->google_map_link)) {
                                                echo '<a href="' . esc_url($branch->google_map_link) . '" target="_blank" style="color: inherit; text-decoration: none;">';
                                                echo ' <i class="fas fa-external-link-alt" style="font-size: 0.75em;"></i></a>';
                                            } else {
                                                echo esc_html($branch->address);
                                            }
                                            echo '</li>';
                                        }
                                        echo '</ul>';
                                    } else {
                                        echo '<p>' . esc_html(get_option('checkin_address', 'Chưa có địa chỉ')) . '</p>';
                                    }
                                } else {
                                    // Show common address
                                    echo '<p>' . esc_html(get_option('checkin_address', '1238/1D Vườn Lài, Tổ 20, khu phố 1, phường An Phú Đông, Quận 12, Thành phố Hồ Chí Minh, Ho Chi Minh City, Vietnam')) . '</p>';
                                }
                                ?>
                            </div>
                        </div>
                        <div class="contact-item">
                            <div class="contact-icon">
                                <i class="fas fa-phone-alt"></i>
                            </div>
                            <div class="contact-text">
                                <h3>Điện thoại</h3>
                                <p><?php echo esc_html(get_option('checkin_phone', '0939 248 305')); ?>
                                </p>
                            </div>
                        </div>
                        <div class="contact-item">
                            <div class="contact-icon">
                                <i class="fas fa-envelope"></i>
                            </div>
                            <div class="contact-text">
                                <h3>Email</h3>
                                <a
                                    href="mailto:<?php echo esc_attr(get_option('checkin_email', 'info@vangroupbarbershop.com')); ?>">
                                    <?php echo esc_html(get_option('checkin_email', 'info@vangroupbarbershop.com')); ?>
                                </a>
                            </div>
                        </div>
                        <div class="contact-item">
                            <div class="contact-icon">
                                <i class="fas fa-clock"></i>
                            </div>
                            <div class="contact-text">
                                <h3>Giờ mở cửa</h3>
                                <p>
                                    <?php echo esc_html(get_option('checkin_opening_hours', 'Thứ 2 - CN: 08:30 - 20:30')); ?>
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="contact-map">
                        <?php
                            $google_map_src = get_option('checkin_google_map', '');
                            if (!empty($google_map_src)) {
                                echo '<iframe src="' . esc_url($google_map_src) . '" width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>';
                            } else {
                                echo '<p style="padding: 30px; text-align: center; color: var(--text-gray);">' . esc_html__('Chưa cài đặt URL bản đồ Google Map.', 'checkin-mkt192') . '</p>';
                            }
                            ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Newsletter Widget -->
        <div id="newsletter-ads-widget" class="newsletter-section widget-dynamic app-module" data-widget="newsletter">
            <div class="container">
                <div class="newsletter-container">
                    <div class="newsletter-text">
                        <h3>Đăng ký nhận tin</h3>
                        <p>Nhận thông tin khuyến mãi và các mẹo chăm sóc tóc từ chuyên gia</p>
                    </div>
                    <form class="newsletter-form">
                        <input type="email" placeholder="Nhập email của bạn" required />
                        <button type="submit" class="btn btn-primary">Đăng ký</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-grid">
                <div class="footer-col">
                    <div class="logo">
                        <img id="logo-img" class="logo-url"
                            src="<?php echo esc_url(get_option('checkin_logo_url', '')); ?>" alt="Logo" />
                    </div>
                    <p>
                        <?php echo esc_html(get_option('checkin_brand_name', 'Default Shop')); ?>
                        - Nơi tạo nên phong cách đích thực của quý ông.
                    </p>
                    <div class="footer-social">
                        <?php if (get_option('checkin_fanpage')) : ?>
                        <a href="<?php echo esc_url(get_option('checkin_fanpage')); ?>"><i
                                class="fab fa-facebook-f"></i></a>
                        <?php endif; ?>
                        <?php if (get_option('checkin_tiktok')) : ?>
                        <a href="<?php echo esc_url(get_option('checkin_tiktok')); ?>"><i class="fab fa-tiktok"></i></a>
                        <?php endif; ?>
                        <?php if (get_option('checkin_youtube')) : ?>
                        <a href="<?php echo esc_url(get_option('checkin_youtube')); ?>"><i
                                class="fab fa-youtube"></i></a>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="footer-col">
                    <h3>Liên kết</h3>
                    <ul>
                        <li><a href="#home"><i class="fas fa-chevron-right"></i>Trang chủ</a></li>
                        <li><a href="#services-widget-menu"><i class="fas fa-chevron-right"></i>Dịch vụ</a></li>
                        <li><a href="#team-widget-ads"><i class="fas fa-chevron-right"></i>Đội ngũ</a></li>
                        <li><a href="/customer-member"><i class="fas fa-chevron-right"></i>Thành viên</a></li>
                        <li><a href="#gallery-sidebar-widget"><i class="fas fa-chevron-right"></i>Hình ảnh</a></li>
                        <li><a href="#contact-widget-menu"><i class="fas fa-chevron-right"></i>Liên hệ</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h3>Dịch vụ</h3>
                    <ul>
                        <li><a href="#"><i class="fas fa-cut"></i>Cắt tóc</a></li>
                        <li><a href="#"><i class="fas fa-spa"></i>Cạo mặt</a></li>
                        <li><a href="#"><i class="fas fa-hand-holding-heart"></i>Ráy tai</a></li>
                        <li><a href="#"><i class="fas fa-paint-brush"></i>Nhuộm tóc</a></li>
                        <li><a href="#"><i class="fas fa-magic"></i>Uốn tóc</a></li>
                        <li><a href="#"><i class="fas fa-hands"></i>Massage mặt</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h3>Liên hệ</h3>
                    <ul>
                        <li>
                            <div class="footer-address">
                                <i class="fas fa-map-marker-alt" id="google-map"></i>
                                <?php
                                $branch_mode = get_option('checkin_branch_mode_enabled', '0');
                                if ($branch_mode == '1') {
                                    // Show all branch addresses
                                    global $wpdb;
                                    $table_name = $wpdb->prefix . 'checkin_mkt192_locations';
                                    $branches   = $wpdb->get_results("SELECT location_name, address, google_map_link FROM $table_name WHERE address IS NOT NULL AND address != '' ORDER BY is_main_branch DESC, id ASC");

                                    if (!empty($branches)) {
                                        echo '<ul class="address-list">';
                                        echo '<span class="address-label">Địa chỉ:</span>';
                                        foreach ($branches as $branch) {
                                            echo '<li>';
                                            echo '<strong>' . esc_html($branch->location_name) . ':</strong> ';
                                            if (!empty($branch->google_map_link)) {
                                                echo '<a href="' . esc_url($branch->google_map_link) . '" target="_blank">';
                                                echo ' <i class="fas fa-external-link-alt" style="font-size: 0.75em;"></i></a>';
                                            } else {
                                                echo esc_html($branch->address);
                                            }
                                            echo '</li>';
                                        }
                                        echo '</ul>';
                                    } else {
                                        echo '<ul class="address-list"><li>' . esc_html(get_option('checkin_address', 'Địa chỉ mặc định')) . '</li></ul>';
                                    }
                                } else {
                                    // Show common address
                                    echo '<ul class="address-list"><li>' . esc_html(get_option('checkin_address', 'Địa chỉ mặc định')) . '</li></ul>';
                                }
                                ?>
                            </div>
                        </li>
                        <li>
                            <a href="tel:<?php echo esc_attr(get_option('checkin_phone', '+84939248305')); ?>"
                                class="phone-link">
                                <i class="fas fa-phone"></i>
                                <?php echo esc_html(get_option('checkin_phone', '0939 248 305')); ?>
                            </a>
                        </li>
                        <li>
                            <a
                                href="mailto:<?php echo esc_attr(get_option('checkin_email', 'info@vangroupbarbershop.com')); ?>">
                                <i class="fas fa-envelope"></i>
                                <?php echo esc_html(get_option('checkin_email', 'info@vangroupbarbershop.com')); ?>
                            </a>
                        </li>
                        <li>
                            <div class="footer-address">
                                <i class="fas fa-clock"></i>
                                <?php echo esc_html__('Mở cửa', 'checkin-mkt192'); ?>:
                                <?php echo esc_html(get_option('checkin_opening_hours', '08:30 - 20:30 hàng ngày')); ?>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>
                    ©
                    <?php echo date('Y'); ?>
                    <?php echo esc_html(get_option('checkin_brand_name', 'Default Shop')); ?>.
                </p>
                <div class="footer-links">
                    <a href="/privacy-policy">Chính sách bảo mật</a>
                    <a href="/terms-of-service">Điều khoản sử dụng</a>
                </div>
            </div>
        </div>
    </footer>

    <!-- Back to Top Button -->
    <a href="#" class="back-to-top">
        <i class="fas fa-arrow-up"></i>
    </a>

    <!-- Mobile Native Navigation Bar -->
    <nav class="mobile-native-nav" id="mobileNativeNav">
        <div class="mobile-nav-container">
            <div class="mobile-nav-items">
                <a href="#home" class="mobile-nav-item active" data-section="home">
                    <i class="fas fa-home mobile-nav-icon"></i>
                    <span class="mobile-nav-text">Trang chủ</span>
                </a>
                <a href="#team-widget-ads" class="mobile-nav-item" data-section="team">
                    <i class="fas fa-calendar-check mobile-nav-icon"></i>
                    <span class="mobile-nav-text">Đặt lịch</span>
                </a>
                <a href="tel:<?php echo esc_attr(get_option('checkin_phone', '+84939248305')); ?>"
                    class="mobile-nav-item">
                    <i class="fas fa-phone-alt mobile-nav-icon"></i>
                    <span class="mobile-nav-text">Hotline</span>
                </a>
                <?php
                // Get main branch Google Map link from database
                global $wpdb;
                $main_branch = $wpdb->get_row(
                    "SELECT google_map_link FROM {$wpdb->prefix}checkin_mkt192_locations WHERE is_main_branch = 1 LIMIT 1"
                );
                $map_link = (!empty($main_branch) && !empty($main_branch->google_map_link))
                    ? $main_branch->google_map_link
                    : get_option('checkin_google_map', '#contact-widget-menu');
                ?>
                <a href="<?php echo esc_url($map_link); ?>" target="_blank" class="mobile-nav-item">
                    <i class="fas fa-map-marker-alt mobile-nav-icon"></i>
                    <span class="mobile-nav-text">Bản đồ</span>
                </a>
            </div>
        </div>
    </nav>

    <!-- Popup Booking -->
    <div id="bookingPopup" class="popup">
        <div id="booking-form">
            <!-- Nút đóng popup -->
            <span class="close-popup-button"><i class="fas fa-times"></i></span>

            <!-- Step 1: Nhập thông tin khách hàng, chọn chi nhánh và chọn thợ -->
            <div class="booking-step" id="step1">
                <h3><i class="fas fa-user-circle"></i> Thông Tin Đặt Lịch</h3>

                <!-- Progress Indicator -->
                <div class="booking-progress">
                    <div class="progress-step active">
                        <div class="progress-circle">1</div>
                        <div class="progress-label">Thông tin</div>
                    </div>
                    <div class="progress-step">
                        <div class="progress-circle">2</div>
                        <div class="progress-label">Dịch vụ</div>
                    </div>
                    <div class="progress-step">
                        <div class="progress-circle">3</div>
                        <div class="progress-label">Thời gian</div>
                    </div>
                    <div class="progress-step">
                        <div class="progress-circle">4</div>
                        <div class="progress-label">Xác nhận</div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="customerPhone"><i class="fas fa-phone"></i> Số điện thoại</label>
                    <input type="tel" id="customerPhone" required class="phone-input" oninput="checkCustomer()"
                        placeholder="Nhập số điện thoại của bạn" />
                </div>

                <div id="customerInfo" style="display: none" class="customer-info">
                    <p><strong><i class="fas fa-info-circle"></i> Thông tin trên hệ thống:</strong></p>
                    <p><i class="fas fa-user"></i> Tên: <span id="customerName" class="customer-name"></span></p>
                    <p><i class="fas fa-cut"></i> Thợ cũ: <span id="oldHairdresser" class="old-hairdresser"></span></p>
                </div>

                <div id="newCustomerInfo" style="display: none" class="new-customer-info">
                    <label for="customerNameInput"><i class="fas fa-signature"></i> Họ và Tên</label>
                    <input type="text" id="customerNameInput" required class="name-input" placeholder="Nhập họ và tên"
                        style="text-transform: uppercase" />
                </div>

                <?php
                // Only show branch selection if branch mode is enabled
                $branch_mode = get_option('checkin_branch_mode_enabled', '0');
                if ($branch_mode == '1') :
                ?>
                <!-- Chi Nhánh Selection - NEW with Pill Style -->
                <div class="form-group branch-select-group">
                    <label for="branchSelect"><i class="fas fa-map-marker-alt"></i> Chọn Chi Nhánh</label>
                    <div class="pill-select-container" id="branchPillContainer">
                        <div class="pill-display" id="branchPillDisplay" onclick="toggleBranchDropdown()">
                            <span class="pill-placeholder">-- Vui lòng chọn chi nhánh --</span>
                        </div>
                        <div class="pill-dropdown" id="branchDropdown" style="display: none;">
                            <ul class="pill-dropdown-list" id="branchDropdownList">
                                <!-- Options will be populated here -->
                            </ul>
                        </div>
                    </div>
                    <input type="hidden" id="branchSelect" required />
                </div>
                <?php endif; ?>

                <div class="form-group">
                    <label for="hairdresserSelect"><i class="fas fa-user-tie"></i> Thợ Phục Vụ</label>
                    <div class="pill-select-container" id="hairdresserPillContainer">
                        <div class="pill-display" id="hairdresserPillDisplay" onclick="toggleHairdresserDropdown()">
                            <span class="pill-placeholder">-- Chọn thợ phục vụ --</span>
                        </div>
                        <div class="pill-dropdown" id="hairdresserDropdown" style="display: none;">
                            <ul class="pill-dropdown-list" id="hairdresserDropdownList">
                                <!-- Options will be populated here -->
                            </ul>
                        </div>
                    </div>
                    <input type="hidden" id="hairdresserSelect" required />
                </div>



                <div id="hairdresserStatus" class="hairdresser-status"></div>

                <div class="silent-group">
                    <label for="silentService"><i class="fas fa-volume-mute"></i> Yêu cầu Thợ im lặng khi phục
                        vụ</label>
                    <label class="switch">
                        <input type="checkbox" id="silentService" />
                        <span class="slider round"></span>
                    </label>
                </div>

                <div class="button-container">
                    <button onclick="nextStep(2)" class="booking-step-next" id="step1NextBtn">Tiếp Theo <i
                            class="fas fa-arrow-right"></i></button>
                </div>
            </div>

            <!-- Branch Change Warning Modal - NEW -->
            <div id="branchWarningModal" class="branch-warning-modal">
                <div class="branch-warning-content">
                    <div class="branch-warning-icon">⚠️</div>
                    <h4>Thông Báo Đổi Chi Nhánh</h4>
                    <p id="branchWarningMessage"></p>
                    <div class="branch-warning-buttons">
                        <button class="branch-warning-confirm" onclick="confirmBranchChange()">
                            <i class="fas fa-check"></i> Đồng ý, chọn lại thợ
                        </button>
                        <button class="branch-warning-cancel" onclick="cancelBranchChange()">
                            <i class="fas fa-times"></i> Giữ nguyên
                        </button>
                    </div>
                </div>
            </div>

            <!-- Step 2: Chọn dịch vụ -->
            <div class="booking-step" id="step2" style="display: none">
                <h3><i class="fas fa-cut"></i> Chọn Dịch Vụ</h3>

                <!-- Progress Indicator -->
                <div class="booking-progress">
                    <div class="progress-step completed">
                        <div class="progress-circle"><i class="fas fa-check"></i></div>
                        <div class="progress-label">Thông tin</div>
                    </div>
                    <div class="progress-step active">
                        <div class="progress-circle">2</div>
                        <div class="progress-label">Dịch vụ</div>
                    </div>
                    <div class="progress-step">
                        <div class="progress-circle">3</div>
                        <div class="progress-label">Thời gian</div>
                    </div>
                    <div class="progress-step">
                        <div class="progress-circle">4</div>
                        <div class="progress-label">Xác nhận</div>
                    </div>
                </div>

                <div id="serviceTab" class="service-tab">
                    <!-- Tabs nhóm dịch vụ sẽ được tạo động -->
                </div>

                <input type="text" placeholder="Tìm dịch vụ..." id="searchServiceInput" oninput="filterServices()"
                    class="search-input" />

                <div id="serviceGrid" class="service-grid">
                    <!-- Các card dịch vụ sẽ được tạo động -->
                </div>

                <div id="selectedServices" class="selected-services">
                    <h4><i class="fas fa-check-double"></i> Dịch Vụ Đã Chọn</h4>
                    <!-- Danh sách dịch vụ đã chọn sẽ hiển thị ở đây -->
                </div>

                <div class="button-container">
                    <button onclick="prevStep(1)" class="booking-step-prev"><i class="fas fa-arrow-left"></i> Quay
                        Lại</button>
                    <button id="nextStepBtn" onclick="nextStep(3)" class="booking-step-next" disabled>
                        Tiếp Theo <i class="fas fa-arrow-right"></i>
                    </button>
                </div>
            </div>

            <!-- Step 3: Chọn khung giờ -->
            <div class="booking-step" id="step3" style="display: none">
                <h3><i class="fas fa-clock"></i> Khung Giờ Hẹn</h3>

                <!-- Progress Indicator -->
                <div class="booking-progress">
                    <div class="progress-step completed">
                        <div class="progress-circle"><i class="fas fa-check"></i></div>
                        <div class="progress-label">Thông tin</div>
                    </div>
                    <div class="progress-step completed">
                        <div class="progress-circle"><i class="fas fa-check"></i></div>
                        <div class="progress-label">Dịch vụ</div>
                    </div>
                    <div class="progress-step active">
                        <div class="progress-circle">3</div>
                        <div class="progress-label">Thời gian</div>
                    </div>
                    <div class="progress-step">
                        <div class="progress-circle">4</div>
                        <div class="progress-label">Xác nhận</div>
                    </div>
                </div>

                <div id="bookingTab" class="booking-tab">
                    <button id="todayTab" onclick="showToday()" class="tab-button active"><i
                            class="fas fa-calendar-day"></i> Hôm Nay</button>
                    <button id="otherDayTab" onclick="showOtherDay()" class="tab-button"><i
                            class="fas fa-calendar-alt"></i> Ngày Khác</button>
                </div>
                <div id="selectedDateDisplay" class="selected-date-display"
                    style="display: none;text-align: center;margin: 10px;">
                    <span id="displayedDate"></span>
                </div>
                <div id="timeSlotsToday" class="time-slots">
                    <div id="timeButtonsToday" class="time-buttons"></div>
                    <div id="timeSlotMessageToday" class="time-slot-message"></div>
                </div>
                <div id="timeSlotsOtherDay" style="display: none" class="time-slots">
                    <div id="calendarPopup" style="display: none" class="calendar-popup">
                        <div class="calendar-container">
                            <input type="text" id="otherDate" class="date-input" placeholder="Chọn ngày..." />
                        </div>
                    </div>
                    <div id="timeButtonsOtherDay" class="time-buttons"></div>
                    <div id="timeSlotMessageOtherDay" class="time-slot-message"></div>
                </div>
                <input type="hidden" id="bookingTime" />
                <div class="button-container">
                    <button onclick="prevStep(2)" class="booking-step-prev">Quay Lại</button>
                    <button onclick="nextStep(4)" class="booking-step-next">Tiếp Theo</button>
                </div>
            </div>

            <!-- Step 4: Xác nhận và gửi booking -->
            <div class="booking-step" id="step4" style="display: none">
                <!-- Brand Name at Top -->
                <div class="confirmation-brand">
                    <h3><i class="fas fa-check-circle"></i> Xác Nhận Đặt Lịch</h3>
                    <p class="brand-name"><i class="fas fa-store"></i>
                        <?php echo esc_html(get_option('checkin_brand_name', 'MKT Checkin Suite')); ?>
                    </p>
                </div>

                <!-- Progress Indicator -->
                <div class="booking-progress">
                    <div class="progress-step completed">
                        <div class="progress-circle"><i class="fas fa-check"></i></div>
                        <div class="progress-label">Thông tin</div>
                    </div>
                    <div class="progress-step completed">
                        <div class="progress-circle"><i class="fas fa-check"></i></div>
                        <div class="progress-label">Dịch vụ</div>
                    </div>
                    <div class="progress-step completed">
                        <div class="progress-circle"><i class="fas fa-check"></i></div>
                        <div class="progress-label">Thời gian</div>
                    </div>
                    <div class="progress-step active">
                        <div class="progress-circle">4</div>
                        <div class="progress-label">Xác nhận</div>
                    </div>
                </div>

                <!-- Redesigned Confirmation Layout -->
                <div class="confirmation-grid">
                    <!-- Row 1: Date+Time (merged in column 1) + Silent Request (column 2) -->
                    <div class="confirmation-row">
                        <div class="confirmation-info date-time-merged">
                            <i class="fas fa-calendar-alt"></i>
                            <span>
                                <strong>Ngày:</strong> <span id="selectedDate"></span>
                                <span class="time-inline time-highlight">
                                    <strong id="selectedTime"></strong>
                                </span>
                            </span>
                        </div>
                        <div class="confirmation-info">
                            <i class="fas fa-volume-mute"></i>
                            <span><strong>Im lặng:</strong> <span id="selectedSilentService"></span></span>
                        </div>
                    </div>

                    <!-- Row 2: Branch + Hairdresser -->
                    <div class="confirmation-row">
                        <?php if ($branch_mode == '1') : ?>
                        <div class="confirmation-info">
                            <i class="fas fa-map-marker-alt"></i>
                            <span><strong>Chi nhánh:</strong> <span id="selectedBranch">Chưa chọn</span></span>
                        </div>
                        <?php endif; ?>
                        <div class="confirmation-info">
                            <i class="fas fa-user-tie"></i>
                            <span><strong>Thợ:</strong> <span id="selectedHairdresser"></span></span>
                        </div>
                    </div>

                    <!-- Row 3: Customer Name + Phone -->
                    <div class="confirmation-row">
                        <div class="confirmation-info">
                            <i class="fas fa-user"></i>
                            <span><strong>Khách:</strong> <span id="selectedCustomerName"></span></span>
                        </div>
                        <div class="confirmation-info">
                            <i class="fas fa-phone"></i>
                            <span><strong>SĐT:</strong> <span id="selectedCustomerPhone"></span></span>
                        </div>
                    </div>
                </div>

                <!-- Service List Full Width -->
                <div class="confirmation-info confirmation-full">
                    <i class="fas fa-cut"></i>
                    <p><strong>Dịch vụ:</strong> <span id="selectedService"></span></p>
                </div>

                <div class="form-group note-display-group">
                    <div id="noteDisplayArea" style="display: none;" class="note-display-area">
                        <div class="note-content">
                            <i class="fas fa-sticky-note"></i>
                            <div class="note-text-wrapper">
                                <strong>Ghi chú:</strong>
                                <span id="noteDisplayText"></span>
                            </div>
                        </div>
                        <button type="button" class="note-edit-btn" onclick="openNoteModal()">
                            <i class="fas fa-edit"></i>
                        </button>
                    </div>
                    <button type="button" id="addNoteBtn" class="add-note-btn" onclick="openNoteModal()">
                        <i class="fas fa-plus-circle"></i> Thêm ghi chú
                    </button>
                </div>

                <div class="button-container">
                    <button onclick="prevStep(3)" class="booking-step-prev"><i class="fas fa-arrow-left"></i> Quay
                        Lại</button>
                    <button id="submitBooking" class="booking-step-next"><i class="fas fa-check-circle"></i> Xác
                        Nhận</button>
                </div>
            </div>

            <!-- Note Modal -->
            <div id="noteModal" class="note-modal" style="display: none;">
                <div class="note-modal-content">
                    <div class="note-modal-header">
                        <h4><i class="fas fa-sticky-note"></i> Nhập Ghi Chú</h4>
                        <button type="button" class="note-modal-close" onclick="closeNoteModal()">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    <div class="note-modal-body">
                        <textarea id="noteModalTextarea" class="note-modal-textarea" rows="5"
                            placeholder="Nhập yêu cầu riêng của bạn (vd: kiểu tóc mong muốn, độ dài cắt...)"></textarea>
                    </div>
                    <div class="note-modal-footer">
                        <button type="button" class="note-modal-cancel" onclick="closeNoteModal()">
                            <i class="fas fa-times"></i> Hủy
                        </button>
                        <button type="button" class="note-modal-confirm" onclick="confirmNote()">
                            <i class="fas fa-check"></i> Xác Nhận
                        </button>
                    </div>
                </div>
            </div>

            <!-- Loading Modal -->
            <div class="booking-step" id="loadingStep" style="display: none">
                <div class="loading-container">
                    <div class="loading-icon">
                        <i class="fas fa-spinner fa-spin"></i>
                    </div>
                    <p>Đang xử lý lịch hẹn, vui lòng đợi...</p>
                </div>
            </div>

            <!-- Success Popup -->
            <div class="booking-step" id="successStep" style="display: none">
                <div class="success-container">
                    <div class="success-checkmark">
                        <svg class="checkmark" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 52 52">
                            <circle class="checkmark-circle" cx="26" cy="26" r="25" fill="none" />
                            <path class="checkmark-check" fill="none" d="M14.1 27.2l7.1 7.2 16.7-16.8" />
                        </svg>
                    </div>
                    <h3>Đặt Lịch Thành Công!</h3>
                    <p>
                        Cảm ơn Quý khách đã lựa
                        chọn<br /><?php echo esc_html(get_option('checkin_brand_name', 'Default Shop')); ?>!
                    </p>
                    <div class="success-actions">
                        <button class="btn btn-primary" id="viewReviewBtn">Xem Đánh Giá Về Shop</button>
                        <button class="btn btn-outline" id="viewBookingBtn">Xem Lịch Hẹn</button>
                    </div>
                </div>
            </div>
        </div>
    </div>


</body>

</html>