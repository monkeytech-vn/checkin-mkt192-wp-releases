<!DOCTYPE html>
<html <?php language_attributes(); ?>>

<head>
    <meta
        charset="<?php bloginfo('charset'); ?>" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>
        Đăng ký thành viên -
        <?php echo esc_html(get_option('checkin_brand_name', 'Shop')); ?>
    </title>
    <?php wp_head(); ?>
    <style>
        :root {
            --primary-color:
                <?php echo esc_attr(get_option('checkin_primary_color', '#00d4aa'));
        ?>
            ;
            --primary-dark:
                <?php $primary = get_option('checkin_primary_color', '#00d4aa');
        // Darken color by 10%
        $rgb = sscanf($primary, '#%02x%02x%02x');
        $r   = max(0, min(255, $rgb[0] * 0.85));
        $g   = max(0, min(255, $rgb[1] * 0.85));
        $b   = max(0, min(255, $rgb[2] * 0.85));
        echo sprintf('#%02x%02x%02x', $r, $g, $b);
        ?>
            ;
            --secondary-color:
                <?php echo esc_attr(get_option('checkin_secondary_color', '#ff6b6b'));
        ?>
            ;
        }
    </style>
</head>

<body <?php body_class(); ?>>
    <div class="container">
        <!-- Header với banner và logo -->
        <div class="header">
            <?php
            $banner_url = get_option('checkin_banner_url', '');
            if (!empty($banner_url)):
            ?>
            <img src="<?php echo esc_url($banner_url); ?>"
                alt="Banner" class="banner" />
            <?php else: ?>
            <div class="banner-placeholder">
                <i class="fas fa-image banner-placeholder-icon"></i>
            </div>
            <?php endif; ?>

            <div class="logo-container">
                <div class="logo-wrapper">
                    <?php
                    $logo_url = get_option('checkin_logo_url', '');
                    if (!empty($logo_url)):
                    ?>
                    <img src="<?php echo esc_url($logo_url); ?>"
                        alt="Logo" class="logo" />
                    <?php else: ?>
                    <div class="logo-placeholder">
                        <i class="fas fa-store"></i>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Card chính -->
        <div class="card">
            <h1 class="title">Đăng ký thành viên</h1>
            <p class="subtitle">
                Đăng ký để trở thành Thành viên của
                <?php echo esc_html(get_option('checkin_brand_name', 'chúng tôi')); ?>
            </p>

            <form id="registrationForm" class="form" method="POST" action="#" onsubmit="return false;">
                <!-- Số điện thoại -->
                <div class="form-group">
                    <label for="phone" class="form-label">
                        Số điện thoại <span class="required">*</span>
                    </label>
                    <div class="input-wrapper">
                        <i class="fas fa-mobile-alt input-icon"></i>
                        <input type="tel" id="phone" name="phone" class="form-input" placeholder="0987654321"
                            pattern="[0-9]{10,11}" maxlength="11" required />
                    </div>
                </div>

                <!-- Họ tên -->
                <div class="form-group">
                    <label for="name" class="form-label"> Họ tên <span class="required">*</span> </label>
                    <div class="input-wrapper">
                        <i class="fas fa-user input-icon"></i>
                        <input type="text" id="name" name="name" class="form-input" placeholder="Nguyễn Văn A"
                            required />
                    </div>
                </div>

                <!-- Ngày sinh & Giới tính (2 cột) -->
                <div class="form-row">
                    <!-- Ngày sinh -->
                    <div class="form-group">
                        <label for="birthday" class="form-label">Ngày sinh <span class="required">*</span></label>
                        <div class="input-wrapper">
                            <i class="fas fa-calendar-alt input-icon"></i>
                            <input type="date" id="birthday" name="birthday" class="form-input" required />
                        </div>
                    </div>

                    <!-- Giới tính -->
                    <div class="form-group">
                        <label for="gender" class="form-label">Giới tính</label>
                        <div class="input-wrapper select-wrapper">
                            <i class="fas fa-venus-mars input-icon"></i>
                            <select id="gender" name="gender" class="form-select">
                                <option value="">-- Chọn --</option>
                                <option value="Nam">Nam</option>
                                <option value="Nữ">Nữ</option>
                                <option value="Khác">Khác</option>
                            </select>
                            <i class="fas fa-chevron-down select-arrow"></i>
                        </div>
                    </div>
                </div>

                <!-- Email -->
                <div class="form-group">
                    <label for="email" class="form-label">Email</label>
                    <div class="input-wrapper">
                        <i class="fas fa-envelope input-icon"></i>
                        <input type="email" id="email" name="email" class="form-input"
                            placeholder="email@example.com" />
                    </div>
                </div>

                <!-- Địa chỉ -->
                <div class="form-group">
                    <label for="address" class="form-label">Địa chỉ</label>
                    <div class="input-wrapper">
                        <i class="fas fa-map-marker-alt input-icon"></i>
                        <input type="text" id="address" name="address" class="form-input"
                            placeholder="123 Nguyễn Văn Linh, Q7, TPHCM" />
                    </div>
                </div>

                <!-- Checkbox đồng ý -->
                <div class="checkbox-group">
                    <input type="checkbox" id="agree" name="agree" class="checkbox-input" required />
                    <label for="agree" class="checkbox-label">
                        Đồng ý cung cấp thông tin cho
                        <strong><?php echo esc_html(get_option('checkin_brand_name', 'Shop')); ?></strong>
                    </label>
                </div>

                <!-- Button submit -->
                <button type="submit" class="btn-submit" id="submitBtn">
                    <span class="spinner"></span>
                    <span class="btn-text">
                        <i class="fas fa-user-plus"></i>
                        Đăng ký ngay
                    </span>
                </button>
            </form>
        </div>

        <!-- Footer -->
        <div class="footer">
            <p class="footer-text">
                ©
                <?php echo date('Y'); ?>
                <span
                    class="footer-brand"><?php echo esc_html(get_option('checkin_brand_name', 'Shop')); ?></span>
            </p>
        </div>
    </div>

    <!-- Modal thông báo -->
    <div class="modal-overlay" id="modalOverlay">
        <div class="modal modal-large">
            <div class="modal-icon" id="modalIcon">
                <i class="fas fa-check-circle"></i>
            </div>
            <h2 class="modal-title" id="modalTitle">Thành công!</h2>
            <p class="modal-message" id="modalMessage">Đăng ký thành viên thành công!</p>

            <!-- Thông tin mã khuyến mãi -->
            <div class="promo-info-box" id="promoInfoBox">
                <h3 class="promo-title">🎟️ MÃ KHUYẾN MÃI THÀNH VIÊN</h3>

                <div class="promo-section">
                    <h4>ℹ️ Thông tin:</h4>
                    <ul>
                        <li>Được gửi kèm theo hóa đơn thanh toán hoặc tại nút <strong>"MÃ KMTV"</strong> bên dưới.</li>
                        <li>Giá trị: <strong>Giảm giá 20k</strong> trên tổng hóa đơn.</li>
                    </ul>
                </div>

                <div class="promo-section">
                    <h4>⚠️ Lưu ý:</h4>
                    <ul>
                        <li>Chỉ có giá trị sử dụng <strong>1 lần</strong>.</li>
                        <li>Không áp dụng vào <strong>T7 & CN</strong> hoặc các ngày <strong>Lễ, Tết</strong>.</li>
                        <li>Không áp dụng đồng thời các CTKM khác.</li>
                        <li>Chương trình có thể tạm ngưng khi có thông báo chính thức.</li>
                        <li>Hạn sử dụng: <strong>30 ngày</strong> (kể từ ngày nhận mã).</li>
                    </ul>
                </div>
            </div>

            <div class="modal-buttons">
                <button class="modal-btn modal-btn-secondary" id="modalBtnMember">
                    <i class="fas fa-ticket-alt"></i>
                    MÃ KMTV
                </button>
                <button class="modal-btn modal-btn-primary" id="modalBtn">Đóng</button>
            </div>
        </div>
    </div>

    <?php wp_footer(); ?>

    <!-- Debug: Kiểm tra JS có load không -->
    <script>
        console.log('=== Customer Registration Page Loaded ===');
        console.log('Form element:', document.getElementById('registrationForm'));
        console.log('Submit button:', document.getElementById('submitBtn'));

        // Check sau 1 giây để đảm bảo JS đã load (vì JS chính load in_footer)
        setTimeout(function() {
            const form = document.getElementById('registrationForm');
            if (form) {
                if (form.dataset.jsAttached) {
                    console.log('✅ Main JS loaded and attached successfully');
                } else {
                    console.error('❌ Main JS not loaded! Form will not work correctly.');
                }
            }
        }, 1000);
    </script>
</body>

</html>
