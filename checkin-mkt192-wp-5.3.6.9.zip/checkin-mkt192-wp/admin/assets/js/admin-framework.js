/**
 * Checkin MKT192 Admin Framework JavaScript
 * Modern admin interface framework
 * Version: 5.1.0
 */

(function ($) {
  'use strict';

  /**
   * Main CheckinAdmin object
   */
  window.CheckinAdmin = {
    /**
     * Initialize the framework
     */
    init: function () {
      console.log('Checkin Admin Framework initialized');
      this.tabs.init();
      this.forms.init();
      this.imageUploader.init();
      this.colorPicker.init();
      this.toggles.init();
      this.clipboard.init();
      this.modals.init();
    },

    /**
     * Tab Navigation System
     */
    tabs: {
      /**
       * Initialize tabs
       */
      init: function () {
        const self = this;

        // Handle tab clicks
        $('.checkin-tabs-nav a').on('click', function (e) {
          e.preventDefault();
          const targetId = $(this).attr('href');
          self.switchTab(targetId, $(this));
        });

        // Show first tab by default or hash
        const hash = window.location.hash;
        if (hash && $(hash).length) {
          self.switchTab(hash);
        } else {
          const firstTab = $('.checkin-tabs-nav a:first');
          if (firstTab.length) {
            self.switchTab(firstTab.attr('href'), firstTab);
          }
        }

        // Handle hash changes
        $(window).on('hashchange', function () {
          const hash = window.location.hash;
          if (hash && $(hash).length) {
            self.switchTab(hash);
          }
        });
      },

      /**
       * Switch to a specific tab
       * @param {string} targetId - Tab pane ID
       * @param {jQuery} $link - Tab link element (optional)
       */
      switchTab: function (targetId, $link) {
        const $tabs = $(targetId).closest('.checkin-tabs');

        // Update active states
        $tabs.find('.checkin-tabs-nav a').removeClass('active').parent().removeClass('active');
        $tabs.find('.checkin-tab-pane').removeClass('active');

        // Activate target
        $(targetId).addClass('active');

        if ($link) {
          $link.addClass('active').parent().addClass('active');
        } else {
          $tabs
            .find('.checkin-tabs-nav a[href="' + targetId + '"]')
            .addClass('active')
            .parent()
            .addClass('active');
        }

        // Update URL hash without scrolling
        if (history.pushState) {
          history.pushState(null, null, targetId);
        }

        // Trigger event
        $(document).trigger('checkin:tab:switched', [targetId]);
      },
    },

    /**
     * Form Handling
     */
    forms: {
      /**
       * Initialize form handling
       */
      init: function () {
        this.initValidation();
        this.initAjaxForms();
        this.initConditionalFields();
      },

      /**
       * Initialize form validation
       */
      initValidation: function () {
        // Real-time validation
        $(
          '.checkin-form-input[required], .checkin-form-textarea[required], .checkin-form-select[required]'
        ).on('blur', function () {
          CheckinAdmin.forms.validateField($(this));
        });

        // Form submit validation
        $('.checkin-form').on('submit', function (e) {
          let isValid = true;
          $(this)
            .find('[required]')
            .each(function () {
              if (!CheckinAdmin.forms.validateField($(this))) {
                isValid = false;
              }
            });

          if (!isValid) {
            e.preventDefault();
            CheckinAdmin.notifications.show('Vui lòng điền đầy đủ các trường bắt buộc', 'error');
          }
        });
      },

      /**
       * Validate a single field
       * @param {jQuery} $field - Field element
       * @returns {boolean} - Is valid
       */
      validateField: function ($field) {
        const $group = $field.closest('.checkin-form-group');
        const value = $field.val().trim();
        const type = $field.attr('type');

        // Remove existing errors
        $group.removeClass('has-error');
        $group.find('.checkin-form-error').remove();

        // Required check
        if ($field.prop('required') && !value) {
          this.showFieldError($field, 'Trường này là bắt buộc');
          return false;
        }

        // Email validation
        if (type === 'email' && value) {
          const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
          if (!emailRegex.test(value)) {
            this.showFieldError($field, 'Email không hợp lệ');
            return false;
          }
        }

        // URL validation
        if (type === 'url' && value) {
          const urlRegex = /^https?:\/\/.+/;
          if (!urlRegex.test(value)) {
            this.showFieldError($field, 'URL không hợp lệ');
            return false;
          }
        }

        return true;
      },

      /**
       * Show field error
       * @param {jQuery} $field - Field element
       * @param {string} message - Error message
       */
      showFieldError: function ($field, message) {
        const $group = $field.closest('.checkin-form-group');
        $group.addClass('has-error');
        $field.after('<div class="checkin-form-error">' + message + '</div>');
      },

      /**
       * Initialize AJAX form submission
       */
      initAjaxForms: function () {
        $('.checkin-ajax-form').on('submit', function (e) {
          e.preventDefault();
          const $form = $(this);
          CheckinAdmin.forms.submitAjaxForm($form);
        });
      },

      /**
       * Submit form via AJAX
       * @param {jQuery} $form - Form element
       */
      submitAjaxForm: function ($form) {
        const $button = $form.find('button[type="submit"]');
        const formData = new FormData($form[0]);

        // Add action if specified
        if ($form.data('action')) {
          formData.append('action', $form.data('action'));
        }

        // Add nonce
        formData.append('nonce', window.checkinMKT192?.nonce || '');

        // Disable button
        $button.prop('disabled', true).addClass('checkin-button-loading');

        // Submit
        CheckinAdmin.ajax.request({
          url: window.ajaxurl || '/wp-admin/admin-ajax.php',
          method: 'POST',
          data: formData,
          processData: false,
          contentType: false,
          success: function (response) {
            if (response.success) {
              CheckinAdmin.notifications.show(
                response.data?.message || 'Lưu thành công!',
                'success'
              );
              $(document).trigger('checkin:form:success', [response]);
            } else {
              CheckinAdmin.notifications.show(response.data?.message || 'Có lỗi xảy ra!', 'error');
            }
          },
          error: function (xhr, status, error) {
            CheckinAdmin.notifications.show('Lỗi kết nối: ' + error, 'error');
          },
          complete: function () {
            $button.prop('disabled', false).removeClass('checkin-button-loading');
          },
        });
      },

      /**
       * Initialize conditional fields
       */
      initConditionalFields: function () {
        // Show/hide fields based on toggle state
        $('[data-toggle-target]').on('change', function () {
          const targetSelector = $(this).data('toggle-target');
          const $target = $(targetSelector);

          if ($(this).is(':checked')) {
            $target.slideDown(200);
          } else {
            $target.slideUp(200);
          }
        });

        // Initialize state
        $('[data-toggle-target]').trigger('change');
      },
    },

    /**
     * Image Uploader
     */
    imageUploader: {
      frame: null,

      /**
       * Initialize image uploaders
       */
      init: function () {
        const self = this;

        // Upload button
        $(document).on('click', '.checkin-upload-image', function (e) {
          e.preventDefault();
          const $button = $(this);
          const $wrapper = $button.closest('.checkin-image-uploader');
          self.openMediaLibrary($wrapper);
        });

        // Remove button
        $(document).on('click', '.checkin-remove-image', function (e) {
          e.preventDefault();
          const $wrapper = $(this).closest('.checkin-image-uploader');
          self.removeImage($wrapper);
        });
      },

      /**
       * Open WordPress media library
       * @param {jQuery} $wrapper - Uploader wrapper element
       */
      openMediaLibrary: function ($wrapper) {
        const self = this;

        // Create media frame if not exists
        if (!this.frame) {
          this.frame = wp.media({
            title: 'Chọn hình ảnh',
            button: {
              text: 'Sử dụng hình này',
            },
            multiple: false,
          });

          this.frame.on('select', function () {
            const attachment = self.frame.state().get('selection').first().toJSON();
            self.setImage($wrapper, attachment);
          });
        }

        this.frame.open();
        this.currentWrapper = $wrapper;
      },

      /**
       * Set image
       * @param {jQuery} $wrapper - Uploader wrapper
       * @param {Object} attachment - Media attachment object
       */
      setImage: function ($wrapper, attachment) {
        const $input = $wrapper.find('input[type="hidden"], input[type="text"]');
        const $preview = $wrapper.find('.checkin-image-preview');
        const $img = $preview.find('img');

        // Set URL
        $input.val(attachment.url);

        // Update preview
        if ($img.length) {
          $img.attr('src', attachment.url).show();
        } else {
          $preview.html('<img src="' + attachment.url + '" alt="">');
        }

        $preview.addClass('has-image');
        $wrapper.find('.checkin-remove-image').show();

        // Trigger event
        $(document).trigger('checkin:image:uploaded', [attachment]);
      },

      /**
       * Remove image
       * @param {jQuery} $wrapper - Uploader wrapper
       */
      removeImage: function ($wrapper) {
        const $input = $wrapper.find('input[type="hidden"], input[type="text"]');
        const $preview = $wrapper.find('.checkin-image-preview');

        $input.val('');
        $preview.find('img').attr('src', '').hide();
        $preview.removeClass('has-image');
        $wrapper.find('.checkin-remove-image').hide();

        // Trigger event
        $(document).trigger('checkin:image:removed');
      },
    },

    /**
     * Color Picker
     */
    colorPicker: {
      /**
       * Initialize color pickers
       */
      init: function () {
        if ($.fn.wpColorPicker) {
          $('.checkin-color-picker-input').wpColorPicker({
            change: function (event, ui) {
              $(document).trigger('checkin:color:changed', [ui.color.toString()]);
            },
          });
        }
      },
    },

    /**
     * Toggle Switches
     */
    toggles: {
      /**
       * Initialize toggles
       */
      init: function () {
        // Handle toggle change events
        $('.checkin-toggle input[type="checkbox"]').on('change', function () {
          const isChecked = $(this).is(':checked');
          const $toggle = $(this).closest('.checkin-toggle');

          $(document).trigger('checkin:toggle:changed', [isChecked, $toggle]);
        });
      },
    },

    /**
     * Clipboard
     */
    clipboard: {
      /**
       * Initialize clipboard functionality
       */
      init: function () {
        $(document).on('click', '[data-clipboard-text]', function (e) {
          e.preventDefault();
          const text = $(this).data('clipboard-text');
          CheckinAdmin.clipboard.copy(text);
        });

        $(document).on('click', '[data-clipboard-target]', function (e) {
          e.preventDefault();
          const targetSelector = $(this).data('clipboard-target');
          const text = $(targetSelector).val() || $(targetSelector).text();
          CheckinAdmin.clipboard.copy(text);
        });
      },

      /**
       * Copy text to clipboard
       * @param {string} text - Text to copy
       */
      copy: function (text) {
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard
            .writeText(text)
            .then(() => {
              CheckinAdmin.notifications.show('Đã sao chép!', 'success', 2000);
            })
            .catch(() => {
              this.fallbackCopy(text);
            });
        } else {
          this.fallbackCopy(text);
        }
      },

      /**
       * Fallback copy method
       * @param {string} text - Text to copy
       */
      fallbackCopy: function (text) {
        const $temp = $('<textarea>');
        $('body').append($temp);
        $temp.val(text).select();
        document.execCommand('copy');
        $temp.remove();
        CheckinAdmin.notifications.show('Đã sao chép!', 'success', 2000);
      },
    },

    /**
     * Modals
     */
    modals: {
      /**
       * Initialize modals
       */
      init: function () {
        // Open modal
        $(document).on('click', '[data-modal-target]', function (e) {
          e.preventDefault();
          const targetId = $(this).data('modal-target');
          CheckinAdmin.modals.open(targetId);
        });

        // Close modal
        $(document).on('click', '.checkin-modal-close, .checkin-modal-backdrop', function (e) {
          if (e.target === this) {
            CheckinAdmin.modals.close($(this).closest('.checkin-modal-backdrop'));
          }
        });

        // ESC key to close
        $(document).on('keydown', function (e) {
          if (e.key === 'Escape') {
            CheckinAdmin.modals.closeAll();
          }
        });
      },

      /**
       * Open modal
       * @param {string} modalId - Modal ID
       */
      open: function (modalId) {
        const $backdrop = $(modalId);
        if ($backdrop.length) {
          $backdrop.addClass('active');
          $('body').css('overflow', 'hidden');
          $(document).trigger('checkin:modal:opened', [modalId]);
        }
      },

      /**
       * Close modal
       * @param {jQuery} $backdrop - Modal backdrop element
       */
      close: function ($backdrop) {
        $backdrop.removeClass('active');
        $('body').css('overflow', '');
        $(document).trigger('checkin:modal:closed');
      },

      /**
       * Close all modals
       */
      closeAll: function () {
        $('.checkin-modal-backdrop.active').each(function () {
          CheckinAdmin.modals.close($(this));
        });
      },
    },

    /**
     * AJAX Helper
     */
    ajax: {
      /**
       * Make AJAX request
       * @param {Object} options - Request options
       */
      request: function (options) {
        const defaults = {
          url: window.ajaxurl || '/wp-admin/admin-ajax.php',
          method: 'POST',
          dataType: 'json',
          cache: false,
        };

        return $.ajax($.extend(defaults, options));
      },
    },

    /**
     * Utilities
     */
    utils: {
      /**
       * Debounce function
       * @param {Function} func - Function to debounce
       * @param {number} wait - Wait time in ms
       * @returns {Function} Debounced function
       */
      debounce: function (func, wait) {
        let timeout;
        return function executedFunction(...args) {
          const later = () => {
            clearTimeout(timeout);
            func(...args);
          };
          clearTimeout(timeout);
          timeout = setTimeout(later, wait);
        };
      },

      /**
       * Throttle function
       * @param {Function} func - Function to throttle
       * @param {number} limit - Time limit in ms
       * @returns {Function} Throttled function
       */
      throttle: function (func, limit) {
        let inThrottle;
        return function (...args) {
          if (!inThrottle) {
            func.apply(this, args);
            inThrottle = true;
            setTimeout(() => (inThrottle = false), limit);
          }
        };
      },

      /**
       * Escape HTML
       * @param {string} text - Text to escape
       * @returns {string} Escaped text
       */
      escapeHtml: function (text) {
        const map = {
          '&': '&amp;',
          '<': '&lt;',
          '>': '&gt;',
          '"': '&quot;',
          "'": '&#039;',
        };
        return text.replace(/[&<>"']/g, (m) => map[m]);
      },
    },
  };

  // Initialize on document ready
  $(document).ready(function () {
    CheckinAdmin.init();
  });
})(jQuery);
