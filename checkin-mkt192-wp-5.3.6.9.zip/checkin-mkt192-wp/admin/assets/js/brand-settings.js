/**
 * Brand Settings Page JavaScript
 * Handle brand settings modal interactions and AJAX saves
 * Version: 5.1.0
 */

(function ($) {
  'use strict';

  // Open brand modal
  window.openBrandModal = function (setting) {
    const modal = document.getElementById('modal-' + setting);
    if (modal) {
      modal.classList.add('active');
      document.body.style.overflow = 'hidden';
    }
  };

  // Close brand modal
  window.closeBrandModal = function (setting) {
    const modal = document.getElementById('modal-' + setting);
    if (modal) {
      modal.classList.remove('active');
      document.body.style.overflow = '';

      // Check if toggle is on but form not saved
      const toggle = $(`.checkin-setting-toggle[data-setting="${setting}"]`);
      if (toggle.length && toggle.is(':checked')) {
        // Check if has required data
        if (!hasRequiredData(setting)) {
          // Turn off toggle
          toggle.prop('checked', false).trigger('change');
          showNotification('Vui lòng hoàn tất cài đặt trước khi bật!', 'warning');
        }
      }
    }
  };

  // Check if setting has required data
  function hasRequiredData(setting) {
    switch (setting) {
      case 'logo-colors':
        const logoUrl = $('input[name="checkin_logo_url"]').val();
        const primaryColor = $('input[name="checkin_primary_color"]').val();
        const secondaryColor = $('input[name="checkin_secondary_color"]').val();
        return logoUrl && primaryColor && secondaryColor;

      case 'information':
        const brandName = $('input[name="checkin_brand_name"]').val();
        const email = $('input[name="checkin_email"]').val();
        return brandName && email;

      case 'social-links':
        const facebookUrl = $('input[name="checkin_facebook_url"]').val();
        return facebookUrl; // At least Facebook is required

      default:
        return false;
    }
  }

  // Close modal when clicking backdrop
  $(document).on('click', '.checkin-modal-backdrop', function (e) {
    if (e.target === this) {
      const modalId = $(this).attr('id').replace('modal-', '');
      closeBrandModal(modalId);
    }
  });

  // Close modal with ESC key
  $(document).on('keydown', function (e) {
    if (e.key === 'Escape') {
      const activeModal = $('.checkin-modal-backdrop.active');
      if (activeModal.length) {
        const modalId = activeModal.attr('id').replace('modal-', '');
        closeBrandModal(modalId);
      }
    }
  });

  // Initialize on page load
  $(document).ready(function () {
    // Initialize image upload handlers
    initImageUpload();

    // Initialize color picker sync
    initColorPicker();

    // Initialize branch mode toggle in Information modal
    initBranchModeToggle();

    // Handle card toggle switches
    $('.checkin-setting-toggle').on('change', function () {
      const setting = $(this).data('setting');
      const isEnabled = $(this).is(':checked');
      const card = $(this).closest('.checkin-setting-card');
      const statusBadge = card.find('.checkin-badge');
      const statusText = card.find('.checkin-toggle-status-text');

      // Update card state
      if (isEnabled) {
        // Check if has required data
        if (!hasRequiredData(setting)) {
          // Prevent toggle and open modal
          $(this).prop('checked', false);
          setTimeout(function () {
            openBrandModal(setting);
          }, 100);
          return;
        }

        card.removeClass('not-configured').addClass('configured');
        statusBadge
          .removeClass('checkin-badge-gray')
          .addClass('checkin-badge-success')
          .text('Đã cấu hình');
        statusText.text('Đang bật');
      } else {
        card.removeClass('configured').addClass('not-configured');
        statusBadge
          .removeClass('checkin-badge-success')
          .addClass('checkin-badge-gray')
          .text('Chưa cấu hình');
        statusText.text('Đang tắt');
      }
    });
  });

  // Handle form submission via AJAX (exclude branch form)
  $('.checkin-brand-form:not(#form-branch)').on('submit', function (e) {
    e.preventDefault();

    const form = $(this);
    const formData = new FormData(this);
    const submitBtn = form.find('button[type="submit"]');
    const settingType = form.attr('id').replace('form-', '');

    // Validate required fields
    let isValid = true;
    form.find('[required]').each(function () {
      if (!$(this).val()) {
        isValid = false;
        $(this).addClass('checkin-input-error');
      } else {
        $(this).removeClass('checkin-input-error');
      }
    });

    if (!isValid) {
      showNotification('Vui lòng điền đầy đủ các trường bắt buộc!', 'error');
      return;
    }

    // Add action and nonce
    formData.append('action', 'checkin_save_brand_settings');
    formData.append('setting_type', settingType);
    formData.append('nonce', checkinAdmin.nonce);

    // Disable submit button
    submitBtn.prop('disabled', true).addClass('checkin-button-loading');

    $.ajax({
      url: ajaxurl,
      type: 'POST',
      data: formData,
      processData: false,
      contentType: false,
      success: function (response) {
        if (response.success) {
          showNotification(response.data.message || 'Cài đặt đã được lưu!', 'success');

          // Enable toggle
          const toggle = $(`.checkin-setting-toggle[data-setting="${settingType}"]`);
          toggle.prop('checked', true).trigger('change');

          // Close modal after delay
          setTimeout(function () {
            closeBrandModal(settingType);
          }, 1000);
        } else {
          showNotification(response.data.message || 'Có lỗi xảy ra!', 'error');

          // Close modal and disable toggle on error
          setTimeout(function () {
            closeBrandModal(settingType);
            const toggle = $(`.checkin-setting-toggle[data-setting="${settingType}"]`);
            toggle.prop('checked', false);
            const card = toggle.closest('.checkin-setting-card');
            card.removeClass('configured').addClass('not-configured');
            card
              .find('.checkin-badge')
              .removeClass('checkin-badge-success')
              .addClass('checkin-badge-gray')
              .text('Chưa cấu hình');
            card.find('.checkin-toggle-status-text').text('Đang tắt');
          }, 1500);
        }
      },
      error: function () {
        showNotification('Có lỗi xảy ra khi lưu cài đặt!', 'error');

        // Close modal and disable toggle on network error
        setTimeout(function () {
          closeBrandModal(settingType);
          const toggle = $(`.checkin-setting-toggle[data-setting="${settingType}"]`);
          toggle.prop('checked', false);
          const card = toggle.closest('.checkin-setting-card');
          card.removeClass('configured').addClass('not-configured');
          card
            .find('.checkin-badge')
            .removeClass('checkin-badge-success')
            .addClass('checkin-badge-gray')
            .text('Chưa cấu hình');
          card.find('.checkin-toggle-status-text').text('Đang tắt');
        }, 1500);
      },
      complete: function () {
        submitBtn.prop('disabled', false).removeClass('checkin-button-loading');
      },
    });
  });

  /**
   * Initialize image upload functionality
   */
  function initImageUpload() {
    let mediaUploader;

    // Upload button click
    $(document).on('click', '.checkin-btn-upload-image', function (e) {
      e.preventDefault();
      const target = $(this).data('target');

      // If the uploader object has already been created, reopen the dialog
      if (mediaUploader) {
        mediaUploader.open();
        return;
      }

      // Create a new media uploader
      mediaUploader = wp.media({
        title: target === 'logo' ? 'Chọn Logo' : 'Chọn Banner',
        button: {
          text: 'Sử dụng ảnh này',
        },
        multiple: false,
      });

      // When an image is selected, run a callback
      mediaUploader.on('select', function () {
        const attachment = mediaUploader.state().get('selection').first().toJSON();
        updateImage(target, attachment.url);
      });

      // Open the uploader dialog
      mediaUploader.open();
    });

    // Show URL input box
    $(document).on('click', '.checkin-btn-input-url', function (e) {
      e.preventDefault();
      const target = $(this).data('target');
      $(`#url-input-${target}`).slideDown(300);
    });

    // Apply URL
    $(document).on('click', '.checkin-btn-apply-url', function (e) {
      e.preventDefault();
      const target = $(this).data('target');
      const url = $(`#url-input-${target} input`).val();

      if (!url) {
        showNotification('Vui lòng nhập URL!', 'warning');
        return;
      }

      // Validate URL
      try {
        new URL(url);
        updateImage(target, url);
        $(`#url-input-${target}`).slideUp(300);
        $(`#url-input-${target} input`).val('');
      } catch (error) {
        showNotification('URL không hợp lệ!', 'error');
      }
    });

    // Cancel URL input
    $(document).on('click', '.checkin-btn-cancel-url', function (e) {
      e.preventDefault();
      const target = $(this).data('target');
      $(`#url-input-${target}`).slideUp(300);
      $(`#url-input-${target} input`).val('');
    });

    // Change image
    $(document).on('click', '.checkin-btn-change-image', function (e) {
      e.preventDefault();
      const target = $(this).data('target');
      $(`.checkin-btn-upload-image[data-target="${target}"]`).trigger('click');
    });

    // Remove image
    $(document).on('click', '.checkin-btn-remove-image', function (e) {
      e.preventDefault();
      const target = $(this).data('target');

      // Confirm removal
      if (!confirm('Bạn có chắc muốn xóa ảnh này?')) {
        return;
      }

      updateImage(target, '');
    });
  }

  /**
   * Update image preview and hidden input
   */
  function updateImage(target, url) {
    const previewBox = $(`.checkin-image-preview-box[data-target="${target}"]`);
    const hiddenInput = $(`#checkin_${target}_url`);

    if (url) {
      // Show image
      previewBox.addClass('has-image').html(`
        <img src="${url}" alt="${target}" class="checkin-preview-img">
        <div class="checkin-image-overlay">
          <button type="button" class="checkin-btn-change-image" data-target="${target}">
            <span class="dashicons dashicons-edit"></span>
            Thay đổi
          </button>
          <button type="button" class="checkin-btn-remove-image" data-target="${target}">
            <span class="dashicons dashicons-trash"></span>
            Xóa
          </button>
        </div>
      `);
      hiddenInput.val(url);
    } else {
      // Show placeholder
      previewBox.removeClass('has-image').html(`
        <div class="checkin-image-placeholder">
          <span class="dashicons dashicons-format-image"></span>
          <p>Chưa có ${target === 'logo' ? 'logo' : 'banner'}</p>
        </div>
      `);
      hiddenInput.val('');
    }
  }

  /**
   * Initialize color picker
   */
  function initColorPicker() {
    // Sync color input with text display
    $(document).on('input', '.checkin-color-input', function () {
      const color = $(this).val();
      $(this).siblings('.checkin-color-text').val(color.toUpperCase());
    });

    // Initialize on page load
    $('.checkin-color-input').each(function () {
      const color = $(this).val();
      $(this).siblings('.checkin-color-text').val(color.toUpperCase());
    });
  }

  /**
   * Initialize branch mode toggle in Information modal
   */
  function initBranchModeToggle() {
    // Toggle switch handler
    $(document).on('change', '#branch-mode-toggle-brand', function () {
      const isEnabled = $(this).is(':checked');
      const statusLabel = $('#branch-mode-label-brand');
      const branchSection = $('#branch-management-section-brand');
      const commonAddressGroup = $('#common-address-group-brand');
      const commonAddressField = commonAddressGroup.find('textarea[name="checkin_address"]');

      if (isEnabled) {
        // Show branch management section
        branchSection.slideDown(300);
        // Hide common address section
        commonAddressGroup.slideUp(300);
        // Remove required from common address
        commonAddressField.removeAttr('required');
        // Update status label
        statusLabel.text('Đang bật');
      } else {
        // Hide branch management section
        branchSection.slideUp(300);
        // Show common address section
        commonAddressGroup.slideDown(300);
        // Add required back to common address
        commonAddressField.attr('required', 'required');
        // Update status label
        statusLabel.text('Đang tắt');
      }
    });

    // Add new branch button
    $(document).on('click', '.checkin-btn-add-branch', function (e) {
      e.preventDefault();
      openBranchModal();
    });

    // Edit branch button
    $(document).on('click', '.checkin-btn-edit-branch', function (e) {
      e.preventDefault();
      const branchId = $(this).data('branch-id');
      openBranchModal(branchId);
    });

    // Delete branch button
    $(document).on('click', '.checkin-btn-delete-branch', function (e) {
      e.preventDefault();
      const branchId = $(this).data('branch-id');
      deleteBranch(branchId);
    });

    // Toggle Google Map field when "Chi nhánh chính" checkbox changes
    $(document).on('change', '#branch-is-main', function () {
      const isChecked = $(this).is(':checked');
      const googleMapGroup = $('#branch-google-map-group');

      if (isChecked) {
        googleMapGroup.slideDown(300);
      } else {
        googleMapGroup.slideUp(300);
        $('#branch-google-map').val(''); // Clear value when hidden
      }
    });
  }

  /**
   * Open branch modal for add or edit
   */
  window.openBranchModal = function (branchId) {
    const modal = $('#modal-branch-form');
    const form = $('#form-branch');
    const title = $('#branch-modal-title');

    // Reset form
    form[0].reset();
    $('#branch-id').val('');

    if (branchId) {
      // Edit mode - load branch data
      title.text('Chỉnh sửa Chi nhánh');

      // Show loading overlay
      const loadingHtml =
        '<div class="checkin-page-loading" style="position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: rgba(255, 255, 255, 0.9); display: flex; align-items: center; justify-content: center; z-index: 10;"><div class="checkin-spinner"></div></div>';
      modal.find('.checkin-modal-content').css('position', 'relative').append(loadingHtml);

      $.ajax({
        url: ajaxurl,
        type: 'POST',
        data: {
          action: 'checkin_get_branch',
          branch_id: branchId,
          nonce: checkinAdmin.nonce,
        },
        success: function (response) {
          // Hide page loading
          hidePageLoading();

          if (response.success && response.data.branch) {
            const branch = response.data.branch;
            $('#branch-id').val(branch.id);
            $('#branch-name').val(branch.location_name);
            $('#branch-address').val(branch.address);
            $('#branch-map-link').val(branch.google_map_link);
            $('#branch-latitude').val(branch.latitude);
            $('#branch-longitude').val(branch.longitude);
            $('#branch-radius').val(branch.radius);
            $('#branch-is-main').prop('checked', branch.is_main_branch == 1);

            // Load Google Map embed if main branch
            if (branch.is_main_branch == 1) {
              $('#branch-google-map-group').show();
              // Load current google map from option
              $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                  action: 'checkin_get_google_map',
                  nonce: checkinAdmin.nonce,
                },
                success: function (res) {
                  if (res.success && res.data.google_map) {
                    $('#branch-google-map').val(res.data.google_map);
                  }
                },
              });
            } else {
              $('#branch-google-map-group').hide();
            }
          } else {
            showNotification(response.data.message || 'Không thể tải dữ liệu chi nhánh!', 'error');
          }
        },
        error: function () {
          // Hide page loading on error
          hidePageLoading();
          showNotification('Có lỗi khi tải dữ liệu chi nhánh!', 'error');
        },
      });
    } else {
      // Add mode
      title.text('Thêm Chi nhánh');
    }

    // Show modal
    modal.addClass('active');
    document.body.style.overflow = 'hidden';
  };

  /**
   * Close branch modal
   */
  window.closeBranchModal = function () {
    const modal = $('#modal-branch-form');
    modal.removeClass('active');
    document.body.style.overflow = '';
  };

  /**
   * Handle branch form submission
   */
  $(document).on('submit', '#form-branch', function (e) {
    e.preventDefault();

    const form = $(this);
    const formData = new FormData(this);
    const submitBtn = form.find('button[type="submit"]');

    // Validate required fields
    let isValid = true;
    form.find('[required]').each(function () {
      if (!$(this).val()) {
        isValid = false;
        $(this).addClass('checkin-input-error');
      } else {
        $(this).removeClass('checkin-input-error');
      }
    });

    if (!isValid) {
      showNotification('Vui lòng điền đầy đủ các trường bắt buộc!', 'error');
      return;
    }

    // Add action and nonce
    formData.append('action', 'checkin_save_branch');
    formData.append('nonce', checkinAdmin.nonce);

    // Disable submit button
    submitBtn.prop('disabled', true).addClass('checkin-button-loading');

    $.ajax({
      url: ajaxurl,
      type: 'POST',
      data: formData,
      processData: false,
      contentType: false,
      success: function (response) {
        if (response.success) {
          showNotification(response.data.message || 'Chi nhánh đã được lưu!', 'success');

          // Close modal after delay
          setTimeout(function () {
            closeBranchModal();
            // Reload branch list in Information modal
            reloadBranchList();
          }, 1000);
        } else {
          showNotification(response.data.message || 'Có lỗi xảy ra!', 'error');
        }
      },
      error: function () {
        showNotification('Có lỗi xảy ra khi lưu chi nhánh!', 'error');
      },
      complete: function () {
        submitBtn.prop('disabled', false).removeClass('checkin-button-loading');
      },
    });
  });

  /**
   * Delete branch
   */
  function deleteBranch(branchId) {
    if (!confirm('Bạn có chắc muốn xóa chi nhánh này?')) {
      return;
    }

    $.ajax({
      url: ajaxurl,
      type: 'POST',
      data: {
        action: 'checkin_delete_branch',
        branch_id: branchId,
        nonce: checkinAdmin.nonce,
      },
      success: function (response) {
        if (response.success) {
          showNotification(response.data.message || 'Chi nhánh đã được xóa!', 'success');
          // Reload branch list
          reloadBranchList();
        } else {
          showNotification(response.data.message || 'Có lỗi xảy ra!', 'error');
        }
      },
      error: function () {
        showNotification('Có lỗi xảy ra khi xóa chi nhánh!', 'error');
      },
    });
  }

  /**
   * Reload branch list in Information modal (realtime update)
   */
  function reloadBranchList() {
    const branchSection = $('#branch-management-section-brand');

    if (branchSection.length === 0) {
      return;
    }

    // Find the branches list container
    const listContainer = branchSection.find('.checkin-form-group');

    // Show loading state
    listContainer.html(
      '<div style="text-align: center; padding: 20px;"><span class="dashicons dashicons-update-alt" style="animation: spin 1s linear infinite; font-size: 32px;"></span></div>'
    );

    // Fetch updated branch list via AJAX
    $.ajax({
      url: ajaxurl,
      type: 'POST',
      data: {
        action: 'checkin_get_branches_list',
        nonce: checkinAdmin.nonce,
      },
      success: function (response) {
        if (response.success && response.data.html) {
          // Replace with new HTML
          listContainer.html(`
            <label class="checkin-form-label">
              <span class="dashicons dashicons-location"></span>
              Danh sách chi nhánh
            </label>
            ${response.data.html}
            <button type="button" class="checkin-button checkin-button-secondary checkin-button-sm checkin-btn-add-branch" style="margin-top: 16px;">
              <span class="dashicons dashicons-plus"></span>
              Thêm chi nhánh mới
            </button>
          `);
        } else {
          showNotification('Không thể tải danh sách chi nhánh!', 'error');
        }
      },
      error: function () {
        showNotification('Có lỗi khi tải danh sách chi nhánh!', 'error');
      },
    });
  }

  // Note: showNotification() is now defined in common.js
})(jQuery);
