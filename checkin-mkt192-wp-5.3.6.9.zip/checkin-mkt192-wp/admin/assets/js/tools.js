/**
 * Tools Page JavaScript
 * Handle tool actions, tab switching, and interactions
 * Version: 5.1.0
 */

(function ($) {
  'use strict';

  /**
   * Initialize on document ready
   */
  $(document).ready(function () {
    initTabSwitching();
    initCopySystemInfo();
    initTestAPIs();
    initRefreshLog();
    initFormConfirmations();
    initClearLog();
  });

  /**
   * Initialize tab switching functionality
   */
  function initTabSwitching() {
    $('.checkin-tools-tab').on('click', function () {
      const targetTab = $(this).data('tab');

      // Update active tab
      $('.checkin-tools-tab').removeClass('active');
      $(this).addClass('active');

      // Update active content
      $('.checkin-tools-tab-content').removeClass('active');
      $(`.checkin-tools-tab-content[data-tab-content="${targetTab}"]`).addClass('active');

      // Update URL without reload
      if (history.pushState) {
        const url = new URL(window.location);
        url.searchParams.set('tab', targetTab);
        history.pushState({}, '', url);
      }
    });

    // Handle browser back/forward buttons
    $(window).on('popstate', function () {
      const urlParams = new URLSearchParams(window.location.search);
      const tab = urlParams.get('tab') || 'system';
      $(`.checkin-tools-tab[data-tab="${tab}"]`).trigger('click');
    });
  }

  /**
   * Copy system info to clipboard
   */
  function initCopySystemInfo() {
    $('#copy-system-info').on('click', function () {
      const $button = $(this);
      const originalText = $button.find('span:last').text();

      // Build markdown-formatted text
      let textToCopy = '# 📊 Thông tin Hệ thống\n\n';

      // Add timestamp
      const now = new Date();
      const timestamp = now.toLocaleString('vi-VN', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      });
      textToCopy += `**Thời gian:** ${timestamp}\n\n`;
      textToCopy += '---\n\n';

      // Gather system info in markdown format
      $('#system-info-content .checkin-system-info-section').each(function () {
        const sectionTitle = $(this).find('.checkin-system-section-title').text().trim();
        textToCopy += `## ${sectionTitle}\n\n`;

        $(this)
          .find('.checkin-system-info-item')
          .each(function () {
            const label = $(this).find('.checkin-system-info-label').text().trim();
            const value = $(this).find('.checkin-system-info-value').text().trim();
            textToCopy += `- **${label}:** ${value}\n`;
          });

        textToCopy += '\n';
      });

      // Add Connection Status section
      const connectionCards = $('.checkin-connection-card');
      if (connectionCards.length > 0) {
        textToCopy += '## Trạng thái Kết nối\n\n';
        connectionCards.each(function () {
          const label = $(this).find('.checkin-connection-label span:last').text().trim();
          const status = $(this).find('.checkin-connection-status').text().trim();
          textToCopy += `- **${label}:** ${status}\n`;
        });
        textToCopy += '\n';
      }

      // Add footer
      textToCopy += '---\n';
      textToCopy += '*Tạo bởi Checkin MKT192 WP Plugin*\n';

      // Copy to clipboard
      copyToClipboard(textToCopy)
        .then(function () {
          // Store original width to prevent layout shift
          const originalWidth = $button.outerWidth();
          $button.css('min-width', originalWidth + 'px');

          // Show success state
          $button.addClass('checkin-button-success');
          $button.find('.dashicons').removeClass('dashicons-admin-page').addClass('dashicons-yes');

          // Update button text (remove icon first, then add new content)
          $button
            .contents()
            .filter(function () {
              return this.nodeType === 3; // Text nodes only
            })
            .remove();
          $button.append('Đã sao chép!');

          // Show notification using internal toast function
          showToast('success', 'Đã sao chép thông tin hệ thống!');

          // Reset after 2 seconds
          setTimeout(function () {
            $button.removeClass('checkin-button-success');
            $button
              .find('.dashicons')
              .removeClass('dashicons-yes')
              .addClass('dashicons-admin-page');

            // Restore original text
            $button
              .contents()
              .filter(function () {
                return this.nodeType === 3;
              })
              .remove();
            $button.append(originalText);

            // Remove min-width
            $button.css('min-width', '');
          }, 2000);
        })
        .catch(function (err) {
          console.error('Copy failed:', err);
          showToast('error', 'Không thể sao chép. Vui lòng thử lại.');
        });
    });
  }

  /**
   * Test all APIs
   */
  function initTestAPIs() {
    $('#test-all-apis').on('click', function () {
      const $button = $(this);

      // Disable button and show loading
      $button.prop('disabled', true).addClass('checkin-button-loading');

      // Call AJAX to test APIs
      console.log('Testing APIs...', { ajaxurl: ajaxurl, nonce: checkinAdmin.nonce });

      $.ajax({
        url: ajaxurl,
        type: 'POST',
        data: {
          action: 'checkin_test_api_connections',
          nonce: checkinAdmin.nonce,
        },
        success: function (response) {
          $button.prop('disabled', false).removeClass('checkin-button-loading');

          if (response.success && response.data.apis) {
            // Show results in modal
            showAPITestModal(
              response.data.apis,
              response.data.success_count,
              response.data.total_count
            );
          } else {
            showToast(
              'error',
              response.data?.message || 'Không thể kiểm tra API. Vui lòng thử lại.'
            );
          }
        },
        error: function (xhr, status, error) {
          $button.prop('disabled', false).removeClass('checkin-button-loading');
          console.error('API test error:', error);
          showToast('error', 'Lỗi khi kiểm tra API: ' + error);
        },
      });
    });
  }

  /**
   * Show API test results in modal
   */
  function showAPITestModal(apis, successCount, totalCount) {
    let resultsHtml = '<div class="checkin-api-test-results" style="display: grid; gap: 12px;">';

    apis.forEach(function (api) {
      const statusClass =
        api.status === 'success' ? 'success' : api.status === 'warning' ? 'warning' : 'danger';
      const icon = api.status === 'success' ? '✓' : api.status === 'warning' ? '⚠' : '✗';

      resultsHtml += `
        <div class="checkin-alert checkin-alert-${statusClass}" style="animation: checkin-fade-in 0.3s ease-out;">
          <span class="checkin-alert-icon">${icon}</span>
          <div class="checkin-alert-content">
            <div class="checkin-alert-title" style="font-weight: 600; margin-bottom: 4px;">${
              api.name
            }</div>
            <div class="checkin-alert-message">${api.message}</div>
            ${
              api.responseTime && api.responseTime !== '-'
                ? `<div class="checkin-text-tertiary" style="font-size: 12px; margin-top: 6px;">
                     <span class="dashicons dashicons-clock" style="font-size: 14px; vertical-align: middle;"></span>
                     ${api.responseTime}
                   </div>`
                : ''
            }
          </div>
        </div>
      `;
    });

    resultsHtml += '</div>';

    // Determine summary alert type
    const summaryType =
      successCount === totalCount ? 'success' : successCount === 0 ? 'danger' : 'warning';
    const summaryIcon = successCount === totalCount ? '✓' : successCount === 0 ? '✗' : 'ℹ';

    // Create modal HTML
    const modalHtml = `
      <div class="checkin-modal-overlay" id="api-test-modal" style="animation: checkin-fade-in 0.2s ease-out;">
        <div class="checkin-modal" style="max-width: 650px; animation: checkin-slide-up 0.3s ease-out;">
          <div class="checkin-modal-header" style="background: linear-gradient(135deg, #8b5cf6, #7c3aed); color: white;">
            <h3 class="checkin-modal-title" style="color: white;">
              <span class="dashicons dashicons-admin-plugins"></span>
              Kết quả kiểm tra API
            </h3>
            <button type="button" class="checkin-modal-close" data-modal-close="api-test-modal" style="color: white; opacity: 0.9;">
              <span class="dashicons dashicons-no-alt"></span>
            </button>
          </div>
          <div class="checkin-modal-body" style="max-height: 500px; overflow-y: auto;">
            <div class="checkin-alert checkin-alert-${summaryType}" style="margin-bottom: 20px;">
              <span class="checkin-alert-icon">${summaryIcon}</span>
              <div class="checkin-alert-content">
                <div class="checkin-alert-title" style="font-weight: 600; margin-bottom: 4px;">
                  Tổng quan kiểm tra
                </div>
                <div class="checkin-alert-message">
                  Đã kiểm tra <strong>${totalCount}</strong> API.
                  <strong style="color: ${
                    summaryType === 'success' ? '#10b981' : '#ef4444'
                  };">${successCount}</strong>
                  kết nối thành công${
                    successCount < totalCount
                      ? ', <strong style="color: #ef4444;">' +
                        (totalCount - successCount) +
                        '</strong> thất bại'
                      : ''
                  }.
                </div>
              </div>
            </div>
            ${resultsHtml}
          </div>
          <div class="checkin-modal-footer">
            <button type="button" class="checkin-button checkin-button-primary" data-modal-close="api-test-modal">
              <span class="dashicons dashicons-yes"></span>
              Đóng
            </button>
          </div>
        </div>
      </div>
    `;

    // Remove existing modal if any
    $('#api-test-modal').remove();

    // Append and show modal
    $('body').append(modalHtml);
    $('#api-test-modal').css('display', 'flex').hide().fadeIn(200);

    // Close modal handlers
    $('[data-modal-close="api-test-modal"]').on('click', function () {
      $('#api-test-modal').fadeOut(200, function () {
        $(this).remove();
      });
    });

    // Close on overlay click
    $('#api-test-modal').on('click', function (e) {
      if ($(e.target).hasClass('checkin-modal-overlay')) {
        $(this).fadeOut(200, function () {
          $(this).remove();
        });
      }
    });

    // Close on ESC key
    $(document).on('keydown.api-test-modal', function (e) {
      if (e.key === 'Escape') {
        $('#api-test-modal').fadeOut(200, function () {
          $(this).remove();
        });
        $(document).off('keydown.api-test-modal');
      }
    });
  }

  /**
   * Refresh log
   */
  function initRefreshLog() {
    $('#refresh-log').on('click', function () {
      const $button = $(this);
      const $icon = $button.find('.dashicons');

      // Add rotation animation
      $icon.addClass('checkin-rotating');

      // Show notification
      showToast('info', 'Đang làm mới log...');

      // Reload page after short delay
      setTimeout(function () {
        window.location.reload();
      }, 500);
    });
  }

  /**
   * Initialize form confirmations
   */
  function initFormConfirmations() {
    // Add loading state to buttons on form submit
    $('.checkin-tool-form').on('submit', function () {
      const $form = $(this);
      const $button = $form.find('button[type="submit"]');
      $button.prop('disabled', true).addClass('checkin-button-loading');
    });

    // Clear cache form
    $('form[action=""] input[value="clear_cache"]')
      .closest('form')
      .on('submit', function (e) {
        showToast('info', 'Đang xoá cache...');
      });

    // Export settings form
    $('form[action=""] input[value="export_settings"]')
      .closest('form')
      .on('submit', function (e) {
        showToast('info', 'Đang xuất cài đặt...');
      });

    // Import settings form
    $('form[action=""] input[value="import_settings"]')
      .closest('form')
      .on('submit', function (e) {
        const fileInput = $(this).find('input[type="file"]');
        if (!fileInput.val()) {
          e.preventDefault();
          showToast('error', 'Vui lòng chọn file để nhập!');
          return false;
        }

        showToast('info', 'Đang nhập cài đặt...');
      });
  }

  /**
   * Copy text to clipboard
   */
  function copyToClipboard(text) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      return navigator.clipboard.writeText(text);
    } else {
      // Fallback for older browsers
      return new Promise(function (resolve, reject) {
        const $temp = $('<textarea>');
        $('body').append($temp);
        $temp.val(text).select();

        try {
          document.execCommand('copy');
          $temp.remove();
          resolve();
        } catch (err) {
          $temp.remove();
          reject(err);
        }
      });
    }
  }

  /**
   * Initialize clear log button
   */
  function initClearLog() {
    $('#checkin-clear-log-btn').on('click', function () {
      const $btn = $(this);

      if (!confirm('Bạn có chắc muốn xóa toàn bộ debug log?')) {
        return;
      }

      // Disable button and show loading
      $btn.prop('disabled', true);
      const originalHTML = $btn.html();
      $btn.html('<span class="dashicons dashicons-update checkin-rotating"></span> Đang xóa...');

      $.ajax({
        url: ajaxurl,
        type: 'POST',
        data: {
          action: 'checkin_clear_debug_log',
          nonce: checkinAdmin.nonce,
        },
        success: function (response) {
          if (response.success) {
            // Show success message
            showToast('success', response.data.message);

            // Reload page after 1 second
            setTimeout(function () {
              location.reload();
            }, 1000);
          } else {
            showToast('error', response.data.message || 'Có lỗi xảy ra khi xóa log');
            $btn.prop('disabled', false).html(originalHTML);
          }
        },
        error: function () {
          showToast('error', 'Không thể kết nối tới server');
          $btn.prop('disabled', false).html(originalHTML);
        },
      });
    });
  }

  /**
   * Show toast notification
   */
  function showToast(type, message) {
    const toastClass =
      type === 'success'
        ? 'checkin-toast-success'
        : type === 'error'
        ? 'checkin-toast-error'
        : 'checkin-toast-info';
    const icon =
      type === 'success'
        ? '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7" /></svg>'
        : type === 'error'
        ? '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>'
        : '<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>';

    const $toast = $(`
      <div class="checkin-toast ${toastClass}">
        <div class="checkin-toast-icon">${icon}</div>
        <div class="checkin-toast-content">
          <div class="checkin-toast-message">${message}</div>
        </div>
        <button class="checkin-toast-close" type="button" aria-label="Close">×</button>
      </div>
    `);

    $('body').append($toast);

    // Show with animation
    setTimeout(() => $toast.addClass('show'), 10);

    // Close button handler
    $toast.find('.checkin-toast-close').on('click', function () {
      $toast.removeClass('show');
      setTimeout(() => $toast.remove(), 300);
    });

    // Auto dismiss after 4 seconds (enough time to read)
    setTimeout(function () {
      $toast.removeClass('show');
      setTimeout(() => $toast.remove(), 300);
    }, 4000);
  }
})(jQuery);
