/**
 * Push Notifications Settings Page JavaScript
 *
 * Handles modal interactions, form submissions, and AJAX calls
 * for the push notifications settings page
 *
 * @package    Checkin_MKT192_WP
 * @subpackage Admin/Assets/JS
 * @since      6.1.0
 */

(function ($) {
  'use strict';

  // Global data from PHP
  const config = window.checkinPushNotifications || {};
  const types = config.types || {};
  const roles = config.roles || {};
  const nonce = config.nonce || '';
  const ajaxUrl = config.ajaxUrl || '/wp-admin/admin-ajax.php';
  const multiBranch = config.multiBranch || false;

  // Sample data for preview
  const sampleData = {
    customer_name: 'Nguyễn Văn A',
    staff_name: 'Trần Văn B',
    branch_name: 'Chi nhánh ABC',
    invoice_id: '12345',
    booking_time: '10:00 ' + new Date().toLocaleDateString('vi-VN'),
    total: '500,000',
    surcharge_amount: '50,000',
    deleted_by: 'Admin',
    rating_stars: '⭐⭐⭐⭐⭐',
    request_type: 'nghỉ phép',
    status_icon: '✅',
    status_text: 'được duyệt',
    month: new Date().getMonth() + 1,
    year: new Date().getFullYear(),
    action_text: 'đã được tạo',
    type_text: 'Nhập kho',
    product_count: '5',
    transaction_id: '999',
    approved_by: 'Quản lý',
  };

  // Current editing type
  let currentType = null;

  /**
   * Initialize page
   */
  function init() {
    bindEvents();
  }

  /**
   * Bind all events
   */
  function bindEvents() {
    // Toggle notification enabled/disabled
    $(document).on('change', '.notification-enabled-toggle', handleToggleChange);

    // Form submit
    $('#form-edit-notification').on('submit', handleFormSubmit);

    // OneSignal config form submit
    $('#form-onesignal-config').on('submit', handleOneSignalConfigSubmit);

    // OneSignal enable toggle
    $('#push-enabled-toggle').on('change', function () {
      const isEnabled = $(this).is(':checked');
      // Update badge immediately
      updatePushBadge(isEnabled);
      // Show/hide config form
      if (isEnabled) {
        $('#form-onesignal-config').slideDown(300);
        $('#toggle-onesignal-config .dashicons')
          .removeClass('dashicons-arrow-down-alt2')
          .addClass('dashicons-arrow-up-alt2');
      } else {
        $('#form-onesignal-config').slideUp(300);
        $('#toggle-onesignal-config .dashicons')
          .removeClass('dashicons-arrow-up-alt2')
          .addClass('dashicons-arrow-down-alt2');
      }
      // Hide/show notification sections
      if (isEnabled && config.isConfigured) {
        $('.checkin-settings-section:not(:first)').slideDown(300);
        $('.checkin-btn-reset-all').show();
      } else {
        $('.checkin-settings-section:not(:first)').slideUp(300);
        $('.checkin-btn-reset-all').hide();
      }
    });

    // Toggle OneSignal config form visibility
    $('#toggle-onesignal-config').on('click', function () {
      const form = $('#form-onesignal-config');
      const icon = $(this).find('.dashicons');

      if (form.is(':visible')) {
        form.slideUp(300);
        icon.removeClass('dashicons-arrow-up-alt2').addClass('dashicons-arrow-down-alt2');
      } else {
        form.slideDown(300);
        icon.removeClass('dashicons-arrow-down-alt2').addClass('dashicons-arrow-up-alt2');
      }
    });

    // Password toggle
    $(document).on('click', '.checkin-toggle-password', function () {
      const targetId = $(this).data('target');
      const input = $('#' + targetId);
      const icon = $(this).find('.dashicons');

      if (input.attr('type') === 'password') {
        input.attr('type', 'text');
        icon.removeClass('dashicons-visibility').addClass('dashicons-hidden');
      } else {
        input.attr('type', 'password');
        icon.removeClass('dashicons-hidden').addClass('dashicons-visibility');
      }
    });

    // Test push connection
    $('#test-push-connection').on('click', handleTestPushConnection);

    // Export settings
    $('#btn-export-settings').on('click', handleExportSettings);

    // Import settings
    $('#btn-import-settings').on('click', function () {
      $('#import-settings-file').click();
    });
    $('#import-settings-file').on('change', handleImportSettings);

    // Variable tag click
    $(document).on('click', '.checkin-variable-tag', handleVariableClick);

    // Live preview on title/body change
    $('#edit-notification-title, #edit-notification-body').on('input', updatePreview);

    // Close modal on backdrop click
    $(document).on('click', '.checkin-modal-backdrop', function (e) {
      if ($(e.target).hasClass('checkin-modal-backdrop')) {
        closeNotificationModal();
      }
    });

    // Close modal on ESC key
    $(document).on('keydown', function (e) {
      if (e.key === 'Escape') {
        closeNotificationModal();
      }
    });

    // Update status label on toggle change
    $('#edit-notification-enabled').on('change', function () {
      const label = $(this).is(':checked') ? 'Đang bật' : 'Đã tắt';
      $('#edit-notification-status-label').text(label);
    });
  }

  /**
   * Handle toggle enable/disable change
   */
  function handleToggleChange() {
    const type = $(this).data('type');
    const enabled = $(this).is(':checked');
    const card = $(this).closest('.checkin-notification-card');

    // Update UI immediately
    card.toggleClass('enabled', enabled).toggleClass('disabled', !enabled);

    // Save to server
    saveNotificationSettings(
      type,
      {
        enabled: enabled,
      },
      true
    );
  }

  /**
   * Open notification edit modal
   */
  window.openNotificationModal = function (type) {
    currentType = type;
    const typeConfig = types[type];

    if (!typeConfig) {
      console.error('Unknown notification type:', type);
      return;
    }

    const settings = typeConfig.settings || {};

    // Update modal title
    $('#modal-notification-name').text(typeConfig.name);

    // Set form values
    $('#edit-notification-type').val(type);
    $('#edit-notification-enabled').prop('checked', settings.enabled !== false);
    $('#edit-notification-title').val(settings.title || typeConfig.default_title);
    $('#edit-notification-body').val(settings.body || typeConfig.default_body);

    // Update status label
    const statusLabel = settings.enabled !== false ? 'Đang bật' : 'Đã tắt';
    $('#edit-notification-status-label').text(statusLabel);

    // Set roles
    $('input[name="roles[]"]').prop('checked', false);
    const selectedRoles = settings.roles || typeConfig.default_roles || [];
    selectedRoles.forEach(function (role) {
      $('input[name="roles[]"][value="' + role + '"]').prop('checked', true);
    });

    // Render variables
    renderVariables(typeConfig.variables || []);

    // Add hints
    $('#edit-notification-title-hint').text('Mặc định: ' + typeConfig.default_title);
    $('#edit-notification-body-hint').text('Mặc định: ' + typeConfig.default_body);

    // Update preview
    updatePreview();

    // Show modal
    $('#modal-edit-notification').fadeIn(200);
  };

  /**
   * Close notification edit modal
   */
  window.closeNotificationModal = function () {
    $('#modal-edit-notification').fadeOut(200);
    currentType = null;
  };

  /**
   * Render variables list
   * Filter out branch_name if multi-branch mode is disabled
   */
  function renderVariables(variables) {
    const container = $('#edit-notification-variables');
    container.empty();

    // Filter out branch_name if multi-branch is disabled
    let filteredVars = variables;
    if (!multiBranch) {
      filteredVars = variables.filter((v) => v !== 'branch_name');
    }

    if (!filteredVars.length) {
      container.html('<span class="checkin-no-variables">Không có biến</span>');
      return;
    }

    filteredVars.forEach(function (variable) {
      const tag = $('<span class="checkin-variable-tag" data-variable="' + variable + '">').html(
        '<span class="dashicons dashicons-editor-code"></span>{' + variable + '}'
      );
      container.append(tag);
    });
  }

  /**
   * Update preview with current title and body
   */
  function updatePreview() {
    const title = $('#edit-notification-title').val() || '';
    const body = $('#edit-notification-body').val() || '';

    // Replace variables with sample data
    let previewTitle = replaceVariables(title);
    let previewBody = replaceVariables(body);

    // Convert newlines to <br> for HTML display
    previewTitle = escapeHtml(previewTitle).replace(/\n/g, '<br>');
    previewBody = escapeHtml(previewBody).replace(/\n/g, '<br>');

    $('#preview-title').html(previewTitle || 'Tiêu đề thông báo');
    $('#preview-body').html(previewBody || 'Nội dung thông báo');
  }

  /**
   * Escape HTML to prevent XSS
   */
  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  /**
   * Replace variables in text with sample data
   */
  function replaceVariables(text) {
    let result = text;
    Object.keys(sampleData).forEach(function (key) {
      result = result.replace(new RegExp('\\{' + key + '\\}', 'g'), sampleData[key]);
    });
    return result;
  }

  /**
   * Handle OneSignal config form submit
   */
  function handleOneSignalConfigSubmit(e) {
    e.preventDefault();

    const submitBtn = $(this).find('.checkin-btn-save-config');
    const originalHtml = submitBtn.html();

    submitBtn
      .prop('disabled', true)
      .html('<span class="dashicons dashicons-update spinning"></span> Đang lưu...');

    const pushEnabled = $('#push-enabled-toggle').is(':checked') ? '1' : '0';
    const appId = $('#onesignal-app-id').val();
    const apiKey = $('#onesignal-api-key').val();
    const safariWebId = $('#onesignal-safari-web-id').val();

    $.ajax({
      url: ajaxUrl,
      type: 'POST',
      data: {
        action: 'checkin_push_save_onesignal_config',
        nonce: nonce,
        push_enabled: pushEnabled,
        app_id: appId,
        api_key: apiKey,
        safari_web_id: safariWebId,
      },
      success: function (response) {
        if (response.success) {
          showNotification(response.data.message, 'success');
          // Always reload page to update UI after save
          setTimeout(function () {
            location.reload();
          }, 1500);
        } else {
          showNotification(response.data.message, 'error');
        }
      },
      error: function () {
        showNotification('Không thể kết nối đến server', 'error');
      },
      complete: function () {
        submitBtn.prop('disabled', false).html(originalHtml);
      },
    });
  }

  /**
   * Handle test push connection button
   */
  function handleTestPushConnection() {
    const button = $(this);
    const originalHtml = button.html();

    button
      .prop('disabled', true)
      .html('<span class="dashicons dashicons-update spinning"></span> Đang gửi...');

    $.ajax({
      url: ajaxUrl,
      type: 'POST',
      data: {
        action: 'checkin_push_test_notification',
        nonce: nonce,
        notification_type: 'connection_test',
      },
      success: function (response) {
        if (response.success) {
          showNotification(response.data.message || 'Đã gửi thông báo test', 'success');
        } else {
          showNotification(response.data.message || 'Không thể gửi thông báo', 'error');
        }
      },
      error: function () {
        showNotification('Không thể kết nối đến server', 'error');
      },
      complete: function () {
        button.prop('disabled', false).html(originalHtml);
      },
    });
  }

  /**
   * Handle variable tag click - insert into focused input
   */
  function handleVariableClick() {
    const variable = '{' + $(this).data('variable') + '}';
    const titleInput = $('#edit-notification-title');
    const bodyInput = $('#edit-notification-body');

    // Try to insert into body first, then title
    const activeElement = document.activeElement;

    if (
      activeElement.id === 'edit-notification-title' ||
      activeElement.id === 'edit-notification-body'
    ) {
      insertAtCursor(activeElement, variable);
    } else {
      // Default to body
      insertAtCursor(bodyInput[0], variable);
    }
  }

  /**
   * Insert text at cursor position
   */
  function insertAtCursor(element, text) {
    const start = element.selectionStart;
    const end = element.selectionEnd;
    const value = element.value;

    element.value = value.substring(0, start) + text + value.substring(end);
    element.selectionStart = element.selectionEnd = start + text.length;
    element.focus();

    // Trigger preview update after inserting variable
    updatePreview();
  }

  /**
   * Handle form submit
   */
  function handleFormSubmit(e) {
    e.preventDefault();

    const submitBtn = $(this).find('button[type="submit"]');
    const originalHtml = submitBtn.html();

    // Set button loading state
    submitBtn
      .prop('disabled', true)
      .html('<span class="dashicons dashicons-update spinning"></span> Đang lưu...');

    const type = $('#edit-notification-type').val();
    const settings = {
      enabled: $('#edit-notification-enabled').is(':checked'),
      title: $('#edit-notification-title').val(),
      body: $('#edit-notification-body').val(),
      roles: $('input[name="roles[]"]:checked')
        .map(function () {
          return $(this).val();
        })
        .get(),
      include_branch: $('#edit-notification-include-branch').is(':checked'),
    };

    saveNotificationSettings(
      type,
      settings,
      false,
      function () {
        // Reset button first
        submitBtn.prop('disabled', false).html(originalHtml);
        // Update card UI without reload
        updateNotificationCardUI(type, settings);
        closeNotificationModal();
      },
      function () {
        // Reset button on error
        submitBtn.prop('disabled', false).html(originalHtml);
      }
    );
  }

  /**
   * Update notification card UI after saving
   */
  function updateNotificationCardUI(type, settings) {
    const card = $('.checkin-notification-card[data-type="' + type + '"]');
    if (!card.length) return;

    // Update enabled state
    card.toggleClass('enabled', settings.enabled).toggleClass('disabled', !settings.enabled);
    card.find('.notification-enabled-toggle').prop('checked', settings.enabled);

    // Update title in card (correct selector: .checkin-preview-title)
    const titleText = settings.title || types[type].default_title;
    card.find('.checkin-preview-title').text(titleText);

    // Update body in card (correct selector: .checkin-preview-body)
    let bodyText = settings.body || types[type].default_body;
    // Convert newlines to <br> for proper display
    const bodyHtml = bodyText.replace(/\n/g, '<br>');
    card.find('.checkin-preview-body').html(bodyHtml);

    // Update roles badges
    const rolesContainer = card.find('.checkin-notification-roles');
    rolesContainer.empty();
    if (settings.roles && settings.roles.length > 0) {
      settings.roles.forEach(function (roleKey) {
        const roleConfig = roles[roleKey];
        if (roleConfig) {
          const hex = roleConfig.color.replace('#', '');
          const r = parseInt(hex.substr(0, 2), 16);
          const g = parseInt(hex.substr(2, 2), 16);
          const b = parseInt(hex.substr(4, 2), 16);
          const badge = $('<span class="checkin-role-badge"></span>')
            .text(roleConfig.label)
            .css({
              'background-color': 'rgba(' + r + ',' + g + ',' + b + ', 0.12)',
              color: roleConfig.color,
            });
          rolesContainer.append(badge);
        }
      });
    }
  }

  /**
   * Save notification settings via AJAX
   */
  function saveNotificationSettings(type, settings, silent, callback, errorCallback) {
    $.ajax({
      url: ajaxUrl,
      type: 'POST',
      data: {
        action: 'checkin_push_save_notification_settings',
        nonce: nonce,
        notification_type: type,
        settings: settings,
      },
      success: function (response) {
        if (response.success) {
          if (!silent) {
            showNotification(response.data.message || 'Đã lưu thành công', 'success');
          }

          // Update local config
          if (types[type]) {
            types[type].settings = $.extend(types[type].settings || {}, settings);
          }

          if (typeof callback === 'function') {
            callback();
          }
        } else {
          showNotification(response.data.message || 'Có lỗi xảy ra', 'error');
          if (typeof errorCallback === 'function') {
            errorCallback();
          }
        }
      },
      error: function () {
        showNotification('Không thể kết nối đến server', 'error');
        if (typeof errorCallback === 'function') {
          errorCallback();
        }
      },
    });
  }

  /**
   * Reset notification settings for current type
   */
  window.resetNotificationSettings = function () {
    if (!currentType) return;

    if (!confirm('Bạn có chắc muốn khôi phục về mặc định?')) {
      return;
    }

    const resetBtn = $('.checkin-btn-reset');
    const originalHtml = resetBtn.html();
    resetBtn
      .prop('disabled', true)
      .html('<span class="dashicons dashicons-update spinning"></span> Đang khôi phục...');

    $.ajax({
      url: ajaxUrl,
      type: 'POST',
      data: {
        action: 'checkin_push_reset_notification_settings',
        nonce: nonce,
        notification_type: currentType,
      },
      success: function (response) {
        if (response.success) {
          showNotification(response.data.message, 'success');

          // Update form with default values
          const typeConfig = types[currentType];
          $('#edit-notification-enabled').prop('checked', true);
          $('#edit-notification-title').val(typeConfig.default_title);
          $('#edit-notification-body').val(typeConfig.default_body);
          $('#edit-notification-include-branch').prop('checked', typeConfig.supports_branch);

          // Reset roles to default
          $('input[name="roles[]"]').prop('checked', false);
          (typeConfig.default_roles || []).forEach(function (role) {
            $('input[name="roles[]"][value="' + role + '"]').prop('checked', true);
          });
        } else {
          showNotification(response.data.message, 'error');
        }
      },
      error: function () {
        showNotification('Không thể kết nối đến server', 'error');
      },
      complete: function () {
        resetBtn.prop('disabled', false).html(originalHtml);
      },
    });
  };

  /**
   * Reset all notification settings
   */
  window.resetAllNotificationSettings = function () {
    if (
      !confirm(
        'Bạn có chắc muốn khôi phục TẤT CẢ thông báo về mặc định? Hành động này không thể hoàn tác.'
      )
    ) {
      return;
    }

    const resetAllBtn = $('.checkin-btn-reset-all');
    const originalHtml = resetAllBtn.html();
    resetAllBtn
      .prop('disabled', true)
      .html('<span class="dashicons dashicons-update spinning"></span> Đang khôi phục...');

    $.ajax({
      url: ajaxUrl,
      type: 'POST',
      data: {
        action: 'checkin_push_reset_notification_settings',
        nonce: nonce,
        notification_type: '', // Empty = reset all
      },
      success: function (response) {
        if (response.success) {
          showNotification(response.data.message, 'success');
          // Reload page
          setTimeout(function () {
            location.reload();
          }, 1500);
        } else {
          showNotification(response.data.message, 'error');
        }
      },
      error: function () {
        showNotification('Không thể kết nối đến server', 'error');
        resetAllBtn.prop('disabled', false).html(originalHtml);
      },
    });
  };

  /**
   * Test notification
   */
  window.testNotification = function (type) {
    const button = $('.checkin-btn-test[data-type="' + type + '"]');
    const originalHtml = button.html();

    button
      .prop('disabled', true)
      .html('<span class="dashicons dashicons-update spinning"></span> Đang gửi...');

    $.ajax({
      url: ajaxUrl,
      type: 'POST',
      data: {
        action: 'checkin_push_test_notification',
        nonce: nonce,
        notification_type: type,
      },
      success: function (response) {
        if (response.success) {
          showNotification(response.data.message || 'Đã gửi thông báo test', 'success');
        } else {
          showNotification(response.data.message || 'Không thể gửi thông báo', 'error');
        }
      },
      error: function () {
        showNotification('Không thể kết nối đến server', 'error');
      },
      complete: function () {
        button.prop('disabled', false).html(originalHtml);
      },
    });
  };

  /**
   * Update push badge based on enabled state
   */
  function updatePushBadge(isEnabled) {
    const badgeContainer = $('.checkin-section-header-actions');
    const badge = badgeContainer.find('.checkin-badge');

    if (isEnabled) {
      badge.removeClass('checkin-badge-gray').addClass('checkin-badge-success');
      badge.html('<span class="dashicons dashicons-yes-alt"></span> Đã kích hoạt');
    } else {
      badge.removeClass('checkin-badge-success').addClass('checkin-badge-gray');
      badge.html('Chưa kích hoạt');
    }
  }

  /**
   * Handle export settings
   */
  function handleExportSettings() {
    const button = $(this);
    const originalHtml = button.html();

    button.prop('disabled', true).html('<span class="dashicons dashicons-update spinning"></span>');

    $.ajax({
      url: ajaxUrl,
      type: 'POST',
      data: {
        action: 'checkin_push_export_settings',
        nonce: nonce,
      },
      success: function (response) {
        if (response.success) {
          // Create and download file
          const dataStr = JSON.stringify(response.data.data, null, 2);
          const blob = new Blob([dataStr], { type: 'application/json' });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = response.data.filename;
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          URL.revokeObjectURL(url);

          showNotification('Đã tải xuống file cài đặt', 'success');
        } else {
          showNotification(response.data.message || 'Không thể xuất cài đặt', 'error');
        }
      },
      error: function () {
        showNotification('Không thể kết nối đến server', 'error');
      },
      complete: function () {
        button.prop('disabled', false).html(originalHtml);
      },
    });
  }

  /**
   * Handle import settings
   */
  function handleImportSettings(e) {
    const file = e.target.files[0];
    if (!file) return;

    // Validate file type
    if (!file.name.endsWith('.json')) {
      showNotification('Vui lòng chọn file .json', 'error');
      return;
    }

    const reader = new FileReader();
    reader.onload = function (event) {
      try {
        const importData = JSON.parse(event.target.result);

        // Validate structure
        if (!importData.notifications) {
          showNotification('Cấu trúc file không đúng', 'error');
          return;
        }

        // Confirm import
        if (!confirm('Bạn có chắc muốn nhập cài đặt từ file này? Cài đặt hiện tại sẽ bị ghi đè.')) {
          return;
        }

        // Send to server
        $.ajax({
          url: ajaxUrl,
          type: 'POST',
          data: {
            action: 'checkin_push_import_settings',
            nonce: nonce,
            import_data: JSON.stringify(importData),
          },
          success: function (response) {
            if (response.success) {
              showNotification(response.data.message, 'success');
              // Reload page to show updated settings
              setTimeout(function () {
                location.reload();
              }, 1500);
            } else {
              showNotification(response.data.message || 'Không thể nhập cài đặt', 'error');
            }
          },
          error: function () {
            showNotification('Không thể kết nối đến server', 'error');
          },
        });
      } catch (err) {
        showNotification('File không hợp lệ: ' + err.message, 'error');
      }
    };

    reader.readAsText(file);
    // Reset input to allow re-selecting same file
    $(this).val('');
  }

  // Initialize on document ready
  $(document).ready(init);
})(jQuery);
