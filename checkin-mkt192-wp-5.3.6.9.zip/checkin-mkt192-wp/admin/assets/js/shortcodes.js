/**
 * Shortcodes Page JavaScript
 * Handle copy to clipboard with smooth animations
 */

(function ($) {
  'use strict';

  /**
   * Copy shortcode to clipboard with animation
   */
  function copyShortcode($button) {
    const shortcode = $button.data('shortcode');
    const $codeContainer = $button.closest('.checkin-shortcode-code');

    // Copy to clipboard
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard
        .writeText(shortcode)
        .then(function () {
          showCopySuccess($button, $codeContainer);
        })
        .catch(function () {
          fallbackCopy(shortcode, $button, $codeContainer);
        });
    } else {
      fallbackCopy(shortcode, $button, $codeContainer);
    }
  }

  /**
   * Fallback copy method for older browsers
   */
  function fallbackCopy(text, $button, $codeContainer) {
    const $temp = $('<textarea>');
    $('body').append($temp);
    $temp.val(text).select();

    try {
      document.execCommand('copy');
      showCopySuccess($button, $codeContainer);
    } catch (err) {
      console.error('Copy failed:', err);
      showCopyError($button);
    }

    $temp.remove();
  }

  /**
   * Show copy success animation
   */
  function showCopySuccess($button, $codeContainer) {
    // Add copied class to button
    $button.addClass('copied');

    // Add ripple effect to code container
    $codeContainer.addClass('copied');

    // Show notification
    if (typeof window.showNotification === 'function') {
      window.showNotification('Đã sao chép mã ngắn!', 'success');
    }

    // Remove classes after animation
    setTimeout(function () {
      $button.removeClass('copied');
    }, 2000);

    setTimeout(function () {
      $codeContainer.removeClass('copied');
    }, 600);
  }

  /**
   * Show copy error
   */
  function showCopyError($button) {
    if (typeof window.showNotification === 'function') {
      window.showNotification('Không thể sao chép. Vui lòng thử lại.', 'error');
    }
  }

  /**
   * Initialize on document ready
   */
  $(document).ready(function () {
    // Handle copy button click
    $(document).on('click', '.checkin-btn-copy-shortcode', function (e) {
      e.preventDefault();
      copyShortcode($(this));
    });

    // Also allow clicking on code container to copy
    $(document).on('click', '.checkin-shortcode-code', function (e) {
      if (!$(e.target).hasClass('checkin-btn-copy-shortcode')) {
        const $button = $(this).find('.checkin-btn-copy-shortcode');
        if ($button.length) {
          copyShortcode($button);
        }
      }
    });

    // Add hover effect hint
    $('.checkin-shortcode-code').attr('title', 'Click để sao chép mã ngắn');

    // Keyboard shortcut: Ctrl+C on focused card
    $('.checkin-shortcode-card').on('keydown', function (e) {
      if ((e.ctrlKey || e.metaKey) && e.key === 'c') {
        e.preventDefault();
        const $button = $(this).find('.checkin-btn-copy-shortcode');
        if ($button.length) {
          copyShortcode($button);
        }
      }
    });
  });
})(jQuery);
