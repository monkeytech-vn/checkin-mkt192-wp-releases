/**
 * Connections Page JavaScript
 * Handle connection modal interactions and AJAX saves
 * Version: 5.1.0
 */

(function ($) {
  'use strict';

  // Open connection modal
  window.openConnectionModal = function (connection) {
    const modal = document.getElementById('modal-' + connection);
    if (modal) {
      // Get card toggle state BEFORE showing modal
      const cardToggle = $(`.checkin-connection-toggle[data-connection="${connection}"]`);
      const isCardEnabled = cardToggle.is(':checked');

      // Sync modal toggles with current data (not card state)
      // This ensures modal reflects actual saved data
      if (!isCardEnabled) {
        // If card is off, check if we should auto-enable modal toggle for new setup
        const hasData = hasExistingData(connection);
        if (!hasData) {
          // No data yet - auto-enable modal toggle for first-time setup
          syncModalTogglesWithCard(connection, true);
        }
      }

      // Special handling for Zalo - enable OA by default if card is on but nothing selected
      if (connection === 'zalo') {
        const zaloOA = $('input[name="checkin_use_zalo_oa"]');
        const zaloUser = $('input[name="checkin_use_zalo_user"]');
        if (!zaloOA.is(':checked') && !zaloUser.is(':checked')) {
          // Default to enabling OA if nothing is checked
          zaloOA.prop('checked', true).trigger('change');
        }
      }

      // Show modal
      modal.classList.add('active');
      document.body.style.overflow = 'hidden';
    }
  };

  // Close connection modal
  window.closeConnectionModal = function (connection) {
    const modal = document.getElementById('modal-' + connection);
    if (modal) {
      modal.classList.remove('active');
      document.body.style.overflow = '';

      // Check if toggle is on but form not saved
      const toggle = $(`.checkin-connection-toggle[data-connection="${connection}"]`);
      if (toggle.length && toggle.is(':checked')) {
        // Check if has required data
        if (needsConfiguration(connection)) {
          // Turn off card toggle
          toggle.prop('checked', false);
          const card = toggle.closest('.checkin-connection-card');
          card.removeClass('enabled').addClass('disabled');
          card
            .find('.checkin-badge')
            .removeClass('checkin-badge-success')
            .addClass('checkin-badge-gray')
            .text('Disabled');
          card.find('.checkin-toggle-status-text').text('Đang tắt');

          // Sync modal toggles with card toggle - turn off modal toggles too
          syncModalTogglesWithCard(connection, false);

          showNotification('Vui lòng hoàn tất cài đặt trước khi bật!', 'warning');
        }
      }
    }
  };

  // Sync modal internal toggles with card toggle state
  function syncModalTogglesWithCard(connection, isEnabled) {
    if (connection === 'lark') {
      $('#lark-enable-toggle').prop('checked', isEnabled);
      if (isEnabled) {
        $('#lark-bot-section').show();
      } else {
        $('#lark-bot-section').hide();
      }
    } else if (connection === 'zalo') {
      if (!isEnabled) {
        // Card is off, turn off all Zalo toggles
        $('input[name="checkin_use_zalo_oa"]').prop('checked', false).trigger('change');
        $('input[name="checkin_use_zalo_user"]').prop('checked', false).trigger('change');
      }
      // Note: When enabled, we let openConnectionModal handle the default OA selection
    } else if (connection === 'google') {
      $('input[name="checkin_use_google_login"]').prop('checked', isEnabled).trigger('change');
    } else if (connection === 'facebook') {
      $('input[name="checkin_use_facebook_login"]').prop('checked', isEnabled).trigger('change');
    }
  }

  // Close modal when clicking backdrop
  $(document).on('click', '.checkin-modal-backdrop', function (e) {
    if (e.target === this) {
      const modalId = $(this).attr('id');
      if (modalId && modalId.startsWith('modal-')) {
        const connection = modalId.replace('modal-', '');
        closeConnectionModal(connection);
      }
    }
  });

  // Close modal with ESC key
  $(document).on('keydown', function (e) {
    if (e.key === 'Escape') {
      const activeModal = $('.checkin-modal-backdrop.active');
      if (activeModal.length) {
        const modalId = activeModal.attr('id');
        if (modalId && modalId.startsWith('modal-')) {
          const connection = modalId.replace('modal-', '');
          closeConnectionModal(connection);
        }
      }
    }
  });

  // Toggle visibility on checkbox change
  $(document).on('change', '[data-toggle-target]', function () {
    const target = $(this).data('toggle-target');
    if ($(this).is(':checked')) {
      $(target).slideDown(300);
    } else {
      $(target).slideUp(300);
    }
  });

  // Initialize toggles on page load
  $(document).ready(function () {
    $('[data-toggle-target]').each(function () {
      const target = $(this).data('toggle-target');
      if ($(this).is(':checked')) {
        $(target).show();
      } else {
        $(target).hide();
      }
    });


    // Lark enable toggle
    $('#lark-enable-toggle').on('change', function () {
      if ($(this).is(':checked')) {
        $('#lark-bot-section').slideDown(300);
      } else {
        $('#lark-bot-section').slideUp(300);
        // Sync with card toggle - turn off card toggle when modal toggle is off
        const cardToggle = $('.checkin-connection-toggle[data-connection="lark"]');
        if (cardToggle.length && cardToggle.is(':checked')) {
          cardToggle.prop('checked', false).trigger('change');
        }
      }
    });

    // Sync Zalo modal toggles with card toggle
    $('input[name="checkin_use_zalo_oa"], input[name="checkin_use_zalo_user"]').on(
      'change',
      function () {
        const zaloOA = $('input[name="checkin_use_zalo_oa"]');
        const zaloUser = $('input[name="checkin_use_zalo_user"]');
        const cardToggle = $('.checkin-connection-toggle[data-connection="zalo"]');

        // If both are off, turn off card toggle
        if (!zaloOA.is(':checked') && !zaloUser.is(':checked')) {
          if (cardToggle.length && cardToggle.is(':checked')) {
            cardToggle.prop('checked', false).trigger('change');
          }
        }

        // OA ↔ Customer sub-toggle interaction
        const customerSubToggle = $('input[data-zalo-sub="customer"]');
        if (zaloOA.is(':checked')) {
          // OA on → customer sub-toggle disabled (OA handles customer messages)
          customerSubToggle.prop('disabled', true).prop('checked', false);
          customerSubToggle.closest('.zalo-user-sub-toggle')
            .find('.checkin-form-description')
            .html('⚠️ Đang tắt vì Zalo OA đã bật — tin nhắn khách sẽ gửi qua OA/ZBS');
        } else {
          // OA off → re-enable customer sub-toggle
          customerSubToggle.prop('disabled', false).prop('checked', true);
          customerSubToggle.closest('.zalo-user-sub-toggle')
            .find('.checkin-form-description')
            .html('Gửi xác nhận/nhắc/hủy lịch hẹn đến khách qua Zalo cá nhân');
        }
      }
    );

    // Sync Google modal toggle with card toggle
    $('input[name="checkin_use_google_login"]').on('change', function () {
      if (!$(this).is(':checked')) {
        const cardToggle = $('.checkin-connection-toggle[data-connection="google"]');
        if (cardToggle.length && cardToggle.is(':checked')) {
          cardToggle.prop('checked', false).trigger('change');
        }
      }
    });

    // Sync Facebook modal toggle with card toggle
    $('input[name="checkin_use_facebook_login"]').on('change', function () {
      if (!$(this).is(':checked')) {
        const cardToggle = $('.checkin-connection-toggle[data-connection="facebook"]');
        if (cardToggle.length && cardToggle.is(':checked')) {
          cardToggle.prop('checked', false).trigger('change');
        }
      }
    });

    // Handle card toggle switches
    $('.checkin-connection-toggle').on('change', function () {
      const connection = $(this).data('connection');
      const isEnabled = $(this).is(':checked');
      const card = $(this).closest('.checkin-connection-card');
      const statusBadge = card.find('.checkin-badge');
      const statusText = card.find('.checkin-toggle-status-text');
      const hasData = hasExistingData(connection);

      // Update card state
      if (isEnabled) {
        // Check if has data
        if (!hasData) {
          // No data - open modal for configuration
          $(this).prop('checked', false);
          setTimeout(function () {
            openConnectionModal(connection);
          }, 100);
          showNotification('Vui lòng nhập thông tin cấu hình!', 'info');
          return;
        }

        // Has data - enable and save immediately
        card.removeClass('disabled').addClass('enabled');
        statusBadge
          .removeClass('checkin-badge-gray')
          .addClass('checkin-badge-success')
          .text('Đã kết nối');
        statusText.text('Đang bật');

        // Sync modal toggle with card toggle
        syncModalTogglesWithCard(connection, true);

        // Save enabled state to database
        saveConnectionToggleState(connection, true);
      } else {
        card.removeClass('enabled').addClass('disabled');
        statusBadge
          .removeClass('checkin-badge-success')
          .addClass('checkin-badge-gray')
          .text('Chưa kết nối');
        statusText.text('Đang tắt');

        // Sync modal toggle with card toggle
        syncModalTogglesWithCard(connection, false);

        // Save disabled state to database
        saveConnectionToggleState(connection, false);
      }
    });
  });

  // Save connection toggle state to database via AJAX
  function saveConnectionToggleState(connection, isEnabled) {
    const formData = new FormData();
    formData.append('action', 'checkin_save_connection');
    formData.append('connection_type', connection);
    formData.append('nonce', checkinAdmin.nonce);

    // Add the appropriate toggle field based on connection type
    switch (connection) {
      case 'zalo':
        // Check which Zalo type is configured
        const zaloAppId = $('input[name="checkin_zalo_oa_app_id"]').val();
        const zaloDomain = $('input[name="checkin_zalo_user_domain"]').val();
        if (zaloAppId) {
          formData.append('checkin_use_zalo_oa', isEnabled ? '1' : '0');
          formData.append('checkin_zalo_oa_app_id', zaloAppId);
          formData.append(
            'checkin_zalo_oa_secret_key',
            $('input[name="checkin_zalo_oa_secret_key"]').val()
          );
        }
        if (zaloDomain) {
          formData.append('checkin_use_zalo_user', isEnabled ? '1' : '0');
          formData.append('checkin_zalo_user_domain', zaloDomain);
          // Sub-toggles: customer & group
          const sendCustomer = $('input[data-zalo-sub="customer"]');
          const sendGroup = $('input[data-zalo-sub="group"]');
          formData.append('checkin_zalo_user_send_customer',
            (sendCustomer.is(':checked') && !sendCustomer.prop('disabled')) ? '1' : '0');
          formData.append('checkin_zalo_user_send_group',
            sendGroup.is(':checked') ? '1' : '0');
        }
        break;
      case 'lark':
        if (isEnabled) {
          formData.append('checkin_use_lark', '1');
        }
        // When disabled, don't append the field (it will be treated as unchecked)
        break;
      case 'google':
        if (isEnabled) {
          formData.append('checkin_use_google_login', '1');
          formData.append(
            'checkin_google_client_id',
            $('input[name="checkin_google_client_id"]').val()
          );
        }
        // Khi tắt, chỉ gửi connection_type là đủ (server sẽ hiểu không có checkin_use_google_login = tắt)
        break;
      case 'facebook':
        if (isEnabled) {
          formData.append('checkin_use_facebook_login', '1');
          formData.append(
            'checkin_facebook_app_id',
            $('input[name="checkin_facebook_app_id"]').val()
          );
          formData.append(
            'checkin_facebook_app_secret',
            $('input[name="checkin_facebook_app_secret"]').val()
          );
        }
        // Khi tắt, chỉ gửi connection_type là đủ (server sẽ hiểu không có checkin_use_facebook_login = tắt)
        break;
    }

    $.ajax({
      url: ajaxurl,
      type: 'POST',
      data: formData,
      processData: false,
      contentType: false,
      success: function (response) {
        if (response.success) {
          console.log('Connection state saved:', connection, isEnabled);
        } else {
          console.error('Failed to save connection state:', response.data.message);
          showNotification('Lỗi khi lưu trạng thái: ' + (response.data.message || ''), 'error');
        }
      },
      error: function () {
        console.error('Network error saving connection state');
        showNotification('Không thể kết nối đến server!', 'error');
      },
    });
  }

  // Check if connection needs configuration
  function needsConfiguration(connection) {
    switch (connection) {
      case 'zalo':
        const zaloOA = $('input[name="checkin_use_zalo_oa"]');
        const zaloUser = $('input[name="checkin_use_zalo_user"]');
        const zaloAppId = $('input[name="checkin_zalo_oa_app_id"]').val();
        const zaloSecretKey = $('input[name="checkin_zalo_oa_secret_key"]').val();
        const zaloDomain = $('input[name="checkin_zalo_user_domain"]').val();

        // If Zalo OA is enabled, check App ID and Secret Key
        if (zaloOA.length && zaloOA.is(':checked')) {
          if (!zaloAppId || !zaloSecretKey || zaloAppId.length < 15 || zaloSecretKey.length < 20) {
            return true;
          }
        }
        // If Zalo User is enabled, check domain
        if (zaloUser.length && zaloUser.is(':checked')) {
          if (!zaloDomain) {
            return true;
          }
        }
        // If neither is enabled, needs configuration
        if ((!zaloOA.length || !zaloOA.is(':checked')) && (!zaloUser.length || !zaloUser.is(':checked'))) {
          return true;
        }
        return false;

      case 'google':
        const googleClientId = $('input[name="checkin_google_client_id"]').val();
        // Stricter regex: 12 digits, dash, 32 lowercase alphanumeric, .apps.googleusercontent.com
        const googleRegex = /^[0-9]{12}-[a-z0-9]{32}\.apps\.googleusercontent\.com$/;
        return !googleClientId || !googleRegex.test(googleClientId);

      case 'facebook':
        const fbAppId = $('input[name="checkin_facebook_app_id"]').val();
        const fbAppSecret = $('input[name="checkin_facebook_app_secret"]').val();
        const fbIdRegex = /^\d{10,20}$/;
        return !fbAppId || !fbIdRegex.test(fbAppId) || !fbAppSecret || fbAppSecret.length < 10;

      case 'lark':
        // Lark doesn't require immediate configuration
        return false;

      default:
        return false;
    }
  }

  // Check if connection has any saved data
  function hasExistingData(connection) {
    switch (connection) {
      case 'zalo':
        const zaloAppId = $('input[name="checkin_zalo_oa_app_id"]').val();
        const zaloSecretKey = $('input[name="checkin_zalo_oa_secret_key"]').val();
        const zaloDomain = $('input[name="checkin_zalo_user_domain"]').val();
        return !!(zaloAppId || zaloSecretKey || zaloDomain); // Has data if any field exists

      case 'google':
        const googleClientId = $('input[name="checkin_google_client_id"]').val();
        return !!googleClientId; // Has data if client ID exists

      case 'facebook':
        const fbAppId = $('input[name="checkin_facebook_app_id"]').val();
        const fbAppSecret = $('input[name="checkin_facebook_app_secret"]').val();
        return !!(fbAppId || fbAppSecret); // Has data if either field exists

      case 'lark':
        return false; // Lark doesn't require pre-check

      default:
        return false;
    }
  }

  // Clear connection data from database when validation fails
  function clearConnectionData(connectionType) {
    $.ajax({
      url: ajaxurl,
      type: 'POST',
      data: {
        action: 'checkin_clear_connection_data',
        connection_type: connectionType,
        nonce: checkinAdmin.nonce,
      },
      success: function (response) {
        if (response.success) {
          console.log('Connection data cleared:', connectionType);
        }
      },
      error: function () {
        console.error('Failed to clear connection data:', connectionType);
      },
    });
  }

  // Handle form submission via AJAX
  $('.checkin-connection-form').on('submit', function (e) {
    e.preventDefault();

    const form = $(this);
    const formData = new FormData(this);
    const submitBtn = form.find('button[type="submit"]');
    const connectionType = form.attr('id').replace('form-', '');

    // Validate required fields
    let isValid = true;
    let missingFields = [];

    form.find('[required]').each(function () {
      if (
        !$(this).val() ||
        ($(this).is(':checkbox') && !$(this).is(':checked') && $(this).attr('data-required-check'))
      ) {
        isValid = false;
        $(this).addClass('checkin-input-error');
        const label = $(this).closest('.checkin-form-group').find('.checkin-form-label').text();
        if (label) missingFields.push(label);
      } else {
        $(this).removeClass('checkin-input-error');
      }
    });

    // Additional validation for Google Client ID
    if (connectionType === 'google') {
      const googleClientId = $('input[name="checkin_google_client_id"]').val();
      const googleRegex = /^[a-zA-Z0-9\-_]+\.apps\.googleusercontent\.com$/;
      if (googleClientId && !googleRegex.test(googleClientId)) {
        isValid = false;
        $('input[name="checkin_google_client_id"]').addClass('checkin-input-error');
        showNotification(
          'Google Client ID không hợp lệ. Client ID phải có định dạng: xxxxx.apps.googleusercontent.com',
          'error'
        );
        return;
      }
    }

    // Additional validation for Facebook App ID and Secret
    if (connectionType === 'facebook') {
      const fbAppId = $('input[name="checkin_facebook_app_id"]').val();
      const fbAppSecret = $('input[name="checkin_facebook_app_secret"]').val();
      const fbIdRegex = /^\d{10,20}$/; // Facebook App ID is numeric, 10-20 digits

      if (fbAppId && !fbIdRegex.test(fbAppId)) {
        isValid = false;
        $('input[name="checkin_facebook_app_id"]').addClass('checkin-input-error');
        showNotification(
          'Facebook App ID không hợp lệ. App ID phải là số có 10-20 chữ số.',
          'error'
        );
        return;
      }

      if (!fbAppSecret || fbAppSecret.length < 10) {
        isValid = false;
        $('input[name="checkin_facebook_app_secret"]').addClass('checkin-input-error');
        showNotification(
          'Facebook App Secret không hợp lệ. App Secret phải có ít nhất 10 ký tự.',
          'error'
        );
        return;
      }
    }

    if (!isValid) {
      if (missingFields.length > 0) {
        showNotification('Vui lòng điền đầy đủ các trường bắt buộc!', 'error');
      }
      return;
    }

    // Add action and nonce
    formData.append('action', 'checkin_save_connection');
    formData.append('connection_type', connectionType);
    formData.append('nonce', checkinAdmin.nonce);

    // Disable submit button
    submitBtn.prop('disabled', true).addClass('checkin-button-loading');

    $.ajax({
      url: ajaxurl,
      type: 'POST',
      data: formData,
      processData: false,
      contentType: false,
      success: function (response) {
        if (response.success) {
          // Show success message
          showNotification(response.data.message || 'Cài đặt đã được lưu!', 'success');

          // Auto-enable toggle if saved successfully
          const toggle = $('.checkin-connection-toggle[data-connection="' + connectionType + '"]');
          if (!toggle.is(':checked')) {
            toggle.prop('checked', true);
            // Update card state
            const card = toggle.closest('.checkin-connection-card');
            card.removeClass('disabled').addClass('enabled');
            card
              .find('.checkin-badge')
              .removeClass('checkin-badge-gray')
              .addClass('checkin-badge-success')
              .text('Enabled');
            card.find('.checkin-toggle-status-text').text('Đang bật');
          }

          // Close modal after delay
          setTimeout(function () {
            closeConnectionModal(connectionType);
          }, 1000);
        } else {
          showNotification(response.data.message || 'Có lỗi xảy ra!', 'error');

          // Clear invalid data from database
          clearConnectionData(connectionType);

          // Close modal and disable toggle on error
          setTimeout(function () {
            closeConnectionModal(connectionType);
            const toggle = $(
              '.checkin-connection-toggle[data-connection="' + connectionType + '"]'
            );
            toggle.prop('checked', false);
            // Update card state
            const card = toggle.closest('.checkin-connection-card');
            card.removeClass('enabled').addClass('disabled');
            card
              .find('.checkin-badge')
              .removeClass('checkin-badge-success')
              .addClass('checkin-badge-gray')
              .text('Disabled');
            card.find('.checkin-toggle-status-text').text('Đang tắt');
          }, 1500);
        }
      },
      error: function () {
        showNotification('Không thể kết nối đến server!', 'error');

        // Clear invalid data from database
        clearConnectionData(connectionType);

        // Close modal and disable toggle on network error
        setTimeout(function () {
          closeConnectionModal(connectionType);
          const toggle = $('.checkin-connection-toggle[data-connection="' + connectionType + '"]');
          toggle.prop('checked', false);
          const card = toggle.closest('.checkin-connection-card');
          card.removeClass('enabled').addClass('disabled');
          card
            .find('.checkin-badge')
            .removeClass('checkin-badge-success')
            .addClass('checkin-badge-gray')
            .text('Disabled');
          card.find('.checkin-toggle-status-text').text('Đang tắt');
        }, 1500);
      },
      complete: function () {
        submitBtn.prop('disabled', false).removeClass('checkin-button-loading');
      },
    });
  });

  // Note: showNotification() is now defined in common.js

  // Password toggle
  $(document).on('click', '.checkin-toggle-password', function () {
    const btn = $(this);
    const targetId = btn.data('target');
    const input = $('#' + targetId);
    const icon = btn.find('.dashicons');

    if (input.attr('type') === 'password') {
      input.attr('type', 'text');
      icon.removeClass('dashicons-visibility').addClass('dashicons-hidden');
    } else {
      input.attr('type', 'password');
      icon.removeClass('dashicons-hidden').addClass('dashicons-visibility');
    }
  });

  // Open add bot modal
  window.openAddBotModal = function () {
    resetBotForm();
    $('#bot-modal-title-text').text('Thêm Bot');
    $('#bot-submit-text').text('Tạo Bot');
    $('#bot-submit-icon').removeClass('dashicons-yes').addClass('dashicons-saved');
    $('#bot_id').val('');
    const $modal = $('#modal-bot-form');
    $modal.css('display', 'flex').addClass('active');
    document.body.style.overflow = 'hidden';
    // Smooth scroll to top
    $modal.find('.checkin-modal-body').scrollTop(0);
    // Filter pills based on default bot type
    filterNotificationPills($('#bot_type').val());
  };

  // Open edit bot modal
  window.openEditBotModal = function (botId) {
    // Show modal immediately with loading state
    const $modal = $('#modal-bot-form');
    $modal.css('display', 'flex').addClass('active');
    document.body.style.overflow = 'hidden';

    // Show loading indicator
    const $body = $modal.find('.checkin-modal-body');
    const originalContent = $body.html();
    $body.html(
      '<div class="checkin-loading-spinner"><div class="spinner"></div><p>Đang tải...</p></div>'
    );
    $body.scrollTop(0);

    $.ajax({
      url: ajaxurl,
      type: 'POST',
      data: {
        action: 'checkin_get_lark_bot',
        bot_id: botId,
        nonce: checkinLarkBot.nonce,
      },
      timeout: 10000, // 10 second timeout
      success: function (response) {
        if (response.success && response.data.bot) {
          const bot = response.data.bot;

          // Restore form content first before modifying
          const $modal = $('#modal-bot-form');
          $modal.find('.checkin-modal-body').html(originalContent);

          // Now fill form with bot data
          $('#bot_id').val(bot.id);
          $('#bot_name').val(bot.bot_name);
          $('#is_active').prop('checked', bot.is_active == 1);

          // Set notification types BEFORE changing bot_type (to prevent pills from being hidden/deactivated)
          if (bot.notification_types) {
            const types =
              typeof bot.notification_types === 'string'
                ? JSON.parse(bot.notification_types)
                : bot.notification_types;
            $('.checkin-pill').removeClass('active');
            // Show all pills first
            $('.checkin-pill').removeClass('hidden').show();
            // Then activate the selected ones
            types.forEach(function (type) {
              $('.checkin-pill[data-value="' + type + '"]').addClass('active');
            });
            updateNotificationTypesInput();
          }

          // Now set bot_type (which will filter pills, but keep the active ones)
          $('#bot_type').val(bot.bot_type).trigger('change');

          // Fill interactive fields
          if (bot.bot_type === 'interactive') {
            $('#chat_id').val(bot.chat_id || '');
            $('#app_id').val(bot.app_id || '');
            $('#app_secret').val(bot.app_secret || '');
          } else {
            $('#webhook_url').val(bot.webhook_url || '');
          }

          // Update modal title
          $('#bot-modal-title-text').text('Chỉnh sửa Bot');
          $('#bot-submit-text').text('Cập nhật Bot');
          $('#bot-submit-icon').removeClass('dashicons-saved').addClass('dashicons-yes');

          $modal.find('.checkin-modal-body').scrollTop(0);
        } else {
          // Hide loading & show error
          closeBotFormModal();
          showNotification(response.data.message || 'Không thể tải thông tin bot!', 'error');
        }
      },
      error: function (xhr, status, error) {
        // Hide loading & show error
        closeBotFormModal();
        let errorMsg = 'Không thể kết nối đến server!';
        if (status === 'timeout') {
          errorMsg = 'Yêu cầu hết thời gian chờ!';
        }
        showNotification(errorMsg, 'error');
      },
    });
  };

  // Close bot form modal
  window.closeBotFormModal = function () {
    const $modal = $('#modal-bot-form');
    $modal.removeClass('active');
    setTimeout(function () {
      $modal.css('display', 'none');
      document.body.style.overflow = '';
      resetBotForm();
    }, 300); // Match CSS transition duration
  };

  // Reset bot form
  function resetBotForm() {
    $('#form-bot')[0].reset();
    $('#bot_id').val('');
    $('.checkin-pill').removeClass('active');
    $('#notification_types').val('');
    $('#bot_type').val('interactive').trigger('change');
  }

  // Close modal when clicking backdrop
  $(document).on('click', '#modal-bot-form', function (e) {
    if (e.target.id === 'modal-bot-form') {
      closeBotFormModal();
    }
  });

  // Handle pill notification type selection
  $(document).on('click', '.checkin-pill', function (e) {
    // Don't toggle if clicking on info icon
    if ($(e.target).hasClass('pill-info-icon')) {
      e.stopPropagation();
      showPillTooltip($(e.target));
      return;
    }
    // Only allow toggling visible pills
    if (!$(this).hasClass('hidden') && $(this).is(':visible')) {
      $(this).toggleClass('active');
      updateNotificationTypesInput();
    }
  });

  // Show tooltip for pill info
  function showPillTooltip($icon) {
    const $pill = $icon.closest('.checkin-pill');
    const description = $pill.data('description');

    if (!description) return;

    // Remove existing tooltips
    $('.pill-tooltip').remove();

    // Create tooltip
    const $tooltip = $('<div class="pill-tooltip">' + description + '</div>');
    $pill.append($tooltip);

    // Show tooltip
    setTimeout(() => $tooltip.addClass('show'), 10);

    // Auto hide after 5 seconds
    setTimeout(() => {
      $tooltip.removeClass('show');
      setTimeout(() => $tooltip.remove(), 200);
    }, 5000);
  }

  // Close tooltips when clicking outside
  $(document).on('click', function (e) {
    if (!$(e.target).closest('.checkin-pill').length) {
      $('.pill-tooltip').removeClass('show');
      setTimeout(() => $('.pill-tooltip').remove(), 200);
    }
  });

  // Update hidden input with selected notification types
  function updateNotificationTypesInput() {
    const selected = [];
    $('.checkin-pill.active:visible').each(function () {
      selected.push($(this).data('value'));
    });
    $('#notification_types').val(JSON.stringify(selected));
    console.log('Updated notification_types:', selected);
  }

  // Handle bot type change
  $(document).on('change', '#bot_type', function () {
    const type = $(this).val();

    // Toggle bot fields sections
    $('#interactive-bot-fields, #webhook-bot-fields').removeClass('active');
    if (type === 'interactive') {
      $('#interactive-bot-fields').addClass('active');
    } else {
      $('#webhook-bot-fields').addClass('active');
    }

    // Filter notification type pills
    filterNotificationPills(type);
  });

  // Filter pills based on bot type
  function filterNotificationPills(botType) {
    $('.checkin-pill').each(function () {
      const $pill = $(this);
      const pillBotType = $pill.data('bot-type');

      if (pillBotType === botType) {
        $pill.removeClass('hidden').show();
      } else {
        $pill.addClass('hidden').hide();
        // Don't deactivate active pills - they might be needed when showing notification_types
        // Just hide them visually
      }
    });
  }

  // Handle bot form submission
  $(document).on('submit', '#form-bot', function (e) {
    e.preventDefault();

    const form = $(this);
    const formData = new FormData(this);
    const submitBtn = form.find('button[type="submit"]');

    // Validate bot name
    if (!$('#bot_name').val().trim()) {
      showNotification('Vui lòng nhập tên bot!', 'error');
      return;
    }

    // Update notification types before validation
    updateNotificationTypesInput();

    // Validate notification types (only visible pills)
    const notificationTypes = $('#notification_types').val();
    if (
      !notificationTypes ||
      notificationTypes === '[]' ||
      JSON.parse(notificationTypes).length === 0
    ) {
      showNotification('Vui lòng chọn ít nhất một loại thông báo!', 'error');
      return;
    }

    formData.append('action', 'checkin_save_lark_bot');
    formData.append('nonce', checkinLarkBot.nonce);

    submitBtn.prop('disabled', true).addClass('checkin-button-loading');

    $.ajax({
      url: ajaxurl,
      type: 'POST',
      data: formData,
      processData: false,
      contentType: false,
      success: function (response) {
        if (response.success) {
          showNotification(response.data.message || 'Bot đã được lưu!', 'success');
          // Close bot form modal
          closeBotFormModal();
          // Reload Lark bot list in modal
          reloadLarkBotList();
        } else {
          showNotification(response.data.message || 'Có lỗi xảy ra!', 'error');
        }
      },
      error: function () {
        showNotification('Không thể kết nối đến server!', 'error');
      },
      complete: function () {
        submitBtn.prop('disabled', false).removeClass('checkin-button-loading');
      },
    });
  });

  /**
   * Reload Lark bot list without reload page
   */
  function reloadLarkBotList() {
    $.ajax({
      url: ajaxurl,
      type: 'GET',
      data: {
        action: 'checkin_get_lark_bots',
        nonce: checkinLarkBot.nonce,
      },
      success: function (response) {
        if (response.success && response.data.html) {
          // Replace bot list HTML
          $('.checkin-bot-list').html(response.data.html);
          // Re-bind delete handlers for new bots
          rebindBotHandlers();
        }
      },
      error: function () {
        console.log('Error reloading bot list');
      },
    });
  }

  /**
   * Rebind event handlers for bot items after reload
   */
  function rebindBotHandlers() {
    // Delete buttons are handled via window.deleteLarkBot which is global
    // Edit buttons are handled via window.openEditBotModal which is global
    // No need to rebind as they use onclick handlers in HTML
  }

  // Delete bot
  window.deleteLarkBot = function (botId) {
    if (!confirm('Bạn có chắc chắn muốn xóa bot này?')) {
      return;
    }

    $.ajax({
      url: ajaxurl,
      type: 'POST',
      data: {
        action: 'checkin_delete_lark_bot',
        bot_id: botId,
        nonce: checkinLarkBot.nonce,
      },
      success: function (response) {
        if (response.success) {
          showNotification(response.data.message || 'Bot đã được xóa!', 'success');
          // Remove bot from UI
          $('.checkin-bot-item[data-bot-id="' + botId + '"]').fadeOut(300, function () {
            $(this).remove();
            // Check if no bots left
            if ($('.checkin-bot-item').length === 0) {
              location.reload();
            }
          });
        } else {
          showNotification(response.data.message || 'Có lỗi xảy ra!', 'error');
        }
      },
      error: function () {
        showNotification('Không thể kết nối đến server!', 'error');
      },
    });
  };

  // Test Google Connection - Opens OAuth popup
  window.testGoogleConnection = function () {
    const clientId = $('input[name="checkin_google_client_id"]').val();
    if (!clientId) {
      showNotification('Vui lòng nhập Google Client ID trước!', 'warning');
      return;
    }

    // Load Google Sign-In library if not loaded
    if (typeof google === 'undefined' || !google.accounts) {
      const script = document.createElement('script');
      script.src = 'https://accounts.google.com/gsi/client';
      script.async = true;
      script.defer = true;
      script.onload = function () {
        initiateGoogleOAuth(clientId);
      };
      document.head.appendChild(script);
    } else {
      initiateGoogleOAuth(clientId);
    }
  };

  function initiateGoogleOAuth(clientId) {
    console.log('=== GOOGLE OAUTH INITIATE ===');
    console.log('Client ID:', clientId);
    console.log('Current Origin:', window.location.origin);
    console.log('Current Protocol:', window.location.protocol);
    console.log('Current Hostname:', window.location.hostname);
    console.log('Current Port:', window.location.port);
    console.log('Full URL:', window.location.href);
    console.log('Initializing Google Sign-In...');

    try {
      // Initialize - same as user-profile.js
      google.accounts.id.initialize({
        client_id: clientId,
        callback: handleGoogleConnectionResponse,
        context: 'signin',
        ux_mode: 'popup',
        auto_prompt: false,
      });

      console.log('Google initialized, triggering popup...');

      // Instead of prompt(), use popup directly - same as user-profile approach
      // Create a temporary container for the button
      const tempButtonContainer = document.createElement('div');
      tempButtonContainer.id = 'temp-google-signin-button';
      tempButtonContainer.style.position = 'fixed';
      tempButtonContainer.style.top = '-9999px';
      tempButtonContainer.style.left = '-9999px';
      document.body.appendChild(tempButtonContainer);

      // Render the button (this handles CORS properly)
      google.accounts.id.renderButton(tempButtonContainer, {
        theme: 'outline',
        size: 'large',
        width: 300,
      });

      // Auto-click the button to trigger popup
      setTimeout(() => {
        const googleButton = tempButtonContainer.querySelector('div[role="button"]');
        if (googleButton) {
          console.log('Auto-clicking Google sign-in button...');
          googleButton.click();

          // Clean up after a delay
          setTimeout(() => {
            if (document.body.contains(tempButtonContainer)) {
              document.body.removeChild(tempButtonContainer);
            }
          }, 2000);
        } else {
          console.error('Could not find Google button to click');
          showNotification('Không thể khởi tạo popup Google. Vui lòng thử lại.', 'error');
          if (document.body.contains(tempButtonContainer)) {
            document.body.removeChild(tempButtonContainer);
          }
        }
      }, 100);

      console.log('Google sign-in triggered');
    } catch (error) {
      console.error('=== GOOGLE OAUTH ERROR ===');
      console.error('Error Message:', error.message);
      console.error('Error Stack:', error.stack);
      console.error('Error Name:', error.name);
      console.error('Error Object:', error);
      console.error('Error Type:', typeof error);

      let errorMsg = 'Lỗi khởi tạo Google OAuth: ' + error.message;
      if (error.message && error.message.includes('CORS')) {
        errorMsg +=
          '\n\n🔴 LỖI CORS: Bạn chưa thêm URL http://localhost:8080 vào Google Console!\n';
        errorMsg += '\n✅ Hướng dẫn:\n';
        errorMsg += '1. Mở https://console.cloud.google.com/apis/credentials\n';
        errorMsg += '2. Chọn OAuth Client ID của bạn\n';
        errorMsg += '3. Thêm http://localhost:8080 vào "Authorized JavaScript origins"\n';
        errorMsg += '4. Lưu và đợi 5-10 phút\n';
        errorMsg += '5. Xóa cache trình duyệt hoặc dùng Incognito mode';
      }

      showNotification(errorMsg, 'error');
    }
  }

  function handleGoogleConnectionResponse(response) {
    if (response.credential) {
      console.log('Google ID Token:', response.credential);

      // Decode JWT token to get user info
      const base64Url = response.credential.split('.')[1];
      const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
      const jsonPayload = decodeURIComponent(
        atob(base64)
          .split('')
          .map(function (c) {
            return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
          })
          .join('')
      );

      const userData = JSON.parse(jsonPayload);
      console.log('Google User Data:', userData);

      // Save to backend
      const restUrl = checkinAdmin.restUrl || window.location.origin + '/wp-json/vg/v1/';
      const apiUrl = restUrl + 'google-settings';
      const payload = {
        email: userData.email,
        name: userData.name,
        email_verified: userData.email_verified,
        picture: userData.picture,
      };

      console.log('=== SAVING TO BACKEND ===');
      console.log('API URL:', apiUrl);
      console.log('Payload:', payload);
      console.log('Nonce:', checkinAdmin.restNonce || checkinAdmin.nonce);

      fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-WP-Nonce': checkinAdmin.restNonce || checkinAdmin.nonce,
        },
        body: JSON.stringify(payload),
      })
        .then((res) => {
          console.log('Response status:', res.status);
          console.log('Response ok:', res.ok);
          return res.json();
        })
        .then((data) => {
          console.log('Save Google account response:', data);
          if (data.success) {
            // Display account info
            displayGoogleAccountInfo({
              email: userData.email,
              name: userData.name,
              email_verified: userData.email_verified,
              picture: userData.picture,
            });

            showNotification('Kết nối Google thành công!', 'success');

            // Update card status
            const toggle = $('.checkin-connection-toggle[data-connection="google"]');
            toggle.prop('checked', true);
            const card = toggle.closest('.checkin-connection-card');
            card.removeClass('disabled').addClass('enabled');
            card
              .find('.checkin-badge')
              .removeClass('checkin-badge-gray')
              .addClass('checkin-badge-success')
              .text('Đã kết nối');
            card.find('.checkin-toggle-status-text').text('Đang bật');
          } else {
            showNotification('Lưu thông tin Google thất bại: ' + (data.message || ''), 'error');
          }
        })
        .catch((error) => {
          console.error('Error saving Google account:', error);
          showNotification('Lỗi khi lưu thông tin Google.', 'error');
        });
    } else {
      showNotification('Không thể kết nối với Google.', 'error');
    }
  }

  // Test Zalo OA Connection - Opens OAuth in popup
  window.testZaloConnection = function () {
    const appId = $('input[name="checkin_zalo_oa_app_id"]').val();
    const secretKey = $('input[name="checkin_zalo_oa_secret_key"]').val();

    if (!appId || !secretKey) {
      showNotification('Vui lòng nhập đầy đủ Zalo OA App ID và Secret Key!', 'warning');
      return;
    }

    // Không đóng modal - để user thấy tiến trình
    initiateZaloAuth(appId, secretKey);
  };

  // Initiate Zalo OAuth in popup
  function initiateZaloAuth(appId, appSecret) {
    // Debug logging
    console.log('=== ZALO CONFIG DEBUG ===');
    console.log('App ID:', appId);
    console.log('App ID length:', appId.length);
    console.log('App Secret:', appSecret ? '***' + appSecret.slice(-4) : 'empty');

    const restUrl = checkinAdmin.restUrl || window.location.origin + '/wp-json/vg/v1/';
    const callbackUrl = restUrl + 'zalo-webhook';

    console.log('REST URL:', restUrl);
    console.log('Callback URL:', callbackUrl);

    // Xóa token cũ trước (nếu có) để tránh polling phát hiện nhầm
    fetch(restUrl + 'zalo-settings', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-WP-Nonce': checkinAdmin.restNonce || checkinAdmin.nonce,
      },
      body: JSON.stringify({
        app_id: appId,
        app_secret: appSecret,
        clear_token: true, // Xóa access_token cũ
      }),
    })
      .then((response) => response.json())
      .then((data) => {
        console.log('Save config response:', data);

        if (data.success && data.auth_url) {
          console.log('✅ Đã xóa token cũ (nếu có) và lưu credentials mới');
          // Open Zalo OAuth in popup
          const authUrl = data.auth_url;
          const state = data.state;

          console.log('🚀 Opening Zalo OAuth in new window...');
          console.log('Auth URL:', authUrl);
          console.log('⚠️ QUAN TRỌNG: Callback URL phải khớp với URL đã đăng ký trên Zalo:');
          console.log('👉', callbackUrl);

          // Save state for verification
          sessionStorage.setItem('zalo_oauth_state', state);

          // Open in popup
          const width = 600;
          const height = 700;
          const left = (screen.width - width) / 2;
          const top = (screen.height - height) / 2;
          const popup = window.open(
            authUrl,
            'ZaloOAuth',
            `width=${width},height=${height},left=${left},top=${top},toolbar=no,location=no,status=no,menubar=no,scrollbars=yes,resizable=yes`
          );

          if (!popup) {
            console.error('❌ Popup bị chặn! Mở trong tab mới...');
            window.open(authUrl, '_blank');
          }

          // Start polling for OAuth completion
          startZaloOAuthPolling(popup);
        } else {
          showNotification(
            'Lỗi khi lưu cấu hình: ' + (data.message || 'Không có thông tin lỗi'),
            'error'
          );
        }
      })
      .catch((error) => {
        console.error('Error saving config:', error);
        showNotification('Đã xảy ra lỗi khi lưu cấu hình: ' + error.message, 'error');
      });
  }

  // Poll for OAuth success
  function startZaloOAuthPolling(popup) {
    console.log('⏳ Đang chờ xác thực từ Zalo...');

    let pollCount = 0;
    const maxPolls = 120; // 2 minutes max
    const restUrl = checkinAdmin.restUrl || window.location.origin + '/wp-json/vg/v1/';

    const pollInterval = setInterval(() => {
      pollCount++;

      // Kiểm tra nếu popup bị đóng bởi user (không phải do code)
      if (popup && popup.closed) {
        clearInterval(pollInterval);
        console.log('⚠️ Popup đã bị đóng, dừng polling');
        showNotification(
          'Bạn đã đóng cửa sổ xác thực. Vui lòng thử lại nếu chưa hoàn tất.',
          'warning'
        );
        return;
      }

      // Check if token exists in database
      fetch(restUrl + 'zalo-settings', {
        method: 'GET',
        headers: { 'X-WP-Nonce': checkinAdmin.restNonce || checkinAdmin.nonce },
      })
        .then((response) => response.json())
        .then((data) => {
          if (data.success && data.data && data.data.access_token) {
            clearInterval(pollInterval);
            console.log('✅ Kết nối Zalo thành công!');

            // Đóng popup OAuth window
            if (popup && !popup.closed) {
              popup.close();
              console.log('🔒 Đã đóng popup OAuth');
            }

            showNotification('Kết nối Zalo OA thành công! Thông tin OA đã được lưu.', 'success');
            sessionStorage.removeItem('zalo_oauth_state');

            // Load và hiển thị thông tin OA
            loadZaloOAInfo(data.data);

            // Update UI to show connected status
            const toggle = $('.checkin-connection-toggle[data-connection="zalo"]');
            toggle.prop('checked', true);
            const card = toggle.closest('.checkin-connection-card');
            card.removeClass('disabled').addClass('enabled');
            card
              .find('.checkin-badge')
              .removeClass('checkin-badge-gray')
              .addClass('checkin-badge-success')
              .text('Đã kết nối');
            card.find('.checkin-toggle-status-text').text('Đang bật');
          } else if (pollCount >= maxPolls) {
            clearInterval(pollInterval);
            console.log('⏰ Timeout: Vui lòng thử lại');
            showNotification('Timeout: Vui lòng hoàn tất xác thực và thử lại', 'warning');
          }
        })
        .catch((error) => {
          console.error('Polling error:', error);
        });
    }, 1000); // Poll every second
  }

  // Handle Zalo OAuth callback
  function handleZaloCallback() {
    const urlParams = new URLSearchParams(window.location.search);
    const zaloSuccess = urlParams.get('zalo_success');
    const state = urlParams.get('state');
    const error = urlParams.get('error');
    const errorDesc = urlParams.get('error_description');

    if (zaloSuccess === 'true' && state) {
      showNotification('Kết nối Zalo OA thành công! Thông tin OA đã được lưu.', 'success');
      sessionStorage.removeItem('zalo_oauth_state');

      // Clean URL
      const cleanUrl =
        window.location.origin + window.location.pathname + '?page=checkin-connections';
      window.history.replaceState({}, document.title, cleanUrl);

      // Reload to update UI
      setTimeout(() => {
        location.reload();
      }, 1500);
    } else if (error) {
      showNotification('Kết nối Zalo thất bại: ' + (errorDesc || error), 'error');

      // Clean URL
      const cleanUrl =
        window.location.origin + window.location.pathname + '?page=checkin-connections';
      window.history.replaceState({}, document.title, cleanUrl);
    }
  }

  // Show/hide connection test buttons when credentials are filled
  $('input[name="checkin_google_client_id"]').on('input', function () {
    const hasValue = $(this).val().trim().length > 0;
    $('#test-google-connection-btn').toggle(hasValue);
  });

  $('input[name="checkin_zalo_oa_app_id"], input[name="checkin_zalo_oa_secret_key"]').on(
    'input',
    function () {
      const appId = $('input[name="checkin_zalo_oa_app_id"]').val().trim();
      const secretKey = $('input[name="checkin_zalo_oa_secret_key"]').val().trim();
      $('#test-zalo-connection-btn').toggle(appId.length > 0 && secretKey.length > 0);
    }
  );

  // Load Zalo OA info on modal open
  function loadZaloOAInfo(oaData, callback) {
    // Hiện loading overlay với blur effect
    $('#zalo-loading-overlay').fadeIn(200);

    if (!oaData) {
      // Fetch from API if not provided
      const restUrl = checkinAdmin.restUrl || window.location.origin + '/wp-json/vg/v1/';
      fetch(restUrl + 'zalo-settings', {
        method: 'GET',
        headers: { 'X-WP-Nonce': checkinAdmin.restNonce || checkinAdmin.nonce },
      })
        .then((response) => response.json())
        .then((data) => {
          $('#zalo-loading-overlay').fadeOut(200);
          if (data.success && data.data && data.data.access_token) {
            displayZaloOAInfo(data.data);
          } else {
            hideZaloOAInfo();
          }
          if (callback) callback();
        })
        .catch(() => {
          $('#zalo-loading-overlay').fadeOut(200);
          hideZaloOAInfo();
          if (callback) callback();
        });
    } else {
      $('#zalo-loading-overlay').fadeOut(200);
      displayZaloOAInfo(oaData);
      if (callback) callback();
    }
  }

  function displayZaloOAInfo(oaData) {
    if (!oaData.oa_name) {
      hideZaloOAInfo();
      return;
    }

    // Hiện OA info, ẩn credentials form với animation
    $('#zalo-credentials-form').fadeOut(200, function () {
      $('#zalo-oa-info').fadeIn(300);
      $('#zalo-reconnect-btn-wrapper').fadeIn(300);
    });

    $('#zalo-oa-name').text(oaData.oa_name || 'Zalo OA');
    $('#zalo-oa-id').text('OA ID: ' + (oaData.oa_id || 'N/A'));
    $('#zalo-oa-followers').text((oaData.num_follower || 0).toLocaleString());
    $('#zalo-oa-package').text(oaData.package_name || 'Free');

    if (oaData.is_verified === '1' || oaData.is_verified === 1) {
      $('#zalo-oa-verified').show();
    } else {
      $('#zalo-oa-verified').hide();
    }

    // Show ZBS template section and auto-load templates
    $('#zbs-template-section').fadeIn(300);
    loadZaloTemplates();

    // Setup nút "Kết nối lại" riêng
    $('#zalo-reconnect-btn')
      .off('click')
      .on('click', function () {
        // Khi bấm Kết nối lại: Hiện form, ẩn OA info
        $('#zalo-oa-info').hide();
        $('#zalo-reconnect-btn-wrapper').hide();
        $('#zbs-template-section').hide();
        $('#zalo-credentials-form').show();

        // Trigger kiểm tra để hiện nút kết nối nếu đã có credentials
        $('input[name="checkin_zalo_oa_app_id"]').trigger('input');
      });
  }

  // ==================== ZBS Template Functions ====================

  /**
   * Load danh sách ZBS templates từ Zalo API
   */
  window.loadZaloTemplates = function () {
    const $loading = $('#zbs-templates-loading');
    const $content = $('#zbs-templates-content');
    const $empty = $('#zbs-templates-empty');
    const $btn = $('#btn-load-zbs-templates');

    // Show loading, hide others
    $loading.show();
    $content.hide();
    $empty.hide();
    $btn.prop('disabled', true).addClass('is-loading');

    $.ajax({
      url: ajaxurl,
      type: 'POST',
      data: {
        action: 'checkin_get_zalo_templates',
        nonce: checkinAdmin.nonce,
      },
      timeout: 20000,
      success: function (response) {
        $loading.hide();
        $btn.prop('disabled', false).removeClass('is-loading');

        if (response.success && response.data && response.data.data) {
          const templates = response.data.data;

          if (templates.length === 0) {
            $empty.show();
            return;
          }

          populateZnsSelects(templates);
          // Show toggle button, start collapsed
          const $toggleBtn = $('#btn-toggle-zbs-templates');
          $toggleBtn.show();
          $content.hide(); // Start collapsed
          // Update button to show "Mở rộng"
          $toggleBtn.find('.dashicons').removeClass('dashicons-arrow-up-alt2').addClass('dashicons-arrow-down-alt2');
          $toggleBtn.contents().filter(function() { return this.nodeType === 3; }).last().replaceWith(' Mở rộng');
        } else {
          $empty.show();
          const msg =
            response.data && response.data.message
              ? response.data.message
              : 'Không thể tải danh sách template';
          console.error('ZBS template load error:', msg);
        }
      },
      error: function (xhr, status) {
        $loading.hide();
        $btn.prop('disabled', false).removeClass('is-loading');
        $empty.show();
        console.error('ZBS template AJAX error:', status);
      },
    });
  };

  /**
   * Toggle collapse/expand for ZBS template cards
   */
  $('#btn-toggle-zbs-templates').on('click', function () {
    const $content = $('#zbs-templates-content');
    const $btn = $(this);
    const $icon = $btn.find('.dashicons');

    if ($content.is(':visible')) {
      $content.slideUp(200);
      $icon.removeClass('dashicons-arrow-up-alt2').addClass('dashicons-arrow-down-alt2');
      $btn.contents().filter(function() { return this.nodeType === 3; }).last().replaceWith(' Mở rộng');
    } else {
      $content.slideDown(200);
      $icon.removeClass('dashicons-arrow-down-alt2').addClass('dashicons-arrow-up-alt2');
      $btn.contents().filter(function() { return this.nodeType === 3; }).last().replaceWith(' Thu gọn');
    }
  });

  /**
   * Populate all 4 ZBS template select dropdowns with pill UI
   */
  function populateZnsSelects(templates) {
    const selects = [
      { id: '#zbs-template-booking', pillId: '#zbs-pill-booking', savedId: '#saved-zbs-template-booking' },
      { id: '#zbs-template-cancel-booking', pillId: '#zbs-pill-cancel-booking', savedId: '#saved-zbs-template-cancel-booking' },
      { id: '#zbs-template-booking-reminder', pillId: '#zbs-pill-booking-reminder', savedId: '#saved-zbs-template-booking-reminder' },
      { id: '#zbs-template-invoice', pillId: '#zbs-pill-invoice', savedId: '#saved-zbs-template-invoice' },
    ];

    // Store templates for dropdown building
    window._zbsTemplates = templates;

    selects.forEach(function (sel) {
      const $select = $(sel.id);
      const $pillContainer = $(sel.pillId);
      const savedValue = $(sel.savedId).val();

      // Clear existing options except first
      $select.find('option:not(:first)').remove();

      // Add template options to hidden select
      templates.forEach(function (tpl) {
        const templateId = tpl.templateId || tpl.template_id;
        const templateName = tpl.templateName || tpl.template_name || 'Template ' + templateId;
        const option = $('<option></option>')
          .val(templateId)
          .text(templateName + ' (ID: ' + templateId + ')');
        $select.append(option);
      });

      // Restore saved selection and show pill
      if (savedValue) {
        $select.val(savedValue);
        showZnsPill($pillContainer, $select);
        // Also trigger detail load for info button
        const type = sel.id.replace('#zbs-template-', '');
        const $card = $pillContainer.closest('.zbs-template-card');
        $card.addClass('has-value');
      }

      // Bind placeholder click — open dropdown picker
      $pillContainer.find('.zbs-pill-placeholder').off('click.zbs').on('click.zbs', function (e) {
        e.stopPropagation();
        openZnsDropdown($pillContainer, $select, templates);
      });

      // Bind pill clear button
      $pillContainer.find('.zbs-pill-clear').off('click.zbs').on('click.zbs', function (e) {
        e.stopPropagation();
        clearZnsPill($pillContainer, $select);
      });
    });

    // Bind info buttons
    $('.zbs-info-btn').off('click.zbs').on('click.zbs', function (e) {
      e.stopPropagation();
      const $card = $(this).closest('.zbs-template-card');
      const $detail = $card.find('.zbs-template-detail');
      const $select = $card.find('.zbs-select');
      const selectedVal = $select.val();

      $(this).toggleClass('is-active');

      if ($detail.is(':visible')) {
        $detail.slideUp(200);
        return;
      }

      if (!selectedVal) {
        $detail.html(
          '<div class="zbs-detail-loading" style="color: var(--checkin-text-tertiary);">Chưa chọn template</div>'
        ).slideDown(200);
        return;
      }

      // Load detail
      const type = $select.attr('id').replace('zbs-template-', '');
      onZnsTemplateSelect(type, selectedVal);
    });

    // Close dropdown on outside click
    $(document).off('click.zbsDropdown').on('click.zbsDropdown', function () {
      $('.zbs-dropdown-picker').remove();
    });
  }

  /**
   * Open custom dropdown picker for ZBS templates
   */
  function openZnsDropdown($pillContainer, $select, templates) {
    // Close any existing
    $('.zbs-dropdown-picker').remove();

    const currentVal = $select.val();
    let html = '<div class="zbs-dropdown-picker">';

    templates.forEach(function (tpl) {
      const templateId = tpl.templateId || tpl.template_id;
      const templateName = tpl.templateName || tpl.template_name || 'Template ' + templateId;
      const isSelected = String(currentVal) === String(templateId);
      html += '<button type="button" class="zbs-dropdown-item' + (isSelected ? ' is-selected' : '') +
        '" data-value="' + escapeHtml(String(templateId)) +
        '" data-name="' + escapeHtml(templateName) + '">' +
        escapeHtml(templateName) +
        ' <span style="opacity:0.5;font-size:11px;">(ID: ' + escapeHtml(String(templateId)) + ')</span>' +
        '<span class="dashicons dashicons-yes-alt zbs-item-check"></span>' +
        '</button>';
    });

    html += '</div>';

    const $dropdown = $(html);
    $pillContainer.append($dropdown);

    // Bind item click
    $dropdown.find('.zbs-dropdown-item').on('click', function (e) {
      e.stopPropagation();
      const val = $(this).data('value');
      const name = $(this).data('name');

      $select.val(String(val)).trigger('change');
      showZnsPill($pillContainer, $select);

      const $card = $pillContainer.closest('.zbs-template-card');
      $card.addClass('has-value');

      $dropdown.remove();
    });

    // Prevent dropdown click from bubbling
    $dropdown.on('click', function (e) {
      e.stopPropagation();
    });
  }

  /**
   * Show pill chip with selected template name
   */
  function showZnsPill($pillContainer, $select) {
    const selectedText = $select.find('option:selected').text();
    const $pill = $pillContainer.find('.zbs-pill');
    const $placeholder = $pillContainer.find('.zbs-pill-placeholder');

    $pill.find('.zbs-pill-text').text(selectedText);
    $placeholder.hide();
    $pill.show();
  }

  /**
   * Clear pill and reset to placeholder
   */
  function clearZnsPill($pillContainer, $select) {
    const $pill = $pillContainer.find('.zbs-pill');
    const $placeholder = $pillContainer.find('.zbs-pill-placeholder');
    const $card = $pillContainer.closest('.zbs-template-card');
    const $detail = $card.find('.zbs-template-detail');

    $select.val('').trigger('change');
    $pill.hide();
    $placeholder.show();
    $card.removeClass('has-value');
    $card.find('.zbs-info-btn').removeClass('is-active');
    $detail.slideUp(200).empty();
  }

  /**
   * Handle ZBS template selection - show detail preview
   */
  function onZnsTemplateSelect(type, templateId) {
    const $detail = $('#zbs-detail-' + type);
    const $card = $detail.closest('.zbs-template-card');

    if (!templateId) {
      $detail.hide().empty();
      $card.removeClass('has-value');
      return;
    }

    $card.addClass('has-value');
    $detail
      .html(
        '<div class="zbs-detail-loading">' +
          '<div class="mini-spinner"></div>' +
          ' Đang tải chi tiết...' +
          '</div>'
      )
      .show();

    $.ajax({
      url: checkinAdmin.restUrl + 'zalo-template-detail?template_id=' + templateId,
      type: 'GET',
      timeout: 15000,
      beforeSend: function (xhr) {
        xhr.setRequestHeader('X-WP-Nonce', checkinAdmin.restNonce);
      },
      success: function (response) {
        if (response.success && response.data) {
          const tpl = response.data;
          let html = '<div class="zbs-detail-card">';

          // Template name
          if (tpl.templateName) {
            html +=
              '<div class="zbs-detail-name">' +
              '<span class="dashicons dashicons-text-page"></span> ' +
              escapeHtml(tpl.templateName) +
              '</div>';
          }

          // Price badge
          if (tpl.price !== undefined) {
            html +=
              '<div class="zbs-detail-price">💰 ' +
              Number(tpl.price).toLocaleString() +
              ' VNĐ/tin</div>';
          }

          // Parameters
          if (tpl.listParams && tpl.listParams.length > 0) {
            html += '<div class="zbs-detail-section-title">Tham số</div>';
            html += '<div class="zbs-detail-params">';
            tpl.listParams.forEach(function (p) {
              html +=
                '<span class="zbs-param-badge">' +
                escapeHtml(p.name || p.paramName || p) +
                '</span>';
            });
            html += '</div>';
          }

          // Preview URL
          if (tpl.previewUrl) {
            html +=
              '<a href="' +
              escapeHtml(tpl.previewUrl) +
              '" target="_blank" rel="noopener" class="zbs-detail-link">' +
              'Xem trước template ' +
              '<span class="dashicons dashicons-arrow-right-alt2"></span>' +
              '</a>';
          }

          html += '</div>';
          $detail.html(html);
        } else {
          $detail.html(
            '<div class="zbs-detail-loading" style="color: var(--checkin-text-tertiary);">Không thể tải chi tiết template</div>'
          );
        }
      },
      error: function () {
        $detail.html(
          '<div class="zbs-detail-loading" style="color: var(--checkin-text-tertiary);">Lỗi khi tải chi tiết template</div>'
        );
      },
    });
  }

  /**
   * Escape HTML to prevent XSS
   */
  function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.appendChild(document.createTextNode(text));
    return div.innerHTML;
  }

  function hideZaloOAInfo() {
    // Ẩn OA info, hiện credentials form với animation
    $('#zalo-oa-info').fadeOut(200);
    $('#zalo-reconnect-btn-wrapper').fadeOut(200, function () {
      $('#zalo-credentials-form').fadeIn(300);
    });
  }

  // Check for Zalo callback on page load
  if (
    window.location.search.includes('zalo_callback=1') ||
    window.location.search.includes('code=')
  ) {
    handleZaloCallback();
  }

  // ========== GOOGLE CONNECTION FUNCTIONS ==========

  // Load Google account info on modal open
  function loadGoogleAccountInfo(accountData, callback) {
    // Hiện loading overlay với blur effect
    $('#google-loading-overlay').fadeIn(200);

    if (!accountData) {
      // Fetch from backend
      const restUrl = checkinAdmin.restUrl || window.location.origin + '/wp-json/vg/v1/';
      fetch(restUrl + 'google-settings', {
        method: 'GET',
        headers: {
          'X-WP-Nonce': checkinAdmin.restNonce || checkinAdmin.nonce,
        },
      })
        .then((res) => res.json())
        .then((data) => {
          $('#google-loading-overlay').fadeOut(200);

          if (data.success && data.data && data.data.email) {
            // Có thông tin account -> hiển thị
            displayGoogleAccountInfo(data.data);
          } else {
            // Chưa có -> hiển thị form credentials
            hideGoogleAccountInfo();
          }

          if (callback) callback();
        })
        .catch((error) => {
          console.error('Error loading Google account:', error);
          $('#google-loading-overlay').fadeOut(200);
          hideGoogleAccountInfo();
          if (callback) callback();
        });
    } else {
      $('#google-loading-overlay').fadeOut(200);
      displayGoogleAccountInfo(accountData);
      if (callback) callback();
    }
  }

  function displayGoogleAccountInfo(accountData) {
    if (!accountData.email) {
      hideGoogleAccountInfo();
      return;
    }

    // Hiện account info, ẩn credentials form với animation
    $('#google-credentials-form').fadeOut(200, function () {
      $('#google-account-info').fadeIn(300);
      $('#google-reconnect-btn-wrapper').fadeIn(300);
    });

    $('#google-account-email').text(accountData.email || 'Google Account');
    $('#google-account-name').text(accountData.name || 'N/A');

    if (accountData.email_verified || accountData.verified_email) {
      $('#google-account-verified').show();
    } else {
      $('#google-account-verified').hide();
    }

    // Setup nút "Kết nối lại" riêng
    $('#google-reconnect-btn')
      .off('click')
      .on('click', function () {
        // Xóa account info cũ trước
        const restUrl = checkinAdmin.restUrl || window.location.origin + '/wp-json/vg/v1/';
        fetch(restUrl + 'google-settings', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-WP-Nonce': checkinAdmin.restNonce || checkinAdmin.nonce,
          },
          body: JSON.stringify({
            clear_account: true,
          }),
        })
          .then((res) => res.json())
          .then((data) => {
            console.log('Clear Google account response:', data);

            // Khi bấm Kết nối lại: Hiện form, ẩn account info
            $('#google-account-info').hide();
            $('#google-reconnect-btn-wrapper').hide();
            $('#google-credentials-form').show();

            // Trigger kiểm tra để hiện nút kết nối nếu đã có credentials
            $('input[name="checkin_google_client_id"]').trigger('input');
          })
          .catch((error) => {
            console.error('Error clearing Google account:', error);
            // Vẫn cho phép reconnect dù có lỗi
            $('#google-account-info').hide();
            $('#google-reconnect-btn-wrapper').hide();
            $('#google-credentials-form').show();
            $('input[name="checkin_google_client_id"]').trigger('input');
          });
      });
  }

  function hideGoogleAccountInfo() {
    // Ẩn account info, hiện credentials form với animation
    $('#google-account-info').fadeOut(200);
    $('#google-reconnect-btn-wrapper').fadeOut(200, function () {
      $('#google-credentials-form').fadeIn(300);
    });
  }

  // Enhanced Google connection handler
  const originalTestGoogleConnection = window.testGoogleConnection;
  window.testGoogleConnection = function () {
    const clientId = $('input[name="checkin_google_client_id"]').val();

    if (!clientId) {
      showNotification('Vui lòng nhập Google Client ID!', 'warning');
      return;
    }

    // Call original function
    if (originalTestGoogleConnection) {
      originalTestGoogleConnection();
    } else {
      // Fallback implementation
      initiateGoogleOAuth(clientId);
    }
  };

  // Enhanced Google OAuth response handler
  // Load info when opening modal
  const originalOpenModal = window.openConnectionModal;
  window.openConnectionModal = function (connection) {
    originalOpenModal(connection);
    if (connection === 'zalo') {
      loadZaloOAInfo();
    } else if (connection === 'google') {
      loadGoogleAccountInfo();
    }
  };

  // Show inline connect button when Client ID is entered
  $('input[name="checkin_google_client_id"]').on('input', function () {
    const clientId = $(this).val().trim();
    $('#test-google-connection-btn-inline').toggle(clientId.length > 0);
  });

  // Display current origin for debugging
  if ($('#debug-window-origin').length) {
    $('#debug-window-origin').text(window.location.origin);
    console.log('=== GOOGLE OAUTH DEBUG INFO ===');
    console.log('Current Origin:', window.location.origin);
    console.log('Current Hostname:', window.location.hostname);
    console.log('Current Protocol:', window.location.protocol);
    console.log('Current Port:', window.location.port);
    console.log('Full URL:', window.location.href);
    console.log('================================');
  }

  // Trigger initial check for showing buttons
  $('input[name="checkin_google_client_id"]').trigger('input');
  $('input[name="checkin_zalo_oa_app_id"]').trigger('input');

  // Add animations
  const style = document.createElement('style');
  style.textContent = `
    @keyframes slideInRight {
      from {
        transform: translateX(100%);
        opacity: 0;
      }
      to {
        transform: translateX(0);
        opacity: 1;
      }
    }
    @keyframes spin {
      from {
        transform: rotate(0deg);
      }
      to {
        transform: rotate(360deg);
      }
    }
    .checkin-button-success {
      background-color: #10b981;
      border-color: #10b981;
    }
    .checkin-button-success:hover {
      background-color: #059669;
      border-color: #059669;
    }
    .zalo-oa-settings {
      transition: opacity 0.3s ease;
    }
    #zalo-oa-info, #zalo-credentials-form, #zalo-reconnect-btn-wrapper {
      transition: opacity 0.3s ease;
    }
    .zalo-spinner, .google-spinner {
      animation: spin 0.8s linear infinite;
    }
    #zalo-loading-overlay, #google-loading-overlay {
      backdrop-filter: blur(8px);
      -webkit-backdrop-filter: blur(8px);
    }
    .google-settings {
      transition: opacity 0.3s ease;
    }
    #google-account-info, #google-credentials-form, #google-reconnect-btn-wrapper {
      transition: opacity 0.3s ease;
    }
  `;
  document.head.appendChild(style);
})(jQuery);
