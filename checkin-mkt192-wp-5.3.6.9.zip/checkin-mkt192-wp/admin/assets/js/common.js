/**
 * Common JavaScript Functions
 * Shared utilities for all admin pages
 * Version: 1.0.0
 */

(function ($) {
  'use strict';

  /**
   * Show toast notification
   * @param {string} message - The notification message
   * @param {string} type - Notification type: 'success', 'error', 'warning'
   */
  window.showNotification = function (message, type) {
    // Remove existing notifications
    $('.checkin-toast').remove();

    // Default to info type if not specified
    type = type || 'info';

    // SVG icons based on type
    let iconSvg =
      '<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M13.5 4L6 11.5L2.5 8" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>'; // success check
    if (type === 'error') {
      iconSvg =
        '<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M12 4L4 12M4 4L12 12" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>'; // error X
    } else if (type === 'warning') {
      iconSvg =
        '<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M8 5V9M8 11V11.5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/><circle cx="8" cy="8" r="7" stroke="currentColor" stroke-width="2"/></svg>'; // warning !
    } else if (type === 'info') {
      iconSvg =
        '<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><circle cx="8" cy="8" r="7" stroke="currentColor" stroke-width="2"/><path d="M8 7V12M8 5V5.5" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg>'; // info i
    }

    // Create notification element
    const notification = $(
      '<div class="checkin-toast checkin-toast-' +
        type +
        '">' +
        '<span class="checkin-toast-icon">' +
        iconSvg +
        '</span>' +
        '<div class="checkin-toast-content">' +
        '<p class="checkin-toast-message">' +
        message +
        '</p>' +
        '</div>' +
        '<button type="button" class="checkin-toast-close">×</button>' +
        '</div>'
    );

    // Append to body
    $('body').append(notification);

    // Close button handler
    notification.find('.checkin-toast-close').on('click', function () {
      notification.removeClass('show');
      setTimeout(function () {
        notification.remove();
      }, 300);
    });

    // Show animation
    setTimeout(function () {
      notification.addClass('show');
    }, 100);

    // Auto-hide after 3 seconds
    setTimeout(function () {
      notification.removeClass('show');
      setTimeout(function () {
        notification.remove();
      }, 300);
    }, 3000);
  };

  /**
   * Show page loading overlay
   */
  window.showPageLoading = function () {
    // Check if overlay already exists
    if ($('.checkin-glassmorphism-loader').length === 0) {
      const overlay = $(
        '<div class="checkin-glassmorphism-loader">' +
          '<div class="checkin-glass-container">' +
          '<div class="checkin-spinner-wrapper">' +
          '<div class="checkin-spinner-inner"></div>' +
          '</div>' +
          '<div class="checkin-loader-text">Đang tải</div>' +
          '</div>' +
          '</div>'
      );
      $('body').append(overlay);
    }
  };

  /**
   * Hide page loading overlay
   */
  window.hidePageLoading = function () {
    $('.checkin-glassmorphism-loader').fadeOut(300, function () {
      $(this).remove();
    });
  };

  /**
   * Initialize navigation loading
   */
  $(document).ready(function () {
    // Handle admin menu navigation with loading
    $(document).on(
      'click',
      '#adminmenu a[href*="checkin-mkt192"], .checkin-nav-item, .nav-tab',
      function (e) {
        const $link = $(this);
        const href = $link.attr('href');

        // Only show loading for internal plugin pages
        if (href && href.includes('checkin-mkt192')) {
          // Don't show loading if it's the current page or active tab
          if (!$link.hasClass('active') && !$link.hasClass('nav-tab-active')) {
            showPageLoading();
          }
        }
      }
    );

    // Hide loading on page load complete
    $(window).on('load', function () {
      setTimeout(function () {
        hidePageLoading();
      }, 400); // Delay thêm 400ms để thấy animation
    });

    // Hide loading when back/forward browser buttons are used
    $(window).on('pageshow', function (event) {
      if (event.originalEvent.persisted) {
        hidePageLoading();
      }
    });
  });
})(jQuery);
