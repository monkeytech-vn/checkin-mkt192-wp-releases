/**
 * Platforms Page JavaScript
 * Handle platform modal interactions and AJAX saves
 * Version: 5.1.0
 */

(function ($) {
  'use strict';

  /**
   * Open platform modal
   */
  window.openPlatformModal = function (platform) {
    const modal = document.getElementById('modal-' + platform);
    if (modal) {
      // Get card toggle state BEFORE showing modal
      const cardToggle = $(`.checkin-connection-toggle[data-connection="${platform}"]`);
      const isCardEnabled = cardToggle.is(':checked');

      // Always sync modal toggle with card toggle state
      syncModalToggleWithCard(platform, isCardEnabled);

      modal.classList.add('active');
      document.body.style.overflow = 'hidden';
    }
  };

  /**
   * Close platform modal
   */
  window.closePlatformModal = function (platform) {
    const modal = document.getElementById('modal-' + platform);
    if (modal) {
      modal.classList.remove('active');
      document.body.style.overflow = '';

      // Check if toggle is on but form not saved
      const toggle = $(`.checkin-connection-toggle[data-connection="${platform}"]`);
      if (toggle.length && toggle.is(':checked')) {
        // Check if has required data
        if (needsConfiguration(platform)) {
          // Turn off card toggle
          toggle.prop('checked', false);
          const card = toggle.closest('.checkin-connection-card');
          updateCardUI(card, false);

          // Sync modal toggle with card toggle - turn off modal toggle too
          syncModalToggleWithCard(platform, false);

          showNotification('Vui lòng hoàn tất cài đặt trước khi bật!', 'warning');
        }
      }
    }
  };

  /**
   * Sync modal internal toggle with card toggle state
   */
  function syncModalToggleWithCard(platform, isEnabled) {
    if (platform === 'wpsocial_ninja') {
      $('input[name="wpsocial_ninja_enabled"]').prop('checked', isEnabled);
    }
  }

  /**
   * Check if has existing data
   */
  function hasExistingData(platform) {
    if (platform === 'wpsocial_ninja') {
      const toggle = $(`.checkin-connection-toggle[data-connection="${platform}"]`);
      return toggle.data('has-config') === '1' || toggle.data('has-config') === 1;
    }
    return false;
  }

  /**
   * Check if needs configuration
   */
  function needsConfiguration(platform) {
    if (platform === 'wpsocial_ninja') {
      const shortcode = $('textarea[name="checkin_review_plugin_shortcode"]').val();
      return !shortcode || shortcode.trim() === '';
    }
    return false;
  }

  /**
   * Update card UI
   */
  function updateCardUI($card, isEnabled) {
    if (isEnabled) {
      $card.removeClass('disabled').addClass('enabled');
      $card
        .find('.checkin-badge')
        .removeClass('checkin-badge-gray')
        .addClass('checkin-badge-success')
        .text('Đang bật');
      $card.find('.checkin-toggle-status-text').text('Đang bật');
    } else {
      $card.removeClass('enabled').addClass('disabled');
      $card
        .find('.checkin-badge')
        .removeClass('checkin-badge-success')
        .addClass('checkin-badge-gray')
        .text('Đang tắt');
      $card.find('.checkin-toggle-status-text').text('Đang tắt');
    }
  }

  // Note: showNotification() is now defined in common.js

  $(document).ready(function () {
    /**
     * Handle platform toggle
     */
    $('.checkin-connection-toggle').on('change', function () {
      const $toggle = $(this);
      const platform = $toggle.data('connection');
      const isEnabled = $toggle.is(':checked');
      const $card = $toggle.closest('.checkin-connection-card');

      if (isEnabled) {
        // Check if has configuration
        const hasConfig = $toggle.data('has-config') === '1' || $toggle.data('has-config') === 1;

        if (!hasConfig) {
          // No data - open modal for setup
          setTimeout(() => {
            openPlatformModal(platform);
          }, 150);
        } else {
          // Has data - just enable
          updateCardUI($card, true);
          saveToggleState(platform, true);
        }
      } else {
        // Disable
        updateCardUI($card, false);
        saveToggleState(platform, false);
      }
    });

    /**
     * Save toggle state only
     */
    function saveToggleState(platform, isEnabled) {
      const formData = new FormData();
      formData.append('action', 'checkin_save_platform');
      formData.append('platform', platform);
      formData.append('nonce', checkinPlatformsAdmin.nonce);
      formData.append(platform + '_enabled', isEnabled ? 'yes' : 'no');

      $.ajax({
        url: checkinPlatformsAdmin.ajaxurl,
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function (response) {
          if (response.success) {
            showNotification(response.data.message);
          } else {
            showNotification(response.data.message, 'error');
          }
        },
        error: function () {
          showNotification('Có lỗi xảy ra khi lưu cài đặt!', 'error');
        },
      });
    }

    /**
     * Handle platform form submission
     */
    $('.checkin-platform-form').on('submit', function (e) {
      e.preventDefault();

      const $form = $(this);
      const platformId = $form.attr('id').replace('form-', '');
      const $submitBtn = $form.find('button[type="submit"]');

      // Validate form
      if (!$form[0].checkValidity()) {
        $form[0].reportValidity();
        return;
      }

      // Prepare form data
      const formData = new FormData($form[0]);
      formData.append('action', 'checkin_save_platform');
      formData.append('platform', platformId);
      formData.append('nonce', checkinPlatformsAdmin.nonce);

      // Disable submit button
      $submitBtn.prop('disabled', true).text('Đang lưu...');

      // Send AJAX request
      $.ajax({
        url: checkinPlatformsAdmin.ajaxurl,
        type: 'POST',
        data: formData,
        processData: false,
        contentType: false,
        success: function (response) {
          if (response.success) {
            // Update card toggle to ON if not already
            const $cardToggle = $(`.checkin-connection-toggle[data-connection="${platformId}"]`);
            if (!$cardToggle.is(':checked')) {
              $cardToggle.prop('checked', true);
              const $card = $cardToggle.closest('.checkin-connection-card');
              updateCardUI($card, true);
            }

            // Update has-config attribute
            $cardToggle.attr('data-has-config', '1').data('has-config', '1');

            showNotification(response.data.message || 'Cài đặt đã được lưu!', 'success');

            // Close modal after delay
            setTimeout(function () {
              closePlatformModal(platformId);
            }, 1000);
          } else {
            showNotification(response.data.message || 'Có lỗi xảy ra!', 'error');

            // Close modal and disable toggle on error
            setTimeout(function () {
              closePlatformModal(platformId);
              const $cardToggle = $(`.checkin-connection-toggle[data-connection="${platformId}"]`);
              $cardToggle.prop('checked', false);
              const $card = $cardToggle.closest('.checkin-connection-card');
              updateCardUI($card, false);
            }, 1500);
          }
        },
        error: function () {
          showNotification('Không thể kết nối đến server!', 'error');

          // Close modal and disable toggle on network error
          setTimeout(function () {
            closePlatformModal(platformId);
            const $cardToggle = $(`.checkin-connection-toggle[data-connection="${platformId}"]`);
            $cardToggle.prop('checked', false);
            const $card = $cardToggle.closest('.checkin-connection-card');
            updateCardUI($card, false);
          }, 1500);
        },
        complete: function () {
          $submitBtn.prop('disabled', false).text('Lưu cài đặt');
        },
      });
    });

    /**
     * Close modal on backdrop click
     */
    $(document).on('click', '.checkin-modal-backdrop', function (e) {
      if (e.target === this) {
        const modalId = $(this).attr('id');
        if (modalId && modalId.startsWith('modal-')) {
          const platform = modalId.replace('modal-', '');
          closePlatformModal(platform);
        }
      }
    });

    /**
     * Close modal on ESC key
     */
    $(document).on('keydown', function (e) {
      if (e.key === 'Escape') {
        const activeModal = $('.checkin-modal-backdrop.active');
        if (activeModal.length) {
          const modalId = activeModal.attr('id');
          if (modalId && modalId.startsWith('modal-')) {
            const platform = modalId.replace('modal-', '');
            closePlatformModal(platform);
          }
        }
      }
    });
  });
})(jQuery);
