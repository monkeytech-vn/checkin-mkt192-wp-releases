<?php
/**
 * Admin Notices Partial
 *
 * Display WordPress admin notices in a styled container
 *
 * @package    Checkin_MKT192_WP
 * @subpackage Admin/Partials
 * @since      5.1.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Get settings errors/messages
$settings_errors = get_settings_errors();

if ( ! empty( $settings_errors ) ) :
	?>
<div class="checkin-admin-notices">
    <?php foreach ( $settings_errors as $error ) : ?>
    <?php
		$notice_type = 'info';
		if ( $error['type'] === 'error' ) {
			$notice_type = 'danger';
		} elseif ( $error['type'] === 'updated' || $error['type'] === 'success' ) {
			$notice_type = 'success';
		} elseif ( $error['type'] === 'warning' ) {
			$notice_type = 'warning';
		}

		$icon = '✓';
		if ( $notice_type === 'danger' ) {
			$icon = '✗';
		} elseif ( $notice_type === 'warning' ) {
			$icon = '⚠';
		} elseif ( $notice_type === 'info' ) {
			$icon = 'ℹ';
		}
		?>
    <div class="checkin-alert checkin-alert-<?php echo esc_attr( $notice_type ); ?> checkin-alert-dismissible">
        <span class="checkin-alert-icon"><?php echo $icon; ?></span>
        <div class="checkin-alert-content">
            <div class="checkin-alert-message">
                <?php echo wp_kses_post( $error['message'] ); ?>
            </div>
        </div>
        <button type="button" class="checkin-alert-close" onclick="this.parentElement.remove()">
            <span class="dashicons dashicons-no-alt"></span>
        </button>
    </div>
    <?php endforeach; ?>
</div>
<?php
	// Clear settings errors after displaying
	global $wp_settings_errors;
	$wp_settings_errors = [];
endif;
?>