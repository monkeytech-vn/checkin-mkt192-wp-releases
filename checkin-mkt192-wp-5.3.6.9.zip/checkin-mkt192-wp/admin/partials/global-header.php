<?php
/**
 * Global Admin Header
 * Logo + Navigation Tabs for all admin pages
 *
 * @package    Checkin_MKT192_WP
 * @subpackage Admin/Partials
 * @since      5.1.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

$current_page = isset($_GET['page']) ? sanitize_text_field($_GET['page']) : '';

// Define navigation items
$nav_items = [
    'checkin-mkt192-dashboard' => [
        'title' => __('Dashboard', 'checkin-mkt192'),
        'icon'  => 'dashicons-dashboard',
    ],
    'checkin-mkt192-brand-settings' => [
        'title' => __('Brand Settings', 'checkin-mkt192'),
        'icon'  => 'dashicons-art',
    ],
    'checkin-mkt192-connections' => [
        'title' => __('Connections', 'checkin-mkt192'),
        'icon'  => 'dashicons-networking',
    ],
    'checkin-mkt192-push-notifications' => [
        'title' => __('Push Notifications', 'checkin-mkt192'),
        'icon'  => 'dashicons-megaphone',
    ],
    'checkin-mkt192-payments' => [
        'title' => __('Payments', 'checkin-mkt192'),
        'icon'  => 'dashicons-money-alt',
    ],
    'checkin-mkt192-platforms' => [
        'title' => __('Platforms', 'checkin-mkt192'),
        'icon'  => 'dashicons-admin-plugins',
    ],
    'checkin-mkt192-shortcodes' => [
        'title' => __('Shortcodes', 'checkin-mkt192'),
        'icon'  => 'dashicons-editor-code',
    ],
    'checkin-mkt192-tools' => [
        'title' => __('Tools', 'checkin-mkt192'),
        'icon'  => 'dashicons-admin-tools',
    ],
    'checkin-mkt192-license' => [
        'title' => __('License', 'checkin-mkt192'),
        'icon'  => 'dashicons-admin-network',
    ],
];
?>

<div class="checkin-global-header">
    <div class="checkin-global-header-brand">
        <div class="checkin-brand-logo">
            <span class="dashicons dashicons-yes-alt"></span>
        </div>
        <div class="checkin-brand-info">
            <h1 class="checkin-brand-name">Checkin MKT 192</h1>
            <p class="checkin-brand-version">v<?php echo CHECKIN_MKT192_WP_VERSION; ?></p>
        </div>
    </div>

    <nav class="checkin-global-nav">
        <?php foreach ($nav_items as $page => $item) : ?>
        <a href="<?php echo admin_url('admin.php?page=' . $page); ?>"
            class="checkin-nav-item <?php echo $current_page === $page ? 'active' : ''; ?>">
            <span class="checkin-nav-icon dashicons <?php echo esc_attr($item['icon']); ?>"></span>
            <span class="checkin-nav-label"><?php echo esc_html($item['title']); ?></span>
        </a>
        <?php endforeach; ?>
    </nav>
</div>
