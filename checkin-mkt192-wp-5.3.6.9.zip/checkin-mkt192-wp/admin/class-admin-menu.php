<?php

/**
 * Admin Menu
 *
 * Handles WordPress admin menu registration and page routing
 *
 * @package    Checkin_MKT192_WP
 * @subpackage Admin
 * @since      5.1.0
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Checkin_MKT192_WP_Admin_Menu
 */
class Checkin_MKT192_WP_Admin_Menu {

	/**
	 * Singleton instance
	 */
	private static $instance = null;

	/**
	 * Get singleton instance
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor
	 */
	private function __construct() {
		add_action( 'admin_menu', [ $this, 'register_admin_menu' ] );

		// Initialize page classes early to register AJAX handlers
		add_action( 'admin_init', [ $this, 'init_page_classes' ] );
	}

	/**
	 * Initialize page classes to register AJAX handlers
	 */
	public function init_page_classes() {
		// Initialize Tools page early for AJAX handlers
		Checkin_MKT192_WP_Tools_Page::get_instance();

		// Initialize Connections page early for AJAX handlers
		new Checkin_MKT192_WP_Connections_Page();

		// Initialize Brand Settings page early for AJAX handlers
		new Checkin_MKT192_WP_Brand_Settings_Page();

		// Initialize Payments page early for AJAX handlers
		Checkin_MKT192_WP_Payments_Page::get_instance();

		// Initialize Push Notifications page early for AJAX handlers
		Checkin_MKT192_WP_Push_Notifications_Page::get_instance();
	}

	/**
	 * Register admin menu
	 */
	public function register_admin_menu() {
		// Main menu
		add_menu_page(
			__( 'Checkin MKT 192', 'checkin-mkt192-wp' ),
			__( 'Checkin MKT 192', 'checkin-mkt192-wp' ),
			'manage_options',
			'checkin-mkt192-dashboard',
			[ $this, 'render_dashboard_page' ],
			'dashicons-yes-alt',
			30
		);

		// Dashboard submenu
		add_submenu_page(
			'checkin-mkt192-dashboard',
			__( 'Dashboard', 'checkin-mkt192-wp' ),
			__( 'Dashboard', 'checkin-mkt192-wp' ),
			'manage_options',
			'checkin-mkt192-dashboard',
			[ $this, 'render_dashboard_page' ]
		);

		// Brand Settings
		add_submenu_page(
			'checkin-mkt192-dashboard',
			__( 'Brand Settings', 'checkin-mkt192-wp' ),
			__( 'Brand Settings', 'checkin-mkt192-wp' ),
			'manage_options',
			'checkin-mkt192-brand-settings',
			[ $this, 'render_brand_settings_page' ]
		);

		// Connections
		add_submenu_page(
			'checkin-mkt192-dashboard',
			__( 'Connections', 'checkin-mkt192-wp' ),
			__( 'Connections', 'checkin-mkt192-wp' ),
			'manage_options',
			'checkin-mkt192-connections',
			[ $this, 'render_connections_page' ]
		);

		// Push Notifications
		add_submenu_page(
			'checkin-mkt192-dashboard',
			__( 'Push Notifications', 'checkin-mkt192-wp' ),
			__( 'Push Notifications', 'checkin-mkt192-wp' ),
			'manage_options',
			'checkin-mkt192-push-notifications',
			[ $this, 'render_push_notifications_page' ]
		);

		// Payments
		add_submenu_page(
			'checkin-mkt192-dashboard',
			__( 'Payments', 'checkin-mkt192-wp' ),
			__( 'Payments', 'checkin-mkt192-wp' ),
			'manage_options',
			'checkin-mkt192-payments',
			[ $this, 'render_payments_page' ]
		);

		// Platforms
		add_submenu_page(
			'checkin-mkt192-dashboard',
			__( 'Platforms', 'checkin-mkt192-wp' ),
			__( 'Platforms', 'checkin-mkt192-wp' ),
			'manage_options',
			'checkin-mkt192-platforms',
			[ $this, 'render_platforms_page' ]
		);

		// Shortcodes
		add_submenu_page(
			'checkin-mkt192-dashboard',
			__( 'Shortcodes', 'checkin-mkt192-wp' ),
			__( 'Shortcodes', 'checkin-mkt192-wp' ),
			'manage_options',
			'checkin-mkt192-shortcodes',
			[ $this, 'render_shortcodes_page' ]
		);

		// Tools
		add_submenu_page(
			'checkin-mkt192-dashboard',
			__( 'Tools', 'checkin-mkt192-wp' ),
			__( 'Tools', 'checkin-mkt192-wp' ),
			'manage_options',
			'checkin-mkt192-tools',
			[ $this, 'render_tools_page' ]
		);

		// License
		add_submenu_page(
			'checkin-mkt192-dashboard',
			__( 'License', 'checkin-mkt192-wp' ),
			__( 'License', 'checkin-mkt192-wp' ),
			'manage_options',
			'checkin-mkt192-license',
			[ $this, 'render_license_page' ]
		);
	}

	/**
	 * Render Dashboard page
	 */
	public function render_dashboard_page() {
		$page = Checkin_MKT192_WP_Dashboard_Page::get_instance();
		$page->render();
	}

	/**
	 * Render Brand Settings page
	 */
	public function render_brand_settings_page() {
		$page = new Checkin_MKT192_WP_Brand_Settings_Page();
		$page->render();
	}

	/**
	 * Render Connections page
	 */
	public function render_connections_page() {
		$page = new Checkin_MKT192_WP_Connections_Page();
		$page->render();
	}

	/**
	 * Render Payments page
	 */
	public function render_payments_page() {
		$page = Checkin_MKT192_WP_Payments_Page::get_instance();
		$page->render();
	}

	/**
	 * Render Platforms page
	 */
	public function render_platforms_page() {
		$page = Checkin_MKT192_WP_Platforms_Page::get_instance();
		$page->render();
	}

	/**
	 * Render Shortcodes page
	 */
	public function render_shortcodes_page() {
		$page = Checkin_MKT192_WP_Shortcodes_Page::get_instance();
		$page->render();
	}

	/**
	 * Render Tools page
	 */
	public function render_tools_page() {
		$page = Checkin_MKT192_WP_Tools_Page::get_instance();
		$page->render();
	}

	/**
	 * Render License page
	 */
	public function render_license_page() {
		$page = Checkin_MKT192_WP_License_Page::get_instance();
		$page->render();
	}

	/**
	 * Render Push Notifications page
	 */
	public function render_push_notifications_page() {
		$page = Checkin_MKT192_WP_Push_Notifications_Page::get_instance();
		$page->render();
	}
}

// Initialize
Checkin_MKT192_WP_Admin_Menu::get_instance();
