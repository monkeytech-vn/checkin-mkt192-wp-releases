<?php
/**
 * Platforms Page
 *
 * Quản lý tích hợp với các nền tảng khác nhau
 *
 * @package    Checkin_MKT192_WP
 * @subpackage Admin/Pages
 * @since      5.1.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Checkin_MKT192_WP_Platforms_Page
 */
class Checkin_MKT192_WP_Platforms_Page {

    /**
     * Option name
     */
    const OPTION_NAME = 'checkin_mkt192_platforms_settings';

    /**
     * Singleton instance
     */
    private static $instance = null;

    /**
     * Get singleton instance
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct() {
        add_action( 'admin_init', [ $this, 'save_settings' ] );
        add_action( 'wp_ajax_checkin_save_platform', [ $this, 'ajax_save_platform' ] );
    }

    /**
     * AJAX handler for saving platform settings
     */
    public function ajax_save_platform() {
        error_log( '=== AJAX Save Platform Called - Handler is working! ===' );
        error_log( 'POST: ' . print_r( $_POST, true ) );

        check_ajax_referer( 'checkin-admin-nonce', 'nonce' );        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( [ 'message' => __( 'Bạn không có quyền thực hiện hành động này!', 'checkin-mkt192-wp' ) ] );
        }

        if ( ! isset( $_POST['platform'] ) ) {
            wp_send_json_error( [ 'message' => __( 'Thiếu thông tin nền tảng!', 'checkin-mkt192-wp' ) ] );
        }

        $platform = sanitize_key( $_POST['platform'] );
        $settings = get_option( self::OPTION_NAME, [] );

        // Handle toggle-only saves (when just enabling/disabling without form data)
        if ( isset( $_POST[ $platform . '_enabled' ] ) && ! isset( $_POST['checkin_review_plugin_shortcode'] ) ) {
            $settings[ $platform . '_enabled' ] = sanitize_key( $_POST[ $platform . '_enabled' ] );
            update_option( self::OPTION_NAME, $settings );
            wp_send_json_success( [ 'message' => __( 'Trạng thái đã được cập nhật!', 'checkin-mkt192-wp' ) ] );
        }

        // Save platform-specific settings
        switch ( $platform ) {
            case 'mailchimp':
                $settings['mailchimp_api_key'] = isset( $_POST['mailchimp_api_key'] ) ? sanitize_text_field( $_POST['mailchimp_api_key'] ) : '';
                $settings['mailchimp_list_id'] = isset( $_POST['mailchimp_list_id'] ) ? sanitize_text_field( $_POST['mailchimp_list_id'] ) : '';
                break;

            case 'zapier':
                $settings['zapier_webhook_url'] = isset( $_POST['zapier_webhook_url'] ) ? esc_url_raw( $_POST['zapier_webhook_url'] ) : '';
                break;

            case 'webhooks':
                $settings['custom_webhook_url']    = isset( $_POST['custom_webhook_url'] ) ? esc_url_raw( $_POST['custom_webhook_url'] ) : '';
                $settings['custom_webhook_secret'] = isset( $_POST['custom_webhook_secret'] ) ? sanitize_text_field( $_POST['custom_webhook_secret'] ) : '';
                break;

            case 'wpsocial_ninja':
                $settings['checkin_review_plugin_shortcode'] = isset( $_POST['checkin_review_plugin_shortcode'] ) ? wp_kses_post( wp_unslash( $_POST['checkin_review_plugin_shortcode'] ) ) : '';
                $settings['wpsocial_ninja_enabled']          = isset( $_POST['wpsocial_ninja_enabled'] ) ? sanitize_key( $_POST['wpsocial_ninja_enabled'] ) : '';
                break;

            default:
                wp_send_json_error( [ 'message' => __( 'Nền tảng không hợp lệ!', 'checkin-mkt192-wp' ) ] );
        }

        update_option( self::OPTION_NAME, $settings );

        wp_send_json_success( [ 'message' => __( 'Cài đặt đã được lưu thành công!', 'checkin-mkt192-wp' ) ] );
    }

    /**
     * Render page content
     */
    public function render() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( __( 'Bạn không có quyền truy cập trang này.', 'checkin-mkt192-wp' ) );
        }
        ?>
<div class="wrap checkin-admin-wrapper">
    <?php include CHECKIN_PLUGIN_DIR . 'admin/partials/global-header.php'; ?>
    <?php include CHECKIN_PLUGIN_DIR . 'admin/partials/admin-notices.php'; ?>
    <div class="checkin-admin-page">
        <?php $this->render_page_header(); ?>
        <?php $this->render_platforms_grid(); ?>
        <?php $this->render_modals(); ?>
    </div>
</div>
<?php
    }

    /**
     * Render modals for platform settings
     */
    private function render_modals() {
        $settings = get_option( self::OPTION_NAME, [] );

        // Mailchimp Modal
        $this->render_mailchimp_modal( $settings );

        // Zapier Modal
        $this->render_zapier_modal( $settings );

        // Webhooks Modal
        $this->render_webhooks_modal( $settings );

        // WooCommerce Modal
        $this->render_woocommerce_modal( $settings );

        // Elementor Modal
        $this->render_elementor_modal( $settings );

        // Contact Form 7 Modal
        $this->render_contact_form_7_modal( $settings );

        // WP Social Ninja Modal
        $this->render_wpsocial_ninja_modal( $settings );
    }

    /**
     * Render Mailchimp modal
     */
    private function render_mailchimp_modal( $settings ) {
        $api_key = isset( $settings['mailchimp_api_key'] ) ? $settings['mailchimp_api_key'] : '';
        $list_id = isset( $settings['mailchimp_list_id'] ) ? $settings['mailchimp_list_id'] : '';
        ?>
<div id="modal-mailchimp" class="checkin-modal-backdrop">
    <div class="checkin-modal">
        <div class="checkin-modal-header">
            <h2 class="checkin-modal-title">
                <span class="dashicons dashicons-email-alt" style="color: #ffe01b;"></span>
                <?php _e( 'Cài đặt Mailchimp', 'checkin-mkt192-wp' ); ?>
            </h2>
            <button type="button" class="checkin-modal-close" onclick="closePlatformModal('mailchimp')">
                <span class="dashicons dashicons-no-alt"></span>
            </button>
        </div>
        <form id="form-mailchimp" class="checkin-platform-form">
            <div class="checkin-modal-body">
                <div class="checkin-form-group">
                    <label class="checkin-form-label required">
                        <?php _e( 'API Key', 'checkin-mkt192-wp' ); ?>
                    </label>
                    <input type="text" name="mailchimp_api_key" value="<?php echo esc_attr( $api_key ); ?>"
                        class="checkin-form-input"
                        placeholder="<?php esc_attr_e( 'Nhập Mailchimp API Key', 'checkin-mkt192-wp' ); ?>" required>
                </div>
                <div class="checkin-form-group">
                    <label class="checkin-form-label required">
                        <?php _e( 'List ID', 'checkin-mkt192-wp' ); ?>
                    </label>
                    <input type="text" name="mailchimp_list_id" value="<?php echo esc_attr( $list_id ); ?>"
                        class="checkin-form-input"
                        placeholder="<?php esc_attr_e( 'Nhập List ID', 'checkin-mkt192-wp' ); ?>" required>
                </div>
            </div>
            <div class="checkin-modal-footer">
                <button type="button" class="checkin-button checkin-button-secondary"
                    onclick="closePlatformModal('mailchimp')">
                    <?php _e( 'Hủy', 'checkin-mkt192-wp' ); ?>
                </button>
                <button type="submit" class="checkin-button checkin-button-primary">
                    <?php _e( 'Lưu cài đặt', 'checkin-mkt192-wp' ); ?>
                </button>
            </div>
        </form>
    </div>
</div>
<?php
    }

    /**
     * Render Zapier modal
     */
    private function render_zapier_modal( $settings ) {
        $webhook_url = isset( $settings['zapier_webhook_url'] ) ? $settings['zapier_webhook_url'] : '';
        ?>
<div id="modal-zapier" class="checkin-modal-backdrop">
    <div class="checkin-modal">
        <div class="checkin-modal-header">
            <h2 class="checkin-modal-title">
                <span class="dashicons dashicons-networking" style="color: #ff4a00;"></span>
                <?php _e( 'Cài đặt Zapier', 'checkin-mkt192-wp' ); ?>
            </h2>
            <button type="button" class="checkin-modal-close" onclick="closePlatformModal('zapier')">
                <span class="dashicons dashicons-no-alt"></span>
            </button>
        </div>
        <form id="form-zapier" class="checkin-platform-form">
            <div class="checkin-modal-body">
                <div class="checkin-form-group">
                    <label class="checkin-form-label required">
                        <?php _e( 'Zapier Webhook URL', 'checkin-mkt192-wp' ); ?>
                    </label>
                    <input type="url" name="zapier_webhook_url" value="<?php echo esc_attr( $webhook_url ); ?>"
                        class="checkin-form-input" placeholder="https://hooks.zapier.com/hooks/catch/..." required>
                </div>
            </div>
            <div class="checkin-modal-footer">
                <button type="button" class="checkin-button checkin-button-secondary"
                    onclick="closePlatformModal('zapier')">
                    <?php _e( 'Hủy', 'checkin-mkt192-wp' ); ?>
                </button>
                <button type="submit" class="checkin-button checkin-button-primary">
                    <?php _e( 'Lưu cài đặt', 'checkin-mkt192-wp' ); ?>
                </button>
            </div>
        </form>
    </div>
</div>
<?php
    }

    /**
     * Render Webhooks modal
     */
    private function render_webhooks_modal( $settings ) {
        $webhook_url    = isset( $settings['custom_webhook_url'] ) ? $settings['custom_webhook_url'] : '';
        $webhook_secret = isset( $settings['custom_webhook_secret'] ) ? $settings['custom_webhook_secret'] : '';
        ?>
<div id="modal-webhooks" class="checkin-modal-backdrop">
    <div class="checkin-modal">
        <div class="checkin-modal-header">
            <h2 class="checkin-modal-title">
                <span class="dashicons dashicons-admin-plugins" style="color: #2271b1;"></span>
                <?php _e( 'Cài đặt Custom Webhooks', 'checkin-mkt192-wp' ); ?>
            </h2>
            <button type="button" class="checkin-modal-close" onclick="closePlatformModal('webhooks')">
                <span class="dashicons dashicons-no-alt"></span>
            </button>
        </div>
        <form id="form-webhooks" class="checkin-platform-form">
            <div class="checkin-modal-body">
                <div class="checkin-form-group">
                    <label class="checkin-form-label required">
                        <?php _e( 'Webhook URL', 'checkin-mkt192-wp' ); ?>
                    </label>
                    <input type="url" name="custom_webhook_url" value="<?php echo esc_attr( $webhook_url ); ?>"
                        class="checkin-form-input" placeholder="https://your-domain.com/webhook" required>
                </div>
                <div class="checkin-form-group">
                    <label class="checkin-form-label">
                        <?php _e( 'Secret Key', 'checkin-mkt192-wp' ); ?>
                    </label>
                    <input type="password" name="custom_webhook_secret"
                        value="<?php echo esc_attr( $webhook_secret ); ?>" class="checkin-form-input"
                        placeholder="<?php esc_attr_e( 'Secret key để xác thực', 'checkin-mkt192-wp' ); ?>">
                </div>
            </div>
            <div class="checkin-modal-footer">
                <button type="button" class="checkin-button checkin-button-secondary"
                    onclick="closePlatformModal('webhooks')">
                    <?php _e( 'Hủy', 'checkin-mkt192-wp' ); ?>
                </button>
                <button type="submit" class="checkin-button checkin-button-primary">
                    <?php _e( 'Lưu cài đặt', 'checkin-mkt192-wp' ); ?>
                </button>
            </div>
        </form>
    </div>
</div>
<?php
    }

    /**
     * Render WooCommerce modal
     */
    private function render_woocommerce_modal( $settings ) {
        ?>
<div id="modal-woocommerce" class="checkin-modal-backdrop">
    <div class="checkin-modal">
        <div class="checkin-modal-header">
            <h2 class="checkin-modal-title">
                <span class="dashicons dashicons-cart" style="color: #96588a;"></span>
                <?php _e( 'Cài đặt WooCommerce', 'checkin-mkt192-wp' ); ?>
            </h2>
            <button type="button" class="checkin-modal-close" onclick="closePlatformModal('woocommerce')">
                <span class="dashicons dashicons-no-alt"></span>
            </button>
        </div>
        <div class="checkin-modal-body">
            <p><?php _e( 'Tích hợp WooCommerce sẽ tự động hoạt động sau khi bật. Không cần cấu hình thêm.', 'checkin-mkt192-wp' ); ?>
            </p>
        </div>
        <div class="checkin-modal-footer">
            <button type="button" class="checkin-button checkin-button-primary"
                onclick="closePlatformModal('woocommerce')">
                <?php _e( 'Đóng', 'checkin-mkt192-wp' ); ?>
            </button>
        </div>
    </div>
</div>
<?php
    }

    /**
     * Render Elementor modal
     */
    private function render_elementor_modal( $settings ) {
        ?>
<div id="modal-elementor" class="checkin-modal-backdrop">
    <div class="checkin-modal">
        <div class="checkin-modal-header">
            <h2 class="checkin-modal-title">
                <span class="dashicons dashicons-editor-table" style="color: #d30c5c;"></span>
                <?php _e( 'Cài đặt Elementor', 'checkin-mkt192-wp' ); ?>
            </h2>
            <button type="button" class="checkin-modal-close" onclick="closePlatformModal('elementor')">
                <span class="dashicons dashicons-no-alt"></span>
            </button>
        </div>
        <div class="checkin-modal-body">
            <p><?php _e( 'Widget Checkin sẽ tự động xuất hiện trong Elementor sau khi bật tích hợp này.', 'checkin-mkt192-wp' ); ?>
            </p>
        </div>
        <div class="checkin-modal-footer">
            <button type="button" class="checkin-button checkin-button-primary"
                onclick="closePlatformModal('elementor')">
                <?php _e( 'Đóng', 'checkin-mkt192-wp' ); ?>
            </button>
        </div>
    </div>
</div>
<?php
    }

    /**
     * Render Contact Form 7 modal
     */
    private function render_contact_form_7_modal( $settings ) {
        ?>
<div id="modal-contact_form_7" class="checkin-modal-backdrop">
    <div class="checkin-modal">
        <div class="checkin-modal-header">
            <h2 class="checkin-modal-title">
                <span class="dashicons dashicons-email" style="color: #0f7c59;"></span>
                <?php _e( 'Cài đặt Contact Form 7', 'checkin-mkt192-wp' ); ?>
            </h2>
            <button type="button" class="checkin-modal-close" onclick="closePlatformModal('contact_form_7')">
                <span class="dashicons dashicons-no-alt"></span>
            </button>
        </div>
        <div class="checkin-modal-body">
            <p><?php _e( 'Tích hợp Contact Form 7 sẽ tự động hoạt động sau khi bật.', 'checkin-mkt192-wp' ); ?>
            </p>
        </div>
        <div class="checkin-modal-footer">
            <button type="button" class="checkin-button checkin-button-primary"
                onclick="closePlatformModal('contact_form_7')">
                <?php _e( 'Đóng', 'checkin-mkt192-wp' ); ?>
            </button>
        </div>
    </div>
</div>
<?php
    }

    /**
     * Render WP Social Ninja modal
     */
    private function render_wpsocial_ninja_modal( $settings ) {
        $shortcode = isset( $settings['checkin_review_plugin_shortcode'] ) ? $settings['checkin_review_plugin_shortcode'] : '';
        $enabled   = isset( $settings['wpsocial_ninja_enabled'] ) && $settings['wpsocial_ninja_enabled'] === 'yes';
        ?>
<div id="modal-wpsocial_ninja" class="checkin-modal-backdrop">
    <div class="checkin-modal">
        <div class="checkin-modal-header">
            <h2 class="checkin-modal-title">
                <span class="dashicons dashicons-star-filled" style="color: #7c3aed;"></span>
                <?php _e( 'Cài đặt WP Social Ninja', 'checkin-mkt192-wp' ); ?>
            </h2>
            <button type="button" class="checkin-modal-close" onclick="closePlatformModal('wpsocial_ninja')">
                <span class="dashicons dashicons-no-alt"></span>
            </button>
        </div>
        <form id="form-wpsocial_ninja" class="checkin-platform-form">
            <div class="checkin-modal-body">
                <div class="checkin-form-group">
                    <label class="checkin-form-label">
                        <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 16px;">
                            <label class="checkin-toggle checkin-toggle-lg">
                                <input type="checkbox" name="wpsocial_ninja_enabled" value="yes"
                                    <?php checked( $enabled, true ); ?>>
                                <span class="checkin-toggle-slider"></span>
                            </label>
                            <span
                                style="font-weight: 500;"><?php _e( 'Bật hiển thị review section', 'checkin-mkt192-wp' ); ?></span>
                        </div>
                    </label>
                </div>
                <div class="checkin-form-group">
                    <label class="checkin-form-label required">
                        <?php _e( 'Review Template Shortcode', 'checkin-mkt192-wp' ); ?>
                    </label>
                    <textarea name="checkin_review_plugin_shortcode" class="checkin-form-input" rows="3"
                        placeholder="<?php esc_attr_e( '[wp_social_ninja id="1921" platform="reviews"]', 'checkin-mkt192-wp' ); ?>"
                        required><?php echo esc_textarea( $shortcode ); ?></textarea>
                    <small style="color: #666; margin-top: 8px; display: block;">
                        <?php _e( 'Nhập shortcode template review từ WP Social Ninja plugin', 'checkin-mkt192-wp' ); ?>
                    </small>
                </div>
            </div>
            <div class="checkin-modal-footer">
                <button type="button" class="checkin-button checkin-button-secondary"
                    onclick="closePlatformModal('wpsocial_ninja')">
                    <?php _e( 'Hủy', 'checkin-mkt192-wp' ); ?>
                </button>
                <button type="submit" class="checkin-button checkin-button-primary">
                    <?php _e( 'Lưu cài đặt', 'checkin-mkt192-wp' ); ?>
                </button>
            </div>
        </form>
    </div>
</div>
<?php
    }

    /**
     * Render page header
     */
    private function render_page_header() {
        ?>
<div class="checkin-page-header">
    <div>
        <h1 class="checkin-page-title">
            <span class="dashicons dashicons-networking"></span>
            <?php _e( 'Cài đặt Tích hợp', 'checkin-mkt192-wp' ); ?>
        </h1>
        <p class="checkin-page-description">
            <?php _e( 'Quản lý tích hợp với các nền tảng và dịch vụ bên ngoài', 'checkin-mkt192-wp' ); ?>
        </p>
    </div>
</div>
<?php
    }

    /**
     * Render platforms grid
     */
    private function render_platforms_grid() {
        $settings  = get_option( self::OPTION_NAME, [] );
        $platforms = [
            'woocommerce' => [
                'title'   => __( 'WooCommerce', 'checkin-mkt192-wp' ),
                'icon'    => 'dashicons-cart',
                'color'   => '#96588a',
                'enabled' => isset( $settings['woocommerce_enabled'] ) && $settings['woocommerce_enabled'] === 'yes',
            ],
            'elementor' => [
                'title'   => __( 'Elementor', 'checkin-mkt192-wp' ),
                'icon'    => 'dashicons-editor-table',
                'color'   => '#d30c5c',
                'enabled' => isset( $settings['elementor_enabled'] ) && $settings['elementor_enabled'] === 'yes',
            ],
            'contact_form_7' => [
                'title'   => __( 'Contact Form 7', 'checkin-mkt192-wp' ),
                'icon'    => 'dashicons-email',
                'color'   => '#0f7c59',
                'enabled' => isset( $settings['contact_form_7_enabled'] ) && $settings['contact_form_7_enabled'] === 'yes',
            ],
            'mailchimp' => [
                'title'   => __( 'Mailchimp', 'checkin-mkt192-wp' ),
                'icon'    => 'dashicons-email-alt',
                'color'   => '#ffe01b',
                'enabled' => isset( $settings['mailchimp_enabled'] ) && $settings['mailchimp_enabled'] === 'yes',
            ],
            'zapier' => [
                'title'   => __( 'Zapier', 'checkin-mkt192-wp' ),
                'icon'    => 'dashicons-networking',
                'color'   => '#ff4a00',
                'enabled' => isset( $settings['zapier_enabled'] ) && $settings['zapier_enabled'] === 'yes',
            ],
            'webhooks' => [
                'title'   => __( 'Custom Webhooks', 'checkin-mkt192-wp' ),
                'icon'    => 'dashicons-admin-plugins',
                'color'   => '#2271b1',
                'enabled' => isset( $settings['webhooks_enabled'] ) && $settings['webhooks_enabled'] === 'yes',
            ],
            'wpsocial_ninja' => [
                'title'   => __( 'WP Social Ninja', 'checkin-mkt192-wp' ),
                'icon'    => 'dashicons-star-filled',
                'color'   => '#7c3aed',
                'enabled' => isset( $settings['wpsocial_ninja_enabled'] ) && $settings['wpsocial_ninja_enabled'] === 'yes',
            ],
        ];
        ?>
<div class="checkin-connections-grid">
    <?php foreach ( $platforms as $key => $platform ) : ?>
    <?php $has_config = $this->has_platform_config( $key, $settings ); ?>
    <div class="checkin-connection-card <?php echo $platform['enabled'] ? 'enabled' : 'disabled'; ?>"
        data-connection="<?php echo esc_attr( $key ); ?>">
        <div class="checkin-connection-header">
            <div class="checkin-connection-icon" style="background: <?php echo esc_attr( $platform['color'] ); ?>">
                <span class="dashicons <?php echo esc_attr( $platform['icon'] ); ?>"></span>
            </div>
            <div class="checkin-connection-info">
                <h3 class="checkin-connection-title">
                    <?php echo esc_html( $platform['title'] ); ?>
                </h3>
                <div class="checkin-connection-status">
                    <?php if ( $platform['enabled'] ) : ?>
                    <span class="checkin-badge checkin-badge-success">
                        <?php _e( 'Đã kết nối', 'checkin-mkt192-wp' ); ?>
                    </span>
                    <?php else : ?>
                    <span class="checkin-badge checkin-badge-gray">
                        <?php _e( 'Chưa kết nối', 'checkin-mkt192-wp' ); ?>
                    </span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="checkin-connection-body">
            <div class="checkin-connection-toggle-wrapper">
                <label class="checkin-toggle checkin-toggle-lg">
                    <input type="checkbox" class="checkin-connection-toggle"
                        data-connection="<?php echo esc_attr( $key ); ?>" <?php if ( $key === 'wpsocial_ninja' ) : ?>
                        data-has-config="<?php echo $has_config ? '1' : '0'; ?>" <?php endif; ?>
                        <?php checked( $platform['enabled'], true ); ?>>
                    <span class="checkin-toggle-slider"></span>
                </label>
                <span class="checkin-toggle-status-text">
                    <?php echo $platform['enabled'] ? __( 'Đang bật', 'checkin-mkt192-wp' ) : __( 'Đang tắt', 'checkin-mkt192-wp' ); ?>
                </span>
            </div>
            <button type="button"
                class="checkin-button checkin-button-secondary checkin-button-sm checkin-button-settings"
                onclick="openPlatformModal('<?php echo esc_js( $key ); ?>')">
                <span class="dashicons dashicons-admin-settings"></span>
                <?php _e( 'Cài đặt', 'checkin-mkt192-wp' ); ?>
            </button>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<?php
    }

    /**
     * Check if platform has configuration
     */
    private function has_platform_config( $platform_id, $settings ) {
        switch ( $platform_id ) {
            case 'mailchimp':
                return ! empty( $settings['mailchimp_api_key'] ) && ! empty( $settings['mailchimp_list_id'] );
            case 'zapier':
                return ! empty( $settings['zapier_webhook_url'] );
            case 'webhooks':
                return ! empty( $settings['custom_webhook_url'] );
            case 'wpsocial_ninja':
                return ! empty( $settings['checkin_review_plugin_shortcode'] );
            case 'woocommerce':
            case 'elementor':
            case 'contact_form_7':
                return $this->check_platform_availability( $platform_id );
            default:
                return false;
        }
    }

    /**
     * Render platform-specific settings
     */
    private function render_platform_settings( $platform_id, $settings ) {
        switch ( $platform_id ) {
            case 'mailchimp':
                $api_key = isset( $settings['mailchimp_api_key'] ) ? $settings['mailchimp_api_key'] : '';
                $list_id = isset( $settings['mailchimp_list_id'] ) ? $settings['mailchimp_list_id'] : '';
                ?>
<div class="checkin-form-group">
    <label class="checkin-form-label"><?php esc_html_e( 'API Key', 'checkin-mkt192-wp' ); ?></label>
    <input type="text" name="mailchimp_api_key" class="checkin-form-control" value="<?php echo esc_attr( $api_key ); ?>"
        placeholder="<?php esc_attr_e( 'Nhập Mailchimp API Key', 'checkin-mkt192-wp' ); ?>">
</div>
<div class="checkin-form-group">
    <label class="checkin-form-label"><?php esc_html_e( 'List ID', 'checkin-mkt192-wp' ); ?></label>
    <input type="text" name="mailchimp_list_id" class="checkin-form-control" value="<?php echo esc_attr( $list_id ); ?>"
        placeholder="<?php esc_attr_e( 'Nhập List ID', 'checkin-mkt192-wp' ); ?>">
</div>
<?php
                break;

            case 'zapier':
                $webhook_url = isset( $settings['zapier_webhook_url'] ) ? $settings['zapier_webhook_url'] : '';
                ?>
<div class="checkin-form-group">
    <label class="checkin-form-label"><?php esc_html_e( 'Zapier Webhook URL', 'checkin-mkt192-wp' ); ?></label>
    <input type="url" name="zapier_webhook_url" class="checkin-form-control"
        value="<?php echo esc_attr( $webhook_url ); ?>" placeholder="https://hooks.zapier.com/hooks/catch/...">
</div>
<?php
                break;

            case 'webhooks':
                $webhook_url    = isset( $settings['custom_webhook_url'] ) ? $settings['custom_webhook_url'] : '';
                $webhook_secret = isset( $settings['custom_webhook_secret'] ) ? $settings['custom_webhook_secret'] : '';
                ?>
<div class="checkin-form-group">
    <label class="checkin-form-label"><?php esc_html_e( 'Webhook URL', 'checkin-mkt192-wp' ); ?></label>
    <input type="url" name="custom_webhook_url" class="checkin-form-control"
        value="<?php echo esc_attr( $webhook_url ); ?>" placeholder="https://your-domain.com/webhook">
</div>
<div class="checkin-form-group">
    <label class="checkin-form-label"><?php esc_html_e( 'Secret Key', 'checkin-mkt192-wp' ); ?></label>
    <input type="password" name="custom_webhook_secret" class="checkin-form-control"
        value="<?php echo esc_attr( $webhook_secret ); ?>"
        placeholder="<?php esc_attr_e( 'Secret key để xác thực', 'checkin-mkt192-wp' ); ?>">
</div>
<?php
                break;

            default:
                ?>
<p class="checkin-form-help">
    <?php esc_html_e( 'Tích hợp này sẽ tự động hoạt động sau khi kích hoạt.', 'checkin-mkt192-wp' ); ?>
</p>
<?php
                break;
        }
    }

    /**
     * Check if platform is available
     */
    private function check_platform_availability( $platform_id ) {
        switch ( $platform_id ) {
            case 'woocommerce':
                return class_exists( 'WooCommerce' );
            case 'elementor':
                return defined( 'ELEMENTOR_VERSION' );
            case 'contact_form_7':
                return class_exists( 'WPCF7' );
            default:
                return true;
        }
    }

    /**
     * Save settings
     */
    public function save_settings() {
        if ( ! isset( $_POST['action'] ) || $_POST['action'] !== 'checkin_save_platforms_settings' ) {
            return;
        }

        if ( ! isset( $_POST['checkin_platforms_nonce'] ) ||
             ! wp_verify_nonce( $_POST['checkin_platforms_nonce'], 'checkin_platforms_settings' ) ) {
            wp_die( __( 'Nonce verification failed', 'checkin-mkt192-wp' ) );
        }

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( __( 'Bạn không có quyền thực hiện hành động này.', 'checkin-mkt192-wp' ) );
        }

        $settings = [];

        // Platform toggles
        $platforms = [ 'woocommerce', 'elementor', 'contact_form_7', 'mailchimp', 'zapier', 'webhooks', 'wpsocial_ninja' ];
        foreach ( $platforms as $platform ) {
            $settings[ $platform . '_enabled' ] = isset( $_POST[ $platform . '_enabled' ] ) ? 'yes' : 'no';
        }

        // Mailchimp settings
        $settings['mailchimp_api_key'] = isset( $_POST['mailchimp_api_key'] ) ? sanitize_text_field( $_POST['mailchimp_api_key'] ) : '';
        $settings['mailchimp_list_id'] = isset( $_POST['mailchimp_list_id'] ) ? sanitize_text_field( $_POST['mailchimp_list_id'] ) : '';

        // Zapier settings
        $settings['zapier_webhook_url'] = isset( $_POST['zapier_webhook_url'] ) ? esc_url_raw( $_POST['zapier_webhook_url'] ) : '';

        // Custom Webhook settings
        $settings['custom_webhook_url']    = isset( $_POST['custom_webhook_url'] ) ? esc_url_raw( $_POST['custom_webhook_url'] ) : '';
        $settings['custom_webhook_secret'] = isset( $_POST['custom_webhook_secret'] ) ? sanitize_text_field( $_POST['custom_webhook_secret'] ) : '';

        // WP Social Ninja settings
        if ( isset( $_POST['checkin_review_plugin_shortcode'] ) ) {
            $shortcode                                   = sanitize_text_field( $_POST['checkin_review_plugin_shortcode'] );
            $settings['checkin_review_plugin_shortcode'] = $shortcode;
        }

        update_option( self::OPTION_NAME, $settings );

        wp_redirect( add_query_arg( [
            'page'             => 'checkin-mkt192-platforms',
            'settings-updated' => 'true'
        ], admin_url( 'admin.php' ) ) );
        exit;
    }
}
?>
