<?php
/**
 * Shortcodes Page
 *
 * Quản lý và hiển thị danh sách shortcodes khả dụng
 *
 * @package    Checkin_MKT192_WP
 * @subpackage Admin/Pages
 * @since      5.1.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Checkin_MKT192_WP_Shortcodes_Page
 */
class Checkin_MKT192_WP_Shortcodes_Page {

	/**
	 * Singleton instance
	 */
	private static $instance = null;

	/**
	 * Get singleton instance
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor
	 */
	private function __construct() {
		// Constructor intentionally left empty
	}

	/**
	 * Render page content
	 */
	public function render() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( __( 'Bạn không có quyền truy cập trang này.', 'checkin-mkt192-wp' ) );
		}
		?>
<div class="wrap checkin-admin-wrapper">
    <?php include CHECKIN_PLUGIN_DIR . 'admin/partials/global-header.php'; ?>
    <?php include CHECKIN_PLUGIN_DIR . 'admin/partials/admin-notices.php'; ?>
    <div class="checkin-admin-page">
        <?php $this->render_page_header(); ?>
        <?php $this->render_shortcodes_grid(); ?>
    </div>
</div>
<?php
	}

	/**
	 * Render page header
	 */
	private function render_page_header() {
		?>
<div class="checkin-page-header">
    <div>
        <h1 class="checkin-page-title">
            <span class="dashicons dashicons-editor-code"></span>
            <?php _e( 'Mã ngắn (Shortcodes)', 'checkin-mkt192-wp' ); ?>
        </h1>
        <p class="checkin-page-description">
            <?php _e( 'Sao chép mã ngắn và dán vào bất kỳ trang hoặc bài viết nào để hiển thị nội dung liên quan.', 'checkin-mkt192-wp' ); ?>
        </p>
    </div>
</div>
<?php
	}

	/**
	 * Render shortcodes grid
	 */
	private function render_shortcodes_grid() {
		$shortcodes = $this->get_shortcodes();
		?>
<div class="checkin-shortcodes-grid">
    <?php foreach ( $shortcodes as $shortcode ) : ?>
    <div class="checkin-shortcode-card">
        <div class="checkin-shortcode-header">
            <div class="checkin-shortcode-icon" style="background: <?php echo esc_attr( $shortcode['color'] ); ?>">
                <span class="dashicons <?php echo esc_attr( $shortcode['icon'] ); ?>"></span>
            </div>
            <div class="checkin-shortcode-info">
                <h3 class="checkin-shortcode-title"><?php echo esc_html( $shortcode['name'] ); ?></h3>
                <p class="checkin-shortcode-description"><?php echo esc_html( $shortcode['description'] ); ?></p>
            </div>
        </div>
        <div class="checkin-shortcode-body">
            <div class="checkin-shortcode-code">
                <code class="checkin-code-display"><?php echo esc_html( $shortcode['code'] ); ?></code>
                <button type="button" class="checkin-btn-copy-shortcode"
                    data-shortcode="<?php echo esc_attr( $shortcode['code'] ); ?>"
                    title="<?php esc_attr_e( 'Sao chép', 'checkin-mkt192-wp' ); ?>">
                    <span class="dashicons dashicons-admin-page"></span>
                </button>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<?php
	}

	/**
	 * Get all available shortcodes
	 *
	 * @return array
	 */
	private function get_shortcodes() {
		return [
			[
				'name'        => __( 'Home', 'checkin-mkt192-wp' ),
				'description' => __( 'Hiển thị trang chủ.', 'checkin-mkt192-wp' ),
				'code'        => '[checkin_mkt192_home]',
				'icon'        => 'dashicons-admin-home',
				'color'       => '#2271b1',
			],
			[
				'name'        => __( 'Admin', 'checkin-mkt192-wp' ),
				'description' => __( 'Hiển thị trang quản trị cho admin.', 'checkin-mkt192-wp' ),
				'code'        => '[checkin_admin_frontend]',
				'icon'        => 'dashicons-admin-users',
				'color'       => '#d63638',
			],
			[
				'name'        => __( 'Điểm Danh', 'checkin-mkt192-wp' ),
				'description' => __( 'Hiển thị trang điểm danh cho người dùng.', 'checkin-mkt192-wp' ),
				'code'        => '[checkin_display]',
				'icon'        => 'dashicons-yes',
				'color'       => '#00a32a',
			],
			[
				'name'        => __( 'App Thợ', 'checkin-mkt192-wp' ),
				'description' => __( 'Hiển thị trang ứng dụng dành cho thợ.', 'checkin-mkt192-wp' ),
				'code'        => '[checkin_app_tho]',
				'icon'        => 'dashicons-hammer',
				'color'       => '#f0b849',
			],
			[
				'name'        => __( 'User Profile', 'checkin-mkt192-wp' ),
				'description' => __( 'Hiển thị trang hồ sơ cá nhân của nhân viên.', 'checkin-mkt192-wp' ),
				'code'        => '[checkin_user_profile]',
				'icon'        => 'dashicons-id',
				'color'       => '#8b5cf6',
			],
			[
				'name'        => __( 'Checkin Dashboard', 'checkin-mkt192-wp' ),
				'description' => __( 'Hiển thị trang dashboard điểm danh.', 'checkin-mkt192-wp' ),
				'code'        => '[checkin_dashboard]',
				'icon'        => 'dashicons-dashboard',
				'color'       => '#3b82f6',
			],
			[
				'name'        => __( 'Customer Review Offline', 'checkin-mkt192-wp' ),
				'description' => __( 'Hiển thị trang khách hàng đánh giá dịch vụ tại Shop.', 'checkin-mkt192-wp' ),
				'code'        => '[checkin_customer_review_offline]',
				'icon'        => 'dashicons-star-filled',
				'color'       => '#ff9800',
			],
			[
				'name'        => __( 'Customer Review Online', 'checkin-mkt192-wp' ),
				'description' => __( 'Hiển thị trang khách hàng đánh giá dịch vụ theo Hoá đơn.', 'checkin-mkt192-wp' ),
				'code'        => '[checkin_customer_review_online]',
				'icon'        => 'dashicons-star-empty',
				'color'       => '#ff5722',
			],
			[
				'name'        => __( 'Customer Member', 'checkin-mkt192-wp' ),
				'description' => __( 'Trang hiển thị mã thành viên và mã booking.', 'checkin-mkt192-wp' ),
				'code'        => '[checkin_customer_member]',
				'icon'        => 'dashicons-groups',
				'color'       => '#9c27b0',
			],
			[
				'name'        => __( 'Customer Registration', 'checkin-mkt192-wp' ),
				'description' => __( 'Trang đăng ký thành viên cho khách hàng.', 'checkin-mkt192-wp' ),
				'code'        => '[checkin_customer_registration]',
				'icon'        => 'dashicons-admin-users',
				'color'       => '#10b981',
			],
			[
				'name'        => __( 'Privacy Policy', 'checkin-mkt192-wp' ),
				'description' => __( 'Trang chính sách bảo mật.', 'checkin-mkt192-wp' ),
				'code'        => '[checkin_policy]',
				'icon'        => 'dashicons-shield',
				'color'       => '#64748b',
			],
			[
				'name'        => __( 'Terms Of Service', 'checkin-mkt192-wp' ),
				'description' => __( 'Trang điều khoản dịch vụ.', 'checkin-mkt192-wp' ),
				'code'        => '[checkin_terms_and_service]',
				'icon'        => 'dashicons-media-document',
				'color'       => '#475569',
			],
		];
	}
}