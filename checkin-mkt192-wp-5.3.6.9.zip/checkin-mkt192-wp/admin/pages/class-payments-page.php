<?php
/**
 * Payments Settings Page
 *
 * Quản lý cấu hình thanh toán cho plugin Checkin MKT192 WP.
 * Bao gồm: Chuyển khoản ngân hàng, Momo, ZaloPay
 *
 * @package    Checkin_MKT192_WP
 * @subpackage Admin/Pages
 * @since      5.1.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Checkin_MKT192_WP_Payments_Page
 *
 * Xử lý hiển thị và lưu cài đặt thanh toán
 */
class Checkin_MKT192_WP_Payments_Page {

    /**
     * Option name để lưu settings
     */
    const OPTION_NAME = 'checkin_mkt192_payments_settings';

    /**
     * Singleton instance
     */
    private static $instance = null;

    /**
     * Tab configurations
     */
    private $tabs = [];

    /**
     * Get singleton instance
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct() {
        $this->setup_tabs();
        add_action( 'wp_ajax_checkin_save_payment', [ $this, 'ajax_save_payment' ] );
        add_action( 'wp_ajax_checkin_delete_payment_info', [ $this, 'ajax_delete_payment_info' ] );
    }

    /**
     * Setup tab configuration
     */
    private function setup_tabs() {
        $this->tabs = [
            'bank' => [
                'label' => __( 'Chuyển khoản ngân hàng', 'checkin-mkt192-wp' ),
                'icon'  => 'dashicons-money-alt',
            ],
            'momo' => [
                'label' => __( 'Momo', 'checkin-mkt192-wp' ),
                'icon'  => 'dashicons-smartphone',
            ],
            'zalopay' => [
                'label' => __( 'ZaloPay', 'checkin-mkt192-wp' ),
                'icon'  => 'dashicons-money',
            ],
        ];
    }

    /**
     * Render page content
     */
    public function render() {
        // Check user capabilities
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( __( 'Bạn không có quyền truy cập trang này.', 'checkin-mkt192-wp' ) );
        }

        // Get saved settings
        $settings = get_option( self::OPTION_NAME, [] );

        ?>
<div class="wrap checkin-admin-wrapper">
    <?php include CHECKIN_PLUGIN_DIR . 'admin/partials/global-header.php'; ?>
    <div class="checkin-admin-page">
        <!-- Page Header -->
        <div class="checkin-page-header">
            <div class="checkin-page-header-content">
                <h1 class="checkin-page-title">
                    <span class="dashicons dashicons-cart"></span>
                    <?php esc_html_e( 'Cài đặt Thanh toán', 'checkin-mkt192-wp' ); ?>
                </h1>
                <p class="checkin-page-description">
                    <?php esc_html_e( 'Cấu hình các phương thức thanh toán cho hệ thống.', 'checkin-mkt192-wp' ); ?>
                </p>
            </div>
        </div>

        <!-- Payment Methods Grid -->
        <?php $this->render_payments_grid( $settings ); ?>

        <!-- Payment Modals -->
        <?php
		$this->render_bank_modal( $settings );
		$this->render_momo_modal( $settings );
		$this->render_zalopay_modal( $settings );
		?>
    </div>
</div>
<?php
    }

	/**
	 * Render payments grid with cards
	 */
	private function render_payments_grid( $settings ) {
		$payments = [
			'bank'     => [
				'title'       => __( 'Chuyển khoản ngân hàng', 'checkin-mkt192-wp' ),
				'description' => __( 'Nhận thanh toán qua chuyển khoản ngân hàng', 'checkin-mkt192-wp' ),
				'icon'        => '💳',
				'color'       => '#10b981',
				'enabled'     => get_option( 'checkin_use_bank_transfer', '0' ) === '1',
			],
			'momo'     => [
				'title'       => __( 'Momo', 'checkin-mkt192-wp' ),
				'description' => __( 'Thanh toán qua ví điện tử Momo', 'checkin-mkt192-wp' ),
				'icon'        => '📱',
				'color'       => '#d91f7a',
				'enabled'     => get_option( 'checkin_use_momo', '0' ) === '1',
			],
			'zalopay'  => [
				'title'       => __( 'ZaloPay', 'checkin-mkt192-wp' ),
				'description' => __( 'Thanh toán qua ví điện tử ZaloPay', 'checkin-mkt192-wp' ),
				'icon'        => '💰',
				'color'       => '#0068ff',
				'enabled'     => get_option( 'checkin_use_zalopay', '0' ) === '1',
			],
		];
		?>
<div class="checkin-payments-grid">
    <?php foreach ( $payments as $payment_id => $payment ) : ?>
    <?php
	$has_config = $this->has_payment_config( $payment_id, $settings );
	$card_state = $has_config ? 'configured' : 'not-configured';
	?>
    <div class="checkin-payment-card <?php echo esc_attr( $card_state ); ?>"
        data-payment="<?php echo esc_attr( $payment_id ); ?>">
        <div class="checkin-payment-header"
            style="border-top-color: <?php echo esc_attr( $payment['color'] ); ?>">
            <div class="checkin-payment-icon"
                style="background: linear-gradient(135deg, <?php echo esc_attr( $payment['color'] ); ?>, <?php echo esc_attr( $payment['color'] ); ?>dd);">
                <span><?php echo $payment['icon']; ?></span>
            </div>
            <div class="checkin-payment-info">
                <h3 class="checkin-payment-title">
                    <?php echo esc_html( $payment['title'] ); ?>
                </h3>
                <p class="checkin-payment-description">
                    <?php echo esc_html( $payment['description'] ); ?>
                </p>
                <span
                    class="checkin-payment-status <?php echo $has_config ? 'configured' : 'not-configured'; ?>">
                    <?php echo $has_config ? __( 'Đã cấu hình', 'checkin-mkt192-wp' ) : __( 'Chưa cấu hình', 'checkin-mkt192-wp' ); ?>
                </span>
            </div>
        </div>
        <div class="checkin-payment-body">
            <div class="checkin-payment-toggle-wrapper">
                <label class="checkin-toggle checkin-toggle-lg">
                    <input type="checkbox" class="checkin-payment-toggle"
                        data-payment="<?php echo esc_attr( $payment_id ); ?>"
                        <?php checked( $payment['enabled'] ); ?>>
                    <span class="checkin-toggle-slider"></span>
                </label>
                <span class="checkin-payment-toggle-text">
                    <?php echo $payment['enabled'] ? __( 'Đang bật', 'checkin-mkt192-wp' ) : __( 'Đang tắt', 'checkin-mkt192-wp' ); ?>
                </span>
            </div>
            <button type="button" class="checkin-btn checkin-btn-secondary checkin-btn-payment-settings"
                data-payment="<?php echo esc_attr( $payment_id ); ?>">
                <span class="dashicons dashicons-admin-generic"></span>
                <?php esc_html_e( 'Cài đặt', 'checkin-mkt192-wp' ); ?>
            </button>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<?php
	}

	/**
	 * Get all branches for multi-branch QR feature
	 *
	 * @return array List of branches
	 */
	private function get_all_branches() {
		global $wpdb;

		$branches = $wpdb->get_results(
			"SELECT id, location_name as branch_name, is_main_branch
			 FROM {$wpdb->prefix}checkin_mkt192_locations
			 ORDER BY is_main_branch DESC, location_name ASC",
			ARRAY_A
		);

		return $branches ?: [];
	}

	/**
	 * Check if payment method has required configuration
	 */
	private function has_payment_config( $payment_id, $settings ) {
		switch ( $payment_id ) {
			case 'bank':
				$auto_mode = get_option( 'checkin_bank_auto_mode', '0' );
				if ( $auto_mode === '1' ) {
					// Auto mode (MonkeyPay): chỉ cần MonkeyPay đã kết nối
					$mp_api_key = get_option( 'monkeypay_api_key', '' );
					return ! empty( $mp_api_key );
				} else {
					$bank_account = get_option( 'checkin_bank_account', '' );
					return ! empty( $bank_account );
				}
			case 'momo':
				$auto_mode = get_option( 'checkin_momo_auto_mode', '0' );
				if ( $auto_mode === '1' ) {
					$partner_code = get_option( 'checkin_momo_partner_code', '' );
					$access_key   = get_option( 'checkin_momo_access_key', '' );
					$secret_key   = get_option( 'checkin_momo_secret_key', '' );
					return ! empty( $partner_code ) && ! empty( $access_key ) && ! empty( $secret_key );
				} else {
					$momo_account = get_option( 'checkin_momo_account', '' );
					return ! empty( $momo_account );
				}
			case 'zalopay':
				$auto_mode = get_option( 'checkin_zalopay_auto_mode', '0' );
				if ( $auto_mode === '1' ) {
					$app_id = get_option( 'checkin_zalopay_app_id', '' );
					$key1   = get_option( 'checkin_zalopay_key1', '' );
					$key2   = get_option( 'checkin_zalopay_key2', '' );
					return ! empty( $app_id ) && ! empty( $key1 ) && ! empty( $key2 );
				} else {
					$zalopay_account = get_option( 'checkin_zalopay_account', '' );
					return ! empty( $zalopay_account );
				}
			default:
				return false;
		}
	}

	/**
	 * Render Bank Transfer modal
	 */
	private function render_bank_modal( $settings ) {
		// Auto mode and manual fields
		$bank_auto_mode      = get_option( 'checkin_bank_auto_mode', '0' );
		$bank_account        = get_option( 'checkin_bank_account', '' );
		$bank_qr_url         = get_option( 'checkin_bank_qr_url', '' );

		// Multi-branch QR settings
		$is_multi_branch     = function_exists( 'checkin_mkt192_is_multi_branch_enabled' ) && checkin_mkt192_is_multi_branch_enabled();
		$bank_qr_per_branch  = get_option( 'checkin_bank_qr_per_branch', '0' );
		$bank_qr_branches    = get_option( 'checkin_bank_qr_branches', [] );
		$all_branches        = $is_multi_branch ? $this->get_all_branches() : [];

		// MBBank automatic mode fields
		require_once plugin_dir_path( dirname( __FILE__ ) ) . '../includes/class-encryption.php';
		$mbbank_service_url    = get_option( 'checkin_mbbank_service_url', 'http://mbbank:3456' );
		$mbbank_api_secret_enc = get_option( 'checkin_mbbank_api_secret', '' );
		$mbbank_api_secret     = ! empty( $mbbank_api_secret_enc ) ? Checkin_Encryption::decrypt( $mbbank_api_secret_enc ) : '';
		$bank_account_number   = get_option( 'checkin_bank_account_number', '' );
		$bank_account_name     = get_option( 'checkin_bank_account_name', '' );
		$monkeypay_note_prefix  = get_option( 'checkin_monkeypay_note_prefix', get_option( 'checkin_mbbank_note_prefix', 'MKT' ) );
		$monkeypay_note_syntax  = get_option( 'checkin_monkeypay_note_syntax', get_option( 'checkin_mbbank_note_syntax', '{invoice_id}' ) );
		$monkeypay_polling      = get_option( 'checkin_monkeypay_polling_interval', get_option( 'checkin_mbbank_polling_interval', '2' ) );

		// MBBank login credentials (encrypted)
		$mbbank_username_enc = get_option( 'checkin_mbbank_username', '' );
		$mbbank_password_enc = get_option( 'checkin_mbbank_password', '' );
		$mbbank_username     = ! empty( $mbbank_username_enc ) ? Checkin_Encryption::decrypt( $mbbank_username_enc ) : '';
		$mbbank_password     = ! empty( $mbbank_password_enc ) ? Checkin_Encryption::decrypt( $mbbank_password_enc ) : '';
		?>
<div class="checkin-modal-backdrop" id="modal-bank" style="display: none;">
    <div class="checkin-modal">
        <div class="checkin-modal-header">
            <h2>
                <span>💳</span>
                <?php esc_html_e( 'Cấu hình Chuyển khoản ngân hàng', 'checkin-mkt192-wp' ); ?>
            </h2>
            <button type="button" class="checkin-modal-close" data-payment="bank">
                <span class="dashicons dashicons-no-alt"></span>
            </button>
        </div>
        <div class="checkin-modal-body">
            <form id="form-bank" class="checkin-payment-form">

                <!-- Auto Mode Toggle -->
                <div class="checkin-form-group">
                    <label class="checkin-form-label">
                        <?php esc_html_e( 'Chế độ thanh toán', 'checkin-mkt192-wp' ); ?>
                    </label>
                    <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 8px;">
                        <label class="checkin-toggle checkin-toggle-lg">
                            <input type="checkbox" id="bank-auto-toggle" name="bank_auto_mode" value="1"
                                <?php checked( $bank_auto_mode, '1' ); ?>>
                            <span class="checkin-toggle-slider"></span>
                        </label>
                        <span class="checkin-payment-mode-text">
                            <?php echo $bank_auto_mode === '1' ? __( 'Thanh toán tự động - Tạo mã Qr thanh toán và xác nhận qua API', 'checkin-mkt192-wp' ) : __( 'Thanh toán thủ công - Dùng hình ảnh mã Qr được tải lên', 'checkin-mkt192-wp' ); ?>
                        </span>
                    </div>
                    <p class="checkin-form-help">
                        <?php esc_html_e( 'Chế độ thủ công: Chỉ hiển thị QR và số tài khoản cho khách hàng. Chế độ tự động: Tích hợp API để xác nhận thanh toán.', 'checkin-mkt192-wp' ); ?>
                    </p>
                </div>

                <div class="checkin-divider"></div>

                <!-- Manual Mode Section -->
                <div id="bank-manual-section"
                    style="<?php echo $bank_auto_mode === '1' ? 'display: none;' : ''; ?>">
                    <h4 class="checkin-section-title">
                        <span class="dashicons dashicons-admin-generic"></span>
                        <?php esc_html_e( 'Thông tin cơ bản', 'checkin-mkt192-wp' ); ?>
                    </h4>

                    <?php if ( $is_multi_branch && ! empty( $all_branches ) ) : ?>
                    <!-- Multi-branch QR Toggle - Always visible -->
                    <div class="checkin-form-group checkin-multi-branch-toggle-wrapper">
                        <label class="checkin-form-label">
                            <?php esc_html_e( 'Chế độ mã QR', 'checkin-mkt192-wp' ); ?>
                        </label>
                        <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 8px;">
                            <label class="checkin-toggle">
                                <input type="checkbox" id="bank-qr-per-branch-toggle" name="bank_qr_per_branch"
                                    value="1"
                                    <?php checked( $bank_qr_per_branch, '1' ); ?>>
                                <span class="checkin-toggle-slider"></span>
                            </label>
                            <span class="checkin-payment-mode-text" id="bank-qr-branch-mode-text">
                                <?php echo $bank_qr_per_branch === '1' ? __( 'Mỗi chi nhánh có mã QR riêng', 'checkin-mkt192-wp' ) : __( 'Dùng chung 1 mã QR cho tất cả chi nhánh', 'checkin-mkt192-wp' ); ?>
                            </span>
                        </div>
                        <p class="checkin-form-help">
                            <?php esc_html_e( 'Bật để cấu hình mã QR chuyển khoản riêng cho từng chi nhánh.', 'checkin-mkt192-wp' ); ?>
                        </p>
                    </div>

                    <div class="checkin-divider"></div>
                    <?php endif; ?>

                    <!-- Single QR Mode: Saved Info Display (if exists) -->
                    <div id="bank-single-qr-section" style="<?php echo ( $is_multi_branch && $bank_qr_per_branch === '1' ) ? 'display: none;' : ''; ?>">
                    <?php if ( ! empty( $bank_account ) || ! empty( $bank_qr_url ) ) : ?>
                    <div class="checkin-saved-info-card">
                        <div class="checkin-saved-info-header">
                            <span class="dashicons dashicons-yes-alt"></span>
                            <strong><?php esc_html_e( 'Thông tin đã lưu', 'checkin-mkt192-wp' ); ?></strong>
                        </div>
                        <div class="checkin-saved-info-body">
                            <?php if ( ! empty( $bank_account ) ) : ?>
                            <div class="checkin-info-row">
                                <span class="checkin-info-label">Số tài khoản:</span>
                                <span
                                    class="checkin-info-value"><?php echo esc_html( $bank_account ); ?></span>
                            </div>
                            <?php endif; ?>
                            <?php if ( ! empty( $bank_qr_url ) ) : ?>
                            <div class="checkin-info-row">
                                <span class="checkin-info-label">Mã QR:</span>
                                <div class="checkin-qr-preview">
                                    <img src="<?php echo esc_url( $bank_qr_url ); ?>"
                                        alt="QR Code" />
                                </div>
                            </div>
                            <div class="checkin-info-row">
                                <span class="checkin-info-label">URL:</span>
                                <span
                                    class="checkin-info-value"><?php echo esc_html( $bank_qr_url ); ?></span>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="checkin-saved-info-actions">
                            <button type="button" class="checkin-btn checkin-btn-sm checkin-btn-secondary"
                                onclick="editPaymentInfo('bank')">
                                <span class="dashicons dashicons-edit"></span>
                                <?php esc_html_e( 'Sửa', 'checkin-mkt192-wp' ); ?>
                            </button>
                            <button type="button" class="checkin-btn checkin-btn-sm checkin-btn-danger"
                                onclick="deletePaymentInfo('bank')">
                                <span class="dashicons dashicons-trash"></span>
                                <?php esc_html_e( 'Xóa', 'checkin-mkt192-wp' ); ?>
                            </button>
                        </div>
                    </div>
                    <?php endif; ?>

                    <div id="bank-manual-form"
                        style="<?php echo ( ! empty( $bank_account ) || ! empty( $bank_qr_url ) ) ? 'display: none;' : ''; ?>">
                        <!-- Account Number -->
                        <div class="checkin-form-group">
                            <label class="checkin-form-label required">
                                <?php esc_html_e( 'Số tài khoản', 'checkin-mkt192-wp' ); ?>
                            </label>
                            <input type="text" name="bank_account" class="checkin-form-control"
                                value="<?php echo esc_attr( $bank_account ); ?>"
                                placeholder="<?php esc_attr_e( 'Ví dụ: 1234567890', 'checkin-mkt192-wp' ); ?>"
                                data-required="true"
                                <?php echo $bank_auto_mode === '0' ? 'required' : ''; ?>>
                        </div>

                        <!-- QR URL (only when single QR mode) -->
                        <div class="checkin-form-group">
                            <label class="checkin-form-label">
                                <?php esc_html_e( 'URL Mã QR', 'checkin-mkt192-wp' ); ?>
                            </label>
                            <div style="display: flex; gap: 8px; margin-bottom: 8px;">
                                <input type="url" id="bank_qr_url" name="bank_qr_url" class="checkin-form-control"
                                    value="<?php echo esc_attr( $bank_qr_url ); ?>"
                                    placeholder="<?php esc_attr_e( 'https://example.com/qr-code.png', 'checkin-mkt192-wp' ); ?>">
                                <button type="button" class="checkin-btn checkin-btn-secondary"
                                    onclick="openMediaUploader('bank_qr_url', 'bank')">
                                    <span class="dashicons dashicons-upload"></span>
                                    <?php esc_html_e( 'Tải lên', 'checkin-mkt192-wp' ); ?>
                                </button>
                            </div>
                            <?php if ( ! empty( $bank_qr_url ) ) : ?>
                            <div class="checkin-qr-preview" id="bank_qr_preview" style="margin-bottom: 8px;">
                                <img src="<?php echo esc_url( $bank_qr_url ); ?>" alt="QR Preview"
                                    style="max-width: 200px; border-radius: 4px; border: 1px solid #ddd;">
                            </div>
                            <?php endif; ?>
                            <p class="checkin-form-help">
                                <?php esc_html_e( 'Nhập URL hình ảnh mã QR hoặc tải lên hình ảnh QR', 'checkin-mkt192-wp' ); ?>
                            </p>
                        </div>
                    </div>
                    </div><!-- End #bank-single-qr-section -->

                    <?php if ( $is_multi_branch && ! empty( $all_branches ) ) : ?>
                    <!-- Multi-branch QR Section -->
                    <div id="bank-multi-qr-section"
                        style="<?php echo $bank_qr_per_branch === '1' ? '' : 'display: none;'; ?>">
                        <div class="checkin-branch-qr-list">
                                <?php foreach ( $all_branches as $branch ) :
                                    $branch_id   = $branch['id'];
                                    $branch_name = $branch['branch_name'];
                                    $branch_qr   = isset( $bank_qr_branches[ $branch_id ] ) ? $bank_qr_branches[ $branch_id ] : '';
                                ?>
                                <div class="checkin-branch-qr-item"
                                    data-branch-id="<?php echo esc_attr( $branch_id ); ?>">
                                    <div class="checkin-branch-qr-header">
                                        <span class="checkin-branch-qr-name">
                                            <span class="dashicons dashicons-location"></span>
                                            <?php echo esc_html( $branch_name ); ?>
                                            <?php if ( ! empty( $branch['is_main_branch'] ) ) : ?>
                                            <span
                                                class="checkin-badge checkin-badge-primary"><?php esc_html_e( 'Chính', 'checkin-mkt192-wp' ); ?></span>
                                            <?php endif; ?>
                                        </span>
                                    </div>
                                    <div class="checkin-branch-qr-body">
                                        <div style="display: flex; gap: 8px; margin-bottom: 8px;">
                                            <input type="url"
                                                id="bank_qr_branch_<?php echo esc_attr( $branch_id ); ?>"
                                                name="bank_qr_branches[<?php echo esc_attr( $branch_id ); ?>]"
                                                class="checkin-form-control"
                                                value="<?php echo esc_attr( $branch_qr ); ?>"
                                                placeholder="<?php esc_attr_e( 'URL mã QR cho chi nhánh này', 'checkin-mkt192-wp' ); ?>">
                                            <button type="button"
                                                class="checkin-btn checkin-btn-secondary checkin-btn-sm"
                                                onclick="openMediaUploader('bank_qr_branch_<?php echo esc_attr( $branch_id ); ?>', 'bank')">
                                                <span class="dashicons dashicons-upload"></span>
                                            </button>
                                        </div>
                                        <?php if ( ! empty( $branch_qr ) ) : ?>
                                        <div class="checkin-qr-preview"
                                            id="bank_qr_branch_<?php echo esc_attr( $branch_id ); ?>_preview">
                                            <img src="<?php echo esc_url( $branch_qr ); ?>"
                                                alt="QR Preview"
                                                style="max-width: 150px; border-radius: 4px; border: 1px solid #ddd;">
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div><!-- End #bank-manual-section -->

                <!-- Automatic Mode Section (MonkeyPay API) -->
                <div id="bank-auto-section"
                    style="<?php echo $bank_auto_mode === '1' ? '' : 'display: none;'; ?>">

                    <!-- auto_amount config is now managed via MonkeyPay Gateway UI -->

                    <!-- MonkeyPay Connection -->
                    <h4 class="checkin-section-title">
                        <span class="dashicons dashicons-cloud"></span>
                        <?php esc_html_e( 'Kết nối MonkeyPay', 'checkin-mkt192-wp' ); ?>
                    </h4>

                    <?php
                    $mp_connected  = ! empty( get_option( 'monkeypay_api_key', '' ) );
                    $mp_name       = get_option( 'monkeypay_merchant_name', '' );
                    $mp_email      = get_option( 'monkeypay_merchant_email', '' );
                    $mp_api_key_display = get_option( 'monkeypay_api_key', '' );
                    ?>

                    <!-- Connected State -->
                    <div id="monkeypay-connected" style="<?php echo $mp_connected ? '' : 'display: none;'; ?>">
                        <div style="background: #f0fdf4; border: 1px solid #86efac; border-radius: 8px; padding: 16px; margin-bottom: 16px;">
                            <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 12px;">
                                <span class="dashicons dashicons-yes-alt" style="color: #16a34a; font-size: 20px;"></span>
                                <strong style="color: #15803d; font-size: 14px;"><?php esc_html_e( 'Đã kết nối', 'checkin-mkt192-wp' ); ?></strong>
                            </div>
                            <table style="width: 100%; font-size: 13px; line-height: 1.8;">
                                <tr>
                                    <td style="color: #6b7280; width: 120px;"><?php esc_html_e( 'Tổ chức:', 'checkin-mkt192-wp' ); ?></td>
                                    <td><strong id="mp-org-name"><?php echo esc_html( $mp_name ); ?></strong></td>
                                </tr>
                                <tr>
                                    <td style="color: #6b7280;"><?php esc_html_e( 'Email:', 'checkin-mkt192-wp' ); ?></td>
                                    <td id="mp-org-email"><?php echo esc_html( $mp_email ); ?></td>
                                </tr>
                                <tr>
                                    <td style="color: #6b7280;"><?php esc_html_e( 'API Key:', 'checkin-mkt192-wp' ); ?></td>
                                    <td><code id="mp-org-apikey" style="font-size: 11px; word-break: break-all;"><?php echo esc_html( $mp_api_key_display ); ?></code></td>
                                </tr>
                            </table>
                            <div style="margin-top: 12px; display: flex; gap: 8px;">
                                <button type="button" id="mbbank-test-connection" class="checkin-btn checkin-btn-secondary" style="font-size: 12px;">
                                    <span class="dashicons dashicons-admin-plugins"></span>
                                    <?php esc_html_e( 'Kiểm tra kết nối', 'checkin-mkt192-wp' ); ?>
                                </button>
                                <button type="button" id="monkeypay-disconnect-btn" class="checkin-btn" style="font-size: 12px; background: #fee2e2; color: #991b1b; border: 1px solid #fca5a5;">
                                    <span class="dashicons dashicons-dismiss"></span>
                                    <?php esc_html_e( 'Ngắt kết nối', 'checkin-mkt192-wp' ); ?>
                                </button>
                                <span id="mbbank-connection-status" style="margin-left: 6px; line-height: 32px;"></span>
                            </div>
                        </div>
                    </div>

                    <!-- Not Connected State: Direct to MonkeyPay Plugin -->
                    <div id="monkeypay-auth" style="<?php echo $mp_connected ? 'display: none;' : ''; ?>">
                        <div style="background: #eff6ff; border: 1px solid #93c5fd; border-radius: 8px; padding: 16px; margin-bottom: 16px;">
                            <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 8px;">
                                <span class="dashicons dashicons-info-outline" style="color: #2563eb; font-size: 18px;"></span>
                                <strong style="color: #1e40af; font-size: 14px;"><?php esc_html_e( 'Chưa kết nối MonkeyPay', 'checkin-mkt192-wp' ); ?></strong>
                            </div>
                            <p style="color: #1e3a5f; font-size: 13px; margin: 0 0 12px 0;">
                                <?php esc_html_e( 'Vui lòng đăng ký / đăng nhập và cấu hình cổng thanh toán trong plugin MonkeyPay.', 'checkin-mkt192-wp' ); ?>
                            </p>
                            <?php
                            $mp_settings_url = admin_url( 'admin.php?page=monkeypay' );
                            ?>
                            <a href="<?php echo esc_url( $mp_settings_url ); ?>" class="checkin-btn checkin-btn-primary" style="display: inline-flex; align-items: center; gap: 6px; text-decoration: none;">
                                <span class="dashicons dashicons-admin-plugins"></span>
                                <?php esc_html_e( 'Mở MonkeyPay Settings', 'checkin-mkt192-wp' ); ?>
                            </a>
                        </div>
                    </div>

                    <!-- Hidden field to persist API key in form -->
                    <input type="hidden" name="monkeypay_api_key" id="monkeypay-api-key" value="<?php echo esc_attr( get_option( 'monkeypay_api_key', '' ) ); ?>">

                    <!-- Payment Gateways (dynamic from MonkeyPay) -->
                    <h4 class="checkin-section-title" style="margin-top: 20px;">
                        <span class="dashicons dashicons-bank"></span>
                        <?php esc_html_e( 'Cổng thanh toán', 'checkin-mkt192-wp' ); ?>
                    </h4>

                    <div id="checkin-gateway-pills" class="checkin-gateway-pills" style="margin-bottom: 16px;">
                        <p class="checkin-form-help" id="checkin-gateway-loading">
                            <span class="dashicons dashicons-update spin"></span>
                            <?php esc_html_e( 'Đang tải cổng thanh toán...', 'checkin-mkt192-wp' ); ?>
                        </p>
                    </div>

                    <input type="hidden" name="selected_gateway_id" id="selected-gateway-id" value="<?php echo esc_attr( get_option( 'checkin_selected_gateway_id', '' ) ); ?>" />
                    <input type="hidden" name="bank_bin" id="selected-bank-bin" value="<?php echo esc_attr( get_option( 'checkin_bank_bin', '970422' ) ); ?>" />

                    <!-- Bank Account Info (auto-populated from selected gateway) -->
                    <div id="checkin-gateway-info" style="display: none;">
                        <div class="checkin-form-group">
                            <label class="checkin-form-label">
                                <?php esc_html_e( 'Số tài khoản', 'checkin-mkt192-wp' ); ?>
                            </label>
                            <input type="text" name="bank_account_number" id="mbbank-account-number" class="checkin-form-control"
                                value="<?php echo esc_attr( $bank_account_number ); ?>"
                                placeholder="<?php esc_attr_e( 'Ví dụ: 1234567890', 'checkin-mkt192-wp' ); ?>"
                                readonly>
                        </div>

                        <div class="checkin-form-group">
                            <label class="checkin-form-label">
                                <?php esc_html_e( 'Tên chủ tài khoản', 'checkin-mkt192-wp' ); ?>
                            </label>
                            <input type="text" name="bank_account_name" id="mbbank-account-name" class="checkin-form-control"
                                value="<?php echo esc_attr( $bank_account_name ); ?>"
                                placeholder="<?php esc_attr_e( 'Ví dụ: NGUYEN VAN A', 'checkin-mkt192-wp' ); ?>"
                                readonly>
                        </div>

                        <!-- VietQR Preview -->
                        <div class="checkin-form-group">
                            <label class="checkin-form-label">
                                <?php esc_html_e( 'Preview QR VietQR', 'checkin-mkt192-wp' ); ?>
                            </label>
                            <div id="mbbank-vietqr-preview" style="margin-top: 8px;">
                                <?php if ( ! empty( $bank_account_number ) ) : ?>
                                <img src="https://img.vietqr.io/image/970422-<?php echo esc_attr( $bank_account_number ); ?>-compact2.png?accountName=<?php echo urlencode( $bank_account_name ); ?>"
                                    alt="VietQR Preview" style="max-width: 250px; border-radius: 8px; border: 1px solid #ddd;">
                                <?php else : ?>
                                <p class="checkin-form-help"><?php esc_html_e( 'Chọn cổng thanh toán để xem preview QR', 'checkin-mkt192-wp' ); ?></p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <!-- Gateway Status Check -->

                    <?php
                    // ── Server-side session/gateway check via MonkeyPay API ──
                    $mp_api_key = get_option( 'monkeypay_api_key', '' );
                    $mp_api_url = function_exists( 'checkin_mkt192_get_monkeypay_url' ) ? checkin_mkt192_get_monkeypay_url() : '';
                    $session_icon    = 'dashicons-warning';
                    $session_bg      = '#fffbeb';
                    $session_border  = '#f59e0b';
                    $session_color   = '#92400e';
                    $session_message = __( 'Chưa cấu hình API Key MonkeyPay.', 'checkin-mkt192-wp' );

                    if ( ! empty( $mp_api_key ) && ! empty( $mp_api_url ) ) {
                        $gw_response = wp_remote_get(
                            rtrim( $mp_api_url, '/' ) . '/api/gateways',
                            [
                                'timeout' => 5,
                                'headers' => [
                                    'X-Api-Key' => $mp_api_key,
                                ],
                            ]
                        );

                        if ( is_wp_error( $gw_response ) ) {
                            $session_icon    = 'dashicons-no';
                            $session_bg      = '#fef2f2';
                            $session_border  = '#ef4444';
                            $session_color   = '#991b1b';
                            $session_message = __( 'Không thể kết nối MonkeyPay Server.', 'checkin-mkt192-wp' );
                        } else {
                            $gw_data = json_decode( wp_remote_retrieve_body( $gw_response ), true );
                            if ( ! empty( $gw_data['gateways'] ) ) {
                                $gw = $gw_data['gateways'][0];
                                $session_icon    = 'dashicons-yes-alt';
                                $session_bg      = '#f0fdf4';
                                $session_border  = '#22c55e';
                                $session_color   = '#166534';
                                $session_message = sprintf(
                                    /* translators: %s: bank name */
                                    __( 'Cổng thanh toán %s đã được cấu hình.', 'checkin-mkt192-wp' ),
                                    esc_html( $gw['bank_name'] ?? 'MB Bank' )
                                );
                            } else {
                                $session_icon    = 'dashicons-warning';
                                $session_bg      = '#fffbeb';
                                $session_border  = '#f59e0b';
                                $session_color   = '#92400e';
                                $session_message = __( 'Chưa có cổng thanh toán nào được cấu hình trên MonkeyPay.', 'checkin-mkt192-wp' );
                            }
                        }
                    }
                    ?>
                    <div id="mp-session-status" class="checkin-notice" style="margin-bottom: 12px; padding: 10px 14px; border-radius: 6px; font-size: 13px; background: <?php echo esc_attr( $session_bg ); ?>; border: 1px solid <?php echo esc_attr( $session_border ); ?>; color: <?php echo esc_attr( $session_color ); ?>;">
                        <span class="dashicons <?php echo esc_attr( $session_icon ); ?>" style="font-size: 16px; width: 16px; height: 16px; margin-right: 4px;"></span>
                        <?php echo esc_html( $session_message ); ?>
                    </div>
                    <!-- Payment Config (read-only — managed via MonkeyPay Gateway) -->
                    <h4 class="checkin-section-title" style="margin-top: 20px;">
                        <span class="dashicons dashicons-admin-settings"></span>
                        <?php esc_html_e( 'Cấu hình thanh toán', 'checkin-mkt192-wp' ); ?>
                    </h4>

                    <?php $auto_amount_value = get_option( 'checkin_bank_auto_amount', '1' ); ?>
                    <div class="checkin-form-group">
                        <label class="checkin-form-label" style="color: #6b7280;">
                            <?php esc_html_e( 'Fill tiền tự động', 'checkin-mkt192-wp' ); ?>
                        </label>
                        <div style="padding: 8px 12px; background: #f9fafb; border: 1px solid #e5e7eb; border-radius: 6px; color: #374151; display: flex; align-items: center; gap: 8px;">
                            <?php if ( $auto_amount_value === '1' || $auto_amount_value === 1 ) : ?>
                                <span style="color: #16a34a;">●</span> <?php esc_html_e( 'Bật — QR có sẵn số tiền', 'checkin-mkt192-wp' ); ?>
                            <?php else : ?>
                                <span style="color: #9ca3af;">●</span> <?php esc_html_e( 'Tắt — Khách tự nhập số tiền', 'checkin-mkt192-wp' ); ?>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Payment Note Config (read-only — managed via MonkeyPay Gateway) -->
                    <h4 class="checkin-section-title" style="margin-top: 20px;">
                        <span class="dashicons dashicons-editor-code"></span>
                        <?php esc_html_e( 'Cú pháp ghi chú chuyển khoản', 'checkin-mkt192-wp' ); ?>
                    </h4>

                    <div style="background: #eff6ff; border: 1px solid #93c5fd; border-radius: 8px; padding: 12px 14px; margin-bottom: 12px; font-size: 13px; color: #1e40af;">
                        <span class="dashicons dashicons-info-outline" style="font-size: 16px; width: 16px; height: 16px; margin-right: 4px;"></span>
                        <?php
                        printf(
                            esc_html__( 'Cấu hình ghi chú và polling giờ được quản lý trong %s.', 'checkin-mkt192-wp' ),
                            '<a href="' . esc_url( admin_url( 'admin.php?page=monkeypay' ) ) . '" style="color: #1e40af; font-weight: 600;">' . esc_html__( 'MonkeyPay → Cổng thanh toán', 'checkin-mkt192-wp' ) . '</a>'
                        );
                        ?>
                    </div>

                    <div class="checkin-form-group">
                        <label class="checkin-form-label" style="color: #6b7280;">
                            <?php esc_html_e( 'Tiền tố hiện tại', 'checkin-mkt192-wp' ); ?>
                        </label>
                        <div style="padding: 8px 12px; background: #f9fafb; border: 1px solid #e5e7eb; border-radius: 6px; font-family: monospace; color: #374151;">
                            <?php echo esc_html( $monkeypay_note_prefix ); ?>
                        </div>
                    </div>

                    <div class="checkin-form-group">
                        <label class="checkin-form-label" style="color: #6b7280;">
                            <?php esc_html_e( 'Cú pháp hiện tại', 'checkin-mkt192-wp' ); ?>
                        </label>
                        <div style="padding: 8px 12px; background: #f9fafb; border: 1px solid #e5e7eb; border-radius: 6px; font-family: monospace; color: #374151;">
                            <?php echo esc_html( $monkeypay_note_prefix . $monkeypay_note_syntax ); ?>
                        </div>
                    </div>

                    <div class="checkin-form-group">
                        <label class="checkin-form-label" style="color: #6b7280;">
                            <?php esc_html_e( 'Polling interval', 'checkin-mkt192-wp' ); ?>
                        </label>
                        <div style="padding: 8px 12px; background: #f9fafb; border: 1px solid #e5e7eb; border-radius: 6px; color: #374151;">
                            <?php echo esc_html( $monkeypay_polling ); ?>s
                        </div>
                    </div>

                </div>
            </form>
        </div>
        <div class="checkin-modal-footer">
            <button type="button" class="checkin-btn checkin-btn-secondary" onclick="closePaymentModal('bank')">
                <?php esc_html_e( 'Huỷ', 'checkin-mkt192-wp' ); ?>
            </button>
            <button type="submit" form="form-bank" class="checkin-btn checkin-btn-primary">
                <span class="dashicons dashicons-saved"></span>
                <?php esc_html_e( 'Lưu thay đổi', 'checkin-mkt192-wp' ); ?>
            </button>
        </div>
    </div>
</div>
<?php
	}

	/**
	 * Render Momo modal
	 */
	private function render_momo_modal( $settings ) {
		// Get auto mode
		$momo_auto_mode = get_option( 'checkin_momo_auto_mode', '0' );

		// Manual mode fields
		$momo_account = get_option( 'checkin_momo_account', '' );
		$momo_qr_url  = get_option( 'checkin_momo_qr_url', '' );

		// Automatic mode fields
		$momo_mode         = get_option( 'checkin_momo_mode', 'sandbox' );
		$momo_partner_code = get_option( 'checkin_momo_partner_code', '' );
		$momo_access_key   = get_option( 'checkin_momo_access_key', '' );
		$momo_secret_key   = get_option( 'checkin_momo_secret_key', '' );
		$momo_phone        = get_option( 'checkin_momo_phone', '' );

		// Check if has saved data
		$has_saved_data = false;
		if ( $momo_auto_mode === '1' ) {
			$has_saved_data = ! empty( $momo_partner_code ) && ! empty( $momo_access_key ) && ! empty( $momo_secret_key );
		} else {
			$has_saved_data = ! empty( $momo_account ) || ! empty( $momo_qr_url );
		}
		?>
<div class="checkin-modal-backdrop" id="modal-momo" style="display: none;">
    <div class="checkin-modal">
        <div class="checkin-modal-header">
            <h2>
                <span>📱</span>
                <?php esc_html_e( 'Cấu hình Momo', 'checkin-mkt192-wp' ); ?>
            </h2>
            <button type="button" class="checkin-modal-close" data-payment="momo">
                <span class="dashicons dashicons-no-alt"></span>
            </button>
        </div>
        <div class="checkin-modal-body">
            <form id="form-momo" class="checkin-payment-form">
                <input type="hidden" name="momo_auto_mode"
                    value="<?php echo esc_attr( $momo_auto_mode ); ?>">

                <!-- Auto Mode Toggle -->
                <div class="checkin-form-group">
                    <label class="checkin-form-label">
                        <?php esc_html_e( 'Chế độ thanh toán', 'checkin-mkt192-wp' ); ?>
                    </label>
                    <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 8px;">
                        <label class="checkin-toggle checkin-toggle-lg">
                            <input type="checkbox" id="momo-auto-toggle" name="momo_auto_mode" value="1"
                                <?php checked( $momo_auto_mode, '1' ); ?>>
                            <span class="checkin-toggle-slider"></span>
                        </label>
                        <span class="checkin-payment-mode-text">
                            <?php echo $momo_auto_mode === '1' ? __( 'Thanh toán tự động - Xác nhận qua API', 'checkin-mkt192-wp' ) : __( 'Thanh toán thủ công - Dùng hình ảnh mã Qr được tải lên', 'checkin-mkt192-wp' ); ?>
                        </span>
                    </div>
                    <p class="checkin-form-help">
                        <?php esc_html_e( 'Chế độ thủ công: Chỉ hiển thị QR và số điện thoại cho khách hàng. Chế độ tự động: Tích hợp API để xác nhận thanh toán.', 'checkin-mkt192-wp' ); ?>
                    </p>
                </div>

                <div class="checkin-divider"></div>

                <!-- Manual Mode Section -->
                <div id="momo-manual-section"
                    style="<?php echo $momo_auto_mode === '1' ? 'display: none;' : ''; ?>">
                    <h4 class="checkin-section-title">
                        <span class="dashicons dashicons-admin-generic"></span>
                        <?php esc_html_e( 'Thông tin cơ bản', 'checkin-mkt192-wp' ); ?>
                    </h4>

                    <!-- Saved Info Display (if exists) -->
                    <?php if ( ! empty( $momo_account ) || ! empty( $momo_qr_url ) ) : ?>
                    <div class="checkin-saved-info-card">
                        <div class="checkin-saved-info-header">
                            <span class="dashicons dashicons-yes-alt"></span>
                            <strong><?php esc_html_e( 'Thông tin đã lưu', 'checkin-mkt192-wp' ); ?></strong>
                        </div>
                        <div class="checkin-saved-info-body">
                            <?php if ( ! empty( $momo_account ) ) : ?>
                            <div class="checkin-info-row">
                                <span class="checkin-info-label">Số điện thoại:</span>
                                <span
                                    class="checkin-info-value"><?php echo esc_html( $momo_account ); ?></span>
                            </div>
                            <?php endif; ?>
                            <?php if ( ! empty( $momo_qr_url ) ) : ?>
                            <div class="checkin-info-row">
                                <span class="checkin-info-label">Mã QR:</span>
                                <div class="checkin-qr-preview">
                                    <img src="<?php echo esc_url( $momo_qr_url ); ?>"
                                        alt="QR Code" />
                                </div>
                            </div>
                            <div class="checkin-info-row">
                                <span class="checkin-info-label">URL:</span>
                                <span
                                    class="checkin-info-value"><?php echo esc_html( $momo_qr_url ); ?></span>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="checkin-saved-info-actions">
                            <button type="button" class="checkin-btn checkin-btn-sm checkin-btn-secondary"
                                onclick="editPaymentInfo('momo')">
                                <span class="dashicons dashicons-edit"></span>
                                <?php esc_html_e( 'Sửa', 'checkin-mkt192-wp' ); ?>
                            </button>
                            <button type="button" class="checkin-btn checkin-btn-sm checkin-btn-danger"
                                onclick="deletePaymentInfo('momo')">
                                <span class="dashicons dashicons-trash"></span>
                                <?php esc_html_e( 'Xóa', 'checkin-mkt192-wp' ); ?>
                            </button>
                        </div>
                    </div>
                    <?php endif; ?>

                    <div id="momo-manual-form"
                        style="<?php echo ( ! empty( $momo_account ) || ! empty( $momo_qr_url ) ) ? 'display: none;' : ''; ?>">
                        <!-- Account Number -->
                        <div class="checkin-form-group">
                            <label class="checkin-form-label required">
                                <?php esc_html_e( 'Số điện thoại Momo', 'checkin-mkt192-wp' ); ?>
                            </label>
                            <input type="text" id="momo_account" name="momo_account" class="checkin-form-control"
                                value="<?php echo esc_attr( $momo_account ); ?>"
                                placeholder="<?php esc_attr_e( 'Ví dụ: 0987654321', 'checkin-mkt192-wp' ); ?>"
                                data-required="true"
                                <?php echo $momo_auto_mode === '0' ? 'required' : ''; ?>>
                        </div>

                        <!-- QR URL -->
                        <div class="checkin-form-group">
                            <label class="checkin-form-label">
                                <?php esc_html_e( 'URL Mã QR', 'checkin-mkt192-wp' ); ?>
                            </label>
                            <div style="display: flex; gap: 8px; margin-bottom: 8px;">
                                <input type="url" id="momo_qr_url" name="momo_qr_url" class="checkin-form-control"
                                    value="<?php echo esc_attr( $momo_qr_url ); ?>"
                                    placeholder="<?php esc_attr_e( 'https://example.com/qr-code.png', 'checkin-mkt192-wp' ); ?>">
                                <button type="button" class="checkin-btn checkin-btn-secondary"
                                    onclick="openMediaUploader('momo_qr_url', 'momo')">
                                    <span class="dashicons dashicons-upload"></span>
                                    <?php esc_html_e( 'Tải lên', 'checkin-mkt192-wp' ); ?>
                                </button>
                            </div>
                            <?php if ( ! empty( $momo_qr_url ) ) : ?>
                            <div class="checkin-qr-preview" id="momo_qr_preview" style="margin-bottom: 8px;">
                                <img src="<?php echo esc_url( $momo_qr_url ); ?>"
                                    alt="QR Preview"
                                    style="max-width: 200px; border-radius: 4px; border: 1px solid #ddd;">
                            </div>
                            <?php endif; ?>
                            <p class="checkin-form-help">
                                <?php esc_html_e( 'Nhập URL hình ảnh mã QR hoặc tải lên hình ảnh QR', 'checkin-mkt192-wp' ); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="checkin-divider"></div>

                <!-- Automatic Mode Section -->
                <div id="momo-auto-section"
                    style="<?php echo $momo_auto_mode === '1' ? '' : 'display: none;'; ?>">
                    <h4 class="checkin-section-title">
                        <span class="dashicons dashicons-update"></span>
                        <?php esc_html_e( 'Cấu hình API tự động', 'checkin-mkt192-wp' ); ?>
                    </h4>

                    <!-- API Mode -->
                    <div class="checkin-form-group">
                        <label class="checkin-form-label required">
                            <?php esc_html_e( 'Chế độ API', 'checkin-mkt192-wp' ); ?>
                        </label>
                        <select id="momo_mode" name="momo_mode" class="checkin-form-control">
                            <option value="sandbox" <?php selected( $momo_mode, 'sandbox' ); ?>>
                                <?php esc_html_e( 'Sandbox (Thử nghiệm)', 'checkin-mkt192-wp' ); ?>
                            </option>
                            <option value="production" <?php selected( $momo_mode, 'production' ); ?>>
                                <?php esc_html_e( 'Production (Thực tế)', 'checkin-mkt192-wp' ); ?>
                            </option>
                        </select>
                    </div>

                    <!-- Partner Code -->
                    <div class="checkin-form-group">
                        <label class="checkin-form-label required">
                            <?php esc_html_e( 'Partner Code', 'checkin-mkt192-wp' ); ?>
                        </label>
                        <input type="text" id="momo_partner_code" name="momo_partner_code" class="checkin-form-control"
                            value="<?php echo esc_attr( $momo_partner_code ); ?>"
                            placeholder="<?php esc_attr_e( 'Nhập Partner Code', 'checkin-mkt192-wp' ); ?>"
                            data-required="true"
                            <?php echo $momo_auto_mode === '1' ? 'required' : ''; ?>>
                    </div>

                    <!-- Access Key -->
                    <div class="checkin-form-group">
                        <label class="checkin-form-label required">
                            <?php esc_html_e( 'Access Key', 'checkin-mkt192-wp' ); ?>
                        </label>
                        <input type="text" id="momo_access_key" name="momo_access_key" class="checkin-form-control"
                            value="<?php echo esc_attr( $momo_access_key ); ?>"
                            placeholder="<?php esc_attr_e( 'Nhập Access Key', 'checkin-mkt192-wp' ); ?>"
                            data-required="true"
                            <?php echo $momo_auto_mode === '1' ? 'required' : ''; ?>>
                    </div>

                    <!-- Secret Key -->
                    <div class="checkin-form-group">
                        <label class="checkin-form-label required">
                            <?php esc_html_e( 'Secret Key', 'checkin-mkt192-wp' ); ?>
                        </label>
                        <input type="password" id="momo_secret_key" name="momo_secret_key" class="checkin-form-control"
                            value="<?php echo esc_attr( $momo_secret_key ); ?>"
                            placeholder="<?php esc_attr_e( 'Nhập Secret Key', 'checkin-mkt192-wp' ); ?>"
                            data-required="true"
                            <?php echo $momo_auto_mode === '1' ? 'required' : ''; ?>>
                    </div>

                    <!-- Momo Phone -->
                    <div class="checkin-form-group">
                        <label class="checkin-form-label">
                            <?php esc_html_e( 'Số điện thoại Momo', 'checkin-mkt192-wp' ); ?>
                        </label>
                        <input type="text" id="momo_phone" name="momo_phone" class="checkin-form-control"
                            value="<?php echo esc_attr( $momo_phone ); ?>"
                            placeholder="<?php esc_attr_e( 'Ví dụ: 0987654321', 'checkin-mkt192-wp' ); ?>">
                    </div>
                </div>
            </form>
        </div>
        <div class="checkin-modal-footer">
            <button type="button" class="checkin-btn checkin-btn-secondary" data-payment="momo"
                onclick="closePaymentModal('momo')">
                <?php esc_html_e( 'Huỷ', 'checkin-mkt192-wp' ); ?>
            </button>
            <button type="submit" form="form-momo" class="checkin-btn checkin-btn-primary">
                <span class="dashicons dashicons-saved"></span>
                <?php esc_html_e( 'Lưu thay đổi', 'checkin-mkt192-wp' ); ?>
            </button>
        </div>
    </div>
</div>
<?php
	}

	/**
	 * Render ZaloPay modal
	 */
	private function render_zalopay_modal( $settings ) {
		// Get auto mode
		$zalopay_auto_mode = get_option( 'checkin_zalopay_auto_mode', '0' );

		// Manual mode fields
		$zalopay_account = get_option( 'checkin_zalopay_account', '' );
		$zalopay_qr_url  = get_option( 'checkin_zalopay_qr_url', '' );

		// Automatic mode fields
		$zalopay_mode         = get_option( 'checkin_zalopay_mode', 'sandbox' );
		$zalopay_app_id       = get_option( 'checkin_zalopay_app_id', '' );
		$zalopay_key1         = get_option( 'checkin_zalopay_key1', '' );
		$zalopay_key2         = get_option( 'checkin_zalopay_key2', '' );
		$zalopay_callback_url = get_option( 'checkin_zalopay_callback_url', '' );

		// Check if has saved data
		$has_saved_data = false;
		if ( $zalopay_auto_mode === '1' ) {
			$has_saved_data = ! empty( $zalopay_app_id ) && ! empty( $zalopay_key1 ) && ! empty( $zalopay_key2 );
		} else {
			$has_saved_data = ! empty( $zalopay_account ) || ! empty( $zalopay_qr_url );
		}
		?>
<div class="checkin-modal-backdrop" id="modal-zalopay" style="display: none;">
    <div class="checkin-modal">
        <div class="checkin-modal-header">
            <h2>
                <span>💰</span>
                <?php esc_html_e( 'Cấu hình ZaloPay', 'checkin-mkt192-wp' ); ?>
            </h2>
            <button type="button" class="checkin-modal-close" data-payment="zalopay">
                <span class="dashicons dashicons-no-alt"></span>
            </button>
        </div>
        <div class="checkin-modal-body">
            <form id="form-zalopay" class="checkin-payment-form">
                <input type="hidden" name="zalopay_auto_mode"
                    value="<?php echo esc_attr( $zalopay_auto_mode ); ?>">

                <!-- Auto Mode Toggle -->
                <div class="checkin-form-group">
                    <label class="checkin-form-label">
                        <?php esc_html_e( 'Chế độ thanh toán', 'checkin-mkt192-wp' ); ?>
                    </label>
                    <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 8px;">
                        <label class="checkin-toggle checkin-toggle-lg">
                            <input type="checkbox" id="zalopay-auto-toggle" name="zalopay_auto_mode" value="1"
                                <?php checked( $zalopay_auto_mode, '1' ); ?>>
                            <span class="checkin-toggle-slider"></span>
                        </label>
                        <span class="checkin-payment-mode-text">
                            <?php echo $zalopay_auto_mode === '1' ? __( 'Thanh toán tự động - Xác nhận qua API', 'checkin-mkt192-wp' ) : __( 'Thanh toán thủ công - Dùng hình ảnh mã Qr được tải lên', 'checkin-mkt192-wp' ); ?>
                        </span>
                    </div>
                    <p class="checkin-form-help">
                        <?php esc_html_e( 'Chế độ thủ công: Chỉ hiển thị QR và số điện thoại cho khách hàng. Chế độ tự động: Tích hợp API để xác nhận thanh toán.', 'checkin-mkt192-wp' ); ?>
                    </p>
                </div>

                <div class="checkin-divider"></div>

                <!-- Manual Mode Section -->
                <div id="zalopay-manual-section"
                    style="<?php echo $zalopay_auto_mode === '1' ? 'display: none;' : ''; ?>">
                    <h4 class="checkin-section-title">
                        <span class="dashicons dashicons-admin-generic"></span>
                        <?php esc_html_e( 'Thông tin cơ bản', 'checkin-mkt192-wp' ); ?>
                    </h4>

                    <!-- Saved Info Display (if exists) -->
                    <?php if ( ! empty( $zalopay_account ) || ! empty( $zalopay_qr_url ) ) : ?>
                    <div class="checkin-saved-info-card">
                        <div class="checkin-saved-info-header">
                            <span class="dashicons dashicons-yes-alt"></span>
                            <strong><?php esc_html_e( 'Thông tin đã lưu', 'checkin-mkt192-wp' ); ?></strong>
                        </div>
                        <div class="checkin-saved-info-body">
                            <?php if ( ! empty( $zalopay_account ) ) : ?>
                            <div class="checkin-info-row">
                                <span class="checkin-info-label">Số điện thoại:</span>
                                <span
                                    class="checkin-info-value"><?php echo esc_html( $zalopay_account ); ?></span>
                            </div>
                            <?php endif; ?>
                            <?php if ( ! empty( $zalopay_qr_url ) ) : ?>
                            <div class="checkin-info-row">
                                <span class="checkin-info-label">Mã QR:</span>
                                <div class="checkin-qr-preview">
                                    <img src="<?php echo esc_url( $zalopay_qr_url ); ?>"
                                        alt="QR Code" />
                                </div>
                            </div>
                            <div class="checkin-info-row">
                                <span class="checkin-info-label">URL:</span>
                                <span
                                    class="checkin-info-value"><?php echo esc_html( $zalopay_qr_url ); ?></span>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="checkin-saved-info-actions">
                            <button type="button" class="checkin-btn checkin-btn-sm checkin-btn-secondary"
                                onclick="editPaymentInfo('zalopay')">
                                <span class="dashicons dashicons-edit"></span>
                                <?php esc_html_e( 'Sửa', 'checkin-mkt192-wp' ); ?>
                            </button>
                            <button type="button" class="checkin-btn checkin-btn-sm checkin-btn-danger"
                                onclick="deletePaymentInfo('zalopay')">
                                <span class="dashicons dashicons-trash"></span>
                                <?php esc_html_e( 'Xóa', 'checkin-mkt192-wp' ); ?>
                            </button>
                        </div>
                    </div>
                    <?php endif; ?>

                    <div id="zalopay-manual-form"
                        style="<?php echo ( ! empty( $zalopay_account ) || ! empty( $zalopay_qr_url ) ) ? 'display: none;' : ''; ?>">
                        <!-- Account Number -->
                        <div class="checkin-form-group">
                            <label class="checkin-form-label required">
                                <?php esc_html_e( 'Số điện thoại ZaloPay', 'checkin-mkt192-wp' ); ?>
                            </label>
                            <input type="text" id="zalopay_account" name="zalopay_account" class="checkin-form-control"
                                value="<?php echo esc_attr( $zalopay_account ); ?>"
                                placeholder="<?php esc_attr_e( 'Ví dụ: 0987654321', 'checkin-mkt192-wp' ); ?>"
                                data-required="true"
                                <?php echo $zalopay_auto_mode === '0' ? 'required' : ''; ?>>
                        </div>

                        <!-- QR URL -->
                        <div class="checkin-form-group">
                            <label class="checkin-form-label">
                                <?php esc_html_e( 'URL Mã QR', 'checkin-mkt192-wp' ); ?>
                            </label>
                            <div style="display: flex; gap: 8px; margin-bottom: 8px;">
                                <input type="url" id="zalopay_qr_url" name="zalopay_qr_url" class="checkin-form-control"
                                    value="<?php echo esc_attr( $zalopay_qr_url ); ?>"
                                    placeholder="<?php esc_attr_e( 'https://example.com/qr-code.png', 'checkin-mkt192-wp' ); ?>">
                                <button type="button" class="checkin-btn checkin-btn-secondary"
                                    onclick="openMediaUploader('zalopay_qr_url', 'zalopay')">
                                    <span class="dashicons dashicons-upload"></span>
                                    <?php esc_html_e( 'Tải lên', 'checkin-mkt192-wp' ); ?>
                                </button>
                            </div>
                            <?php if ( ! empty( $zalopay_qr_url ) ) : ?>
                            <div class="checkin-qr-preview" id="zalopay_qr_preview" style="margin-bottom: 8px;">
                                <img src="<?php echo esc_url( $zalopay_qr_url ); ?>"
                                    alt="QR Preview"
                                    style="max-width: 200px; border-radius: 4px; border: 1px solid #ddd;">
                            </div>
                            <?php endif; ?>
                            <p class="checkin-form-help">
                                <?php esc_html_e( 'Nhập URL hình ảnh mã QR hoặc tải lên hình ảnh QR', 'checkin-mkt192-wp' ); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="checkin-divider"></div>

                <!-- Automatic Mode Section -->
                <div id="zalopay-auto-section"
                    style="<?php echo $zalopay_auto_mode === '1' ? '' : 'display: none;'; ?>">
                    <h4 class="checkin-section-title">
                        <span class="dashicons dashicons-update"></span>
                        <?php esc_html_e( 'Cấu hình API tự động', 'checkin-mkt192-wp' ); ?>
                    </h4>

                    <!-- API Mode -->
                    <div class="checkin-form-group">
                        <label class="checkin-form-label required">
                            <?php esc_html_e( 'Chế độ API', 'checkin-mkt192-wp' ); ?>
                        </label>
                        <select id="zalopay_mode" name="zalopay_mode" class="checkin-form-control">
                            <option value="sandbox" <?php selected( $zalopay_mode, 'sandbox' ); ?>>
                                <?php esc_html_e( 'Sandbox (Thử nghiệm)', 'checkin-mkt192-wp' ); ?>
                            </option>
                            <option value="production" <?php selected( $zalopay_mode, 'production' ); ?>>
                                <?php esc_html_e( 'Production (Thực tế)', 'checkin-mkt192-wp' ); ?>
                            </option>
                        </select>
                    </div>

                    <!-- App ID -->
                    <div class="checkin-form-group">
                        <label class="checkin-form-label required">
                            <?php esc_html_e( 'App ID', 'checkin-mkt192-wp' ); ?>
                        </label>
                        <input type="text" id="zalopay_app_id" name="zalopay_app_id" class="checkin-form-control"
                            value="<?php echo esc_attr( $zalopay_app_id ); ?>"
                            placeholder="<?php esc_attr_e( 'Nhập App ID', 'checkin-mkt192-wp' ); ?>"
                            data-required="true"
                            <?php echo $zalopay_auto_mode === '1' ? 'required' : ''; ?>>
                    </div>

                    <!-- Key 1 -->
                    <div class="checkin-form-group">
                        <label class="checkin-form-label required">
                            <?php esc_html_e( 'Key 1', 'checkin-mkt192-wp' ); ?>
                        </label>
                        <input type="password" id="zalopay_key1" name="zalopay_key1" class="checkin-form-control"
                            value="<?php echo esc_attr( $zalopay_key1 ); ?>"
                            placeholder="<?php esc_attr_e( 'Nhập Key 1', 'checkin-mkt192-wp' ); ?>"
                            data-required="true"
                            <?php echo $zalopay_auto_mode === '1' ? 'required' : ''; ?>>
                    </div>

                    <!-- Key 2 -->
                    <div class="checkin-form-group">
                        <label class="checkin-form-label required">
                            <?php esc_html_e( 'Key 2', 'checkin-mkt192-wp' ); ?>
                        </label>
                        <input type="password" id="zalopay_key2" name="zalopay_key2" class="checkin-form-control"
                            value="<?php echo esc_attr( $zalopay_key2 ); ?>"
                            placeholder="<?php esc_attr_e( 'Nhập Key 2', 'checkin-mkt192-wp' ); ?>"
                            data-required="true"
                            <?php echo $zalopay_auto_mode === '1' ? 'required' : ''; ?>>
                    </div>

                    <!-- Callback URL -->
                    <div class="checkin-form-group">
                        <label class="checkin-form-label">
                            <?php esc_html_e( 'Callback URL', 'checkin-mkt192-wp' ); ?>
                        </label>
                        <input type="url" id="zalopay_callback_url" name="zalopay_callback_url"
                            class="checkin-form-control"
                            value="<?php echo esc_attr( $zalopay_callback_url ); ?>"
                            placeholder="<?php echo esc_attr( home_url( '/zalopay-callback' ) ); ?>">
                    </div>
                </div>
            </form>
        </div>
        <div class="checkin-modal-footer">
            <button type="button" class="checkin-btn checkin-btn-secondary" data-payment="zalopay"
                onclick="closePaymentModal('zalopay')">
                <?php esc_html_e( 'Huỷ', 'checkin-mkt192-wp' ); ?>
            </button>
            <button type="submit" form="form-zalopay" class="checkin-btn checkin-btn-primary">
                <span class="dashicons dashicons-saved"></span>
                <?php esc_html_e( 'Lưu thay đổi', 'checkin-mkt192-wp' ); ?>
            </button>
        </div>
    </div>
</div>
<?php
	}

    /**
     * Render Bank Transfer tab
     */
    private function render_bank_tab( $settings ) {
        $bank_enabled        = isset( $settings['bank_enabled'] ) ? $settings['bank_enabled'] : 'no';
        $bank_name           = isset( $settings['bank_name'] ) ? $settings['bank_name'] : '';
        $bank_account_number = isset( $settings['bank_account_number'] ) ? $settings['bank_account_number'] : '';
        $bank_account_name   = isset( $settings['bank_account_name'] ) ? $settings['bank_account_name'] : '';
        $bank_branch         = isset( $settings['bank_branch'] ) ? $settings['bank_branch'] : '';
        $bank_qr_code        = isset( $settings['bank_qr_code'] ) ? $settings['bank_qr_code'] : '';
        $bank_instructions   = isset( $settings['bank_instructions'] ) ? $settings['bank_instructions'] : '';
        ?>
<div class="checkin-card">
    <div class="checkin-card-header">
        <h3><?php esc_html_e( 'Cấu hình chuyển khoản ngân hàng', 'checkin-mkt192-wp' ); ?>
        </h3>
    </div>
    <div class="checkin-card-body">
        <!-- Enable Bank Transfer -->
        <div class="checkin-form-group">
            <label class="checkin-form-label">
                <?php esc_html_e( 'Kích hoạt chuyển khoản ngân hàng', 'checkin-mkt192-wp' ); ?>
            </label>
            <label class="checkin-toggle">
                <input type="checkbox" name="bank_enabled" value="yes" data-toggle-target="bank-settings"
                    <?php checked( $bank_enabled, 'yes' ); ?>>
                <span class="checkin-toggle-slider"></span>
            </label>
            <p class="checkin-form-help">
                <?php esc_html_e( 'Bật/tắt phương thức thanh toán chuyển khoản ngân hàng.', 'checkin-mkt192-wp' ); ?>
            </p>
        </div>

        <div id="bank-settings"
            style="<?php echo $bank_enabled === 'yes' ? '' : 'display:none;'; ?>">
            <!-- Bank Name -->
            <div class="checkin-form-group">
                <label class="checkin-form-label" for="bank_name">
                    <?php esc_html_e( 'Tên ngân hàng', 'checkin-mkt192-wp' ); ?>
                    <span class="checkin-required">*</span>
                </label>
                <input type="text" id="bank_name" name="bank_name" class="checkin-form-control"
                    value="<?php echo esc_attr( $bank_name ); ?>"
                    placeholder="<?php esc_attr_e( 'Ví dụ: Vietcombank', 'checkin-mkt192-wp' ); ?>">
                <p class="checkin-form-help">
                    <?php esc_html_e( 'Nhập tên đầy đủ của ngân hàng.', 'checkin-mkt192-wp' ); ?>
                </p>
            </div>

            <!-- Account Number -->
            <div class="checkin-form-group">
                <label class="checkin-form-label" for="bank_account_number">
                    <?php esc_html_e( 'Số tài khoản', 'checkin-mkt192-wp' ); ?>
                    <span class="checkin-required">*</span>
                </label>
                <input type="text" id="bank_account_number" name="bank_account_number" class="checkin-form-control"
                    value="<?php echo esc_attr( $bank_account_number ); ?>"
                    placeholder="<?php esc_attr_e( 'Ví dụ: 1234567890', 'checkin-mkt192-wp' ); ?>">
                <p class="checkin-form-help">
                    <?php esc_html_e( 'Số tài khoản nhận tiền.', 'checkin-mkt192-wp' ); ?>
                </p>
            </div>

            <!-- Account Name -->
            <div class="checkin-form-group">
                <label class="checkin-form-label" for="bank_account_name">
                    <?php esc_html_e( 'Tên chủ tài khoản', 'checkin-mkt192-wp' ); ?>
                    <span class="checkin-required">*</span>
                </label>
                <input type="text" id="bank_account_name" name="bank_account_name" class="checkin-form-control"
                    value="<?php echo esc_attr( $bank_account_name ); ?>"
                    placeholder="<?php esc_attr_e( 'Ví dụ: NGUYEN VAN A', 'checkin-mkt192-wp' ); ?>">
                <p class="checkin-form-help">
                    <?php esc_html_e( 'Tên chủ tài khoản theo đăng ký ngân hàng.', 'checkin-mkt192-wp' ); ?>
                </p>
            </div>

            <!-- Bank Branch -->
            <div class="checkin-form-group">
                <label class="checkin-form-label" for="bank_branch">
                    <?php esc_html_e( 'Chi nhánh', 'checkin-mkt192-wp' ); ?>
                </label>
                <input type="text" id="bank_branch" name="bank_branch" class="checkin-form-control"
                    value="<?php echo esc_attr( $bank_branch ); ?>"
                    placeholder="<?php esc_attr_e( 'Ví dụ: Chi nhánh Hà Nội', 'checkin-mkt192-wp' ); ?>">
                <p class="checkin-form-help">
                    <?php esc_html_e( 'Tên chi nhánh ngân hàng (tuỳ chọn).', 'checkin-mkt192-wp' ); ?>
                </p>
            </div>

            <!-- QR Code -->
            <div class="checkin-form-group">
                <label class="checkin-form-label">
                    <?php esc_html_e( 'Mã QR Code', 'checkin-mkt192-wp' ); ?>
                </label>
                <div class="checkin-image-uploader">
                    <div class="checkin-image-preview">
                        <?php if ( $bank_qr_code ) : ?>
                        <img src="<?php echo esc_url( $bank_qr_code ); ?>"
                            alt="QR Code">
                        <button type="button" class="checkin-btn-remove-image" data-target="bank_qr_code">
                            <span class="dashicons dashicons-no-alt"></span>
                        </button>
                        <?php else : ?>
                        <div class="checkin-image-placeholder">
                            <span class="dashicons dashicons-format-image"></span>
                            <p><?php esc_html_e( 'Chưa có hình ảnh', 'checkin-mkt192-wp' ); ?>
                            </p>
                        </div>
                        <?php endif; ?>
                    </div>
                    <input type="hidden" id="bank_qr_code" name="bank_qr_code"
                        value="<?php echo esc_attr( $bank_qr_code ); ?>">
                    <button type="button" class="checkin-btn checkin-btn-secondary checkin-btn-upload-image"
                        data-target="bank_qr_code">
                        <span class="dashicons dashicons-upload"></span>
                        <?php esc_html_e( 'Tải lên QR Code', 'checkin-mkt192-wp' ); ?>
                    </button>
                </div>
                <p class="checkin-form-help">
                    <?php esc_html_e( 'Mã QR Code để khách hàng có thể quét và chuyển khoản nhanh.', 'checkin-mkt192-wp' ); ?>
                </p>
            </div>

            <!-- Instructions -->
            <div class="checkin-form-group">
                <label class="checkin-form-label" for="bank_instructions">
                    <?php esc_html_e( 'Hướng dẫn chuyển khoản', 'checkin-mkt192-wp' ); ?>
                </label>
                <textarea id="bank_instructions" name="bank_instructions" class="checkin-form-control" rows="5"
                    placeholder="<?php esc_attr_e( 'Nhập hướng dẫn chi tiết về cách chuyển khoản...', 'checkin-mkt192-wp' ); ?>"><?php echo esc_textarea( $bank_instructions ); ?></textarea>
                <p class="checkin-form-help">
                    <?php esc_html_e( 'Hướng dẫn chi tiết cho khách hàng khi thực hiện chuyển khoản.', 'checkin-mkt192-wp' ); ?>
                </p>
            </div>
        </div>
    </div>
</div>
<?php
    }

    /**
     * Render Momo tab
     */
    private function render_momo_tab( $settings ) {
        $momo_enabled      = isset( $settings['momo_enabled'] ) ? $settings['momo_enabled'] : 'no';
        $momo_mode         = isset( $settings['momo_mode'] ) ? $settings['momo_mode'] : 'sandbox';
        $momo_partner_code = isset( $settings['momo_partner_code'] ) ? $settings['momo_partner_code'] : '';
        $momo_access_key   = isset( $settings['momo_access_key'] ) ? $settings['momo_access_key'] : '';
        $momo_secret_key   = isset( $settings['momo_secret_key'] ) ? $settings['momo_secret_key'] : '';
        $momo_phone        = isset( $settings['momo_phone'] ) ? $settings['momo_phone'] : '';
        $momo_qr_code      = isset( $settings['momo_qr_code'] ) ? $settings['momo_qr_code'] : '';
        ?>
<div class="checkin-card">
    <div class="checkin-card-header">
        <h3><?php esc_html_e( 'Cấu hình Momo', 'checkin-mkt192-wp' ); ?>
        </h3>
    </div>
    <div class="checkin-card-body">
        <!-- Enable Momo -->
        <div class="checkin-form-group">
            <label class="checkin-form-label">
                <?php esc_html_e( 'Kích hoạt thanh toán Momo', 'checkin-mkt192-wp' ); ?>
            </label>
            <label class="checkin-toggle">
                <input type="checkbox" name="momo_enabled" value="yes" data-toggle-target="momo-settings"
                    <?php checked( $momo_enabled, 'yes' ); ?>>
                <span class="checkin-toggle-slider"></span>
            </label>
            <p class="checkin-form-help">
                <?php esc_html_e( 'Bật/tắt phương thức thanh toán qua Momo.', 'checkin-mkt192-wp' ); ?>
            </p>
        </div>

        <div id="momo-settings"
            style="<?php echo $momo_enabled === 'yes' ? '' : 'display:none;'; ?>">
            <!-- API Mode -->
            <div class="checkin-form-group">
                <label class="checkin-form-label" for="momo_mode">
                    <?php esc_html_e( 'Chế độ API', 'checkin-mkt192-wp' ); ?>
                </label>
                <select id="momo_mode" name="momo_mode" class="checkin-form-control">
                    <option value="sandbox" <?php selected( $momo_mode, 'sandbox' ); ?>>
                        <?php esc_html_e( 'Sandbox (Thử nghiệm)', 'checkin-mkt192-wp' ); ?>
                    </option>
                    <option value="production" <?php selected( $momo_mode, 'production' ); ?>>
                        <?php esc_html_e( 'Production (Thực tế)', 'checkin-mkt192-wp' ); ?>
                    </option>
                </select>
                <p class="checkin-form-help">
                    <?php esc_html_e( 'Chọn môi trường API để kết nối với Momo.', 'checkin-mkt192-wp' ); ?>
                </p>
            </div>

            <!-- Partner Code -->
            <div class="checkin-form-group">
                <label class="checkin-form-label" for="momo_partner_code">
                    <?php esc_html_e( 'Partner Code', 'checkin-mkt192-wp' ); ?>
                    <span class="checkin-required">*</span>
                </label>
                <input type="text" id="momo_partner_code" name="momo_partner_code" class="checkin-form-control"
                    value="<?php echo esc_attr( $momo_partner_code ); ?>"
                    placeholder="<?php esc_attr_e( 'Nhập Partner Code', 'checkin-mkt192-wp' ); ?>">
                <p class="checkin-form-help">
                    <?php esc_html_e( 'Mã đối tác được cung cấp bởi Momo.', 'checkin-mkt192-wp' ); ?>
                </p>
            </div>

            <!-- Access Key -->
            <div class="checkin-form-group">
                <label class="checkin-form-label" for="momo_access_key">
                    <?php esc_html_e( 'Access Key', 'checkin-mkt192-wp' ); ?>
                    <span class="checkin-required">*</span>
                </label>
                <input type="text" id="momo_access_key" name="momo_access_key" class="checkin-form-control"
                    value="<?php echo esc_attr( $momo_access_key ); ?>"
                    placeholder="<?php esc_attr_e( 'Nhập Access Key', 'checkin-mkt192-wp' ); ?>">
                <p class="checkin-form-help">
                    <?php esc_html_e( 'Access Key để xác thực API.', 'checkin-mkt192-wp' ); ?>
                </p>
            </div>

            <!-- Secret Key -->
            <div class="checkin-form-group">
                <label class="checkin-form-label" for="momo_secret_key">
                    <?php esc_html_e( 'Secret Key', 'checkin-mkt192-wp' ); ?>
                    <span class="checkin-required">*</span>
                </label>
                <input type="password" id="momo_secret_key" name="momo_secret_key" class="checkin-form-control"
                    value="<?php echo esc_attr( $momo_secret_key ); ?>"
                    placeholder="<?php esc_attr_e( 'Nhập Secret Key', 'checkin-mkt192-wp' ); ?>">
                <p class="checkin-form-help">
                    <?php esc_html_e( 'Secret Key để mã hóa dữ liệu giao dịch.', 'checkin-mkt192-wp' ); ?>
                </p>
            </div>

            <!-- Momo Phone -->
            <div class="checkin-form-group">
                <label class="checkin-form-label" for="momo_phone">
                    <?php esc_html_e( 'Số điện thoại Momo', 'checkin-mkt192-wp' ); ?>
                </label>
                <input type="text" id="momo_phone" name="momo_phone" class="checkin-form-control"
                    value="<?php echo esc_attr( $momo_phone ); ?>"
                    placeholder="<?php esc_attr_e( 'Ví dụ: 0987654321', 'checkin-mkt192-wp' ); ?>">
                <p class="checkin-form-help">
                    <?php esc_html_e( 'Số điện thoại liên kết với tài khoản Momo của bạn.', 'checkin-mkt192-wp' ); ?>
                </p>
            </div>

            <!-- QR Code -->
            <div class="checkin-form-group">
                <label class="checkin-form-label">
                    <?php esc_html_e( 'Mã QR Code', 'checkin-mkt192-wp' ); ?>
                </label>
                <div class="checkin-image-uploader">
                    <div class="checkin-image-preview">
                        <?php if ( $momo_qr_code ) : ?>
                        <img src="<?php echo esc_url( $momo_qr_code ); ?>"
                            alt="QR Code">
                        <button type="button" class="checkin-btn-remove-image" data-target="momo_qr_code">
                            <span class="dashicons dashicons-no-alt"></span>
                        </button>
                        <?php else : ?>
                        <div class="checkin-image-placeholder">
                            <span class="dashicons dashicons-format-image"></span>
                            <p><?php esc_html_e( 'Chưa có hình ảnh', 'checkin-mkt192-wp' ); ?>
                            </p>
                        </div>
                        <?php endif; ?>
                    </div>
                    <input type="hidden" id="momo_qr_code" name="momo_qr_code"
                        value="<?php echo esc_attr( $momo_qr_code ); ?>">
                    <button type="button" class="checkin-btn checkin-btn-secondary checkin-btn-upload-image"
                        data-target="momo_qr_code">
                        <span class="dashicons dashicons-upload"></span>
                        <?php esc_html_e( 'Tải lên QR Code', 'checkin-mkt192-wp' ); ?>
                    </button>
                </div>
                <p class="checkin-form-help">
                    <?php esc_html_e( 'Mã QR Code cá nhân của tài khoản Momo.', 'checkin-mkt192-wp' ); ?>
                </p>
            </div>

            <!-- Test Connection -->
            <div class="checkin-form-group">
                <button type="button" class="checkin-btn checkin-btn-secondary" id="test-momo-connection">
                    <span class="dashicons dashicons-admin-plugins"></span>
                    <?php esc_html_e( 'Kiểm tra kết nối', 'checkin-mkt192-wp' ); ?>
                </button>
                <p class="checkin-form-help">
                    <?php esc_html_e( 'Kiểm tra xem API có hoạt động đúng không.', 'checkin-mkt192-wp' ); ?>
                </p>
            </div>
        </div>
    </div>
</div>
<?php
    }

    /**
     * Render ZaloPay tab
     */
    private function render_zalopay_tab( $settings ) {
        $zalopay_enabled      = isset( $settings['zalopay_enabled'] ) ? $settings['zalopay_enabled'] : 'no';
        $zalopay_mode         = isset( $settings['zalopay_mode'] ) ? $settings['zalopay_mode'] : 'sandbox';
        $zalopay_app_id       = isset( $settings['zalopay_app_id'] ) ? $settings['zalopay_app_id'] : '';
        $zalopay_key1         = isset( $settings['zalopay_key1'] ) ? $settings['zalopay_key1'] : '';
        $zalopay_key2         = isset( $settings['zalopay_key2'] ) ? $settings['zalopay_key2'] : '';
        $zalopay_callback_url = isset( $settings['zalopay_callback_url'] ) ? $settings['zalopay_callback_url'] : '';
        ?>
<div class="checkin-card">
    <div class="checkin-card-header">
        <h3><?php esc_html_e( 'Cấu hình ZaloPay', 'checkin-mkt192-wp' ); ?>
        </h3>
    </div>
    <div class="checkin-card-body">
        <!-- Enable ZaloPay -->
        <div class="checkin-form-group">
            <label class="checkin-form-label">
                <?php esc_html_e( 'Kích hoạt thanh toán ZaloPay', 'checkin-mkt192-wp' ); ?>
            </label>
            <label class="checkin-toggle">
                <input type="checkbox" name="zalopay_enabled" value="yes" data-toggle-target="zalopay-settings"
                    <?php checked( $zalopay_enabled, 'yes' ); ?>>
                <span class="checkin-toggle-slider"></span>
            </label>
            <p class="checkin-form-help">
                <?php esc_html_e( 'Bật/tắt phương thức thanh toán qua ZaloPay.', 'checkin-mkt192-wp' ); ?>
            </p>
        </div>

        <div id="zalopay-settings"
            style="<?php echo $zalopay_enabled === 'yes' ? '' : 'display:none;'; ?>">
            <!-- API Mode -->
            <div class="checkin-form-group">
                <label class="checkin-form-label" for="zalopay_mode">
                    <?php esc_html_e( 'Chế độ API', 'checkin-mkt192-wp' ); ?>
                </label>
                <select id="zalopay_mode" name="zalopay_mode" class="checkin-form-control">
                    <option value="sandbox" <?php selected( $zalopay_mode, 'sandbox' ); ?>>
                        <?php esc_html_e( 'Sandbox (Thử nghiệm)', 'checkin-mkt192-wp' ); ?>
                    </option>
                    <option value="production" <?php selected( $zalopay_mode, 'production' ); ?>>
                        <?php esc_html_e( 'Production (Thực tế)', 'checkin-mkt192-wp' ); ?>
                    </option>
                </select>
                <p class="checkin-form-help">
                    <?php esc_html_e( 'Chọn môi trường API để kết nối với ZaloPay.', 'checkin-mkt192-wp' ); ?>
                </p>
            </div>

            <!-- App ID -->
            <div class="checkin-form-group">
                <label class="checkin-form-label" for="zalopay_app_id">
                    <?php esc_html_e( 'App ID', 'checkin-mkt192-wp' ); ?>
                    <span class="checkin-required">*</span>
                </label>
                <input type="text" id="zalopay_app_id" name="zalopay_app_id" class="checkin-form-control"
                    value="<?php echo esc_attr( $zalopay_app_id ); ?>"
                    placeholder="<?php esc_attr_e( 'Nhập App ID', 'checkin-mkt192-wp' ); ?>">
                <p class="checkin-form-help">
                    <?php esc_html_e( 'App ID được cung cấp bởi ZaloPay.', 'checkin-mkt192-wp' ); ?>
                </p>
            </div>

            <!-- Key 1 -->
            <div class="checkin-form-group">
                <label class="checkin-form-label" for="zalopay_key1">
                    <?php esc_html_e( 'Key 1', 'checkin-mkt192-wp' ); ?>
                    <span class="checkin-required">*</span>
                </label>
                <input type="password" id="zalopay_key1" name="zalopay_key1" class="checkin-form-control"
                    value="<?php echo esc_attr( $zalopay_key1 ); ?>"
                    placeholder="<?php esc_attr_e( 'Nhập Key 1', 'checkin-mkt192-wp' ); ?>">
                <p class="checkin-form-help">
                    <?php esc_html_e( 'Key 1 để tạo chữ ký giao dịch.', 'checkin-mkt192-wp' ); ?>
                </p>
            </div>

            <!-- Key 2 -->
            <div class="checkin-form-group">
                <label class="checkin-form-label" for="zalopay_key2">
                    <?php esc_html_e( 'Key 2', 'checkin-mkt192-wp' ); ?>
                    <span class="checkin-required">*</span>
                </label>
                <input type="password" id="zalopay_key2" name="zalopay_key2" class="checkin-form-control"
                    value="<?php echo esc_attr( $zalopay_key2 ); ?>"
                    placeholder="<?php esc_attr_e( 'Nhập Key 2', 'checkin-mkt192-wp' ); ?>">
                <p class="checkin-form-help">
                    <?php esc_html_e( 'Key 2 để xác thực callback từ ZaloPay.', 'checkin-mkt192-wp' ); ?>
                </p>
            </div>

            <!-- Callback URL -->
            <div class="checkin-form-group">
                <label class="checkin-form-label" for="zalopay_callback_url">
                    <?php esc_html_e( 'Callback URL', 'checkin-mkt192-wp' ); ?>
                </label>
                <input type="url" id="zalopay_callback_url" name="zalopay_callback_url" class="checkin-form-control"
                    value="<?php echo esc_attr( $zalopay_callback_url ); ?>"
                    placeholder="<?php echo esc_attr( home_url( '/zalopay-callback' ) ); ?>">
                <p class="checkin-form-help">
                    <?php esc_html_e( 'URL để ZaloPay gửi thông báo về kết quả giao dịch.', 'checkin-mkt192-wp' ); ?>
                </p>
            </div>

            <!-- Test Connection -->
            <div class="checkin-form-group">
                <button type="button" class="checkin-btn checkin-btn-secondary" id="test-zalopay-connection">
                    <span class="dashicons dashicons-admin-plugins"></span>
                    <?php esc_html_e( 'Kiểm tra kết nối', 'checkin-mkt192-wp' ); ?>
                </button>
                <p class="checkin-form-help">
                    <?php esc_html_e( 'Kiểm tra xem API có hoạt động đúng không.', 'checkin-mkt192-wp' ); ?>
                </p>
            </div>
        </div>
    </div>
</div>

<!-- Documentation Card -->
<div class="checkin-card">
    <div class="checkin-card-header">
        <h3><?php esc_html_e( 'Tài liệu hướng dẫn', 'checkin-mkt192-wp' ); ?>
        </h3>
    </div>
    <div class="checkin-card-body">
        <div class="checkin-alert checkin-alert-info">
            <span class="dashicons dashicons-info"></span>
            <div>
                <strong><?php esc_html_e( 'Hướng dẫn tích hợp ZaloPay', 'checkin-mkt192-wp' ); ?></strong>
                <p><?php esc_html_e( 'Để nhận được App ID và các Key, vui lòng đăng ký tài khoản merchant tại:', 'checkin-mkt192-wp' ); ?>
                </p>
                <a href="https://docs.zalopay.vn" target="_blank" class="checkin-btn checkin-btn-link">
                    <?php esc_html_e( 'ZaloPay Developer Portal', 'checkin-mkt192-wp' ); ?>
                    <span class="dashicons dashicons-external"></span>
                </a>
            </div>
        </div>
    </div>
</div>
<?php
    }

	/**
	 * AJAX handler to save payment settings
	 */
	public function ajax_save_payment() {
		// Log incoming request for debugging
		error_log( 'Payment save request: ' . print_r( $_POST, true ) );

		// Check nonce
		if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( $_POST['nonce'], 'checkin-admin-nonce' ) ) {
			error_log( 'Nonce verification failed' );
			wp_send_json_error( [ 'message' => __( 'Xác thực không hợp lệ.', 'checkin-mkt192-wp' ) ] );
		}

		// Check capabilities
		if ( ! current_user_can( 'manage_options' ) ) {
			error_log( 'User lacks manage_options capability' );
			wp_send_json_error( [ 'message' => __( 'Bạn không có quyền thực hiện hành động này.', 'checkin-mkt192-wp' ) ] );
		}

		// Get payment type
		$payment_type = isset( $_POST['payment_type'] ) ? sanitize_key( $_POST['payment_type'] ) : '';

		if ( empty( $payment_type ) ) {
			error_log( 'Payment type is empty' );
			wp_send_json_error( [ 'message' => __( 'Loại thanh toán không hợp lệ.', 'checkin-mkt192-wp' ) ] );
		}

		// Process based on payment type
		switch ( $payment_type ) {
			case 'bank':
				$this->save_bank_settings();
				break;

			case 'momo':
				$this->save_momo_settings();
				break;

			case 'zalopay':
				$this->save_zalopay_settings();
				break;

			default:
				wp_send_json_error( [ 'message' => __( 'Loại thanh toán không được hỗ trợ.', 'checkin-mkt192-wp' ) ] );
		}

		// Handle toggle state (enabled/disabled)
		$use_option_key = 'checkin_use_' . $payment_type . ( $payment_type === 'bank' ? '_transfer' : '' );
		$enabled_value  = isset( $_POST['enabled'] ) && ( $_POST['enabled'] === 'true' || $_POST['enabled'] === '1' ) ? '1' : '0';
		update_option( $use_option_key, $enabled_value );

		// When saving bank settings from the modal form, force-enable bank transfer
		// (the card toggle might not be checked yet, but saving config implies enabling)
		if ( $payment_type === 'bank' && $enabled_value === '0' && isset( $_POST['bank_auto_mode'] ) ) {
			update_option( 'checkin_use_bank_transfer', '1' );
		}

		wp_send_json_success( [
			'message' => __( 'Cài đặt đã được lưu thành công!', 'checkin-mkt192-wp' ),
		] );
	}

	/**
	 * Save Bank Transfer settings
	 */
	private function save_bank_settings() {
		// Get auto mode
		$auto_mode = isset( $_POST['bank_auto_mode'] ) && $_POST['bank_auto_mode'] === '1' ? '1' : '0';
		update_option( 'checkin_bank_auto_mode', $auto_mode );

		// Save auto amount sub-toggle (only relevant when auto mode is on)
		if ( $auto_mode === '1' ) {
			$auto_amount = isset( $_POST['bank_auto_amount'] ) && $_POST['bank_auto_amount'] === '1' ? '1' : '0';
			update_option( 'checkin_bank_auto_amount', $auto_amount );
		}

		if ( $auto_mode === '1' ) {
			// Save MonkeyPay API Key
			if ( isset( $_POST['monkeypay_api_key'] ) && ! empty( $_POST['monkeypay_api_key'] ) ) {
				update_option( 'monkeypay_api_key', sanitize_text_field( $_POST['monkeypay_api_key'] ) );
			}
			// Save selected gateway ID
			if ( isset( $_POST['selected_gateway_id'] ) ) {
				update_option( 'checkin_selected_gateway_id', sanitize_text_field( $_POST['selected_gateway_id'] ) );
			}
			// MonkeyPay server URL is read live from the MonkeyPay plugin
			// (see checkin_mkt192_get_monkeypay_url) — nothing to persist here.

			// Save bank account info from selected gateway
			if ( isset( $_POST['bank_account_number'] ) ) {
				update_option( 'checkin_bank_account_number', sanitize_text_field( $_POST['bank_account_number'] ) );
			}
			if ( isset( $_POST['bank_account_name'] ) ) {
				update_option( 'checkin_bank_account_name', sanitize_text_field( $_POST['bank_account_name'] ) );
			}
			// Save bank BIN code (for VietQR) — defaults to MB Bank if not provided
			if ( isset( $_POST['bank_bin'] ) && ! empty( $_POST['bank_bin'] ) ) {
				update_option( 'checkin_bank_bin', sanitize_text_field( $_POST['bank_bin'] ) );
			}

		} else {
			// Save only basic manual configuration
			update_option( 'checkin_bank_account', isset( $_POST['bank_account'] ) ? sanitize_text_field( $_POST['bank_account'] ) : '' );
			update_option( 'checkin_bank_qr_url', isset( $_POST['bank_qr_url'] ) ? esc_url_raw( $_POST['bank_qr_url'] ) : '' );

			// Save multi-branch QR settings
			$qr_per_branch = isset( $_POST['bank_qr_per_branch'] ) && $_POST['bank_qr_per_branch'] === '1' ? '1' : '0';
			update_option( 'checkin_bank_qr_per_branch', $qr_per_branch );

			if ( $qr_per_branch === '1' && isset( $_POST['bank_qr_branches'] ) && is_array( $_POST['bank_qr_branches'] ) ) {
				$branch_qrs = [];
				foreach ( $_POST['bank_qr_branches'] as $branch_id => $qr_url ) {
					$branch_id                  = absint( $branch_id );
					$branch_qrs[ $branch_id ]   = esc_url_raw( $qr_url );
				}
				update_option( 'checkin_bank_qr_branches', $branch_qrs );
			}
		}

		// Note config (note_prefix, note_syntax, polling_interval) giờ
		// quản lý qua MonkeyPay plugin gateway UI — không lưu ở Checkin nữa.
		// Phần read vẫn giữ fallback chain cho backward compatibility.

		error_log( 'Bank settings saved successfully in mode: ' . $auto_mode );
	}

	/**
	 * Register a bank session on MonkeyPay server.
	 *
	 * Calls POST /api/transactions/sessions using X-Api-Key.
	 *
	 * @param string $username   MB Bank username.
	 * @param string $session_id MB Bank session token.
	 * @param string $device_id  MB Bank device ID.
	 */
	private function register_monkeypay_bank_session( $username, $session_id, $device_id ) {
		$api_url = checkin_mkt192_get_monkeypay_url();
		$api_key = get_option( 'monkeypay_api_key', '' );

		if ( empty( $api_key ) ) {
			error_log( '[MonkeyPay] Cannot register session: API key missing.' );
			return;
		}

		// Get account number (from manual field or stored option)
		$account_number = isset( $_POST['mb_account_number'] )
			? sanitize_text_field( $_POST['mb_account_number'] )
			: get_option( 'checkin_mp_mb_account_number', '' );

		if ( ! empty( $account_number ) ) {
			update_option( 'checkin_mp_mb_account_number', $account_number );
		}

		$url  = rtrim( $api_url, '/' ) . '/api/transactions/sessions';
		$body = [
			'username'       => $username,
			'account_number' => $account_number,
			'session_id'     => $session_id,
			'device_id'      => $device_id,
		];

		$response = wp_remote_post( $url, [
			'method'  => 'POST',
			'timeout' => 30,
			'headers' => [
				'Content-Type' => 'application/json',
				'X-Api-Key'    => $api_key,
			],
			'body'    => wp_json_encode( $body ),
		]);

		if ( is_wp_error( $response ) ) {
			error_log( '[MonkeyPay] Session registration failed: ' . $response->get_error_message() );
			return;
		}

		$code = wp_remote_retrieve_response_code( $response );
		$data = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( $code === 201 && ! empty( $data['session_id'] ) ) {
			update_option( 'checkin_mp_session_db_id', $data['session_id'] );
			error_log( '[MonkeyPay] Session registered successfully: #' . $data['session_id'] );
		} else {
			$err = isset( $data['error'] ) ? $data['error'] : 'HTTP ' . $code;
			error_log( '[MonkeyPay] Session registration error: ' . $err );
		}
	}

	/**
	 * Save Momo settings
	 */
	private function save_momo_settings() {
		// Get auto mode
		$auto_mode = isset( $_POST['momo_auto_mode'] ) && $_POST['momo_auto_mode'] === '1' ? '1' : '0';
		update_option( 'checkin_momo_auto_mode', $auto_mode );

		if ( $auto_mode === '1' ) {
			// Save full API configuration
			update_option( 'checkin_momo_mode', isset( $_POST['momo_mode'] ) ? sanitize_text_field( $_POST['momo_mode'] ) : 'sandbox' );
			update_option( 'checkin_momo_partner_code', isset( $_POST['momo_partner_code'] ) ? sanitize_text_field( $_POST['momo_partner_code'] ) : '' );
			update_option( 'checkin_momo_access_key', isset( $_POST['momo_access_key'] ) ? sanitize_text_field( $_POST['momo_access_key'] ) : '' );
			update_option( 'checkin_momo_secret_key', isset( $_POST['momo_secret_key'] ) ? sanitize_text_field( $_POST['momo_secret_key'] ) : '' );
			update_option( 'checkin_momo_phone', isset( $_POST['momo_phone'] ) ? sanitize_text_field( $_POST['momo_phone'] ) : '' );
			update_option( 'checkin_momo_qr_code', isset( $_POST['momo_qr_code'] ) ? esc_url_raw( $_POST['momo_qr_code'] ) : '' );
		} else {
			// Save only basic manual configuration
			update_option( 'checkin_momo_account', isset( $_POST['momo_account'] ) ? sanitize_text_field( $_POST['momo_account'] ) : '' );
			update_option( 'checkin_momo_qr_url', isset( $_POST['momo_qr_url'] ) ? esc_url_raw( $_POST['momo_qr_url'] ) : '' );
		}
		error_log( 'Momo settings saved successfully in mode: ' . $auto_mode );
	}

	/**
	 * Save ZaloPay settings
	 */
	private function save_zalopay_settings() {
		// Get auto mode
		$auto_mode = isset( $_POST['zalopay_auto_mode'] ) && $_POST['zalopay_auto_mode'] === '1' ? '1' : '0';
		update_option( 'checkin_zalopay_auto_mode', $auto_mode );

		if ( $auto_mode === '1' ) {
			// Save full API configuration
			update_option( 'checkin_zalopay_mode', isset( $_POST['zalopay_mode'] ) ? sanitize_text_field( $_POST['zalopay_mode'] ) : 'sandbox' );
			update_option( 'checkin_zalopay_app_id', isset( $_POST['zalopay_app_id'] ) ? sanitize_text_field( $_POST['zalopay_app_id'] ) : '' );
			update_option( 'checkin_zalopay_key1', isset( $_POST['zalopay_key1'] ) ? sanitize_text_field( $_POST['zalopay_key1'] ) : '' );
			update_option( 'checkin_zalopay_key2', isset( $_POST['zalopay_key2'] ) ? sanitize_text_field( $_POST['zalopay_key2'] ) : '' );
			update_option( 'checkin_zalopay_callback_url', isset( $_POST['zalopay_callback_url'] ) ? esc_url_raw( $_POST['zalopay_callback_url'] ) : '' );
		} else {
			// Save only basic manual configuration
			update_option( 'checkin_zalopay_account', isset( $_POST['zalopay_account'] ) ? sanitize_text_field( $_POST['zalopay_account'] ) : '' );
			update_option( 'checkin_zalopay_qr_url', isset( $_POST['zalopay_qr_url'] ) ? esc_url_raw( $_POST['zalopay_qr_url'] ) : '' );
		}
		error_log( 'ZaloPay settings saved successfully in mode: ' . $auto_mode );
	}

	/**
	 * AJAX handler to delete payment info
	 */
	public function ajax_delete_payment_info() {
		// Check nonce
		check_ajax_referer( 'checkin-admin-nonce', 'nonce' );

		// Check capabilities
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( [ 'message' => __( 'Bạn không có quyền thực hiện hành động này.', 'checkin-mkt192-wp' ) ] );
		}

		// Get payment type
		$payment_type = isset( $_POST['payment_type'] ) ? sanitize_key( $_POST['payment_type'] ) : '';

		if ( empty( $payment_type ) ) {
			wp_send_json_error( [ 'message' => __( 'Loại thanh toán không hợp lệ.', 'checkin-mkt192-wp' ) ] );
		}

		// Delete based on payment type
		switch ( $payment_type ) {
			case 'bank':
				delete_option( 'checkin_use_bank_transfer' );
				delete_option( 'checkin_bank_auto_mode' );
				delete_option( 'checkin_bank_account' );
				delete_option( 'checkin_bank_qr_url' );
				delete_option( 'checkin_bank_name' );
				delete_option( 'checkin_bank_account_number' );
				delete_option( 'checkin_bank_account_name' );
				delete_option( 'checkin_bank_branch' );
				delete_option( 'checkin_bank_qr_code' );
				delete_option( 'checkin_bank_instructions' );
				break;

			case 'momo':
				delete_option( 'checkin_use_momo' );
				delete_option( 'checkin_momo_auto_mode' );
				delete_option( 'checkin_momo_account' );
				delete_option( 'checkin_momo_qr_url' );
				delete_option( 'checkin_momo_mode' );
				delete_option( 'checkin_momo_partner_code' );
				delete_option( 'checkin_momo_access_key' );
				delete_option( 'checkin_momo_secret_key' );
				delete_option( 'checkin_momo_phone' );
				delete_option( 'checkin_momo_qr_code' );
				break;

			case 'zalopay':
				delete_option( 'checkin_use_zalopay' );
				delete_option( 'checkin_zalopay_auto_mode' );
				delete_option( 'checkin_zalopay_account' );
				delete_option( 'checkin_zalopay_qr_url' );
				delete_option( 'checkin_zalopay_mode' );
				delete_option( 'checkin_zalopay_app_id' );
				delete_option( 'checkin_zalopay_key1' );
				delete_option( 'checkin_zalopay_key2' );
				delete_option( 'checkin_zalopay_callback_url' );
				break;

			default:
				wp_send_json_error( [ 'message' => __( 'Loại thanh toán không được hỗ trợ.', 'checkin-mkt192-wp' ) ] );
		}

		wp_send_json_success( [
			'message' => __( 'Thông tin đã được xóa thành công!', 'checkin-mkt192-wp' ),
		] );
	}
}
?>
