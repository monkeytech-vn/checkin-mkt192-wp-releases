<?php
/**
 * License Page
 *
 * Quản lý license key và kích hoạt plugin
 *
 * @package    Checkin_MKT192_WP
 * @subpackage Admin/Pages
 * @since      5.1.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Checkin_MKT192_WP_License_Page
 */
class Checkin_MKT192_WP_License_Page {

    /**
     * Option name
     */
    const OPTION_NAME = 'checkin_mkt192_license';

    /**
     * Singleton instance
     */
    private static $instance = null;

    /**
     * Get singleton instance
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct() {
        add_action( 'admin_init', [ $this, 'handle_actions' ] );
    }

    /**
     * Render page content
     */
    public function render() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( __( 'Bạn không có quyền truy cập trang này.', 'checkin-mkt192-wp' ) );
        }

        $license_data    = get_option( self::OPTION_NAME, [] );
        $license_key     = isset( $license_data['key'] ) ? $license_data['key'] : '';
        $license_status  = isset( $license_data['status'] ) ? $license_data['status'] : 'inactive';
        $license_expires = isset( $license_data['expires'] ) ? $license_data['expires'] : '';
        $license_type    = isset( $license_data['type'] ) ? $license_data['type'] : '';
        ?>
<div class="wrap checkin-admin-wrapper">
    <?php include CHECKIN_PLUGIN_DIR . 'admin/partials/global-header.php'; ?>
    <div class="checkin-admin-page">
        <!-- Page Header -->
        <div class="checkin-page-header">
            <div class="checkin-page-header-content">
                <h1 class="checkin-page-title">
                    <span class="dashicons dashicons-admin-network"></span>
                    <?php esc_html_e( 'Giấy phép', 'checkin-mkt192-wp' ); ?>
                </h1>
                <p class="checkin-page-description">
                    <?php esc_html_e( 'Quản lý license key và kích hoạt plugin.', 'checkin-mkt192-wp' ); ?>
                </p>
            </div>
        </div>

        <!-- License Status -->
        <div class="checkin-card">
            <div class="checkin-card-header">
                <h3><?php esc_html_e( 'Trạng thái License', 'checkin-mkt192-wp' ); ?>
                </h3>
            </div>
            <div class="checkin-card-body">
                <?php if ( $license_status === 'active' ) : ?>
                <div class="checkin-license-status checkin-license-active">
                    <div class="checkin-license-status-icon">
                        <span class="dashicons dashicons-yes-alt"></span>
                    </div>
                    <div class="checkin-license-status-content">
                        <h4><?php esc_html_e( 'License đang hoạt động', 'checkin-mkt192-wp' ); ?>
                        </h4>
                        <p><?php esc_html_e( 'Plugin của bạn đã được kích hoạt và đang hoạt động bình thường.', 'checkin-mkt192-wp' ); ?>
                        </p>
                        <?php if ( $license_type ) : ?>
                        <p><strong><?php esc_html_e( 'Loại:', 'checkin-mkt192-wp' ); ?></strong>
                            <?php echo esc_html( ucfirst( $license_type ) ); ?>
                        </p>
                        <?php endif; ?>
                        <?php if ( $license_expires ) : ?>
                        <p><strong><?php esc_html_e( 'Hết hạn:', 'checkin-mkt192-wp' ); ?></strong>
                            <?php echo esc_html( date_i18n( get_option( 'date_format' ), strtotime( $license_expires ) ) ); ?>
                        </p>
                        <?php endif; ?>
                    </div>
                </div>
                <?php else : ?>
                <div class="checkin-license-status checkin-license-inactive">
                    <div class="checkin-license-status-icon">
                        <span class="dashicons dashicons-warning"></span>
                    </div>
                    <div class="checkin-license-status-content">
                        <h4><?php esc_html_e( 'License chưa kích hoạt', 'checkin-mkt192-wp' ); ?>
                        </h4>
                        <p><?php esc_html_e( 'Vui lòng nhập license key để kích hoạt plugin và nhận được các tính năng đầy đủ.', 'checkin-mkt192-wp' ); ?>
                        </p>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- License Form -->
        <div class="checkin-card">
            <div class="checkin-card-header">
                <h3><?php echo $license_status === 'active' ? esc_html__( 'Thông tin License', 'checkin-mkt192-wp' ) : esc_html__( 'Kích hoạt License', 'checkin-mkt192-wp' ); ?>
                </h3>
            </div>
            <div class="checkin-card-body">
                <?php if ( $license_status === 'active' ) : ?>
                <!-- Show masked license key -->
                <div class="checkin-form-group">
                    <label class="checkin-form-label"><?php esc_html_e( 'License Key', 'checkin-mkt192-wp' ); ?></label>
                    <div class="checkin-license-key-display">
                        <code><?php echo esc_html( $this->mask_license_key( $license_key ) ); ?></code>
                    </div>
                </div>

                <!-- Deactivate button -->
                <form method="post" action=""
                    onsubmit="return confirm('<?php esc_attr_e( 'Bạn có chắc muốn huỷ kích hoạt license?', 'checkin-mkt192-wp' ); ?>');">
                    <?php wp_nonce_field( 'checkin_deactivate_license', 'checkin_license_nonce' ); ?>
                    <input type="hidden" name="action" value="deactivate_license">
                    <button type="submit" class="checkin-btn checkin-btn-danger">
                        <span class="dashicons dashicons-dismiss"></span>
                        <?php esc_html_e( 'Huỷ kích hoạt License', 'checkin-mkt192-wp' ); ?>
                    </button>
                </form>
                <?php else : ?>
                <!-- Activation form -->
                <form method="post" action="" id="checkin-license-form">
                    <?php wp_nonce_field( 'checkin_activate_license', 'checkin_license_nonce' ); ?>
                    <input type="hidden" name="action" value="activate_license">

                    <div class="checkin-form-group">
                        <label class="checkin-form-label" for="license_key">
                            <?php esc_html_e( 'License Key', 'checkin-mkt192-wp' ); ?>
                            <span class="checkin-required">*</span>
                        </label>
                        <input type="text" id="license_key" name="license_key" class="checkin-form-control"
                            value="<?php echo esc_attr( $license_key ); ?>"
                            placeholder="<?php esc_attr_e( 'Nhập license key của bạn', 'checkin-mkt192-wp' ); ?>"
                            required>
                        <p class="checkin-form-help">
                            <?php esc_html_e( 'License key được gửi qua email khi bạn mua plugin.', 'checkin-mkt192-wp' ); ?>
                        </p>
                    </div>

                    <button type="submit" class="checkin-btn checkin-btn-primary">
                        <span class="dashicons dashicons-yes"></span>
                        <?php esc_html_e( 'Kích hoạt License', 'checkin-mkt192-wp' ); ?>
                    </button>
                </form>
                <?php endif; ?>
            </div>
        </div>

        <!-- License Info -->
        <div class="checkin-grid" style="grid-template-columns: 1fr 1fr;">
            <div class="checkin-card">
                <div class="checkin-card-header">
                    <h3><?php esc_html_e( 'Thông tin hỗ trợ', 'checkin-mkt192-wp' ); ?>
                    </h3>
                </div>
                <div class="checkin-card-body">
                    <div class="checkin-info-list">
                        <div class="checkin-info-item">
                            <span class="dashicons dashicons-email"></span>
                            <div>
                                <strong><?php esc_html_e( 'Email hỗ trợ', 'checkin-mkt192-wp' ); ?></strong>
                                <p><a href="mailto:support@mkt192.com">support@mkt192.com</a></p>
                            </div>
                        </div>
                        <div class="checkin-info-item">
                            <span class="dashicons dashicons-book"></span>
                            <div>
                                <strong><?php esc_html_e( 'Tài liệu', 'checkin-mkt192-wp' ); ?></strong>
                                <p><a href="https://docs.mkt192.com" target="_blank">docs.mkt192.com</a></p>
                            </div>
                        </div>
                        <div class="checkin-info-item">
                            <span class="dashicons dashicons-admin-site"></span>
                            <div>
                                <strong><?php esc_html_e( 'Website', 'checkin-mkt192-wp' ); ?></strong>
                                <p><a href="https://mkt192.com" target="_blank">mkt192.com</a></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="checkin-card">
                <div class="checkin-card-header">
                    <h3><?php esc_html_e( 'Câu hỏi thường gặp', 'checkin-mkt192-wp' ); ?>
                    </h3>
                </div>
                <div class="checkin-card-body">
                    <div class="checkin-faq-list">
                        <div class="checkin-faq-item">
                            <strong><?php esc_html_e( 'License key ở đâu?', 'checkin-mkt192-wp' ); ?></strong>
                            <p><?php esc_html_e( 'License key được gửi qua email khi bạn mua plugin. Kiểm tra hộp thư spam nếu không thấy.', 'checkin-mkt192-wp' ); ?>
                            </p>
                        </div>
                        <div class="checkin-faq-item">
                            <strong><?php esc_html_e( 'Một license dùng cho mấy trang?', 'checkin-mkt192-wp' ); ?></strong>
                            <p><?php esc_html_e( 'Phụ thuộc vào gói bạn mua: Single (1 trang), Developer (5 trang), hoặc Agency (không giới hạn).', 'checkin-mkt192-wp' ); ?>
                            </p>
                        </div>
                        <div class="checkin-faq-item">
                            <strong><?php esc_html_e( 'License hết hạn thì sao?', 'checkin-mkt192-wp' ); ?></strong>
                            <p><?php esc_html_e( 'Plugin vẫn hoạt động nhưng bạn sẽ không nhận được cập nhật và hỗ trợ. Gia hạn để tiếp tục nhận benefits.', 'checkin-mkt192-wp' ); ?>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Upgrade Options -->
        <?php if ( $license_status === 'active' && $license_type !== 'agency' ) : ?>
        <div class="checkin-card">
            <div class="checkin-card-header">
                <h3><?php esc_html_e( 'Nâng cấp gói License', 'checkin-mkt192-wp' ); ?>
                </h3>
            </div>
            <div class="checkin-card-body">
                <div class="checkin-upgrade-grid">
                    <?php if ( $license_type === 'single' ) : ?>
                    <div class="checkin-upgrade-option">
                        <h4>Developer License</h4>
                        <p class="checkin-upgrade-price">$149 <span>/năm</span></p>
                        <ul>
                            <li><?php esc_html_e( 'Sử dụng cho 5 trang web', 'checkin-mkt192-wp' ); ?>
                            </li>
                            <li><?php esc_html_e( 'Cập nhật không giới hạn', 'checkin-mkt192-wp' ); ?>
                            </li>
                            <li><?php esc_html_e( 'Hỗ trợ ưu tiên', 'checkin-mkt192-wp' ); ?>
                            </li>
                        </ul>
                        <a href="https://mkt192.com/upgrade" class="checkin-btn checkin-btn-primary" target="_blank">
                            <?php esc_html_e( 'Nâng cấp ngay', 'checkin-mkt192-wp' ); ?>
                        </a>
                    </div>
                    <?php endif; ?>

                    <div class="checkin-upgrade-option checkin-upgrade-featured">
                        <span
                            class="checkin-badge checkin-badge-primary"><?php esc_html_e( 'Phổ biến nhất', 'checkin-mkt192-wp' ); ?></span>
                        <h4>Agency License</h4>
                        <p class="checkin-upgrade-price">$299 <span>/năm</span></p>
                        <ul>
                            <li><?php esc_html_e( 'Không giới hạn trang web', 'checkin-mkt192-wp' ); ?>
                            </li>
                            <li><?php esc_html_e( 'Cập nhật không giới hạn', 'checkin-mkt192-wp' ); ?>
                            </li>
                            <li><?php esc_html_e( 'Hỗ trợ VIP 24/7', 'checkin-mkt192-wp' ); ?>
                            </li>
                            <li><?php esc_html_e( 'White label option', 'checkin-mkt192-wp' ); ?>
                            </li>
                        </ul>
                        <a href="https://mkt192.com/upgrade" class="checkin-btn checkin-btn-primary" target="_blank">
                            <?php esc_html_e( 'Nâng cấp ngay', 'checkin-mkt192-wp' ); ?>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php
    }

    /**
     * Handle license actions
     */
    public function handle_actions() {
        if ( ! isset( $_POST['action'] ) || ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $action = sanitize_text_field( $_POST['action'] );

        if ( $action === 'activate_license' ) {
            if ( ! isset( $_POST['checkin_license_nonce'] ) ||
                 ! wp_verify_nonce( $_POST['checkin_license_nonce'], 'checkin_activate_license' ) ) {
                wp_die( __( 'Nonce verification failed', 'checkin-mkt192-wp' ) );
            }

            $license_key = isset( $_POST['license_key'] ) ? sanitize_text_field( $_POST['license_key'] ) : '';

            if ( empty( $license_key ) ) {
                wp_redirect( add_query_arg( [
                    'page'    => 'checkin-mkt192-license',
                    'message' => 'empty_key',
                ], admin_url( 'admin.php' ) ) );
                exit;
            }

            // TODO: Implement actual license validation with API
            $result = $this->validate_license( $license_key );

            if ( $result['success'] ) {
                update_option( self::OPTION_NAME, [
                    'key'     => $license_key,
                    'status'  => 'active',
                    'type'    => $result['type'],
                    'expires' => $result['expires'],
                ] );

                wp_redirect( add_query_arg( [
                    'page'    => 'checkin-mkt192-license',
                    'message' => 'activated',
                ], admin_url( 'admin.php' ) ) );
            } else {
                wp_redirect( add_query_arg( [
                    'page'    => 'checkin-mkt192-license',
                    'message' => 'invalid_key',
                ], admin_url( 'admin.php' ) ) );
            }
            exit;

        } elseif ( $action === 'deactivate_license' ) {
            if ( ! isset( $_POST['checkin_license_nonce'] ) ||
                 ! wp_verify_nonce( $_POST['checkin_license_nonce'], 'checkin_deactivate_license' ) ) {
                wp_die( __( 'Nonce verification failed', 'checkin-mkt192-wp' ) );
            }

            // TODO: Implement actual license deactivation with API
            delete_option( self::OPTION_NAME );

            wp_redirect( add_query_arg( [
                'page'    => 'checkin-mkt192-license',
                'message' => 'deactivated',
            ], admin_url( 'admin.php' ) ) );
            exit;
        }
    }

    /**
     * Validate license with remote API
     */
    private function validate_license( $license_key ) {
        // TODO: Replace with actual API call
        // For now, return dummy success for testing
        return [
            'success' => true,
            'type'    => 'single',
            'expires' => date( 'Y-m-d', strtotime( '+1 year' ) ),
        ];
    }

    /**
     * Mask license key for display
     */
    private function mask_license_key( $key ) {
        if ( strlen( $key ) <= 8 ) {
            return $key;
        }
        return substr( $key, 0, 4 ) . str_repeat( '*', strlen( $key ) - 8 ) . substr( $key, -4 );
    }
}
?>