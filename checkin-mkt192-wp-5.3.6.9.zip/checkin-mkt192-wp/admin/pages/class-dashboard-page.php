<?php
/**
 * Dashboard Page
 *
 * Trang tổng quan hiển thị thống kê thật từ dữ liệu vận hành:
 * lịch hẹn, doanh thu, khách hàng, đánh giá, nhân sự và trạng thái kết nối.
 *
 * @package    Checkin_MKT192_WP
 * @subpackage Admin/Pages
 * @since      5.1.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Checkin_MKT192_WP_Dashboard_Page
 *
 * Xử lý hiển thị dashboard và các widget thống kê
 */
class Checkin_MKT192_WP_Dashboard_Page {

    /**
     * Singleton instance
     */
    private static $instance = null;

    /**
     * Get singleton instance
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct() {
        // Constructor
    }

    /**
     * Format tiền VND: 1250000 -> 1.250.000đ
     */
    private function fmt_money( $amount ) {
        return number_format( (float) $amount, 0, ',', '.' ) . 'đ';
    }

    /**
     * Rút gọn tiền cho thẻ thống kê: 125430000 -> 125,4tr
     */
    private function fmt_money_short( $amount ) {
        $amount = (float) $amount;
        if ( $amount >= 1000000000 ) {
            return str_replace( '.', ',', (string) round( $amount / 1000000000, 2 ) ) . ' tỷ';
        }
        if ( $amount >= 1000000 ) {
            return str_replace( '.', ',', (string) round( $amount / 1000000, 1 ) ) . 'tr';
        }
        return number_format( $amount, 0, ',', '.' );
    }

    /**
     * Thời gian tương đối "x phút trước" (an toàn khi lệch múi giờ)
     */
    private function time_ago( $mysql_datetime ) {
        $ts  = strtotime( $mysql_datetime );
        $now = current_time( 'timestamp' );
        if ( ! $ts ) {
            return '';
        }
        if ( abs( $now - $ts ) < 60 ) {
            return __( 'Vừa xong', 'checkin-mkt192-wp' );
        }
        if ( $ts > $now ) {
            return wp_date( 'd/m H:i', $ts );
        }
        return human_time_diff( $ts, $now ) . ' ' . __( 'trước', 'checkin-mkt192-wp' );
    }

    /**
     * Render page content
     */
    public function render() {
        // Check user capabilities
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( __( 'Bạn không có quyền truy cập trang này.', 'checkin-mkt192-wp' ) );
        }

        $stats      = $this->get_statistics();
        $alerts     = $this->get_pending_alerts();
        $chart      = $this->get_revenue_last_7_days();
        $reviews    = $this->get_review_summary();
        $top_staff  = $this->get_top_staff_this_month();
        $activities = $this->get_recent_activities();
        ?>
<div class="wrap checkin-admin-wrapper">
    <?php include CHECKIN_PLUGIN_DIR . 'admin/partials/global-header.php'; ?>
    <div class="checkin-admin-page">
        <!-- Page Header -->
        <div class="checkin-page-header">
            <div class="checkin-page-header-content">
                <h1 class="checkin-page-title">
                    <span class="dashicons dashicons-dashboard"></span>
                    <?php esc_html_e( 'Tổng quan', 'checkin-mkt192-wp' ); ?>
                </h1>
                <p class="checkin-page-description">
                    <?php
                    printf(
                        /* translators: %s: current date */
                        esc_html__( 'Số liệu vận hành cập nhật đến %s.', 'checkin-mkt192-wp' ),
                        esc_html( wp_date( 'H:i d/m/Y', current_time( 'timestamp' ) ) )
                    );
                    ?>
                </p>
            </div>
            <div class="checkin-page-header-actions">
                <button type="button" class="checkin-btn checkin-btn-secondary" id="refresh-dashboard"
                    onclick="window.location.reload();">
                    <span class="dashicons dashicons-update"></span>
                    <?php esc_html_e( 'Làm mới', 'checkin-mkt192-wp' ); ?>
                </button>
            </div>
        </div>

        <?php if ( ! empty( $alerts ) ) : ?>
        <!-- Pending items that need admin attention -->
        <div class="checkin-alert-strip">
            <span class="checkin-alert-strip-title">
                <span class="dashicons dashicons-bell"></span>
                <?php esc_html_e( 'Cần chú ý:', 'checkin-mkt192-wp' ); ?>
            </span>
            <?php foreach ( $alerts as $alert ) : ?>
            <span class="checkin-badge checkin-badge-warning"><?php echo esc_html( $alert ); ?></span>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <!-- Statistics Cards -->
        <div class="checkin-stats-grid">
            <!-- Bookings today -->
            <div class="checkin-stat-card">
                <div class="checkin-stat-icon checkin-stat-icon-primary">
                    <span class="dashicons dashicons-calendar-alt"></span>
                </div>
                <div class="checkin-stat-content">
                    <div class="checkin-stat-value">
                        <?php echo esc_html( number_format_i18n( $stats['bookings_today'] ) ); ?>
                    </div>
                    <div class="checkin-stat-label">
                        <?php esc_html_e( 'Lịch hẹn hôm nay', 'checkin-mkt192-wp' ); ?>
                    </div>
                    <div class="checkin-stat-change checkin-stat-change-neutral">
                        <?php
                        printf(
                            /* translators: %s: number of bookings this month */
                            esc_html__( '%s lịch trong tháng', 'checkin-mkt192-wp' ),
                            esc_html( number_format_i18n( $stats['bookings_month'] ) )
                        );
                        ?>
                    </div>
                </div>
            </div>

            <!-- Revenue this month -->
            <div class="checkin-stat-card">
                <div class="checkin-stat-icon checkin-stat-icon-success">
                    <span class="dashicons dashicons-chart-line"></span>
                </div>
                <div class="checkin-stat-content">
                    <div class="checkin-stat-value">
                        <?php echo esc_html( $this->fmt_money_short( $stats['revenue_month'] ) ); ?>
                    </div>
                    <div class="checkin-stat-label">
                        <?php esc_html_e( 'Doanh thu tháng này', 'checkin-mkt192-wp' ); ?>
                    </div>
                    <?php if ( null !== $stats['revenue_change'] && $stats['revenue_change'] >= 0 ) : ?>
                    <div class="checkin-stat-change checkin-stat-change-positive">
                        <span class="dashicons dashicons-arrow-up-alt"></span>
                        <?php echo esc_html( $stats['revenue_change'] ); ?>%
                        <?php esc_html_e( 'so với cùng kỳ tháng trước', 'checkin-mkt192-wp' ); ?>
                    </div>
                    <?php elseif ( null !== $stats['revenue_change'] ) : ?>
                    <div class="checkin-stat-change checkin-stat-change-negative">
                        <span class="dashicons dashicons-arrow-down-alt"></span>
                        <?php echo esc_html( abs( $stats['revenue_change'] ) ); ?>%
                        <?php esc_html_e( 'so với cùng kỳ tháng trước', 'checkin-mkt192-wp' ); ?>
                    </div>
                    <?php else : ?>
                    <div class="checkin-stat-change checkin-stat-change-neutral">
                        <?php esc_html_e( 'Chưa có dữ liệu tháng trước', 'checkin-mkt192-wp' ); ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Invoices this month -->
            <div class="checkin-stat-card">
                <div class="checkin-stat-icon checkin-stat-icon-warning">
                    <span class="dashicons dashicons-media-text"></span>
                </div>
                <div class="checkin-stat-content">
                    <div class="checkin-stat-value">
                        <?php echo esc_html( number_format_i18n( $stats['invoices_month'] ) ); ?>
                    </div>
                    <div class="checkin-stat-label">
                        <?php esc_html_e( 'Hóa đơn tháng này', 'checkin-mkt192-wp' ); ?>
                    </div>
                    <div class="checkin-stat-change checkin-stat-change-neutral">
                        <?php
                        printf(
                            /* translators: 1: invoices today, 2: revenue today */
                            esc_html__( 'Hôm nay: %1$s hóa đơn • %2$s', 'checkin-mkt192-wp' ),
                            esc_html( number_format_i18n( $stats['invoices_today'] ) ),
                            esc_html( $this->fmt_money_short( $stats['revenue_today'] ) )
                        );
                        ?>
                    </div>
                </div>
            </div>

            <!-- Customers -->
            <div class="checkin-stat-card">
                <div class="checkin-stat-icon checkin-stat-icon-info">
                    <span class="dashicons dashicons-groups"></span>
                </div>
                <div class="checkin-stat-content">
                    <div class="checkin-stat-value">
                        <?php echo esc_html( number_format_i18n( $stats['customers_total'] ) ); ?>
                    </div>
                    <div class="checkin-stat-label">
                        <?php esc_html_e( 'Khách hàng', 'checkin-mkt192-wp' ); ?>
                    </div>
                    <?php if ( $stats['customers_new_month'] > 0 ) : ?>
                    <div class="checkin-stat-change checkin-stat-change-positive">
                        <span class="dashicons dashicons-plus-alt2"></span>
                        <?php
                        printf(
                            /* translators: %s: new customers this month */
                            esc_html__( '%s khách mới trong tháng', 'checkin-mkt192-wp' ),
                            esc_html( number_format_i18n( $stats['customers_new_month'] ) )
                        );
                        ?>
                    </div>
                    <?php else : ?>
                    <div class="checkin-stat-change checkin-stat-change-neutral">
                        <?php esc_html_e( 'Chưa có khách mới trong tháng', 'checkin-mkt192-wp' ); ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Revenue chart + Reviews -->
        <div class="checkin-grid" style="grid-template-columns: 2fr 1fr;">
            <div class="checkin-card">
                <div class="checkin-card-header">
                    <h3><?php esc_html_e( 'Doanh thu 7 ngày gần nhất', 'checkin-mkt192-wp' ); ?></h3>
                    <span class="checkin-badge checkin-badge-primary">
                        <?php echo esc_html( $this->fmt_money( $chart['total'] ) ); ?>
                    </span>
                </div>
                <div class="checkin-card-body">
                    <?php $this->render_revenue_chart( $chart ); ?>
                </div>
            </div>

            <div class="checkin-card">
                <div class="checkin-card-header">
                    <h3><?php esc_html_e( 'Đánh giá 30 ngày qua', 'checkin-mkt192-wp' ); ?></h3>
                </div>
                <div class="checkin-card-body">
                    <?php $this->render_review_summary( $reviews ); ?>
                </div>
            </div>
        </div>

        <!-- Recent Activity + Top staff -->
        <div class="checkin-grid" style="grid-template-columns: 2fr 1fr;">
            <div class="checkin-card">
                <div class="checkin-card-header">
                    <h3><?php esc_html_e( 'Hoạt động gần đây', 'checkin-mkt192-wp' ); ?></h3>
                </div>
                <div class="checkin-card-body">
                    <?php $this->render_recent_activity( $activities ); ?>
                </div>
            </div>

            <div class="checkin-card">
                <div class="checkin-card-header">
                    <h3><?php esc_html_e( 'Top thợ tháng này', 'checkin-mkt192-wp' ); ?></h3>
                </div>
                <div class="checkin-card-body">
                    <?php $this->render_top_staff( $top_staff ); ?>
                </div>
            </div>
        </div>

        <!-- System status + Quick Actions -->
        <div class="checkin-grid" style="grid-template-columns: 1fr 1fr;">
            <div class="checkin-card">
                <div class="checkin-card-header">
                    <h3><?php esc_html_e( 'Trạng thái hệ thống & kết nối', 'checkin-mkt192-wp' ); ?></h3>
                </div>
                <div class="checkin-card-body">
                    <?php $this->render_system_status(); ?>
                </div>
            </div>

            <div class="checkin-card">
                <div class="checkin-card-header">
                    <h3><?php esc_html_e( 'Hành động nhanh', 'checkin-mkt192-wp' ); ?></h3>
                </div>
                <div class="checkin-card-body">
                    <div class="checkin-quick-actions">
                        <a href="<?php echo esc_url( admin_url( 'admin.php?page=checkin-mkt192-brand-settings' ) ); ?>"
                            class="checkin-quick-action">
                            <span class="dashicons dashicons-admin-appearance"></span>
                            <span><?php esc_html_e( 'Cài đặt thương hiệu', 'checkin-mkt192-wp' ); ?></span>
                        </a>
                        <a href="<?php echo esc_url( admin_url( 'admin.php?page=checkin-mkt192-connections' ) ); ?>"
                            class="checkin-quick-action">
                            <span class="dashicons dashicons-admin-plugins"></span>
                            <span><?php esc_html_e( 'Kết nối dịch vụ', 'checkin-mkt192-wp' ); ?></span>
                        </a>
                        <a href="<?php echo esc_url( admin_url( 'admin.php?page=checkin-mkt192-payments' ) ); ?>"
                            class="checkin-quick-action">
                            <span class="dashicons dashicons-money"></span>
                            <span><?php esc_html_e( 'Thanh toán', 'checkin-mkt192-wp' ); ?></span>
                        </a>
                        <a href="<?php echo esc_url( admin_url( 'admin.php?page=checkin-mkt192-push-notifications' ) ); ?>"
                            class="checkin-quick-action">
                            <span class="dashicons dashicons-megaphone"></span>
                            <span><?php esc_html_e( 'Push Notifications', 'checkin-mkt192-wp' ); ?></span>
                        </a>
                        <a href="<?php echo esc_url( admin_url( 'admin.php?page=checkin-mkt192-shortcodes' ) ); ?>"
                            class="checkin-quick-action">
                            <span class="dashicons dashicons-editor-code"></span>
                            <span><?php esc_html_e( 'Shortcodes', 'checkin-mkt192-wp' ); ?></span>
                        </a>
                        <a href="<?php echo esc_url( admin_url( 'admin.php?page=checkin-mkt192-tools' ) ); ?>"
                            class="checkin-quick-action">
                            <span class="dashicons dashicons-admin-tools"></span>
                            <span><?php esc_html_e( 'Công cụ', 'checkin-mkt192-wp' ); ?></span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
    }

    /**
     * Thống kê chính từ dữ liệu thật
     */
    private function get_statistics() {
        global $wpdb;

        $booking_table  = $wpdb->prefix . 'bookingmkt192_booking_data';
        $invoice_table  = $wpdb->prefix . 'checkin_mkt192_invoices_data';
        $customer_table = $wpdb->prefix . 'bookingmkt192_customer_data';

        $today            = current_time( 'Y-m-d' );
        $month_start      = current_time( 'Y-m-01' );
        $next_month_start = wp_date( 'Y-m-01', strtotime( $month_start . ' +1 month' ) );
        $prev_month_start = wp_date( 'Y-m-01', strtotime( $month_start . ' -1 month' ) );

        // Lịch hẹn (bỏ lịch đã xóa/hủy)
        $bookings_today = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$booking_table} WHERE booking_date = %s AND status != 'deleted'",
            $today
        ) );
        $bookings_month = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$booking_table} WHERE booking_date >= %s AND booking_date < %s AND status != 'deleted'",
            $month_start,
            $next_month_start
        ) );

        // Doanh thu từ hóa đơn đã thanh toán (paid_at có backfill, fallback created_at)
        $revenue_month = (float) $wpdb->get_var( $wpdb->prepare(
            "SELECT COALESCE(SUM(total), 0) FROM {$invoice_table}
             WHERE status = 'paid' AND COALESCE(paid_at, created_at) >= %s AND COALESCE(paid_at, created_at) < %s",
            $month_start,
            $next_month_start
        ) );
        // So sánh cùng kỳ: từ đầu tháng trước đến cùng số ngày đã trôi qua của tháng này
        $days_elapsed     = (int) current_time( 'j' );
        $prev_period_end  = wp_date( 'Y-m-d', strtotime( $prev_month_start . ' +' . $days_elapsed . ' days' ) );
        $revenue_prev_period = (float) $wpdb->get_var( $wpdb->prepare(
            "SELECT COALESCE(SUM(total), 0) FROM {$invoice_table}
             WHERE status = 'paid' AND COALESCE(paid_at, created_at) >= %s AND COALESCE(paid_at, created_at) < %s",
            $prev_month_start,
            $prev_period_end
        ) );
        $revenue_change = $revenue_prev_period > 0
            ? round( ( $revenue_month - $revenue_prev_period ) / $revenue_prev_period * 100, 1 )
            : null;

        $invoices_month = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$invoice_table}
             WHERE status = 'paid' AND COALESCE(paid_at, created_at) >= %s AND COALESCE(paid_at, created_at) < %s",
            $month_start,
            $next_month_start
        ) );
        $today_row = $wpdb->get_row( $wpdb->prepare(
            "SELECT COUNT(*) AS cnt, COALESCE(SUM(total), 0) AS revenue FROM {$invoice_table}
             WHERE status = 'paid' AND DATE(COALESCE(paid_at, created_at)) = %s",
            $today
        ) );

        // Khách hàng
        $customers_total     = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$customer_table}" );
        $customers_new_month = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$customer_table} WHERE created_at >= %s AND created_at < %s",
            $month_start,
            $next_month_start
        ) );

        return [
            'bookings_today'      => $bookings_today,
            'bookings_month'      => $bookings_month,
            'revenue_month'       => $revenue_month,
            'revenue_change'      => $revenue_change,
            'invoices_month'      => $invoices_month,
            'invoices_today'      => $today_row ? (int) $today_row->cnt : 0,
            'revenue_today'       => $today_row ? (float) $today_row->revenue : 0,
            'customers_total'     => $customers_total,
            'customers_new_month' => $customers_new_month,
        ];
    }

    /**
     * Các mục đang chờ xử lý cần admin chú ý
     */
    private function get_pending_alerts() {
        global $wpdb;

        $alerts = [];

        $approval_table = $wpdb->prefix . 'checkin_mkt192_approval_requests';
        $pending_requests = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$approval_table} WHERE status = 'pending'"
        );
        if ( $pending_requests > 0 ) {
            $alerts[] = sprintf(
                /* translators: %s: number of pending approval requests */
                __( '%s đơn xin phép chờ duyệt', 'checkin-mkt192-wp' ),
                number_format_i18n( $pending_requests )
            );
        }

        $invoice_table = $wpdb->prefix . 'checkin_mkt192_invoices_data';
        $pending_invoices = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$invoice_table} WHERE status = 'pending'"
        );
        if ( $pending_invoices > 0 ) {
            $alerts[] = sprintf(
                /* translators: %s: number of unpaid invoices */
                __( '%s hóa đơn chưa thanh toán', 'checkin-mkt192-wp' ),
                number_format_i18n( $pending_invoices )
            );
        }

        // Chỉ tính giao dịch kho 30 ngày gần đây — tồn cũ nhiều năm không còn ý nghĩa xử lý
        $inventory_table = $wpdb->prefix . 'checkin_mkt192_inventory_transactions';
        $pending_inventory = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$inventory_table} WHERE status = 'CHỜ DUYỆT' AND created_at >= %s",
            wp_date( 'Y-m-d H:i:s', strtotime( current_time( 'mysql' ) . ' -30 days' ) )
        ) );
        if ( $pending_inventory > 0 ) {
            $alerts[] = sprintf(
                /* translators: %s: number of pending inventory transactions */
                __( '%s giao dịch kho chờ duyệt', 'checkin-mkt192-wp' ),
                number_format_i18n( $pending_inventory )
            );
        }

        return $alerts;
    }

    /**
     * Doanh thu theo ngày trong 7 ngày gần nhất
     */
    private function get_revenue_last_7_days() {
        global $wpdb;

        $invoice_table = $wpdb->prefix . 'checkin_mkt192_invoices_data';
        $start_date    = wp_date( 'Y-m-d', strtotime( current_time( 'Y-m-d' ) . ' -6 days' ) );

        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT DATE(COALESCE(paid_at, created_at)) AS d, SUM(total) AS revenue
             FROM {$invoice_table}
             WHERE status = 'paid' AND DATE(COALESCE(paid_at, created_at)) >= %s
             GROUP BY DATE(COALESCE(paid_at, created_at))",
            $start_date
        ), OBJECT_K );

        $days  = [];
        $total = 0;
        $max   = 0;
        for ( $i = 6; $i >= 0; $i-- ) {
            $date    = wp_date( 'Y-m-d', strtotime( current_time( 'Y-m-d' ) . " -{$i} days" ) );
            $revenue = isset( $rows[ $date ] ) ? (float) $rows[ $date ]->revenue : 0;
            $days[]  = [
                'label'    => wp_date( 'd/m', strtotime( $date ) ),
                'revenue'  => $revenue,
                'is_today' => 0 === $i,
            ];
            $total += $revenue;
            $max    = max( $max, $revenue );
        }

        return [
            'days'  => $days,
            'total' => $total,
            'max'   => $max,
        ];
    }

    /**
     * Tổng hợp đánh giá 30 ngày (gộp offline + online)
     */
    private function get_review_summary() {
        global $wpdb;

        $off_table    = $wpdb->prefix . 'checkin_mkt192_customer_reviews_off';
        $online_table = $wpdb->prefix . 'checkin_mkt192_customer_reviews_online';
        $since        = wp_date( 'Y-m-d H:i:s', strtotime( current_time( 'mysql' ) . ' -30 days' ) );

        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT COUNT(*) AS cnt, AVG(service_rating) AS avg_service, AVG(staff_rating) AS avg_staff FROM (
                SELECT service_rating, staff_rating, created_at FROM {$off_table} WHERE created_at >= %s
                UNION ALL
                SELECT service_rating, staff_rating, created_at FROM {$online_table} WHERE created_at >= %s
            ) r",
            $since,
            $since
        ) );

        return [
            'count'       => $row ? (int) $row->cnt : 0,
            'avg_service' => $row && $row->avg_service ? round( (float) $row->avg_service, 1 ) : 0,
            'avg_staff'   => $row && $row->avg_staff ? round( (float) $row->avg_staff, 1 ) : 0,
        ];
    }

    /**
     * Top 5 thợ theo doanh thu tháng này (từ chi tiết hóa đơn đã thanh toán)
     */
    private function get_top_staff_this_month() {
        global $wpdb;

        $invoice_table = $wpdb->prefix . 'checkin_mkt192_invoices_data';
        $detail_table  = $wpdb->prefix . 'checkin_mkt192_invoices_data_detail';

        $month_start      = current_time( 'Y-m-01' );
        $next_month_start = wp_date( 'Y-m-01', strtotime( $month_start . ' +1 month' ) );

        // Ép COLLATE khi join: 2 bảng trên DB cũ có collation khác nhau (general_ci vs unicode_ci)
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT d.staff_name, SUM(d.total) AS revenue, COUNT(DISTINCT d.invoice_id) AS invoice_count
             FROM {$detail_table} d
             INNER JOIN {$invoice_table} i
                ON d.invoice_id COLLATE utf8mb4_unicode_ci = i.invoice_id COLLATE utf8mb4_unicode_ci
             WHERE i.status = 'paid'
               AND COALESCE(i.paid_at, i.created_at) >= %s
               AND COALESCE(i.paid_at, i.created_at) < %s
               AND d.staff_name IS NOT NULL AND d.staff_name != ''
             GROUP BY d.staff_name
             ORDER BY revenue DESC
             LIMIT 5",
            $month_start,
            $next_month_start
        ) );
    }

    /**
     * Gộp hoạt động gần đây từ lịch hẹn, hóa đơn, đánh giá và đơn xin phép
     */
    private function get_recent_activities() {
        global $wpdb;

        $items = [];

        // Lịch hẹn mới nhất
        $booking_table = $wpdb->prefix . 'bookingmkt192_booking_data';
        $bookings = $wpdb->get_results(
            "SELECT customer_name, hairdresser_name, booking_date, booking_time, status, created_at
             FROM {$booking_table} WHERE status != 'deleted'
             ORDER BY created_at DESC LIMIT 4"
        );
        foreach ( (array) $bookings as $b ) {
            $items[] = [
                'ts'          => $b->created_at,
                'icon'        => 'dashicons-calendar-alt',
                'icon_color'  => 'primary',
                'title'       => __( 'Lịch hẹn mới', 'checkin-mkt192-wp' ),
                'description' => sprintf(
                    /* translators: 1: customer name, 2: staff name, 3: date, 4: time */
                    __( '%1$s đặt %2$s — %3$s %4$s', 'checkin-mkt192-wp' ),
                    $b->customer_name,
                    $b->hairdresser_name,
                    wp_date( 'd/m', strtotime( $b->booking_date ) ),
                    substr( $b->booking_time, 0, 5 )
                ),
            ];
        }

        // Hóa đơn thanh toán gần nhất
        $invoice_table = $wpdb->prefix . 'checkin_mkt192_invoices_data';
        $invoices = $wpdb->get_results(
            "SELECT invoice_id, customer_name, total, COALESCE(paid_at, created_at) AS ts
             FROM {$invoice_table} WHERE status = 'paid'
             ORDER BY COALESCE(paid_at, created_at) DESC LIMIT 4"
        );
        foreach ( (array) $invoices as $inv ) {
            $items[] = [
                'ts'          => $inv->ts,
                'icon'        => 'dashicons-money-alt',
                'icon_color'  => 'success',
                'title'       => __( 'Thanh toán thành công', 'checkin-mkt192-wp' ),
                'description' => sprintf(
                    /* translators: 1: invoice id, 2: customer name, 3: amount */
                    __( 'Hóa đơn %1$s — %2$s — %3$s', 'checkin-mkt192-wp' ),
                    $inv->invoice_id,
                    $inv->customer_name,
                    $this->fmt_money( $inv->total )
                ),
            ];
        }

        // Đánh giá mới nhất (gộp 2 bảng)
        $off_table    = $wpdb->prefix . 'checkin_mkt192_customer_reviews_off';
        $online_table = $wpdb->prefix . 'checkin_mkt192_customer_reviews_online';
        $reviews = $wpdb->get_results(
            "SELECT customer_name, staff_name, service_rating, staff_rating, created_at FROM (
                SELECT customer_name, staff_name, service_rating, staff_rating, created_at FROM {$off_table}
                UNION ALL
                SELECT customer_name, staff_name, service_rating, staff_rating, created_at FROM {$online_table}
            ) r ORDER BY created_at DESC LIMIT 3"
        );
        foreach ( (array) $reviews as $r ) {
            $rating = round( ( (float) $r->service_rating + (float) $r->staff_rating ) / 2, 1 );
            $items[] = [
                'ts'          => $r->created_at,
                'icon'        => 'dashicons-star-filled',
                'icon_color'  => 'warning',
                'title'       => __( 'Đánh giá mới', 'checkin-mkt192-wp' ),
                'description' => sprintf(
                    /* translators: 1: customer name, 2: staff name, 3: rating */
                    __( '%1$s đánh giá thợ %2$s — %3$s/5 sao', 'checkin-mkt192-wp' ),
                    $r->customer_name,
                    $r->staff_name,
                    $rating
                ),
            ];
        }

        // Đơn xin phép mới nhất
        $approval_table = $wpdb->prefix . 'checkin_mkt192_approval_requests';
        $requests = $wpdb->get_results(
            "SELECT staff_name, request_type, status, created_at
             FROM {$approval_table} ORDER BY created_at DESC LIMIT 3"
        );
        $type_labels = [
            'late_early'     => __( 'xin đi trễ/về sớm', 'checkin-mkt192-wp' ),
            'leave'          => __( 'xin nghỉ phép', 'checkin-mkt192-wp' ),
            'overtime'       => __( 'đăng ký tăng ca', 'checkin-mkt192-wp' ),
            'salary_advance' => __( 'xin ứng lương', 'checkin-mkt192-wp' ),
        ];
        $status_labels = [
            'pending'  => __( 'chờ duyệt', 'checkin-mkt192-wp' ),
            'approved' => __( 'đã duyệt', 'checkin-mkt192-wp' ),
            'rejected' => __( 'từ chối', 'checkin-mkt192-wp' ),
        ];
        foreach ( (array) $requests as $req ) {
            $type_label   = isset( $type_labels[ $req->request_type ] ) ? $type_labels[ $req->request_type ] : $req->request_type;
            $status_label = isset( $status_labels[ $req->status ] ) ? $status_labels[ $req->status ] : $req->status;
            $items[] = [
                'ts'          => $req->created_at,
                'icon'        => 'dashicons-clipboard',
                'icon_color'  => 'pending' === $req->status ? 'danger' : 'info',
                'title'       => __( 'Đơn xin phép', 'checkin-mkt192-wp' ),
                'description' => sprintf( '%1$s %2$s (%3$s)', $req->staff_name, $type_label, $status_label ),
            ];
        }

        // Sắp xếp theo thời gian giảm dần, lấy 8 mục mới nhất
        usort( $items, function ( $a, $b ) {
            return strcmp( $b['ts'], $a['ts'] );
        } );

        return array_slice( $items, 0, 8 );
    }

    /**
     * Render biểu đồ cột doanh thu 7 ngày (CSS thuần)
     */
    private function render_revenue_chart( $chart ) {
        if ( $chart['max'] <= 0 ) {
            echo '<p class="checkin-empty-state">' . esc_html__( 'Chưa có doanh thu trong 7 ngày gần nhất.', 'checkin-mkt192-wp' ) . '</p>';
            return;
        }
        ?>
<div class="checkin-mini-chart">
    <?php foreach ( $chart['days'] as $day ) : ?>
    <?php $height = $chart['max'] > 0 ? max( 2, round( $day['revenue'] / $chart['max'] * 100 ) ) : 2; ?>
    <div class="checkin-mini-chart-col" title="<?php echo esc_attr( $day['label'] . ': ' . $this->fmt_money( $day['revenue'] ) ); ?>">
        <span class="checkin-mini-chart-value">
            <?php echo esc_html( $day['revenue'] > 0 ? $this->fmt_money_short( $day['revenue'] ) : '–' ); ?>
        </span>
        <div class="checkin-mini-chart-bar-wrap">
            <div class="checkin-mini-chart-bar<?php echo $day['is_today'] ? ' is-today' : ''; ?>"
                style="height: <?php echo esc_attr( $height ); ?>%;"></div>
        </div>
        <span class="checkin-mini-chart-label"><?php echo esc_html( $day['label'] ); ?></span>
    </div>
    <?php endforeach; ?>
</div>
<?php
    }

    /**
     * Render tổng hợp đánh giá
     */
    private function render_review_summary( $reviews ) {
        if ( $reviews['count'] <= 0 ) {
            echo '<p class="checkin-empty-state">' . esc_html__( 'Chưa có đánh giá nào trong 30 ngày qua.', 'checkin-mkt192-wp' ) . '</p>';
            return;
        }
        ?>
<div class="checkin-rating-summary">
    <div class="checkin-rating-row">
        <span class="checkin-rating-label"><?php esc_html_e( 'Dịch vụ', 'checkin-mkt192-wp' ); ?></span>
        <span class="checkin-rating-stars"><?php $this->render_stars( $reviews['avg_service'] ); ?></span>
        <span class="checkin-rating-value"><?php echo esc_html( $reviews['avg_service'] ); ?>/5</span>
    </div>
    <div class="checkin-rating-row">
        <span class="checkin-rating-label"><?php esc_html_e( 'Thợ', 'checkin-mkt192-wp' ); ?></span>
        <span class="checkin-rating-stars"><?php $this->render_stars( $reviews['avg_staff'] ); ?></span>
        <span class="checkin-rating-value"><?php echo esc_html( $reviews['avg_staff'] ); ?>/5</span>
    </div>
    <p class="checkin-rating-count">
        <?php
        printf(
            /* translators: %s: number of reviews */
            esc_html__( 'Tổng %s lượt đánh giá trong 30 ngày.', 'checkin-mkt192-wp' ),
            esc_html( number_format_i18n( $reviews['count'] ) )
        );
        ?>
    </p>
</div>
<?php
    }

    /**
     * Render dãy sao theo điểm trung bình
     */
    private function render_stars( $rating ) {
        for ( $i = 1; $i <= 5; $i++ ) {
            if ( $rating >= $i - 0.25 ) {
                echo '<span class="dashicons dashicons-star-filled"></span>';
            } elseif ( $rating >= $i - 0.75 ) {
                echo '<span class="dashicons dashicons-star-half"></span>';
            } else {
                echo '<span class="dashicons dashicons-star-empty"></span>';
            }
        }
    }

    /**
     * Render danh sách top thợ
     */
    private function render_top_staff( $top_staff ) {
        if ( empty( $top_staff ) ) {
            echo '<p class="checkin-empty-state">' . esc_html__( 'Chưa có doanh thu trong tháng này.', 'checkin-mkt192-wp' ) . '</p>';
            return;
        }
        ?>
<div class="checkin-top-staff-list">
    <?php foreach ( $top_staff as $index => $staff ) : ?>
    <div class="checkin-top-staff-item">
        <span class="checkin-top-staff-rank rank-<?php echo esc_attr( $index + 1 ); ?>">
            <?php echo esc_html( $index + 1 ); ?>
        </span>
        <div class="checkin-top-staff-info">
            <span class="checkin-top-staff-name"><?php echo esc_html( $staff->staff_name ); ?></span>
            <span class="checkin-top-staff-meta">
                <?php
                printf(
                    /* translators: %s: number of invoices */
                    esc_html__( '%s hóa đơn', 'checkin-mkt192-wp' ),
                    esc_html( number_format_i18n( $staff->invoice_count ) )
                );
                ?>
            </span>
        </div>
        <span class="checkin-top-staff-revenue"><?php echo esc_html( $this->fmt_money( $staff->revenue ) ); ?></span>
    </div>
    <?php endforeach; ?>
</div>
<?php
    }

    /**
     * Render recent activity list
     */
    private function render_recent_activity( $activities ) {
        if ( empty( $activities ) ) {
            echo '<p class="checkin-empty-state">' . esc_html__( 'Chưa có hoạt động nào.', 'checkin-mkt192-wp' ) . '</p>';
            return;
        }
        ?>
<div class="checkin-activity-list">
    <?php foreach ( $activities as $activity ) : ?>
    <div class="checkin-activity-item">
        <div class="checkin-activity-icon checkin-activity-icon-<?php echo esc_attr( $activity['icon_color'] ); ?>">
            <span class="dashicons <?php echo esc_attr( $activity['icon'] ); ?>"></span>
        </div>
        <div class="checkin-activity-content">
            <div class="checkin-activity-title">
                <?php echo esc_html( $activity['title'] ); ?>
            </div>
            <div class="checkin-activity-description">
                <?php echo esc_html( $activity['description'] ); ?>
            </div>
            <div class="checkin-activity-time">
                <?php echo esc_html( $this->time_ago( $activity['ts'] ) ); ?>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<?php
    }

    /**
     * Render trạng thái hệ thống & kết nối từ cấu hình thật
     */
    private function render_system_status() {
        $status_items = [];

        // Phiên bản plugin
        $status_items[] = [
            'label'  => __( 'Phiên bản Plugin', 'checkin-mkt192-wp' ),
            'value'  => defined( 'CHECKIN_MKT192_VERSION' ) ? 'v' . CHECKIN_MKT192_VERSION : '—',
            'status' => 'success',
        ];

        // Zalo OA (ZBS)
        $status_items[] = $this->connection_status_item(
            __( 'Zalo OA (tin nhắn ZBS)', 'checkin-mkt192-wp' ),
            get_option( 'checkin_use_zalo_oa', '0' ) === '1',
            get_option( 'checkin_zalo_oa_app_id', '' ) && get_option( 'checkin_zalo_oa_secret_key', '' )
        );

        // Google Login
        $status_items[] = $this->connection_status_item(
            __( 'Đăng nhập Google', 'checkin-mkt192-wp' ),
            get_option( 'checkin_use_google_login', '0' ) === '1',
            (bool) get_option( 'checkin_google_client_id', '' )
        );

        // Lark — config nằm trong bảng message bot, không phải wp_options
        global $wpdb;
        $bot_table   = $wpdb->prefix . 'checkin_mkt192_message_bot_settings';
        $active_bots = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$bot_table}
             WHERE is_active = 1
               AND ( (app_id IS NOT NULL AND app_id != '' AND app_secret IS NOT NULL AND app_secret != '')
                  OR (webhook_url IS NOT NULL AND webhook_url != '') )"
        );
        $lark_enabled = get_option( 'checkin_use_lark', '0' ) === '1';
        if ( $lark_enabled && $active_bots > 0 ) {
            $status_items[] = [
                'label'  => __( 'Thông báo Lark', 'checkin-mkt192-wp' ),
                'value'  => sprintf(
                    /* translators: %s: number of active bots */
                    __( 'Hoạt động (%s bot)', 'checkin-mkt192-wp' ),
                    number_format_i18n( $active_bots )
                ),
                'status' => 'success',
            ];
        } else {
            $status_items[] = $this->connection_status_item(
                __( 'Thông báo Lark', 'checkin-mkt192-wp' ),
                $lark_enabled,
                false
            );
        }

        // Chuyển khoản ngân hàng
        $status_items[] = $this->connection_status_item(
            __( 'Chuyển khoản tự động', 'checkin-mkt192-wp' ),
            get_option( 'checkin_use_bank_transfer', '0' ) === '1',
            (bool) get_option( 'checkin_bank_account_number', '' )
        );

        // Push notifications (OneSignal)
        $status_items[] = $this->connection_status_item(
            __( 'Push Notifications', 'checkin-mkt192-wp' ),
            get_option( 'checkin_push_enabled', '0' ) === '1',
            (bool) get_option( 'checkin_onesignal_app_id', '' )
        );

        // Chế độ chi nhánh
        $status_items[] = [
            'label'  => __( 'Chế độ nhiều chi nhánh', 'checkin-mkt192-wp' ),
            'value'  => get_option( 'checkin_branch_mode_enabled', '0' ) === '1'
                ? __( 'Đang bật', 'checkin-mkt192-wp' )
                : __( 'Tắt', 'checkin-mkt192-wp' ),
            'status' => get_option( 'checkin_branch_mode_enabled', '0' ) === '1' ? 'success' : 'gray',
        ];
        ?>
<div class="checkin-status-list">
    <?php foreach ( $status_items as $item ) : ?>
    <div class="checkin-status-item">
        <span class="checkin-status-label"><?php echo esc_html( $item['label'] ); ?></span>
        <span class="checkin-badge checkin-badge-<?php echo esc_attr( $item['status'] ); ?>">
            <?php echo esc_html( $item['value'] ); ?>
        </span>
    </div>
    <?php endforeach; ?>
</div>
<?php
    }

    /**
     * Trạng thái 1 kết nối: bật + đủ cấu hình / bật nhưng thiếu cấu hình / tắt
     */
    private function connection_status_item( $label, $enabled, $configured ) {
        if ( $enabled && $configured ) {
            return [ 'label' => $label, 'value' => __( 'Hoạt động', 'checkin-mkt192-wp' ), 'status' => 'success' ];
        }
        if ( $enabled ) {
            return [ 'label' => $label, 'value' => __( 'Thiếu cấu hình', 'checkin-mkt192-wp' ), 'status' => 'warning' ];
        }
        return [ 'label' => $label, 'value' => __( 'Tắt', 'checkin-mkt192-wp' ), 'status' => 'gray' ];
    }
}
?>
