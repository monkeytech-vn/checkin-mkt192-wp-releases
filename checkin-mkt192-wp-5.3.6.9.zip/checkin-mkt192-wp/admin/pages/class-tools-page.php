<?php
/**
 * Tools Page
 *
 * Trang công cụ với shortcodes, system info, và debug tools
 *
 * @package    Checkin_MKT192_WP
 * @subpackage Admin/Pages
 * @since      5.1.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Checkin_MKT192_WP_Tools_Page
 *
 * Xử lý hiển thị các công cụ hỗ trợ
 */
class Checkin_MKT192_WP_Tools_Page {

    /**
     * Singleton instance
     */
    private static $instance = null;

    /**
     * Tab configurations
     */
    private $tabs = [];

    /**
     * Get singleton instance
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct() {
        $this->setup_tabs();
        add_action( 'admin_init', [ $this, 'handle_actions' ] );
        add_action( 'wp_ajax_checkin_test_api_connections', [ $this, 'ajax_test_api_connections' ] );
        add_action( 'wp_ajax_checkin_clear_debug_log', [ $this, 'ajax_clear_debug_log' ] );
    }

    /**
     * Setup tab configuration
     */
    private function setup_tabs() {
        $this->tabs = [
            'system' => [
                'label' => __( 'Thông tin hệ thống', 'checkin-mkt192-wp' ),
                'icon'  => 'dashicons-info',
            ],
            'debug' => [
                'label' => __( 'Debug & Logs', 'checkin-mkt192-wp' ),
                'icon'  => 'dashicons-admin-tools',
            ],
            'permissions' => [
                'label' => __( 'Quyền truy cập', 'checkin-mkt192-wp' ),
                'icon'  => 'dashicons-admin-users',
            ],
        ];
    }

    /**
     * Render page content
     */
    public function render() {
        // Check user capabilities
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( __( 'Bạn không có quyền truy cập trang này.', 'checkin-mkt192-wp' ) );
        }

        $active_tab = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'system';

        // Validate active tab
        if ( ! array_key_exists( $active_tab, $this->tabs ) ) {
            $active_tab = 'system';
        }

        ?>
<div class="wrap checkin-admin-wrapper">
    <?php include CHECKIN_PLUGIN_DIR . 'admin/partials/global-header.php'; ?>
    <?php include CHECKIN_PLUGIN_DIR . 'admin/partials/admin-notices.php'; ?>
    <div class="checkin-admin-page">
        <?php $this->render_page_header(); ?>
        <?php $this->render_tools_tabs( $active_tab ); ?>
        <?php $this->render_tab_content( $active_tab ); ?>
    </div>
</div>
<?php
    }

    /**
     * Render page header
     */
    private function render_page_header() {
        ?>
<div class="checkin-page-header">
    <div>
        <h1 class="checkin-page-title">
            <span class="dashicons dashicons-admin-tools"></span>
            <?php _e( 'Công cụ & Tiện ích', 'checkin-mkt192-wp' ); ?>
        </h1>
        <p class="checkin-page-description">
            <?php _e( 'Công cụ hỗ trợ, thông tin hệ thống và debug tools', 'checkin-mkt192-wp' ); ?>
        </p>
    </div>
</div>
<?php
    }

    /**
     * Render tabs navigation
     */
    private function render_tools_tabs( $active_tab ) {
        ?>
<div class="checkin-tools-tabs">
    <?php foreach ( $this->tabs as $tab_id => $tab ) : ?>
    <button type="button" class="checkin-tools-tab <?php echo $active_tab === $tab_id ? 'active' : ''; ?>"
        data-tab="<?php echo esc_attr( $tab_id ); ?>">
        <span class="dashicons <?php echo esc_attr( $tab['icon'] ); ?>"></span>
        <span class="checkin-tab-label"><?php echo esc_html( $tab['label'] ); ?></span>
    </button>
    <?php endforeach; ?>
</div>
<?php
    }

    /**
     * Render tab content
     */
    private function render_tab_content( $active_tab ) {
        ?>
<div class="checkin-tools-content">
    <div class="checkin-tools-tab-content <?php echo $active_tab === 'system' ? 'active' : ''; ?>"
        data-tab-content="system">
        <?php $this->render_system_tab(); ?>
    </div>
    <div class="checkin-tools-tab-content <?php echo $active_tab === 'debug' ? 'active' : ''; ?>"
        data-tab-content="debug">
        <?php $this->render_debug_tab(); ?>
    </div>
    <div class="checkin-tools-tab-content <?php echo $active_tab === 'permissions' ? 'active' : ''; ?>"
        data-tab-content="permissions">
        <?php $this->render_permissions_tab(); ?>
    </div>
</div>
<?php
    }

    /**
     * Render System Info tab
     */
    private function render_system_tab() {
        global $wpdb;

        $system_info = [
            'WordPress' => [
                'Version'       => get_bloginfo( 'version' ),
                'Site URL'      => get_site_url(),
                'Home URL'      => get_home_url(),
                'Language'      => get_locale(),
                'Timezone'      => wp_timezone_string(),
                'Multisite'     => is_multisite() ? __( 'Có', 'checkin-mkt192-wp' ) : __( 'Không', 'checkin-mkt192-wp' ),
            ],
            'Server' => [
                'PHP Version'      => PHP_VERSION,
                'MySQL Version'    => $wpdb->db_version(),
                'Server Software'  => $_SERVER['SERVER_SOFTWARE'],
                'Max Upload Size'  => size_format( wp_max_upload_size() ),
                'Memory Limit'     => ini_get( 'memory_limit' ),
                'Max Execution'    => ini_get( 'max_execution_time' ) . 's',
                'Max Input Vars'   => ini_get( 'max_input_vars' ),
            ],
            'Plugin' => [
                'Version'           => CHECKIN_MKT192_WP_VERSION,
                'Database Version'  => get_option( 'checkin_mkt192_db_version', '1.0' ),
                'Install Date'      => get_option( 'checkin_mkt192_install_date', __( 'Không xác định', 'checkin-mkt192-wp' ) ),
                'Debug Mode'        => defined( 'WP_DEBUG' ) && WP_DEBUG ? __( 'Bật', 'checkin-mkt192-wp' ) : __( 'Tắt', 'checkin-mkt192-wp' ),
            ],
        ];
        ?>
<div class="checkin-tools-grid">
    <!-- System Info Card -->
    <div class="checkin-tool-card checkin-tool-card-wide">
        <div class="checkin-tool-card-header">
            <div class="checkin-tool-card-icon" style="background: linear-gradient(135deg, #2271b1, #135e96);">
                <span class="dashicons dashicons-info"></span>
            </div>
            <div class="checkin-tool-card-title-wrapper">
                <h3 class="checkin-tool-card-title">
                    <?php _e( 'Thông tin hệ thống', 'checkin-mkt192-wp' ); ?>
                </h3>
                <p class="checkin-tool-card-desc">
                    <?php _e( 'Chi tiết về môi trường WordPress và server', 'checkin-mkt192-wp' ); ?>
                </p>
            </div>
            <button type="button" class="checkin-button checkin-button-secondary checkin-button-sm"
                id="copy-system-info">
                <span class="dashicons dashicons-admin-page"></span>
                <?php _e( 'Sao chép', 'checkin-mkt192-wp' ); ?>
            </button>
        </div>
        <div class="checkin-tool-card-body">
            <div id="system-info-content" class="checkin-system-info-sections">
                <?php foreach ( $system_info as $section => $items ) : ?>
                <div class="checkin-system-info-section">
                    <h4 class="checkin-system-section-title">
                        <?php echo esc_html( $section ); ?>
                    </h4>
                    <div class="checkin-system-info-grid">
                        <?php foreach ( $items as $label => $value ) : ?>
                        <div class="checkin-system-info-item">
                            <div class="checkin-system-info-label">
                                <?php echo esc_html( $label ); ?>
                            </div>
                            <div class="checkin-system-info-value">
                                <?php echo esc_html( $value ); ?>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <!-- Active Plugins Card -->
    <div class="checkin-tool-card checkin-tool-card-wide">
        <div class="checkin-tool-card-header">
            <div class="checkin-tool-card-icon" style="background: linear-gradient(135deg, #8b5cf6, #7c3aed);">
                <span class="dashicons dashicons-admin-plugins"></span>
            </div>
            <div class="checkin-tool-card-title-wrapper">
                <h3 class="checkin-tool-card-title">
                    <?php _e( 'Plugin đang kích hoạt', 'checkin-mkt192-wp' ); ?>
                </h3>
                <p class="checkin-tool-card-desc">
                    <?php _e( 'Danh sách các plugin đang hoạt động trên website', 'checkin-mkt192-wp' ); ?>
                </p>
            </div>
        </div>
        <div class="checkin-tool-card-body">
            <?php $this->render_active_plugins(); ?>
        </div>
    </div>

    <!-- Connection Status Card -->
    <div class="checkin-tool-card checkin-tool-card-wide">
        <div class="checkin-tool-card-header">
            <div class="checkin-tool-card-icon" style="background: linear-gradient(135deg, #06b6d4, #0891b2);">
                <span class="dashicons dashicons-networking"></span>
            </div>
            <div class="checkin-tool-card-title-wrapper">
                <h3 class="checkin-tool-card-title">
                    <?php _e( 'Trạng thái kết nối', 'checkin-mkt192-wp' ); ?>
                </h3>
                <p class="checkin-tool-card-desc">
                    <?php _e( 'Kiểm tra trạng thái kết nối của các dịch vụ tích hợp', 'checkin-mkt192-wp' ); ?>
                </p>
            </div>
        </div>
        <div class="checkin-tool-card-body">
            <div class="checkin-connection-grid">
                <?php $this->render_connection_status(); ?>
            </div>
        </div>
    </div>
</div>
<?php
    }

    /**
     * Render Debug tab
     */
    private function render_debug_tab() {
        ?>
<div class="checkin-alert checkin-alert-warning" style="margin-bottom: 24px;">
    <span class="checkin-alert-icon">⚠</span>
    <div class="checkin-alert-content">
        <div class="checkin-alert-title">
            <?php _e( 'Cảnh báo', 'checkin-mkt192-wp' ); ?>
        </div>
        <div class="checkin-alert-message">
            <?php _e( 'Các công cụ debug có thể ảnh hưởng đến dữ liệu của bạn. Vui lòng sử dụng cẩn thận!', 'checkin-mkt192-wp' ); ?>
        </div>
    </div>
</div>

<div class="checkin-tools-grid">
    <!-- Clear Cache Tool -->
    <div class="checkin-tool-card">
        <div class="checkin-tool-card-header">
            <div class="checkin-tool-card-icon" style="background: linear-gradient(135deg, #f59e0b, #d97706);">
                <span class="dashicons dashicons-trash"></span>
            </div>
            <div class="checkin-tool-card-title-wrapper">
                <h3 class="checkin-tool-card-title">
                    <?php _e( 'Xoá Cache', 'checkin-mkt192-wp' ); ?>
                </h3>
                <p class="checkin-tool-card-desc">
                    <?php _e( 'Xoá tất cả cache của plugin để tải lại dữ liệu mới', 'checkin-mkt192-wp' ); ?>
                </p>
            </div>
        </div>
        <div class="checkin-tool-card-body">
            <form method="post" action="" class="checkin-tool-form">
                <?php wp_nonce_field( 'checkin_clear_cache', 'checkin_clear_cache_nonce' ); ?>
                <input type="hidden" name="action" value="clear_cache">
                <button type="submit" class="checkin-button checkin-button-warning checkin-button-block">
                    <span class="dashicons dashicons-trash"></span>
                    <?php _e( 'Xoá Cache', 'checkin-mkt192-wp' ); ?>
                </button>
            </form>
        </div>
    </div>

    <!-- Reset Settings Tool -->
    <div class="checkin-tool-card">
        <div class="checkin-tool-card-header">
            <div class="checkin-tool-card-icon" style="background: linear-gradient(135deg, #ef4444, #dc2626);">
                <span class="dashicons dashicons-backup"></span>
            </div>
            <div class="checkin-tool-card-title-wrapper">
                <h3 class="checkin-tool-card-title">
                    <?php _e( 'Reset Cài đặt', 'checkin-mkt192-wp' ); ?>
                </h3>
                <p class="checkin-tool-card-desc">
                    <?php _e( 'Khôi phục cài đặt về mặc định. Dữ liệu check-in không bị ảnh hưởng', 'checkin-mkt192-wp' ); ?>
                </p>
            </div>
        </div>
        <div class="checkin-tool-card-body">
            <form method="post" action="" class="checkin-tool-form"
                onsubmit="return confirm('<?php esc_attr_e( 'Bạn có chắc muốn reset tất cả cài đặt?', 'checkin-mkt192-wp' ); ?>');">
                <?php wp_nonce_field( 'checkin_reset_settings', 'checkin_reset_settings_nonce' ); ?>
                <input type="hidden" name="action" value="reset_settings">
                <button type="submit" class="checkin-button checkin-button-danger checkin-button-block">
                    <span class="dashicons dashicons-backup"></span>
                    <?php _e( 'Reset Cài đặt', 'checkin-mkt192-wp' ); ?>
                </button>
            </form>
        </div>
    </div>

    <!-- Export Settings Tool -->
    <div class="checkin-tool-card">
        <div class="checkin-tool-card-header">
            <div class="checkin-tool-card-icon" style="background: linear-gradient(135deg, #10b981, #059669);">
                <span class="dashicons dashicons-download"></span>
            </div>
            <div class="checkin-tool-card-title-wrapper">
                <h3 class="checkin-tool-card-title">
                    <?php _e( 'Xuất Cài đặt', 'checkin-mkt192-wp' ); ?>
                </h3>
                <p class="checkin-tool-card-desc">
                    <?php _e( 'Xuất cài đặt thành file JSON để sao lưu hoặc di chuyển', 'checkin-mkt192-wp' ); ?>
                </p>
            </div>
        </div>
        <div class="checkin-tool-card-body">
            <form method="post" action="" class="checkin-tool-form">
                <?php wp_nonce_field( 'checkin_export_settings', 'checkin_export_settings_nonce' ); ?>
                <input type="hidden" name="action" value="export_settings">
                <button type="submit" class="checkin-button checkin-button-secondary checkin-button-block">
                    <span class="dashicons dashicons-download"></span>
                    <?php _e( 'Xuất File', 'checkin-mkt192-wp' ); ?>
                </button>
            </form>
        </div>
    </div>

    <!-- Import Settings Tool -->
    <div class="checkin-tool-card">
        <div class="checkin-tool-card-header">
            <div class="checkin-tool-card-icon" style="background: linear-gradient(135deg, #3b82f6, #2563eb);">
                <span class="dashicons dashicons-upload"></span>
            </div>
            <div class="checkin-tool-card-title-wrapper">
                <h3 class="checkin-tool-card-title">
                    <?php _e( 'Nhập Cài đặt', 'checkin-mkt192-wp' ); ?>
                </h3>
                <p class="checkin-tool-card-desc">
                    <?php _e( 'Nhập file JSON cài đặt đã xuất trước đó', 'checkin-mkt192-wp' ); ?>
                </p>
            </div>
        </div>
        <div class="checkin-tool-card-body">
            <form method="post" action="" enctype="multipart/form-data" class="checkin-tool-form">
                <?php wp_nonce_field( 'checkin_import_settings', 'checkin_import_settings_nonce' ); ?>
                <input type="hidden" name="action" value="import_settings">
                <div class="checkin-form-group">
                    <input type="file" name="settings_file" accept=".json" class="checkin-form-input" required>
                </div>
                <button type="submit" class="checkin-button checkin-button-secondary checkin-button-block">
                    <span class="dashicons dashicons-upload"></span>
                    <?php _e( 'Nhập File', 'checkin-mkt192-wp' ); ?>
                </button>
            </form>
        </div>
    </div>

    <!-- Test API Tool -->
    <div class="checkin-tool-card">
        <div class="checkin-tool-card-header">
            <div class="checkin-tool-card-icon" style="background: linear-gradient(135deg, #8b5cf6, #7c3aed);">
                <span class="dashicons dashicons-admin-plugins"></span>
            </div>
            <div class="checkin-tool-card-title-wrapper">
                <h3 class="checkin-tool-card-title">
                    <?php _e( 'Kiểm tra API', 'checkin-mkt192-wp' ); ?>
                </h3>
                <p class="checkin-tool-card-desc">
                    <?php _e( 'Kiểm tra kết nối với tất cả các dịch vụ bên ngoài', 'checkin-mkt192-wp' ); ?>
                </p>
            </div>
        </div>
        <div class="checkin-tool-card-body">
            <button type="button" class="checkin-button checkin-button-secondary checkin-button-block"
                id="test-all-apis">
                <span class="dashicons dashicons-admin-plugins"></span>
                <?php _e( 'Kiểm tra tất cả', 'checkin-mkt192-wp' ); ?>
            </button>
        </div>
    </div>

    <!-- Debug Log Tool -->
    <div class="checkin-tool-card checkin-tool-card-wide">
        <div class="checkin-tool-card-header">
            <div class="checkin-tool-card-icon" style="background: linear-gradient(135deg, #64748b, #475569);">
                <span class="dashicons dashicons-media-text"></span>
            </div>
            <div class="checkin-tool-card-title-wrapper">
                <h3 class="checkin-tool-card-title">
                    <?php _e( 'Debug Log', 'checkin-mkt192-wp' ); ?>
                </h3>
                <p class="checkin-tool-card-desc">
                    <?php _e( 'Xem các log gần đây của plugin', 'checkin-mkt192-wp' ); ?>
                </p>
            </div>
            <button type="button" class="checkin-button checkin-button-secondary checkin-button-sm" id="refresh-log">
                <span class="dashicons dashicons-update"></span>
                <?php _e( 'Làm mới', 'checkin-mkt192-wp' ); ?>
            </button>
        </div>
        <div class="checkin-tool-card-body">
            <?php $this->render_debug_log(); ?>
        </div>
    </div>
</div>
<?php
    }    /**
     * Check connection status
     */
    private function check_connection_status( $service ) {
        switch ( $service ) {
            case 'zalo':
                // Check Zalo OA connection from individual options (Connections page)
                $use_zalo_oa   = get_option( 'checkin_use_zalo_oa' );
                $use_zalo_user = get_option( 'checkin_use_zalo_user' );

                if ( in_array( $use_zalo_oa, [ 'yes', '1', 1, true ], true )   || $use_zalo_oa     === 'yes' ||
                     in_array( $use_zalo_user, [ 'yes', '1', 1, true ], true ) || $use_zalo_user   === 'yes' ) {
                    global $wpdb;
                    $zalo_config = $wpdb->get_row(
                        "SELECT access_token FROM {$wpdb->prefix}checkin_mkt192_zalo_config WHERE id = 1"
                    );
                    return ( $zalo_config && !empty( $zalo_config->access_token ) )
                        ? __( 'Đã kết nối', 'checkin-mkt192-wp' )
                        : __( 'Chưa có token', 'checkin-mkt192-wp' );
                }
                return __( 'Chưa kích hoạt', 'checkin-mkt192-wp' );

            case 'lark':
                // Check Lark connection from individual options (Connections page)
                $use_lark = get_option( 'checkin_use_lark' );
                if ( in_array( $use_lark, [ 'yes', '1', 1, true ], true ) || $use_lark === 'yes' ) {
                    global $wpdb;
                    $bot_count = $wpdb->get_var(
                        "SELECT COUNT(*) FROM {$wpdb->prefix}checkin_mkt192_message_bot_settings WHERE is_active = 1"
                    );
                    return ( $bot_count > 0 )
                        ? sprintf( __( 'Đã kết nối (%d bots)', 'checkin-mkt192-wp' ), $bot_count )
                        : __( 'Chưa có bot', 'checkin-mkt192-wp' );
                }
                return __( 'Chưa kích hoạt', 'checkin-mkt192-wp' );

            case 'google':
                // Check Google login from individual options (Connections page)
                $use_google = get_option( 'checkin_use_google_login' );
                if ( in_array( $use_google, [ 'yes', '1', 1, true ], true ) || $use_google === 'yes' ) {
                    $client_id = get_option( 'checkin_google_client_id' );
                    return !empty( $client_id )
                        ? __( 'Đã cấu hình', 'checkin-mkt192-wp' )
                        : __( 'Thiếu Client ID', 'checkin-mkt192-wp' );
                }
                return __( 'Chưa kích hoạt', 'checkin-mkt192-wp' );

            case 'facebook':
                // Check Facebook login from individual options (Connections page)
                $use_facebook = get_option( 'checkin_use_facebook_login' );
                if ( in_array( $use_facebook, [ 'yes', '1', 1, true ], true ) || $use_facebook === 'yes' ) {
                    $app_id = get_option( 'checkin_facebook_app_id' );
                    return !empty( $app_id )
                        ? __( 'Đã cấu hình', 'checkin-mkt192-wp' )
                        : __( 'Thiếu App ID', 'checkin-mkt192-wp' );
                }
                return __( 'Chưa kích hoạt', 'checkin-mkt192-wp' );

            case 'momo':
            case 'zalopay':
                // Check payment gateway settings
                $payment_settings = get_option( 'checkin_payment_settings', [] );
                $gateway_key      = $service === 'momo' ? 'momo' : 'zalopay';

                if ( isset( $payment_settings[ $gateway_key ] ) && $payment_settings[ $gateway_key ]['enabled'] === 'yes' ) {
                    $has_credentials = !empty( $payment_settings[ $gateway_key ]['partner_code'] )
                                    && !empty( $payment_settings[ $gateway_key ]['access_key'] );
                    return $has_credentials
                        ? __( 'Đã cấu hình', 'checkin-mkt192-wp' )
                        : __( 'Thiếu thông tin', 'checkin-mkt192-wp' );
                }
                return __( 'Chưa kích hoạt', 'checkin-mkt192-wp' );

            default:
                return __( 'Không xác định', 'checkin-mkt192-wp' );
        }
    }

    /**
     * Render active plugins list
     */
    private function render_active_plugins() {
        $active_plugins = get_option( 'active_plugins' );
        $all_plugins    = get_plugins();
        ?>
<div class="checkin-plugins-list">
    <?php foreach ( $active_plugins as $plugin_path ) : ?>
    <?php if ( isset( $all_plugins[ $plugin_path ] ) ) : ?>
    <?php $plugin = $all_plugins[ $plugin_path ]; ?>
    <div class="checkin-plugin-item">
        <div class="checkin-plugin-icon">
            <span class="dashicons dashicons-admin-plugins"></span>
        </div>
        <div class="checkin-plugin-info">
            <h4 class="checkin-plugin-name">
                <?php echo esc_html( $plugin['Name'] ); ?>
            </h4>
            <p class="checkin-plugin-author">
                <?php echo wp_kses_post( $plugin['Author'] ); ?>
            </p>
        </div>
        <div class="checkin-plugin-version">
            <span class="checkin-badge checkin-badge-info">v<?php echo esc_html( $plugin['Version'] ); ?></span>
        </div>
    </div>
    <?php endif; ?>
    <?php endforeach; ?>
</div>
<?php
    }

    /**
     * Render connection status grid
     */
    private function render_connection_status() {
        $services = [
            'zalo'     => __( 'Zalo OA', 'checkin-mkt192-wp' ),
            'lark'     => __( 'Lark/DingTalk', 'checkin-mkt192-wp' ),
            'google'   => __( 'Google Login', 'checkin-mkt192-wp' ),
            'facebook' => __( 'Facebook Login', 'checkin-mkt192-wp' ),
            'momo'     => __( 'Momo Payment', 'checkin-mkt192-wp' ),
            'zalopay'  => __( 'ZaloPay', 'checkin-mkt192-wp' ),
        ];

        foreach ( $services as $service_key => $service_label ) :
            $status_text  = $this->check_connection_status( $service_key );
            $status_class = $this->get_connection_status_class( $status_text );
            ?>
<div class="checkin-connection-card">
    <div class="checkin-connection-label">
        <span
            class="checkin-connection-label-icon"><?php echo esc_html( strtoupper( substr( $service_key, 0, 1 ) ) ); ?></span>
        <span><?php echo esc_html( $service_label ); ?></span>
    </div>
    <div class="checkin-connection-status <?php echo esc_attr( $status_class ); ?>">
        <?php echo wp_kses_post( $status_text ); ?>
    </div>
</div>
<?php
        endforeach;
    }

    /**
     * Get CSS class for connection status
     */
    private function get_connection_status_class( $status_text ) {
        // Check for success status (Đã kết nối, Đã cấu hình)
        if ( strpos( $status_text, 'Đã' ) === 0 ) {
            return 'connected';
        }
        // Check for warning/error status (Chưa, Thiếu)
        elseif ( strpos( $status_text, 'Chưa' ) === 0 || strpos( $status_text, 'Thiếu' ) === 0 ) {
            return 'disconnected';
        }
        // Default to disconnected
        else {
            return 'disconnected';
        }
    }

    /**
     * Render debug log
     */
    private function render_debug_log() {
        $log_entries = [];

        // Try to read WordPress debug.log
        if ( defined( 'WP_DEBUG' ) && WP_DEBUG && defined( 'WP_DEBUG_LOG' ) && WP_DEBUG_LOG ) {
            $log_file = WP_CONTENT_DIR . '/debug.log';

            if ( file_exists( $log_file ) && is_readable( $log_file ) ) {
                // Read last 50 lines from log file
                $lines = $this->tail_file( $log_file, 50 );

                foreach ( $lines as $line ) {
                    $entry = $this->parse_log_line( $line );
                    if ( $entry ) {
                        $log_entries[] = $entry;
                    }
                }

                // Reverse to show newest first
                $log_entries = array_reverse( $log_entries );
            }
        }
        ?>
<div class="checkin-log-viewer">
    <div class="checkin-log-header"
        style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <h3 style="margin: 0;">
            <?php _e( 'Debug Log', 'checkin-mkt192-wp' ); ?>
        </h3>
        <button type="button" id="checkin-clear-log-btn" class="button"
            style="display: flex; align-items: center; gap: 8px; padding: 8px 16px; border-radius: 6px; background: #f0f0f1; border: 1px solid #c3c4c7; color: #d63638; font-weight: 500; cursor: pointer; transition: all 0.2s;"
            onmouseover="this.style.background='#fff'; this.style.borderColor='#d63638'; this.style.color='#d63638';"
            onmouseout="this.style.background='#f0f0f1'; this.style.borderColor='#c3c4c7'; this.style.color='#d63638';">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
                stroke-linecap="round" stroke-linejoin="round">
                <polyline points="3 6 5 6 21 6"></polyline>
                <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                <line x1="10" y1="11" x2="10" y2="17"></line>
                <line x1="14" y1="11" x2="14" y2="17"></line>
            </svg>
            <?php _e( 'Xóa Log', 'checkin-mkt192-wp' ); ?>
        </button>
    </div>
    <?php if ( empty( $log_entries ) ) : ?>
    <div class="checkin-empty-state">
        <div class="checkin-empty-state-icon">
            <span class="dashicons dashicons-yes-alt"></span>
        </div>
        <div class="checkin-empty-state-title">
            <?php _e( 'Không có log nào', 'checkin-mkt192-wp' ); ?>
        </div>
        <div class="checkin-empty-state-description">
            <?php _e( 'Chưa có bản ghi log nào được tạo', 'checkin-mkt192-wp' ); ?>
        </div>
    </div>
    <?php else : ?>
    <div class="checkin-log-entries">
        <?php foreach ( $log_entries as $entry ) : ?>
        <div
            class="checkin-log-entry checkin-log-<?php echo strtolower( $entry['level'] ) === 'error' ? 'error' : ( strtolower( $entry['level'] ) === 'warning' ? 'warning' : 'info' ); ?>">
            <div class="checkin-log-badge">
                <span
                    class="checkin-badge <?php echo strtolower( $entry['level'] ) === 'error' ? 'checkin-badge-danger' : ( strtolower( $entry['level'] ) === 'warning' ? 'checkin-badge-warning' : 'checkin-badge-info' ); ?>">
                    <?php echo esc_html( $entry['level'] ); ?>
                </span>
            </div>
            <div class="checkin-log-content">
                <div class="checkin-log-message">
                    <?php echo esc_html( $entry['message'] ); ?>
                </div>
                <div class="checkin-log-time">
                    <span class="dashicons dashicons-clock"></span>
                    <?php echo esc_html( $entry['time'] ); ?>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>
<?php
    }

    /**
     * Handle actions (clear cache, reset settings, etc.)
     */
    public function handle_actions() {
        if ( ! isset( $_POST['action'] ) || ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $action = sanitize_text_field( $_POST['action'] );

        switch ( $action ) {
            case 'clear_cache':
                if ( isset( $_POST['checkin_clear_cache_nonce'] ) &&
                     wp_verify_nonce( $_POST['checkin_clear_cache_nonce'], 'checkin_clear_cache' ) ) {
                    // TODO: Implement cache clearing
                    wp_cache_flush();
                    wp_redirect( add_query_arg( [
                        'page'    => 'checkin-mkt192-tools',
                        'tab'     => 'debug',
                        'message' => 'cache_cleared',
                    ], admin_url( 'admin.php' ) ) );
                    exit;
                }
                break;

            case 'reset_settings':
                if ( isset( $_POST['checkin_reset_settings_nonce'] ) &&
                     wp_verify_nonce( $_POST['checkin_reset_settings_nonce'], 'checkin_reset_settings' ) ) {
                    // TODO: Implement settings reset
                    wp_redirect( add_query_arg( [
                        'page'    => 'checkin-mkt192-tools',
                        'tab'     => 'debug',
                        'message' => 'settings_reset',
                    ], admin_url( 'admin.php' ) ) );
                    exit;
                }
                break;

            case 'export_settings':
                if ( isset( $_POST['checkin_export_settings_nonce'] ) &&
                     wp_verify_nonce( $_POST['checkin_export_settings_nonce'], 'checkin_export_settings' ) ) {
                    // TODO: Implement settings export
                    $this->export_settings();
                }
                break;

            case 'import_settings':
                if ( isset( $_POST['checkin_import_settings_nonce'] ) &&
                     wp_verify_nonce( $_POST['checkin_import_settings_nonce'], 'checkin_import_settings' ) ) {
                    // TODO: Implement settings import
                    $this->import_settings();
                }
                break;
        }
    }

    /**
     * Read last N lines from file
     */
    private function tail_file( $file, $lines = 50 ) {
        $handle = fopen( $file, 'r' );
        if ( ! $handle ) {
            return [];
        }

        $line_count = 0;
        $pos        = -2;
        $buffer     = [];
        $chunk_size = 4096;

        fseek( $handle, 0, SEEK_END );
        $end_pos = ftell( $handle );

        while ( $line_count < $lines && $end_pos > 0 ) {
            $read_size = min( $chunk_size, $end_pos );
            $end_pos  -= $read_size;

            fseek( $handle, $end_pos, SEEK_SET );
            $chunk = fread( $handle, $read_size );

            $buffer = explode( "\n", $chunk . implode( "\n", $buffer ) );

            // If we have a partial line at the end, keep it in buffer
            if ( $end_pos > 0 && substr( $chunk, 0, 1 ) !== "\n" ) {
                $first     = array_shift( $buffer );
                $buffer[0] = $first . $buffer[0];
            }

            $line_count = count( $buffer ) - 1;
        }

        fclose( $handle );

        // Remove empty lines
        $buffer = array_filter( $buffer, function ( $line ) {
            return trim( $line ) !== '';
        } );

        return array_slice( $buffer, -$lines );
    }

    /**
     * Parse log line into structured data
     */
    private function parse_log_line( $line ) {
        // WordPress debug.log format: [DD-Mon-YYYY HH:MM:SS UTC] message
        // Example: [14-Nov-2025 04:47:45 UTC] AJAX Test API called...
        if ( preg_match( '/^\[([^\]]+)\]\s+(.+)$/', $line, $matches ) ) {
            $time_str = $matches[1];
            $message  = $matches[2];

            // Phân tích message để xác định level
            $level = 'INFO';
            $type  = 'Info';

            if ( preg_match( '/^(PHP\s+(?:Fatal error|Parse error|Warning|Notice|Deprecated)|WordPress database error)/i', $message, $type_matches ) ) {
                $type_str = $type_matches[1];

                if ( stripos( $type_str, 'Fatal' ) !== false || stripos( $type_str, 'Parse' ) !== false ) {
                    $level = 'ERROR';
                    $type  = 'Error';
                } elseif ( stripos( $type_str, 'Warning' ) !== false || stripos( $type_str, 'database error' ) !== false ) {
                    $level = 'WARNING';
                    $type  = 'Warning';
                } else {
                    $level = 'INFO';
                    $type  = 'Notice';
                }
            }

            // Format time
            try {
                $date_obj   = new DateTime( $time_str );
                $date_obj->setTimezone( new DateTimeZone( wp_timezone_string() ) );
                $local_time = $date_obj->format( 'd/m/Y H:i:s' );
            } catch ( Exception $e ) {
                $local_time = $time_str;
            }

            // Clean up message
            $message = preg_replace( '/\s+/', ' ', $message ); // Remove extra spaces
            $message = preg_replace( '/made by.*$/', '[...]', $message ); // Remove long stack trace

            // Truncate long messages
            if ( strlen( $message ) > 200 ) {
                $message = substr( $message, 0, 200 ) . '...';
            }

            return [
                'time'    => $local_time,
                'level'   => $level,
                'type'    => $type,
                'message' => $message,
            ];
        }

        return null;
    }

    /**
     * Export settings to JSON
     */
    private function export_settings() {
        $settings = [
            'brand'       => get_option( 'checkin_mkt192_brand_settings', [] ),
            'connections' => get_option( 'checkin_mkt192_connections_settings', [] ),
            'payments'    => get_option( 'checkin_mkt192_payments_settings', [] ),
        ];

        header( 'Content-Type: application/json' );
        header( 'Content-Disposition: attachment; filename="checkin-mkt192-settings-' . date( 'Y-m-d' ) . '.json"' );
        echo json_encode( $settings, JSON_PRETTY_PRINT );
        exit;
    }

    /**
     * Import settings from JSON
     */
    private function import_settings() {
        if ( ! isset( $_FILES['settings_file'] ) ) {
            return;
        }

        $file = $_FILES['settings_file'];
        if ( $file['type'] !== 'application/json' ) {
            wp_redirect( add_query_arg( [
                'page'    => 'checkin-mkt192-tools',
                'tab'     => 'debug',
                'message' => 'invalid_file',
            ], admin_url( 'admin.php' ) ) );
            exit;
        }

        $json     = file_get_contents( $file['tmp_name'] );
        $settings = json_decode( $json, true );

        if ( json_last_error() === JSON_ERROR_NONE ) {
            if ( isset( $settings['brand'] ) ) {
                update_option( 'checkin_mkt192_brand_settings', $settings['brand'] );
            }
            if ( isset( $settings['connections'] ) ) {
                update_option( 'checkin_mkt192_connections_settings', $settings['connections'] );
            }
            if ( isset( $settings['payments'] ) ) {
                update_option( 'checkin_mkt192_payments_settings', $settings['payments'] );
            }

            wp_redirect( add_query_arg( [
                'page'    => 'checkin-mkt192-tools',
                'tab'     => 'debug',
                'message' => 'import_success',
            ], admin_url( 'admin.php' ) ) );
        } else {
            wp_redirect( add_query_arg( [
                'page'    => 'checkin-mkt192-tools',
                'tab'     => 'debug',
                'message' => 'import_failed',
            ], admin_url( 'admin.php' ) ) );
        }
        exit;
    }

    /**
     * AJAX handler for clearing debug log
     */
    public function ajax_clear_debug_log() {
        // Verify nonce and permissions
        $nonce_check = check_ajax_referer( 'checkin-admin-nonce', 'nonce', false );

        if ( ! $nonce_check ) {
            error_log( 'Clear Log: Nonce verification failed' );
            wp_send_json_error( [
                'message' => __( 'Xác thực không hợp lệ. Vui lòng tải lại trang.', 'checkin-mkt192-wp' ),
            ] );
        }

        if ( ! current_user_can( 'manage_options' ) ) {
            error_log( 'Clear Log: Permission denied' );
            wp_send_json_error( [
                'message' => __( 'Bạn không có quyền thực hiện thao tác này.', 'checkin-mkt192-wp' ),
            ] );
        }

        $log_file = WP_CONTENT_DIR . '/debug.log';

        if ( ! file_exists( $log_file ) ) {
            wp_send_json_success( [
                'message' => __( 'File log không tồn tại.', 'checkin-mkt192-wp' ),
            ] );
        }

        // Clear log file
        if ( file_put_contents( $log_file, '' ) === false ) {
            error_log( 'Clear Log: Failed to clear debug.log' );
            wp_send_json_error( [
                'message' => __( 'Không thể xóa file log. Vui lòng kiểm tra quyền ghi file.', 'checkin-mkt192-wp' ),
            ] );
        }

        error_log( 'Debug log cleared by user ID: ' . get_current_user_id() );

        wp_send_json_success( [
            'message' => __( 'Đã xóa log thành công!', 'checkin-mkt192-wp' ),
        ] );
    }

    /**
     * AJAX handler to test API connections
     */
    public function ajax_test_api_connections() {
        // Verify nonce and permissions
        $nonce_check = check_ajax_referer( 'checkin-admin-nonce', 'nonce', false );

        if ( ! $nonce_check ) {
            error_log( 'API Test: Nonce verification failed' );
            wp_send_json_error( [
                'message' => __( 'Xác thực không hợp lệ. Vui lòng tải lại trang.', 'checkin-mkt192-wp' ),
            ] );
        }

        if ( ! current_user_can( 'manage_options' ) ) {
            error_log( 'API Test: Permission denied' );
            wp_send_json_error( [
                'message' => __( 'Bạn không có quyền thực hiện thao tác này.', 'checkin-mkt192-wp' ),
            ] );
        }

        error_log( '=== Starting API tests ===' );
        $results = [];

        // Test Zalo OA - Tách riêng
        $zalo_oa_enabled = get_option( 'checkin_use_zalo_oa', '0' ) === '1';
        $results[]       = $this->test_api_connection( 'Zalo OA', $zalo_oa_enabled, 'zalo_oa' );

        // Test Zalo User - Tách riêng
        $zalo_user_enabled = get_option( 'checkin_use_zalo_user', '0' ) === '1';
        $results[]         = $this->test_api_connection( 'Zalo User', $zalo_user_enabled, 'zalo_user' );

        // Test Lark
        $lark_enabled = get_option( 'checkin_use_lark', '0' ) === '1';
        $results[]    = $this->test_api_connection( 'Lark', $lark_enabled, 'lark' );

        // Test Google - Check actual options
        $google_enabled = get_option( 'checkin_use_google_login', '0' ) === '1';
        $results[]      = $this->test_api_connection( 'Google', $google_enabled, 'google' );

        // Test Facebook - Check actual options
        $facebook_enabled = get_option( 'checkin_use_facebook_login', '0' ) === '1';
        $results[]        = $this->test_api_connection( 'Facebook', $facebook_enabled, 'facebook' );

        // Test Momo - Check payments settings
        $momo_settings = get_option( 'checkin_mkt192_payments_settings', [] );
        $momo_enabled  = isset( $momo_settings['momo']['enabled'] ) && $momo_settings['momo']['enabled'];
        $results[]     = $this->test_api_connection( 'Momo', $momo_enabled, 'momo' );

        // Test ZaloPay - Check payments settings
        $zalopay_enabled = isset( $momo_settings['zalopay']['enabled'] ) && $momo_settings['zalopay']['enabled'];
        $results[]       = $this->test_api_connection( 'ZaloPay', $zalopay_enabled, 'zalopay' );

        $success_count = count( array_filter( $results, function ( $r ) {
            return $r['status'] === 'success';
        } ) );

        error_log( sprintf(
            'API Tests completed: %d total, %d success, %d failed',
            count( $results ),
            $success_count,
            count( $results ) - $success_count
        ) );

        foreach ( $results as $result ) {
            error_log( sprintf(
                '  - %s: %s (%s)',
                $result['name'],
                $result['status'],
                $result['message']
            ) );
        }

        wp_send_json_success( [
            'apis'          => $results,
            'total_count'   => count( $results ),
            'success_count' => $success_count,
        ] );
    }

    /**
     * Test single API connection
     *
     * @param string $name API name
     * @param bool   $enabled Is API enabled in settings
     * @param string $type API type
     * @return array Test result
     */
    private function test_api_connection( $name, $enabled, $type ) {
        // If not enabled, return not configured
        if ( ! $enabled ) {
            return [
                'name'         => $name,
                'status'       => 'warning',
                'message'      => __( 'Chưa cấu hình', 'checkin-mkt192-wp' ),
                'responseTime' => '-',
            ];
        }

        // Try to test actual connection
        $start_time = microtime( true );

        try {
            // TODO: Implement actual API testing based on type
            // For now, simulate testing
            $test_result = $this->perform_api_test( $type );

            $end_time      = microtime( true );
            $response_time = round( ( $end_time - $start_time ) * 1000 ); // Convert to ms

            if ( $test_result['success'] ) {
                return [
                    'name'         => $name,
                    'status'       => 'success',
                    'message'      => __( 'Kết nối thành công', 'checkin-mkt192-wp' ),
                    'responseTime' => $response_time . 'ms',
                ];
            } else {
                return [
                    'name'         => $name,
                    'status'       => 'error',
                    'message'      => sprintf(
                        __( 'Không thể kết nối: %s', 'checkin-mkt192-wp' ),
                        $test_result['error']
                    ),
                    'responseTime' => '-',
                ];
            }
        } catch ( Exception $e ) {
            return [
                'name'         => $name,
                'status'       => 'error',
                'message'      => sprintf(
                    __( 'Lỗi: %s', 'checkin-mkt192-wp' ),
                    $e->getMessage()
                ),
                'responseTime' => '-',
            ];
        }
    }

    /**
     * Perform actual API test
     *
     * @param string $type API type
     * @return array Result with success and error keys
     */
    private function perform_api_test( $type ) {
        $start_time = microtime( true );

        try {
            switch ( $type ) {
                case 'zalo_oa':
                    // Test Zalo OA API
                    $result = $this->test_zalo_oa_api();
                    break;

                case 'zalo_user':
                    // Test Zalo User API
                    $result = $this->test_zalo_user_api();
                    break;

                case 'lark':
                    // Test Lark API - Check database for bot settings
                    global $wpdb;
                    $table_name = $wpdb->prefix . 'checkin_mkt192_message_bot_settings';

                    // Check if bot exists in database
                    if ( $wpdb->get_var( "SHOW TABLES LIKE '$table_name'" ) !== $table_name ) {
                        return [
                            'success' => false,
                            'error'   => 'Bảng cấu hình bot không tồn tại',
                        ];
                    }

                    // Get bot that has 'api_test' in notification_types
                    $bots = $wpdb->get_results( "SELECT * FROM $table_name WHERE webhook_url IS NOT NULL AND webhook_url != ''" );

                    $bot = null;
                    foreach ( $bots as $b ) {
                        $types = json_decode( $b->notification_types, true );
                        if ( is_array( $types ) && in_array( 'api_test', $types ) ) {
                            $bot = $b;
                            break;
                        }
                    }

                    if ( ! $bot ) {
                        return [
                            'success' => false,
                            'error'   => 'Chưa cấu hình bot với loại thông báo "api_test"',
                        ];
                    }

                    // Test Lark API with bot settings
                    $result = $this->test_lark_api( $bot );
                    break;

                case 'google':
                case 'facebook':
                    // Test cơ bản - kiểm tra endpoint có tồn tại không
                    $result = $this->test_generic_api( $type );
                    break;

                default:
                    // For other APIs, just return success if enabled
                    usleep( rand( 50000, 200000 ) );
                    return [
                        'success' => true,
                        'error'   => null,
                    ];
            }

            return $result;

        } catch ( Exception $e ) {
            return [
                'success' => false,
                'error'   => $e->getMessage(),
            ];
        }
    }

    /**
     * Test Zalo OA API connection by sending test message
     */
    private function test_zalo_oa_api() {
        // Get Zalo OA settings
        $zalo_oa_id        = get_option( 'checkin_zalo_oa_id', '' );
        $zalo_access_token = get_option( 'checkin_zalo_access_token', '' );

        if ( empty( $zalo_oa_id ) || empty( $zalo_access_token ) ) {
            return [
                'success' => false,
                'error'   => 'Chưa cấu hình Zalo OA ID hoặc Access Token',
            ];
        }

        // Test phone number
        $test_phone = '0962794917';

        // Get user_id from phone
        $user_api_url  = 'https://openapi.zalo.me/v2.0/oa/getprofile';
        $user_response = wp_remote_get( add_query_arg( 'data', json_encode( [ 'phone' => $test_phone ] ), $user_api_url ), [
            'headers' => [
                'access_token' => $zalo_access_token,
            ],
            'timeout' => 10,
        ] );

        if ( is_wp_error( $user_response ) ) {
            return [
                'success' => false,
                'error'   => 'Không lấy được user: ' . $user_response->get_error_message(),
            ];
        }

        $user_data = json_decode( wp_remote_retrieve_body( $user_response ), true );
        if ( empty( $user_data['data']['user_id'] ) ) {
            return [
                'success' => false,
                'error'   => 'Không tìm thấy user Zalo với SĐT test',
            ];
        }

        $user_id = $user_data['data']['user_id'];

        // Send test message
        $message_url  = 'https://openapi.zalo.me/v2.0/oa/message';
        $message_data = [
            'recipient' => [ 'user_id' => $user_id ],
            'message'   => [
                'text' => '✅ Test kết nối Zalo OA thành công!\n\nThời gian: ' . current_time( 'd/m/Y H:i:s' ),
            ],
        ];

        $response = wp_remote_post( $message_url, [
            'headers' => [
                'access_token' => $zalo_access_token,
                'Content-Type' => 'application/json',
            ],
            'body'    => json_encode( $message_data ),
            'timeout' => 10,
        ] );

        if ( is_wp_error( $response ) ) {
            return [
                'success' => false,
                'error'   => $response->get_error_message(),
            ];
        }

        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        if ( isset( $body['error'] ) && $body['error'] != 0 ) {
            return [
                'success' => false,
                'error'   => $body['message'] ?? 'Lỗi gửi message',
            ];
        }

        return [
            'success' => true,
            'error'   => null,
        ];
    }

    /**
     * Test Zalo User API connection by sending test notification
     */
    private function test_zalo_user_api() {
        // Get domain from option (auto-updated by ngrok)
        $domain = get_option( 'checkin_zalo_user_domain', '' );

        if ( empty( $domain ) ) {
            return [
                'success' => false,
                'error'   => 'Chưa cấu hình domain',
            ];
        }

        // Send test notification via n8n webhook (using booking endpoint)
        $test_url = trailingslashit( $domain ) . 'webhook/n8n-send-message-invoice';

        // Format data like booking notification
        $test_time         = current_time( 'H:i d/m/Y' );
        $notification_data = [
            'table_name'       => 'test_booking',
            'booking_id'       => 'TEST_' . time(),
            'customer_phone'   => '0962794917',
            'customer_name'    => 'Test API User',
            'booking_time'     => $test_time,
            'service_name'     => 'Kiểm tra kết nối API',
            'hairdresser_name' => 'System Test',
            'staff_id'         => 'API_TEST',
            'checkin_url'      => home_url(),
            'reschedule_url'   => home_url(),
            'chat_admin_url'   => home_url(),
            'voucher_url'      => home_url(),
        ];

        $response = wp_remote_post( $test_url, [
            'timeout'   => 10,
            'sslverify' => false,
            'headers'   => [
                'Content-Type'                => 'application/json',
                'ngrok-skip-browser-warning'  => 'true',
            ],
            'body' => json_encode( $notification_data ),
        ] );

        if ( is_wp_error( $response ) ) {
            return [
                'success' => false,
                'error'   => $response->get_error_message(),
            ];
        }

        $status_code = wp_remote_retrieve_response_code( $response );
        $body        = json_decode( wp_remote_retrieve_body( $response ), true );

        // Check for success - chỉ chấp nhận 200
        if ( $status_code === 200 ) {
            return [
                'success' => true,
                'error'   => null,
            ];
        }

        // Bất kỳ status code nào khác đều là lỗi
        return [
            'success' => false,
            'error'   => 'HTTP ' . $status_code . ( isset( $body['message'] ) ? ': ' . $body['message'] : '' ),
        ];
    }

    /**
     * Test Lark API connection
     *
     * @param object $bot Bot settings from database
     */
    private function test_lark_api( $bot = null ) {
        // Test using card builder and send to bot
        if ( $bot && ! empty( $bot->webhook_url ) ) {
            // Load card builder
            require_once CHECKIN_PLUGIN_DIR . 'includes/lark/card-builder.php';

            // Build test card
            $test_time = current_time( 'd/m/Y H:i:s' );
            $card_data = build_api_test_card( $bot->bot_name, $test_time );

            // Send via webhook
            $payload = [
                'msg_type' => 'interactive',
                'card'     => $card_data,
            ];

            $response = wp_remote_post( $bot->webhook_url, [
                'timeout'   => 10,
                'sslverify' => false,
                'headers'   => [
                    'Content-Type' => 'application/json',
                ],
                'body' => json_encode( $payload ),
            ] );

            if ( is_wp_error( $response ) ) {
                return [
                    'success' => false,
                    'error'   => $response->get_error_message(),
                ];
            }

            $status_code = wp_remote_retrieve_response_code( $response );
            $body        = json_decode( wp_remote_retrieve_body( $response ), true );

            // Lark webhook returns 200 on success
            if ( $status_code !== 200 ) {
                $error_msg = isset( $body['msg'] ) ? $body['msg'] : 'HTTP ' . $status_code;
                return [
                    'success' => false,
                    'error'   => $error_msg,
                ];
            }

            return [
                'success' => true,
                'error'   => null,
            ];
        }

        // Fallback: Test local Lark callback endpoint
        $site_url = get_site_url();
        $test_url = trailingslashit( $site_url ) . 'wp-json/vg/v1/lark-callback';

        $response = wp_remote_post( $test_url, [
            'timeout'   => 5,
            'sslverify' => false,
            'headers'   => [
                'Content-Type' => 'application/json',
            ],
            'body' => json_encode( [ 'challenge' => 'test' ] ),
        ] );

        if ( is_wp_error( $response ) ) {
            return [
                'success' => false,
                'error'   => $response->get_error_message(),
            ];
        }

        $status_code = wp_remote_retrieve_response_code( $response );
        // Lark endpoint returns 200 or 400, both mean it's working
        if ( $status_code !== 200 && $status_code !== 400 ) {
            return [
                'success' => false,
                'error'   => 'HTTP ' . $status_code,
            ];
        }

        return [
            'success' => true,
            'error'   => null,
        ];
    }

    /**
     * Test generic API - check if REST endpoints exist
     */
    private function test_generic_api( $type ) {
        // Test basic REST API availability
        $site_url = get_site_url();
        $test_url = trailingslashit( $site_url ) . 'wp-json/vg/v1/';

        $response = wp_remote_get( $test_url, [
            'timeout'   => 5,
            'sslverify' => false,
        ] );

        if ( is_wp_error( $response ) ) {
            return [
                'success' => false,
                'error'   => $response->get_error_message(),
            ];
        }

        // Nếu REST API hoạt động thì OK
        $status_code = wp_remote_retrieve_response_code( $response );
        if ( $status_code === 200 || $status_code === 404 ) {
            // 404 là bình thường vì endpoint gốc không có
            return [
                'success' => true,
                'error'   => null,
            ];
        }

        return [
            'success' => false,
            'error'   => 'HTTP ' . $status_code,
        ];
    }

    /**
     * Render Permissions tab - Debug user permissions
     */
    private function render_permissions_tab() {
        global $wpdb;

        // Get current WordPress user
        $current_user = wp_get_current_user();
        $user_id      = $current_user->ID;

        if ( ! $user_id ) {
            ?>
<div class="checkin-alert checkin-alert-error">
    <span class="checkin-alert-icon">❌</span>
    <div class="checkin-alert-content">
        <div class="checkin-alert-title">
            <?php _e( 'Không đăng nhập', 'checkin-mkt192-wp' ); ?>
        </div>
        <div class="checkin-alert-message">
            <?php _e( 'Bạn chưa đăng nhập vào hệ thống.', 'checkin-mkt192-wp' ); ?>
        </div>
    </div>
</div>
<?php
            return;
        }

        // Get staff info
        $staff_table = $wpdb->prefix . 'checkin_mkt192_staff';
        $staff       = $wpdb->get_row( $wpdb->prepare(
            "SELECT id, display_name, user_email, user_role FROM {$staff_table} WHERE user_id = %d",
            $user_id
        ) );

        // Get all roles
        $role_table = $wpdb->prefix . 'checkin_mkt192_staff_roles';
        $all_roles  = $wpdb->get_results(
            "SELECT id, role_name, JSON_LENGTH(permissions) as module_count FROM {$role_table} ORDER BY JSON_LENGTH(permissions) DESC"
        );

        // Get current role details
        $current_role = null;
        if ( $staff && $staff->user_role ) {
            $current_role = $wpdb->get_row( $wpdb->prepare(
                "SELECT id, role_name, permissions, access_permissions FROM {$role_table} WHERE role_name = %s",
                $staff->user_role
            ) );
        }

        ?>
<div class="checkin-tools-grid">
    <!-- WordPress User Info Card -->
    <div class="checkin-tool-card">
        <div class="checkin-tool-card-header">
            <div class="checkin-tool-card-icon" style="background: linear-gradient(135deg, #2271b1, #135e96);">
                <span class="dashicons dashicons-admin-users"></span>
            </div>
            <div class="checkin-tool-card-title-wrapper">
                <h3 class="checkin-tool-card-title">
                    <?php _e( 'Tài khoản WordPress', 'checkin-mkt192-wp' ); ?>
                </h3>
                <p class="checkin-tool-card-desc">
                    <?php _e( 'Thông tin tài khoản đang đăng nhập', 'checkin-mkt192-wp' ); ?>
                </p>
            </div>
        </div>
        <div class="checkin-tool-card-body">
            <div class="checkin-system-info-grid">
                <div class="checkin-system-info-item">
                    <div class="checkin-system-info-label">User ID</div>
                    <div class="checkin-system-info-value">
                        <?php echo esc_html( $current_user->ID ); ?>
                    </div>
                </div>
                <div class="checkin-system-info-item">
                    <div class="checkin-system-info-label">
                        <?php _e( 'Username', 'checkin-mkt192-wp' ); ?>
                    </div>
                    <div class="checkin-system-info-value">
                        <?php echo esc_html( $current_user->user_login ); ?>
                    </div>
                </div>
                <div class="checkin-system-info-item">
                    <div class="checkin-system-info-label">Email</div>
                    <div class="checkin-system-info-value">
                        <?php echo esc_html( $current_user->user_email ); ?>
                    </div>
                </div>
                <div class="checkin-system-info-item">
                    <div class="checkin-system-info-label">
                        <?php _e( 'Tên hiển thị', 'checkin-mkt192-wp' ); ?>
                    </div>
                    <div class="checkin-system-info-value">
                        <?php echo esc_html( $current_user->display_name ); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php if ( ! $staff ) : ?>
    <!-- Staff Not Found Card -->
    <div class="checkin-tool-card">
        <div class="checkin-tool-card-header">
            <div class="checkin-tool-card-icon" style="background: linear-gradient(135deg, #ef4444, #dc2626);">
                <span class="dashicons dashicons-warning"></span>
            </div>
            <div class="checkin-tool-card-title-wrapper">
                <h3 class="checkin-tool-card-title">
                    <?php _e( 'Không tìm thấy Staff Record', 'checkin-mkt192-wp' ); ?>
                </h3>
            </div>
        </div>
        <div class="checkin-tool-card-body">
            <div class="checkin-alert checkin-alert-error">
                <span class="checkin-alert-icon">❌</span>
                <div class="checkin-alert-content">
                    <div class="checkin-alert-message">
                        <?php printf( __( 'WordPress user (ID: %d) chưa được liên kết với bản ghi staff trong cơ sở dữ liệu.', 'checkin-mkt192-wp' ), $user_id ); ?>
                    </div>
                    <div class="checkin-alert-message">
                        <strong><?php _e( 'Khắc phục:', 'checkin-mkt192-wp' ); ?></strong>
                        <?php _e( 'Truy cập Quản lý Nhân viên và tạo hoặc liên kết bản ghi staff với user này.', 'checkin-mkt192-wp' ); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php else : ?>
    <!-- Staff Info Card -->
    <div class="checkin-tool-card">
        <div class="checkin-tool-card-header">
            <div class="checkin-tool-card-icon" style="background: linear-gradient(135deg, #10b981, #059669);">
                <span class="dashicons dashicons-id"></span>
            </div>
            <div class="checkin-tool-card-title-wrapper">
                <h3 class="checkin-tool-card-title">
                    <?php _e( 'Thông tin Nhân viên', 'checkin-mkt192-wp' ); ?>
                </h3>
                <p class="checkin-tool-card-desc">
                    <?php _e( 'Bản ghi staff liên kết với tài khoản của bạn', 'checkin-mkt192-wp' ); ?>
                </p>
            </div>
        </div>
        <div class="checkin-tool-card-body">
            <div class="checkin-system-info-grid">
                <div class="checkin-system-info-item">
                    <div class="checkin-system-info-label">Staff ID</div>
                    <div class="checkin-system-info-value">
                        <?php echo esc_html( $staff->id ); ?>
                    </div>
                </div>
                <div class="checkin-system-info-item">
                    <div class="checkin-system-info-label">
                        <?php _e( 'Họ tên', 'checkin-mkt192-wp' ); ?>
                    </div>
                    <div class="checkin-system-info-value">
                        <?php echo esc_html( $staff->display_name ); ?>
                    </div>
                </div>
                <div class="checkin-system-info-item">
                    <div class="checkin-system-info-label">Email</div>
                    <div class="checkin-system-info-value">
                        <?php echo esc_html( $staff->user_email ); ?>
                    </div>
                </div>
                <div class="checkin-system-info-item">
                    <div class="checkin-system-info-label">
                        <?php _e( 'Vai trò', 'checkin-mkt192-wp' ); ?>
                    </div>
                    <div class="checkin-system-info-value">
                        <?php echo esc_html( $staff->user_role ); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php if ( ! $current_role ) : ?>
    <!-- Role Not Found Card -->
    <div class="checkin-tool-card checkin-tool-card-wide">
        <div class="checkin-tool-card-header">
            <div class="checkin-tool-card-icon" style="background: linear-gradient(135deg, #f59e0b, #d97706);">
                <span class="dashicons dashicons-warning"></span>
            </div>
            <div class="checkin-tool-card-title-wrapper">
                <h3 class="checkin-tool-card-title">
                    <?php _e( 'Không tìm thấy vai trò', 'checkin-mkt192-wp' ); ?>
                </h3>
            </div>
        </div>
        <div class="checkin-tool-card-body">
            <div class="checkin-alert checkin-alert-error">
                <span class="checkin-alert-icon">❌</span>
                <div class="checkin-alert-content">
                    <div class="checkin-alert-message">
                        <?php printf( __( 'Vai trò "%s" không tồn tại trong bảng vai trò.', 'checkin-mkt192-wp' ), esc_html( $staff->user_role ) ); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php else :
        $permissions  = json_decode( $current_role->permissions, true );
        $access_perms = json_decode( $current_role->access_permissions, true );
        $module_count = is_array( $permissions ) ? count( $permissions ) : 0;
        $action_count = 0;
        if ( is_array( $permissions ) ) {
            foreach ( $permissions as $actions ) {
                $action_count += is_array( $actions ) ? count( $actions ) : 0;
            }
        }

        // Get total available modules from all roles to calculate max
        $max_modules = 0;
        foreach ( $all_roles as $role ) {
            if ( $role->module_count > $max_modules ) {
                $max_modules = $role->module_count;
            }
        }

        $is_full_access = $module_count >= $max_modules;
        ?>
    <!-- Current Role Card -->
    <div class="checkin-tool-card checkin-tool-card-wide">
        <div class="checkin-tool-card-header">
            <div class="checkin-tool-card-icon"
                style="background: linear-gradient(135deg, <?php echo $is_full_access ? '#10b981, #059669' : '#f59e0b, #d97706'; ?>);">
                <span class="dashicons dashicons-admin-network"></span>
            </div>
            <div class="checkin-tool-card-title-wrapper">
                <h3 class="checkin-tool-card-title">
                    <?php printf( __( 'Vai trò hiện tại: %s', 'checkin-mkt192-wp' ), esc_html( $current_role->role_name ) ); ?>
                </h3>
                <p class="checkin-tool-card-desc">
                    <?php
                    if ( $is_full_access ) {
                        printf( __( '✅ Có đầy đủ quyền truy cập (%d modules)', 'checkin-mkt192-wp' ), $module_count );
                    } else {
                        printf( __( '⚠️ Quyền hạn chế - Chỉ có %d/%d modules', 'checkin-mkt192-wp' ), $module_count, $max_modules );
                    }
                    ?>
                </p>
            </div>
        </div>
        <div class="checkin-tool-card-body">
            <?php if ( ! $is_full_access ) : ?>
            <div class="checkin-alert checkin-alert-warning" style="margin-bottom: 20px;">
                <span class="checkin-alert-icon">⚠</span>
                <div class="checkin-alert-content">
                    <div class="checkin-alert-title">
                        <?php _e( 'Quyền hạn chế', 'checkin-mkt192-wp' ); ?>
                    </div>
                    <div class="checkin-alert-message">
                        <?php printf( __( 'Vai trò của bạn chỉ có %d modules trong tổng số %d. Đây là lý do bạn gặp lỗi 403!', 'checkin-mkt192-wp' ), $module_count, $max_modules ); ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <div class="checkin-system-info-grid">
                <div class="checkin-system-info-item">
                    <div class="checkin-system-info-label">Role ID</div>
                    <div class="checkin-system-info-value">
                        <?php echo esc_html( $current_role->id ); ?>
                    </div>
                </div>
                <div class="checkin-system-info-item">
                    <div class="checkin-system-info-label">
                        <?php _e( 'Tên vai trò', 'checkin-mkt192-wp' ); ?>
                    </div>
                    <div class="checkin-system-info-value">
                        <?php echo esc_html( $current_role->role_name ); ?>
                    </div>
                </div>
                <div class="checkin-system-info-item">
                    <div class="checkin-system-info-label">
                        <?php _e( 'Số modules', 'checkin-mkt192-wp' ); ?>
                    </div>
                    <div class="checkin-system-info-value">
                        <strong><?php echo $module_count; ?> /
                            <?php echo $max_modules; ?></strong>
                        <?php if ( $module_count < $max_modules ) : ?>
                        <span style="color: #ef4444;">
                            (<?php printf( __( 'Thiếu %d modules', 'checkin-mkt192-wp' ), $max_modules - $module_count ); ?>)
                        </span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="checkin-system-info-item">
                    <div class="checkin-system-info-label">
                        <?php _e( 'Tổng số actions', 'checkin-mkt192-wp' ); ?>
                    </div>
                    <div class="checkin-system-info-value">
                        <?php echo $action_count; ?>
                    </div>
                </div>
                <div class="checkin-system-info-item">
                    <div class="checkin-system-info-label">
                        <?php _e( 'Quyền truy cập', 'checkin-mkt192-wp' ); ?>
                    </div>
                    <div class="checkin-system-info-value">
                        <?php echo is_array( $access_perms ) && ! empty( $access_perms ) ? implode( ', ', $access_perms ) : __( 'Không có', 'checkin-mkt192-wp' ); ?>
                    </div>
                </div>
                <div class="checkin-system-info-item">
                    <div class="checkin-system-info-label">
                        <?php _e( 'Danh sách modules', 'checkin-mkt192-wp' ); ?>
                    </div>
                    <div class="checkin-system-info-value">
                        <?php echo is_array( $permissions ) && ! empty( $permissions ) ? implode( ', ', array_keys( $permissions ) ) : __( 'Không có', 'checkin-mkt192-wp' ); ?>
                    </div>
                </div>
            </div>

            <?php if ( ! $is_full_access && ! empty( $all_roles ) ) :
                // Find role with most permissions
                $best_role = $all_roles[0];
            ?>
            <div style="margin-top: 20px;">
                <h4 style="margin-bottom: 10px; color: #2271b1;">
                    <?php _e( '🔧 Cách khắc phục', 'checkin-mkt192-wp' ); ?>
                </h4>
                <div class="checkin-alert checkin-alert-info" style="margin-bottom: 15px;">
                    <span class="checkin-alert-icon">💡</span>
                    <div class="checkin-alert-content">
                        <div class="checkin-alert-title">
                            <?php _e( 'Phương án 1: Thay đổi vai trò Staff (Khuyến nghị)', 'checkin-mkt192-wp' ); ?>
                        </div>
                        <div class="checkin-alert-message">
                            <p><?php _e( 'Chạy lệnh SQL sau trong phpMyAdmin:', 'checkin-mkt192-wp' ); ?>
                            </p>
                            <pre
                                style="background: #000; color: #0f0; padding: 15px; border-radius: 5px; overflow-x: auto;">UPDATE wp_checkin_mkt192_staff SET user_role = '<?php echo esc_sql( $best_role->role_name ); ?>' WHERE id = <?php echo $staff->id; ?>;</pre>
                            <p><?php printf( __( 'Thay đổi vai trò từ <strong>%s</strong> (%d/%d modules) thành <strong>%s</strong> (%d/%d modules).', 'checkin-mkt192-wp' ), esc_html( $current_role->role_name ), $module_count, $max_modules, esc_html( $best_role->role_name ), $best_role->module_count, $max_modules ); ?>
                            </p>
                        </div>
                    </div>
                </div>

                <div class="checkin-alert checkin-alert-info">
                    <span class="checkin-alert-icon">💡</span>
                    <div class="checkin-alert-content">
                        <div class="checkin-alert-title">
                            <?php _e( 'Phương án 2: Cập nhật quyền của vai trò hiện tại', 'checkin-mkt192-wp' ); ?>
                        </div>
                        <div class="checkin-alert-message">
                            <p><?php printf( __( 'Hoặc bạn có thể cập nhật vai trò <strong>%s</strong> để có đủ %d modules.', 'checkin-mkt192-wp' ), esc_html( $current_role->role_name ), $max_modules ); ?>
                            </p>
                            <p><?php printf( __( 'Truy cập: <strong>Cài đặt Admin → Vai trò → Sửa "%s"</strong>', 'checkin-mkt192-wp' ), esc_html( $current_role->role_name ) ); ?>
                            </p>
                            <p><?php printf( __( 'Sau đó chọn tất cả %d modules với các actions của chúng.', 'checkin-mkt192-wp' ), $max_modules ); ?>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- All Roles Table -->
    <div class="checkin-tool-card checkin-tool-card-wide">
        <div class="checkin-tool-card-header">
            <div class="checkin-tool-card-icon" style="background: linear-gradient(135deg, #8b5cf6, #7c3aed);">
                <span class="dashicons dashicons-groups"></span>
            </div>
            <div class="checkin-tool-card-title-wrapper">
                <h3 class="checkin-tool-card-title">
                    <?php _e( 'Tất cả các vai trò', 'checkin-mkt192-wp' ); ?>
                </h3>
                <p class="checkin-tool-card-desc">
                    <?php _e( 'Danh sách các vai trò có trong hệ thống', 'checkin-mkt192-wp' ); ?>
                </p>
            </div>
        </div>
        <div class="checkin-tool-card-body">
            <table class="widefat" style="width: 100%;">
                <thead>
                    <tr>
                        <th>Role ID</th>
                        <th><?php _e( 'Tên vai trò', 'checkin-mkt192-wp' ); ?>
                        </th>
                        <th><?php _e( 'Modules', 'checkin-mkt192-wp' ); ?>
                        </th>
                        <th><?php _e( 'Trạng thái', 'checkin-mkt192-wp' ); ?>
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ( $all_roles as $role ) : ?>
                    <tr
                        <?php if ( $current_role && $role->id == $current_role->id ) echo 'style="background: #ffffcc;"'; ?>>
                        <td><?php echo esc_html( $role->id ); ?></td>
                        <td>
                            <strong><?php echo esc_html( $role->role_name ); ?></strong>
                            <?php if ( $current_role && $role->id == $current_role->id ) echo ' <span style="color: #2271b1;">(' . __( 'Hiện tại', 'checkin-mkt192-wp' ) . ')</span>'; ?>
                        </td>
                        <td><?php echo esc_html( $role->module_count ); ?>
                        </td>
                        <td>
                            <?php if ( $role->module_count >= $max_modules ) : ?>
                            <span style="color: #10b981;">✅
                                <?php _e( 'Đầy đủ quyền', 'checkin-mkt192-wp' ); ?></span>
                            <?php else : ?>
                            <span style="color: #f59e0b;">⚠️
                                <?php printf( __( 'Hạn chế (%d/%d)', 'checkin-mkt192-wp' ), $role->module_count, $max_modules ); ?></span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>
</div>
<?php
    }
}
?>