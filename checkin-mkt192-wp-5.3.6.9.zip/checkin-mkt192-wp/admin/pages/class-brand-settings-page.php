<?php
/**
 * Brand Settings Page
 *
 * @package    Checkin_MKT192_WP
 * @subpackage Admin/Pages
 * @since      5.1.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class Checkin_MKT192_WP_Brand_Settings_Page
 *
 * Handles the Brand Settings admin page
 */
class Checkin_MKT192_WP_Brand_Settings_Page {

    /**
     * Page slug
     *
     * @var string
     */
    private $page_slug = 'checkin-mkt192-brand-settings';

    /**
     * Tab configuration
     *
     * @var array
     */
    private $tabs = [];

    /**
     * Constructor
     */
    public function __construct() {
        $this->setup_tabs();
        $this->register_settings();
        $this->register_ajax_handlers();
    }

    /**
     * Register AJAX handlers
     */
    private function register_ajax_handlers() {
        add_action('wp_ajax_checkin_save_brand_settings', [$this, 'ajax_save_brand_settings']);
        add_action('wp_ajax_checkin_save_branch', [$this, 'ajax_save_branch']);
        add_action('wp_ajax_checkin_delete_branch', [$this, 'ajax_delete_branch']);
        add_action('wp_ajax_checkin_get_branch', [$this, 'ajax_get_branch']);
        add_action('wp_ajax_checkin_get_google_map', [$this, 'ajax_get_google_map']);
        add_action('wp_ajax_checkin_get_branches_list', [$this, 'ajax_get_branches_list']);
    }

    /**
     * AJAX handler for saving brand settings
     */
    public function ajax_save_brand_settings() {
        error_log('=== Brand Settings AJAX Called ===');
        error_log('POST data: ' . print_r($_POST, true));

        try {
            check_ajax_referer('checkin-admin-nonce', 'nonce');
        } catch (Exception $e) {
            error_log('Nonce verification failed: ' . $e->getMessage());
            wp_send_json_error(['message' => __('Xác thực không hợp lệ!', 'checkin-mkt192')]);
            return;
        }

        if (!current_user_can('manage_options')) {
            error_log('User does not have manage_options capability');
            wp_send_json_error(['message' => __('Bạn không có quyền thực hiện hành động này!', 'checkin-mkt192')]);
        }

        $setting_type = isset($_POST['setting_type']) ? sanitize_key($_POST['setting_type']) : '';
        error_log('Setting type: ' . $setting_type);

        if (empty($setting_type)) {
            wp_send_json_error(['message' => __('Thiếu thông tin cài đặt!', 'checkin-mkt192')]);
        }

        // Save settings based on type
        switch ($setting_type) {
            case 'logo-colors':
                update_option('checkin_logo_url', isset($_POST['checkin_logo_url']) ? esc_url_raw($_POST['checkin_logo_url']) : '');
                update_option('checkin_banner_url', isset($_POST['checkin_banner_url']) ? esc_url_raw($_POST['checkin_banner_url']) : '');
                update_option('checkin_primary_color', isset($_POST['checkin_primary_color']) ? sanitize_hex_color($_POST['checkin_primary_color']) : '#2271b1');
                update_option('checkin_secondary_color', isset($_POST['checkin_secondary_color']) ? sanitize_hex_color($_POST['checkin_secondary_color']) : '#50575e');
                break;

            case 'information':
                update_option('checkin_brand_name', isset($_POST['checkin_brand_name']) ? sanitize_text_field($_POST['checkin_brand_name']) : '');
                update_option('checkin_email', isset($_POST['checkin_email']) ? sanitize_email($_POST['checkin_email']) : '');
                update_option('checkin_phone', isset($_POST['checkin_phone']) ? sanitize_text_field($_POST['checkin_phone']) : '');

                // Save branch mode setting
                $branch_mode_enabled = isset($_POST['checkin_branch_mode_enabled']) && $_POST['checkin_branch_mode_enabled'] == '1' ? '1' : '0';
                update_option('checkin_branch_mode_enabled', $branch_mode_enabled);

                // Save common address only if branch mode is OFF
                if ($branch_mode_enabled == '0') {
                    update_option('checkin_address', isset($_POST['checkin_address']) ? sanitize_textarea_field($_POST['checkin_address']) : '');
                }

                // Save domain as plain text (without protocol)
                $domain = isset($_POST['checkin_domain']) ? trim(sanitize_text_field($_POST['checkin_domain'])) : '';
                // Remove any protocol if user accidentally includes it
                $domain = preg_replace('#^https?://#i', '', $domain);
                update_option('checkin_domain', $domain);
                update_option('checkin_opening_hours', isset($_POST['checkin_opening_hours']) ? sanitize_text_field($_POST['checkin_opening_hours']) : '');

                // Save Google Maps embed code (iframe or URL)
                if (isset($_POST['checkin_google_map'])) {
                    $google_map_input = stripslashes($_POST['checkin_google_map']);

                    // If it's an iframe, extract the src URL only for security
                    if (strpos($google_map_input, '<iframe') !== false) {
                        // Extract src from iframe
                        preg_match('/src=["\']([^"\']+)["\']/', $google_map_input, $matches);
                        if (!empty($matches[1])) {
                            // Save only the embed URL
                            $google_map_value = esc_url_raw($matches[1]);
                        } else {
                            $google_map_value = '';
                        }
                    } else {
                        // If it's just a URL, save it
                        $google_map_value = esc_url_raw($google_map_input);
                    }

                    update_option('checkin_google_map', $google_map_value, false);
                }
                break;

            case 'social-links':
                update_option('checkin_fanpage', isset($_POST['checkin_fanpage']) ? esc_url_raw($_POST['checkin_fanpage']) : '');
                update_option('checkin_tiktok', isset($_POST['checkin_tiktok']) ? esc_url_raw($_POST['checkin_tiktok']) : '');
                update_option('checkin_youtube', isset($_POST['checkin_youtube']) ? esc_url_raw($_POST['checkin_youtube']) : '');
                break;

            default:
                wp_send_json_error(['message' => __('Loại cài đặt không hợp lệ!', 'checkin-mkt192')]);
        }

        wp_send_json_success(['message' => __('Cài đặt đã được lưu thành công!', 'checkin-mkt192')]);
    }

    /**
     * Setup tabs configuration
     */
    private function setup_tabs() {
        $this->tabs = [
            'logo-colors' => [
                'title' => __('Logo & Colors', 'checkin-mkt192'),
                'icon'  => 'dashicons-art',
            ],
            'information' => [
                'title' => __('Information', 'checkin-mkt192'),
                'icon'  => 'dashicons-info',
            ],
            'social-links' => [
                'title' => __('Social Links', 'checkin-mkt192'),
                'icon'  => 'dashicons-share',
            ],
        ];
    }

    /**
     * Register settings
     */
    private function register_settings() {
        // Logo & Colors settings
        register_setting('checkin_brand_logo_colors', 'checkin_logo_url', [
            'type'              => 'string',
            'sanitize_callback' => 'esc_url_raw',
            'default'           => '',
        ]);

        register_setting('checkin_brand_logo_colors', 'checkin_banner_url', [
            'type'              => 'string',
            'sanitize_callback' => 'esc_url_raw',
            'default'           => '',
        ]);

        register_setting('checkin_brand_logo_colors', 'checkin_primary_color', [
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_hex_color',
            'default'           => '#2271b1',
        ]);

        register_setting('checkin_brand_logo_colors', 'checkin_secondary_color', [
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_hex_color',
            'default'           => '#50575e',
        ]);

        // Information settings
        register_setting('checkin_brand_information', 'checkin_brand_name', [
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default'           => '',
        ]);

        register_setting('checkin_brand_information', 'checkin_domain', [
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default'           => '',
        ]);

        register_setting('checkin_brand_information', 'checkin_address', [
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default'           => '',
        ]);

        register_setting('checkin_brand_information', 'checkin_phone', [
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default'           => '',
        ]);

        register_setting('checkin_brand_information', 'checkin_email', [
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_email',
            'default'           => '',
        ]);

        register_setting('checkin_brand_information', 'checkin_opening_hours', [
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default'           => '',
        ]);

        // Social Links settings
        register_setting('checkin_brand_social_links', 'checkin_fanpage', [
            'type'              => 'string',
            'sanitize_callback' => 'esc_url_raw',
            'default'           => '',
        ]);

        register_setting('checkin_brand_social_links', 'checkin_tiktok', [
            'type'              => 'string',
            'sanitize_callback' => 'esc_url_raw',
            'default'           => '',
        ]);

        register_setting('checkin_brand_social_links', 'checkin_youtube', [
            'type'              => 'string',
            'sanitize_callback' => 'esc_url_raw',
            'default'           => '',
        ]);

        register_setting('checkin_brand_social_links', 'checkin_google_map', [
            'type'              => 'string',
            'sanitize_callback' => 'wp_kses_post',
            'default'           => '',
        ]);
    }

    /**
     * Render the page
     */
    public function render() {
        ?>
<div class="wrap checkin-admin-wrapper">
    <?php include CHECKIN_PLUGIN_DIR . 'admin/partials/global-header.php'; ?>
    <?php include CHECKIN_PLUGIN_DIR . 'admin/partials/admin-notices.php'; ?>
    <div class="checkin-admin-page">
        <?php $this->render_page_header(); ?>
        <?php $this->render_settings_grid(); ?>
        <?php $this->render_modals(); ?>
    </div>
</div>
<?php
    }

    /**
     * Render page header
     */
    private function render_page_header() {
        ?>
<div class="checkin-page-header">
    <div>
        <h1 class="checkin-page-title">
            <span class="dashicons dashicons-admin-appearance"></span>
            <?php _e('Cài đặt Thương hiệu', 'checkin-mkt192'); ?>
        </h1>
        <p class="checkin-page-description">
            <?php _e('Cấu hình thông tin thương hiệu, logo, màu sắc và mạng xã hội', 'checkin-mkt192'); ?>
        </p>
    </div>
</div>
<?php
    }

    /**
     * Render settings grid
     */
    private function render_settings_grid() {
        $settings = [
            'logo-colors' => [
                'title'   => __('Logo & Colors', 'checkin-mkt192'),
                'icon'    => 'dashicons-art',
                'color'   => '#8b5cf6',
                'enabled' => !empty(get_option('checkin_logo_url', '')) || !empty(get_option('checkin_primary_color', '')),
            ],
            'information' => [
                'title'   => __('Information', 'checkin-mkt192'),
                'icon'    => 'dashicons-info',
                'color'   => '#3b82f6',
                'enabled' => !empty(get_option('checkin_brand_name', '')) || !empty(get_option('checkin_email', '')),
            ],
            'social-links' => [
                'title'   => __('Social Links', 'checkin-mkt192'),
                'icon'    => 'dashicons-share',
                'color'   => '#10b981',
                'enabled' => !empty(get_option('checkin_facebook_url', '')) || !empty(get_option('checkin_twitter_url', '')),
            ],
        ];
        ?>
<div class="checkin-settings-grid">
    <?php foreach ($settings as $key => $setting) : ?>
    <div class="checkin-setting-card <?php echo $setting['enabled'] ? 'configured' : 'not-configured'; ?>"
        data-setting="<?php echo esc_attr($key); ?>">
        <div class="checkin-setting-header">
            <div class="checkin-setting-icon" style="background: <?php echo esc_attr($setting['color']); ?>">
                <span class="dashicons <?php echo esc_attr($setting['icon']); ?>"></span>
            </div>
            <div class="checkin-setting-info">
                <h3 class="checkin-setting-title">
                    <?php echo esc_html($setting['title']); ?>
                </h3>
                <div class="checkin-setting-status">
                    <?php if ($setting['enabled']) : ?>
                    <span class="checkin-badge checkin-badge-success">
                        <?php _e('Đã cấu hình', 'checkin-mkt192'); ?>
                    </span>
                    <?php else : ?>
                    <span class="checkin-badge checkin-badge-gray">
                        <?php _e('Chưa cấu hình', 'checkin-mkt192'); ?>
                    </span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="checkin-setting-body">
            <div class="checkin-setting-toggle-wrapper">
                <label class="checkin-toggle checkin-toggle-lg">
                    <input type="checkbox" class="checkin-setting-toggle" data-setting="<?php echo esc_attr($key); ?>"
                        <?php checked($setting['enabled'], true); ?>>
                    <span class="checkin-toggle-slider"></span>
                </label>
                <span class="checkin-toggle-status-text">
                    <?php echo $setting['enabled'] ? __('Đang dùng', 'checkin-mkt192') : __('Chưa dùng', 'checkin-mkt192'); ?>
                </span>
            </div>
            <button type="button"
                class="checkin-button checkin-button-secondary checkin-button-sm checkin-button-settings"
                onclick="openBrandModal('<?php echo esc_js($key); ?>')">
                <span class="dashicons dashicons-admin-settings"></span>
                <?php _e('Cài đặt', 'checkin-mkt192'); ?>
            </button>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<?php
    }

    /**
     * Render modals
     */
    private function render_modals() {
        $this->render_logo_colors_modal();
        $this->render_information_modal();
        $this->render_social_links_modal();
        $this->render_branch_modal();
    }

    /**
     * Render Logo & Colors Modal
     */
    private function render_logo_colors_modal() {
        $logo_url        = get_option('checkin_logo_url', '');
        $banner_url      = get_option('checkin_banner_url', '');
        $primary_color   = get_option('checkin_primary_color', '#2271b1');
        $secondary_color = get_option('checkin_secondary_color', '#50575e');
        ?>
<div id="modal-logo-colors" class="checkin-modal-backdrop">
    <div class="checkin-modal" style="max-width: 700px;">
        <div class="checkin-modal-header">
            <h2 class="checkin-modal-title">
                <span class="dashicons dashicons-art" style="color: #8b5cf6;"></span>
                <?php _e('Cài đặt Logo & Colors', 'checkin-mkt192'); ?>
            </h2>
            <button type="button" class="checkin-modal-close" onclick="closeBrandModal('logo-colors')">
                <span class="dashicons dashicons-no-alt"></span>
            </button>
        </div>
        <form id="form-logo-colors" class="checkin-brand-form">
            <div class="checkin-modal-body">
                <!-- Logo Section -->
                <div class="checkin-image-upload-section">
                    <label class="checkin-form-label required">
                        <span class="dashicons dashicons-format-image"></span>
                        <?php _e('Logo thương hiệu', 'checkin-mkt192'); ?>
                    </label>

                    <div class="checkin-image-upload-container">
                        <div class="checkin-image-preview-box <?php echo !empty($logo_url) ? 'has-image' : ''; ?>"
                            data-target="logo">
                            <?php if (!empty($logo_url)) : ?>
                            <img src="<?php echo esc_url($logo_url); ?>" alt="Logo" class="checkin-preview-img">
                            <div class="checkin-image-overlay">
                                <button type="button" class="checkin-btn-change-image" data-target="logo">
                                    <span class="dashicons dashicons-edit"></span>
                                    <?php _e('Thay đổi', 'checkin-mkt192'); ?>
                                </button>
                                <button type="button" class="checkin-btn-remove-image" data-target="logo">
                                    <span class="dashicons dashicons-trash"></span>
                                    <?php _e('Xóa', 'checkin-mkt192'); ?>
                                </button>
                            </div>
                            <?php else : ?>
                            <div class="checkin-image-placeholder">
                                <span class="dashicons dashicons-format-image"></span>
                                <p><?php _e('Chưa có logo', 'checkin-mkt192'); ?>
                                </p>
                            </div>
                            <?php endif; ?>
                        </div>

                        <div class="checkin-image-actions">
                            <button type="button"
                                class="checkin-button checkin-button-secondary checkin-btn-upload-image"
                                data-target="logo">
                                <span class="dashicons dashicons-upload"></span>
                                <?php _e('Tải lên', 'checkin-mkt192'); ?>
                            </button>
                            <button type="button" class="checkin-button checkin-button-secondary checkin-btn-input-url"
                                data-target="logo">
                                <span class="dashicons dashicons-admin-links"></span>
                                <?php _e('Nhập URL', 'checkin-mkt192'); ?>
                            </button>
                        </div>

                        <input type="hidden" name="checkin_logo_url" id="checkin_logo_url"
                            value="<?php echo esc_attr($logo_url); ?>" required>

                        <div class="checkin-url-input-box" id="url-input-logo" style="display: none;">
                            <input type="url" class="checkin-form-input" placeholder="https://example.com/logo.png"
                                data-target="logo">
                            <div class="checkin-url-input-actions">
                                <button type="button"
                                    class="checkin-button checkin-button-sm checkin-button-primary checkin-btn-apply-url"
                                    data-target="logo">
                                    <span class="dashicons dashicons-yes"></span>
                                    <?php _e('Áp dụng', 'checkin-mkt192'); ?>
                                </button>
                                <button type="button"
                                    class="checkin-button checkin-button-sm checkin-button-secondary checkin-btn-cancel-url"
                                    data-target="logo">
                                    <span class="dashicons dashicons-no"></span>
                                    <?php _e('Hủy', 'checkin-mkt192'); ?>
                                </button>
                            </div>
                        </div>

                        <p class="checkin-form-description">
                            <span class="dashicons dashicons-info"></span>
                            <?php _e('Khuyến nghị: 200x80px, PNG với nền trong suốt', 'checkin-mkt192'); ?>
                        </p>
                    </div>
                </div>

                <div class="checkin-divider"></div>

                <!-- Banner Section -->
                <div class="checkin-image-upload-section">
                    <label class="checkin-form-label">
                        <span class="dashicons dashicons-format-image"></span>
                        <?php _e('Banner', 'checkin-mkt192'); ?>
                        <span class="checkin-badge checkin-badge-gray"><?php _e('Tùy chọn', 'checkin-mkt192'); ?></span>
                    </label>

                    <div class="checkin-image-upload-container">
                        <div class="checkin-image-preview-box checkin-banner-preview <?php echo !empty($banner_url) ? 'has-image' : ''; ?>"
                            data-target="banner">
                            <?php if (!empty($banner_url)) : ?>
                            <img src="<?php echo esc_url($banner_url); ?>" alt="Banner" class="checkin-preview-img">
                            <div class="checkin-image-overlay">
                                <button type="button" class="checkin-btn-change-image" data-target="banner">
                                    <span class="dashicons dashicons-edit"></span>
                                    <?php _e('Thay đổi', 'checkin-mkt192'); ?>
                                </button>
                                <button type="button" class="checkin-btn-remove-image" data-target="banner">
                                    <span class="dashicons dashicons-trash"></span>
                                    <?php _e('Xóa', 'checkin-mkt192'); ?>
                                </button>
                            </div>
                            <?php else : ?>
                            <div class="checkin-image-placeholder">
                                <span class="dashicons dashicons-format-image"></span>
                                <p><?php _e('Chưa có banner', 'checkin-mkt192'); ?>
                                </p>
                            </div>
                            <?php endif; ?>
                        </div>

                        <div class="checkin-image-actions">
                            <button type="button"
                                class="checkin-button checkin-button-secondary checkin-btn-upload-image"
                                data-target="banner">
                                <span class="dashicons dashicons-upload"></span>
                                <?php _e('Tải lên', 'checkin-mkt192'); ?>
                            </button>
                            <button type="button" class="checkin-button checkin-button-secondary checkin-btn-input-url"
                                data-target="banner">
                                <span class="dashicons dashicons-admin-links"></span>
                                <?php _e('Nhập URL', 'checkin-mkt192'); ?>
                            </button>
                        </div>

                        <input type="hidden" name="checkin_banner_url" id="checkin_banner_url"
                            value="<?php echo esc_attr($banner_url); ?>">

                        <div class="checkin-url-input-box" id="url-input-banner" style="display: none;">
                            <input type="url" class="checkin-form-input" placeholder="https://example.com/banner.png"
                                data-target="banner">
                            <div class="checkin-url-input-actions">
                                <button type="button"
                                    class="checkin-button checkin-button-sm checkin-button-primary checkin-btn-apply-url"
                                    data-target="banner">
                                    <span class="dashicons dashicons-yes"></span>
                                    <?php _e('Áp dụng', 'checkin-mkt192'); ?>
                                </button>
                                <button type="button"
                                    class="checkin-button checkin-button-sm checkin-button-secondary checkin-btn-cancel-url"
                                    data-target="banner">
                                    <span class="dashicons dashicons-no"></span>
                                    <?php _e('Hủy', 'checkin-mkt192'); ?>
                                </button>
                            </div>
                        </div>

                        <p class="checkin-form-description">
                            <span class="dashicons dashicons-info"></span>
                            <?php _e('Khuyến nghị: 1200x400px, dùng cho trang đăng nhập', 'checkin-mkt192'); ?>
                        </p>
                    </div>
                </div>

                <div class="checkin-divider"></div>

                <!-- Color Section -->
                <div class="checkin-colors-section">
                    <label class="checkin-form-label">
                        <span class="dashicons dashicons-art"></span>
                        <?php _e('Màu sắc thương hiệu', 'checkin-mkt192'); ?>
                    </label>

                    <div class="checkin-color-grid">
                        <div class="checkin-color-picker-box">
                            <label class="checkin-color-label">
                                <?php _e('Màu chính', 'checkin-mkt192'); ?>
                                <span class="checkin-required">*</span>
                            </label>
                            <div class="checkin-color-input-wrapper">
                                <input type="color" name="checkin_primary_color"
                                    value="<?php echo esc_attr($primary_color); ?>" class="checkin-color-input"
                                    required>
                                <input type="text" class="checkin-color-text"
                                    value="<?php echo esc_attr($primary_color); ?>" readonly>
                            </div>
                            <p class="checkin-color-desc">
                                <?php _e('Dùng cho nút, liên kết', 'checkin-mkt192'); ?>
                            </p>
                        </div>

                        <div class="checkin-color-picker-box">
                            <label class="checkin-color-label">
                                <?php _e('Màu phụ', 'checkin-mkt192'); ?>
                                <span class="checkin-required">*</span>
                            </label>
                            <div class="checkin-color-input-wrapper">
                                <input type="color" name="checkin_secondary_color"
                                    value="<?php echo esc_attr($secondary_color); ?>" class="checkin-color-input"
                                    required>
                                <input type="text" class="checkin-color-text"
                                    value="<?php echo esc_attr($secondary_color); ?>" readonly>
                            </div>
                            <p class="checkin-color-desc">
                                <?php _e('Dùng cho yếu tố phụ', 'checkin-mkt192'); ?>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="checkin-modal-footer">
                <button type="button" class="checkin-button checkin-button-secondary"
                    onclick="closeBrandModal('logo-colors')">
                    <?php _e('Hủy', 'checkin-mkt192'); ?>
                </button>
                <button type="submit" class="checkin-button checkin-button-primary">
                    <?php _e('Lưu cài đặt', 'checkin-mkt192'); ?>
                </button>
            </div>
        </form>
    </div>
</div>
<?php
    }

    /**
     * Render Information Modal
     */
    private function render_information_modal() {
        global $wpdb;

        $brand_name     = get_option('checkin_brand_name', '');
        $email          = get_option('checkin_email', '');
        $phone          = get_option('checkin_phone', '');
        $address        = get_option('checkin_address', '');
        $domain         = get_option('checkin_domain', '');
        $opening_hours  = get_option('checkin_opening_hours', '');
        $google_map     = get_option('checkin_google_map', '');
        $branch_mode    = get_option('checkin_branch_mode_enabled', '0');

        // Get all branches
        $branches = $wpdb->get_results(
            "SELECT id, location_name, address, google_map_link, latitude, longitude, radius, is_main_branch
             FROM {$wpdb->prefix}checkin_mkt192_locations
             ORDER BY is_main_branch DESC, location_name ASC",
            ARRAY_A
        );
        ?>
<div id="modal-information" class="checkin-modal-backdrop">
    <div class="checkin-modal" style="max-width: 700px;">
        <div class="checkin-modal-header">
            <h2 class="checkin-modal-title">
                <span class="dashicons dashicons-info" style="color: #3b82f6;"></span>
                <?php _e('Cài đặt Information', 'checkin-mkt192'); ?>
            </h2>
            <button type="button" class="checkin-modal-close" onclick="closeBrandModal('information')">
                <span class="dashicons dashicons-no-alt"></span>
            </button>
        </div>
        <form id="form-information" class="checkin-brand-form">
            <div class="checkin-modal-body">
                <div class="checkin-form-group">
                    <label class="checkin-form-label required">
                        <?php _e('Tên thương hiệu', 'checkin-mkt192'); ?>
                    </label>
                    <input type="text" name="checkin_brand_name" value="<?php echo esc_attr($brand_name); ?>"
                        class="checkin-form-input" placeholder="Công ty TNHH ABC" required>
                </div>

                <div class="checkin-form-group">
                    <label class="checkin-form-label required">
                        <?php _e('Email', 'checkin-mkt192'); ?>
                    </label>
                    <input type="email" name="checkin_email" value="<?php echo esc_attr($email); ?>"
                        class="checkin-form-input" placeholder="info@company.com" required>
                </div>

                <div class="checkin-form-group">
                    <label class="checkin-form-label required">
                        <?php _e('Số điện thoại', 'checkin-mkt192'); ?>
                    </label>
                    <input type="tel" name="checkin_phone" value="<?php echo esc_attr($phone); ?>"
                        class="checkin-form-input" placeholder="0123456789" required>
                </div>

                <!-- Địa chỉ chung - hiển thị khi toggle TẮT -->
                <div id="common-address-group-brand" style="<?php echo $branch_mode == '1' ? 'display: none;' : ''; ?>">
                    <div class="checkin-form-group">
                        <label class="checkin-form-label required">
                            <?php _e('Địa chỉ', 'checkin-mkt192'); ?>
                        </label>
                        <textarea name="checkin_address" class="checkin-form-input" rows="3"
                            placeholder="Địa chỉ công ty"
                            <?php echo $branch_mode == '1' ? '' : 'required'; ?>><?php echo esc_textarea($address); ?></textarea>
                    </div>

                    <div class="checkin-form-group">
                        <label class="checkin-form-label required">
                            <?php _e('Google Map Embed', 'checkin-mkt192'); ?>
                        </label>
                        <textarea name="checkin_google_map" class="checkin-form-input" rows="4"
                            placeholder="<iframe src='https://www.google.com/maps/embed?pb=...'></iframe>"
                            <?php echo $branch_mode == '1' ? '' : 'required'; ?>><?php echo esc_textarea($google_map); ?></textarea>
                        <p class="checkin-form-description">
                            <?php _e('Dán mã nhúng iframe từ Google Maps', 'checkin-mkt192'); ?>
                        </p>
                    </div>
                </div>

                <!-- Toggle switch cho chế độ chi nhánh -->
                <div class="checkin-form-group">
                    <label class="checkin-form-label">
                        <?php _e('Chế độ đa chi nhánh', 'checkin-mkt192'); ?>
                    </label>
                    <div style="display: flex; align-items: center; gap: 12px;">
                        <label class="checkin-toggle checkin-toggle-lg">
                            <input type="checkbox" id="branch-mode-toggle-brand" name="checkin_branch_mode_enabled"
                                value="1" <?php checked($branch_mode, '1'); ?>>
                            <span class="checkin-toggle-slider"></span>
                        </label>
                        <span class="checkin-toggle-status-text" id="branch-mode-label-brand">
                            <?php echo $branch_mode == '1' ? __('Đang bật', 'checkin-mkt192') : __('Đang tắt', 'checkin-mkt192'); ?>
                        </span>
                    </div>
                    <p class="checkin-form-description">
                        <?php _e('Bật để quản lý nhiều chi nhánh với địa chỉ riêng biệt', 'checkin-mkt192'); ?>
                    </p>
                </div>

                <!-- Phần quản lý chi nhánh - hiển thị khi toggle BẬT -->
                <div id="branch-management-section-brand"
                    style="<?php echo $branch_mode == '1' ? '' : 'display: none;'; ?>">
                    <div class="checkin-divider"></div>

                    <div class="checkin-form-group">
                        <label class="checkin-form-label">
                            <span class="dashicons dashicons-location"></span>
                            <?php _e('Danh sách chi nhánh', 'checkin-mkt192'); ?>
                        </label>

                        <?php if (!empty($branches)) : ?>
                        <div class="checkin-branches-list">
                            <?php foreach ($branches as $branch) : ?>
                            <div class="checkin-branch-item" data-branch-id="<?php echo esc_attr($branch['id']); ?>">
                                <div class="checkin-branch-header">
                                    <div class="checkin-branch-name">
                                        <strong><?php echo esc_html($branch['location_name']); ?></strong>
                                        <?php if ($branch['is_main_branch'] == 1) : ?>
                                        <span class="checkin-badge checkin-badge-success">
                                            <span class="dashicons dashicons-star-filled"></span>
                                            <?php _e('Chi nhánh chính', 'checkin-mkt192'); ?>
                                        </span>
                                        <?php endif; ?>
                                    </div>
                                    <div style="display: flex; gap: 8px;">
                                        <button type="button"
                                            class="checkin-button checkin-button-sm checkin-button-secondary checkin-btn-edit-branch"
                                            data-branch-id="<?php echo esc_attr($branch['id']); ?>">
                                            <span class="dashicons dashicons-edit"></span>
                                            <?php _e('Sửa', 'checkin-mkt192'); ?>
                                        </button>
                                        <button type="button"
                                            class="checkin-button checkin-button-sm checkin-button-danger checkin-btn-delete-branch"
                                            data-branch-id="<?php echo esc_attr($branch['id']); ?>">
                                            <span class="dashicons dashicons-trash"></span>
                                            <?php _e('Xóa', 'checkin-mkt192'); ?>
                                        </button>
                                    </div>
                                </div>
                                <div class="checkin-branch-details">
                                    <div class="checkin-branch-info">
                                        <i class="dashicons dashicons-location"></i>
                                        <?php echo esc_html($branch['address'] ?: __('Chưa có địa chỉ', 'checkin-mkt192')); ?>
                                    </div>
                                    <?php if ($branch['google_map_link']) : ?>
                                    <div class="checkin-branch-info">
                                        <i class="dashicons dashicons-admin-site"></i>
                                        <a href="<?php echo esc_url($branch['google_map_link']); ?>" target="_blank">
                                            <?php _e('Xem trên Google Maps', 'checkin-mkt192'); ?>
                                        </a>
                                    </div>
                                    <?php endif; ?>
                                    <div class="checkin-branch-info">
                                        <i class="dashicons dashicons-location-alt"></i>
                                        <?php echo esc_html($branch['latitude']); ?>,
                                        <?php echo esc_html($branch['longitude']); ?>
                                        (<?php echo esc_html($branch['radius']); ?>m)
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <?php else : ?>
                        <div class="checkin-empty-state">
                            <span class="dashicons dashicons-location" style="font-size: 48px; opacity: 0.3;"></span>
                            <p><?php _e('Chưa có chi nhánh nào. Hãy tạo chi nhánh đầu tiên!', 'checkin-mkt192'); ?>
                            </p>
                        </div>
                        <?php endif; ?>

                        <button type="button"
                            class="checkin-button checkin-button-secondary checkin-button-sm checkin-btn-add-branch"
                            style="margin-top: 16px;">
                            <span class="dashicons dashicons-plus"></span>
                            <?php _e('Thêm chi nhánh mới', 'checkin-mkt192'); ?>
                        </button>
                    </div>
                </div>

                <div class="checkin-form-group">
                    <label class="checkin-form-label required">
                        <?php _e('Domain', 'checkin-mkt192'); ?>
                    </label>
                    <input type="text" name="checkin_domain" value="<?php echo esc_attr($domain); ?>"
                        class="checkin-form-input" placeholder="ví dụ: shopabc.com hoặc localhost:8080"
                        pattern="^([a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$|^localhost(:[0-9]+)?$"
                        title="Nhập tên miền hợp lệ (ví dụ: shopabc.com) hoặc localhost với port (localhost:8080)"
                        required>
                </div>

                <div class="checkin-form-group">
                    <label class="checkin-form-label required">
                        <?php _e('Thời gian hoạt động', 'checkin-mkt192'); ?>
                    </label>
                    <input type="text" name="checkin_opening_hours" value="<?php echo esc_attr($opening_hours); ?>"
                        class="checkin-form-input" placeholder="8:00 - 20:00 (Thứ 2 - Thứ 7)" required>
                </div>
            </div>
            <div class="checkin-modal-footer">
                <button type="button" class="checkin-button checkin-button-secondary"
                    onclick="closeBrandModal('information')">
                    <?php _e('Hủy', 'checkin-mkt192'); ?>
                </button>
                <button type="submit" class="checkin-button checkin-button-primary">
                    <?php _e('Lưu cài đặt', 'checkin-mkt192'); ?>
                </button>
            </div>
        </form>
    </div>
</div>
<?php
    }

    /**
     * Render Social Links Modal
     */
    private function render_social_links_modal() {
        $fanpage = get_option('checkin_fanpage', '');
        $tiktok  = get_option('checkin_tiktok', '');
        $youtube = get_option('checkin_youtube', '');
        ?>
<div id="modal-social-links" class="checkin-modal-backdrop">
    <div class="checkin-modal" style="max-width: 700px;">
        <div class="checkin-modal-header">
            <h2 class="checkin-modal-title">
                <span class="dashicons dashicons-share" style="color: #10b981;"></span>
                <?php _e('Cài đặt Social Links', 'checkin-mkt192'); ?>
            </h2>
            <button type="button" class="checkin-modal-close" onclick="closeBrandModal('social-links')">
                <span class="dashicons dashicons-no-alt"></span>
            </button>
        </div>
        <form id="form-social-links" class="checkin-brand-form">
            <div class="checkin-modal-body">
                <div class="checkin-form-group">
                    <label class="checkin-form-label">
                        <span class="dashicons dashicons-facebook"></span>
                        <?php _e('Facebook Fanpage', 'checkin-mkt192'); ?>
                    </label>
                    <input type="url" name="checkin_fanpage" value="<?php echo esc_attr($fanpage); ?>"
                        class="checkin-form-input" placeholder="https://facebook.com/yourpage">
                </div>

                <div class="checkin-form-group">
                    <label class="checkin-form-label">
                        <span class="dashicons dashicons-video-alt3"></span>
                        <?php _e('TikTok', 'checkin-mkt192'); ?>
                    </label>
                    <input type="url" name="checkin_tiktok" value="<?php echo esc_attr($tiktok); ?>"
                        class="checkin-form-input" placeholder="https://tiktok.com/@youraccount">
                </div>

                <div class="checkin-form-group">
                    <label class="checkin-form-label">
                        <span class="dashicons dashicons-youtube"></span>
                        <?php _e('YouTube', 'checkin-mkt192'); ?>
                    </label>
                    <input type="url" name="checkin_youtube" value="<?php echo esc_attr($youtube); ?>"
                        class="checkin-form-input" placeholder="https://youtube.com/yourchannel">
                </div>
            </div>
            <div class="checkin-modal-footer">
                <button type="button" class="checkin-button checkin-button-secondary"
                    onclick="closeBrandModal('social-links')">
                    <?php _e('Hủy', 'checkin-mkt192'); ?>
                </button>
                <button type="submit" class="checkin-button checkin-button-primary">
                    <?php _e('Lưu cài đặt', 'checkin-mkt192'); ?>
                </button>
            </div>
        </form>
    </div>
</div>
<?php
    }

    /**
     * Render tabs
     */
    private function render_tabs() {
        ?>
<div class="checkin-tabs">
    <ul class="checkin-tabs-nav">
        <?php foreach ($this->tabs as $key => $tab) : ?>
        <li>
            <a href="#tab-<?php echo esc_attr($key); ?>">
                <span class="dashicons <?php echo esc_attr($tab['icon']); ?>"></span>
                <?php echo esc_html($tab['title']); ?>
            </a>
        </li>
        <?php endforeach; ?>
    </ul>

    <div class="checkin-tabs-content">
        <?php
                $this->render_logo_colors_tab();
                $this->render_information_tab();
                $this->render_social_links_tab();
                ?>
    </div>
</div>
<?php
    }

    /**
     * Render Logo & Colors tab
     */
    private function render_logo_colors_tab() {
        $logo_url        = get_option('checkin_logo_url', '');
        $banner_url      = get_option('checkin_banner_url', '');
        $primary_color   = get_option('checkin_primary_color', '#2271b1');
        $secondary_color = get_option('checkin_secondary_color', '#50575e');
        ?>
<div id="tab-logo-colors" class="checkin-tab-pane">
    <div class="checkin-card">
        <div class="checkin-card-header">
            <h3 class="checkin-card-title">
                <?php _e('Logo & Banner', 'checkin-mkt192'); ?>
            </h3>
            <p class="checkin-card-description">
                <?php _e('Upload logo và banner cho thương hiệu của bạn', 'checkin-mkt192'); ?>
            </p>
        </div>
        <div class="checkin-card-body">
            <div class="checkin-grid checkin-grid-cols-2 checkin-gap-6">
                <!-- Logo -->
                <div class="checkin-form-group">
                    <label class="checkin-form-label"><?php _e('Logo', 'checkin-mkt192'); ?></label>
                    <div class="checkin-image-uploader">
                        <input type="hidden" name="checkin_logo_url" value="<?php echo esc_attr($logo_url); ?>">
                        <div class="checkin-image-preview <?php echo $logo_url ? 'has-image' : ''; ?>">
                            <?php if ($logo_url) : ?>
                            <img src="<?php echo esc_url($logo_url); ?>" alt="Logo">
                            <?php else : ?>
                            <div class="checkin-image-preview-placeholder">
                                <span class="dashicons dashicons-format-image" style="font-size: 48px;"></span>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="checkin-image-actions">
                            <button type="button" class="button checkin-upload-image">
                                <?php _e('Chọn Logo', 'checkin-mkt192'); ?>
                            </button>
                            <button type="button" class="button checkin-remove-image"
                                <?php echo !$logo_url ? 'style="display:none;"' : ''; ?>>
                                <?php _e('Xóa', 'checkin-mkt192'); ?>
                            </button>
                        </div>
                        <p class="checkin-form-description">
                            <?php _e('Khuyến nghị: 200x80px, định dạng PNG có nền trong suốt', 'checkin-mkt192'); ?>
                        </p>
                    </div>
                </div>

                <!-- Banner -->
                <div class="checkin-form-group">
                    <label class="checkin-form-label"><?php _e('Banner', 'checkin-mkt192'); ?></label>
                    <div class="checkin-image-uploader">
                        <input type="hidden" name="checkin_banner_url" value="<?php echo esc_attr($banner_url); ?>">
                        <div class="checkin-image-preview <?php echo $banner_url ? 'has-image' : ''; ?>">
                            <?php if ($banner_url) : ?>
                            <img src="<?php echo esc_url($banner_url); ?>" alt="Banner">
                            <?php else : ?>
                            <div class="checkin-image-preview-placeholder">
                                <span class="dashicons dashicons-format-image" style="font-size: 48px;"></span>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="checkin-image-actions">
                            <button type="button" class="button checkin-upload-image">
                                <?php _e('Chọn Banner', 'checkin-mkt192'); ?>
                            </button>
                            <button type="button" class="button checkin-remove-image"
                                <?php echo !$banner_url ? 'style="display:none;"' : ''; ?>>
                                <?php _e('Xóa', 'checkin-mkt192'); ?>
                            </button>
                        </div>
                        <p class="checkin-form-description">
                            <?php _e('Khuyến nghị: 1200x400px, dùng cho trang đăng ký thành viên', 'checkin-mkt192'); ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="checkin-card">
        <div class="checkin-card-header">
            <h3 class="checkin-card-title">
                <?php _e('Màu sắc thương hiệu', 'checkin-mkt192'); ?>
            </h3>
            <p class="checkin-card-description">
                <?php _e('Chọn màu chính và màu phụ cho thương hiệu', 'checkin-mkt192'); ?>
            </p>
        </div>
        <div class="checkin-card-body">
            <div class="checkin-grid checkin-grid-cols-2 checkin-gap-6">
                <!-- Primary Color -->
                <div class="checkin-form-group">
                    <label class="checkin-form-label"><?php _e('Màu chính', 'checkin-mkt192'); ?></label>
                    <div class="checkin-color-picker">
                        <input type="text" name="checkin_primary_color" value="<?php echo esc_attr($primary_color); ?>"
                            class="checkin-color-picker-input">
                    </div>
                    <p class="checkin-form-description">
                        <?php _e('Màu chính sẽ được sử dụng cho các nút, liên kết và các điểm nhấn chính', 'checkin-mkt192'); ?>
                    </p>
                </div>

                <!-- Secondary Color -->
                <div class="checkin-form-group">
                    <label class="checkin-form-label"><?php _e('Màu phụ', 'checkin-mkt192'); ?></label>
                    <div class="checkin-color-picker">
                        <input type="text" name="checkin_secondary_color"
                            value="<?php echo esc_attr($secondary_color); ?>" class="checkin-color-picker-input">
                    </div>
                    <p class="checkin-form-description">
                        <?php _e('Màu phụ sẽ được sử dụng cho các yếu tố thứ cấp', 'checkin-mkt192'); ?>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
    }

    /**
     * Render Information tab
     */
    private function render_information_tab() {
        $brand_name    = get_option('checkin_brand_name', '');
        $domain        = get_option('checkin_domain', '');
        $address       = get_option('checkin_address', '');
        $phone         = get_option('checkin_phone', '');
        $email         = get_option('checkin_email', '');
        $opening_hours = get_option('checkin_opening_hours', '');
        ?>
<div id="tab-information" class="checkin-tab-pane">
    <div class="checkin-card">
        <div class="checkin-card-header">
            <h3 class="checkin-card-title">
                <?php _e('Thông tin doanh nghiệp', 'checkin-mkt192'); ?>
            </h3>
            <p class="checkin-card-description">
                <?php _e('Điền thông tin cơ bản về doanh nghiệp của bạn', 'checkin-mkt192'); ?>
            </p>
        </div>
        <div class="checkin-card-body">
            <div class="checkin-grid checkin-grid-cols-2 checkin-gap-6">
                <!-- Brand Name -->
                <div class="checkin-form-group">
                    <label class="checkin-form-label required"><?php _e('Tên thương hiệu', 'checkin-mkt192'); ?></label>
                    <input type="text" name="checkin_brand_name" value="<?php echo esc_attr($brand_name); ?>"
                        class="checkin-form-input" required>
                </div>

                <!-- Domain -->
                <div class="checkin-form-group">
                    <label class="checkin-form-label"><?php _e('Domain', 'checkin-mkt192'); ?></label>
                    <input type="text" name="checkin_domain" value="<?php echo esc_attr($domain); ?>"
                        class="checkin-form-input" placeholder="shopabc.com">
                </div>

                <!-- Address -->
                <div class="checkin-form-group">
                    <label class="checkin-form-label"><?php _e('Địa chỉ', 'checkin-mkt192'); ?></label>
                    <input type="text" name="checkin_address" value="<?php echo esc_attr($address); ?>"
                        class="checkin-form-input">
                </div>

                <!-- Phone -->
                <div class="checkin-form-group">
                    <label class="checkin-form-label"><?php _e('Số điện thoại', 'checkin-mkt192'); ?></label>
                    <input type="tel" name="checkin_phone" value="<?php echo esc_attr($phone); ?>"
                        class="checkin-form-input" placeholder="0123 456 789">
                </div>

                <!-- Email -->
                <div class="checkin-form-group">
                    <label class="checkin-form-label"><?php _e('Email', 'checkin-mkt192'); ?></label>
                    <input type="email" name="checkin_email" value="<?php echo esc_attr($email); ?>"
                        class="checkin-form-input" placeholder="contact@example.com">
                </div>

                <!-- Opening Hours -->
                <div class="checkin-form-group">
                    <label class="checkin-form-label"><?php _e('Giờ mở cửa', 'checkin-mkt192'); ?></label>
                    <input type="text" name="checkin_opening_hours" value="<?php echo esc_attr($opening_hours); ?>"
                        class="checkin-form-input" placeholder="8:00 - 20:00">
                </div>
            </div>
        </div>
    </div>
</div>
<?php
    }

    /**
     * Render Social Links tab
     */
    private function render_social_links_tab() {
        $fanpage    = get_option('checkin_fanpage', '');
        $tiktok     = get_option('checkin_tiktok', '');
        $youtube    = get_option('checkin_youtube', '');
        $google_map = get_option('checkin_google_map', '');
        ?>
<div id="tab-social-links" class="checkin-tab-pane">
    <div class="checkin-card">
        <div class="checkin-card-header">
            <h3 class="checkin-card-title">
                <?php _e('Liên kết mạng xã hội', 'checkin-mkt192'); ?>
            </h3>
            <p class="checkin-card-description">
                <?php _e('Thêm liên kết đến các trang mạng xã hội của bạn', 'checkin-mkt192'); ?>
            </p>
        </div>
        <div class="checkin-card-body">
            <div class="checkin-grid checkin-grid-cols-2 checkin-gap-6">
                <!-- Facebook Fanpage -->
                <div class="checkin-form-group">
                    <label class="checkin-form-label">
                        <span class="dashicons dashicons-facebook"></span>
                        <?php _e('Facebook Fanpage', 'checkin-mkt192'); ?>
                    </label>
                    <input type="url" name="checkin_fanpage" value="<?php echo esc_attr($fanpage); ?>"
                        class="checkin-form-input" placeholder="https://facebook.com/yourpage">
                </div>

                <!-- TikTok -->
                <div class="checkin-form-group">
                    <label class="checkin-form-label">
                        <span class="dashicons dashicons-video-alt3"></span>
                        <?php _e('TikTok', 'checkin-mkt192'); ?>
                    </label>
                    <input type="url" name="checkin_tiktok" value="<?php echo esc_attr($tiktok); ?>"
                        class="checkin-form-input" placeholder="https://tiktok.com/@youraccount">
                </div>

                <!-- YouTube -->
                <div class="checkin-form-group">
                    <label class="checkin-form-label">
                        <span class="dashicons dashicons-youtube"></span>
                        <?php _e('YouTube', 'checkin-mkt192'); ?>
                    </label>
                    <input type="url" name="checkin_youtube" value="<?php echo esc_attr($youtube); ?>"
                        class="checkin-form-input" placeholder="https://youtube.com/yourchannel">
                </div>
            </div>

            <!-- Google Map -->
            <div class="checkin-form-group">
                <label class="checkin-form-label">
                    <span class="dashicons dashicons-location"></span>
                    <?php _e('Google Map Embed', 'checkin-mkt192'); ?>
                </label>
                <textarea name="checkin_google_map" class="checkin-form-textarea" rows="4"
                    placeholder="<iframe src='https://www.google.com/maps/embed?pb=...'></iframe>"><?php echo esc_textarea($google_map); ?></textarea>
                <p class="checkin-form-description">
                    <?php _e('Dán mã nhúng iframe từ Google Maps', 'checkin-mkt192'); ?>
                </p>
            </div>
        </div>
    </div>
</div>
<?php
    }

    /**
     * Save settings
     */
    private function save_settings() {
        // Save all posted settings
        if (isset($_POST['checkin_logo_url'])) {
            update_option('checkin_logo_url', esc_url_raw($_POST['checkin_logo_url']));
        }
        if (isset($_POST['checkin_banner_url'])) {
            update_option('checkin_banner_url', esc_url_raw($_POST['checkin_banner_url']));
        }
        if (isset($_POST['checkin_primary_color'])) {
            update_option('checkin_primary_color', sanitize_hex_color($_POST['checkin_primary_color']));
        }
        if (isset($_POST['checkin_secondary_color'])) {
            update_option('checkin_secondary_color', sanitize_hex_color($_POST['checkin_secondary_color']));
        }
        if (isset($_POST['checkin_brand_name'])) {
            update_option('checkin_brand_name', sanitize_text_field($_POST['checkin_brand_name']));
        }
        if (isset($_POST['checkin_domain'])) {
            update_option('checkin_domain', esc_url_raw($_POST['checkin_domain']));
        }
        if (isset($_POST['checkin_address'])) {
            update_option('checkin_address', sanitize_text_field($_POST['checkin_address']));
        }
        if (isset($_POST['checkin_phone'])) {
            update_option('checkin_phone', sanitize_text_field($_POST['checkin_phone']));
        }
        if (isset($_POST['checkin_email'])) {
            update_option('checkin_email', sanitize_email($_POST['checkin_email']));
        }
        if (isset($_POST['checkin_opening_hours'])) {
            update_option('checkin_opening_hours', sanitize_text_field($_POST['checkin_opening_hours']));
        }
        if (isset($_POST['checkin_fanpage'])) {
            update_option('checkin_fanpage', esc_url_raw($_POST['checkin_fanpage']));
        }
        if (isset($_POST['checkin_tiktok'])) {
            update_option('checkin_tiktok', esc_url_raw($_POST['checkin_tiktok']));
        }
        if (isset($_POST['checkin_youtube'])) {
            update_option('checkin_youtube', esc_url_raw($_POST['checkin_youtube']));
        }
        if (isset($_POST['checkin_google_map'])) {
            // Save Google Maps embed code (iframe or URL)
            // For admin users, we trust the input
            $google_map_input = stripslashes($_POST['checkin_google_map']);

            // If it's an iframe, extract the src URL only for security
            if (strpos($google_map_input, '<iframe') !== false) {
                // Extract src from iframe
                preg_match('/src=["\']([^"\']+)["\']/', $google_map_input, $matches);
                if (!empty($matches[1])) {
                    // Save only the embed URL
                    $google_map_value = esc_url_raw($matches[1]);
                } else {
                    $google_map_value = '';
                }
            } else {
                // If it's just a URL, save it
                $google_map_value = esc_url_raw($google_map_input);
            }

            update_option('checkin_google_map', $google_map_value, false);
        }

        // Show success message
        add_settings_error(
            'checkin_messages',
            'checkin_message',
            __('Cài đặt đã được lưu thành công!', 'checkin-mkt192'),
            'updated'
        );
    }

    /**
     * AJAX handler for saving branch (add or update)
     */
    public function ajax_save_branch() {
        try {
            check_ajax_referer('checkin-admin-nonce', 'nonce');
        } catch (Exception $e) {
            wp_send_json_error(['message' => __('Xác thực không hợp lệ!', 'checkin-mkt192')]);
            return;
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Bạn không có quyền thực hiện hành động này!', 'checkin-mkt192')]);
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'checkin_mkt192_locations';

        // Get form data
        $branch_id       = isset($_POST['branch_id']) && !empty($_POST['branch_id']) ? intval($_POST['branch_id']) : 0;
        $location_name   = isset($_POST['location_name']) ? sanitize_text_field($_POST['location_name']) : '';
        $address         = isset($_POST['address']) ? sanitize_textarea_field($_POST['address']) : '';
        $google_map_link = isset($_POST['google_map_link']) ? esc_url_raw($_POST['google_map_link']) : '';
        $latitude        = isset($_POST['latitude']) ? floatval($_POST['latitude']) : 0;
        $longitude       = isset($_POST['longitude']) ? floatval($_POST['longitude']) : 0;
        $radius          = isset($_POST['radius']) ? intval($_POST['radius']) : 100;
        $is_main_branch  = isset($_POST['is_main_branch']) && $_POST['is_main_branch'] == '1' ? 1 : 0;

        // Get Google Map embed (only for main branch)
        $google_map_embed = '';
        if ($is_main_branch == 1 && isset($_POST['google_map_embed'])) {
            $google_map_input = stripslashes($_POST['google_map_embed']);
            // Extract src from iframe if provided
            if (strpos($google_map_input, '<iframe') !== false) {
                preg_match('/src=["\']([^"\']+)["\']/', $google_map_input, $matches);
                if (!empty($matches[1])) {
                    $google_map_embed = esc_url_raw($matches[1]);
                }
            } else {
                $google_map_embed = esc_url_raw($google_map_input);
            }
        }

        // Validate required fields
        if (empty($location_name) || empty($address) || $latitude == 0 || $longitude == 0) {
            wp_send_json_error(['message' => __('Vui lòng điền đầy đủ các trường bắt buộc!', 'checkin-mkt192')]);
        }

        // If setting as main branch, unset other main branches and update google map
        if ($is_main_branch == 1) {
            $wpdb->update($table_name, ['is_main_branch' => 0], ['is_main_branch' => 1]);
            // Save google map embed to option for main branch
            if (!empty($google_map_embed)) {
                update_option('checkin_google_map', $google_map_embed, false);
            }
        }

        $data = [
            'location_name'   => $location_name,
            'address'         => $address,
            'google_map_link' => $google_map_link,
            'latitude'        => $latitude,
            'longitude'       => $longitude,
            'radius'          => $radius,
            'is_main_branch'  => $is_main_branch,
        ];

        if ($branch_id > 0) {
            // Get old branch name before update
            $old_branch = $wpdb->get_row($wpdb->prepare(
                "SELECT location_name FROM $table_name WHERE id = %d",
                $branch_id
            ));

            $old_location_name = $old_branch ? $old_branch->location_name : '';

            // Update existing branch
            $result = $wpdb->update($table_name, $data, ['id' => $branch_id]);

            // Check for actual error (false), not just 0 rows affected
            if ($result === false) {
                wp_send_json_error(['message' => __('Có lỗi khi cập nhật chi nhánh!', 'checkin-mkt192')]);
            }

            // If branch name changed, update all related tables
            if (!empty($old_location_name) && $old_location_name !== $location_name) {
                $this->sync_branch_name_across_tables($old_location_name, $location_name);
            }

            // Success even if 0 rows affected (data unchanged)
            wp_send_json_success([
                'message'   => __('Chi nhánh đã được cập nhật!', 'checkin-mkt192'),
                'branch_id' => $branch_id
            ]);
        } else {
            // Insert new branch
            $result = $wpdb->insert($table_name, $data);

            if ($result === false) {
                wp_send_json_error(['message' => __('Có lỗi khi thêm chi nhánh!', 'checkin-mkt192')]);
            }

            wp_send_json_success([
                'message'   => __('Chi nhánh đã được thêm!', 'checkin-mkt192'),
                'branch_id' => $wpdb->insert_id
            ]);
        }
    }

    /**
     * Sync branch name across all tables with branch column
     *
     * @param string $old_name Old branch name
     * @param string $new_name New branch name
     */
    private function sync_branch_name_across_tables($old_name, $new_name) {
        global $wpdb;

        error_log("Checkin MKT192: Starting branch name sync from '$old_name' to '$new_name'");

        // List of all tables with branch column
        $tables_with_branch = [
            $wpdb->prefix . 'checkin_mkt192_staff',
            $wpdb->prefix . 'checkin_mkt192_service_data',
            $wpdb->prefix . 'checkin_mkt192_products',
            $wpdb->prefix . 'checkin_mkt192_shiftsettings',
            $wpdb->prefix . 'bookingmkt192_booking_data',
            $wpdb->prefix . 'checkin_mkt192_invoices_data',
            $wpdb->prefix . 'checkin_mkt192_invoices_data_detail',
            $wpdb->prefix . 'bookingmkt192_customer_data',
            $wpdb->prefix . 'checkin_mkt192_manager_schedules',
        ];

        $total_updated = 0;

        foreach ($tables_with_branch as $table) {
            // Check if table exists using prepared query
            $table_exists = $wpdb->get_var($wpdb->prepare(
                'SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s',
                $table
            ));

            if (!$table_exists) {
                error_log("Checkin MKT192: Table $table does not exist, skipping");
                continue;
            }

            // Check if branch column exists
            $column_exists = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_SCHEMA = DATABASE()
                AND TABLE_NAME = %s
                AND COLUMN_NAME = 'branch'",
                $table
            ));

            if (!$column_exists) {
                error_log("Checkin MKT192: Column 'branch' does not exist in $table, skipping");
                continue;
            }

            // Count records before update
            $count_before = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM `$table` WHERE branch = %s",
                $old_name
            ));

            error_log("Checkin MKT192: Found $count_before records in $table with branch = '$old_name'");

            // Update all records with old branch name to new branch name
            $updated = $wpdb->update(
                $table,
                ['branch' => $new_name],
                ['branch' => $old_name],
                ['%s'],
                ['%s']
            );

            if ($updated === false) {
                error_log("Checkin MKT192: ERROR updating $table - " . $wpdb->last_error);
            } else {
                $total_updated += $updated;
                error_log("Checkin MKT192: Successfully updated $updated records in $table from '$old_name' to '$new_name'");
            }
        }

        error_log("Checkin MKT192: Branch name sync completed. Total records updated: $total_updated");
    }

    /**
     * AJAX handler for deleting branch
     */
    public function ajax_delete_branch() {
        try {
            check_ajax_referer('checkin-admin-nonce', 'nonce');
        } catch (Exception $e) {
            wp_send_json_error(['message' => __('Xác thực không hợp lệ!', 'checkin-mkt192')]);
            return;
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Bạn không có quyền thực hiện hành động này!', 'checkin-mkt192')]);
        }

        $branch_id = isset($_POST['branch_id']) ? intval($_POST['branch_id']) : 0;

        if ($branch_id <= 0) {
            wp_send_json_error(['message' => __('ID chi nhánh không hợp lệ!', 'checkin-mkt192')]);
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'checkin_mkt192_locations';

        $result = $wpdb->delete($table_name, ['id' => $branch_id]);

        if ($result === false) {
            wp_send_json_error(['message' => __('Có lỗi khi xóa chi nhánh!', 'checkin-mkt192')]);
        }

        wp_send_json_success(['message' => __('Chi nhánh đã được xóa!', 'checkin-mkt192')]);
    }

    /**
     * AJAX handler for getting single branch data
     */
    public function ajax_get_branch() {
        try {
            check_ajax_referer('checkin-admin-nonce', 'nonce');
        } catch (Exception $e) {
            wp_send_json_error(['message' => __('Xác thực không hợp lệ!', 'checkin-mkt192')]);
            return;
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Bạn không có quyền thực hiện hành động này!', 'checkin-mkt192')]);
        }

        $branch_id = isset($_POST['branch_id']) ? intval($_POST['branch_id']) : 0;

        if ($branch_id <= 0) {
            wp_send_json_error(['message' => __('ID chi nhánh không hợp lệ!', 'checkin-mkt192')]);
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'checkin_mkt192_locations';

        $branch = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $branch_id), ARRAY_A);

        if (!$branch) {
            wp_send_json_error(['message' => __('Không tìm thấy chi nhánh!', 'checkin-mkt192')]);
        }

        wp_send_json_success(['branch' => $branch]);
    }

    /**
     * AJAX handler for getting Google Map embed
     */
    public function ajax_get_google_map() {
        try {
            check_ajax_referer('checkin-admin-nonce', 'nonce');
        } catch (Exception $e) {
            wp_send_json_error(['message' => __('Xác thực không hợp lệ!', 'checkin-mkt192')]);
            return;
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Bạn không có quyền thực hiện hành động này!', 'checkin-mkt192')]);
        }

        $google_map = get_option('checkin_google_map', '');
        wp_send_json_success(['google_map' => $google_map]);
    }

    /**
     * AJAX handler for getting branches list HTML (for realtime update)
     */
    public function ajax_get_branches_list() {
        try {
            check_ajax_referer('checkin-admin-nonce', 'nonce');
        } catch (Exception $e) {
            wp_send_json_error(['message' => __('Xác thực không hợp lệ!', 'checkin-mkt192')]);
            return;
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Bạn không có quyền thực hiện hành động này!', 'checkin-mkt192')]);
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'checkin_mkt192_locations';
        $branches   = $wpdb->get_results("SELECT * FROM $table_name ORDER BY is_main_branch DESC, id ASC", ARRAY_A);

        ob_start();
        if (!empty($branches)) {
            ?>
<div class="checkin-branches-list">
    <?php foreach ($branches as $branch) : ?>
    <div class="checkin-branch-item" data-branch-id="<?php echo esc_attr($branch['id']); ?>">
        <div class="checkin-branch-header">
            <div class="checkin-branch-name">
                <strong><?php echo esc_html($branch['location_name']); ?></strong>
                <?php if ($branch['is_main_branch'] == 1) : ?>
                <span class="checkin-badge checkin-badge-success">
                    <span class="dashicons dashicons-star-filled"></span>
                    <?php _e('Chi nhánh chính', 'checkin-mkt192'); ?>
                </span>
                <?php endif; ?>
            </div>
            <div style="display: flex; gap: 8px;">
                <button type="button"
                    class="checkin-button checkin-button-sm checkin-button-secondary checkin-btn-edit-branch"
                    data-branch-id="<?php echo esc_attr($branch['id']); ?>">
                    <span class="dashicons dashicons-edit"></span>
                    <?php _e('Sửa', 'checkin-mkt192'); ?>
                </button>
                <button type="button"
                    class="checkin-button checkin-button-sm checkin-button-danger checkin-btn-delete-branch"
                    data-branch-id="<?php echo esc_attr($branch['id']); ?>">
                    <span class="dashicons dashicons-trash"></span>
                    <?php _e('Xóa', 'checkin-mkt192'); ?>
                </button>
            </div>
        </div>
        <div class="checkin-branch-details">
            <div class="checkin-branch-info">
                <i class="dashicons dashicons-location"></i>
                <?php echo esc_html($branch['address'] ?: __('Chưa có địa chỉ', 'checkin-mkt192')); ?>
            </div>
            <?php if ($branch['google_map_link']) : ?>
            <div class="checkin-branch-info">
                <i class="dashicons dashicons-admin-site"></i>
                <a href="<?php echo esc_url($branch['google_map_link']); ?>" target="_blank">
                    <?php _e('Xem trên Google Maps', 'checkin-mkt192'); ?>
                </a>
            </div>
            <?php endif; ?>
            <div class="checkin-branch-info">
                <i class="dashicons dashicons-location-alt"></i>
                <?php echo esc_html($branch['latitude']); ?>,
                <?php echo esc_html($branch['longitude']); ?>
                (<?php echo esc_html($branch['radius']); ?>m)
            </div>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<?php
        } else {
            ?>
<div class="checkin-empty-state">
    <span class="dashicons dashicons-location" style="font-size: 48px; opacity: 0.3;"></span>
    <p><?php _e('Chưa có chi nhánh nào. Hãy tạo chi nhánh đầu tiên!', 'checkin-mkt192'); ?>
    </p>
</div>
<?php
        }
        $html = ob_get_clean();

        wp_send_json_success(['html' => $html]);
    }

    /**
     * Render Branch Management Modal (Add/Edit)
     */
    private function render_branch_modal() {
        ?>
<div id="modal-branch-form" class="checkin-modal-backdrop">
    <div class="checkin-modal" style="max-width: 800px;">
        <div class="checkin-modal-header">
            <h2 class="checkin-modal-title">
                <span class="dashicons dashicons-location"></span>
                <span id="branch-modal-title"><?php _e('Thêm Chi nhánh', 'checkin-mkt192'); ?></span>
            </h2>
            <button type="button" class="checkin-modal-close" onclick="closeBranchModal()">
                <span class="dashicons dashicons-no-alt"></span>
            </button>
        </div>
        <form id="form-branch" class="checkin-brand-form">
            <input type="hidden" id="branch-id" name="branch_id" value="">
            <div class="checkin-modal-body">
                <div class="checkin-form-group">
                    <label class="checkin-form-label required">
                        <?php _e('Tên chi nhánh', 'checkin-mkt192'); ?>
                    </label>
                    <input type="text" id="branch-name" name="location_name" class="checkin-form-input"
                        placeholder="Ví dụ: Chi nhánh Quận 1" required>
                </div>

                <div class="checkin-form-group">
                    <label class="checkin-form-label required">
                        <?php _e('Địa chỉ', 'checkin-mkt192'); ?>
                    </label>
                    <textarea id="branch-address" name="address" class="checkin-form-input" rows="3"
                        placeholder="Địa chỉ đầy đủ của chi nhánh" required></textarea>
                </div>

                <div class="checkin-form-group">
                    <label class="checkin-form-label">
                        <?php _e('Link Google Maps', 'checkin-mkt192'); ?>
                    </label>
                    <input type="url" id="branch-map-link" name="google_map_link" class="checkin-form-input"
                        placeholder="https://maps.google.com/...">
                    <p class="checkin-form-description">
                        <?php _e('Link để khách hàng xem vị trí trên Google Maps', 'checkin-mkt192'); ?>
                    </p>
                </div>

                <div class="checkin-divider"></div>

                <h4 style="margin-bottom: 16px; color: var(--checkin-text-primary);">
                    <i class="dashicons dashicons-location-alt"></i>
                    <?php _e('Tọa độ & Bán kính', 'checkin-mkt192'); ?>
                </h4>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 16px;">
                    <div class="checkin-form-group">
                        <label class="checkin-form-label required">
                            <?php _e('Vĩ độ (Latitude)', 'checkin-mkt192'); ?>
                        </label>
                        <input type="number" id="branch-latitude" name="latitude" class="checkin-form-input"
                            step="0.0000001" placeholder="10.762622" required>
                    </div>

                    <div class="checkin-form-group">
                        <label class="checkin-form-label required">
                            <?php _e('Kinh độ (Longitude)', 'checkin-mkt192'); ?>
                        </label>
                        <input type="number" id="branch-longitude" name="longitude" class="checkin-form-input"
                            step="0.0000001" placeholder="106.660172" required>
                    </div>
                </div>

                <div class="checkin-form-group">
                    <label class="checkin-form-label required">
                        <?php _e('Bán kính check-in (meters)', 'checkin-mkt192'); ?>
                    </label>
                    <input type="number" id="branch-radius" name="radius" class="checkin-form-input" min="10" step="10"
                        placeholder="100" required>
                    <p class="checkin-form-description">
                        <?php _e('Khoảng cách tối đa cho phép check-in (tính bằng mét)', 'checkin-mkt192'); ?>
                    </p>
                </div>

                <div class="checkin-divider"></div>

                <div class="checkin-form-group">
                    <label style="display: flex; align-items: center; gap: 8px; cursor: pointer;">
                        <input type="checkbox" id="branch-is-main" name="is_main_branch" value="1"
                            style="margin: 0; cursor: pointer;">
                        <span style="font-weight: 500; color: var(--checkin-text-primary);">
                            <span class="dashicons dashicons-star-filled" style="color: #fbbf24;"></span>
                            <?php _e('Đặt làm chi nhánh chính', 'checkin-mkt192'); ?>
                        </span>
                    </label>
                    <p class="checkin-form-description" style="margin-left: 32px;">
                        <?php _e('Chi nhánh chính sẽ hiển thị đầu tiên trong danh sách', 'checkin-mkt192'); ?>
                    </p>
                </div>

                <!-- Google Map Embed - chỉ hiển thị khi là chi nhánh chính -->
                <div class="checkin-form-group" id="branch-google-map-group" style="display: none;">
                    <label class="checkin-form-label">
                        <span class="dashicons dashicons-admin-site"></span>
                        <?php _e('Google Map Embed (Chi nhánh chính)', 'checkin-mkt192'); ?>
                    </label>
                    <textarea id="branch-google-map" name="google_map_embed" class="checkin-form-input" rows="4"
                        placeholder="<iframe src='https://www.google.com/maps/embed?pb=...'></iframe>"></textarea>
                    <p class="checkin-form-description">
                        <?php _e('Dán mã nhúng iframe từ Google Maps để hiển thị trên trang chủ', 'checkin-mkt192'); ?>
                    </p>
                </div>
            </div>
            <div class="checkin-modal-footer">
                <button type="button" class="checkin-button checkin-button-secondary" onclick="closeBranchModal()">
                    <?php _e('Hủy', 'checkin-mkt192'); ?>
                </button>
                <button type="submit" class="checkin-button checkin-button-primary">
                    <span class="dashicons dashicons-saved"></span>
                    <?php _e('Lưu chi nhánh', 'checkin-mkt192'); ?>
                </button>
            </div>
        </form>
    </div>
</div>
<?php
    }
}
?>
