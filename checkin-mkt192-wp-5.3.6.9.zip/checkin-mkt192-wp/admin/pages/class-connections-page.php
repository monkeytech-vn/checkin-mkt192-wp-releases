<?php
/**
 * Connections Page
 *
 * @package    Checkin_MKT192_WP
 * @subpackage Admin/Pages
 * @since      5.1.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class Checkin_MKT192_WP_Connections_Page
 */
class Checkin_MKT192_WP_Connections_Page {

    private $page_slug = 'checkin-mkt192-connections';
    private $tabs      = [];
    private $bot_manager;

    public function __construct() {
        // Load bot manager
        require_once CHECKIN_PLUGIN_DIR . 'includes/lark/class-checkin-mkt192-message-bot-manager.php';
        $this->bot_manager = Checkin_MKT192_Message_Bot_Manager::get_instance();

        $this->setup_tabs();
        $this->register_settings();
        $this->register_ajax_handlers();

        // Enqueue scripts
        add_action('admin_enqueue_scripts', [$this, 'enqueue_scripts']);
    }

    public function enqueue_scripts($hook) {
        // Check if we're on the connections page
        if (strpos($hook, 'checkin-mkt192-connections') === false) {
            return;
        }

        // Script is already enqueued by class-admin-assets.php
        // Just localize it with nonce for bot operations
        wp_localize_script('checkin-admin-connections', 'checkinLarkBot', [
            'nonce' => wp_create_nonce('checkin_lark_bot'),
        ]);

        // Localize for connections operations
        wp_localize_script('checkin-admin-connections', 'checkinAdmin', [
            'nonce'     => wp_create_nonce('checkin_connections'),
            'restNonce' => wp_create_nonce('wp_rest'),
            'restUrl'   => rest_url('vg/v1/'),
        ]);
    }

    private function register_ajax_handlers() {
        add_action('wp_ajax_checkin_save_connection', [$this, 'ajax_save_connection']);
        add_action('wp_ajax_checkin_clear_connection_data', [$this, 'ajax_clear_connection_data']);
        add_action('wp_ajax_checkin_save_lark_bot', [$this, 'ajax_save_lark_bot']);
        add_action('wp_ajax_checkin_delete_lark_bot', [$this, 'ajax_delete_lark_bot']);
        add_action('wp_ajax_checkin_get_lark_bot', [$this, 'ajax_get_lark_bot']);
        add_action('wp_ajax_checkin_get_lark_bots', [$this, 'ajax_get_lark_bots']);
        add_action('wp_ajax_checkin_get_zalo_templates', [$this, 'ajax_get_zalo_templates']);
    }

    public function ajax_save_connection() {
        check_ajax_referer('checkin_connections', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Bạn không có quyền thực hiện hành động này!', 'checkin-mkt192')]);
        }

        $result = $this->save_connection_settings();
        if (is_wp_error($result)) {
            wp_send_json_error(['message' => $result->get_error_message()]);
        } else {
            wp_send_json_success(['message' => __('Cài đặt đã được lưu thành công!', 'checkin-mkt192')]);
        }
    }

    public function ajax_save_lark_bot() {
        // Debug logging
        error_log('=== AJAX Save Lark Bot Called ===');
        error_log('POST data: ' . print_r($_POST, true));
        error_log('User can manage_options: ' . (current_user_can('manage_options') ? 'YES' : 'NO'));
        error_log('Current user ID: ' . get_current_user_id());

        check_ajax_referer('checkin_lark_bot', 'nonce');

        if (!current_user_can('manage_options')) {
            error_log('Permission denied for user');
            wp_send_json_error(['message' => __('Bạn không có quyền thực hiện hành động này!', 'checkin-mkt192')]);
        }

        $bot_id  = isset($_POST['bot_id']) ? absint($_POST['bot_id']) : 0;
        $is_edit = $bot_id > 0;

        // Parse notification_types from JSON string
        $notification_types = isset($_POST['notification_types']) ? $_POST['notification_types'] : '[]';
        if (is_string($notification_types)) {
            // Remove WordPress magic quotes slashes before parsing
            $notification_types = stripslashes($notification_types);
            $notification_types = json_decode($notification_types, true);
        }

        error_log('Parsed notification_types: ' . print_r($notification_types, true));
        error_log('Is array: ' . (is_array($notification_types) ? 'YES' : 'NO'));
        error_log('Count: ' . (is_array($notification_types) ? count($notification_types) : 0));

        $data = [
            'bot_name'           => sanitize_text_field($_POST['bot_name']),
            'bot_type'           => sanitize_text_field($_POST['bot_type']),
            'notification_types' => $notification_types,
            'is_active'          => isset($_POST['is_active']) ? 1 : 0
        ];

        error_log('Data to create bot: ' . print_r($data, true));

        if ($data['bot_type'] === 'interactive') {
            $data['chat_id']    = sanitize_text_field($_POST['chat_id'] ?? '');
            $data['app_id']     = sanitize_text_field($_POST['app_id'] ?? '');
            $data['app_secret'] = sanitize_text_field($_POST['app_secret'] ?? '');
        } else {
            $data['webhook_url'] = esc_url_raw($_POST['webhook_url'] ?? '');
        }

        if ($is_edit) {
            $result  = $this->bot_manager->update_bot($bot_id, $data);
            $message = __('Bot đã được cập nhật thành công!', 'checkin-mkt192');
        } else {
            $result  = $this->bot_manager->create_bot($data);
            $message = __('Bot đã được tạo thành công!', 'checkin-mkt192');
        }

        if (is_wp_error($result)) {
            wp_send_json_error(['message' => $result->get_error_message()]);
        }

        wp_send_json_success(['message' => $message]);
    }

    public function ajax_delete_lark_bot() {
        check_ajax_referer('checkin_lark_bot', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Bạn không có quyền thực hiện hành động này!', 'checkin-mkt192')]);
        }

        $bot_id = isset($_POST['bot_id']) ? absint($_POST['bot_id']) : 0;

        if (!$bot_id) {
            wp_send_json_error(['message' => __('ID bot không hợp lệ!', 'checkin-mkt192')]);
        }

        $result = $this->bot_manager->delete_bot($bot_id);

        if (is_wp_error($result)) {
            wp_send_json_error(['message' => $result->get_error_message()]);
        }

        wp_send_json_success(['message' => __('Bot đã được xóa thành công!', 'checkin-mkt192')]);
    }

    public function ajax_get_lark_bot() {
        check_ajax_referer('checkin_lark_bot', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Bạn không có quyền thực hiện hành động này!', 'checkin-mkt192')]);
        }

        $bot_id = isset($_POST['bot_id']) ? absint($_POST['bot_id']) : 0;

        if (!$bot_id) {
            wp_send_json_error(['message' => __('ID bot không hợp lệ!', 'checkin-mkt192')]);
        }

        $bot = $this->bot_manager->get_bot($bot_id);

        if (!$bot) {
            wp_send_json_error(['message' => __('Không tìm thấy bot!', 'checkin-mkt192')]);
        }

        // Parse notification_types if it's JSON string
        if (isset($bot->notification_types) && is_string($bot->notification_types)) {
            $bot->notification_types = json_decode($bot->notification_types, true);
        }

        wp_send_json_success(['bot' => $bot]);
    }

    /**
     * Get Lark bots list as HTML for AJAX reload
     */
    public function ajax_get_lark_bots() {
        check_ajax_referer('checkin_lark_bot', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Bạn không có quyền thực hiện hành động này!', 'checkin-mkt192')]);
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'checkin_mkt192_message_bot_settings';

        // Check if table exists before querying
        $bots = [];
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") === $table_name) {
            $bots = $wpdb->get_results("SELECT * FROM $table_name ORDER BY id DESC");
        }

        // Generate HTML for bot list (same structure as render_lark_modal)
        ob_start();
        if (empty($bots)) {
            ?>
<div class="checkin-empty-state" style="padding: 30px 20px;">
    <div class="checkin-empty-state-icon">
        <span class="dashicons dashicons-admin-site-alt3" style="font-size: 48px;"></span>
    </div>
    <div class="checkin-empty-state-title">
        <?php _e('Chưa có Lark Bot nào', 'checkin-mkt192'); ?>
    </div>
    <div class="checkin-empty-state-description">
        <?php _e('Thêm bot đầu tiên để bắt đầu nhận thông báo', 'checkin-mkt192'); ?>
    </div>
</div>
<?php
        } else {
            ?>
<div class="checkin-bot-list">
    <?php foreach ($bots as $bot) : ?>
    <div class="checkin-bot-item" data-bot-id="<?php echo esc_attr($bot->id); ?>">
        <div class="checkin-bot-info">
            <h4 class="checkin-bot-name">
                <?php echo esc_html($bot->bot_name); ?>
            </h4>
            <p class="checkin-bot-type">
                <?php
                $types = is_string($bot->notification_types) ? json_decode($bot->notification_types, true) : [];
                if (!empty($types) && is_array($types)) {
                    echo esc_html(implode(', ', array_slice($types, 0, 3)));
                    if (count($types) > 3) echo '...';
                } else {
                    echo esc_html($bot->bot_type);
                }
                ?>
            </p>
        </div>
        <div class="checkin-bot-status">
            <?php if ($bot->is_active) : ?>
            <span class="checkin-badge checkin-badge-success">Active</span>
            <?php else : ?>
            <span class="checkin-badge checkin-badge-gray">Inactive</span>
            <?php endif; ?>
        </div>
        <div class="checkin-bot-actions">
            <button type="button" class="checkin-button checkin-button-sm checkin-button-ghost"
                onclick="openEditBotModal(<?php echo esc_js($bot->id); ?>)"
                title="<?php _e('Chỉnh sửa', 'checkin-mkt192'); ?>">
                <span class="dashicons dashicons-edit"></span>
            </button>
            <button type="button"
                class="checkin-button checkin-button-sm checkin-button-ghost checkin-button-danger"
                onclick="deleteLarkBot(<?php echo esc_js($bot->id); ?>)"
                title="<?php _e('Xóa', 'checkin-mkt192'); ?>">
                <span class="dashicons dashicons-trash"></span>
            </button>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<?php
        }
        $html = ob_get_clean();

        wp_send_json_success(['html' => $html]);
    }

    /**
     * AJAX handler to fetch Zalo ZBS templates
     */
    public function ajax_get_zalo_templates() {
        check_ajax_referer('checkin_connections', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Bạn không có quyền thực hiện hành động này!', 'checkin-mkt192')]);
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'checkin_mkt192_zalo_config';
        $config     = $wpdb->get_row("SELECT access_token FROM $table_name ORDER BY updated_at DESC LIMIT 1");

        if (!$config || empty($config->access_token)) {
            wp_send_json_error(['message' => 'Chưa kết nối Zalo OA hoặc access token không hợp lệ']);
        }

        $url = add_query_arg([
            'offset' => 0,
            'limit'  => 100,
            'status' => 1,
        ], 'https://business.openapi.zalo.me/template/all');

        $response = wp_remote_get($url, [
            'headers' => [
                'Content-Type' => 'application/json',
                'access_token' => $config->access_token,
            ],
            'timeout' => 15,
        ]);

        if (is_wp_error($response)) {
            wp_send_json_error(['message' => 'Lỗi kết nối Zalo API: ' . $response->get_error_message()]);
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);

        if (isset($body['error']) && $body['error'] !== 0) {
            wp_send_json_error(['message' => $body['message'] ?? 'Lỗi từ Zalo API', 'error' => $body['error']]);
        }

        wp_send_json_success($body);
    }

    private function setup_tabs() {
        $this->tabs = [
            'zalo' => [
                'title' => __('Zalo', 'checkin-mkt192'),
                'icon'  => 'dashicons-admin-comments',
            ],
            'lark' => [
                'title' => __('Lark', 'checkin-mkt192'),
                'icon'  => 'dashicons-admin-site-alt3',
            ],
            'google' => [
                'title' => __('Google', 'checkin-mkt192'),
                'icon'  => 'dashicons-google',
            ],
            'facebook' => [
                'title' => __('Facebook', 'checkin-mkt192'),
                'icon'  => 'dashicons-facebook',
            ],
        ];
    }

    private function register_settings() {
        // Zalo settings
        register_setting('checkin_connections_zalo', 'checkin_use_zalo_oa');
        register_setting('checkin_connections_zalo', 'checkin_use_zalo_user');
        register_setting('checkin_connections_zalo', 'checkin_zalo_user_domain');
        register_setting('checkin_connections_zalo', 'checkin_zalo_user_send_customer');
        register_setting('checkin_connections_zalo', 'checkin_zalo_user_send_group');

        // Zalo ZBS Template settings
        register_setting('checkin_connections_zalo', 'checkin_zbs_template_booking');
        register_setting('checkin_connections_zalo', 'checkin_zbs_template_cancel_booking');
        register_setting('checkin_connections_zalo', 'checkin_zbs_template_booking_reminder');
        register_setting('checkin_connections_zalo', 'checkin_zbs_template_invoice');

        // Lark settings
        register_setting('checkin_connections_lark', 'checkin_use_lark');

        // Google settings
        register_setting('checkin_connections_google', 'checkin_use_google_login');
        register_setting('checkin_connections_google', 'checkin_google_client_id');
        register_setting('checkin_connections_google', 'checkin_google_account_email');
        register_setting('checkin_connections_google', 'checkin_google_account_name');
        register_setting('checkin_connections_google', 'checkin_google_account_verified');
        register_setting('checkin_connections_google', 'checkin_google_account_picture');

        // Facebook settings
        register_setting('checkin_connections_facebook', 'checkin_use_facebook_login');
        register_setting('checkin_connections_facebook', 'checkin_facebook_app_id');
        register_setting('checkin_connections_facebook', 'checkin_facebook_app_secret');
    }

    public function render() {
        // Handle AJAX save
        if (isset($_POST['action']) && $_POST['action'] === 'checkin_save_connection') {
            check_ajax_referer('checkin_connections', 'nonce');
            $result = $this->save_connection_settings();
            if (is_wp_error($result)) {
                wp_send_json_error(['message' => $result->get_error_message()]);
            } else {
                wp_send_json_success(['message' => __('Cài đặt đã được lưu thành công!', 'checkin-mkt192')]);
            }
        }
        ?>
<div class="wrap checkin-admin-wrapper">
    <?php include CHECKIN_PLUGIN_DIR . 'admin/partials/global-header.php'; ?>
    <?php include CHECKIN_PLUGIN_DIR . 'admin/partials/admin-notices.php'; ?>
    <div class="checkin-admin-page">
        <?php $this->render_page_header(); ?>
        <?php $this->render_connections_grid(); ?>
        <?php $this->render_modals(); ?>
    </div>
</div>
<?php
    }

    private function render_page_header() {
        ?>
<div class="checkin-page-header">
    <div>
        <h1 class="checkin-page-title">
            <span class="dashicons dashicons-admin-links"></span>
            <?php _e('Cài đặt Kết nối', 'checkin-mkt192'); ?>
        </h1>
        <p class="checkin-page-description">
            <?php _e('Kết nối với các nền tảng mạng xã hội và dịch vụ của bên thứ ba', 'checkin-mkt192'); ?>
        </p>
    </div>
</div>
<?php
    }

    private function render_connections_grid() {
        $connections = [
            'zalo' => [
                'title'   => 'Zalo',
                'icon'    => 'dashicons-admin-comments',
                'color'   => '#0068FF',
                'enabled' => get_option('checkin_use_zalo_oa', '0') === '1' || get_option('checkin_use_zalo_user', '0') === '1',
            ],
            'lark' => [
                'title'   => 'Lark',
                'icon'    => 'dashicons-admin-site-alt3',
                'color'   => '#00D6B9',
                'enabled' => get_option('checkin_use_lark', '0') === '1',
            ],
            'google' => [
                'title'   => 'Google',
                'icon'    => 'dashicons-google',
                'color'   => '#4285F4',
                'enabled' => get_option('checkin_use_google_login', '0') === '1',
            ],
            'facebook' => [
                'title'   => 'Facebook',
                'icon'    => 'dashicons-facebook',
                'color'   => '#1877F2',
                'enabled' => get_option('checkin_use_facebook_login', '0') === '1',
            ],
        ];
        ?>
<div class="checkin-connections-grid">
    <?php foreach ($connections as $key => $connection) : ?>
    <div class="checkin-connection-card <?php echo $connection['enabled'] ? 'enabled' : 'disabled'; ?>"
        data-connection="<?php echo esc_attr($key); ?>">
        <div class="checkin-connection-header">
            <div class="checkin-connection-icon" style="background: <?php echo esc_attr($connection['color']); ?>">
                <span class="dashicons <?php echo esc_attr($connection['icon']); ?>"></span>
            </div>
            <div class="checkin-connection-info">
                <h3 class="checkin-connection-title">
                    <?php echo esc_html($connection['title']); ?>
                </h3>
                <div class="checkin-connection-status">
                    <?php if ($connection['enabled']) : ?>
                    <span class="checkin-badge checkin-badge-success">
                        <?php _e('Đã kết nối', 'checkin-mkt192'); ?>
                    </span>
                    <?php else : ?>
                    <span class="checkin-badge checkin-badge-gray">
                        <?php _e('Chưa kết nối', 'checkin-mkt192'); ?>
                    </span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="checkin-connection-body">
            <div class="checkin-connection-toggle-wrapper">
                <label class="checkin-toggle checkin-toggle-lg">
                    <input type="checkbox" class="checkin-connection-toggle"
                        data-connection="<?php echo esc_attr($key); ?>" <?php checked($connection['enabled'], true); ?>>
                    <span class="checkin-toggle-slider"></span>
                </label>
                <span class="checkin-toggle-status-text">
                    <?php echo $connection['enabled'] ? __('Đang bật', 'checkin-mkt192') : __('Đang tắt', 'checkin-mkt192'); ?>
                </span>
            </div>
            <button type="button"
                class="checkin-button checkin-button-secondary checkin-button-sm checkin-button-settings"
                onclick="openConnectionModal('<?php echo esc_js($key); ?>')">
                <span class="dashicons dashicons-admin-settings"></span>
                <?php _e('Cài đặt', 'checkin-mkt192'); ?>
            </button>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<?php
    }

    private function render_modals() {
        // Render all connection modals
        $this->render_zalo_modal();
        $this->render_lark_modal();
        $this->render_google_modal();
        $this->render_facebook_modal();
        $this->render_bot_form_modal();
    }

    private function render_zalo_modal() {
        $use_zalo_oa       = get_option('checkin_use_zalo_oa', '0');
        $use_zalo_user     = get_option('checkin_use_zalo_user', '0');
        $zalo_user_domain  = get_option('checkin_zalo_user_domain', '');
        $zalo_user_send_customer = get_option('checkin_zalo_user_send_customer', '1');
        $zalo_user_send_group    = get_option('checkin_zalo_user_send_group', '1');

        // ZBS Template selections
        $zbs_template_booking          = get_option('checkin_zbs_template_booking', '');
        $zbs_template_cancel_booking   = get_option('checkin_zbs_template_cancel_booking', '');
        $zbs_template_booking_reminder = get_option('checkin_zbs_template_booking_reminder', '');
        $zbs_template_invoice          = get_option('checkin_zbs_template_invoice', '');
        ?>
<!-- Modal Zalo -->
<div id="modal-zalo" class="checkin-modal-backdrop">
    <div class="checkin-modal" style="max-width: 600px;">
        <div class="checkin-modal-header">
            <h2 class="checkin-modal-title">
                <span class="dashicons dashicons-admin-comments" style="color: #0068FF;"></span>
                <?php _e('Cài đặt Zalo', 'checkin-mkt192'); ?>
            </h2>
            <button type="button" class="checkin-modal-close" onclick="closeConnectionModal('zalo')">
                <span class="dashicons dashicons-no-alt"></span>
            </button>
        </div>
        <form id="form-zalo" class="checkin-connection-form">
            <div class="checkin-modal-body">
                <!-- Zalo OA -->
                <div class="checkin-form-group">
                    <label class="checkin-toggle">
                        <input type="checkbox" name="checkin_use_zalo_oa" value="1" <?php checked($use_zalo_oa, '1'); ?>
                            data-toggle-target=".zalo-oa-settings">
                        <span class="checkin-toggle-slider"></span>
                        <span class="checkin-toggle-label">
                            <?php _e('Kích hoạt Zalo OA', 'checkin-mkt192'); ?>
                        </span>
                    </label>
                    <p class="checkin-form-description">
                        <?php _e('Sử dụng Zalo Official Account', 'checkin-mkt192'); ?>
                    </p>
                    <div class="checkin-alert checkin-alert-info" style="margin-top: 20px;">
                    <span class="checkin-alert-icon">ℹ</span>
                    <div class="checkin-alert-content">
                        <div class="checkin-alert-message">
                            <?php _e('Để sử dụng Zalo, bạn cần đăng ký ứng dụng tại Zalo Developer Portal và lấy thông tin cấu hình.', 'checkin-mkt192'); ?>
                        </div>
                    </div>
                </div>
                </div>

                <!-- Zalo OA Settings -->
                <div class="zalo-oa-settings" style="display: none; position: relative;">
                    <!-- Loading Overlay -->
                    <div id="zalo-loading-overlay"
                        style="display: none; position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: rgba(255, 255, 255, 0.9); backdrop-filter: blur(8px); -webkit-backdrop-filter: blur(8px); z-index: 1000; border-radius: 8px;">
                        <div
                            style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); text-align: center;">
                            <div class="zalo-spinner"
                                style="width: 50px; height: 50px; margin: 0 auto 15px; border: 4px solid #e9ecef; border-top-color: #0068FF; border-radius: 50%; animation: spin 0.8s linear infinite;">
                            </div>
                            <p style="color: #495057; font-size: 14px; font-weight: 500;">Đang tải thông tin...</p>
                        </div>
                    </div>

                    <!-- Credentials Form (Hidden when connected) -->
                    <div id="zalo-credentials-form">
                        <!-- Callback URL Warning -->
                        <div class="checkin-alert checkin-alert-warning" style="margin-bottom: 20px;">
                            <span class="checkin-alert-icon">⚠️</span>
                            <div class="checkin-alert-content">
                                <div class="checkin-alert-title" style="font-weight: 600; margin-bottom: 8px;">
                                    <?php _e('Quan trọng: Callback URL', 'checkin-mkt192'); ?>
                                </div>
                                <div class="checkin-alert-message" style="font-size: 13px; margin-bottom: 10px;">
                                    <?php _e('Trước khi kết nối, đăng ký Callback URL này trên Zalo Developer Console:', 'checkin-mkt192'); ?>
                                </div>
                                <div
                                    style="background: #fff; padding: 10px; border-radius: 4px; font-family: monospace; font-size: 12px; word-break: break-all; border: 1px solid #ffa94d;">
                                    <span
                                        id="zalo-callback-url-display"><?php echo esc_html(rest_url('vg/v1/zalo-webhook')); ?></span>
                                </div>
                                <div style="margin-top: 10px;">
                                    <a href="https://developers.zalo.me/" target="_blank" rel="noopener"
                                        style="color: #1c7ed6; text-decoration: underline; font-size: 13px;">
                                        <?php _e('Mở Zalo Developer Console →', 'checkin-mkt192'); ?>
                                    </a>
                                </div>
                            </div>
                        </div>

                        <p class="checkin-form-description"
                            style="margin-top: 8px; text-align: center; font-size: 12px; color: #868e96;">
                            <?php _e('Nhập App ID và Secret Key để hiện nút kết nối', 'checkin-mkt192'); ?>
                        </p>

                        <div class="checkin-form-group">
                            <label class="checkin-form-label">
                                <?php _e('Zalo OA App ID', 'checkin-mkt192'); ?>
                            </label>
                            <input type="text" name="checkin_zalo_oa_app_id"
                                value="<?php echo esc_attr(get_option('checkin_zalo_oa_app_id', '')); ?>"
                                class="checkin-form-input" placeholder="1234567890123456789">
                            <p class="checkin-form-description">
                                <?php _e('App ID từ Zalo Developer Portal', 'checkin-mkt192'); ?>
                            </p>
                        </div>

                        <div class="checkin-form-group">
                            <label class="checkin-form-label">
                                <?php _e('Zalo OA Secret Key', 'checkin-mkt192'); ?>
                            </label>
                            <input type="password" name="checkin_zalo_oa_secret_key"
                                value="<?php echo esc_attr(get_option('checkin_zalo_oa_secret_key', '')); ?>"
                                class="checkin-form-input" placeholder="your-secret-key">
                            <p class="checkin-form-description">
                                <?php _e('Secret Key từ Zalo Developer Portal', 'checkin-mkt192'); ?>
                            </p>
                        </div>

                        <!-- Connect Button under Secret Key -->
                        <div class="checkin-form-group">
                            <button type="button" class="checkin-button checkin-button-success"
                                id="test-zalo-connection-btn" onclick="testZaloConnection()"
                                style="display: none; width: 100%;">
                                <span class="dashicons dashicons-admin-links" style="margin-right: 5px;"></span>
                                <span
                                    id="zalo-connect-btn-text"><?php _e('Kết nối Zalo OA', 'checkin-mkt192'); ?></span>
                            </button>
                        </div>
                    </div>
                    <!-- End Credentials Form -->

                    <!-- Connected OA Info (Outside credentials form) -->
                    <div id="zalo-oa-info" class="checkin-card"
                        style="display: none; margin-bottom: 20px; border: 2px solid #0068FF; background: #f8f9fa;">
                        <div style="padding: 20px;">
                            <div style="display: flex; align-items: center; gap: 15px;">
                                <div style="flex-shrink: 0;">
                                    <div
                                        style="width: 60px; height: 60px; border-radius: 50%; background: linear-gradient(135deg, #0068FF, #00A6FF); display: flex; align-items: center; justify-content: center; font-size: 28px; color: white; box-shadow: 0 4px 12px rgba(0, 104, 255, 0.3);">
                                        <span class="dashicons dashicons-admin-comments"
                                            style="font-size: 32px; width: 32px; height: 32px;"></span>
                                    </div>
                                </div>
                                <div style="flex: 1;">
                                    <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 5px;">
                                        <h3 id="zalo-oa-name"
                                            style="margin: 0; font-size: 18px; font-weight: 600; color: #212529;">
                                            Loading...</h3>
                                        <span id="zalo-oa-verified"
                                            style="background: rgb(0, 104, 255);display: flex;align-items: center;color: white;padding: 2px 8px;border-radius: 12px;font-size: 11px;font-weight: 600;">
                                            <span class="dashicons dashicons-yes-alt"
                                                style="font-size: 12px; width: 12px; height: 12px; margin-right: 2px;"></span>
                                            Xác thực
                                        </span>
                                    </div>
                                    <span style="margin-left: 8px;" id="zalo-oa-id">OA ID: ...</span>
                                    <div
                                        style="display: flex; align-items: center; gap: 15px; font-size: 13px; color: #6c757d;">
                                        <span>
                                            <span class="dashicons dashicons-groups"
                                                style="font-size: 14px; width: 14px; height: 14px;"></span>
                                            <strong id="zalo-oa-followers">0</strong> Followers
                                        </span>
                                        <span id="zalo-oa-package"
                                            style="background: #e7f5ff; color: #1971c2; padding: 3px 10px; border-radius: 4px; font-weight: 500;">Free</span>
                                    </div>
                                    <div
                                        style="display: flex;align-items: center;gap: 3px;margin-top: 8px;font-size: 12px;color: #868e96;">
                                        <span class="dashicons dashicons-yes-alt"
                                            style="color: #51cf66; font-size: 14px; width: 14px; height: 14px;"></span>
                                        <span
                                            style="color: #099721;background: #51cf663b;padding: 4px 8px;border-radius: 5px;font-weight: 600;">Đã
                                            kết nối</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Reconnect Button (shown when OA info is displayed) -->
                    <div class="checkin-form-group" id="zalo-reconnect-btn-wrapper" style="display: none;">
                        <button type="button" class="checkin-button checkin-button-primary" id="zalo-reconnect-btn"
                            style="width: 100%;">
                            <span class="dashicons dashicons-update" style="margin-right: 5px;"></span>
                            <?php _e('Kết nối lại', 'checkin-mkt192'); ?>
                        </button>
                    </div>

                    <!-- ZBS Template Settings (shown when OA is connected) -->
                    <div id="zbs-template-section" style="display: none;">
                        <div class="checkin-divider"></div>

                        <div class="zbs-section-header">
                            <h3 class="zbs-section-title">
                                <span class="zbs-section-icon">
                                    <span class="dashicons dashicons-media-text"></span>
                                </span>
                                <?php _e('Cài đặt ZBS Template', 'checkin-mkt192'); ?>
                            </h3>
                            <button type="button" class="zbs-btn-load"
                                id="btn-load-zbs-templates" onclick="loadZaloTemplates()">
                                <span class="dashicons dashicons-update"></span>
                                <?php _e('Tải danh sách', 'checkin-mkt192'); ?>
                            </button>
                            <button type="button" class="zbs-btn-load zbs-btn-toggle"
                                id="btn-toggle-zbs-templates" style="display: none;">
                                <span class="dashicons dashicons-arrow-down-alt2"></span>
                                <?php _e('Mở rộng', 'checkin-mkt192'); ?>
                            </button>
                        </div>

                        <div id="zbs-templates-loading" style="display: none;">
                            <div class="zbs-loading">
                                <div class="zbs-loading-spinner"></div>
                                <span class="zbs-loading-text"><?php _e('Đang tải danh sách template...', 'checkin-mkt192'); ?></span>
                            </div>
                        </div>

                        <div id="zbs-templates-content" style="display: none;">
                            <!-- Booking Template -->
                            <div class="zbs-template-card" data-type="booking">
                                <div class="zbs-card-header">
                                    <label class="zbs-template-label">
                                        <span class="zbs-template-emoji">📅</span>
                                        <?php _e('Xác nhận đặt lịch', 'checkin-mkt192'); ?>
                                    </label>
                                    <button type="button" class="zbs-info-btn" title="<?php _e('Xem chi tiết template', 'checkin-mkt192'); ?>">
                                        <span class="dashicons dashicons-info-outline"></span>
                                    </button>
                                </div>
                                <select name="checkin_zbs_template_booking" id="zbs-template-booking" class="zbs-select zbs-select-hidden">
                                    <option value=""><?php _e('-- Chọn template --', 'checkin-mkt192'); ?></option>
                                </select>
                                <div class="zbs-pill-container" id="zbs-pill-booking">
                                    <button type="button" class="zbs-pill-placeholder">
                                        <span class="dashicons dashicons-plus-alt2"></span>
                                        <?php _e('Chọn template', 'checkin-mkt192'); ?>
                                    </button>
                                    <div class="zbs-pill" style="display: none;">
                                        <span class="zbs-pill-text"></span>
                                        <button type="button" class="zbs-pill-clear" title="<?php _e('Xóa', 'checkin-mkt192'); ?>">
                                            <span class="dashicons dashicons-no-alt"></span>
                                        </button>
                                    </div>
                                </div>
                                <div class="zbs-template-detail" id="zbs-detail-booking" style="display: none;"></div>
                            </div>

                            <!-- Cancel Booking Template -->
                            <div class="zbs-template-card" data-type="cancel">
                                <div class="zbs-card-header">
                                    <label class="zbs-template-label">
                                        <span class="zbs-template-emoji">❌</span>
                                        <?php _e('Hủy lịch hẹn', 'checkin-mkt192'); ?>
                                    </label>
                                    <button type="button" class="zbs-info-btn" title="<?php _e('Xem chi tiết template', 'checkin-mkt192'); ?>">
                                        <span class="dashicons dashicons-info-outline"></span>
                                    </button>
                                </div>
                                <select name="checkin_zbs_template_cancel_booking" id="zbs-template-cancel-booking" class="zbs-select zbs-select-hidden">
                                    <option value=""><?php _e('-- Chọn template --', 'checkin-mkt192'); ?></option>
                                </select>
                                <div class="zbs-pill-container" id="zbs-pill-cancel-booking">
                                    <button type="button" class="zbs-pill-placeholder">
                                        <span class="dashicons dashicons-plus-alt2"></span>
                                        <?php _e('Chọn template', 'checkin-mkt192'); ?>
                                    </button>
                                    <div class="zbs-pill" style="display: none;">
                                        <span class="zbs-pill-text"></span>
                                        <button type="button" class="zbs-pill-clear" title="<?php _e('Xóa', 'checkin-mkt192'); ?>">
                                            <span class="dashicons dashicons-no-alt"></span>
                                        </button>
                                    </div>
                                </div>
                                <div class="zbs-template-detail" id="zbs-detail-cancel-booking" style="display: none;"></div>
                            </div>

                            <!-- Booking Reminder Template -->
                            <div class="zbs-template-card" data-type="reminder">
                                <div class="zbs-card-header">
                                    <label class="zbs-template-label">
                                        <span class="zbs-template-emoji">⏰</span>
                                        <?php _e('Nhắc lịch hẹn', 'checkin-mkt192'); ?>
                                    </label>
                                    <button type="button" class="zbs-info-btn" title="<?php _e('Xem chi tiết template', 'checkin-mkt192'); ?>">
                                        <span class="dashicons dashicons-info-outline"></span>
                                    </button>
                                </div>
                                <select name="checkin_zbs_template_booking_reminder" id="zbs-template-booking-reminder" class="zbs-select zbs-select-hidden">
                                    <option value=""><?php _e('-- Chọn template --', 'checkin-mkt192'); ?></option>
                                </select>
                                <div class="zbs-pill-container" id="zbs-pill-booking-reminder">
                                    <button type="button" class="zbs-pill-placeholder">
                                        <span class="dashicons dashicons-plus-alt2"></span>
                                        <?php _e('Chọn template', 'checkin-mkt192'); ?>
                                    </button>
                                    <div class="zbs-pill" style="display: none;">
                                        <span class="zbs-pill-text"></span>
                                        <button type="button" class="zbs-pill-clear" title="<?php _e('Xóa', 'checkin-mkt192'); ?>">
                                            <span class="dashicons dashicons-no-alt"></span>
                                        </button>
                                    </div>
                                </div>
                                <div class="zbs-template-detail" id="zbs-detail-booking-reminder" style="display: none;"></div>
                            </div>

                            <!-- Invoice Template -->
                            <div class="zbs-template-card" data-type="invoice">
                                <div class="zbs-card-header">
                                    <label class="zbs-template-label">
                                        <span class="zbs-template-emoji">🧾</span>
                                        <?php _e('Hóa đơn', 'checkin-mkt192'); ?>
                                    </label>
                                    <button type="button" class="zbs-info-btn" title="<?php _e('Xem chi tiết template', 'checkin-mkt192'); ?>">
                                        <span class="dashicons dashicons-info-outline"></span>
                                    </button>
                                </div>
                                <select name="checkin_zbs_template_invoice" id="zbs-template-invoice" class="zbs-select zbs-select-hidden">
                                    <option value=""><?php _e('-- Chọn template --', 'checkin-mkt192'); ?></option>
                                </select>
                                <div class="zbs-pill-container" id="zbs-pill-invoice">
                                    <button type="button" class="zbs-pill-placeholder">
                                        <span class="dashicons dashicons-plus-alt2"></span>
                                        <?php _e('Chọn template', 'checkin-mkt192'); ?>
                                    </button>
                                    <div class="zbs-pill" style="display: none;">
                                        <span class="zbs-pill-text"></span>
                                        <button type="button" class="zbs-pill-clear" title="<?php _e('Xóa', 'checkin-mkt192'); ?>">
                                            <span class="dashicons dashicons-no-alt"></span>
                                        </button>
                                    </div>
                                </div>
                                <div class="zbs-template-detail" id="zbs-detail-invoice" style="display: none;"></div>
                            </div>
                        </div>

                        <div id="zbs-templates-empty" style="display: none;">
                            <div class="checkin-alert checkin-alert-warning">
                                <span class="checkin-alert-icon">⚠️</span>
                                <div class="checkin-alert-content">
                                    <div class="checkin-alert-message">
                                        <?php _e('Không tìm thấy ZBS template nào đang được kích hoạt (ENABLE). Vui lòng tạo và kích hoạt template trên Zalo Business.', 'checkin-mkt192'); ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Hidden inputs to store saved template values -->
                        <input type="hidden" id="saved-zbs-template-booking" value="<?php echo esc_attr($zbs_template_booking); ?>">
                        <input type="hidden" id="saved-zbs-template-cancel-booking" value="<?php echo esc_attr($zbs_template_cancel_booking); ?>">
                        <input type="hidden" id="saved-zbs-template-booking-reminder" value="<?php echo esc_attr($zbs_template_booking_reminder); ?>">
                        <input type="hidden" id="saved-zbs-template-invoice" value="<?php echo esc_attr($zbs_template_invoice); ?>">
                    </div>
                </div>

                <!-- Zalo User -->
                <div class="checkin-form-group">
                    <label class="checkin-toggle">
                        <input type="checkbox" name="checkin_use_zalo_user" value="1"
                            <?php checked($use_zalo_user, '1'); ?> data-toggle-target=".zalo-user-settings">
                        <span class="checkin-toggle-slider"></span>
                        <span class="checkin-toggle-label">
                            <?php _e('Sử dụng Zalo cá nhân', 'checkin-mkt192'); ?>
                        </span>
                    </label>
                    <p class="checkin-form-description">
                        <?php _e('Cho phép gửi tin nhắn hệ thống bằng Zalo cá nhân', 'checkin-mkt192'); ?>
                    </p>
                </div>

                <!-- Zalo User Domain -->
                <div class="zalo-user-settings" style="display: none;">
                    <div class="checkin-form-group">
                        <label class="checkin-form-label">
                            <?php _e('Zalo User Domain', 'checkin-mkt192'); ?>
                        </label>
                        <input type="text" name="checkin_zalo_user_domain"
                            value="<?php echo esc_attr($zalo_user_domain); ?>" class="checkin-form-input"
                            placeholder="your-domain">
                        <p class="checkin-form-description">
                            <?php _e('Domain từ Zalo Developer Portal', 'checkin-mkt192'); ?>
                        </p>
                    </div>

                    <!-- Zalo User Sub-toggles -->
                    <div class="checkin-info-callout" style="margin: 12px 0;">
                        <span class="dashicons dashicons-info" style="color: #0068ff;"></span>
                        <span><?php _e('Nếu đang bật Zalo OA, tin nhắn đến khách sẽ gửi qua OA. Chỉ tin nhắn Group đi qua Zalo cá nhân.', 'checkin-mkt192'); ?></span>
                    </div>

                    <div class="checkin-form-group zalo-user-sub-toggle">
                        <label class="checkin-toggle">
                            <input type="checkbox" name="checkin_zalo_user_send_customer" value="1"
                                <?php checked($zalo_user_send_customer, '1'); ?>
                                data-zalo-sub="customer"
                                <?php echo ($use_zalo_oa === '1') ? 'disabled' : ''; ?>>
                            <span class="checkin-toggle-slider"></span>
                            <span class="checkin-toggle-label">
                                <?php _e('Gửi tin nhắn đến khách hàng', 'checkin-mkt192'); ?>
                            </span>
                        </label>
                        <?php if ($use_zalo_oa === '1'): ?>
                            <p class="checkin-form-description" style="color: var(--checkin-warning, #dba617);">
                                <?php _e('⚠️ Đang tắt vì Zalo OA đã bật — tin nhắn khách sẽ gửi qua OA/ZBS', 'checkin-mkt192'); ?>
                            </p>
                        <?php else: ?>
                            <p class="checkin-form-description">
                                <?php _e('Gửi xác nhận/nhắc/hủy lịch hẹn đến khách qua Zalo cá nhân', 'checkin-mkt192'); ?>
                            </p>
                        <?php endif; ?>
                    </div>

                    <div class="checkin-form-group zalo-user-sub-toggle">
                        <label class="checkin-toggle">
                            <input type="checkbox" name="checkin_zalo_user_send_group" value="1"
                                <?php checked($zalo_user_send_group, '1'); ?>
                                data-zalo-sub="group">
                            <span class="checkin-toggle-slider"></span>
                            <span class="checkin-toggle-label">
                                <?php _e('Gửi thông báo đến Group nhân viên', 'checkin-mkt192'); ?>
                            </span>
                        </label>
                        <p class="checkin-form-description">
                            <?php _e('Thông báo lịch hẹn mới/nhắc/hủy đến Group Zalo nhân viên', 'checkin-mkt192'); ?>
                        </p>
                    </div>
                </div>

            </div>
            <div class="checkin-modal-footer">
                <button type="button" class="checkin-button checkin-button-secondary"
                    onclick="closeConnectionModal('zalo')">
                    <?php _e('Hủy', 'checkin-mkt192'); ?>
                </button>
                <button type="submit" class="checkin-button checkin-button-primary">
                    <?php _e('Lưu cài đặt', 'checkin-mkt192'); ?>
                </button>
            </div>
        </form>
    </div>
</div>
<?php
    }

    private function render_lark_modal() {
        $use_lark = get_option('checkin_use_lark', '0');

        // Get lark bots from database
        global $wpdb;
        $table_name = $wpdb->prefix . 'checkin_mkt192_message_bot_settings';

        // Check if table exists before querying
        $bots = [];
        if ( $wpdb->get_var( "SHOW TABLES LIKE '$table_name'" ) === $table_name ) {
            // Get all Lark bots (bot_type can be 'webhook' or 'interactive', not 'lark')
            $bots = $wpdb->get_results("SELECT * FROM $table_name ORDER BY id DESC");
        }
        ?>
<div id="modal-lark" class="checkin-modal-backdrop">
    <div class="checkin-modal" style="max-width: 700px;">
        <div class="checkin-modal-header">
            <h2 class="checkin-modal-title">
                <span class="dashicons dashicons-admin-site-alt3" style="color: #00D6B9;"></span>
                <?php _e('Cài đặt Lark', 'checkin-mkt192'); ?>
            </h2>
            <button type="button" class="checkin-modal-close" onclick="closeConnectionModal('lark')">
                <span class="dashicons dashicons-no-alt"></span>
            </button>
        </div>
        <form id="form-lark" class="checkin-connection-form">
            <div class="checkin-modal-body">
                <div class="checkin-form-group">
                    <label class="checkin-toggle">
                        <input type="checkbox" name="checkin_use_lark" value="1" <?php checked($use_lark, '1'); ?>
                            id="lark-enable-toggle">
                        <span class="checkin-toggle-slider"></span>
                        <span class="checkin-toggle-label">
                            <?php _e('Kích hoạt Lark Bot', 'checkin-mkt192'); ?>
                        </span>
                    </label>
                    <p class="checkin-form-description">
                        <?php _e('Bật để sử dụng hệ thống Lark Bot cho thông báo', 'checkin-mkt192'); ?>
                    </p>
                </div>

                <div id="lark-bot-section" style="<?php echo $use_lark === '1' ? '' : 'display: none;'; ?>">
                    <div class="checkin-divider"></div>

                    <div class="checkin-flex checkin-items-center checkin-justify-between" style="margin-bottom: 16px;">
                        <h3 style="margin: 0; font-size: 15px; font-weight: 600;">
                            <?php _e('Danh sách Lark Bot', 'checkin-mkt192'); ?>
                        </h3>
                        <button type="button" class="checkin-button checkin-button-primary checkin-button-sm"
                            onclick="openAddBotModal()">
                            <span class="dashicons dashicons-plus-alt"></span>
                            <?php _e('Thêm Bot', 'checkin-mkt192'); ?>
                        </button>
                    </div>

                    <?php if (empty($bots)) : ?>
                    <div class="checkin-empty-state" style="padding: 30px 20px;">
                        <div class="checkin-empty-state-icon">
                            <span class="dashicons dashicons-admin-site-alt3" style="font-size: 48px;"></span>
                        </div>
                        <div class="checkin-empty-state-title">
                            <?php _e('Chưa có Lark Bot nào', 'checkin-mkt192'); ?>
                        </div>
                        <div class="checkin-empty-state-description">
                            <?php _e('Thêm bot đầu tiên để bắt đầu nhận thông báo', 'checkin-mkt192'); ?>
                        </div>
                    </div>
                    <?php else : ?>
                    <div class="checkin-bot-list">
                        <?php foreach ($bots as $bot) : ?>
                        <div class="checkin-bot-item" data-bot-id="<?php echo esc_attr($bot->id); ?>">
                            <div class="checkin-bot-info">
                                <h4 class="checkin-bot-name">
                                    <?php echo esc_html($bot->bot_name); ?>
                                </h4>
                                <p class="checkin-bot-type">
                                    <?php
                                    $types = is_string($bot->notification_types) ? json_decode($bot->notification_types, true) : [];
                                    if (!empty($types) && is_array($types)) {
                                        echo esc_html(implode(', ', array_slice($types, 0, 3)));
                                        if (count($types) > 3) echo '...';
                                    } else {
                                        echo esc_html($bot->bot_type);
                                    }
                                    ?>
                                </p>
                            </div>
                            <div class="checkin-bot-status">
                                <?php if ($bot->is_active) : ?>
                                <span class="checkin-badge checkin-badge-success">Active</span>
                                <?php else : ?>
                                <span class="checkin-badge checkin-badge-gray">Inactive</span>
                                <?php endif; ?>
                            </div>
                            <div class="checkin-bot-actions">
                                <button type="button" class="checkin-button checkin-button-sm checkin-button-ghost"
                                    onclick="openEditBotModal(<?php echo esc_js($bot->id); ?>)"
                                    title="<?php _e('Chỉnh sửa', 'checkin-mkt192'); ?>">
                                    <span class="dashicons dashicons-edit"></span>
                                </button>
                                <button type="button"
                                    class="checkin-button checkin-button-sm checkin-button-ghost checkin-button-danger"
                                    onclick="deleteLarkBot(<?php echo esc_js($bot->id); ?>)"
                                    title="<?php _e('Xóa', 'checkin-mkt192'); ?>">
                                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                        stroke-width="2">
                                        <polyline points="3 6 5 6 21 6"></polyline>
                                        <path
                                            d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2">
                                        </path>
                                        <line x1="10" y1="11" x2="10" y2="17"></line>
                                        <line x1="14" y1="11" x2="14" y2="17"></line>
                                    </svg>
                                </button>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>

                    <div class="checkin-alert checkin-alert-info" style="margin-top: 16px;">
                        <span class="checkin-alert-icon">💡</span>
                        <div class="checkin-alert-content">
                            <div class="checkin-alert-message">
                                <?php _e('Bạn có thể tạo nhiều bot với các loại thông báo khác nhau: điểm danh, lương, tồn kho, v.v.', 'checkin-mkt192'); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="checkin-modal-footer">
                <button type="button" class="checkin-button checkin-button-secondary"
                    onclick="closeConnectionModal('lark')">
                    <?php _e('Đóng', 'checkin-mkt192'); ?>
                </button>
                <button type="submit" class="checkin-button checkin-button-primary">
                    <?php _e('Lưu cài đặt', 'checkin-mkt192'); ?>
                </button>
            </div>
        </form>
    </div>
</div>
<?php
    }

    private function render_bot_form_modal() {
        ?>
<!-- Modal Add/Edit Bot -->
<div id="modal-bot-form" class="checkin-modal-backdrop">
    <div class="checkin-modal checkin-modal-bot">
        <form id="form-bot" class="checkin-connection-form">
            <input type="hidden" name="bot_id" id="bot_id" value="">
            <div class="checkin-modal-header">
                <h2 class="checkin-modal-title" id="bot-modal-title">
                    <span class="dashicons dashicons-admin-site-alt3"></span>
                    <span id="bot-modal-title-text"><?php _e('Thêm Bot', 'checkin-mkt192'); ?></span>
                </h2>
                <button type="button" class="checkin-modal-close" onclick="closeBotFormModal()">
                    <span class="dashicons dashicons-no-alt"></span>
                </button>
            </div>
            <div class="checkin-modal-body">
                <!-- Bot Name -->
                <div class="checkin-form-group">
                    <label class="checkin-form-label required">
                        <?php _e('Tên Bot', 'checkin-mkt192'); ?>
                    </label>
                    <input type="text" name="bot_name" id="bot_name" class="checkin-form-input" required
                        placeholder="<?php _e('VD: Booking Bot, Inventory Bot', 'checkin-mkt192'); ?>">
                    <p class="checkin-form-description">
                        <?php _e('Tên để nhận diện bot', 'checkin-mkt192'); ?>
                    </p>
                </div>

                <!-- Bot Type -->
                <div class="above-bot-type-section">
                    <div class="checkin-form-group">
                        <label class="checkin-form-label required">
                            <?php _e('Loại Bot', 'checkin-mkt192'); ?>
                        </label>
                        <select name="bot_type" id="bot_type" class="checkin-form-input" required>
                            <?php foreach (Checkin_MKT192_Message_Bot_Manager::BOT_TYPES as $key => $label): ?>
                            <option value="<?php echo esc_attr($key); ?>">
                                <?php echo esc_html($label); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                        <p class="checkin-form-description">
                            <?php _e('Bot tương tác dùng Lark API, Bot webhook gửi qua URL', 'checkin-mkt192'); ?>
                        </p>
                    </div>

                    <!-- Active Status -->
                    <div class="checkin-form-group">
                        <label class="checkin-toggle">
                            <input type="checkbox" name="is_active" id="is_active" value="1" checked>
                            <span class="checkin-toggle-slider"></span>
                            <span class="checkin-toggle-label">
                                <?php _e('Kích hoạt bot', 'checkin-mkt192'); ?>
                            </span>
                        </label>
                    </div>
                </div>

                <!-- Notification Types -->
                <div class="checkin-form-group">
                    <label class="checkin-form-label required">
                        <?php _e('Loại Thông báo', 'checkin-mkt192'); ?>
                    </label>
                    <div class="checkin-pill-select" id="notification-types-pills">
                        <?php foreach (Checkin_MKT192_Message_Bot_Manager::NOTIFICATION_TYPES as $key => $label):
                            $description = Checkin_MKT192_Message_Bot_Manager::NOTIFICATION_DESCRIPTIONS[$key] ?? '';
                            // Determine bot type for this notification
                            $bot_type_filter = '';
                            if (in_array($key, Checkin_MKT192_Message_Bot_Manager::NOTIFICATION_TYPES_BY_BOT['interactive'])) {
                                $bot_type_filter = 'interactive';
                            } elseif (in_array($key, Checkin_MKT192_Message_Bot_Manager::NOTIFICATION_TYPES_BY_BOT['webhook'])) {
                                $bot_type_filter = 'webhook';
                            }
                        ?>
                        <button type="button" class="checkin-pill" data-value="<?php echo esc_attr($key); ?>"
                            data-bot-type="<?php echo esc_attr($bot_type_filter); ?>"
                            data-description="<?php echo esc_attr($description); ?>">
                            <span class="pill-label"><?php echo esc_html($label); ?></span>
                            <span class="dashicons dashicons-info-outline pill-info-icon"></span>
                        </button>
                        <?php endforeach; ?>
                    </div>
                    <input type="hidden" name="notification_types" id="notification_types" value="">
                    <p class="checkin-form-description">
                        <?php _e('Chọn các loại thông báo phù hợp với loại bot. Nhấp vào biểu tượng ⓘ để xem mô tả.', 'checkin-mkt192'); ?>
                    </p>
                </div>

                <!-- Interactive Bot Fields -->
                <div id="interactive-bot-fields" class="bot-fields-section">
                    <div class="checkin-divider"></div>
                    <h4 class="bot-fields-title">
                        <?php _e('Cấu hình Bot Tương tác', 'checkin-mkt192'); ?>
                    </h4>

                    <div class="checkin-form-group">
                        <label class="checkin-form-label">
                            <?php _e('Chat ID', 'checkin-mkt192'); ?>
                        </label>
                        <input type="text" name="chat_id" id="chat_id" class="checkin-form-input"
                            placeholder="<?php _e('Chat ID hoặc Group ID', 'checkin-mkt192'); ?>">
                    </div>

                    <div class="checkin-form-group">
                        <label class="checkin-form-label">
                            <?php _e('App ID', 'checkin-mkt192'); ?>
                        </label>
                        <input type="text" name="app_id" id="app_id" class="checkin-form-input"
                            placeholder="<?php _e('App ID từ Lark', 'checkin-mkt192'); ?>">
                    </div>

                    <div class="checkin-form-group">
                        <label class="checkin-form-label">
                            <?php _e('App Secret', 'checkin-mkt192'); ?>
                        </label>
                        <input type="password" name="app_secret" id="app_secret" class="checkin-form-input"
                            placeholder="<?php _e('App Secret từ Lark', 'checkin-mkt192'); ?>">
                    </div>
                </div>

                <!-- Webhook Bot Fields -->
                <div id="webhook-bot-fields" class="bot-fields-section">
                    <div class="checkin-divider"></div>
                    <h4 class="bot-fields-title">
                        <?php _e('Cấu hình Bot Webhook', 'checkin-mkt192'); ?>
                    </h4>

                    <div class="checkin-form-group">
                        <label class="checkin-form-label">
                            <?php _e('Webhook URL', 'checkin-mkt192'); ?>
                        </label>
                        <input type="url" name="webhook_url" id="webhook_url" class="checkin-form-input"
                            placeholder="https://open.feishu.cn/open-apis/bot/v2/hook/...">
                        <p class="checkin-form-description">
                            <?php _e('URL webhook từ Lark Bot', 'checkin-mkt192'); ?>
                        </p>
                    </div>
                </div>
            </div>

            <!-- Modal Footer -->
            <div class="checkin-modal-footer">
                <button type="button" class="checkin-button checkin-button-secondary" onclick="closeBotFormModal()">
                    <span class="dashicons dashicons-dismiss"></span>
                    <?php _e('Hủy', 'checkin-mkt192'); ?>
                </button>
                <button type="submit" class="checkin-button checkin-button-primary" id="bot-submit-btn">
                    <span class="dashicons dashicons-saved" id="bot-submit-icon"></span>
                    <span id="bot-submit-text"><?php _e('Tạo Bot', 'checkin-mkt192'); ?></span>
                </button>
            </div>
        </form>
    </div>
</div>
<?php
    }

    private function render_google_modal() {
        $use_google = get_option('checkin_use_google_login', '0');
        $client_id  = get_option('checkin_google_client_id', '');
        ?>
<div id="modal-google" class="checkin-modal-backdrop">
    <div class="checkin-modal" style="max-width: 600px;">
        <div class="checkin-modal-header">
            <h2 class="checkin-modal-title">
                <span class="dashicons dashicons-google" style="color: #4285F4;"></span>
                <?php _e('Cài đặt Google', 'checkin-mkt192'); ?>
            </h2>
            <button type="button" class="checkin-modal-close" onclick="closeConnectionModal('google')">
                <span class="dashicons dashicons-no-alt"></span>
            </button>
        </div>
        <form id="form-google" class="checkin-connection-form">
            <div class="checkin-modal-body">
                <div class="checkin-form-group">
                    <label class="checkin-toggle">
                        <input type="checkbox" name="checkin_use_google_login" value="1"
                            <?php checked($use_google, '1'); ?> data-toggle-target=".google-settings">
                        <span class="checkin-toggle-slider"></span>
                        <span class="checkin-toggle-label">
                            <?php _e('Kích hoạt đăng nhập Google', 'checkin-mkt192'); ?>
                        </span>
                    </label>
                </div>

                <div class="google-settings" style="display: none; position: relative;">
                    <!-- Loading Overlay -->
                    <div id="google-loading-overlay"
                        style="display: none; position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: rgba(255, 255, 255, 0.9); backdrop-filter: blur(8px); -webkit-backdrop-filter: blur(8px); z-index: 1000; border-radius: 8px;">
                        <div
                            style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); text-align: center;">
                            <div class="google-spinner"
                                style="width: 50px; height: 50px; margin: 0 auto 15px; border: 4px solid #e9ecef; border-top-color: #4285F4; border-radius: 50%; animation: spin 0.8s linear infinite;">
                            </div>
                            <p style="color: #495057; font-size: 14px; font-weight: 500;">\u0110ang t\u1ea3i th\u00f4ng
                                tin...</p>
                        </div>
                    </div>

                    <!-- Credentials Form (Hidden when connected) -->
                    <div id="google-credentials-form">
                        <div class="checkin-divider"></div>
                        <div class="checkin-form-group">
                            <label class="checkin-form-label required">
                                <?php _e('Google Client ID', 'checkin-mkt192'); ?>
                            </label>
                            <input type="text" name="checkin_google_client_id"
                                value="<?php echo esc_attr($client_id); ?>" class="checkin-form-input"
                                placeholder="xxxxx.apps.googleusercontent.com">
                            <p class="checkin-form-description">
                                <?php _e('Client ID từ Google Cloud Console', 'checkin-mkt192'); ?>
                            </p>
                        </div>

                        <!-- Debug Info Alert -->
                        <div class="checkin-alert"
                            style="background: #fff3cd; border-color: #ffc107; margin-bottom: 15px;">
                            <span class="checkin-alert-icon" style="color: #856404;">🔍</span>
                            <div class="checkin-alert-content">
                                <div class="checkin-alert-title"
                                    style="font-weight: 600; margin-bottom: 8px; color: #856404;">
                                    Debug Info - URL hiện tại
                                </div>
                                <div style="font-size: 13px; color: #856404; margin-bottom: 10px;">
                                    <strong>Window Location Origin:</strong><br>
                                    <code id="debug-window-origin"
                                        style="background: #fff; padding: 4px 8px; border-radius: 3px; display: inline-block; margin-top: 5px; color: #212529;">Đang tải...</code>
                                </div>
                                <div style="font-size: 13px; color: #856404;">
                                    <strong>WordPress Home URL:</strong><br>
                                    <code
                                        style="background: #fff; padding: 4px 8px; border-radius: 3px; display: inline-block; margin-top: 5px; color: #212529;"><?php echo esc_html(home_url()); ?></code>
                                </div>
                                <div style="margin-top: 10px; font-size: 12px; color: #856404;">
                                    ⚠️ <strong>Quan trọng:</strong> URL trong <code>window.location.origin</code> PHẢI
                                    khớp 100% với URL bạn đã thêm vào Google Console (bao gồm cả http/https và có/không
                                    có www)
                                </div>
                            </div>
                        </div>

                        <div class="checkin-alert checkin-alert-info">
                            <span class="checkin-alert-icon">💡</span>
                            <div class="checkin-alert-content">
                                <div class="checkin-alert-message">
                                    <ol style="margin: 10px 0 0 20px; font-size: 13px;">
                                        <li>Truy cập <a href="https://console.cloud.google.com/apis/credentials"
                                                target="_blank" rel="noopener">Google Cloud Console → Credentials</a>
                                        </li>
                                        <li>Chọn OAuth 2.0 Client ID của bạn</li>
                                        <li>Trong <strong>Authorized JavaScript origins</strong>, thêm <strong>CHÍNH
                                                XÁC</strong> URL từ "Window Location Origin" ở trên (ví dụ: <code
                                                style="background: #e9ecef; padding: 2px 6px; border-radius: 3px;">http://localhost:8080</code>)
                                        </li>
                                        <li><strong style="color: #d9534f;">⚠️ QUAN TRỌNG:</strong> Sau khi lưu,
                                            <strong>ĐỢI 5-10 PHÚT</strong> để Google cập nhật cache. Đây là nguyên nhân
                                            phổ biến nhất gây lỗi CORS!
                                        </li>
                                        <li>Xóa cache trình duyệt (Ctrl+Shift+Delete) hoặc thử <strong>Incognito
                                                mode</strong> (Ctrl+Shift+N)</li>
                                        <li>Sao chép Client ID và dán vào trường trên</li>
                                        <li>Nhấn nút "Kết nối với Google" và kiểm tra Console (F12) nếu có lỗi</li>
                                    </ol>
                                    <div
                                        style="margin-top: 15px; padding: 12px; background: #fff3cd; border-left: 4px solid #ffc107; border-radius: 4px;">
                                        <strong style="color: #856404;">🔴 Nếu vẫn báo lỗi CORS/FedCM:</strong>
                                        <ul style="margin: 8px 0 0 20px; font-size: 12px; color: #856404;">
                                            <li>Kiểm tra URL trong Google Console có <strong>CHÍNH XÁC 100%</strong> với
                                                "Window Location Origin" không (bao gồm cả http/https)</li>
                                            <li>Đợi thêm 10-15 phút nữa (cache của Google rất chậm)</li>
                                            <li>Thử trình duyệt khác (Chrome, Edge, Firefox)</li>
                                            <li>Kiểm tra lại Client ID có đúng không</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Connect Button -->
                        <div class="checkin-form-group">
                            <button type="button" class="checkin-button checkin-button-success"
                                id="test-google-connection-btn-inline" onclick="testGoogleConnection()"
                                style="display: none; width: 100%;">
                                <span class="dashicons dashicons-admin-links" style="margin-right: 5px;"></span>
                                <span
                                    id="google-connect-btn-text"><?php _e('Kết nối với Google', 'checkin-mkt192'); ?></span>
                            </button>
                            <p class="checkin-form-description"
                                style="margin-top: 8px; text-align: center; font-size: 12px; color: #868e96;">
                                <?php _e('Nhập Client ID để hiện nút kết nối', 'checkin-mkt192'); ?>
                            </p>
                        </div>
                    </div>
                    <!-- End Credentials Form -->

                    <!-- Connected Google Info (Outside credentials form) -->
                    <div id="google-account-info" class="checkin-card"
                        style="display: none; margin-bottom: 20px; border: 2px solid #4285F4; background: #f8f9fa;">
                        <div style="padding: 20px;">
                            <div style="display: flex; align-items: center; gap: 15px;">
                                <div style="flex-shrink: 0;">
                                    <div
                                        style="width: 60px; height: 60px; border-radius: 50%; background: linear-gradient(135deg, #4285F4, #34A853); display: flex; align-items: center; justify-content: center; font-size: 28px; color: white; box-shadow: 0 4px 12px rgba(66, 133, 244, 0.3);">
                                        <span class="dashicons dashicons-google"
                                            style="font-size: 32px; width: 32px; height: 32px;"></span>
                                    </div>
                                </div>
                                <div style="flex: 1;">
                                    <div style="display: grid;align-items: center;gap: 8px;margin-bottom: 5px;">
                                        <h3 id="google-account-email"
                                            style="margin: 0; font-size: 18px; font-weight: 600; color: #212529;">
                                            Loading...</h3>
                                        <span id="google-account-verified"
                                            style="background: #4285F4;display: flex;align-items: center;color: white;padding: 2px 8px;width: fit-content;border-radius: 12px;font-size: 11px;text-align: center;font-weight: 600;">
                                            <span class="dashicons dashicons-yes-alt"
                                                style="font-size: 12px; width: 12px; height: 12px; margin-right: 2px;"></span>
                                            Xác thực
                                        </span>
                                    </div>
                                    <div
                                        style="display: flex;align-items: center;gap: 3px;margin-top: 8px;font-size: 12px;color: #868e96;">
                                        <span class="dashicons dashicons-yes-alt"
                                            style="color: #51cf66; font-size: 14px; width: 14px; height: 14px;"></span>
                                        <span style="color: #51cf66; font-weight: 600;">Đã kết nối</span>
                                        <span style="margin-left: 8px;" id="google-account-name">...</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Reconnect Button (shown when account info is displayed) -->
                    <div class="checkin-form-group" id="google-reconnect-btn-wrapper" style="display: none;">
                        <button type="button" class="checkin-button checkin-button-primary" id="google-reconnect-btn"
                            style="width: 100%;">
                            <span class="dashicons dashicons-update" style="margin-right: 5px;"></span>
                            <?php _e('Kết nối lại', 'checkin-mkt192'); ?>
                        </button>
                    </div>
                </div>
            </div>
            <div class="checkin-modal-footer">
                <button type="button" class="checkin-button checkin-button-secondary"
                    onclick="closeConnectionModal('google')">
                    <?php _e('Hủy', 'checkin-mkt192'); ?>
                </button>
                <button type="submit" class="checkin-button checkin-button-primary">
                    <?php _e('Lưu cài đặt', 'checkin-mkt192'); ?>
                </button>
            </div>
        </form>
    </div>
</div>
<?php
    }

    private function render_facebook_modal() {
        $use_facebook = get_option('checkin_use_facebook_login', '0');
        $app_id       = get_option('checkin_facebook_app_id', '');
        $app_secret   = get_option('checkin_facebook_app_secret', '');
        ?>
<div id="modal-facebook" class="checkin-modal-backdrop">
    <div class="checkin-modal" style="max-width: 600px;">
        <div class="checkin-modal-header">
            <h2 class="checkin-modal-title">
                <span class="dashicons dashicons-facebook" style="color: #1877F2;"></span>
                <?php _e('Cài đặt Facebook', 'checkin-mkt192'); ?>
            </h2>
            <button type="button" class="checkin-modal-close" onclick="closeConnectionModal('facebook')">
                <span class="dashicons dashicons-no-alt"></span>
            </button>
        </div>
        <form id="form-facebook" class="checkin-connection-form">
            <div class="checkin-modal-body">
                <div class="checkin-form-group">
                    <label class="checkin-toggle">
                        <input type="checkbox" name="checkin_use_facebook_login" value="1"
                            <?php checked($use_facebook, '1'); ?> data-toggle-target=".facebook-settings">
                        <span class="checkin-toggle-slider"></span>
                        <span class="checkin-toggle-label">
                            <?php _e('Kích hoạt đăng nhập Facebook', 'checkin-mkt192'); ?>
                        </span>
                    </label>
                </div>

                <div class="facebook-settings" style="display: none;">
                    <div class="checkin-divider"></div>

                    <div class="checkin-form-group">
                        <label class="checkin-form-label required">
                            <?php _e('Facebook App ID', 'checkin-mkt192'); ?>
                        </label>
                        <input type="text" name="checkin_facebook_app_id" value="<?php echo esc_attr($app_id); ?>"
                            class="checkin-form-input" placeholder="1234567890123456">
                        <p class="checkin-form-description">
                            <?php _e('App ID từ Facebook Developer Portal', 'checkin-mkt192'); ?>
                        </p>
                    </div>

                    <div class="checkin-form-group">
                        <label class="checkin-form-label required">
                            <?php _e('Facebook App Secret', 'checkin-mkt192'); ?>
                        </label>
                        <div class="checkin-input-wrapper" style="position: relative;">
                            <input type="password" name="checkin_facebook_app_secret"
                                value="<?php echo esc_attr($app_secret); ?>" class="checkin-form-input"
                                id="facebook-app-secret" placeholder="••••••••••••••••">
                            <button type="button" class="button checkin-toggle-password"
                                data-target="facebook-app-secret"
                                style="position: absolute; right: 5px; top: 50%; transform: translateY(-50%);">
                                <span class="dashicons dashicons-visibility"></span>
                            </button>
                        </div>
                        <p class="checkin-form-description">
                            <?php _e('App Secret từ Facebook Developer Portal', 'checkin-mkt192'); ?>
                        </p>
                    </div>
                </div>

                <div class="checkin-alert checkin-alert-warning">
                    <span class="checkin-alert-icon">⚠</span>
                    <div class="checkin-alert-content">
                        <div class="checkin-alert-message">
                            <?php _e('Không chia sẻ App Secret với bất kỳ ai. Thông tin này được mã hóa khi lưu trữ.', 'checkin-mkt192'); ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="checkin-modal-footer">
                <button type="button" class="checkin-button checkin-button-secondary"
                    onclick="closeConnectionModal('facebook')">
                    <?php _e('Hủy', 'checkin-mkt192'); ?>
                </button>
                <button type="submit" class="checkin-button checkin-button-primary">
                    <?php _e('Lưu cài đặt', 'checkin-mkt192'); ?>
                </button>
            </div>
        </form>
    </div>
</div>
<?php
    }

    private function save_connection_settings() {
        // Get the specific connection type being saved
        $connection_type = isset($_POST['connection_type']) ? sanitize_text_field($_POST['connection_type']) : '';

        // Only save the connection specified by connection_type to avoid affecting other connections
        switch ($connection_type) {
            case 'zalo':
                // Lưu trạng thái bật/tắt Zalo OA
                if (isset($_POST['checkin_use_zalo_oa']) && $_POST['checkin_use_zalo_oa'] === '1') {
                    update_option('checkin_use_zalo_oa', '1');
                } else {
                    update_option('checkin_use_zalo_oa', '0');
                }

                // Lưu credentials nếu có (không validate, vì sẽ validate khi OAuth)
                if (isset($_POST['checkin_zalo_oa_app_id'])) {
                    $zalo_app_id = sanitize_text_field($_POST['checkin_zalo_oa_app_id']);
                    if (!empty($zalo_app_id)) {
                        update_option('checkin_zalo_oa_app_id', $zalo_app_id);
                    }
                }
                if (isset($_POST['checkin_zalo_oa_secret_key'])) {
                    $zalo_secret_key = sanitize_text_field($_POST['checkin_zalo_oa_secret_key']);
                    if (!empty($zalo_secret_key)) {
                        update_option('checkin_zalo_oa_secret_key', $zalo_secret_key);
                    }
                }

                // Lưu trạng thái bật/tắt Zalo User
                if (isset($_POST['checkin_use_zalo_user']) && $_POST['checkin_use_zalo_user'] === '1') {
                    update_option('checkin_use_zalo_user', '1');
                } else {
                    update_option('checkin_use_zalo_user', '0');
                }

                // Lưu Zalo User Domain
                if (isset($_POST['checkin_zalo_user_domain'])) {
                    update_option('checkin_zalo_user_domain', sanitize_text_field($_POST['checkin_zalo_user_domain']));
                }

                // Lưu toggle gửi khách / gửi group
                update_option('checkin_zalo_user_send_customer',
                    (isset($_POST['checkin_zalo_user_send_customer']) && $_POST['checkin_zalo_user_send_customer'] === '1') ? '1' : '0'
                );
                update_option('checkin_zalo_user_send_group',
                    (isset($_POST['checkin_zalo_user_send_group']) && $_POST['checkin_zalo_user_send_group'] === '1') ? '1' : '0'
                );

                // Lưu ZBS Template selections
                $zbs_template_fields = [
                    'checkin_zbs_template_booking',
                    'checkin_zbs_template_cancel_booking',
                    'checkin_zbs_template_booking_reminder',
                    'checkin_zbs_template_invoice',
                ];
                foreach ($zbs_template_fields as $field) {
                    if (isset($_POST[$field])) {
                        update_option($field, sanitize_text_field($_POST[$field]));
                    }
                }
                break;

            case 'lark':
                if (isset($_POST['checkin_use_lark'])) {
                    update_option('checkin_use_lark', '1');
                } else {
                    update_option('checkin_use_lark', '0');
                }
                break;

            case 'google':
                // Lưu trạng thái bật/tắt Google
                if (isset($_POST['checkin_use_google_login']) && $_POST['checkin_use_google_login'] === '1') {
                    $google_client_id = isset($_POST['checkin_google_client_id']) ? sanitize_text_field($_POST['checkin_google_client_id']) : '';

                    // Validate Google Client ID - just check not empty, format validation is done on client side
                    if (empty($google_client_id)) {
                        return new WP_Error('missing_google_client_id', __('Vui lòng nhập Google Client ID', 'checkin-mkt192'));
                    }

                    // Test Google Client ID validity by checking its format and making a test request
                    $test_result = $this->test_google_credentials($google_client_id);
                    if (is_wp_error($test_result)) {
                        return $test_result;
                    }

                    update_option('checkin_use_google_login', '1');
                    update_option('checkin_google_client_id', $google_client_id);
                } else {
                    // Khi tắt, chỉ cần lưu trạng thái tắt, không cần validate
                    update_option('checkin_use_google_login', '0');
                }
                break;

            case 'facebook':
                // Lưu trạng thái bật/tắt Facebook
                if (isset($_POST['checkin_use_facebook_login']) && $_POST['checkin_use_facebook_login'] === '1') {
                    $facebook_app_id     = isset($_POST['checkin_facebook_app_id']) ? sanitize_text_field($_POST['checkin_facebook_app_id']) : '';
                    $facebook_app_secret = isset($_POST['checkin_facebook_app_secret']) ? sanitize_text_field($_POST['checkin_facebook_app_secret']) : '';

                    // Validate Facebook App ID and Secret - just check not empty, format validation is done on client side
                    if (empty($facebook_app_id)) {
                        return new WP_Error('missing_facebook_app_id', __('Vui lòng nhập Facebook App ID', 'checkin-mkt192'));
                    }
                    if (empty($facebook_app_secret)) {
                        return new WP_Error('missing_facebook_app_secret', __('Vui lòng nhập Facebook App Secret', 'checkin-mkt192'));
                    }

                    // Test Facebook credentials validity by getting app access token
                    $test_result = $this->test_facebook_credentials($facebook_app_id, $facebook_app_secret);
                    if (is_wp_error($test_result)) {
                        return $test_result;
                    }

                    update_option('checkin_use_facebook_login', '1');
                    update_option('checkin_facebook_app_id', $facebook_app_id);
                    update_option('checkin_facebook_app_secret', $facebook_app_secret);
                } else {
                    // Khi tắt, chỉ cần lưu trạng thái tắt, không cần validate
                    update_option('checkin_use_facebook_login', '0');
                }
                break;

            default:
                return new WP_Error('invalid_connection_type', __('Loại kết nối không hợp lệ', 'checkin-mkt192'));
        }

        return true;
    }

    /**
     * Test Google Client ID validity
     * Uses Google's tokeninfo endpoint to verify the client ID format and availability
     */
    private function test_google_credentials($client_id) {
        // Basic format validation
        if (!preg_match('/^[0-9]{12}-[a-z0-9]{32}\.apps\.googleusercontent\.com$/', $client_id)) {
            return new WP_Error('invalid_google_client_id', __('Google Client ID không đúng định dạng. Phải có dạng: 123456789012-abc...xyz.apps.googleusercontent.com (12 số, dấu gạch ngang, 32 ký tự chữ thường/số)', 'checkin-mkt192'));
        }

        // Try to verify the Client ID by checking Google's OpenID configuration
        // This ensures the Client ID format matches Google's actual structure
        $discovery_url      = 'https://accounts.google.com/.well-known/openid-configuration';
        $discovery_response = wp_remote_get($discovery_url, [
            'timeout'   => 10,
            'sslverify' => true
        ]);

        if (is_wp_error($discovery_response)) {
            return new WP_Error('google_connection_failed', __('Không thể kết nối đến Google để xác thực. Vui lòng kiểm tra kết nối internet.', 'checkin-mkt192'));
        }

        $discovery_code = wp_remote_retrieve_response_code($discovery_response);
        if ($discovery_code !== 200) {
            return new WP_Error('google_api_error', __('Google API không phản hồi. Vui lòng thử lại sau.', 'checkin-mkt192'));
        }

        $discovery_body = wp_remote_retrieve_body($discovery_response);
        $discovery_data = json_decode($discovery_body, true);

        if (!$discovery_data || !isset($discovery_data['authorization_endpoint'])) {
            return new WP_Error('google_api_error', __('Không thể xác thực với Google. Vui lòng thử lại sau.', 'checkin-mkt192'));
        }

        // The Client ID format is now strictly validated
        // Real validation would require Client Secret to get access token,
        // but we enforce strict format to minimize invalid IDs

        // Additional check: verify Google API is working
        $discovery_response = wp_remote_get('https://accounts.google.com/.well-known/openid-configuration', [
            'timeout'   => 10,
            'sslverify' => true
        ]);

        if (is_wp_error($discovery_response)) {
            return new WP_Error('google_api_error', __('Không thể xác thực với Google API. Vui lòng thử lại sau.', 'checkin-mkt192'));
        }

        $discovery_code = wp_remote_retrieve_response_code($discovery_response);
        if ($discovery_code !== 200) {
            return new WP_Error('google_api_error', __('Google API không phản hồi. Vui lòng thử lại sau.', 'checkin-mkt192'));
        }

        // Client ID is valid and registered with Google
        return true;
    }

    /**
     * Test Facebook App credentials validity
     * Uses Facebook's Graph API to get app access token
     */
    private function test_zalo_oa_credentials($app_id, $secret_key) {
        // Basic format validation
        if (!is_numeric($app_id) || strlen($app_id) < 15) {
            return new WP_Error('invalid_zalo_app_id', __('Zalo OA App ID không đúng định dạng. Phải là dãy số dài tối thiểu 15 ký tự.', 'checkin-mkt192'));
        }

        if (strlen($secret_key) < 20) {
            return new WP_Error('invalid_zalo_secret_key', __('Zalo OA Secret Key không hợp lệ. Phải có ít nhất 20 ký tự.', 'checkin-mkt192'));
        }

        // Try to get access token from Zalo OA API
        // Endpoint: https://oauth.zaloapp.com/v4/oa/access_token
        $token_url = 'https://oauth.zaloapp.com/v4/oa/access_token';
        $response  = wp_remote_post($token_url, [
            'timeout' => 15,
            'headers' => [
                'Content-Type' => 'application/x-www-form-urlencoded',
                'secret_key'   => $secret_key
            ],
            'body' => [
                'app_id'        => $app_id,
                'grant_type'    => 'refresh_token',
                'refresh_token' => 'test' // Just testing credentials format
            ]
        ]);

        if (is_wp_error($response)) {
            return new WP_Error('zalo_connection_failed', __('Không thể kết nối đến Zalo API. Vui lòng kiểm tra kết nối internet.', 'checkin-mkt192'));
        }

        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        $data          = json_decode($response_body, true);

        // Check if response indicates invalid credentials
        // Zalo returns error codes: -124 (invalid app_id), -14009 (invalid secret_key)
        if (isset($data['error']) && in_array($data['error'], [-124, -14009])) {
            return new WP_Error('invalid_zalo_credentials', __('Zalo OA App ID hoặc Secret Key không hợp lệ. Vui lòng kiểm tra lại từ Zalo Developer Portal.', 'checkin-mkt192'));
        }

        // If we get here, credentials format is valid (even if refresh_token is invalid)
        // Real validation would require actual refresh_token, but we verify credentials structure
        return true;
    }

    private function test_facebook_credentials($app_id, $app_secret) {
        // Try to get app access token from Facebook
        $url = sprintf(
            'https://graph.facebook.com/oauth/access_token?client_id=%s&client_secret=%s&grant_type=client_credentials',
            urlencode($app_id),
            urlencode($app_secret)
        );

        $response = wp_remote_get($url, [
            'timeout'   => 15,
            'sslverify' => true
        ]);

        if (is_wp_error($response)) {
            return new WP_Error('facebook_connection_failed', __('Không thể kết nối đến Facebook để xác thực. Vui lòng kiểm tra kết nối internet.', 'checkin-mkt192'));
        }

        $response_code = wp_remote_retrieve_response_code($response);
        $body          = wp_remote_retrieve_body($response);
        $data          = json_decode($body, true);

        // Check for errors in response
        if ($response_code !== 200 || isset($data['error'])) {
            $error_message = isset($data['error']['message']) ? $data['error']['message'] : __('Credentials không hợp lệ', 'checkin-mkt192');
            return new WP_Error('facebook_invalid_credentials', sprintf(
                __('Facebook App ID hoặc App Secret không hợp lệ: %s', 'checkin-mkt192'),
                $error_message
            ));
        }

        // Check if we got an access token
        if (!isset($data['access_token'])) {
            return new WP_Error('facebook_no_token', __('Không thể lấy access token từ Facebook. Vui lòng kiểm tra lại App ID và App Secret.', 'checkin-mkt192'));
        }

        // Credentials are valid
        return true;
    }

    /**
     * Test OneSignal API credentials validity
     * Uses OneSignal's apps endpoint to verify credentials
     */
    private function test_onesignal_credentials($app_id, $api_key) {
        // Test by getting app info from OneSignal
        $response = wp_remote_get('https://onesignal.com/api/v1/apps/' . $app_id, [
            'timeout'   => 10,
            'sslverify' => true,
            'headers'   => [
                'Authorization' => 'Basic ' . $api_key,
            ],
        ]);

        if (is_wp_error($response)) {
            return new WP_Error('onesignal_connection_failed', sprintf(
                __('Không thể kết nối đến OneSignal: %s', 'checkin-mkt192'),
                $response->get_error_message()
            ));
        }

        $http_code = wp_remote_retrieve_response_code($response);
        $body      = json_decode(wp_remote_retrieve_body($response), true);

        if ($http_code === 401) {
            return new WP_Error('onesignal_invalid_api_key', __('REST API Key không hợp lệ. Vui lòng kiểm tra lại.', 'checkin-mkt192'));
        }

        if ($http_code === 404) {
            return new WP_Error('onesignal_invalid_app_id', __('App ID không tồn tại trên OneSignal.', 'checkin-mkt192'));
        }

        if ($http_code !== 200) {
            $error_message = isset($body['errors'][0]) ? $body['errors'][0] : __('Lỗi không xác định', 'checkin-mkt192');
            return new WP_Error('onesignal_error', sprintf(
                __('OneSignal trả về lỗi: %s', 'checkin-mkt192'),
                $error_message
            ));
        }

        // Credentials are valid
        return true;
    }

    /**
     * Clear connection data when validation fails
     */
    public function ajax_clear_connection_data() {
        check_ajax_referer('checkin_connections', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Bạn không có quyền thực hiện hành động này!', 'checkin-mkt192')]);
        }

        $connection_type = isset($_POST['connection_type']) ? sanitize_text_field($_POST['connection_type']) : '';

        switch ($connection_type) {
            case 'google':
                update_option('checkin_use_google_login', '0');
                update_option('checkin_google_client_id', '');
                break;

            case 'facebook':
                update_option('checkin_use_facebook_login', '0');
                update_option('checkin_facebook_app_id', '');
                update_option('checkin_facebook_app_secret', '');
                break;

            case 'zalo':
                update_option('checkin_use_zalo_oa', '0');
                update_option('checkin_zalo_oa_app_id', '');
                update_option('checkin_zalo_oa_secret_key', '');
                update_option('checkin_use_zalo_user', '0');
                update_option('checkin_zalo_user_domain', '');
                break;

            case 'lark':
                update_option('checkin_use_lark', '0');
                break;

            default:
                wp_send_json_error(['message' => __('Loại kết nối không hợp lệ', 'checkin-mkt192')]);
                return;
        }

        wp_send_json_success(['message' => __('Đã xóa dữ liệu kết nối', 'checkin-mkt192')]);
    }
}
?>
