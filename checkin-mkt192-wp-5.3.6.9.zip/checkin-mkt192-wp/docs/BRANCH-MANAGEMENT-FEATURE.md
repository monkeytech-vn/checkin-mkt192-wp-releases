# Chi Nhánh Management Feature - Implementation Summary

## Tổng quan

Đã hoàn thành việc thêm tính năng quản lý chi nhánh nâng cao vào trang Branch Settings với toggle switch để bật/tắt chế độ chi nhánh.

## Các thay đổi đã thực hiện

### 1. Database Schema Updates

**File**: `includes/class-checkin-mkt192-activation.php`

Đã thêm các cột mới vào bảng `wp_checkin_mkt192_locations`:

- `address` (TEXT) - Địa chỉ chi nhánh
- `google_map_link` (TEXT) - Link Google Maps
- `is_main_branch` (TINYINT) - Đánh dấu chi nhánh chính

**Migration Method**: `add_branch_management_fields()`

- Tự động kiểm tra và thêm các cột nếu chưa tồn tại
- Chạy tự động khi plugin được load (`wp_loaded` hook)
- Log tất cả các thay đổi vào WordPress error log

### 2. Frontend UI Updates

**File**: `frontend/pages/admin-setting-frontend.html`

#### Thêm Toggle Switch:

```html
<div class="form-group">
  <label>Chi nhánh</label>
  <label class="switch">
    <input type="checkbox" id="branch-mode-toggle" onchange="toggleBranchMode()" />
    <span class="slider"></span>
  </label>
  <span class="toggle-label" id="branch-mode-label">Tắt</span>
</div>
```

#### Chế độ TẮT (mặc định):

- Hiển thị input "Địa chỉ" (readonly)
- Ẩn toàn bộ phần quản lý chi nhánh

#### Chế độ BẬT:

- Ẩn input địa chỉ chung
- Hiển thị section quản lý chi nhánh với các trường:
  1. **Tên chi nhánh** - Tên để hiển thị
  2. **Địa chỉ** - Địa chỉ cụ thể của chi nhánh
  3. **Link Google Map** - URL đến Google Maps
  4. **Vĩ độ (Latitude)** - Tọa độ vĩ độ
  5. **Kinh độ (Longitude)** - Tọa độ kinh độ
  6. **Khoảng cách cho phép** - Bán kính check-in (50m-1000m)
  7. **Checkbox "Chi nhánh chính"** - Đánh dấu chi nhánh chính

### 3. JavaScript Functions

**File**: `frontend/assets/js/pages/admin-setting-frontend.js`

#### Hàm mới:

1. **`toggleBranchMode()`**

   - Xử lý logic khi toggle switch thay đổi
   - Hiển thị/ẩn các section tương ứng
   - Cập nhật label "Bật"/"Tắt"

2. **`updateLocationFields()` (đã cập nhật)**

   - Load tất cả thông tin chi nhánh khi chọn từ dropdown
   - Populate các trường: name, address, map link, lat, long, radius, is_main_branch

3. **`saveLocation()` (đã cập nhật)**

   - Validate tất cả các trường bắt buộc
   - Gửi dữ liệu đầy đủ lên API
   - Bao gồm: location_name, address, google_map_link, latitude, longitude, radius, is_main_branch

4. **`deleteLocation()` (đã cập nhật)**
   - Clear tất cả các trường sau khi xóa
   - Reset form về trạng thái ban đầu

### 4. Backend API Updates

**File**: `includes/rest-api/location-api.php`

#### `checkin_mkt192_get_all_locations_api()`:

- Thêm các cột mới vào SELECT query
- Sắp xếp: chi nhánh chính lên đầu, sau đó theo tên

#### `checkin_mkt192_get_location_by_id()`:

- Trả về đầy đủ thông tin chi nhánh bao gồm các trường mới

#### `checkin_mkt192_update_location_api()`:

- Nhận và validate các trường mới
- Logic đặc biệt: khi đánh dấu chi nhánh chính, tự động bỏ đánh dấu các chi nhánh khác
- Cập nhật tất cả các trường: location_name, address, google_map_link, latitude, longitude, radius, is_main_branch

**File**: `includes/rest-api/branch-api.php`

#### `checkin_mkt192_get_all_branches_api()`:

- Cập nhật để trả về các trường mới
- Sắp xếp chi nhánh chính lên đầu

### 5. CSS Styling

**File**: `frontend/assets/css/pages/admin-setting-frontend.css`

Thêm styles:

```css
.toggle-label
  -
  Label
  hiển
  thị
  trạng
  thái
  Bật/Tắt
  #branch-management-section
  -
  Container
  cho
  phần
  quản
  lý
  chi
  nhánh
  #common-address-group
  -
  Container
  cho
  địa
  chỉ
  chung;
```

### 6. Plugin Activation Hooks

**File**: `checkin-mkt192-wp.php`

Đã thêm:

```php
register_activation_hook(__FILE__, ['Checkin_MKT192_Activation', 'add_branch_management_fields']);
add_action('wp_loaded', ['Checkin_MKT192_Activation', 'add_branch_management_fields'], 11);
```

## Cách sử dụng

### Cho Admin:

1. Truy cập trang **Admin Settings** > **Vị trí điểm danh**
2. Mặc định toggle ở chế độ TẮT - hiển thị địa chỉ chung (readonly)
3. Bật toggle "Chi nhánh" để:
   - Hiển thị nút "Thêm chi nhánh"
   - Thêm chi nhánh mới bằng cách nhập tên và click "Thêm chi nhánh"
   - Chọn chi nhánh từ dropdown để chỉnh sửa
   - Điền đầy đủ thông tin: tên, địa chỉ, link map, tọa độ, bán kính
   - Tick checkbox "Chi nhánh chính" nếu là chi nhánh chính
   - Click "Lưu vị trí" để save
   - Click "Xóa" để xóa chi nhánh đã chọn

### Đặc điểm quan trọng:

- Chỉ có thể có 1 chi nhánh chính tại một thời điểm
- Khi đánh dấu chi nhánh mới là "chính", các chi nhánh khác sẽ tự động bỏ đánh dấu
- Chi nhánh chính luôn hiển thị đầu tiên trong danh sách
- Các trường bắt buộc: tên, địa chỉ, vĩ độ, kinh độ, bán kính

## Migration & Backward Compatibility

### Tự động migration:

- Database schema sẽ tự động update khi plugin được load
- Không cần thao tác thủ công
- An toàn cho dữ liệu hiện có
- Log tất cả thay đổi vào error log

### Backward compatibility:

- Code cũ vẫn hoạt động bình thường
- Các API endpoint hiện có được mở rộng, không phá vỡ
- Nếu không bật toggle, giao diện hoạt động như cũ

## Testing Checklist

✅ Database migration chạy thành công
✅ Toggle switch hoạt động đúng (bật/tắt)
✅ Thêm chi nhánh mới
✅ Load thông tin chi nhánh khi chọn
✅ Cập nhật thông tin chi nhánh
✅ Xóa chi nhánh
✅ Checkbox chi nhánh chính hoạt động
✅ API endpoints trả về dữ liệu đầy đủ
✅ Validation form đúng
✅ UI/UX mượt mà

## Files Modified

1. `includes/class-checkin-mkt192-activation.php` - Database schema
2. `checkin-mkt192-wp.php` - Activation hooks
3. `frontend/pages/admin-setting-frontend.html` - UI/HTML
4. `frontend/assets/js/pages/admin-setting-frontend.js` - JavaScript logic
5. `frontend/assets/css/pages/admin-setting-frontend.css` - Styling
6. `includes/rest-api/location-api.php` - Location API endpoints
7. `includes/rest-api/branch-api.php` - Branch API endpoints

## Migration Files Created

1. `migrations/add-branch-fields.sql` - SQL script (tham khảo)
2. `migrations/run-branch-migration.php` - PHP migration script (backup, không cần thiết vì có auto-migration)

## Notes

- Toggle switch sử dụng cùng thiết kế với trang Connection Settings (reuse CSS)
- Tất cả API calls đều có error handling và user feedback (toast messages)
- Code tuân thủ WordPress coding standards
- Tương thích với cả desktop và mobile
- Logging đầy đủ để debug

## Version

Feature hoàn thành: **2025-11-23**
Plugin version compatibility: **5.1.1.9.9.6+**
