# Hoa hồng theo kỳ lương (thay cho hoa hồng theo cấp bậc) — bản thiết kế chờ chốt

> Trạng thái: **bước 1–5 đã code** (5.3.4.7 + 5.3.4.8). Kent trả lời §5 ngày 10/09/2026 — xem §7. SaaS MonkeySalon nhận bản mô tả qua hộp thư leader.
> Viết 2026-09-08 sau khi Kent mô tả yêu cầu của chủ site VG; Kent bảo "tiếp tục các phần khác" nên chọn phương án và ghi rõ.

## 1. Vấn đề

- Hoa hồng hiện lấy từ `salary_level_settings` theo **tên bậc** (`Cao cấp 1 (C40_15)`…). Chủ shop muốn
  chỉnh lẻ 5% cho từng thợ, từng tháng → phải tạo bậc mới liên tục, tên bậc thành mã hoá (`40-5`, `40-25`).
- KPI (feedback Google Maps, đăng bài FB, bán ≥ N sản phẩm) hiện chỉ ảnh hưởng **thưởng sản phẩm**;
  chủ site muốn **không đạt KPI thì trừ % hoa hồng dịch vụ/hoá chất**, mức trừ cấu hình được.
- Mọi luật thưởng/phạt phải do owner/admin cấu hình trên site, không hard-code (10% sản phẩm, 10% tăng ca…).

## 2. Mô hình đề xuất

### 2.1 Bảng `checkin_mkt192_salary_period_rates` — "thẻ hoa hồng" của một thợ trong một kỳ

| Cột | Kiểu | Ý nghĩa |
|---|---|---|
| `id` | bigint PK | |
| `staff_name` | varchar(191) | Thợ (theo `display_name`, giống các bảng lương hiện có) |
| `period` | char(7) | `YYYY-MM` |
| `service_percent` | decimal(5,2) | % hoa hồng dịch vụ cắt |
| `chemical_percent` | decimal(5,2) | % hoa hồng hoá chất |
| `product_percent` | decimal(5,2) | % hoa hồng bán sản phẩm (mặc định 10) |
| `product_min_qty` | int | Bán từ N sản phẩm mới được hưởng (mặc định 3 theo yêu cầu chủ site; hiện tại là 1) |
| `overtime_percent` | decimal(5,2) | % tăng ca (mặc định 10) |
| `kpi_penalty_percent` | decimal(5,2) | Trừ bao nhiêu điểm % nếu không đạt KPI (mặc định 5) |
| `kpi_penalty_scope` | enum('service','chemical','both') | Trừ trên dịch vụ, hoá chất hay cả hai |
| `kpi_required` | set('feedback','post_fb','service','product') | KPI nào bắt buộc; thiếu **một** trong số đó là bị trừ |
| `note` | varchar(255) | Ghi chú của admin ("tăng HC +5% vì tháng 9 đẩy nhuộm") |
| `source` | enum('manual','carried','level') | Ai tạo: admin nhập / kế thừa kỳ trước / sinh từ bậc |
| `updated_by`, `updated_at` | | |
| UNIQUE (`staff_name`, `period`) | | |

### 2.2 Cách tìm thẻ hoa hồng hiệu lực cho (thợ, kỳ) — `resolve_rates()`

1. Có dòng `period_rates` đúng kỳ → dùng.
2. Không có → lấy dòng **kỳ gần nhất trước đó** của thợ (kế thừa: "T9 không đổi thì giữ 40-20").
   Khi tính lương lần đầu cho kỳ mới, **ghi một bản sao** với `source='carried'` để lịch sử đóng băng
   (kỳ sau sửa không làm đổi kỳ đã trả).
3. Vẫn không có (thợ mới, site chưa từng dùng thẻ) → sinh từ `salary_level_settings` của bậc đang active,
   `source='level'`. Bậc **không bị bỏ** — chỉ còn là "mẫu khởi tạo" + tiêu chí thăng bậc.

### 2.3 Công thức lương thợ (thay đoạn `$service_salary = …` trong `update_hairdresser_salary`)

```
rate           = resolve_rates(staff, period)
kpi            = kpi_results(staff, period) nếu is_evaluated = 1, ngược lại null
kpi_failed     = kpi != null && có KPI trong rate.kpi_required mà *_achieved = 0
penalty_pts    = kpi_failed ? rate.kpi_penalty_percent : 0
svc_pct        = max(0, rate.service_percent  - (scope ∈ {service,both}  ? penalty_pts : 0))
chem_pct       = max(0, rate.chemical_percent - (scope ∈ {chemical,both} ? penalty_pts : 0))
service_salary = (service_total  - penalty_service)  * svc_pct  / 100
chemical_salary= (chemical_total - penalty_chemical) * chem_pct / 100
product_salary = product_count >= rate.product_min_qty ? product_total * rate.product_percent / 100 : 0
overtime_salary= overtime_total * rate.overtime_percent / 100
```

Phiếu lương hiện dòng giải thích: `Dịch vụ · 27.930.000 đ × 40% (45% − 5% KPI feedback)`.
Bảng `hairdresser_salary` thêm cột `rates_json` (ảnh chụp thẻ + KPI đã áp) để phiếu cũ không đổi khi
cài đặt đổi — việc suy ngược % từ tiền/doanh số (bản 5.3.4.7) chỉ là tạm.

### 2.4 Truy thu tự động khi khách đánh giá ≤ 3 sao

Đã có `penalty_service`/`penalty_chemical` tính theo hoá đơn. Cần: khi review ≤ 3★ gắn được với
`invoice_id`, tự đánh dấu hoá đơn `penalty=1` + lý do; tính lương gom vào `penalty_*` như hiện nay.
Cần chốt: truy thu **toàn bộ** hoá đơn hay theo % (§5 câu 5).

## 3. Giao diện admin

- Tab **Lương Nhân Viên → Thợ**: thêm cột "Hoa hồng kỳ này" (`45 · 15 · SP 10%/≥3`), bấm mở modal
  **Thẻ hoa hồng tháng MM/YYYY**: 4 ô % + ngưỡng sản phẩm + khối KPI (bắt buộc KPI nào, trừ mấy %, trên
  mục nào) + ghi chú. Nút "Sao chép sang kỳ sau" và "Áp cho tất cả thợ" (bulk).
- Kỳ đã chốt (thợ Đồng ý / đã thanh toán) → modal chỉ đọc, muốn sửa phải "Mở lại phiếu".
- Trang **Cài đặt cấp bậc** giữ nguyên, thêm ghi chú: bậc chỉ dùng để khởi tạo thẻ hoa hồng.

## 4. Lộ trình

| Bước | Việc | Ước lượng |
|---|---|---|
| 1 | Bảng + dbDelta + `resolve_rates()` + fallback bậc (không đổi kết quả lương hiện tại) | 0.5 ngày |
| 2 | Sửa công thức tính lương + `rates_json` + phiếu lương hiện % đã áp và lý do trừ | 0.5 ngày |
| 3 | API GET/PUT `salary-period-rates` (scope `salary.calculate`) + modal admin + bulk | 1 ngày |
| 4 | KPI phạt hoa hồng (dùng `kpi_results` sẵn có) + ngưỡng sản phẩm | 0.5 ngày |
| 5 | Truy thu tự động theo review ≤ 3★ | 0.5 ngày (sau khi chốt §5.5) |
| 6 | Test trên Docker WP với dữ liệu seed, rồi VG | 0.5 ngày |

## 5. Câu hỏi phải chốt trước khi code

1. **Phạm vi**: làm trên plugin WordPress hiện tại (VG dùng ngay) hay để dành cho bản SaaS mới? Hay cả hai
   (plugin làm trước, SaaS port lại)?
2. **Thẻ hoa hồng theo thợ** (mỗi thợ một thẻ mỗi kỳ, kế thừa kỳ trước) — đúng ý chủ site? Hay có thêm
   "thẻ mặc định toàn salon" để thợ mới tự nhận?
3. **KPI nào bắt buộc** và trừ **một lần 5%** dù trượt cả 2 KPI, hay **cộng dồn** (trượt 2 = −10%)?
4. **Ngưỡng sản phẩm ≥ 3**: đếm **số dòng hoá đơn sản phẩm** (như `product_count_total` hiện tại) hay
   **tổng số lượng** (một hoá đơn bán 3 chai = 3)?
5. **Truy thu review ≤ 3★**: truy thu 100% giá trị hoá đơn hay theo %, và có cần admin duyệt trước không?
6. Kỳ đã trả lương mà admin sửa thẻ hoa hồng: **cấm** hay **cho sửa + tự tính lại + báo thợ xác nhận lại**?

## 6. Giả định đã chọn khi code (Kent chưa trả lời §5 — sửa được, báo em)

| Câu | Đã chọn | Đổi ở đâu nếu muốn khác |
|---|---|---|
| 5.1 Phạm vi | Làm trên **plugin WP** (VG dùng ngay); SaaS port lại sau | — |
| 5.2 Thẻ theo thợ | **Mỗi thợ một thẻ/kỳ**, kế thừa kỳ trước; chưa có "thẻ mặc định salon" — dùng *Áp cho tất cả thợ* thay thế | `checkin_mkt192_resolve_period_rates()` |
| 5.3 Trượt nhiều KPI | **Trừ một lần** (không cộng dồn) | `checkin_mkt192_apply_period_rates()` |
| 5.4 Ngưỡng sản phẩm | Đếm **dòng hoá đơn sản phẩm** (`product_count_total`, như hiện tại) | chỗ tính `$product_count_total` trong `update_hairdresser_salary` |
| 5.5 Truy thu ≤ 3★ | **Chưa làm** | bước 5 |
| 5.6 Kỳ đã chốt | **Cấm sửa thẻ** (409); chưa có nút "Mở lại phiếu" cho admin | `checkin_mkt192_save_period_rates_api()` |
| Mặc định thẻ đầu tiên | DV/HC theo bậc, SP 10% từ 1 SP (giữ hành vi cũ, admin đổi thành 3), tăng ca 10%, KPI bắt buộc = đánh giá + đăng bài, trừ 5% trên dịch vụ | `checkin_mkt192_default_period_rates_from_level()` |

Điểm cần Kent để mắt: **thợ chưa có thẻ nào vẫn chạy theo bậc** → hai cơ chế song song cho tới khi admin tạo thẻ cho toàn bộ thợ (một lần *Áp cho tất cả thợ* là xong).

## 7. Kent chốt 10/09/2026 (thay các giả định ở §6)

| Câu | Kent chốt | Đã làm (5.3.4.8) |
|---|---|---|
| 5.1 | Plugin WP hiện tại; SaaS MonkeySalon nhận mô tả qua `~/monkeysalon-team/hop-thu/leader.md` | ✅ |
| 5.2 | Thẻ theo thợ, kế thừa kỳ trước — đúng | ✅ |
| 5.3 | Thêm lựa chọn cho admin; **mặc định trượt cả 2 KPI vẫn trừ 5% một lần trên DV cắt** | ✅ `kpi_penalty_mode` once/each |
| 5.4 | Ngưỡng tính theo **số sản phẩm** (một dòng 3 chai = 3) | ✅ `product_count_total` = Σ quantity |
| 5.5 | Admin **bật/tắt**, chọn **% giá trị hoá đơn** hay **phạt số tiền** | ✅ option `checkin_mkt192_review_penalty`, phiếu trừ tự động `source=review` |
| 5.6 | Kỳ đã trả lương **không sửa**; thay đổi chỉ áp kỳ sau | ✅ 409 + nút *Mở thẻ kỳ sau* |
| 5.7 (mới) | **Phiếu thưởng / phiếu trừ** có lý do (thưởng nóng, thưởng lễ, đồng phục đơn giá × số lượng, phạt…) | ✅ bảng `salary_adjustments`, modal *Thưởng / Trừ*, cộng vào Tổng lương / Tổng trừ |

Còn để ngỏ: "thẻ mặc định toàn salon" (thợ mới tự nhận) — hiện dùng *Áp cho tất cả thợ*; nút *Mở lại phiếu* cho admin khi cần sửa kỳ đã chốt.

## 8. Bản 5.3.5.0 (10/09/2026) — hạng Barber, cài đặt lương, hồ sơ

- **Hạng ≠ hoa hồng.** `staff_level_history.level_name` giờ chỉ nhận 4 hạng (`checkin_mkt192_barber_tiers()`); `salary_level_settings`
  rows role Thợ = 4 hạng với % **tham chiếu** (chỉ dùng khi thợ không có thẻ nào). Migration `checkin_mkt192_migrate_barber_tiers()`
  chạy một lần khi db < 8.5.0, idempotent qua option `checkin_mkt192_barber_tiers_migrated`.
- **Quy tắc gom:** theo % dịch vụ của bậc cũ: 0 → Thử Việc, < 40 → Chính Thức, ≥ 40 → Chuyên Nghiệp; danh sách Master qua filter
  `checkin_mkt192_barber_master_staff` (mặc định `['Vũ Phương']`, chỉ áp cho dòng active/mới nhất — các dòng cũ của Vũ Phương vẫn theo %).
- **Cài đặt lương** (`checkin_mkt192_salary_settings`): `staff_view` always|after_day (+`staff_view_day`), `review_penalty`,
  `card_defaults`, `kpi_changes_level` (mặc định false). `pay_period` cố định `month` — theo tuần cần đổi khoá kỳ `YYYY-MM` ở mọi bảng,
  chưa làm.
- **Hồ sơ** `GET /staff-profile`: `level_history` gộp dòng liên tiếp cùng hạng; `commission_history` sinh từ `salary_period_rates`
  (chỉ ghi kỳ có thay đổi so với kỳ trước, kèm `changes[]`, `updated_by`).
- **Còn để ngỏ:** kỳ lương theo tuần; nút *Mở lại phiếu* đã chốt; thẻ mặc định toàn salon cho thợ mới; xoá hẳn cột `uniform_fee`
  (giữ hiển thị legacy, nhập mới dùng phiếu trừ *Đồng phục*).

## 9. Bản 5.3.5.x–5.3.6.0 (10/09/2026) — truy thu tự động, KPI, sửa dữ liệu

- **Truy thu tự động** `checkin_mkt192_sync_auto_penalties()` chạy đầu mỗi lần tính lương thợ (trước khi cộng doanh số):
  gỡ dấu cũ của chính nó (marker `salary_adjustments.kind='marker'`, source `review|no_image`) → gom hoá đơn vi phạm → áp theo mode.
  Mode `commission` = `UPDATE invoices_data_detail SET is_penalty=1` chỉ trên dòng `is_penalty=0` (không nhận sở hữu hoá đơn admin truy thu tay).
  Cài đặt ở `salary_settings.review_penalty` / `.no_image_penalty` (mặc định **tắt**). Khách vãng lai: `customer_name = 'Khách vãng lai'`
  hoặc lý do not_image có "Khách vãng lai".
- **KPI**: `kpi_results` thêm `service_actual, product_actual, post_fb_actual, post_fb_required, feedback_actual, manual_json`.
  Ghi đè tay áp sau khi tính tự động; `kpi_result_view()` chuẩn hoá cho UI; `hairdresser-salary-data` trả `kpi`.
- **% bậc cũ cho kỳ không có thẻ**: `legacy_level_name` → bảng bậc cũ hoặc parse mã (`C45_20`, `(45-15)`, `P0_40`).
  Bài học VG 10/09: kỳ 08/2026 bị tính theo % hạng mới, phải tính lại 5 phiếu chưa chốt.
- **Đồng phục** (`uniform_fee` legacy) nay cộng vào Tổng trừ khi tính lại; Xuân Tiến 08/2026 (đã chốt) còn lệch 274.000 chờ Kent quyết.
- **Migration không được dựa vào `function_exists` + version**: OPcache có thể còn file cũ vài giây sau deploy ghi file lẻ → cờ riêng, idempotent.

## 10. Bản 5.3.6.2 (10/09/2026) — KPI Google Maps, KPI FB theo ngày công, bỏ kiểu truy thu hoa hồng

- **Bài học đếm Google Maps**: JOIN `invoices_data` ↔ `invoices_data_detail` theo `invoice_id` trả rỗng trên VG dù REST
  `staff-invoices` cho thấy Hoàng Huy 08/2026 có 30 hoá đơn `image_feedback` (bảng tạo khác thời điểm → khả năng lệch collation,
  `get_var` trả null → `(int)` = 0). Không có quyền SQL trên VG để xác nhận collation; **fix an toàn là đếm 2 bước**
  (`checkin_mkt192_staff_period_invoice_ids()` → `IN (...)` trên `invoices_data`), dùng chung cho `kpi_actuals()` và `evaluate`.
  Đối soát nhanh: `GET /kpi-result?staff_name&period&live=1` (admin) trả `live` tính tại chỗ.
- **Autocompute đánh giá KPI trước khi tính lương** (kỳ chưa chốt, kỳ hiện tại + kỳ trước, throttle 2 phút/thợ): KPI trên phiếu
  luôn theo dữ liệu mới; đây cũng là cách VG tự sửa các bản ghi KPI 08/2026 đếm sai.
- **KPI Đăng bài FB**: `kpi_settings.post_fb_mode` = `workdays` (mục tiêu = N bài/ngày công → phải đạt = N × ngày công thực tế)
  | `count` (số bài cố định). `checkin_mkt192_post_fb_required($mode, $kpi, $days)`. `kpi_results` lưu `post_fb_mode`, `working_days`;
  bản ghi cũ không mode + `required ≠ kpi` → UI coi là `legacy` (KPI/tháng quy theo ngày công/30).
  Migration một lần (cờ `checkin_mkt192_kpi_postfb_workdays_migrated`, guard `post_fb_mode='count'`): kpi>0 → `workdays`, kpi = max(1, round(kpi/30)).
- **Truy thu**: chỉ `percent` | `fixed`. `commission` cũ → `percent` mức 0; API lưu từ chối bật khi mức ≤ 0. Bước 1 của
  `sync_auto_penalties()` vẫn gỡ marker cũ nếu còn.

## 11. Bản 5.3.6.3–5.3.6.8 (10/09/2026) — luật cứng rút ra

- **KHÔNG JOIN `invoices_data` với bảng khác theo `invoice_id` trên VG** (detail, reviews): trả rỗng, không báo lỗi. Luôn 2 bước:
  lấy mã hoá đơn (`checkin_mkt192_staff_period_invoice_ids`) → `WHERE invoice_id IN (...)`. Đã dính 2 lần (KPI Google Maps, truy thu tự động).
- KPI chỉ áp vào lương khi kỳ đã hết (`checkin_mkt192_kpi_applies`); kỳ đang chạy chỉ hiện tiến trình.
- Truy thu % = `salary_adjustments.kind='base_penalty'` (category service|chemical) trừ vào doanh số trước khi nhân hoa hồng;
  100% = bỏ hẳn hoá đơn, sản phẩm vẫn tính. Admin *Bỏ qua* → marker `category='ignored'` (sync chừa ref_id đó), *Khôi phục* = xoá marker.
- Trang admin-setting: `handleFormSubmission()` phải gắn ngay khi DOM sẵn sàng; nút trong form cần `type="button"`.
- `FB.login` phải gọi đồng bộ trong handler click; không dùng `auth_type: 'reauthenticate'` cho đồng bộ bài đăng.

