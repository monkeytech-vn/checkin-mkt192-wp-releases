/**
 * Test case để verify logic tính ngày hết hạn mã thành viên
 * Fix: Đồng bộ logic giữa PHP (customer-api.php) và JS (app-tho.js)
 */

// ===== TEST SCENARIOS =====

// Scenario 1: Đăng ký ngày 1/1, check ngày 30/1 (29 ngày)
// Expected: Có hiệu lực
const test1_checkin = new Date('2024-01-01');
const test1_today = new Date('2024-01-30');
const test1_days = Math.floor((test1_today - test1_checkin) / (1000 * 60 * 60 * 24));
console.log('Test 1:', test1_days, 'days →', test1_days <= 30 ? '✅ Có hiệu lực' : '❌ Hết hạn');

// Scenario 2: Đăng ký ngày 1/1, check ngày 31/1 (30 ngày đúng)
// Expected: Có hiệu lực
const test2_checkin = new Date('2024-01-01');
const test2_today = new Date('2024-01-31');
const test2_days = Math.floor((test2_today - test2_checkin) / (1000 * 60 * 60 * 24));
console.log('Test 2:', test2_days, 'days →', test2_days <= 30 ? '✅ Có hiệu lực' : '❌ Hết hạn');

// Scenario 3: Đăng ký ngày 1/1, check ngày 1/2 (31 ngày)
// Expected: Hết hạn
const test3_checkin = new Date('2024-01-01');
const test3_today = new Date('2024-02-01');
const test3_days = Math.floor((test3_today - test3_checkin) / (1000 * 60 * 60 * 24));
console.log('Test 3:', test3_days, 'days →', test3_days <= 30 ? '❌ Có hiệu lực' : '✅ Hết hạn');

// Scenario 4: Đăng ký ngày 1/3, check ngày 31/3 (30 ngày - tháng 31 ngày)
// Expected: Có hiệu lực
const test4_checkin = new Date('2024-03-01');
const test4_today = new Date('2024-03-31');
const test4_days = Math.floor((test4_today - test4_checkin) / (1000 * 60 * 60 * 24));
console.log('Test 4:', test4_days, 'days →', test4_days <= 30 ? '✅ Có hiệu lực' : '❌ Hết hạn');

// Scenario 5: Đăng ký ngày 1/3, check ngày 1/4 (31 ngày)
// Expected: Hết hạn
const test5_checkin = new Date('2024-03-01');
const test5_today = new Date('2024-04-01');
const test5_days = Math.floor((test5_today - test5_checkin) / (1000 * 60 * 60 * 24));
console.log('Test 5:', test5_days, 'days →', test5_days <= 30 ? '❌ Có hiệu lực' : '✅ Hết hạn');

// Scenario 6: Đăng ký ngày 15/2, check ngày 16/3 (30 ngày - tháng 2 năm nhuận)
// Expected: Có hiệu lực
const test6_checkin = new Date('2024-02-15');
const test6_today = new Date('2024-03-16');
const test6_days = Math.floor((test6_today - test6_checkin) / (1000 * 60 * 60 * 24));
console.log('Test 6:', test6_days, 'days →', test6_days <= 30 ? '✅ Có hiệu lực' : '❌ Hết hạn');

// ===== PHP EQUIVALENT =====
/*
<?php
// Test 1: 29 days
$checkin = strtotime('2024-01-01');
$today = strtotime('2024-01-30');
$days = floor(($today - $checkin) / (60 * 60 * 24));
echo "Test 1: $days days → " . ($days <= 30 ? '✅ Có hiệu lực' : '❌ Hết hạn') . "\n";

// Test 2: 30 days (edge case)
$checkin = strtotime('2024-01-01');
$today = strtotime('2024-01-31');
$days = floor(($today - $checkin) / (60 * 60 * 24));
echo "Test 2: $days days → " . ($days <= 30 ? '✅ Có hiệu lực' : '❌ Hết hạn') . "\n";

// Test 3: 31 days (expired)
$checkin = strtotime('2024-01-01');
$today = strtotime('2024-02-01');
$days = floor(($today - $checkin) / (60 * 60 * 24));
echo "Test 3: $days days → " . ($days <= 30 ? '❌ Có hiệu lực' : '✅ Hết hạn') . "\n";
?>
*/

// ===== EXPECTED OUTPUT =====
/*
Test 1: 29 days → ✅ Có hiệu lực
Test 2: 30 days → ✅ Có hiệu lực
Test 3: 31 days → ✅ Hết hạn
Test 4: 30 days → ✅ Có hiệu lực
Test 5: 31 days → ✅ Hết hạn
Test 6: 30 days → ✅ Có hiệu lực
*/
