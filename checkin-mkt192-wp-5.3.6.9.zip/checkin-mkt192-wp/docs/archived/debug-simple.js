// 🔍 SIMPLE DEBUG - Just show raw response
// Run this in browser console first to see what we get

fetch('http://localhost:8080/wp-json/vg/v1/debug/current-user-permissions', {
  method: 'GET',
  credentials: 'include',
})
  .then((r) => {
    console.log('Status:', r.status, r.statusText);
    return r.text();
  })
  .then((text) => {
    console.log('Raw response:', text);
    try {
      const data = JSON.parse(text);
      console.log('Parsed JSON:', data);

      // Check what's in the response
      console.log('\nResponse structure:');
      console.log('- Has error?', !!data.error);
      console.log('- Has user?', !!data.user);
      console.log('- Has staff?', !!data.staff);
      console.log('- Has current_role?', !!data.current_role);
      console.log('- Has available_roles?', !!data.available_roles);

      if (data.error) {
        console.error('ERROR:', data.error);
        if (data.debug) console.log('Debug info:', data.debug);
        if (data.solution) console.log('Solution:', data.solution);
      }
    } catch (e) {
      console.error('Failed to parse JSON:', e);
    }
  })
  .catch((err) => {
    console.error('Fetch failed:', err);
  });
