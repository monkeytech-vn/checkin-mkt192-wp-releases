// 🔧 DEBUG USER PERMISSIONS - Safe Version with Error Handling
// Copy & paste this into browser console on WordPress admin page

fetch('http://localhost:8080/wp-json/vg/v1/debug/current-user-permissions', {
  method: 'GET',
  credentials: 'include',
})
  .then((response) => {
    console.log('Response status:', response.status);
    return response.json();
  })
  .then((data) => {
    console.clear();
    console.log(
      '%c=== DEBUG USER PERMISSIONS ===',
      'color: cyan; font-size: 18px; font-weight: bold'
    );
    console.log('\n📦 Raw Response:', data);

    // Check for errors
    if (data.error) {
      console.log('%c❌ ERROR:', 'color: red; font-weight: bold', data.error);
      if (data.debug) {
        console.log('\n🔍 Debug Info:');
        console.log('  - is_user_logged_in:', data.debug.is_user_logged_in);
        console.log('  - get_current_user_id:', data.debug.get_current_user_id);
        console.log('  - cookies_present:', data.debug.cookies_present);
        console.log('  - wordpress_logged_in_cookie:', data.debug.wordpress_logged_in_cookie);
      }
      if (data.solution) {
        console.log('\n💡 Solution:', data.solution);
      }
      return;
    }

    // Check if data structure is valid
    if (!data.staff) {
      console.log('%c⚠️ Unexpected response structure', 'color: orange; font-weight: bold');
      console.log('Expected: { staff: {...}, current_role: {...}, ... }');
      console.log('Got:', data);
      return;
    }

    // Display user info
    console.log('\n%c✅ WordPress User:', 'color: green; font-weight: bold');
    if (data.user) {
      console.log('  - Username:', data.user.wordpress_user);
      console.log('  - User ID:', data.user.id);
    }

    // Display staff info
    console.log('\n%c👤 Staff Info:', 'color: blue; font-weight: bold');
    console.log('  - Name:', data.staff.name);
    console.log('  - Email:', data.staff.email);
    console.log('  - Staff ID:', data.staff.id);
    console.log('  - Role ID:', data.staff.role_id);

    // Display current role
    console.log('\n%c🎭 Current Role:', 'color: orange; font-weight: bold', data.current_role.name);
    console.log('  - Role ID:', data.current_role.id);
    console.log('  - Modules:', data.current_role.module_count, '/ 20');
    console.log('  - Actions:', data.current_role.action_count);

    if (data.current_role.module_count < 20) {
      console.log(
        '%c  ⚠️ WARNING: Missing',
        20 - data.current_role.module_count,
        'modules!',
        'color: orange; font-weight: bold'
      );
    } else {
      console.log('%c  ✅ Has full permissions!', 'color: green; font-weight: bold');
    }

    console.log('  - Module List:', data.current_role.modules.join(', '));
    console.log('  - Access Permissions:', data.current_role.access_permissions.join(', '));

    // Display available roles
    console.log('\n%c📋 Available Roles:', 'color: purple; font-weight: bold');
    if (data.available_roles && data.available_roles.length > 0) {
      console.table(data.available_roles);
    }

    // Generate fix SQL
    console.log('\n%c🔧 FIX COMMANDS:', 'color: yellow; font-weight: bold');

    if (data.current_role.module_count < 20) {
      // Find admin role with most modules
      const adminRole = data.available_roles.reduce(
        (max, role) => (role.module_count > max.module_count ? role : max),
        { module_count: 0 }
      );

      if (adminRole.id) {
        const sqlCommand = `UPDATE wp_checkin_mkt192_staff SET role_id = ${adminRole.id} WHERE id = ${data.staff.id};`;

        console.log('\n📝 SQL Command to Fix:');
        console.log(
          '%c' + sqlCommand,
          'background: #000; color: #0f0; padding: 10px; font-family: monospace; font-size: 13px'
        );

        console.log('\n📋 Steps to Apply Fix:');
        console.log('1. Open phpMyAdmin: http://localhost:8081');
        console.log('2. Login: wordpress_user / wordpress_password');
        console.log('3. Database: wordpress');
        console.log('4. Tab "SQL"');
        console.log('5. Paste this command and click "Go":');
        console.log('   ' + sqlCommand);
        console.log('6. Refresh this page (F5)');

        // Try to copy to clipboard
        if (navigator.clipboard) {
          navigator.clipboard
            .writeText(sqlCommand)
            .then(() => {
              console.log(
                '%c\n✅ SQL command copied to clipboard! Just paste (Ctrl+V) in phpMyAdmin.',
                'color: lime; font-weight: bold; font-size: 14px'
              );
            })
            .catch(() => {
              console.log('\n⚠️ Could not auto-copy. Please copy the SQL command above manually.');
            });
        }

        console.log('\n🎯 What this does:');
        console.log(
          '   Changes your staff role from:',
          data.current_role.name,
          '(',
          data.current_role.module_count,
          'modules)'
        );
        console.log('   To:', adminRole.role_name, '(', adminRole.module_count, 'modules)');
      }
    } else {
      console.log('✅ Your role already has full permissions (20 modules)');
      console.log('If you still see 403 errors, try:');
      console.log('1. Clear browser cache (Ctrl+Shift+Delete)');
      console.log('2. Hard refresh page (Ctrl+Shift+R)');
      console.log('3. Check if other staff users have correct permissions');
    }

    console.log('\n%c=== END DEBUG ===', 'color: cyan; font-size: 18px; font-weight: bold');

    return data;
  })
  .catch((error) => {
    console.error('%c❌ FETCH ERROR:', 'color: red; font-weight: bold', error);
    console.log('\n🔍 Troubleshooting:');
    console.log('1. Make sure you are on a WordPress admin page (URL contains /wp-admin/)');
    console.log('2. Make sure you are logged in to WordPress');
    console.log('3. Check if WordPress is running: http://localhost:8080');
    console.log('4. Check browser console for CORS or network errors');
    console.log('\nError details:', error.message);
  });
