# 🏗️ ARCHITECTURE DOCUMENTATION - CHECKIN MKT192 WP

## 📐 KIẾN TRÚC TỔNG QUAN

### Nguyên tắc thiết kế:

1. **Separation of Concerns** - Tách biệt admin/frontend/core
2. **Modularity** - Mỗi feature là một module độc lập
3. **Reusability** - UI components có thể tái sử dụng
4. **Scalability** - Dễ dàng mở rộng thêm features
5. **Maintainability** - Code dễ đọc, dễ bảo trì

---

## 📁 CẤU TRÚC THƯ MỤC CHI TIẾT

```
checkin-mkt192-wp/
│
├── checkin-mkt192-wp.php              # Main plugin file (bootstrap)
├── index.php                          # Security (prevent directory listing)
├── README.md                          # Plugin documentation
├── CHANGELOG.md                       # Version history
├── LICENSE.txt                        # License information
├── REFACTORING_CHECKLIST.md          # Development checklist
├── ARCHITECTURE.md                    # This file
│
├── admin/                             # ⭐ ADMIN AREA (NEW)
│   ├── index.php                      # Security
│   │
│   ├── class-admin-menu.php          # 🎯 Menu registration & structure
│   ├── class-settings-manager.php    # 🎯 Settings registration & handling
│   ├── class-admin-notices.php       # 🎯 Admin notifications system
│   │
│   ├── pages/                         # 📄 Admin page controllers
│   │   ├── index.php
│   │   ├── class-dashboard-page.php          # Dashboard overview
│   │   ├── class-brand-settings-page.php     # Brand settings (Logo, Info, Social)
│   │   ├── class-connections-page.php        # Connections (Zalo, Lark, Google, FB)
│   │   ├── class-payments-page.php           # Payment methods (Bank, Momo, ZaloPay)
│   │   ├── class-platforms-page.php          # Platform integrations
│   │   ├── class-tools-page.php              # Tools, shortcodes, debug
│   │   └── class-license-page.php            # License & support
│   │
│   └── partials/                      # 🧩 Reusable UI components
│       ├── index.php
│       ├── admin-header.php           # Page header template
│       ├── admin-footer.php           # Page footer template
│       ├── navigation-tabs.php        # Horizontal tabs component
│       ├── settings-card.php          # Settings card container
│       ├── toggle-switch.php          # Toggle switch component
│       ├── image-uploader.php         # Image upload field
│       ├── color-picker.php           # Color picker field
│       ├── input-field.php            # Text input field
│       ├── textarea-field.php         # Textarea field
│       ├── select-field.php           # Select dropdown field
│       └── notification.php           # Notification/alert box
│
├── assets/                            # 🎨 STATIC ASSETS
│   ├── index.php
│   │
│   ├── admin/                         # Admin-only assets
│   │   ├── index.php
│   │   │
│   │   ├── css/
│   │   │   ├── index.php
│   │   │   ├── admin-framework.css        # 🎨 Core UI framework
│   │   │   ├── admin-framework.min.css    # Minified version
│   │   │   ├── components.css             # UI components styles
│   │   │   ├── components.min.css
│   │   │   │
│   │   │   └── pages/                     # Page-specific styles
│   │   │       ├── dashboard.css
│   │   │       ├── brand-settings.css
│   │   │       ├── connections.css
│   │   │       ├── payments.css
│   │   │       ├── platforms.css
│   │   │       ├── tools.css
│   │   │       └── license.css
│   │   │
│   │   ├── js/
│   │   │   ├── index.php
│   │   │   ├── admin-framework.js         # 🔧 Core JS framework
│   │   │   ├── admin-framework.min.js
│   │   │   │
│   │   │   ├── modules/                   # Feature modules
│   │   │   │   ├── tab-navigation.js      # Tab switching
│   │   │   │   ├── image-uploader.js      # Media library
│   │   │   │   ├── color-picker.js        # Color selection
│   │   │   │   ├── toggle-handler.js      # Toggle switches
│   │   │   │   ├── form-handler.js        # Form validation & submit
│   │   │   │   ├── ajax-handler.js        # AJAX requests
│   │   │   │   ├── clipboard.js           # Copy to clipboard
│   │   │   │   └── notifications.js       # Notification system
│   │   │   │
│   │   │   └── pages/                     # Page-specific scripts
│   │   │       ├── brand-settings.js
│   │   │       ├── connections.js
│   │   │       ├── payments.js
│   │   │       └── tools.js
│   │   │
│   │   └── images/                        # Admin images
│   │       ├── index.php
│   │       ├── logo.png
│   │       ├── icons/
│   │       └── placeholders/
│   │
│   ├── frontend/                      # Frontend-only assets (DEPRECATED - moved to /frontend)
│   │   └── (Empty - assets moved to /frontend/assets/)
│   │
│   ├── image/                         # Legacy images folder
│   │
│   └── shared/                        # Shared assets (admin + frontend)
│       ├── fonts/
│       └── icons/
│
├── includes/                          # 🔧 CORE FUNCTIONALITY
│   ├── index.php
│   │
│   ├── core/                          # ⚙️ Core classes (NEW)
│   │   ├── index.php
│   │   ├── class-plugin.php           # Main plugin orchestrator
│   │   ├── class-loader.php           # Hooks & filters loader
│   │   ├── class-activator.php        # Activation handler
│   │   ├── class-deactivator.php      # Deactivation handler
│   │   └── class-uninstaller.php      # Uninstall handler
│   │
│   ├── admin/                         # 👨‍💼 Admin-specific logic (NEW)
│   │   ├── index.php
│   │   ├── class-admin.php            # Admin initialization
│   │   └── class-admin-ajax.php       # Admin AJAX handlers
│   │
│   ├── frontend/                      # 👥 Frontend logic
│   │   ├── index.php
│   │   └── class-frontend.php         # Frontend initialization
│   │
│   ├── class-checkin-mkt192-activation.php       # (Existing - may refactor)
│   ├── class-checkin-mkt192-admin-management.php # (Existing - will deprecate)
│   ├── class-checkin-mkt192-shortcodes.php       # (Existing)
│   ├── class-checkin-mkt192-assets.php           # (Existing - may refactor)
│   │
│   ├── rest-api/                      # REST API endpoints
│   │   ├── rest-api-init.php
│   │   └── [existing files...]
│   │
│   ├── automation/                    # Automation & cron jobs
│   │   └── [existing files...]
│   │
│   ├── lark/                          # Lark integration
│   │   └── [existing files...]
│   │
│   ├── zalo/                          # Zalo integration
│   │   └── [existing files...]
│   │
│   ├── booking/                       # Booking system
│   │   └── [existing files...]
│   │
│   ├── license-manager.php            # (Existing)
│   └── admin-debug-page.php           # (Existing - may refactor)
│
├── frontend/                          # 🎨 FRONTEND FILES (NEW STRUCTURE)
│   ├── index.php
│   │
│   ├── assets/                        # Frontend assets
│   │   ├── css/
│   │   │   ├── components/            # Reusable CSS components
│   │   │   │   ├── modals.css         # Modal & Toast styles
│   │   │   │   └── salary-staff.css   # Salary staff component
│   │   │   │
│   │   │   └── pages/                 # Page-specific CSS
│   │   │       ├── checkin.css
│   │   │       ├── checkin-dashboard.css
│   │   │       ├── customer-member.css
│   │   │       ├── customer-registration.css
│   │   │       ├── customer-review-offline.css
│   │   │       ├── customer-review-online.css
│   │   │       ├── admin-setting-frontend.css
│   │   │       ├── home.css
│   │   │       ├── app-tho/           # App Tho module styles
│   │   │       │   ├── app-tho.css
│   │   │       │   ├── sidebar.css
│   │   │       │   ├── invoice-services.css
│   │   │       │   ├── inventory.css
│   │   │       │   └── dark-mode.css
│   │   │       └── user/              # User profile styles
│   │   │           └── user-profile.css
│   │   │
│   │   ├── js/
│   │   │   ├── modules/               # Reusable JS modules
│   │   │   │   ├── modals.js          # Modal & notification system
│   │   │   │   └── salary-staff.js    # Salary calculation
│   │   │   │
│   │   │   └── pages/                 # Page-specific JS
│   │   │       ├── checkin.js
│   │   │       ├── checkin-dashboard.js
│   │   │       ├── customer-member.js
│   │   │       ├── customer-registration.js
│   │   │       ├── customer-review-offline.js
│   │   │       ├── customer-review-online.js
│   │   │       ├── admin-setting-frontend.js
│   │   │       ├── home.js
│   │   │       ├── app-tho.js
│   │   │       └── user-profile.js
│   │   │
│   │   └── images/                    # Frontend images
│   │
│   ├── pages/                         # Frontend page templates
│   │   ├── checkin.html
│   │   ├── checkin-dashboard.html
│   │   ├── customer-member.html
│   │   ├── customer-registration.php
│   │   ├── customer-review-offline.html
│   │   ├── customer-review-online.html
│   │   ├── admin-setting-frontend.html
│   │   ├── home.php
│   │   ├── app-tho.html
│   │   ├── user-profile.html
│   │   ├── modals.html
│   │   ├── policy.html
│   │   ├── terms-and-service.html
│   │   ├── admin-dashboard.html
│   │   └── admin-setting.html
│   │
│   ├── components/                    # Reusable frontend components
│   │   └── (Reserved for future use)
│   │
│   └── README.md                      # Frontend documentation
│
├── templates/                         # 📄 LEGACY TEMPLATES (DEPRECATED)
│   └── (Empty - moved to frontend/pages/)
│
├── languages/                         # 🌐 TRANSLATIONS
│   ├── checkin-mkt192-en_US.po
│   └── checkin-mkt192-vi_VN.po
│
└── docs/                              # 📚 DOCUMENTATION
    ├── user-guide.md
    ├── developer-guide.md
    ├── api-reference.md
    └── screenshots/
```

---

## 🎯 ADMIN MENU STRUCTURE

```
WordPress Admin Sidebar:
│
└─ 📍 Checkin MKT 192                 (Parent Menu)
   ├─ 📊 Dashboard                    (Overview, stats, quick actions)
   ├─ 🎨 Brand Settings                (Logo, Colors, Information, Social)
   ├─ 🔌 Connections                   (Zalo, Lark, Google, Facebook)
   ├─ 💳 Payments                      (Bank, Momo, ZaloPay)
   ├─ 🔗 Platforms                     (Review plugin, other integrations)
   ├─ 🛠️ Tools                         (Shortcodes, System info, Debug)
   └─ 🔑 License & Support             (License, Updates, Support)
```

### Mỗi page có horizontal tabs:

#### 🎨 Brand Settings

- **Logo & Colors** - Logo, Banner, Primary Color, Secondary Color
- **Information** - Brand name, Domain, Address, Phone, Email, Hours
- **Social Links** - Fanpage, TikTok, YouTube, Google Maps

#### 🔌 Connections

- **Zalo** - Zalo OA, Zalo User
- **Lark** - Lark Bot configuration
- **Google** - Google Login, Client ID
- **Facebook** - Facebook Login, App ID, App Secret

#### 💳 Payments

- **Bank Transfer** - Account info, QR Code
- **Momo** - Account info, QR Code
- **ZaloPay** - Account info, QR Code

---

## 🎨 UI/UX DESIGN SYSTEM

### Color Palette

```css
/* Primary Colors */
--primary-color: #2271b1; /* WordPress admin blue */
--primary-hover: #135e96;
--primary-light: #e7f3ff;

/* Secondary Colors */
--secondary-color: #50575e; /* Dark gray */
--secondary-light: #8c8f94;

/* Status Colors */
--success-color: #00a32a; /* Green */
--warning-color: #f0b849; /* Orange */
--error-color: #d63638; /* Red */
--info-color: #2271b1; /* Blue */

/* Neutral Colors */
--white: #ffffff;
--gray-50: #f9f9f9;
--gray-100: #f0f0f1;
--gray-200: #dcdcde;
--gray-300: #c3c4c7;
--gray-700: #50575e;
--gray-900: #1d2327;

/* Text Colors */
--text-primary: #1d2327;
--text-secondary: #50575e;
--text-tertiary: #8c8f94;
--text-link: #2271b1;
```

### Typography

```css
/* Font Stack */
--font-primary: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen-Sans, Ubuntu,
  Cantarell, 'Helvetica Neue', sans-serif;

/* Font Sizes */
--font-size-xs: 12px;
--font-size-sm: 13px;
--font-size-base: 14px;
--font-size-lg: 16px;
--font-size-xl: 20px;
--font-size-2xl: 24px;
--font-size-3xl: 30px;

/* Font Weights */
--font-weight-normal: 400;
--font-weight-medium: 500;
--font-weight-semibold: 600;
--font-weight-bold: 700;
```

### Spacing

```css
/* Spacing Scale */
--space-1: 4px;
--space-2: 8px;
--space-3: 12px;
--space-4: 16px;
--space-5: 20px;
--space-6: 24px;
--space-8: 32px;
--space-10: 40px;
--space-12: 48px;
--space-16: 64px;
```

### Border Radius

```css
--radius-sm: 4px;
--radius-md: 8px;
--radius-lg: 12px;
--radius-full: 9999px;
```

### Shadows

```css
--shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
--shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
--shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
--shadow-xl: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
```

### Breakpoints

```css
/* Responsive Breakpoints */
--breakpoint-mobile: 640px;
--breakpoint-tablet: 768px;
--breakpoint-desktop: 1024px;
--breakpoint-wide: 1280px;
```

---

## 🧩 UI COMPONENTS

### 1. Navigation Tabs

```html
<div class="checkin-tabs">
  <ul class="checkin-tabs-nav">
    <li class="active"><a href="#tab1">Tab 1</a></li>
    <li><a href="#tab2">Tab 2</a></li>
  </ul>
  <div class="checkin-tabs-content">
    <div id="tab1" class="tab-pane active">...</div>
    <div id="tab2" class="tab-pane">...</div>
  </div>
</div>
```

### 2. Settings Card

```html
<div class="checkin-card">
  <div class="checkin-card-header">
    <h3>Card Title</h3>
  </div>
  <div class="checkin-card-body">
    <!-- Settings fields -->
  </div>
  <div class="checkin-card-footer">
    <button class="button button-primary">Save</button>
  </div>
</div>
```

### 3. Toggle Switch

```html
<label class="checkin-toggle">
  <input type="checkbox" name="setting" value="1" />
  <span class="checkin-toggle-slider"></span>
  <span class="checkin-toggle-label">Enable Feature</span>
</label>
```

### 4. Image Uploader

```html
<div class="checkin-image-uploader">
  <input type="hidden" name="image_url" class="image-url" />
  <div class="image-preview">
    <img src="" alt="" />
  </div>
  <button type="button" class="button upload-button">Upload Image</button>
  <button type="button" class="button remove-button">Remove</button>
</div>
```

### 5. Notification

```html
<div class="checkin-notice checkin-notice-success">
  <p>Settings saved successfully!</p>
</div>
```

---

## 🔧 JAVASCRIPT ARCHITECTURE

### Core Framework (admin-framework.js)

```javascript
var CheckinAdmin = {
  // Initialization
  init: function () {
    this.tabs.init();
    this.forms.init();
    this.notifications.init();
  },

  // Tab navigation
  tabs: {
    init: function () {},
    switch: function (tabId) {},
  },

  // Form handling
  forms: {
    init: function () {},
    validate: function (form) {},
    submit: function (form) {},
  },

  // AJAX wrapper
  ajax: {
    request: function (action, data, callback) {},
  },

  // Notification system
  notifications: {
    show: function (message, type) {},
    hide: function () {},
  },

  // Media uploader
  media: {
    upload: function (target) {},
  },
};

jQuery(document).ready(function ($) {
  CheckinAdmin.init();
});
```

---

## 📊 DATA FLOW

### Settings Save Flow

```
User Input (Form)
    ↓
JavaScript Validation
    ↓
AJAX Request (with nonce)
    ↓
PHP Sanitization & Validation
    ↓
WordPress Settings API (update_option)
    ↓
Database (wp_options)
    ↓
Success Response
    ↓
UI Notification
```

### Settings Load Flow

```
Page Load
    ↓
PHP get_option()
    ↓
Database Query
    ↓
Data Rendering (escaped output)
    ↓
UI Display
```

---

## 🔒 SECURITY MEASURES

1. **Nonce Verification** - Tất cả AJAX requests
2. **Capability Checks** - `manage_options` cho admin pages
3. **Input Sanitization** - `sanitize_text_field()`, `sanitize_email()`, etc.
4. **Output Escaping** - `esc_html()`, `esc_attr()`, `esc_url()`
5. **CSRF Protection** - Nonce tokens
6. **SQL Injection Prevention** - Prepared statements (nếu có custom queries)
7. **XSS Prevention** - Output escaping
8. **File Upload Security** - Type validation, size limits

---

## 📈 PERFORMANCE OPTIMIZATION

1. **Conditional Loading** - Chỉ load assets khi cần
2. **Minification** - CSS và JS minified versions
3. **Lazy Loading** - Images loaded khi visible
4. **Caching** - Transients API cho expensive operations
5. **Database Optimization** - Indexed queries
6. **Asset Versioning** - Cache busting

---

## 🧪 TESTING STRATEGY

### Unit Tests

- Settings registration
- Data sanitization
- Permission checks

### Integration Tests

- Form submissions
- AJAX requests
- Settings save/load

### UI Tests

- Tab navigation
- Form validation
- Responsive behavior

### Browser Testing

- Chrome, Firefox, Safari, Edge
- Desktop, Tablet, Mobile

---

## 🔄 BACKWARDS COMPATIBILITY

### Deprecated Functions

- Keep old functions với `_deprecated_function()` notice
- Gradual migration path
- Documentation cho developers

### Settings Migration

- Option names giữ nguyên
- Thêm settings mới không conflict với cũ
- Fallback values cho missing options

---

## 📝 CODING STANDARDS

### PHP

- WordPress Coding Standards
- PSR-4 autoloading (for new classes)
- DocBlocks for all classes/methods

### JavaScript

- ESLint configuration
- Modern ES6+ syntax (transpiled for compatibility)
- JSDoc comments

### CSS

- BEM naming convention
- Mobile-first approach
- CSS custom properties (variables)

---

## 🚀 DEPLOYMENT CHECKLIST

- [ ] Code review
- [ ] Security audit
- [ ] Performance testing
- [ ] Cross-browser testing
- [ ] Responsive testing
- [ ] Accessibility check
- [ ] Documentation updated
- [ ] Version number bumped
- [ ] CHANGELOG updated
- [ ] Git tag created

---

**Version:** 1.0.0
**Last Updated:** 13/11/2025
**Maintained by:** Monkey Tech 192
