# Chức năng Tạo Đơn Xin Phép (Request Approval Feature)

## Tổng quan

Bổ sung chức năng tạo đơn xin phép vào trang User Profile, cho phép nhân viên tạo các loại đơn khác nhau và gửi thông báo về group quản lý.

## Các loại đơn

1. **Đơn xin đi trễ/về sớm** (late_early_request)

   - Ngày áp dụng
   - Loại: Đi trễ / Về sớm
   - Thời gian dự kiến (trễ/sớm bao nhiêu phút)
   - Lý do

2. **Đơn xin nghỉ phép** (leave_request)

   - Ngày bắt đầu nghỉ
   - Ngày kết thúc nghỉ
   - Tổng số ngày nghỉ (tự tính)
   - Loại nghỉ: Nghỉ phép năm / Nghỉ không lương / Nghỉ ốm
   - Lý do

3. **Đơn xin tăng ca** (overtime_request)

   - Ngày tăng ca
   - Thời gian bắt đầu
   - Thời gian kết thúc
   - Tổng số giờ tăng ca (tự tính)
   - Lý do

4. **Đơn xin ứng lương** (salary_advance_request)
   - Số tiền xin ứng
   - Lý do
   - Ghi chú

## Tiến độ thực hiện

### Phase 1: Database & API ✅ IN PROGRESS

- [ ] 1.1. Tạo bảng database `checkin_mkt192_approval_requests`
- [ ] 1.2. Tạo file API `approval-requests-api.php`
  - [ ] POST `/approval-requests` - Tạo đơn mới
  - [ ] GET `/approval-requests` - Lấy danh sách đơn
  - [ ] GET `/approval-requests/{id}` - Lấy chi tiết đơn
  - [ ] PUT `/approval-requests/{id}/approve` - Duyệt đơn
  - [ ] PUT `/approval-requests/{id}/reject` - Từ chối đơn
- [ ] 1.3. Cập nhật file permission.php với các scope mới
  - approval.create
  - approval.read
  - approval.approve
  - approval.reject

### Phase 2: Lark Notification ⏳ PENDING

- [ ] 2.1. Tạo file `send_approval_request_notification.php`
- [ ] 2.2. Tạo card builder cho các loại đơn
- [ ] 2.3. Xử lý callback khi admin bấm duyệt/từ chối trên Lark

### Phase 3: Frontend - Modal Tạo Đơn ⏳ PENDING

- [ ] 3.1. Tạo file CSS `request-approval.css`
- [ ] 3.2. Tạo file JS `request-approval.js`
- [ ] 3.3. Thêm HTML modal vào `user-profile.html`
- [ ] 3.4. Thêm nút "Tạo đơn" vào profile page
- [ ] 3.5. Xử lý logic hiển thị form theo loại đơn

### Phase 4: Frontend - Lịch sử đơn ⏳ PENDING

- [ ] 4.1. Tạo giao diện xem lịch sử đơn đã gửi
- [ ] 4.2. Realtime cập nhật trạng thái đơn
- [ ] 4.3. Thêm nút Approval vào navigation bar (nếu cần)

### Phase 5: Admin Settings ⏳ PENDING

- [ ] 5.1. Cập nhật `admin-setting-frontend.js` để quản lý quyền mới
- [ ] 5.2. Thêm UI cấu hình quyền approval trong admin

## Database Schema

```sql
CREATE TABLE checkin_mkt192_approval_requests (
    id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
    request_id VARCHAR(50) NOT NULL COMMENT 'Mã đơn (VD: REQ-20250611-001)',
    request_type ENUM('late_early', 'leave', 'overtime', 'salary_advance') NOT NULL,
    staff_name VARCHAR(191) NOT NULL,
    staff_id BIGINT(20) UNSIGNED NOT NULL,

    -- Common fields
    request_date DATE NOT NULL COMMENT 'Ngày tạo đơn',
    reason TEXT NOT NULL,
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    approved_by VARCHAR(191) DEFAULT NULL,
    approved_at DATETIME DEFAULT NULL,
    reject_reason TEXT DEFAULT NULL,

    -- Late/Early specific
    late_early_type ENUM('late', 'early') DEFAULT NULL,
    late_early_date DATE DEFAULT NULL,
    late_early_minutes INT(11) DEFAULT NULL,

    -- Leave specific
    leave_start_date DATE DEFAULT NULL,
    leave_end_date DATE DEFAULT NULL,
    leave_total_days INT(11) DEFAULT NULL,
    leave_type ENUM('annual', 'unpaid', 'sick') DEFAULT NULL,

    -- Overtime specific
    overtime_date DATE DEFAULT NULL,
    overtime_start_time TIME DEFAULT NULL,
    overtime_end_time TIME DEFAULT NULL,
    overtime_hours DECIMAL(5,2) DEFAULT NULL,

    -- Salary advance specific
    advance_amount DECIMAL(15,2) DEFAULT NULL,

    -- Lark integration
    lark_message_id VARCHAR(255) DEFAULT NULL,

    -- Timestamps
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    PRIMARY KEY (id),
    UNIQUE KEY request_id (request_id),
    INDEX idx_staff_name (staff_name),
    INDEX idx_request_type (request_type),
    INDEX idx_status (status),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

## API Endpoints

### POST /vg/v1/approval-requests

Tạo đơn mới

- Permission: `approval.create`
- Body: Tùy theo loại đơn

### GET /vg/v1/approval-requests

Lấy danh sách đơn

- Permission: `approval.read`
- Query params: `staff_name`, `request_type`, `status`, `start_date`, `end_date`

### PUT /vg/v1/approval-requests/{id}/approve

Duyệt đơn

- Permission: `approval.approve`

### PUT /vg/v1/approval-requests/{id}/reject

Từ chối đơn

- Permission: `approval.reject`
- Body: `reject_reason`

## Notes

- Cần update permission.php với các scope mới
- Cần update admin-setting-frontend.js để hiển thị quyền mới trong UI
- Tham khảo cơ chế callback của inventory transaction cho việc xử lý duyệt/từ chối từ Lark
