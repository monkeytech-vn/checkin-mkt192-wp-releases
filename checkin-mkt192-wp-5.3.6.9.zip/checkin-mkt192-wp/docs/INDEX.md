# 📑 Documentation Index - Checkin MKT192 Plugin

## 🎯 Current Version: v5.1.7.4.0 (Latest)

**Plugin Status:** ✅ Production Ready - Approval system, modern Git workflow, comprehensive permissions.

---

## ⚡ Quick Start

**🔴 New User?** → Start: [QUICKSTART.md](QUICKSTART.md) (setup & configuration)
**🟡 Developer?** → Start: [ARCHITECTURE.md](ARCHITECTURE.md) (system design)
**🟢 Admin?** → Start: [PERMISSION_GUIDE.md](PERMISSION_GUIDE.md) (permissions & roles)
**🔵 API User?** → Start: [PUBLIC_APIS.md](PUBLIC_APIS.md) (REST API reference)
**🔒 Security?** → Start: [SECURITY_AUDIT.md](SECURITY_AUDIT.md) (security checklist)

---

## 📚 Core Documentation

Essential documentation for the Checkin MKT192 WordPress plugin:

### 1️⃣ `QUICKSTART.md` ⭐ **START HERE**

- Plugin installation and basic setup
- Configuration steps for integrations (Zalo, Lark, payments)
- Quick testing guide

### 2️⃣ `ARCHITECTURE.md`

- System architecture overview
- Database schema and relationships
- File structure and organization
- Security considerations

### 3️⃣ `PUBLIC_APIS.md`

- Complete REST API reference
- Authentication and authorization
- Endpoint documentation with examples

### 4️⃣ `PERMISSION_GUIDE.md`

- Role-based permissions system
- Admin capabilities and restrictions
- User access control

### 5️⃣ `SECURITY_AUDIT.md` 🔒 **NEW**

- Security vulnerabilities checklist
- Production deployment guidelines
- Files to remove before deploy

### 6️⃣ `REQUEST-APPROVAL-FEATURE.md`

- Approval request system documentation
- Staff profile change workflow
- Manager approval process

---

## 📋 Recent Changes (Changelog)

### v5.1.7.4.0 - Approval System & Modern Git (December 2024)

- Approval Request System for staff profile changes
- REST API endpoints for approval management
- Modern Edit Modal UI
- GitHub Actions CI/CD workflows
- Git Flow + Conventional Commits migration
- Security audit documentation

### v5.1.7.3.0 - User Profile Updates

- User profile management features
- Staff profile API endpoints

### v5.1.0 - Admin UI Overhaul

- Tabbed admin pages
- Settings migration improvements

### v5.0.0 - Major Rewrite

- Modular REST API architecture
- Enhanced security and performance

---

## 🗄️ Archived Files

Debug and test scripts moved to `docs/archived/`:

- `debug-simple.js`
- `debug-script-safe.js`
- `test-promo-expiry-logic.js`

---

## 📞 Support

For issues or questions:

- Check relevant documentation above
- Contact maintainers via repository
- Internal support: Monkey Tech 192 channels

**Last Updated:** December 2024
