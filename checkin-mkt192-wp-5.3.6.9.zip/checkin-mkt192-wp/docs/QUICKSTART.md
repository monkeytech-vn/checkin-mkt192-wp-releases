# 📋 QUICK START - GUIDE CHI NHÁNH

## 🎯 QUICK SUMMARY

### ✅ Điều Đã Hoàn Thành

1. ✅ Phân tích tổng thể plugin: README, cấu trúc, logic hiện tại
2. ✅ Tạo 4 file documentation chi tiết (~2,600 lines)
3. ✅ Lập kế hoạch 8 task chính + 90+ subtask
4. ✅ Khuyến nghị phương pháp tối ưu

### 📊 Overview

- **Phạm vi:** 15 bảng database, 7 trang frontend, 10+ API endpoints
- **Thời gian:** 2-3 tuần
- **Phương pháp:** Auto-Detect (GPS) + Manual Select
- **Complexity:** 🟠 Medium-High

---

## 📖 DOCUMENTATION CREATED

| #   | File                                    | Mục Đích                                              | Đọc khi                |
| --- | --------------------------------------- | ----------------------------------------------------- | ---------------------- |
| 1   | `BRANCH_FEATURE_IMPLEMENTATION_PLAN.md` | Kế hoạch tổng quát, scope, architecture, risks        | Lần đầu hiểu project   |
| 2   | `TASK_BREAKDOWN_CHECKLIST.md`           | 8 task + 90+ subtask chi tiết, công việc từng ngày    | Bắt đầu implementation |
| 3   | `BRANCH_SELECTOR_COMPARISON.md`         | So sánh phương pháp 1 vs 2, khuyến nghị               | Quyết định cách làm    |
| 4   | `BRANCH_ARCHITECTURE.md`                | System architecture, data flow, security, performance | Hiểu kiến trúc kỹ      |
| 5   | File này                                | Quick reference, FAQ, next steps                      | Cần nhanh overview     |

---

## 🎯 RECOMMENDED READING ORDER

```
1st: This file (5 min)
     ↓
2nd: BRANCH_SELECTOR_COMPARISON.md (15 min)
     Hiểu 2 phương pháp, confirm khuyến nghị
     ↓
3rd: BRANCH_FEATURE_IMPLEMENTATION_PLAN.md (30 min)
     Hiểu toàn bộ scope, timeline, tasks
     ↓
4th: BRANCH_ARCHITECTURE.md (30 min)
     Hiểu system design, data flow
     ↓
5th: TASK_BREAKDOWN_CHECKLIST.md (while coding)
     Follow danh sách task, check off khi xong
```

---

## 🚀 WHAT TO BUILD: TÓM TẮT

### Database Layer (TASK 1)

```
Add 'branch' column to 15 tables:
staff, service_data, products, service_groups,
ctkm_settings, salary_level_settings, staff_roles,
shiftsettings, penalty_settings, advance_salary,
cashier_salary, hairdresser_salary, kpi_settings,
kpi_results, manager_schedules

Each gets:
- Column: branch VARCHAR(255) DEFAULT ''
- Index: idx_branch (branch)
```

### API Layer (TASK 2)

```
New endpoints:
- GET /branches                    → List all branches
- GET /branch-by-location?lat=X&lon=Y → Auto-detect

Updated endpoints:
- GET /staff?branch=X              → Filtered data
- GET /services?branch=X
- GET /products?branch=X
- GET /invoices?branch=X
- ... (10+ more)
```

### Frontend Layer (TASKS 3-7)

**Admin-Setting-Frontend:**

- Add branch column to 7 tables
- Add branch select filter to 4 sections

**App-Tho:**

- Add branch selector component (auto-detect + manual)
- Filter all 8 sections by selected branch

**Helper Module:**

- branchHelper.js - Reusable branch detection/filtering

---

## 📈 TIMELINE

```
Week 1 (Backend):
├─ Day 1: Database schema
├─ Day 2-3: REST API endpoints
├─ Day 4-5: Test & verify
│
Week 2 (Admin Frontend):
├─ Day 1-2: Column updates
├─ Day 3-4: Select filters
├─ Day 5: Integration & test
│
Week 3 (App-Tho & Polish):
├─ Day 1-2: Branch selector + auto-detect
├─ Day 3-4: Filter all sections
├─ Day 5: QA & performance
```

---

## ✨ KEY DESIGN DECISIONS

### 1. Auto-Detect + Manual Select (Recommended)

- ✅ Auto-detect on load using GPS
- ✅ Allow manual override with select
- ✅ Remember choice in localStorage
- ✅ Same pattern as user-profile page

**Why?** Best UX. User doesn't have to think 90% of time.

### 2. Reusable Helper Module

- ✅ File: `branchHelper.js`
- ✅ Functions: detectBranch(), getBranches(), getCurrentBranch(), setCurrentBranch(), filterByBranch()
- ✅ Use in both admin-setting-frontend & app-tho

**Why?** DRY principle. Less code, easier maintenance.

### 3. Backward Compatible API

- ✅ GET /services?branch=X → Returns filtered
- ✅ GET /services → Returns ALL (no break)

**Why?** Safe for production. Existing integrations don't break.

### 4. Static CSS (No Tailwind)

- ✅ Pure CSS with CSS Variables
- ✅ BEM naming
- ✅ Mobile-first responsive

**Why?** Faster, smaller bundle, full control.

---

## 🎯 WHAT USERS WILL SEE

### On Admin-Setting-Frontend

```
Before:
│ Danh sách Nhân viên
├─ Tên | Email | Vai trò | Hành động
│ John │ j@... │ Staff  │ ...

After:
│ Danh sách Nhân viên
├─ Tên | Email | Vai trò | Chi Nhánh | Hành động
│ John │ j@... │ Staff  │ [Select] │ ...
         + Select, Dropdown, filter sections
```

### On App-Tho

```
Before:
│ Services │ Products │ Staff │ Bookings │ ...

After:
┌─────────────────────────────────────────┐
│ Chi Nhánh: [Branch 1 ▼]  ✓ Detected    │ ← Auto-detected!
├─────────────────────────────────────────┤
│ Services │ Products │ Staff │ Bookings │ ...
│ (filtered by Branch 1)
```

---

## 🔐 SECURITY & PERFORMANCE

### Security

- ✅ Sanitize branch parameter
- ✅ Validate branch exists in locations table
- ✅ Permission checks per user
- ✅ No SQL injection (prepared statements)
- ✅ No XSS (proper DOM manipulation)

### Performance

- ✅ Index on `branch` column
- ✅ Parallel API calls (Promise.all)
- ✅ Session caching for branches list
- ✅ Lazy load sections
- ✅ Target: < 2s page load + branch switch

---

## ✅ SUCCESS CRITERIA

When done, must have:

- ✅ All 15 tables with `branch` column
- ✅ Auto-detection works 90%+ of time
- ✅ All sections filter by branch correctly
- ✅ No data leaks between branches
- ✅ Mobile responsive (320px+)
- ✅ Page load < 2s
- ✅ No breaking changes to existing API
- ✅ All tests passing

---

## 🤔 COMMON QUESTIONS

**Q: Auto-detect uses GPS - is it slow?**
A: 1-3s async, doesn't block UI. Data loads in parallel.

**Q: What if GPS is denied/fails?**
A: Falls back to manual select. User picks branch manually.

**Q: Will this break existing code?**
A: No. New column has default value. API backward compatible.

**Q: Do I need Tailwind for CSS?**
A: No. Using pure CSS with CSS variables. Faster, smaller.

**Q: How much code needs to change?**
A: ~3,000 lines total: JS, PHP, CSS across 20+ files.

**Q: Can I do it incrementally?**
A: Yes. Each phase is independent. Can pause between phases.

---

## 🚀 NEXT STEPS

1. **Now:** Read BRANCH_SELECTOR_COMPARISON.md (confirm method)
2. **Then:** Read BRANCH_FEATURE_IMPLEMENTATION_PLAN.md (understand scope)
3. **Then:** Read BRANCH_ARCHITECTURE.md (understand design)
4. **Then:** Start TASK 1 from TASK_BREAKDOWN_CHECKLIST.md

**Estimated reading time:** 1-2 hours
**Estimated implementation time:** 2-3 weeks

---

## 📊 FEATURE MATRIX

| Component     | Location                  | Status  | Complexity |
| ------------- | ------------------------- | ------- | ---------- |
| Database      | 15 tables                 | 🔴 TODO | Medium     |
| REST API      | /vg/v1/                   | 🔴 TODO | High       |
| Branch Helper | JS component              | 🔴 TODO | Low        |
| Admin-Setting | Tables & Selects          | 🔴 TODO | High       |
| App-Tho       | Branch selector + filters | 🔴 TODO | Very High  |
| CSS           | Components                | 🔴 TODO | Medium     |
| Testing       | Full QA                   | 🔴 TODO | Medium     |

---

## 📞 WHERE TO FIND THINGS

| Need             | File                                  | Line Range       |
| ---------------- | ------------------------------------- | ---------------- |
| Database changes | BRANCH_FEATURE_IMPLEMENTATION_PLAN.md | Task 1 section   |
| API details      | BRANCH_ARCHITECTURE.md                | REST API section |
| Admin updates    | TASK_BREAKDOWN_CHECKLIST.md           | TASK 4 section   |
| App-Tho details  | TASK_BREAKDOWN_CHECKLIST.md           | TASK 5 section   |
| CSS guidelines   | BRANCH_FEATURE_IMPLEMENTATION_PLAN.md | TASK 6 section   |
| Code examples    | BRANCH_ARCHITECTURE.md                | Throughout       |

---

## 🎯 DECISION POINT

**Which approach to use?**

```
Method 1: Manual Select Only
├─ ✅ Simple to code
├─ ❌ Bad UX (user must click every time)
└─ ❌ Not consistent with user-profile

Method 2: Auto-Detect + Manual Select ✅✅✅ RECOMMENDED
├─ ✅ Best UX (auto-selected 90% of time)
├─ ✅ Flexible (allow manual override)
├─ ✅ Consistent with user-profile
└─ ⚠️ Slightly more code (but worth it)
```

**Proceed with Method 2 ✅**

---

## 🎓 KEY CONCEPTS

### Branch

- Represents a location/chi nhánh of the business
- Stored in `locations` table
- Referenced as `location_name` string in new columns

### Auto-Detection

- Get user's GPS coordinates
- Call API /branch-by-location
- Server finds nearest branch within radius
- Return branch name

### Filtering

- When user selects branch, store in localStorage
- All data fetches include ?branch=SelectedBranch parameter
- Server filters results, returns only that branch's data

### Fallback

- If GPS denied: Show select, let user pick manually
- If auto-detect fails: Use previous selection or first branch
- If no branches exist: Show message, operate normally

---

## 📋 FINAL CHECKLIST

Before starting implementation:

- [ ] Read all documentation (1-2 hours)
- [ ] Confirm Method 2 approach with team
- [ ] Backup database
- [ ] Create feature branch `feature/branch-system`
- [ ] Setup staging environment
- [ ] Review TASK_BREAKDOWN_CHECKLIST.md
- [ ] Understand timeline (2-3 weeks)
- [ ] Allocate team members
- [ ] Plan QA process

---

## 🚀 YOU'RE READY!

**Status:** ✅ Complete Planning. Ready for Implementation.

**Get Started:**

1. Read BRANCH_SELECTOR_COMPARISON.md (confirm method)
2. Start TASK 1: Database Schema
3. Follow TASK_BREAKDOWN_CHECKLIST.md daily

**Questions?** Refer to documentation files.

---

**Created:** 17/11/2025
**Version:** 1.0
**Status:** Ready to Code 🎉
