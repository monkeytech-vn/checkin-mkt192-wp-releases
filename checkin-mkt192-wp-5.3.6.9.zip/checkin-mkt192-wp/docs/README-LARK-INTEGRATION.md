# Hướng dẫn tích hợp Lark/Larksuite

## Tổng quan

Plugin Checkin MKT192 WP đã được tích hợp với Lark/Larksuite để gửi thông báo đến users, group chats và channels.

## ⚡ Hai phương thức gửi tin nhắn

### 🤖 Phương thức 1: Bot Identity (Tenant Access Token)

- ✅ **Đã implement sẵn**
- Tin nhắn hiển thị từ **Bot App**
- **Ưu điểm:** Đơn giản, chỉ cần App ID và App Secret
- **Nhược điểm:** Bot cần được thêm vào group trước, tin nhắn hiển thị từ bot
- **Use case:** Thông báo tự động, alerts, reports

### 👤 Phương thức 2: Admin Identity (User Access Token)

- 🔄 **Cần cấu hình thêm OAuth**
- Tin nhắn hiển thị từ **tài khoản Admin thật**
- **Ưu điểm:** Tin nhắn mang tính cá nhân hơn, không cần thêm bot vào group
- **Nhược điểm:** Phức tạp hơn, cần OAuth flow và refresh token
- **Use case:** Thông báo quan trọng cần sự xác thực của admin
- 📖 **Xem phần [OAuth Setup](#oauth-setup-phương-thức-2)** bên dưới

---

## Cấu hình

### Phương thức 1: Bot Identity (Khuyến nghị cho bắt đầu)

#### 1. Tạo Lark App

1. Truy cập [Lark Developer Console](https://open.larksuite.com/app)
2. Chọn **Self-built App** → Tạo app mới
3. Đặt tên app (ví dụ: "Checkin MKT192 Notification Bot")
4. Lấy **App ID** và **App Secret** từ phần **Credentials**

#### 2. Cấp quyền cho App

Trong Lark Developer Console, vào **Permissions & Scopes** và thêm:

**Permissions & Scopes:**

- `im:message` - Gửi tin nhắn
- `im:message:send_as_bot` - Gửi tin nhắn với tư cách bot
- `im:chat` - Truy cập thông tin chat
- `im:card` - Gửi interactive message cards (optional)

#### 3. Publish App

1. Vào tab **Version Management & Release**
2. Click **Create Version** → **Submit for Release**
3. Chờ admin organization approve (hoặc tự approve nếu bạn là admin)

#### 4. Thêm Bot vào Group

1. Mở Lark app → Vào group chat cần nhận thông báo
2. Click vào tên group → **Settings** → **Bots**
3. Click **Add Bot** → Tìm và thêm bot của bạn

#### 5. Cấu hình trong WordPress

1. Đăng nhập vào WordPress Admin
2. Vào menu **Checkin MKT 192** → **Cài đặt**
3. Chọn tab **Kết nối**
4. Bật toggle **"Kích hoạt Lark"**
5. Nhập **Lark App ID** và **Lark App Secret**
6. Nhấn **"Lưu cài đặt"**

## Sử dụng trong code

### Kiểm tra Lark đã được kích hoạt

```php
if (Checkin_MKT192_Lark_Helper::is_enabled()) {
    // Lark đã được bật
}

if (Checkin_MKT192_Lark_Helper::is_configured()) {
    // Lark đã được cấu hình đầy đủ (có App ID và Secret)
}
```

### Gửi tin nhắn text đơn giản

```php
// Gửi đến group chat
$result = Checkin_MKT192_Lark_Helper::send_text_message(
    'oc_xxxxxxxxxxxx',  // Chat ID
    'Xin chào! Đây là tin nhắn test từ WordPress.',
    'chat_id'
);

// Gửi đến user
$result = Checkin_MKT192_Lark_Helper::send_text_message(
    'ou_xxxxxxxxxxxx',  // User ID
    'Xin chào! Đây là tin nhắn test.',
    'user_id'
);
```

### Gửi thông báo có định dạng

```php
$result = Checkin_MKT192_Lark_Helper::send_notification(
    'oc_xxxxxxxxxxxx',  // Chat ID
    '🎉 Thông báo quan trọng',  // Tiêu đề
    'Đây là nội dung thông báo. Vui lòng kiểm tra và xác nhận.',  // Nội dung
    'chat_id'
);
```

### Gửi message card với buttons (Interactive)

```php
$card = [
    'config' => [
        'wide_screen_mode' => true
    ],
    'header' => [
        'title' => [
            'tag' => 'plain_text',
            'content' => '📅 Lịch hẹn mới'
        ],
        'template' => 'blue'
    ],
    'elements' => [
        [
            'tag' => 'div',
            'text' => [
                'tag' => 'lark_md',
                'content' => '**Khách hàng:** Nguyễn Văn A\n**Thời gian:** 14:00 - 15:00\n**Dịch vụ:** Cắt tóc'
            ]
        ],
        [
            'tag' => 'action',
            'actions' => [
                [
                    'tag' => 'button',
                    'text' => [
                        'tag' => 'plain_text',
                        'content' => 'Xác nhận'
                    ],
                    'type' => 'primary',
                    'url' => 'https://yourdomain.com/confirm?id=123'
                ],
                [
                    'tag' => 'button',
                    'text' => [
                        'tag' => 'plain_text',
                        'content' => 'Từ chối'
                    ],
                    'type' => 'danger',
                    'url' => 'https://yourdomain.com/reject?id=123'
                ]
            ]
        ]
    ]
];

$result = Checkin_MKT192_Lark_Helper::send_interactive_message(
    'oc_xxxxxxxxxxxx',
    $card,
    'chat_id'
);
```

### Xử lý kết quả

```php
$result = Checkin_MKT192_Lark_Helper::send_text_message(...);

if (is_wp_error($result)) {
    // Có lỗi xảy ra
    error_log('Lark Error: ' . $result->get_error_message());
} else {
    // Thành công
    if ($result['code'] === 0) {
        // Tin nhắn đã được gửi thành công
        $message_id = $result['data']['message_id'];
    } else {
        // Có lỗi từ Lark API
        error_log('Lark API Error: ' . $result['msg']);
    }
}
```

## Lấy Chat ID / User ID

### Cách 1: Từ Lark Admin

1. Mở group chat trong Lark
2. Click vào tên group → Settings
3. Copy Chat ID

### Cách 2: Qua API

```php
// Cần có quyền im:chat để list chats
$token = Checkin_MKT192_Lark_Helper::get_access_token();
$url = 'https://open.larksuite.com/open-apis/im/v1/chats';

$response = wp_remote_get($url, [
    'headers' => [
        'Authorization' => 'Bearer ' . $token
    ]
]);

$body = json_decode(wp_remote_retrieve_body($response), true);
// $body['data']['items'] chứa danh sách chats
```

## Các loại Receive ID Type

- `chat_id` - Group chat ID (bắt đầu bằng `oc_`)
- `user_id` - User ID (bắt đầu bằng `ou_`)
- `open_id` - Open ID của user
- `union_id` - Union ID (dùng cho nhiều apps)
- `email` - Email của user

## Debug & Logging

Tất cả các hoạt động Lark đều được ghi log vào:

```
wp-content/plugins/checkin-mkt192-wp/includes/lark/logs/lark_untils_log.log
```

## Tài liệu tham khảo

- [Lark Open Platform Documentation](https://open.larksuite.com/document)
- [Send Messages API](https://open.larksuite.com/document/server-docs/im-v1/message/create)
- [Message Card Builder](https://open.larksuite.com/document/common-capabilities/message-card/message-cards-content/using-markdown-tags)
- [Interactive Components](https://open.larksuite.com/document/common-capabilities/message-card/add-card-interaction/interaction-overview)

## Lưu ý

1. **Tenant Access Token** được cache tự động trong 2 tiếng (thời gian expire từ Lark API)
2. App cần được **Published** và **Approved** trong organization để gửi tin nhắn
3. Bot cần được **added vào group** trước khi có thể gửi tin nhắn đến group đó
4. Rate limit: 50 requests/second/app (theo tài liệu Lark)

## Ví dụ thực tế

### Gửi thông báo khi có booking mới

```php
function send_booking_notification($booking_data) {
    if (!Checkin_MKT192_Lark_Helper::is_configured()) {
        return;
    }

    $chat_id = 'oc_xxxxxxxxxxxx'; // Group ID của team

    $message = sprintf(
        "🎯 Có booking mới!\n\n" .
        "👤 Khách hàng: %s\n" .
        "📞 Số điện thoại: %s\n" .
        "⏰ Thời gian: %s\n" .
        "💇 Dịch vụ: %s",
        $booking_data['customer_name'],
        $booking_data['phone'],
        $booking_data['time'],
        $booking_data['service']
    );

    Checkin_MKT192_Lark_Helper::send_notification(
        $chat_id,
        '📅 Booking mới',
        $message,
        'chat_id'
    );
}
```

### Gửi nhắc nhở định kỳ

```php
function send_daily_reminder() {
    if (!Checkin_MKT192_Lark_Helper::is_configured()) {
        return;
    }

    $chat_id = 'oc_xxxxxxxxxxxx';

    Checkin_MKT192_Lark_Helper::send_text_message(
        $chat_id,
        '⏰ Nhắc nhở: Đừng quên điểm danh hôm nay!',
        'chat_id'
    );
}

// Đăng ký cron job
add_action('init', function() {
    if (!wp_next_scheduled('daily_lark_reminder')) {
        wp_schedule_event(strtotime('08:00:00'), 'daily', 'daily_lark_reminder');
    }
});

add_action('daily_lark_reminder', 'send_daily_reminder');
```

## Troubleshooting

### Lỗi "app_ticket_invalid"

- App chưa được publish hoặc approve trong organization

### Lỗi "not_in_chat"

- Bot chưa được thêm vào group chat. Cần add bot vào group trước.

### Lỗi "insufficient_scope"

- Thiếu permissions. Kiểm tra lại permissions trong Developer Console.

### Token không hợp lệ

- Kiểm tra lại App ID và App Secret
- Xóa cache: `delete_transient('lark_tenant_access_token_' . md5($app_id))`

---

## OAuth Setup (Phương thức 2)

### Gửi tin nhắn dưới danh nghĩa Admin

Nếu bạn muốn tin nhắn hiển thị từ **tài khoản admin thật** (không phải bot), cần setup OAuth để lấy `user_access_token`.

#### Bước 1: Config OAuth trong Lark App

1. Vào [Lark Developer Console](https://open.larksuite.com/app) → Chọn app của bạn
2. Vào **Security Settings** → **Redirect URLs**
3. Thêm redirect URI: `https://yourdomain.com/wp-json/checkin-mkt192/v1/lark/oauth-callback`
4. **Lưu App ID, App Secret và Redirect URI**

#### Bước 2: Thêm thêm Scopes cho OAuth

Ngoài scopes ở trên, thêm:

- `im:message` (nếu chưa có)
- `im:chat` (để list groups)

**Lưu ý:** Không cần scope `im:message:send_as_bot` nếu chỉ dùng user token.

#### Bước 3: Authorization Flow

**A. Lấy Authorization Code (Manual - Admin làm 1 lần)**

Admin cần authorize app để lấy code:

```
https://open.larksuite.com/open-apis/authen/v1/authorize?
  app_id=YOUR_APP_ID&
  redirect_uri=https://yourdomain.com/wp-json/checkin-mkt192/v1/lark/oauth-callback&
  scope=im:message,im:chat&
  state=random_state_string
```

**B. Exchange Code cho Access Token**

Sau khi user authorize, Lark sẽ redirect về callback URI với `code` parameter:

```php
// WordPress REST API endpoint để xử lý callback
POST https://open.larksuite.com/open-apis/authen/v1/oauth_access_token

{
  "app_id": "YOUR_APP_ID",
  "app_secret": "YOUR_APP_SECRET",
  "grant_type": "authorization_code",
  "code": "AUTH_CODE_FROM_REDIRECT",
  "redirect_uri": "YOUR_REDIRECT_URI"
}

// Response:
{
  "access_token": "u-xxx...",  // User access token
  "refresh_token": "r-xxx...",  // Để refresh khi hết hạn
  "expires_in": 7200,  // 2 giờ
  "token_type": "Bearer"
}
```

**C. Lưu User Access Token**

Token cần được lưu an toàn trong database và refresh định kỳ (mỗi 2 giờ).

#### Bước 4: Gửi tin nhắn với User Access Token

```php
// Thay vì dùng tenant_access_token, dùng user_access_token
$url = 'https://open.larksuite.com/open-apis/im/v1/messages?receive_id_type=chat_id';

$headers = [
    'Authorization' => 'Bearer ' . $user_access_token,  // User token thay vì tenant token
    'Content-Type' => 'application/json'
];

$payload = [
    'receive_id' => 'oc_xxxxxxxxxxxx',
    'msg_type' => 'text',
    'content' => json_encode(['text' => 'Tin nhắn từ Admin'])
];

$response = wp_remote_post($url, [
    'headers' => $headers,
    'body' => json_encode($payload)
]);

// Tin nhắn sẽ hiển thị từ tài khoản admin, không phải bot
```

#### Bước 5: Refresh Token khi hết hạn

```php
POST https://open.larksuite.com/open-apis/authen/v1/oauth_access_token

{
  "app_id": "YOUR_APP_ID",
  "app_secret": "YOUR_APP_SECRET",
  "grant_type": "refresh_token",
  "refresh_token": "SAVED_REFRESH_TOKEN"
}

// Response: New access_token và refresh_token
```

### Implementation trong Plugin (Coming Soon)

Hiện tại plugin đã hỗ trợ **Bot Identity** (Phương thức 1). Để hỗ trợ **Admin Identity** (Phương thức 2), cần implement:

1. **UI Settings mới:**

   - Toggle chọn "Bot Mode" vs "Admin Mode"
   - Button "Authorize with Lark" để bắt đầu OAuth flow
   - Hiển thị trạng thái token (còn hạn hay hết hạn)

2. **Backend:**

   - OAuth callback endpoint
   - Token storage và refresh logic
   - Helper methods sử dụng user_access_token

3. **Helper Class mở rộng:**

   ```php
   // Gửi as admin
   Checkin_MKT192_Lark_Helper::send_as_admin($chat_id, $message);

   // Gửi as bot (hiện tại)
   Checkin_MKT192_Lark_Helper::send_as_bot($chat_id, $message);
   ```

### So sánh hai phương thức

| Tiêu chí              | Bot Identity            | Admin Identity                        |
| --------------------- | ----------------------- | ------------------------------------- |
| **Độ phức tạp**       | ⭐ Đơn giản             | ⭐⭐⭐ Phức tạp                       |
| **Setup**             | App ID + Secret         | OAuth flow + Token refresh            |
| **Hiển thị từ**       | Bot App                 | Admin account                         |
| **Cần add vào group** | ✅ Có                   | ❌ Không (nếu admin đã là thành viên) |
| **Token lifetime**    | 2 giờ (auto refresh)    | 2 giờ (cần refresh manual)            |
| **Rate limit**        | 50 req/sec/app          | 100 req/hour/user                     |
| **Use case**          | Alerts, reports tự động | Thông báo quan trọng cần authority    |

### Khuyến nghị

- **Mặc định dùng Bot Identity** (Phương thức 1) cho hầu hết use cases
- **Chỉ dùng Admin Identity** (Phương thức 2) khi:
  - Tin nhắn cần sự xác thực/authority của admin
  - Không muốn user biết đây là tin tự động
  - Group không cho phép thêm bot

---

## 📚 Tài liệu Lark API (2025)

### Official Documentation

- [Lark Open Platform](https://open.larksuite.com/document)
- [Authentication Guide](https://open.larksuite.com/document/server-docs/getting-started/authenticate-api-calls)
- [Send Messages API](https://open.larksuite.com/document/server-docs/im-v1/message/create)
- [Message Card Builder](https://open.larksuite.com/document/common-capabilities/message-card/message-cards-content/using-markdown-tags)
- [OAuth 2.0 Guide](https://open.larksuite.com/document/server-docs/api-call-guide/server-api-guide/oauth-2-0)

### Key Changes in 2025

- API endpoints vẫn giữ nguyên (`/im/v1/messages`)
- OAuth flow không thay đổi so với 2024
- Rate limits được tăng lên: 50 req/sec (bot), 100 req/hour (user)
- Hỗ trợ tốt hơn cho interactive components và webhooks

### Differences: Bot vs User Token

**Tenant Access Token (Bot):**

```
POST /open-apis/auth/v3/tenant_access_token/internal
Body: { "app_id": "...", "app_secret": "..." }
→ Gets: tenant_access_token (2 hours)
→ Messages appear from: Bot App
```

**User Access Token (Admin):**

```
OAuth Flow:
1. User authorizes via browser
2. Exchange code for access_token
3. Refresh every 2 hours
→ Messages appear from: Admin User Account
```
