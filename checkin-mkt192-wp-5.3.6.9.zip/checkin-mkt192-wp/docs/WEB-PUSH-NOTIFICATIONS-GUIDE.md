# 🔔 WEB PUSH NOTIFICATIONS - HƯỚNG DẪN TRIỂN KHAI

**Ngày tạo:** 15/12/2024
**Plugin:** Checkin MKT192 WP v5.1.7.4.7
**Mục đích:** Thêm Push Notifications giống app mobile vào WordPress

---

## 📋 TỔNG QUAN

### 🎯 Mục tiêu

Hiển thị **Push Notifications** trên trình duyệt với:

- ✅ Thông báo hiển thị trên màn hình (notification banner)
- ✅ Âm thanh thông báo (notification sound)
- ✅ Icon, hình ảnh, actions
- ✅ Click vào notification để mở trang
- ✅ Hoạt động ngay cả khi đóng trình duyệt (background)

### 🔧 Công nghệ sử dụng

1. **Service Workers** - Background script
2. **Web Push API** - Push notifications từ server
3. **Notification API** - Hiển thị notifications
4. **VAPID Protocol** - Bảo mật push messages

---

## 🏗️ KIẾN TRÚC TỔNG QUÁT

```
┌─────────────────────────────────────────────────────┐
│                   USER BROWSER                       │
│                                                      │
│  ┌──────────────────────────────────────────────┐  │
│  │         Service Worker (SW)                   │  │
│  │  - Chạy background                            │  │
│  │  - Lắng nghe push events                      │  │
│  │  - Hiển thị notifications                     │  │
│  └──────────────────────────────────────────────┘  │
│                      ↑                               │
│                      │ Push Message                 │
└──────────────────────┼──────────────────────────────┘
                       │
                       │
┌──────────────────────┼──────────────────────────────┐
│                      ↓                               │
│            PUSH SERVICE PROVIDER                     │
│  - Google FCM (Chrome, Edge)                         │
│  - Mozilla Push Service (Firefox)                    │
│  - Apple Push Notification (Safari)                  │
└──────────────────────┬──────────────────────────────┘
                       ↑
                       │ Send Push
┌──────────────────────┼──────────────────────────────┐
│                      │                               │
│            YOUR WORDPRESS SERVER                     │
│  ┌────────────────────────────────────────────────┐ │
│  │  Push Notification Plugin/System                │ │
│  │  - Lưu subscriptions                            │ │
│  │  - Gửi push qua VAPID                           │ │
│  │  - Trigger: booking, invoice, review...         │ │
│  └────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────┘
```

---

## 📦 YÊU CẦU TRIỂN KHAI

### 1. SSL Certificate (HTTPS)

⚠️ **BẮT BUỘC** - Service Workers chỉ hoạt động trên HTTPS

```
✅ https://yourdomain.com
❌ http://yourdomain.com (không hoạt động)
```

### 2. Browser Support

| Browser    | Support | Version          |
| ---------- | ------- | ---------------- |
| Chrome     | ✅      | 42+              |
| Firefox    | ✅      | 44+              |
| Edge       | ✅      | 17+              |
| Safari     | ✅      | 16+ (macOS 13+)  |
| Opera      | ✅      | 29+              |
| iOS Safari | ⚠️      | 16.4+ (PWA only) |

### 3. User Permission

- User phải **cho phép notifications** (popup request)

---

## 🚀 TRIỂN KHAI TỪNG BƯỚC

## BƯỚC 1: Tạo Service Worker

### File: `frontend/assets/js/sw-push-notifications.js`

```javascript
/**
 * Service Worker for Push Notifications
 * File: /wp-content/plugins/checkin-mkt192-wp/frontend/assets/js/sw-push-notifications.js
 */

// Version để cache busting
const SW_VERSION = 'v1.0.0';

// Install event
self.addEventListener('install', (event) => {
  console.log('[Service Worker] Installing...', SW_VERSION);
  self.skipWaiting(); // Activate immediately
});

// Activate event
self.addEventListener('activate', (event) => {
  console.log('[Service Worker] Activating...', SW_VERSION);
  event.waitUntil(self.clients.claim()); // Take control immediately
});

// Listen for push events
self.addEventListener('push', (event) => {
  console.log('[Service Worker] Push received:', event);

  // Default notification data
  let notificationData = {
    title: 'Thông báo mới',
    body: 'Bạn có thông báo mới từ salon',
    icon: '/wp-content/plugins/checkin-mkt192-wp/frontend/assets/images/icon-192x192.png',
    badge: '/wp-content/plugins/checkin-mkt192-wp/frontend/assets/images/badge-72x72.png',
    image: null,
    tag: 'default-notification',
    requireInteraction: false,
    silent: false,
    vibrate: [200, 100, 200],
    data: {
      url: '/',
      timestamp: Date.now(),
    },
    actions: [],
  };

  // Parse push data if available
  if (event.data) {
    try {
      const payload = event.data.json();
      notificationData = { ...notificationData, ...payload };
    } catch (e) {
      notificationData.body = event.data.text();
    }
  }

  // Show notification
  event.waitUntil(
    self.registration.showNotification(notificationData.title, {
      body: notificationData.body,
      icon: notificationData.icon,
      badge: notificationData.badge,
      image: notificationData.image,
      tag: notificationData.tag,
      requireInteraction: notificationData.requireInteraction,
      silent: notificationData.silent,
      vibrate: notificationData.vibrate,
      data: notificationData.data,
      actions: notificationData.actions,
    })
  );
});

// Listen for notification click
self.addEventListener('notificationclick', (event) => {
  console.log('[Service Worker] Notification clicked:', event);

  // Close notification
  event.notification.close();

  // Get URL from notification data
  const urlToOpen = event.notification.data?.url || '/';

  // Open URL
  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      // Check if window is already open
      for (let client of clientList) {
        if (client.url === urlToOpen && 'focus' in client) {
          return client.focus();
        }
      }
      // Open new window if not found
      if (clients.openWindow) {
        return clients.openWindow(urlToOpen);
      }
    })
  );
});

// Listen for notification close
self.addEventListener('notificationclose', (event) => {
  console.log('[Service Worker] Notification closed:', event);

  // Track notification closed (optional)
  // Can send analytics here
});
```

---

## BƯỚC 2: Đăng ký Service Worker

### File: `frontend/assets/js/components/push-notification-manager.js`

```javascript
/**
 * Push Notification Manager
 * File: /wp-content/plugins/checkin-mkt192-wp/frontend/assets/js/components/push-notification-manager.js
 */

class PushNotificationManager {
  constructor() {
    this.swPath =
      '/wp-content/plugins/checkin-mkt192-wp/frontend/assets/js/sw-push-notifications.js';
    this.vapidPublicKey = null; // Sẽ load từ server
    this.apiEndpoint = window.checkinMKT192?.apiUrl || '/wp-json/vg/v1';
    this.isSupported = this.checkSupport();
    this.registration = null;
    this.subscription = null;
  }

  /**
   * Check browser support
   */
  checkSupport() {
    if (!('serviceWorker' in navigator)) {
      console.warn('Service Workers not supported');
      return false;
    }
    if (!('PushManager' in window)) {
      console.warn('Push API not supported');
      return false;
    }
    if (!('Notification' in window)) {
      console.warn('Notification API not supported');
      return false;
    }
    return true;
  }

  /**
   * Initialize push notifications
   */
  async init() {
    if (!this.isSupported) {
      console.log('Push notifications not supported');
      return false;
    }

    try {
      // Get VAPID public key from server
      await this.loadVapidKey();

      // Register service worker
      this.registration = await navigator.serviceWorker.register(this.swPath, {
        scope: '/',
      });

      console.log('Service Worker registered:', this.registration);

      // Wait for service worker to be ready
      await navigator.serviceWorker.ready;

      return true;
    } catch (error) {
      console.error('Failed to initialize push notifications:', error);
      return false;
    }
  }

  /**
   * Load VAPID public key from server
   */
  async loadVapidKey() {
    try {
      const response = await fetch(`${this.apiEndpoint}/push-notifications/vapid-key`);
      const data = await response.json();
      this.vapidPublicKey = data.publicKey;
    } catch (error) {
      console.error('Failed to load VAPID key:', error);
      throw error;
    }
  }

  /**
   * Request notification permission
   */
  async requestPermission() {
    if (!this.isSupported) {
      return 'denied';
    }

    const permission = await Notification.requestPermission();
    console.log('Notification permission:', permission);
    return permission;
  }

  /**
   * Subscribe to push notifications
   */
  async subscribe() {
    if (!this.registration) {
      await this.init();
    }

    // Check permission
    const permission = await this.requestPermission();
    if (permission !== 'granted') {
      throw new Error('Notification permission denied');
    }

    try {
      // Get existing subscription
      let subscription = await this.registration.pushManager.getSubscription();

      // If no subscription, create new one
      if (!subscription) {
        const vapidKey = this.urlBase64ToUint8Array(this.vapidPublicKey);
        subscription = await this.registration.pushManager.subscribe({
          userVisibleOnly: true,
          applicationServerKey: vapidKey,
        });
      }

      this.subscription = subscription;

      // Send subscription to server
      await this.saveSubscriptionToServer(subscription);

      console.log('Push subscription successful:', subscription);
      return subscription;
    } catch (error) {
      console.error('Failed to subscribe:', error);
      throw error;
    }
  }

  /**
   * Unsubscribe from push notifications
   */
  async unsubscribe() {
    if (!this.registration) {
      return;
    }

    try {
      const subscription = await this.registration.pushManager.getSubscription();
      if (subscription) {
        await subscription.unsubscribe();
        await this.deleteSubscriptionFromServer(subscription);
        this.subscription = null;
        console.log('Unsubscribed from push notifications');
      }
    } catch (error) {
      console.error('Failed to unsubscribe:', error);
      throw error;
    }
  }

  /**
   * Save subscription to WordPress server
   */
  async saveSubscriptionToServer(subscription) {
    try {
      const response = await fetch(`${this.apiEndpoint}/push-notifications/subscribe`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${this.getAuthToken()}`,
        },
        body: JSON.stringify({
          subscription: subscription.toJSON(),
          user_agent: navigator.userAgent,
          user_id: window.checkinMKT192?.userId || null,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to save subscription');
      }

      return await response.json();
    } catch (error) {
      console.error('Failed to save subscription to server:', error);
      throw error;
    }
  }

  /**
   * Delete subscription from server
   */
  async deleteSubscriptionFromServer(subscription) {
    try {
      const response = await fetch(`${this.apiEndpoint}/push-notifications/unsubscribe`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${this.getAuthToken()}`,
        },
        body: JSON.stringify({
          endpoint: subscription.endpoint,
        }),
      });

      return await response.json();
    } catch (error) {
      console.error('Failed to delete subscription from server:', error);
      throw error;
    }
  }

  /**
   * Get current subscription status
   */
  async getSubscriptionStatus() {
    if (!this.isSupported) {
      return { supported: false, subscribed: false };
    }

    if (!this.registration) {
      await this.init();
    }

    const subscription = await this.registration.pushManager.getSubscription();
    const permission = Notification.permission;

    return {
      supported: true,
      subscribed: !!subscription,
      permission: permission,
      subscription: subscription?.toJSON() || null,
    };
  }

  /**
   * Show local notification (not push)
   */
  async showLocalNotification(title, options = {}) {
    if (!this.isSupported) {
      console.warn('Notifications not supported');
      return;
    }

    const permission = await this.requestPermission();
    if (permission !== 'granted') {
      console.warn('Notification permission not granted');
      return;
    }

    if (!this.registration) {
      await this.init();
    }

    const defaultOptions = {
      body: '',
      icon: '/wp-content/plugins/checkin-mkt192-wp/frontend/assets/images/icon-192x192.png',
      badge: '/wp-content/plugins/checkin-mkt192-wp/frontend/assets/images/badge-72x72.png',
      vibrate: [200, 100, 200],
      tag: 'local-notification',
      requireInteraction: false,
      silent: false,
      data: {
        url: window.location.href,
        timestamp: Date.now(),
      },
    };

    await this.registration.showNotification(title, {
      ...defaultOptions,
      ...options,
    });
  }

  /**
   * Utility: Convert VAPID key
   */
  urlBase64ToUint8Array(base64String) {
    const padding = '='.repeat((4 - (base64String.length % 4)) % 4);
    const base64 = (base64String + padding).replace(/\-/g, '+').replace(/_/g, '/');

    const rawData = window.atob(base64);
    const outputArray = new Uint8Array(rawData.length);

    for (let i = 0; i < rawData.length; ++i) {
      outputArray[i] = rawData.charCodeAt(i);
    }
    return outputArray;
  }

  /**
   * Get auth token from localStorage
   */
  getAuthToken() {
    return localStorage.getItem('checkin_auth_token') || '';
  }
}

// Export global instance
window.PushNotificationManager = new PushNotificationManager();
```

---

## BƯỚC 3: Backend API Endpoints

### File: `includes/rest-api/push-notifications-api.php`

```php
<?php
/**
 * Push Notifications API
 * File: /wp-content/plugins/checkin-mkt192-wp/includes/rest-api/push-notifications-api.php
 */

if (!defined('ABSPATH')) {
    exit;
}

// Register REST API routes
add_action('rest_api_init', function () {
    // Get VAPID public key
    register_rest_route('vg/v1', '/push-notifications/vapid-key', [
        'methods'             => 'GET',
        'callback'            => 'checkin_mkt192_get_vapid_public_key',
        'permission_callback' => '__return_true' // Public
    ]);

    // Subscribe to push notifications
    register_rest_route('vg/v1', '/push-notifications/subscribe', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_push_subscribe',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login'])
    ]);

    // Unsubscribe from push notifications
    register_rest_route('vg/v1', '/push-notifications/unsubscribe', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_push_unsubscribe',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login'])
    ]);

    // Send test notification
    register_rest_route('vg/v1', '/push-notifications/test', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_push_test',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'admin'])
    ]);
});

/**
 * Get VAPID public key
 */
function checkin_mkt192_get_vapid_public_key($request) {
    $public_key = get_option('checkin_vapid_public_key', '');

    // Generate keys if not exists
    if (empty($public_key)) {
        $keys = checkin_mkt192_generate_vapid_keys();
        $public_key = $keys['publicKey'];
    }

    return rest_ensure_response([
        'success'   => true,
        'publicKey' => $public_key
    ]);
}

/**
 * Subscribe to push notifications
 */
function checkin_mkt192_push_subscribe($request) {
    global $wpdb;

    $params       = json_decode($request->get_body(), true);
    $subscription = $params['subscription'] ?? null;
    $user_agent   = $params['user_agent'] ?? '';
    $user_id      = $params['user_id'] ?? get_current_user_id();

    if (!$subscription || !isset($subscription['endpoint'])) {
        return new WP_Error('invalid_subscription', 'Invalid subscription data', ['status' => 400]);
    }

    $table = $wpdb->prefix . 'checkin_mkt192_push_subscriptions';

    // Check if subscription exists
    $exists = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM $table WHERE endpoint = %s",
        $subscription['endpoint']
    ));

    if ($exists) {
        // Update existing subscription
        $wpdb->update(
            $table,
            [
                'user_id'       => $user_id,
                'subscription'  => json_encode($subscription),
                'user_agent'    => $user_agent,
                'updated_at'    => current_time('mysql')
            ],
            ['endpoint' => $subscription['endpoint']],
            ['%d', '%s', '%s', '%s'],
            ['%s']
        );
    } else {
        // Insert new subscription
        $wpdb->insert(
            $table,
            [
                'user_id'      => $user_id,
                'endpoint'     => $subscription['endpoint'],
                'subscription' => json_encode($subscription),
                'user_agent'   => $user_agent,
                'created_at'   => current_time('mysql'),
                'updated_at'   => current_time('mysql')
            ],
            ['%d', '%s', '%s', '%s', '%s', '%s']
        );
    }

    return rest_ensure_response([
        'success' => true,
        'message' => 'Subscription saved successfully'
    ]);
}

/**
 * Unsubscribe from push notifications
 */
function checkin_mkt192_push_unsubscribe($request) {
    global $wpdb;

    $params   = json_decode($request->get_body(), true);
    $endpoint = $params['endpoint'] ?? null;

    if (!$endpoint) {
        return new WP_Error('invalid_endpoint', 'Invalid endpoint', ['status' => 400]);
    }

    $table = $wpdb->prefix . 'checkin_mkt192_push_subscriptions';

    $wpdb->delete($table, ['endpoint' => $endpoint], ['%s']);

    return rest_ensure_response([
        'success' => true,
        'message' => 'Unsubscribed successfully'
    ]);
}

/**
 * Send test notification
 */
function checkin_mkt192_push_test($request) {
    $user_id = get_current_user_id();

    $result = checkin_mkt192_send_push_notification($user_id, [
        'title' => 'Test Notification',
        'body'  => 'This is a test push notification!',
        'icon'  => '/wp-content/plugins/checkin-mkt192-wp/frontend/assets/images/icon-192x192.png',
        'data'  => [
            'url' => home_url('/user-profile')
        ]
    ]);

    if ($result['success']) {
        return rest_ensure_response([
            'success' => true,
            'message' => 'Test notification sent successfully',
            'sent'    => $result['sent']
        ]);
    } else {
        return new WP_Error('send_failed', $result['message'], ['status' => 500]);
    }
}

/**
 * Generate VAPID keys
 */
function checkin_mkt192_generate_vapid_keys() {
    require_once CHECKIN_PLUGIN_DIR . 'vendor/autoload.php'; // Minishlink/WebPush library

    $auth = \Minishlink\WebPush\VAPID::createVapidKeys();

    update_option('checkin_vapid_public_key', $auth['publicKey']);
    update_option('checkin_vapid_private_key', $auth['privateKey']);

    return $auth;
}

/**
 * Send push notification to user(s)
 *
 * @param int|array $user_ids User ID or array of user IDs
 * @param array $notification_data Notification data
 * @return array Result
 */
function checkin_mkt192_send_push_notification($user_ids, $notification_data) {
    global $wpdb;

    if (!is_array($user_ids)) {
        $user_ids = [$user_ids];
    }

    $table = $wpdb->prefix . 'checkin_mkt192_push_subscriptions';

    // Get subscriptions for users
    $placeholders = implode(',', array_fill(0, count($user_ids), '%d'));
    $subscriptions = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM $table WHERE user_id IN ($placeholders)",
        ...$user_ids
    ));

    if (empty($subscriptions)) {
        return [
            'success' => false,
            'message' => 'No subscriptions found',
            'sent'    => 0
        ];
    }

    require_once CHECKIN_PLUGIN_DIR . 'vendor/autoload.php';

    $auth = [
        'VAPID' => [
            'subject'    => home_url(),
            'publicKey'  => get_option('checkin_vapid_public_key'),
            'privateKey' => get_option('checkin_vapid_private_key')
        ]
    ];

    $webPush = new \Minishlink\WebPush\WebPush($auth);

    $sent = 0;
    $failed = 0;

    foreach ($subscriptions as $sub) {
        $subscription = json_decode($sub->subscription, true);

        try {
            $report = $webPush->sendOneNotification(
                \Minishlink\WebPush\Subscription::create($subscription),
                json_encode($notification_data)
            );

            if ($report->isSuccess()) {
                $sent++;
            } else {
                $failed++;
                error_log('Push notification failed: ' . $report->getReason());

                // Delete expired subscriptions
                if ($report->isSubscriptionExpired()) {
                    $wpdb->delete($table, ['id' => $sub->id], ['%d']);
                }
            }
        } catch (Exception $e) {
            $failed++;
            error_log('Push notification error: ' . $e->getMessage());
        }
    }

    return [
        'success' => $sent > 0,
        'message' => "Sent $sent notifications, $failed failed",
        'sent'    => $sent,
        'failed'  => $failed
    ];
}

/**
 * Create push subscriptions table
 */
function checkin_mkt192_create_push_subscriptions_table() {
    global $wpdb;
    $table_name      = $wpdb->prefix . 'checkin_mkt192_push_subscriptions';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT(20) UNSIGNED NOT NULL,
        endpoint TEXT NOT NULL,
        subscription LONGTEXT NOT NULL,
        user_agent VARCHAR(500) DEFAULT NULL,
        created_at DATETIME NOT NULL,
        updated_at DATETIME NOT NULL,
        PRIMARY KEY  (id),
        KEY idx_user_id (user_id)
    ) $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}

// Add to activation hook
add_action('checkin_mkt192_activation', 'checkin_mkt192_create_push_subscriptions_table');
```

---

## BƯỚC 4: Tích hợp vào UI

### File: `frontend/pages/user-profile.html` (Example)

```html
<!-- Push Notification Settings Section -->
<div class="settings-card">
  <h3>🔔 Cài đặt thông báo</h3>

  <div class="notification-status">
    <p id="notification-status-text">Đang kiểm tra...</p>
  </div>

  <button id="btn-enable-notifications" class="btn btn-primary" style="display:none;">
    Bật thông báo
  </button>

  <button id="btn-disable-notifications" class="btn btn-secondary" style="display:none;">
    Tắt thông báo
  </button>

  <button id="btn-test-notification" class="btn btn-info" style="display:none;">
    Gửi thông báo thử
  </button>
</div>

<script>
  // Initialize when page loads
  document.addEventListener('DOMContentLoaded', async () => {
    const pushManager = window.PushNotificationManager;

    // Initialize
    await pushManager.init();

    // Check status
    const status = await pushManager.getSubscriptionStatus();
    updateUI(status);

    // Enable button click
    document.getElementById('btn-enable-notifications').addEventListener('click', async () => {
      try {
        await pushManager.subscribe();
        const status = await pushManager.getSubscriptionStatus();
        updateUI(status);
        alert('Đã bật thông báo thành công!');
      } catch (error) {
        alert('Không thể bật thông báo: ' + error.message);
      }
    });

    // Disable button click
    document.getElementById('btn-disable-notifications').addEventListener('click', async () => {
      try {
        await pushManager.unsubscribe();
        const status = await pushManager.getSubscriptionStatus();
        updateUI(status);
        alert('Đã tắt thông báo!');
      } catch (error) {
        alert('Lỗi: ' + error.message);
      }
    });

    // Test button click
    document.getElementById('btn-test-notification').addEventListener('click', async () => {
      try {
        const response = await fetch('/wp-json/vg/v1/push-notifications/test', {
          method: 'POST',
          headers: {
            Authorization: 'Bearer ' + localStorage.getItem('checkin_auth_token'),
          },
        });
        const data = await response.json();
        alert(data.message);
      } catch (error) {
        alert('Lỗi: ' + error.message);
      }
    });

    function updateUI(status) {
      const statusText = document.getElementById('notification-status-text');
      const btnEnable = document.getElementById('btn-enable-notifications');
      const btnDisable = document.getElementById('btn-disable-notifications');
      const btnTest = document.getElementById('btn-test-notification');

      if (!status.supported) {
        statusText.textContent = '❌ Trình duyệt không hỗ trợ thông báo';
        btnEnable.style.display = 'none';
        btnDisable.style.display = 'none';
        btnTest.style.display = 'none';
      } else if (status.permission === 'denied') {
        statusText.textContent = '🚫 Bạn đã từ chối quyền thông báo';
        btnEnable.style.display = 'none';
        btnDisable.style.display = 'none';
        btnTest.style.display = 'none';
      } else if (status.subscribed) {
        statusText.textContent = '✅ Thông báo đang được bật';
        btnEnable.style.display = 'none';
        btnDisable.style.display = 'inline-block';
        btnTest.style.display = 'inline-block';
      } else {
        statusText.textContent = '⚪ Thông báo chưa được bật';
        btnEnable.style.display = 'inline-block';
        btnDisable.style.display = 'none';
        btnTest.style.display = 'none';
      }
    }
  });
</script>
```

---

## BƯỚC 5: Gửi Push từ Backend

### Example: Gửi thông báo khi có booking mới

```php
<?php
// File: includes/rest-api/booking-api.php

// Trong function tạo booking
function checkin_mkt192_create_booking_api($request) {
    // ... existing booking creation code ...

    // After successful booking, send push notification to staff
    $staff_user_id = get_staff_user_id($hairdresser_name); // Get WordPress user ID

    if ($staff_user_id) {
        checkin_mkt192_send_push_notification($staff_user_id, [
            'title' => '📅 Booking mới',
            'body'  => "Khách hàng {$customer_name} đặt lịch lúc {$booking_time}",
            'icon'  => '/wp-content/plugins/checkin-mkt192-wp/frontend/assets/images/icon-192x192.png',
            'badge' => '/wp-content/plugins/checkin-mkt192-wp/frontend/assets/images/badge-72x72.png',
            'tag'   => 'booking-' . $booking_id,
            'requireInteraction' => true,
            'vibrate' => [200, 100, 200, 100, 200],
            'data'  => [
                'url' => home_url('/app-tho?view=bookings'),
                'booking_id' => $booking_id
            ],
            'actions' => [
                [
                    'action' => 'view',
                    'title'  => 'Xem chi tiết'
                ],
                [
                    'action' => 'close',
                    'title'  => 'Đóng'
                ]
            ]
        ]);
    }

    // ... rest of code ...
}
```

---

## 🔊 THÊM ÂM THANH CHO NOTIFICATION

### Cách 1: Sử dụng âm thanh hệ thống (Default)

```javascript
// Trong Service Worker
self.registration.showNotification(title, {
  // ...
  silent: false, // Bật âm thanh mặc định
  vibrate: [200, 100, 200], // + Rung
});
```

### Cách 2: Custom âm thanh (Play trong page)

**Lưu ý:** Service Worker không thể play audio trực tiếp. Phải play trong main thread.

```javascript
// File: frontend/assets/js/components/push-notification-manager.js

// Thêm vào class PushNotificationManager

playNotificationSound() {
    const audio = new Audio('/wp-content/plugins/checkin-mkt192-wp/frontend/assets/sounds/notification.mp3');
    audio.volume = 0.5;
    audio.play().catch(err => console.log('Cannot play sound:', err));
}

// Listen for push event trong main page
navigator.serviceWorker.addEventListener('message', (event) => {
    if (event.data.type === 'PUSH_RECEIVED') {
        this.playNotificationSound();
    }
});
```

**Service Worker cập nhật:**

```javascript
// sw-push-notifications.js
self.addEventListener('push', (event) => {
  // ... existing code ...

  // Notify main thread
  event.waitUntil(
    self.clients.matchAll().then((clients) => {
      clients.forEach((client) => {
        client.postMessage({
          type: 'PUSH_RECEIVED',
          data: notificationData,
        });
      });
    })
  );
});
```

---

## 📦 CÀI ĐẶT DEPENDENCIES - 2 CÁCH

### ⚠️ VẤN ĐỀ VỚI COMPOSER

**Nhược điểm:**

- ❌ Thư mục `vendor/` rất nặng (~5-10 MB)
- ❌ Mỗi lần update plugin phải include cả vendor
- ❌ Upload lên server lâu (hàng ngàn files)
- ❌ Git conflict khi làm team

**Kích thước:**

```
vendor/
├── minishlink/web-push/     ~500 KB
├── web-token/jwt-*          ~3 MB
├── symfony/*                ~2 MB
├── psr/*                    ~100 KB
└── ... (dependencies khác)
TỔNG: ~5-8 MB, 1000+ files
```

---

### ✅ GIẢI PHÁP 1: KHÔNG DÙNG COMPOSER (Khuyến nghị)

Viết code PHP thuần để gửi Web Push, không cần library:

#### File: `includes/class-web-push-sender.php`

```php
<?php
/**
 * Web Push Sender - Lightweight implementation
 * Không cần Composer, chỉ dùng PHP thuần
 */

if (!defined('ABSPATH')) {
    exit;
}

class Checkin_MKT192_Web_Push_Sender {

    private $vapid_public_key;
    private $vapid_private_key;
    private $vapid_subject;

    public function __construct() {
        $this->vapid_public_key = get_option('checkin_vapid_public_key');
        $this->vapid_private_key = get_option('checkin_vapid_private_key');
        $this->vapid_subject = home_url();
    }

    /**
     * Generate VAPID keys (chỉ chạy 1 lần)
     */
    public static function generate_vapid_keys() {
        // Sử dụng OpenSSL để tạo keys
        $config = [
            'private_key_type' => OPENSSL_KEYTYPE_EC,
            'curve_name' => 'prime256v1',
        ];

        $private_key_resource = openssl_pkey_new($config);
        $private_key_details = openssl_pkey_get_details($private_key_resource);

        // Export private key
        openssl_pkey_export($private_key_resource, $private_key_pem);

        // Get public key
        $public_key_pem = $private_key_details['key'];

        // Convert to base64url format
        $private_key_base64 = self::pem_to_base64url($private_key_pem);
        $public_key_base64 = self::der_to_base64url($private_key_details['ec']['key']);

        $keys = [
            'publicKey' => $public_key_base64,
            'privateKey' => $private_key_base64,
        ];

        // Save to database
        update_option('checkin_vapid_public_key', $keys['publicKey']);
        update_option('checkin_vapid_private_key', $keys['privateKey']);

        return $keys;
    }

    /**
     * Send push notification
     *
     * @param array $subscription Push subscription
     * @param array $payload Notification data
     * @return bool Success
     */
    public function send($subscription, $payload) {
        if (!is_array($subscription) || empty($subscription['endpoint'])) {
            return false;
        }

        try {
            // Parse endpoint
            $endpoint = $subscription['endpoint'];
            $auth = $subscription['keys']['auth'] ?? '';
            $p256dh = $subscription['keys']['p256dh'] ?? '';

            if (empty($auth) || empty($p256dh)) {
                throw new Exception('Missing subscription keys');
            }

            // Prepare payload
            $payload_json = json_encode($payload);

            // Encrypt payload
            $encrypted = $this->encrypt_payload($payload_json, $p256dh, $auth);

            // Generate VAPID JWT
            $vapid_header = $this->generate_vapid_jwt($endpoint);

            // Send HTTP request
            $response = $this->send_http_request(
                $endpoint,
                $encrypted['ciphertext'],
                $encrypted['salt'],
                $encrypted['public_key'],
                $vapid_header
            );

            return $response['success'];

        } catch (Exception $e) {
            error_log('Web Push Send Error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Encrypt payload for Web Push
     */
    private function encrypt_payload($payload, $user_public_key, $user_auth) {
        // Decode base64url keys
        $user_public_key_decoded = self::base64url_decode($user_public_key);
        $user_auth_decoded = self::base64url_decode($user_auth);

        // Generate server keys
        $server_key = openssl_pkey_new([
            'private_key_type' => OPENSSL_KEYTYPE_EC,
            'curve_name' => 'prime256v1',
        ]);

        $server_key_details = openssl_pkey_get_details($server_key);
        $server_public_key = $server_key_details['ec']['key'];

        // Compute shared secret using ECDH
        $shared_secret = openssl_pkey_derive(
            $user_public_key_decoded,
            $server_key,
            65 // Key length for P-256
        );

        // Generate salt
        $salt = random_bytes(16);

        // Derive encryption key
        $encryption_key = $this->hkdf(
            $user_auth_decoded . $shared_secret,
            $salt,
            'Content-Encoding: aes128gcm' . "\0",
            32
        );

        // Derive nonce
        $nonce = $this->hkdf(
            $user_auth_decoded . $shared_secret,
            $salt,
            'Content-Encoding: nonce' . "\0",
            12
        );

        // Add padding to payload
        $padded_payload = pack('n*', strlen($payload)) . $payload;

        // Encrypt with AES-128-GCM
        $ciphertext = openssl_encrypt(
            $padded_payload,
            'aes-128-gcm',
            $encryption_key,
            OPENSSL_RAW_DATA,
            $nonce,
            $tag
        );

        return [
            'ciphertext' => $ciphertext . $tag,
            'salt' => base64_encode($salt),
            'public_key' => base64_encode($server_public_key),
        ];
    }

    /**
     * Generate VAPID JWT token
     */
    private function generate_vapid_jwt($endpoint) {
        // Parse endpoint to get audience
        $url_parts = parse_url($endpoint);
        $audience = $url_parts['scheme'] . '://' . $url_parts['host'];

        // JWT Header
        $header = [
            'typ' => 'JWT',
            'alg' => 'ES256',
        ];

        // JWT Payload
        $payload = [
            'aud' => $audience,
            'exp' => time() + 43200, // 12 hours
            'sub' => 'mailto:' . get_option('admin_email'),
        ];

        // Encode
        $header_encoded = self::base64url_encode(json_encode($header));
        $payload_encoded = self::base64url_encode(json_encode($payload));
        $data = $header_encoded . '.' . $payload_encoded;

        // Sign with private key
        $private_key = openssl_pkey_get_private($this->vapid_private_key);
        openssl_sign($data, $signature, $private_key, OPENSSL_ALGO_SHA256);

        $signature_encoded = self::base64url_encode($signature);

        return $data . '.' . $signature_encoded;
    }

    /**
     * Send HTTP request to push service
     */
    private function send_http_request($endpoint, $ciphertext, $salt, $server_public_key, $vapid_jwt) {
        $headers = [
            'Content-Type: application/octet-stream',
            'Content-Encoding: aes128gcm',
            'Authorization: vapid t=' . $vapid_jwt . ', k=' . $this->vapid_public_key,
            'Crypto-Key: p256ecdsa=' . $server_public_key,
            'TTL: 86400', // 24 hours
        ];

        $ch = curl_init($endpoint);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $ciphertext,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 10,
        ]);

        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        return [
            'success' => ($http_code >= 200 && $http_code < 300),
            'http_code' => $http_code,
            'response' => $response,
            'error' => $error,
        ];
    }

    /**
     * HKDF key derivation
     */
    private function hkdf($ikm, $salt, $info, $length) {
        // Extract
        $prk = hash_hmac('sha256', $ikm, $salt, true);

        // Expand
        $t = '';
        $okm = '';
        $i = 0;

        while (strlen($okm) < $length) {
            $i++;
            $t = hash_hmac('sha256', $t . $info . chr($i), $prk, true);
            $okm .= $t;
        }

        return substr($okm, 0, $length);
    }

    /**
     * Base64URL encode
     */
    private static function base64url_encode($data) {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }

    /**
     * Base64URL decode
     */
    private static function base64url_decode($data) {
        return base64_decode(strtr($data, '-_', '+/'));
    }

    /**
     * Convert PEM to base64url
     */
    private static function pem_to_base64url($pem) {
        $pem = str_replace([
            '-----BEGIN EC PRIVATE KEY-----',
            '-----END EC PRIVATE KEY-----',
            "\r",
            "\n"
        ], '', $pem);
        return self::base64url_encode(base64_decode($pem));
    }

    /**
     * Convert DER to base64url
     */
    private static function der_to_base64url($der) {
        return self::base64url_encode($der);
    }
}
```

**Ưu điểm:**

- ✅ Không cần Composer, không cần vendor/
- ✅ Plugin nhẹ hơn (~5-8 MB)
- ✅ Update plugin dễ dàng hơn
- ✅ Không conflict dependencies

**Nhược điểm:**

- ⚠️ Code phức tạp hơn (crypto operations)
- ⚠️ Cần test kỹ (security-critical)
- ⚠️ Maintain code tự viết

---

### ✅ GIẢI PHÁP 2: DÙNG COMPOSER (Dễ hơn nhưng nặng)

Nếu chấp nhận plugin nặng hơn để có code đơn giản:

```bash
cd /wp-content/plugins/checkin-mkt192-wp

# Tạo composer.json
cat > composer.json << 'EOF'
{
    "require": {
        "minishlink/web-push": "^8.0"
    },
    "config": {
        "optimize-autoloader": true,
        "classmap-authoritative": true
    }
}
EOF

# Install (production only, no dev dependencies)
composer install --no-dev --optimize-autoloader

# Tạo .gitignore cho vendor
echo "vendor/" > .gitignore
```

**Sử dụng:**

```php
<?php
// Trong includes/rest-api/push-notifications-api.php

require_once CHECKIN_PLUGIN_DIR . 'vendor/autoload.php';

function checkin_mkt192_send_push_notification($user_ids, $notification_data) {
    // ... existing code ...

    $auth = [
        'VAPID' => [
            'subject'    => home_url(),
            'publicKey'  => get_option('checkin_vapid_public_key'),
            'privateKey' => get_option('checkin_vapid_private_key')
        ]
    ];

    $webPush = new \Minishlink\WebPush\WebPush($auth);

    foreach ($subscriptions as $sub) {
        $subscription = json_decode($sub->subscription, true);

        $report = $webPush->sendOneNotification(
            \Minishlink\WebPush\Subscription::create($subscription),
            json_encode($notification_data)
        );

        // Handle result...
    }
}
```

**Deployment:**

- Khi update plugin, PHẢI include thư mục `vendor/`
- Zip file plugin sẽ nặng thêm 5-8 MB
- Upload lâu hơn (~1000 files thay vì ~100 files)

---

### ✅ GIẢI PHÁP 3: HYBRID (Tối ưu nhất)

**Dùng external service thay vì tự gửi push:**

#### Option A: OneSignal (Free)

```javascript
// Frontend - Dùng OneSignal SDK
<script src="https://cdn.onesignal.com/sdks/OneSignalSDK.js"></script>
<script>
  window.OneSignal = window.OneSignal || [];
  OneSignal.push(function() {
    OneSignal.init({
      appId: "YOUR_ONESIGNAL_APP_ID",
    });
  });
</script>
```

```php
// Backend - Gửi push qua OneSignal API
function send_push_via_onesignal($user_id, $notification) {
    $onesignal_app_id = get_option('onesignal_app_id');
    $onesignal_api_key = get_option('onesignal_api_key');

    $data = [
        'app_id' => $onesignal_app_id,
        'include_external_user_ids' => [(string)$user_id],
        'headings' => ['en' => $notification['title']],
        'contents' => ['en' => $notification['body']],
        'url' => $notification['data']['url'] ?? home_url(),
    ];

    $response = wp_remote_post('https://onesignal.com/api/v1/notifications', [
        'headers' => [
            'Content-Type' => 'application/json',
            'Authorization' => 'Basic ' . $onesignal_api_key,
        ],
        'body' => json_encode($data),
    ]);

    return !is_wp_error($response);
}
```

**Ưu điểm:**

- ✅ KHÔNG cần Composer
- ✅ KHÔNG cần VAPID keys
- ✅ Có dashboard quản lý
- ✅ Analytics miễn phí
- ✅ Support tốt

**Nhược điểm:**

- ⚠️ Phụ thuộc service bên thứ 3
- ⚠️ Free plan: 10,000 users

#### Option B: Firebase Cloud Messaging (FCM)

```javascript
// Frontend - Dùng Firebase SDK
<script src="https://www.gstatic.com/firebasejs/9.0.0/firebase-app.js"></script>
<script src="https://www.gstatic.com/firebasejs/9.0.0/firebase-messaging.js"></script>
<script>
  const firebaseConfig = {
    apiKey: "...",
    projectId: "...",
    messagingSenderId: "...",
    appId: "..."
  };

  firebase.initializeApp(firebaseConfig);
  const messaging = firebase.messaging();
</script>
```

```php
// Backend - Gửi qua FCM API
function send_push_via_fcm($tokens, $notification) {
    $fcm_server_key = get_option('fcm_server_key');

    $data = [
        'registration_ids' => $tokens,
        'notification' => [
            'title' => $notification['title'],
            'body' => $notification['body'],
            'icon' => $notification['icon'],
        ],
        'data' => $notification['data'],
    ];

    $response = wp_remote_post('https://fcm.googleapis.com/fcm/send', [
        'headers' => [
            'Content-Type' => 'application/json',
            'Authorization' => 'key=' . $fcm_server_key,
        ],
        'body' => json_encode($data),
    ]);

    return !is_wp_error($response);
}
```

---

## 📊 SO SÁNH CÁC GIẢI PHÁP

| Tiêu chí             | Tự code PHP | Composer    | OneSignal        | FCM          |
| -------------------- | ----------- | ----------- | ---------------- | ------------ |
| **Plugin size**      | +0 MB       | +5-8 MB     | +0 MB            | +0 MB        |
| **Dependencies**     | ✅ Không    | ❌ Vendor   | ✅ SDK CDN       | ✅ SDK CDN   |
| **Setup complexity** | ⭐⭐⭐⭐⭐  | ⭐⭐        | ⭐⭐⭐           | ⭐⭐⭐       |
| **Maintenance**      | ⭐⭐⭐      | ⭐⭐⭐⭐⭐  | ⭐⭐⭐⭐⭐       | ⭐⭐⭐⭐     |
| **Control**          | ✅ 100%     | ✅ 100%     | ⚠️ 80%           | ⚠️ 80%       |
| **Cost**             | Free        | Free        | Free (10k users) | Free         |
| **Analytics**        | ❌ Tự build | ❌ Tự build | ✅ Dashboard     | ✅ Dashboard |

---

## 🎯 KHUYẾN NGHỊ

### 🥇 **TOP CHOICE: OneSignal** (Cho hầu hết trường hợp)

**Lý do:**

- Plugin nhẹ (không cần Composer)
- Setup đơn giản
- Dashboard quản lý đẹp
- Analytics miễn phí
- Support tốt

### 🥈 **SECOND: Tự code PHP** (Nếu muốn full control)

**Lý do:**

- Không phụ thuộc bên thứ 3
- Data privacy tốt
- Customize hoàn toàn

**Nhưng:** Code phức tạp, cần test kỹ

### 🥉 **LAST: Composer** (Chỉ khi cần nhanh)

**Chấp nhận được khi:**

- Plugin đã lớn sẵn (>10 MB)
- Có build process tốt
- Deploy qua CI/CD

**Tránh khi:**

- Plugin nhỏ, cần nhẹ
- Update thủ công thường xuyên
- Shared hosting giới hạn dung lượng

---

## 🧪 TESTING

### 1. Test trong Chrome DevTools

```javascript
// Console
await navigator.serviceWorker.register(
  '/wp-content/plugins/checkin-mkt192-wp/frontend/assets/js/sw-push-notifications.js'
);

// Request permission
await Notification.requestPermission();

// Subscribe
const registration = await navigator.serviceWorker.ready;
const subscription = await registration.pushManager.subscribe({
  userVisibleOnly: true,
  applicationServerKey: urlBase64ToUint8Array(VAPID_PUBLIC_KEY),
});

console.log(JSON.stringify(subscription));
```

### 2. Test push từ backend

```php
// Trong WordPress admin
wp_ajax test:
checkin_mkt192_send_push_notification(1, [
    'title' => 'Test',
    'body' => 'Hello from WordPress!'
]);
```

---

## ⚠️ LƯU Ý QUAN TRỌNG

### 1. iOS Safari Limitations

- ✅ Chỉ hoạt động với PWA (đã thêm vào Home Screen)
- ❌ Không hoạt động trong Safari browser thông thường
- ⚠️ Cần iOS 16.4+

### 2. Permission Denied

- User từ chối → không thể request lại
- Phải vào Settings → Site Settings → Notifications → Reset

### 3. HTTPS Required

- Service Workers chỉ chạy trên HTTPS
- Exception: localhost (cho dev)

### 4. Battery & Performance

- Too many notifications → annoying
- Implement "notification preferences"
- Allow users to control frequency

---

## 📊 KẾT LUẬN

✅ **ĐÃ TRIỂN KHAI:**

- Service Worker cho background tasks
- Web Push API integration
- Notification với âm thanh + rung
- Backend API để gửi push
- UI để bật/tắt notifications

✅ **TƯƠNG TỰ APP MOBILE:**

- ✅ Notification banner
- ✅ Âm thanh
- ✅ Icon, badge
- ✅ Click to open page
- ✅ Background notifications
- ✅ Vibration

🎯 **NEXT STEPS:**

1. Thêm file âm thanh custom
2. Tạo admin panel để gửi broadcast notifications
3. Implement notification history
4. Add notification preferences (email, push, SMS)
5. Analytics tracking

**Chi phí:** ~$1,000 - $2,000
**Thời gian:** 1-2 tuần

---

Bạn muốn tôi tạo code boilerplate sẵn để bắt đầu implement không? 🚀
