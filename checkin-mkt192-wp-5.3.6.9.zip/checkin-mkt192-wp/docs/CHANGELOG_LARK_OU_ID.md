# Tích hợp API Lark để tự động lấy ou_id khi cập nhật thông tin nhân viên

## Thay đổi

### Frontend (admin-setting-frontend.js)

- ✅ Thêm hàm `getLarkOuId()` để gọi API Lark và lấy member_id
- ✅ Cập nhật `saveStaffRow()` để tự động gọi API trước khi lưu
- ✅ Thêm `ou_id` vào object staff khi cập nhật

### Backend API (lark-api.php)

- ✅ Thêm REST endpoint `/vg/v1/lark/get-member-id` (POST)
- ✅ Thêm function `get_lark_member_id()` để xử lý request
- ✅ Thêm function `remove_accents()` để so sánh tên tiếng Việt
- ✅ Thuật toán so sánh thông minh:
  - Bỏ dấu tiếng Việt
  - Chuyển chữ thường
  - So sánh substring và similarity (>70%)
  - Ví dụ: "Thế Giáp" match "thegiap" ✓

### Backend Staff API (staff-profile-api.php)

- ✅ Cập nhật `checkin_mkt192_save_staff_api()` để nhận `ou_id` từ request
- ✅ Cập nhật `checkin_mkt192_update_staff_api()` để nhận và lưu `ou_id`
- ✅ Lưu `ou_id` vào database khi tạo mới hoặc cập nhật nhân viên

### Testing & Documentation

- ✅ Tạo test script: `test-lark-member-id.php`
- ✅ Tạo tài liệu: `docs/LARK_OU_ID_INTEGRATION.md`

## Cách sử dụng

1. Admin vào trang Admin Settings
2. Chỉnh sửa thông tin nhân viên (display_name)
3. Click "Lưu" (💾)
4. Hệ thống tự động:
   - Gọi API Lark để lấy member_id
   - So sánh tên với danh sách members trong chat
   - Lưu ou_id vào database cột `ou_id`

## API Request Example

```javascript
POST /wp-json/vg/v1/lark/get-member-id
{
  "display_name": "Thế Giáp"
}
```

## API Response Example

```json
{
  "success": true,
  "data": {
    "member_id": "ou_0d597d4e0f8abb608655e1df267446d0",
    "name": "thegiap"
  }
}
```

## So sánh tên

| WordPress Display Name | Lark Name   | Kết quả |
| ---------------------- | ----------- | ------- |
| Thế Giáp               | thegiap     | ✓ Match |
| Minh Phương            | Minh Phương | ✓ Match |
| Quốc Ngân              | Quốc Ngân   | ✓ Match |

## Xử lý lỗi

- Nếu không tìm thấy: sử dụng giá trị mặc định `ou_id = '1'`
- Log error vào Console và file log
- Không làm gián đoạn quá trình lưu nhân viên

## Test

Chạy test script:

```
http://localhost:8080/wp-content/plugins/checkin-mkt192-wp/test-lark-member-id.php
```

Kiểm tra database:

```sql
SELECT display_name, ou_id
FROM wp_checkin_mkt192_staff
WHERE ou_id IS NOT NULL AND ou_id != '1';
```

## Files thay đổi

1. frontend/assets/js/pages/admin-setting-frontend.js
2. includes/rest-api/lark-api.php
3. includes/rest-api/staff-profile-api.php
4. test-lark-member-id.php (new)
5. docs/LARK_OU_ID_INTEGRATION.md (new)

## Notes

- Chat ID: `oc_ade0d4a7fbe010a3d5e0f39d0e82a7bd`
- Yêu cầu permission: `manage_options`
- Token được cache để tránh gọi API quá nhiều
- Tương thích với các module hiện có (booking, review, stock)
