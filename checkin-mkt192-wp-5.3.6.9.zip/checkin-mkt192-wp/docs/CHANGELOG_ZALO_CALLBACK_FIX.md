# Fix Zalo OA Callback URL cho Local Testing

## 📅 Date: 2025-11-16

## 🎯 Mục đích

Sửa lỗi hardcoded callback URL trong code, cho phép test Zalo OA trên local environment với ngrok hoặc domain khác.

## ❌ Vấn đề ban đầu

### 1. Hardcoded callback URL

```javascript
// frontend/assets/js/pages/admin-setting-frontend.js (line ~3960)
const redirectUri = encodeURIComponent(
  'https://vangroupbarbershop.store/wp-json/vg/v1/zalo-webhook'
);
```

```php
// includes/rest-api/zalo-api.php (line 289)
$redirectUri = 'https://vangroupbarbershop.store/wp-json/vg/v1/zalo-webhook';
```

### 2. Không thể test trên local

- Zalo OA chỉ cho phép 1 callback URL duy nhất
- Production đang dùng URL → không test được local
- Developer phải thay đổi callback trên Zalo portal mỗi lần test

### 3. Logic không đồng bộ

- File `connections.js` dùng dynamic URL ✅
- File `admin-setting-frontend.js` dùng hardcoded URL ❌
- File `zalo-api.php` có 1 hàm dynamic, 1 hàm hardcoded ❌

## ✅ Giải pháp

### 1. Sửa `frontend/assets/js/pages/admin-setting-frontend.js`

**Dòng ~3946-3965:** Function `initiateZaloAuth()`

```diff
function initiateZaloAuth() {
  const appId = document.getElementById('modal_zalo_app_id').value.trim();
  const appSecret = document.getElementById('modal_zalo_app_secret').value.trim();
  const state = Math.random().toString(36).substring(2, 15);
  document.getElementById('modal_zalo_state').value = state;

  if (!appId || !appSecret) {
    showWarning('Vui lòng điền đầy đủ App ID và App Secret!');
    return;
  }

  // Lưu cấu hình trước
+ const restUrl = checkinData.restUrl || window.location.origin + '/wp-json/vg/v1/';
- fetch(`${checkinData.restUrl}zalo-settings`, {
+ fetch(`${restUrl}zalo-settings`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-WP-Nonce': checkinData.nonce,
    },
    body: JSON.stringify({ app_id: appId, app_secret: appSecret }),
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.success) {
-       // Chuyển hướng đến Zalo để cấp quyền
-       const redirectUri = encodeURIComponent(
-         'https://vangroupbarbershop.store/wp-json/vg/v1/zalo-webhook'
-       );
+       // Chuyển hướng đến Zalo để cấp quyền với dynamic callback URL
+       const redirectUri = encodeURIComponent(restUrl + 'zalo-webhook');
        const authUrl = `https://oauth.zaloapp.com/v4/oa/permission?app_id=${appId}&redirect_uri=${redirectUri}&state=${state}`;

+       console.log('Zalo OAuth URL:', authUrl);
+       console.log('Callback URL:', restUrl + 'zalo-webhook');
+
        window.location.href = authUrl; // Chuyển hướng trực tiếp trên trang hiện tại
      } else {
        showError('Lỗi khi lưu cấu hình: ' + (data.message || 'Không có thông tin lỗi'));
      }
    })
    .catch((error) => {
      console.error('Error saving config:', error);
      showError('Đã xảy ra lỗi khi lưu cấu hình: ' + error.message);
    });
}
```

**Lợi ích:**

- ✅ Tự động detect đúng domain (production/local/ngrok)
- ✅ Logging để debug
- ✅ Đồng bộ với logic trong `connections.js`

### 2. Sửa `includes/rest-api/zalo-api.php`

**Dòng 289:** Function `get_zalo_tokens()`

```diff
function get_zalo_tokens(WP_REST_Request $request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'checkin_mkt192_zalo_config';
    $data       = $request->get_json_params();

    $app_id     = sanitize_text_field($data['app_id']);
    $app_secret = sanitize_text_field($data['app_secret']);
    $code       = sanitize_text_field($data['code']);

    if (!$app_id || !$app_secret || !$code) {
        return new WP_REST_Response(['success' => false, 'message' => 'App ID, App Secret và Code không được để trống'], 400);
    }

    // Gọi API Zalo để lấy access token và refresh token
    $url         = 'https://oauth.zaloapp.com/v4/oa/access_token';
-   $redirectUri = 'https://vangroupbarbershop.store/wp-json/vg/v1/zalo-webhook'; // Đảm bảo khớp với callback đã đăng ký
+   // Use dynamic callback URL instead of hardcoded domain
+   $redirectUri = rest_url('vg/v1/zalo-webhook');
    $params      = http_build_query([
        'app_id'       => $app_id,
        'app_secret'   => $app_secret,
        'code'         => $code,
        'grant_type'   => 'authorization_code',
        'redirect_uri' => $redirectUri
    ]);
```

**Lưu ý:**

- Function `handle_zalo_webhook()` đã dùng dynamic URL từ trước: `$redirectUri = rest_url('vg/v1/zalo-webhook');` ✅
- Chỉ cần sửa function `get_zalo_tokens()` để đồng bộ

## 📋 Files Changed

1. ✅ `frontend/assets/js/pages/admin-setting-frontend.js`

   - Function: `initiateZaloAuth()`
   - Lines: ~3946-3975

2. ✅ `includes/rest-api/zalo-api.php`

   - Function: `get_zalo_tokens()`
   - Line: 289

3. ✅ `docs/ZALO_LOCAL_TESTING_GUIDE.md` (NEW)

   - Hướng dẫn chi tiết test với ngrok

4. ✅ `docs/QUICK_ZALO_TEST_GUIDE.md` (NEW)

   - Quick start guide

5. ✅ `docs/CHANGELOG_ZALO_CALLBACK_FIX.md` (THIS FILE)
   - Ghi lại thay đổi

## 🧪 Testing

### Test Case 1: Production Environment

```
Domain: https://vangroupbarbershop.store
Expected callback: https://vangroupbarbershop.store/wp-json/vg/v1/zalo-webhook
✅ Works as before
```

### Test Case 2: Local với Ngrok

```
Domain: https://abc123.ngrok-free.app
Expected callback: https://abc123.ngrok-free.app/wp-json/vg/v1/zalo-webhook
✅ Now works!
```

### Test Case 3: localhost (Development)

```
Domain: http://localhost:8080
Expected callback: http://localhost:8080/wp-json/vg/v1/zalo-webhook
⚠️ Zalo yêu cầu HTTPS → Cần dùng ngrok
```

### Test Flow

1. Start ngrok: `ngrok http 8080`
2. Update Zalo callback URL với ngrok domain
3. Test tại **Connections page**: `/wp-admin/admin.php?page=checkin-connections`
4. Test tại **Admin Settings page**: `/admin` → Tab Zalo → Cấu hình lại
5. Verify console logs show correct callback URL
6. Verify OAuth redirect works
7. Verify tokens saved to database

## 🔄 Backward Compatibility

✅ **100% backward compatible**

- Không breaking changes
- Production environment hoạt động bình thường
- Chỉ thêm khả năng hoạt động trên local/ngrok

## 🚀 Deployment

### Không cần action đặc biệt

- Deploy code như bình thường
- Không cần update database
- Không cần update Zalo settings
- Production callback URL giữ nguyên

### Để test local

1. Install ngrok
2. Đọc `QUICK_ZALO_TEST_GUIDE.md`
3. Update Zalo callback URL tạm thời
4. Test
5. Đổi lại callback về production

## 📚 Documentation

- [Quick Guide](./QUICK_ZALO_TEST_GUIDE.md) - Fast setup (5 phút)
- [Full Guide](./ZALO_LOCAL_TESTING_GUIDE.md) - Chi tiết đầy đủ

## 👨‍💻 Developer Notes

### Nguyên tắc quan trọng

1. **NEVER hardcode domain trong code**
2. Luôn dùng `rest_url()` (PHP) hoặc `checkinData.restUrl` (JS)
3. Cung cấp fallback: `window.location.origin + '/wp-json/vg/v1/'`

### Pattern áp dụng

```javascript
// ✅ GOOD
const restUrl = checkinData.restUrl || window.location.origin + '/wp-json/vg/v1/';
const callbackUrl = restUrl + 'endpoint';

// ❌ BAD
const callbackUrl = 'https://vangroupbarbershop.store/wp-json/vg/v1/endpoint';
```

```php
// ✅ GOOD
$callback_url = rest_url('vg/v1/endpoint');

// ❌ BAD
$callback_url = 'https://vangroupbarbershop.store/wp-json/vg/v1/endpoint';
```

## 🐛 Known Issues

### None ✅

## 🔮 Future Improvements

1. **Environment-specific settings UI**

   - Cho phép admin config callback URL override cho testing
   - UI tại Settings → Connections

2. **Multiple Zalo Apps support**

   - Production App
   - Development App
   - Tự động switch dựa trên environment

3. **Better error handling**

   - Hiển thị callback URL trong error message
   - Suggest ngrok setup nếu localhost detect

4. **Automatic ngrok detection**
   - Detect ngrok headers
   - Show warning nếu callback mismatch

## ✅ Verification

- [x] Code reviewed
- [x] Logic đồng bộ giữa connections.js và admin-setting-frontend.js
- [x] Tested trên production domain
- [x] Tested với ngrok
- [x] Documentation complete
- [x] No breaking changes
- [x] Backward compatible

## 📝 Version Info

- Plugin Version: 5.1.1
- Change Date: 2025-11-16
- Change Type: Bug Fix + Enhancement
- Severity: Medium (không ảnh hưởng production, cải thiện DX)
