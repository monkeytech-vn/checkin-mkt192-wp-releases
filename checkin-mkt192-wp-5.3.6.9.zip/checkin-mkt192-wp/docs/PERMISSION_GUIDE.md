# 📚 Hướng Dẫn Sử Dụng Hệ Thống Phân Quyền

## 🎯 Tổng Quan

Hệ thống phân quyền sử dụng **scope-based authorization** để kiểm soát truy cập vào các API endpoint. Mỗi quyền được định nghĩa theo định dạng `module.action`.

---

## 🔐 Cấu Trúc Phân Quyền

### Định Dạng Scope

```
module.action
```

**Ví dụ:**

- `invoice.read` - Xem hóa đơn
- `salary.calculate` - Tính lương
- `kpi.evaluate` - Đánh giá KPI
- `role.delete` - Xóa vai trò

### Module Hiện Có

| Module        | Mô Tả       | Các Action Khả Dụng                       |
| ------------- | ----------- | ----------------------------------------- |
| **invoice**   | Hóa đơn     | read, create, update, delete, send        |
| **booking**   | Đặt lịch    | read, create, update, delete, resend      |
| **service**   | Dịch vụ     | read, create, update, delete              |
| **product**   | Sản phẩm    | read, create, update, delete              |
| **staff**     | Nhân viên   | read, create, update, delete              |
| **salary**    | Lương       | read, calculate, confirm, payment, notify |
| **kpi**       | KPI         | read, config, evaluate, delete, reset     |
| **penalty**   | Phạt        | read, create, update, delete              |
| **location**  | Chi nhánh   | read, create, update, delete              |
| **shift**     | Ca làm việc | read, create, update, delete              |
| **leave**     | Nghỉ phép   | read, request, approve, delete            |
| **zalo**      | Zalo        | send_message                              |
| **dashboard** | Báo cáo     | view, view_all                            |
| **role**      | Vai trò     | read, create, update, delete              |
| **checkin**   | Chấm công   | record, view, view_all                    |

---

## 💻 Áp Dụng Trong Code

### 1. Trong REST API Endpoints

**Pattern cơ bản:**

```php
'permission_callback' => checkin_mkt192_permission([
    'mode' => 'login',
    'scope' => 'module.action'
])
```

**Ví dụ cụ thể:**

```php
// API endpoint để xem danh sách hóa đơn
register_rest_route('checkin-mkt192/v1', '/invoices', [
    'methods' => 'GET',
    'callback' => 'get_invoices_handler',
    'permission_callback' => checkin_mkt192_permission([
        'mode' => 'login',
        'scope' => 'invoice.read'
    ])
]);

// API endpoint để tính lương
register_rest_route('checkin-mkt192/v1', '/calculate-salary', [
    'methods' => 'POST',
    'callback' => 'calculate_salary_handler',
    'permission_callback' => checkin_mkt192_permission([
        'mode' => 'login',
        'scope' => 'salary.calculate'
    ])
]);

// API endpoint để đánh giá KPI
register_rest_route('checkin-mkt192/v1', '/evaluate-kpi', [
    'methods' => 'POST',
    'callback' => 'evaluate_kpi_handler',
    'permission_callback' => checkin_mkt192_permission([
        'mode' => 'login',
        'scope' => 'kpi.evaluate'
    ])
]);
```

### 2. Các Mode Phân Quyền

| Mode        | Mô Tả                     | Sử Dụng Khi                  |
| ----------- | ------------------------- | ---------------------------- |
| **public**  | Không cần đăng nhập       | API công khai cho khách hàng |
| **login**   | Yêu cầu đăng nhập + scope | API nội bộ cho nhân viên     |
| **manager** | Chỉ dành cho quản lý      | API quản trị cấp cao         |
| **array**   | Tùy chỉnh roles/scope     | Cần kiểm soát chi tiết hơn   |

**Ví dụ:**

```php
// Public API - không cần quyền
'permission_callback' => checkin_mkt192_permission(['mode' => 'public'])

// Login + scope - cần đăng nhập và có quyền
'permission_callback' => checkin_mkt192_permission([
    'mode' => 'login',
    'scope' => 'salary.read'
])

// Manager only
'permission_callback' => checkin_mkt192_permission(['mode' => 'manager'])

// Custom với nhiều roles
'permission_callback' => checkin_mkt192_permission([
    'mode' => ['roles' => ['Admin', 'Quản lý'], 'scope' => 'invoice.delete']
])
```

---

## 🗄️ Cấu Hình Trong Database

### Bảng: `wp_checkin_mkt192_staff_roles`

**Cột `permissions` (JSON):**

```json
{
  "invoice": ["read", "create", "update", "delete", "send"],
  "salary": ["read", "calculate", "confirm", "payment", "notify"],
  "kpi": ["read", "config", "evaluate", "delete"],
  "role": ["read", "create", "update", "delete"]
}
```

**Cấu trúc:**

- Key: Tên module
- Value: Mảng các action được phép

---

## 🖱️ Cấu Hình Qua Giao Diện

### Truy cập trang cấu hình vai trò:

1. Vào **Dashboard Admin**
2. Chọn **Cài đặt** → **Vai trò nhân viên**
3. Click **Sửa** hoặc **Thêm mới** vai trò

### Thiết lập quyền cho module:

#### Ví dụ 1: Module Lương (Salary)

**Các quyền khả dụng:**

- ✅ **Xem** (`salary.read`) - Xem thông tin lương
- ✅ **Tính lương** (`salary.calculate`) - Tính toán lương nhân viên
- ✅ **Xác nhận** (`salary.confirm`) - Xác nhận phiếu lương
- ✅ **Thanh toán** (`salary.payment`) - Cập nhật trạng thái thanh toán
- ✅ **Gửi thông báo** (`salary.notify`) - Gửi thông báo lương

**Cách chọn:**

1. Click vào button **"Lương"** trong danh sách module
2. Dropdown hiện ra với các checkbox tương ứng
3. Tick vào các quyền cần cấp:
   - Nhân viên thường: chỉ tick "Xem"
   - Thu ngân: tick "Xem", "Tính lương"
   - Quản lý: tick tất cả

#### Ví dụ 2: Module KPI

**Các quyền khả dụng:**

- ✅ **Xem** (`kpi.read`) - Xem KPI
- ✅ **Cấu hình** (`kpi.config`) - Thiết lập tiêu chí KPI
- ✅ **Đánh giá** (`kpi.evaluate`) - Đánh giá KPI nhân viên
- ✅ **Xóa** (`kpi.delete`) - Xóa bản ghi KPI
- ✅ **Reset** (`kpi.reset`) - Reset KPI về mặc định

#### Ví dụ 3: Module Vai trò (Role)

**Các quyền khả dụng:**

- ✅ **Xem** (`role.read`) - Xem danh sách vai trò
- ✅ **Thêm** (`role.create`) - Tạo vai trò mới
- ✅ **Sửa** (`role.update`) - Chỉnh sửa vai trò
- ✅ **Xóa** (`role.delete`) - Xóa vai trò

**⚠️ Lưu ý:** Module vai trò rất quan trọng, chỉ cấp cho Admin hoặc Quản lý cấp cao!

---

## 📋 Checklist Triển Khai Phân Quyền Mới

Khi thêm API endpoint mới, hãy làm theo các bước:

### ✅ Bước 1: Định nghĩa scope trong `permission.php`

```php
// Thêm vào phần scope messages
$scope_messages = [
    // ... existing scopes ...
    'module.action' => 'Mô tả quyền bằng tiếng Việt',
];

// Thêm vào phần alias mapping
function checkin_mkt192_scope_to_permission_candidates($scope) {
    $aliases = [
        // ... existing aliases ...
        'module.action' => ['module' => 'module', 'action' => 'action'],
    ];
    // ...
}
```

### ✅ Bước 2: Áp dụng trong API file

```php
register_rest_route('checkin-mkt192/v1', '/endpoint', [
    'methods' => 'GET',
    'callback' => 'your_handler',
    'permission_callback' => checkin_mkt192_permission([
        'mode' => 'login',
        'scope' => 'module.action'
    ])
]);
```

### ✅ Bước 3: Cập nhật UI dropdown (nếu cần)

Thêm checkbox tương ứng vào `admin-setting-frontend.js`:

```javascript
// Trong phần modules array
const modules = [
  // ... existing modules ...
  'module',
];

// Trong phần actionLabels
const actionLabels = {
  // ... existing actions ...
  action: 'Mô tả hành động',
};
```

### ✅ Bước 4: Test

1. Đăng nhập với user có vai trò khác nhau
2. Thử truy cập API endpoint
3. Kiểm tra:
   - User có quyền → API thành công
   - User không có quyền → API trả về 403 với thông báo tiếng Việt
   - Log trong `error_log` ghi nhận permission check

---

## 🔍 Debug & Troubleshooting

### Kiểm tra log phân quyền

File: `wp-content/debug.log`

**Định dạng log:**

```
[timestamp] Checking scope 'salary.calculate' for role 'Thu ngân'
[timestamp] Permission granted for scope 'salary.calculate'
```

hoặc

```
[timestamp] Checking scope 'role.delete' for role 'Nhân viên'
[timestamp] Permission denied for scope 'role.delete'
```

### Các lỗi thường gặp

#### ❌ Lỗi 1: API trả về 403 dù user có quyền

**Nguyên nhân:**

- Scope chưa được thêm vào `permission.php`
- Mapping alias sai
- Database chưa có quyền trong `permissions` JSON

**Giải pháp:**

1. Kiểm tra `permission.php` có scope này chưa
2. Kiểm tra mapping alias đúng format
3. Vào UI cấu hình vai trò và tick lại quyền
4. Xem `debug.log` để biết chi tiết

#### ❌ Lỗi 2: Thông báo lỗi bằng tiếng Anh

**Nguyên nhân:**

- Chưa định nghĩa message trong `$scope_messages`

**Giải pháp:**

```php
$scope_messages = [
    'your.scope' => 'Thông báo tiếng Việt',
];
```

#### ❌ Lỗi 3: Fallback cho phép tất cả

**Nguyên nhân:**

- Vai trò chưa được cấu hình trong database
- Hệ thống dùng fallback logic (default allow)

**Giải pháp:**

- Vào UI cấu hình vai trò và lưu lại (dù không thay đổi gì)
- Điều này sẽ tạo record trong database

---

## 📊 Danh Sách Scope Đầy Đủ

### Module: Invoice (Hóa đơn)

- `invoice.read` - Xem hóa đơn
- `invoice.create` - Tạo hóa đơn
- `invoice.update` - Cập nhật hóa đơn
- `invoice.delete` - Xóa hóa đơn
- `invoice.send` - Gửi hóa đơn

### Module: Salary (Lương)

- `salary.read` - Xem lương
- `salary.calculate` - Tính lương
- `salary.confirm` - Xác nhận phiếu lương
- `salary.payment` - Cập nhật thanh toán
- `salary.notify` - Gửi thông báo lương

### Module: KPI

- `kpi.read` - Xem KPI
- `kpi.config` - Cấu hình KPI
- `kpi.evaluate` - Đánh giá KPI
- `kpi.delete` - Xóa KPI
- `kpi.reset` - Reset KPI

### Module: Role (Vai trò)

- `role.read` - Xem vai trò
- `role.create` - Tạo vai trò
- `role.update` - Sửa vai trò
- `role.delete` - Xóa vai trò

### Module: Booking (Đặt lịch)

- `booking.read` - Xem booking
- `booking.create` - Tạo booking
- `booking.update` - Cập nhật booking
- `booking.delete` - Xóa booking
- `booking.resend` - Gửi lại thông báo

### Module: Checkin (Chấm công)

- `checkin.record` - Ghi nhận chấm công
- `checkin.view` - Xem chấm công cá nhân
- `checkin.view_all` - Xem tất cả chấm công

### Module: Leave (Nghỉ phép)

- `leave.read` - Xem nghỉ phép
- `leave.request` - Đăng ký nghỉ phép
- `leave.approve` - Duyệt nghỉ phép
- `leave.delete` - Xóa đơn nghỉ phép

### Module: Service (Dịch vụ)

- `service.read` - Xem dịch vụ
- `service.create` - Tạo dịch vụ
- `service.update` - Cập nhật dịch vụ
- `service.delete` - Xóa dịch vụ

### Module: Product (Sản phẩm)

- `product.read` - Xem sản phẩm
- `product.create` - Tạo sản phẩm
- `product.update` - Cập nhật sản phẩm
- `product.delete` - Xóa sản phẩm

### Module: Staff (Nhân viên)

- `staff.read` - Xem nhân viên
- `staff.create` - Thêm nhân viên
- `staff.update` - Cập nhật nhân viên
- `staff.delete` - Xóa nhân viên

### Module: Dashboard (Báo cáo)

- `dashboard.view` - Xem báo cáo cá nhân
- `dashboard.view_all` - Xem tất cả báo cáo

---

## 🎓 Best Practices

### ✅ DO (Nên làm)

1. **Luôn sử dụng scope cụ thể**

   ```php
   'permission_callback' => checkin_mkt192_permission([
       'mode' => 'login',
       'scope' => 'salary.read'
   ])
   ```

2. **Định nghĩa scope message bằng tiếng Việt**

   ```php
   'salary.confirm' => 'Bạn không có quyền xác nhận phiếu lương.'
   ```

3. **Test với nhiều vai trò khác nhau**

   - Admin
   - Quản lý
   - Thu ngân
   - Nhân viên thường

4. **Log permission checks để debug**
   - Hệ thống tự động log vào `error_log()`

### ❌ DON'T (Không nên làm)

1. **Không dùng `__return_true` cho API nội bộ**

   ```php
   // ❌ SAI
   'permission_callback' => '__return_true'

   // ✅ ĐÚNG
   'permission_callback' => checkin_mkt192_permission([
       'mode' => 'login',
       'scope' => 'module.action'
   ])
   ```

2. **Không dùng `current_user_can('manage_options')` trực tiếp**

   ```php
   // ❌ SAI
   'permission_callback' => function() {
       return current_user_can('manage_options');
   }

   // ✅ ĐÚNG
   'permission_callback' => checkin_mkt192_permission(['mode' => 'manager'])
   ```

3. **Không hardcode role names trong permission check**

   ```php
   // ❌ SAI
   if ($role_name === 'Admin') { ... }

   // ✅ ĐÚNG
   // Để hệ thống scope tự động xử lý
   ```

---

## 📖 Tham Khảo

### File quan trọng:

- `includes/permission.php` - Core permission logic
- `includes/rest-api/invoice-api.php` - Reference implementation
- `includes/rest-api/salary-api.php` - Updated với scopes
- `includes/rest-api/kpi-api.php` - Updated với scopes
- `includes/rest-api/staff-role-api.php` - Updated với scopes

### Documents:

- `PERMISSION_ANALYSIS.md` - Phân tích chi tiết hệ thống
- `PERMISSION_TODO.md` - Checklist công việc

---

## 🆘 Hỗ Trợ

Nếu gặp vấn đề:

1. Kiểm tra `wp-content/debug.log`
2. Xem `PERMISSION_ANALYSIS.md` để hiểu rõ hơn
3. Tham khảo `invoice-api.php` làm ví dụ
4. Test với nhiều vai trò khác nhau

---

**Cập nhật lần cuối:** 2025-01-XX
**Version:** 1.0
**Trạng thái:** 30% complete - Phase 2 done, Phase 3 in progress
