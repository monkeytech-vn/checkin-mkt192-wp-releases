<div align="center">

# 🎯 Checkin MKT192 WP

**Giải Pháp Quản Lý Salon & Dịch Vụ Toàn Diện cho WordPress**

[![Phiên bản](https://img.shields.io/badge/phiên_bản-5.3.0.4-blue.svg)](https://github.com/monkeytech192/checkin-mkt192-wp/releases)
[![WordPress](https://img.shields.io/badge/WordPress-5.8+-blue.svg)](https://wordpress.org/)
[![PHP](https://img.shields.io/badge/PHP-7.4+-purple.svg)](https://php.net/)
[![Giấy phép](https://img.shields.io/badge/giấy_phép-Proprietary-red.svg)](LICENSE)

**Ngôn ngữ**: [English](README.md) | [Tiếng Việt](README_VI.md)

[Tính năng](#-tính-năng) • [Cài đặt](#-cài-đặt) • [Tài liệu](#-tài-liệu) • [Hỗ trợ](#-hỗ-trợ)

</div>

---

## 📖 Tổng Quan

**Checkin MKT192 WP** là plugin WordPress toàn diện được thiết kế cho salon, spa và các doanh nghiệp dịch vụ. Plugin cung cấp hệ sinh thái hoàn chỉnh để quản lý đặt lịch, chấm công nhân viên, tính lương, kho hàng, quan hệ khách hàng và thông báo—tất cả từ một nền tảng tích hợp duy nhất.

### 🎯 Phù Hợp Cho

- 💇 Salon Tóc & Barber Shop
- 💅 Tiệm Nail & Spa
- 🧖 Trung Tâm Làm Đẹp & Chăm Sóc Sức Khỏe
- 🏥 Phòng Khám Y Tế & Nha Khoa
- 🛠️ Doanh Nghiệp Dịch Vụ

---

## ✨ Tính Năng

### 📅 **Đặt Lịch & Lên Lịch**

- Hệ thống đặt lịch online với trạng thái thời gian thực
- Phân công nhân viên và quản lý slot
- Nhắc nhở đặt lịch tự động (Zalo OA, SMS)
- Theo dõi lịch sử đặt lịch khách hàng
- Hỗ trợ đa chi nhánh

### 👥 **Quản Lý Nhân Viên**

- Chấm công bằng mã QR
- Theo dõi chuyên cần với vị trí GPS
- Yêu cầu tăng ca & đi trễ
- Bảng điều khiển hiệu suất nhân viên
- Phân quyền theo vai trò

### 💰 **Tính Lương & Tiền Công**

- Tính lương tự động
- Hoa hồng theo doanh số
- Theo dõi KPI và thưởng
- Quản lý phạt
- Cấu trúc lương đa cấp
- Xuất Excel cho kế toán

### 📦 **Quản Lý Kho Hàng**

- Theo dõi tồn kho sản phẩm
- Kho hàng đa chi nhánh
- Yêu cầu xuất/nhập kho
- Cảnh báo hàng sắp hết
- Quản lý đơn đặt hàng

### 💳 **Tích Hợp Thanh Toán**

- Nhiều cổng thanh toán (VNPay, MoMo, ZaloPay)
- Thanh toán QR code
- Tạo hóa đơn
- Theo dõi thanh toán
- Báo cáo doanh thu

### 📊 **Quan Hệ Khách Hàng**

- Hồ sơ khách hàng với lịch sử ghé thăm
- Hệ thống thành viên với điểm tích lũy
- Chúc mừng sinh nhật tự động
- Thu thập đánh giá & phản hồi
- Phân loại khách hàng

### 🔔 **Thông Báo**

- Push notification (OneSignal)
- Tích hợp Lark/Feishu
- Tin nhắn Zalo OA
- Thông báo email
- Trung tâm thông báo trong ứng dụng

### 🌐 **Hỗ Trợ Đa Chi Nhánh**

- Quản lý tập trung
- Lọc dữ liệu theo chi nhánh
- Báo cáo xuyên chi nhánh
- Phân quyền theo chi nhánh

### 🔐 **Bảo Mật & Xác Thực**

- Tích hợp Google OAuth
- Đăng nhập Facebook
- Xác thực JWT token
- Kiểm soát truy cập theo vai trò (RBAC)
- Hệ thống liên kết tài khoản

---

## 🚀 Cài Đặt

### Yêu Cầu Hệ Thống

- WordPress 5.8 trở lên
- PHP 7.4 trở lên
- MySQL 5.7 trở lên
- HTTPS (bắt buộc cho push notification)

### Cài Đặt Nhanh

1. **Tải xuống** gói plugin
2. **Upload** vào `wp-content/plugins/checkin-mkt192-wp`
3. **Kích hoạt** plugin trong WordPress Admin → Plugins
4. **Cấu hình** trong Checkin MKT192 → Cài Đặt Thương Hiệu

### Thiết Lập Lần Đầu

1. **Cài Đặt Thương Hiệu**
   - Upload logo và màu sắc thương hiệu
   - Thiết lập tên doanh nghiệp và thông tin liên hệ
   - Cấu hình múi giờ và đơn vị tiền tệ

2. **Quản Lý Chi Nhánh**
   - Thêm địa điểm kinh doanh
   - Thiết lập giờ hoạt động
   - Phân công nhân viên cho chi nhánh

3. **Kết Nối**
   - Cấu hình Zalo OA (tùy chọn)
   - Thiết lập tích hợp Lark (tùy chọn)
   - Kích hoạt cổng thanh toán

4. **Onboarding Nhân Viên**
   - Tạo tài khoản nhân viên
   - Phân quyền và vai trò
   - Thiết lập cấp bậc lương

---

## 📚 Tài Liệu

### Liên Kết Nhanh

- **Hướng Dẫn Admin**: `docs/admin-guide.md`
- **Tài Liệu API**: `docs/api-reference.md`
- **Nhật Ký Thay Đổi**: [CHANGELOG.md](CHANGELOG.md)
- **Tích Hợp Lark**: `docs/README-LARK-INTEGRATION.md`

### Khái Niệm Chính

#### Migration Chi Nhánh

Khi kích hoạt plugin, hệ thống tự động:

- Tạo các bảng cơ sở dữ liệu cần thiết
- Di chuyển dữ liệu chi nhánh từ `checkin_mkt192_locations`
- Thêm cột chi nhánh vào các bảng hiện có

#### Giao Dịch Kho Hàng

- Nhiều sản phẩm trong một giao dịch chia sẻ cùng `transaction_id`
- Phê duyệt cập nhật tất cả dòng một cách nguyên tử
- Điều chỉnh tồn kho được đồng bộ giữa các chi nhánh

#### Tính Lương

- Chạy tự động vào ngày 1 hàng tháng
- Tính toán dựa trên dịch vụ, sản phẩm và KPI
- Hỗ trợ hoa hồng theo bậc và thưởng
- Xử lý phạt và khấu trừ

---

## 🔧 Cấu Hình

### Cài Đặt Cơ Bản

#### 1. Cổng Thanh Toán

```php
// Cấu hình trong: Checkin MKT192 → Thanh Toán
- QR Banking
- MoMo: Partner Code, Access Key, Secret Key
- ZaloPay: App ID, Key1, Key2
```

#### 2. Tích Hợp Zalo OA

```php
// Cấu hình trong: Checkin MKT192 → Kết Nối
- OA ID
- App ID & Secret Key
- Access Token (tự động làm mới)
```

#### 3. Push Notification

```php
// Cấu hình trong: Checkin MKT192 → Push Notifications
- OneSignal App ID
- REST API Key
- Safari Web ID (cho iOS)
```

### Cấu Hình Nâng Cao

Xem `docs/advanced-configuration.md` để biết:

- Custom hooks và filters
- Tối ưu hóa cơ sở dữ liệu
- Tùy chỉnh cron job
- Thiết lập multi-site

---

## 🎨 Tùy Chỉnh

### Shortcodes

```php
[checkin_dashboard]          // Bảng điều khiển nhân viên
[user_profile]               // Trang hồ sơ người dùng
[customer_member]            // Cổng khách hàng
[app_tho]                    // Ứng dụng di động nhân viên
[admin_setting_frontend]     // Cài đặt admin
[request_approval]           // Yêu cầu phê duyệt
```

### Hooks & Filters

```php
// Tùy chỉnh tính lương
add_filter('checkin_mkt192_salary_calculation', 'custom_salary_logic', 10, 2);

// Sửa đổi slot đặt lịch
add_filter('checkin_mkt192_booking_slots', 'custom_booking_slots', 10, 3);

// Thêm loại thông báo tùy chỉnh
add_action('checkin_mkt192_send_notification', 'custom_notification', 10, 2);
```

---

## 🐛 Xử Lý Sự Cố

### Vấn Đề Thường Gặp

**H: Tính lương không chính xác**

- Kiểm tra cài đặt KPI trong Admin Settings → KPI
- Xem phần trăm hoa hồng trong Cấp Bậc Lương
- Xem lại cài đặt phạt

**H: Push notification không hoạt động**

- Đảm bảo HTTPS đã được bật
- Xác minh cấu hình OneSignal
- Kiểm tra quyền trình duyệt

**H: Slot đặt lịch không hiển thị**

- Xác nhận giờ làm việc của nhân viên
- Kiểm tra yêu cầu đi trễ/về sớm đã duyệt
- Xác minh giờ hoạt động chi nhánh

**H: Lỗi cổng thanh toán**

- Kiểm tra lại thông tin API
- Đảm bảo callback URL có thể truy cập
- Xem log cổng thanh toán

### Chế Độ Debug

Bật ghi log debug:

```php
// Thêm vào wp-config.php
define('CHECKIN_MKT192_DEBUG', true);
```

Log được lưu trong: `includes/rest-api/logs/`

---

## 📊 Hiệu Suất

### Mẹo Tối Ưu

1. **Đánh Index Cơ Sở Dữ Liệu**
   - Tự động tạo khi kích hoạt
   - Index trên `branch_id`, `staff_id`, `created_at`

2. **Caching**
   - Sử dụng WordPress transients cho API response
   - Tính lương được cache 24 giờ
   - Dữ liệu kho hàng được cache 1 giờ

3. **Cron Jobs**
   - Dọn dẹp ảnh: Hàng ngày lúc 2 giờ sáng
   - Dọn dẹp log: Hàng tuần
   - Tính lương: Ngày 1 hàng tháng lúc 1 giờ sáng

---

## 🔒 Bảo Mật

### Thực Hành Tốt Nhất

- ✅ Tất cả đầu vào người dùng được sanitize và validate
- ✅ Truy vấn SQL sử dụng prepared statements
- ✅ Xác minh nonce cho AJAX requests
- ✅ JWT tokens cho xác thực API
- ✅ Kiểm soát truy cập theo vai trò (RBAC)
- ✅ HTTPS bắt buộc cho các thao tác nhạy cảm

### Quyền Riêng Tư Dữ Liệu

- Dữ liệu khách hàng được lưu trữ an toàn trong cơ sở dữ liệu WordPress
- PII (Thông tin nhận dạng cá nhân) được mã hóa
- Xuất/xóa dữ liệu tuân thủ GDPR
- Nhật ký kiểm toán cho các thao tác nhạy cảm

---

## 🌍 Quốc Tế Hóa

### Ngôn Ngữ Hỗ Trợ

- 🇻🇳 Tiếng Việt (Chính)
- 🇬🇧 Tiếng Anh (Một phần)

### Dịch Thuật

Plugin sẵn sàng cho dịch thuật. Đóng góp bản dịch:

1. Sử dụng POEdit hoặc Loco Translate
2. Dịch `languages/checkin-mkt192-wp.pot`
3. Gửi PR với file `.po` và `.mo`

---

## 🤝 Hỗ Trợ

### Nhận Trợ Giúp

- 📧 **Email**: support@monkeytech192.vn
- 💬 **Nhóm Lark**: Liên hệ admin để được mời
- 📱 **Zalo**: 0123-456-789
- 🌐 **Website**: [monkeytech192.vn](https://monkeytech192.vn)

### Báo Cáo Lỗi

1. Kiểm tra các vấn đề hiện có trong repository
2. Cung cấp các bước tái tạo chi tiết
3. Bao gồm phiên bản WordPress & PHP
4. Đính kèm log lỗi liên quan

---

## 📝 Giấy Phép

Plugin này là phần mềm độc quyền được phát triển bởi **Monkey Tech 192**.

**Bản quyền © 2023-2026 Monkey Tech 192. Bảo lưu mọi quyền.**

Nghiêm cấm sao chép, phân phối hoặc sửa đổi trái phép.

---

## 🙏 Ghi Nhận

### Phát Triển Bởi

**Monkey Tech 192**  
Website: [monkeytech192.vn](https://monkeytech192.vn)

### Tích Hợp

- [OneSignal](https://onesignal.com/) - Push Notifications
- [Lark/Feishu](https://www.larksuite.com/) - Giao Tiếp Nhóm
- [Zalo OA](https://oa.zalo.me/) - Tin Nhắn Khách Hàng
- [VNPay](https://vnpay.vn/) - Cổng Thanh Toán

---

## 📈 Nhật Ký Thay Đổi

Xem [CHANGELOG.md](CHANGELOG.md) để biết lịch sử phiên bản chi tiết.

### Phiên Bản Mới Nhất: 5.3.0.4 (19/03/2026)

**Cải tiến & Sửa lỗi:**

- Tích hợp Plugin MonkeyPay hỗ trợ luồng thanh toán tự động và thủ công
- Template thông báo Lark cho giao dịch thanh toán thành công
- Sửa lỗi modal thanh toán giữ trạng thái cũ giữa các hóa đơn
- Sửa lỗi Reset trang không tự động lấy hóa đơn tiếp theo trong hàng đợi

[Xem Nhật Ký Đầy Đủ →](CHANGELOG.md)

---

<div align="center">

**Được tạo với ❤️ bởi Monkey Tech 192**

[Website](https://monkeytech192.vn) • [Hỗ Trợ](mailto:support@monkeytech192.vn)

</div>
