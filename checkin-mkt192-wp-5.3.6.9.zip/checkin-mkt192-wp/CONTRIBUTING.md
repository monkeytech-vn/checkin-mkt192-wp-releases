# Contributing to Check-in MKT192 Plugin

Thank you for your interest in contributing to this project! 🎉

## 📋 Code of Conduct

Please be respectful and constructive in all interactions.

## 🔄 Git Workflow

We follow **Git Flow** branching model:

```
main          ← Production-ready code
  └── develop ← Development branch
        ├── feature/* ← New features
        ├── bugfix/*  ← Bug fixes
        └── hotfix/*  ← Urgent production fixes
```

### Branch Naming Convention

| Type    | Pattern               | Example                 |
| ------- | --------------------- | ----------------------- |
| Feature | `feature/description` | `feature/qr-scanner`    |
| Bug Fix | `bugfix/description`  | `bugfix/export-excel`   |
| Hotfix  | `hotfix/description`  | `hotfix/security-patch` |
| Release | `release/version`     | `release/4.6.0`         |

## 📝 Commit Message Convention

We use **Conventional Commits** specification:

```
<type>(<scope>): <description>

[optional body]

[optional footer]
```

### Types

| Type       | Description                           |
| ---------- | ------------------------------------- |
| `feat`     | A new feature                         |
| `fix`      | A bug fix                             |
| `docs`     | Documentation changes                 |
| `style`    | Code style changes (formatting, etc.) |
| `refactor` | Code refactoring                      |
| `perf`     | Performance improvements              |
| `test`     | Adding or updating tests              |
| `chore`    | Maintenance tasks                     |

### Examples

```bash
feat(api): add new endpoint for bulk check-in
fix(export): resolve Excel date format issue
docs(readme): update installation guide
refactor(core): optimize database queries
```

## 🚀 How to Contribute

### 1. Fork & Clone

```bash
git clone https://github.com/YOUR_USERNAME/checkin-mkt192-wp.git
cd checkin-mkt192-wp
git remote add upstream https://github.com/monkeytech192/checkin-mkt192-wp.git
```

### 2. Create Branch

```bash
git checkout develop
git pull upstream develop
git checkout -b feature/your-feature
```

### 3. Make Changes

- Write clean, documented code
- Follow WordPress Coding Standards
- Test your changes thoroughly

### 4. Commit & Push

```bash
git add .
git commit -m "feat: add your feature description"
git push origin feature/your-feature
```

### 5. Create Pull Request

- Open PR against `develop` branch
- Fill in the PR template
- Wait for review

## 🧪 Testing

Before submitting:

1. Test on WordPress 5.0+
2. Test with PHP 7.4, 8.0, 8.1
3. Check for JavaScript errors
4. Verify REST API endpoints

## 📦 Release Process

1. Merge `develop` into `release/x.x.x`
2. Update version in plugin header
3. Update CHANGELOG.md
4. Merge into `main`
5. Create GitHub release with tag
6. Merge `main` back to `develop`

## 💬 Questions?

Open an issue or contact the maintainers.
