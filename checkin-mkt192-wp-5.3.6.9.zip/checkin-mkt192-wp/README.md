<div align="center">

# 🎯 Checkin MKT192 WP

**All-in-One Salon & Service Management for WordPress**

[![Version](https://img.shields.io/badge/version-5.3.0.5-blue.svg?style=for-the-badge)](https://github.com/monkeytech192/checkin-mkt192-wp/releases)
[![WordPress](https://img.shields.io/badge/WordPress-5.8+-21759B?style=for-the-badge&logo=wordpress&logoColor=white)](https://wordpress.org/)
[![PHP](https://img.shields.io/badge/PHP-7.4+-777BB4?style=for-the-badge&logo=php&logoColor=white)](https://php.net/)
[![License](https://img.shields.io/badge/License-Proprietary-red?style=for-the-badge)](LICENSE)

[<img src="https://flagcdn.com/24x18/gb.png" width="20" height="15" alt="English"> English](#-overview) · [<img src="https://flagcdn.com/24x18/vn.png" width="20" height="15" alt="Tiếng Việt"> Tiếng Việt](#-tổng-quan)

</div>

---

<!-- ═══════════════════════════════════════════════ -->
<!-- 🇬🇧 ENGLISH                                     -->
<!-- ═══════════════════════════════════════════════ -->

## 📖 Overview

**Checkin MKT192 WP** is a comprehensive WordPress plugin designed for salons, spas, and service businesses. It provides a complete ecosystem for managing bookings, staff, payroll, inventory, payments, and customer relationships — all from one integrated platform.

### 🎯 Perfect For

| Industry | Example |
|----------|---------|
| 💇 Hair & Beauty | Salons, Barbershops, Nail Studios |
| 🧖 Wellness | Spas, Massage Parlors |
| 🏥 Healthcare | Clinics, Dental Offices |
| 🛠️ Services | Any appointment-based business |

---

## ✨ Features

<details>
<summary><b>📅 Booking & Scheduling</b></summary>

- Online booking with real-time availability
- Staff assignment & slot management
- Automated reminders (Zalo OA, Push Notification)
- Booking history & multi-branch support
</details>

<details>
<summary><b>👥 Staff Management</b></summary>

- QR code check-in / check-out
- Attendance tracking with GPS
- Overtime & leave requests with approval workflow
- Performance dashboard & role-based permissions
</details>

<details>
<summary><b>💰 Payroll & Salary</b></summary>

- Automated salary calculation with commission tiers
- KPI tracking, bonuses & penalty management
- Multi-level salary structures
- Excel export for accounting
</details>

<details>
<summary><b>💳 Payment Integration</b></summary>

- **MonkeyPay** — Auto bank transfer verification (MB Bank)
- QR code payments, MoMo, ZaloPay
- Invoice generation & revenue reports
- Payment success sound effects (Web Audio API)
</details>

<details>
<summary><b>🔔 Notifications</b></summary>

- Push notifications (OneSignal)
- Lark / Feishu integration
- Zalo OA + ZBS Template messaging
- In-app notification center
</details>

<details>
<summary><b>📦 More</b></summary>

- Inventory & stock management
- Customer CRM with membership & loyalty
- Multi-branch centralized management
- Google OAuth, Facebook Login, Zalo Login
</details>

---

## 🚀 Installation

### Requirements

| Requirement | Version |
|-------------|---------|
| WordPress | 5.8+ |
| PHP | 7.4+ |
| MySQL | 5.7+ |
| HTTPS | Required for push notifications |

### Quick Install

1. **Download** the latest release `.zip`
2. WordPress Admin → **Plugins** → **Add New** → **Upload Plugin**
3. **Activate** the plugin
4. Configure in **Checkin MKT192** → **Brand Settings**

---

## 🔧 Configuration

| Setting | Location |
|---------|----------|
| Brand & Logo | Brand Settings |
| Branches | Admin Settings → Branches |
| Payment Gateways | Payments |
| Zalo OA / ZBS | Connections |
| Push Notifications | Push Notifications |
| Lark Integration | Connections → Lark |

---

## 🎨 Shortcodes

```
[checkin_dashboard]        → Staff dashboard
[user_profile]             → User profile page
[customer_member]          → Customer portal
[app_tho]                  → Staff mobile app
[admin_setting_frontend]   → Admin settings
[request_approval]         → Approval requests
```

---

## 🐛 Troubleshooting

<details>
<summary><b>Payment method saved as empty?</b></summary>

Fixed in v5.3.0.5. Update to the latest version.
</details>

<details>
<summary><b>Infinite loading on special off-day?</b></summary>

Fixed in v5.3.0.5. Update to the latest version.
</details>

<details>
<summary><b>Push notifications not working?</b></summary>

Ensure HTTPS is enabled, OneSignal is configured, and browser permissions are granted.
</details>

<details>
<summary><b>Debug mode</b></summary>

```php
// Add to wp-config.php
define('CHECKIN_MKT192_DEBUG', true);
```

Logs: `includes/rest-api/logs/`
</details>

---

## 📈 Changelog

See [CHANGELOG.md](CHANGELOG.md) for full version history.

### Latest: v5.3.0.5 (2026-03-23)

- 🐛 Fix payment method (bank/momo) saved as empty — race condition in auto-confirm flow
- 🐛 Fix infinite loading on special off-day booking — missing `hidePageLoading()` on API error

[View Full Changelog →](CHANGELOG.md)

---

## 🔒 Security

- ✅ Prepared statements for all SQL queries
- ✅ JWT token authentication
- ✅ Role-based access control (RBAC)
- ✅ Encrypted sensitive payment config
- ✅ Input sanitization & nonce verification

---

## 🤝 Support

- 📧 **Email**: support@monkeytech192.vn
- 🌐 **Website**: [monkeytech192.vn](https://monkeytech192.vn)
- 📱 **Zalo OA**: Contact via [monkeytech192.vn](https://monkeytech192.vn)

---

<!-- ═══════════════════════════════════════════════ -->
<!-- 🇻🇳 TIẾNG VIỆT                                  -->
<!-- ═══════════════════════════════════════════════ -->

## 📖 Tổng Quan

**Checkin MKT192 WP** là plugin WordPress toàn diện dành cho salon tóc, spa và doanh nghiệp dịch vụ. Cung cấp hệ sinh thái hoàn chỉnh: quản lý đặt lịch, nhân viên, lương, kho hàng, thanh toán và khách hàng — tất cả trong một nền tảng duy nhất.

### 🎯 Phù Hợp Với

| Ngành | Ví dụ |
|-------|-------|
| 💇 Tóc & Làm đẹp | Salon, Barbershop, Tiệm nail |
| 🧖 Chăm sóc sức khỏe | Spa, Massage |
| 🏥 Y tế | Phòng khám, Nha khoa |
| 🛠️ Dịch vụ | Mọi doanh nghiệp đặt lịch hẹn |

---

## ✨ Tính Năng Chính

<details>
<summary><b>📅 Đặt Lịch & Lịch Hẹn</b></summary>

- Đặt lịch online real-time
- Phân bổ thợ & quản lý slot
- Nhắc lịch tự động (Zalo OA, Push Notification)
- Lịch sử đặt lịch & hỗ trợ đa chi nhánh
</details>

<details>
<summary><b>👥 Quản Lý Nhân Viên</b></summary>

- Chấm công bằng QR code
- Theo dõi tọa độ GPS
- Đơn xin đi trễ/về sớm/nghỉ phép có phê duyệt
- Dashboard hiệu suất & phân quyền theo vai trò
</details>

<details>
<summary><b>💰 Lương & Chấm Công</b></summary>

- Tính lương tự động theo dịch vụ, KPI, hoa hồng
- Quản lý phạt & khấu trừ
- Cấp bậc lương đa tầng
- Xuất Excel cho kế toán
</details>

<details>
<summary><b>💳 Thanh Toán</b></summary>

- **MonkeyPay** — Xác nhận chuyển khoản tự động (MB Bank)
- QR code, MoMo, ZaloPay
- Xuất hóa đơn & báo cáo doanh thu
- Hiệu ứng âm thanh khi thanh toán thành công
</details>

<details>
<summary><b>🔔 Thông Báo</b></summary>

- Push notification (OneSignal)
- Tích hợp Lark / Feishu
- Zalo OA + ZBS Template
- Trung tâm thông báo trong ứng dụng
</details>

<details>
<summary><b>📦 Khác</b></summary>

- Quản lý kho hàng & xuất nhập
- CRM khách hàng, thành viên & tích điểm
- Quản lý tập trung đa chi nhánh
- Đăng nhập Google, Facebook, Zalo
</details>

---

## 🚀 Cài Đặt

### Yêu Cầu

| Yêu cầu | Phiên bản |
|----------|-----------|
| WordPress | 5.8+ |
| PHP | 7.4+ |
| MySQL | 5.7+ |
| HTTPS | Bắt buộc cho push notification |

### Cài Đặt Nhanh

1. **Tải** file `.zip` phiên bản mới nhất
2. WordPress Admin → **Plugins** → **Thêm mới** → **Tải Plugin lên**
3. **Kích hoạt** plugin
4. Cấu hình tại **Checkin MKT192** → **Cài đặt thương hiệu**

---

## 📈 Lịch Sử Thay Đổi

Xem [CHANGELOG.md](CHANGELOG.md) để biết chi tiết.

### Mới nhất: v5.3.0.5 (23/03/2026)

- 🐛 Sửa lỗi phương thức thanh toán bank/momo bị trống — race condition trong flow auto-confirm
- 🐛 Sửa lỗi loading vô hạn khi chọn ngày OFF đặc biệt — thiếu `hidePageLoading()` khi API lỗi

[Xem toàn bộ Changelog →](CHANGELOG.md)

---

## 📝 Giấy Phép

Phần mềm độc quyền của **Monkey Tech 192**.

**Copyright © 2023–2026 Monkey Tech 192. All rights reserved.**

---

<div align="center">

**Made with ❤️ by [Monkey Tech 192](https://monkeytech192.vn)**

</div>
