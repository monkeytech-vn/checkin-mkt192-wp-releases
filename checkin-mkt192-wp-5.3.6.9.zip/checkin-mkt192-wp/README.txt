=== Checkin MKT192 WP ===
Contributors: monkeytech192
Tags: checkin, booking, appointment, salon, barber shop
Requires at least: 6.0
Tested up to: 6.4
Requires PHP: 7.4
Stable tag: 5.3.6.9
License: Proprietary
License URI: https://example.com/license

A comprehensive check-in and booking management plugin for salons and service businesses.

== Short Description ==

Checkin MKT192 WP provides booking, staff checkin, payroll, inventory and notification integrations for salons and service shops. It ships with REST APIs and admin pages for configuration.

== Quick Start ==

1. Upload the plugin folder to `/wp-content/plugins/checkin-mkt192-wp`
2. Activate the plugin in WordPress Admin → Plugins
3. Configure Brand & Connections in Checkin MKT192 menu
4. Optional: configure Zalo OA and Lark integrations

== Notable Behavior ==

- Automatic branch migration: on activation the plugin ensures `branch` columns and indexes exist and populates empty values from the `checkin_mkt192_locations` table.
- Inventory transactions: multiple products are saved as separate rows sharing a single `transaction_id`; approval updates all rows and adjusts product stock using DB transactions.

== Changelog ==

Xem chi tiết tại `CHANGELOG.md`

== Docs ==

See `docs/INDEX.md` for curated documentation and entry points.

== Support ==

Contact maintainers via repository or internal support channels.
