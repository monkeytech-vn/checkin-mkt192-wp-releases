<?php

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class quản lý các cron job của plugin.
 */
class Checkin_MKT192_Cron {
    /**
     * Instance của class (Singleton pattern).
     *
     * @var Checkin_MKT192_Cron
     */
    private static $instance = null;

    /**
     * Lấy instance của class.
     *
     * @return Checkin_MKT192_Cron
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor.
     */
    private function __construct() {
        $this->init_hooks();
    }

    /**
     * Khởi tạo các WordPress cron hooks.
     */
    private function init_hooks() {
        // Import required files
        require_once __DIR__ . '/class-checkin-mkt192-update-promoCode.php';
        require_once __DIR__ . '/class-checkin-mkt192-image-upload.php';
        require_once __DIR__ . '/class-checkin-mkt192-reprocess-temp-files.php';
        require_once __DIR__ . '/fix-temp-urls.php'; // Fix script for temp URLs in DB
        require_once __DIR__ . '/class-checkin-mkt192-log-cleanup.php';
        require_once __DIR__ . '/class-checkin-mkt192-image-cleanup.php';
        require_once dirname(__FILE__, 2) . '/lark/new_thread_daily.php';
        require_once dirname(__FILE__, 2) . '/lark/send_missing_image_notification.php';
        require_once dirname(__FILE__, 2) . '/zalo/class-checkin-mkt192-zalo-booking-reminder.php';
        require_once dirname(__FILE__, 2) . '/rest-api/zalo-api.php';

        // Đăng ký các cron job
        add_action('daily_new_thread_lark', [Checkin_MKT192_NewThreadDaily::class, 'send_daily_new_thread']);
        add_action('send_booking_reminder', [Checkin_MKT192_ZaloBookingReminder::class, 'check_and_send_booking_reminder']);
        add_action('daily_upload_image', [Checkin_MKT192_ImageUpload::class, 'upload_customer_image']);
        add_action('daily_update_promo_code', [Checkin_MKT192_UpdatePromoCode::class, 'update_customer_promo_code']);
        add_action('daily_missing_image_notification', [Checkin_MKT192_MissingImageNotification::class, 'send_missing_image_notification']);
        add_action('daily_reprocess_temp_files', [Checkin_MKT192_ReprocessTempFiles::class, 'reprocess_temp_files']);
        add_action('daily_refresh_zalo_tokens', 'refresh_zalo_tokens_cron');
        add_action('weekly_cleanup_customer_images', [Checkin_MKT192_Image_Cleanup::class, 'execute']);
        // add_action('stop_booking_reminder', [$this, 'stop_and_reschedule_booking_reminder']);
        // add_action('stop_upload_image', [$this, 'stop_and_reschedule_upload_image']);
    }

    /**
     * Dừng và lập lịch lại cron job upload image.
     */
    public function stop_and_reschedule_upload_image() {
        // Xóa tất cả lịch hiện có cho daily_upload_image
        while ($timestamp = wp_next_scheduled('daily_upload_image')) {
            wp_unschedule_event($timestamp, 'daily_upload_image');
        }
        // Lập lịch lại cho ngày hôm sau lúc 01:00
        $next_day = strtotime('tomorrow 01:00');
        wp_schedule_event($next_day, 'every_5_minutes', 'daily_upload_image');
    }

    /**
     * Dừng và lập lịch lại cron job booking reminder.
     */
    public function stop_and_reschedule_booking_reminder() {
        // Xóa tất cả lịch hiện có cho send_booking_reminder
        while ($timestamp = wp_next_scheduled('send_booking_reminder')) {
            wp_unschedule_event($timestamp, 'send_booking_reminder');
        }
        // Lập lịch lại cho ngày hôm sau lúc 01:00
        $next_day = strtotime('tomorrow 01:00');
        wp_schedule_event($next_day, 'every_5_minutes', 'send_booking_reminder');
    }
}

// Khởi tạo instance
Checkin_MKT192_Cron::get_instance();
?>
