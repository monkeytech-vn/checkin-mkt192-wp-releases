<?php
/**
 * Test script cho cleanup customer images
 *
 * Truy cập từ browser:
 * - ?action=dry_run (mặc định) - Xem trước các file sẽ bị xóa
 * - ?action=execute - Thực thi xóa thật
 * - ?action=stats - Xem thống kê tổng quan
 */

// Load WordPress
require_once dirname(__FILE__, 5) . '/wp-load.php';

// Kiểm tra quyền admin
if (!current_user_can('manage_options')) {
    wp_die('Bạn không có quyền truy cập trang này.');
}

// ============================================
// INLINE CLASS - Không cần file riêng
// ============================================
if (!class_exists('Checkin_MKT192_Image_Cleanup')) {
    class Checkin_MKT192_Image_Cleanup {

        private static $log_file;
        private static $base_dir;

        private static function init() {
            self::$log_file = __DIR__ . '/logs/cleanup_customer_images.log';
            self::$base_dir = WP_CONTENT_DIR . '/uploads/checkin-mkt192-wp/customer_image/';
        }

        private static function log($message) {
            $timestamp = date('Y-m-d H:i:s');
            @file_put_contents(self::$log_file, "[$timestamp] $message\n", FILE_APPEND);
        }

        public static function run_cleanup($dry_run = false) {
            self::init();

            $start_time     = microtime(true);
            $six_months_ago = strtotime('-6 months');

            $result = [
                'mode'                     => $dry_run ? 'dry_run' : 'execute',
                'started_at'               => date('Y-m-d H:i:s'),
                'customers_processed'      => 0,
                'customers_with_deletions' => 0,
                'files_deleted'            => 0,
                'bytes_freed'              => 0,
                'errors'                   => [],
                'deleted_files'            => []
            ];

            if (!is_dir(self::$base_dir)) {
                $result['errors'][] = 'Directory not found: ' . self::$base_dir;
                return $result;
            }

            $customer_dirs = glob(self::$base_dir . '*', GLOB_ONLYDIR);
            if (empty($customer_dirs)) {
                return $result;
            }

            foreach ($customer_dirs as $customer_dir) {
                $result['customers_processed']++;
                $customer_id = basename($customer_dir);

                $images = glob($customer_dir . '/*.webp');
                if (empty($images)) {
                    continue;
                }

                // Nhóm ảnh theo ngày
                $images_by_date = [];
                foreach ($images as $image_path) {
                    $filename = basename($image_path);
                    if (preg_match('/^([A-Z0-9]+)_(\d{8})/', $filename, $matches)) {
                        $date = $matches[2];
                        if (!isset($images_by_date[$date])) {
                            $images_by_date[$date] = [];
                        }
                        $images_by_date[$date][] = [
                            'path'     => $image_path,
                            'filename' => $filename,
                            'size'     => filesize($image_path)
                        ];
                    }
                }

                if (empty($images_by_date)) {
                    continue;
                }

                krsort($images_by_date);
                $dates = array_keys($images_by_date);

                // Phải có ít nhất 2 lần ghé
                if (count($dates) < 2) {
                    continue;
                }

                // Kiểm tra ngày gần nhất trong vòng 6 tháng
                $latest_date      = $dates[0];
                $latest_timestamp = strtotime(
                    substr($latest_date, 0, 4) . '-' .
                    substr($latest_date, 4, 2) . '-' .
                    substr($latest_date, 6, 2)
                );

                if ($latest_timestamp < $six_months_ago) {
                    continue;
                }

                // Giữ 2 ngày gần nhất
                $dates_to_keep   = array_slice($dates, 0, 2);
                $dates_to_delete = array_slice($dates, 2);

                if (empty($dates_to_delete)) {
                    continue;
                }

                $result['customers_with_deletions']++;

                foreach ($dates_to_delete as $date_to_delete) {
                    foreach ($images_by_date[$date_to_delete] as $image) {
                        $result['files_deleted']++;
                        $result['bytes_freed'] += $image['size'];
                        $result['deleted_files'][] = [
                            'customer_id' => $customer_id,
                            'filename'    => $image['filename'],
                            'date'        => $date_to_delete,
                            'size'        => $image['size']
                        ];

                        if (!$dry_run) {
                            if (!@unlink($image['path'])) {
                                $result['errors'][] = "Failed to delete: {$image['path']}";
                            }
                        }
                    }
                }
            }

            $result['execution_time'] = round(microtime(true) - $start_time, 2);
            $result['completed_at']   = date('Y-m-d H:i:s');

            return $result;
        }

        public static function dry_run() {
            return self::run_cleanup(true);
        }

        public static function execute() {
            return self::run_cleanup(false);
        }
    }
}

// Helper function
if (!function_exists('formatBytes')) {
    function formatBytes($bytes, $precision = 2) {
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        $bytes = max($bytes, 0);
        $pow   = floor(($bytes ? log($bytes) : 0) / log(1024));
        $pow   = min($pow, count($units) - 1);
        $bytes /= pow(1024, $pow);
        return round($bytes, $precision) . ' ' . $units[$pow];
    }
}

$action = isset($_GET['action']) ? sanitize_text_field($_GET['action']) : 'dry_run';

header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="vi">

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Cleanup Customer Images</title>
	<style>
		body {
			font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
			max-width: 1200px;
			margin: 0 auto;
			padding: 20px;
			background: #f5f5f5;
		}

		.container {
			background: white;
			padding: 30px;
			border-radius: 10px;
			box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
		}

		h1 {
			color: #333;
			border-bottom: 2px solid #4CAF50;
			padding-bottom: 10px;
		}

		.nav {
			margin: 20px 0;
			padding: 15px;
			background: #f9f9f9;
			border-radius: 5px;
		}

		.nav a {
			display: inline-block;
			padding: 10px 20px;
			margin-right: 10px;
			background: #4CAF50;
			color: white;
			text-decoration: none;
			border-radius: 5px;
			transition: background 0.3s;
		}

		.nav a:hover {
			background: #45a049;
		}

		.nav a.danger {
			background: #f44336;
		}

		.nav a.danger:hover {
			background: #da190b;
		}

		.nav a.info {
			background: #2196F3;
		}

		.nav a.info:hover {
			background: #1976D2;
		}

		.stats {
			display: grid;
			grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
			gap: 20px;
			margin: 20px 0;
		}

		.stat-card {
			background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
			color: white;
			padding: 20px;
			border-radius: 10px;
			text-align: center;
		}

		.stat-card h3 {
			margin: 0;
			font-size: 2em;
		}

		.stat-card p {
			margin: 5px 0 0 0;
			opacity: 0.9;
		}

		.log {
			background: #1e1e1e;
			color: #d4d4d4;
			padding: 20px;
			border-radius: 10px;
			font-family: 'Consolas', monospace;
			white-space: pre-wrap;
			overflow-x: auto;
			max-height: 500px;
			overflow-y: auto;
		}

		.success {
			color: #4CAF50;
		}

		.warning {
			color: #ff9800;
		}

		.error {
			color: #f44336;
		}

		.info {
			color: #2196F3;
		}

		table {
			width: 100%;
			border-collapse: collapse;
			margin-top: 20px;
		}

		th,
		td {
			padding: 12px;
			text-align: left;
			border-bottom: 1px solid #ddd;
		}

		th {
			background: #4CAF50;
			color: white;
		}

		tr:hover {
			background: #f5f5f5;
		}

		.badge {
			display: inline-block;
			padding: 3px 8px;
			border-radius: 3px;
			font-size: 0.85em;
		}

		.badge-success {
			background: #4CAF50;
			color: white;
		}

		.badge-warning {
			background: #ff9800;
			color: white;
		}

		.badge-info {
			background: #2196F3;
			color: white;
		}
	</style>
</head>

<body>
	<div class="container">
		<h1>🧹 Cleanup Customer Images</h1>

		<div class="nav">
			<a href="?action=dry_run">📋 Dry Run (Xem trước)</a>
			<a href="?action=stats" class="info">📊 Thống kê</a>
			<a href="?action=execute" class="danger"
				onclick="return confirm('Bạn có chắc muốn xóa các file? Hành động này không thể hoàn tác!');">🗑️ Thực
				thi xóa</a>
		</div>

		<?php
        if ($action === 'stats') {
            // Hiển thị thống kê
            $base_dir      = WP_CONTENT_DIR . '/uploads/checkin-mkt192-wp/customer_image/';
            $customer_dirs = glob($base_dir . '*', GLOB_ONLYDIR);

            $total_customers = count($customer_dirs);
            $total_files     = 0;
            $total_size      = 0;
            $files_by_date   = [];

            foreach ($customer_dirs as $dir) {
                $images = glob($dir . '/*.webp');
                $total_files += count($images);

                foreach ($images as $img) {
                    $total_size += filesize($img);
                    $filename = basename($img);
                    if (preg_match('/^[A-Z0-9]+_(\d{8})/', $filename, $m)) {
                        $date = $m[1];
                        if (!isset($files_by_date[$date])) {
                            $files_by_date[$date] = 0;
                        }
                        $files_by_date[$date]++;
                    }
                }
            }

            krsort($files_by_date);
            ?>
		<div class="stats">
			<div class="stat-card">
				<h3><?php echo number_format($total_customers); ?>
				</h3>
				<p>Khách hàng</p>
			</div>
			<div class="stat-card">
				<h3><?php echo number_format($total_files); ?></h3>
				<p>Tổng số ảnh</p>
			</div>
			<div class="stat-card">
				<h3><?php echo formatBytes($total_size); ?></h3>
				<p>Tổng dung lượng</p>
			</div>
			<div class="stat-card">
				<h3><?php echo count($files_by_date); ?></h3>
				<p>Số ngày có ảnh</p>
			</div>
		</div>

		<h2>📅 Phân bố ảnh theo ngày (20 ngày gần nhất)</h2>
		<table>
			<tr>
				<th>Ngày</th>
				<th>Số ảnh</th>
			</tr>
			<?php
                $count = 0;
                foreach ($files_by_date as $date => $num):
                    if ($count >= 20) break;
                    $formatted_date = substr($date, 0, 4) . '-' . substr($date, 4, 2) . '-' . substr($date, 6, 2);
                ?>
			<tr>
				<td><?php echo $formatted_date; ?></td>
				<td><?php echo number_format($num); ?></td>
			</tr>
			<?php
                    $count++;
                endforeach;
                ?>
		</table>
		<?php
        } else {
            // Chạy cleanup (dry_run hoặc execute)
            $is_dry_run = ($action !== 'execute');
            $result     = $is_dry_run ? Checkin_MKT192_Image_Cleanup::dry_run() : Checkin_MKT192_Image_Cleanup::execute();
            ?>

		<h2><?php echo $is_dry_run ? '📋 Kết quả Dry Run' : '🗑️ Kết quả Xóa'; ?>
		</h2>

		<div class="stats">
			<div class="stat-card">
				<h3><?php echo number_format($result['customers_processed']); ?>
				</h3>
				<p>Khách hàng xử lý</p>
			</div>
			<div class="stat-card" style="background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);">
				<h3><?php echo number_format($result['customers_with_deletions']); ?>
				</h3>
				<p>Khách có ảnh cần xóa</p>
			</div>
			<div class="stat-card" style="background: linear-gradient(135deg, #5ee7df 0%, #b490ca 100%);">
				<h3><?php echo number_format($result['files_deleted']); ?>
				</h3>
				<p>File
					<?php echo $is_dry_run ? 'sẽ xóa' : 'đã xóa'; ?>
				</p>
			</div>
			<div class="stat-card" style="background: linear-gradient(135deg, #fa709a 0%, #fee140 100%);">
				<h3><?php echo formatBytes($result['bytes_freed']); ?>
				</h3>
				<p>Dung lượng
					<?php echo $is_dry_run ? 'sẽ giải phóng' : 'đã giải phóng'; ?>
				</p>
			</div>
		</div>

		<?php if (!empty($result['deleted_files'])): ?>
		<h2>📁 Chi tiết các file
			<?php echo $is_dry_run ? 'sẽ bị xóa' : 'đã xóa'; ?>
		</h2>
		<table>
			<tr>
				<th>Khách hàng</th>
				<th>Tên file</th>
				<th>Ngày</th>
				<th>Dung lượng</th>
			</tr>
			<?php foreach ($result['deleted_files'] as $file): ?>
			<tr>
				<td><span
						class="badge badge-info"><?php echo esc_html($file['customer_id']); ?></span>
				</td>
				<td><?php echo esc_html($file['filename']); ?>
				</td>
				<td><?php
                        $d = $file['date'];
                        echo substr($d, 0, 4) . '-' . substr($d, 4, 2) . '-' . substr($d, 6, 2);
                    ?></td>
				<td><?php echo formatBytes($file['size']); ?>
				</td>
			</tr>
			<?php endforeach; ?>
		</table>
		<?php endif; ?>

		<?php if (!empty($result['errors'])): ?>
		<h2 class="error">❌ Lỗi</h2>
		<div class="log">
			<?php foreach ($result['errors'] as $error): ?>
			<span
				class="error"><?php echo esc_html($error); ?></span>
			<?php endforeach; ?>
		</div>
		<?php endif; ?>

		<?php
        }
        ?>

		<p style="margin-top: 30px; color: #666; font-size: 0.9em;">
			⏱ Thời gian thực thi:
			<?php echo isset($result['execution_time']) ? $result['execution_time'] . 's' : 'N/A'; ?>
			|
			📅 <?php echo date('Y-m-d H:i:s'); ?>
		</p>
	</div>
</body>

</html>
