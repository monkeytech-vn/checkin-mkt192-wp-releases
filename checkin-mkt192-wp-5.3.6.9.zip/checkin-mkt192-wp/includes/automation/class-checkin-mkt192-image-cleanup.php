<?php

/**
 * Class Checkin_MKT192_Image_Cleanup
 *
 * Wrapper class cho cleanup-customer-images.php để chạy như cron job
 *
 * Quy tắc xóa:
 * 1. Chỉ xét các khách có lần ghé gần nhất trong vòng 6 tháng
 * 2. Chỉ xóa nếu khách có ÍT NHẤT 4 lần ghé khác nhau (4 ngày khác nhau)
 * 3. Giữ lại 3 lần ghé gần nhất, MỖI LẦN CHỈ GIỮ 1 ẢNH (ảnh upload đầu tiên theo filemtime)
 * 4. KHÔNG xóa nếu sau khi xóa thư mục khách sẽ rỗng (khách lâu k quay lại vẫn giữ ảnh)
 * 5. KHÔNG xóa ảnh feedback (file có chứa "feedback" trong tên)
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class Checkin_MKT192_Image_Cleanup {

    /**
     * Execute cleanup via cron
     */
    public static function execute() {
        $log_file   = __DIR__ . '/logs/image_cleanup.log';
        $start_time = microtime(true);

        try {
            self::log($log_file, '=== START Weekly Image Cleanup ===');

            $base_dir       = WP_CONTENT_DIR . '/uploads/checkin-mkt192-wp/customer_image/';
            $six_months_ago = strtotime('-6 months');
            $today          = date('Ymd');

            if (!is_dir($base_dir)) {
                self::log($log_file, "Directory not found: $base_dir");
                return;
            }

            $stats = [
                'customers_scanned'         => 0,
                'customers_with_old_images' => 0,
                'files_deleted'             => 0,
                'bytes_freed'               => 0,
                'errors'                    => 0,
            ];

            // Scan customer directories
            $customer_dirs = glob($base_dir . 'KH*', GLOB_ONLYDIR);

            foreach ($customer_dirs as $customer_dir) {
                $stats['customers_scanned']++;
                $customer_id = basename($customer_dir);

                // Get all image files
                $files = glob($customer_dir . '/*.{jpg,jpeg,png,webp}', GLOB_BRACE);
                if (empty($files)) {
                    continue;
                }

                // Tách riêng file feedback và file thường
                $normal_files   = [];
                $feedback_files = [];
                foreach ($files as $file) {
                    $filename = basename($file);
                    if (stripos($filename, 'feedback') !== false) {
                        $feedback_files[] = $file; // Giữ lại feedback, không xóa
                    } else {
                        $normal_files[] = $file;
                    }
                }

                // Chỉ xử lý file thường (không phải feedback)
                if (empty($normal_files)) {
                    continue;
                }

                // Group files by date (extract YYYYMMDD from filename)
                $dates = [];
                foreach ($normal_files as $file) {
                    $filename = basename($file);
                    // Match pattern: KH123_20231115_0.webp
                    if (preg_match('/_(\d{8})_/', $filename, $matches)) {
                        $date = $matches[1];
                        if (!isset($dates[$date])) {
                            $dates[$date] = [];
                        }
                        $dates[$date][] = $file;
                    }
                }

                // Need at least 4 different dates to delete anything (keep 3, delete rest)
                if (count($dates) < 4) {
                    continue;
                }

                // Sort dates descending (newest first)
                krsort($dates);
                $date_keys = array_keys($dates);

                // Check if newest date is within 6 months
                $newest_date      = $date_keys[0];
                $newest_timestamp = strtotime($newest_date);
                if ($newest_timestamp < $six_months_ago) {
                    continue; // Skip if customer hasn't visited in 6 months
                }

                // Keep 3 newest dates (1 image each), delete the rest
                $dates_to_keep   = array_slice($date_keys, 0, 3);
                $dates_to_delete = array_slice($date_keys, 3);

                if (empty($dates_to_delete)) {
                    continue;
                }

                // Chuẩn bị danh sách file cần xóa:
                // 1. Tất cả file từ các ngày cũ (dates_to_delete)
                // 2. File thừa từ 3 ngày gần nhất (chỉ giữ 1 ảnh/ngày)
                $files_to_delete = [];
                $files_to_keep   = [];

                // Xử lý 3 ngày gần nhất: chỉ giữ 1 ảnh cũ nhất (upload đầu tiên)
                foreach ($dates_to_keep as $date) {
                    $day_files = $dates[$date];

                    // Sắp xếp theo thời gian tạo file (cũ nhất trước = upload đầu tiên)
                    usort($day_files, function($a, $b) {
                        return filemtime($a) - filemtime($b);
                    });

                    $files_to_keep[] = $day_files[0]; // Giữ ảnh upload đầu tiên
                    // Các ảnh còn lại của ngày đó cũng xóa
                    for ($i = 1; $i < count($day_files); $i++) {
                        $files_to_delete[] = $day_files[$i];
                    }
                }

                // Tất cả file từ các ngày cũ
                foreach ($dates_to_delete as $date) {
                    foreach ($dates[$date] as $file) {
                        $files_to_delete[] = $file;
                    }
                }

                $files_to_keep_count = count($files_to_keep);

                // Thêm feedback files vào count giữ lại (vì không xóa feedback)
                $total_remaining = $files_to_keep_count + count($feedback_files);

                // KHÔNG XÓA nếu sau khi xóa thư mục sẽ rỗng (giữ ảnh cho khách lâu không quay lại)
                if ($total_remaining === 0) {
                    self::log($log_file, "Skip $customer_id: would leave folder empty");
                    continue;
                }

                $stats['customers_with_old_images']++;

                // Xóa tất cả file trong danh sách
                foreach ($files_to_delete as $file) {
                    $file_size = filesize($file);
                    if (@unlink($file)) {
                        $stats['files_deleted']++;
                        $stats['bytes_freed'] += $file_size;
                    } else {
                        $stats['errors']++;
                        self::log($log_file, "Failed to delete: $file");
                    }
                }
            }

            $duration = round((microtime(true) - $start_time) * 1000, 1);
            $mb_freed = round($stats['bytes_freed'] / 1024 / 1024, 2);

            self::log($log_file, "Customers scanned: {$stats['customers_scanned']}");
            self::log($log_file, "Customers with old images: {$stats['customers_with_old_images']}");
            self::log($log_file, "Files deleted: {$stats['files_deleted']}");
            self::log($log_file, "Space freed: {$mb_freed} MB");
            self::log($log_file, "Errors: {$stats['errors']}");
            self::log($log_file, "Duration: {$duration}ms");
            self::log($log_file, "=== END Weekly Image Cleanup ===\n");

        } catch (Exception $e) {
            self::log($log_file, 'ERROR: ' . $e->getMessage());
        }
    }

    /**
     * Log message to file
     */
    private static function log($file, $message) {
        $timestamp = date('Y-m-d H:i:s');
        $log_entry = "[$timestamp] $message\n";

        // Ensure log directory exists
        $log_dir = dirname($file);
        if (!is_dir($log_dir)) {
            wp_mkdir_p($log_dir);
        }

        file_put_contents($file, $log_entry, FILE_APPEND);
    }
}