<?php

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class xử lý cập nhật mã khuyến mãi và thông tin khách hàng.
 */
class Checkin_MKT192_UpdatePromoCode {
    /**
     * Cập nhật mã khuyến mãi và thông tin thợ làm tóc cho khách hàng.
     */
    public static function update_customer_promo_code() {
        global $wpdb;

        $log_file = __DIR__ . '/logs/update-promoCode-customer.log';
        ini_set('log_errors', 1);
        ini_set('error_log', $log_file);

        // Tính ngày hôm qua
        $yesterday = date('Y-m-d', strtotime('-1 day'));
        $start     = $yesterday . ' 00:00:00';
        $end       = $yesterday . ' 23:59:59';

        $invoice_table  = $wpdb->prefix . 'checkin_mkt192_invoices_data';
        $customer_table = $wpdb->prefix . 'bookingmkt192_customer_data';

        $invoices = $wpdb->get_results($wpdb->prepare(
            "SELECT customer_id, services
             FROM {$invoice_table}
             WHERE created_at BETWEEN %s AND %s",
            $start,
            $end
        ));

        foreach ($invoices as $invoice) {
            if (empty($invoice->customer_id)) {
                continue;
            }

            // Lấy thông tin khách hàng
            $customer = $wpdb->get_row($wpdb->prepare(
                "SELECT membership_level
                 FROM {$customer_table}
                 WHERE customer_id = %s
                 LIMIT 1",
                $invoice->customer_id
            ));

            if (!$customer) {
                continue;
            }

            // Tách danh sách thợ thực hiện từ services
            $staffNames = [];
            $services   = json_decode($invoice->services, true);
            if (is_array($services)) {
                foreach ($services as $svc) {
                    if (!empty($svc['staff_name'])) {
                        $staffNames[] = trim($svc['staff_name']);
                    }
                }
            }

            $staffNames     = array_unique($staffNames);
            $staffNamesText = implode(', ', $staffNames);

            // Dữ liệu cập nhật chung
            $update_data = [
                'hairdresser_name' => $staffNamesText,
                'new_checkin'      => $yesterday
            ];
            $update_format = ['%s', '%s'];

            // Nếu là Thành Viên thì thêm new_code
            if ($customer->membership_level === 'Thành Viên') {
                $characters   = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
                $randomString = substr(str_shuffle($characters), 0, 2);
                $newCode      = $invoice->customer_id . $randomString . date('dmy');

                $update_data['new_code'] = $newCode;
                $update_format[]         = '%s';
            }

            $wpdb->update(
                $customer_table,
                $update_data,
                ['customer_id' => $invoice->customer_id],
                $update_format,
                ['%s']
            );
        }

        $log_message = '✅ Cron update promo code chạy lúc: ' . date('Y-m-d H:i:s') . "\n";
        $log_message .= '📊 Tổng số hóa đơn xử lý: ' . count($invoices) . "\n";
        $log_message .= "📅 Ngày xử lý: $yesterday\n";
        file_put_contents($log_file, $log_message, FILE_APPEND);

        // Gửi thông báo qua Bot Manager
        require_once plugin_dir_path(__FILE__) . '../lark/class-checkin-mkt192-message-bot-manager.php';
        $bot_manager = Checkin_MKT192_Message_Bot_Manager::get_instance();

        $notification_msg = "🔄 *Cập nhật mã khuyến mãi*\n\n";
        $notification_msg .= "📅 Ngày: $yesterday\n";
        $notification_msg .= '📊 Số hóa đơn: ' . count($invoices) . "\n";
        $notification_msg .= '✅ Hoàn tất lúc: ' . date('Y-m-d H:i:s');

        $result = $bot_manager->send_message('promo_code_update', $notification_msg, null);

        if (is_wp_error($result)) {
            file_put_contents($log_file, 'Failed to send notification: ' . $result->get_error_message() . "\n", FILE_APPEND);
        } else if (isset($result['code']) && $result['code'] == 0) {
            file_put_contents($log_file, "Notification sent successfully\n", FILE_APPEND);
        } else {
            $error_msg = isset($result['msg']) ? $result['msg'] : 'Unknown error';
            file_put_contents($log_file, "Bot Manager error: $error_msg\n", FILE_APPEND);
        }
    }
}
?>