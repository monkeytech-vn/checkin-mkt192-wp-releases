<?php

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class quản lý cron job tự động xóa log files
 * Chạy mỗi 2 ngày vào cuối ngày để dọn dẹp log files
 */
class Checkin_MKT192_LogCleanup {
    /**
     * Các file log KHÔNG bị xoá theo chu kỳ (chỉ cắt bớt khi quá to).
     */
    const KEEP_FILES = ['cleanup_history.log', 'update_invoice.log'];

    /**
     * Ngưỡng cắt bớt file được giữ lại (byte).
     */
    const KEEP_MAX_BYTES = 20971520; // 20 MB

    /**
     * Instance của class (Singleton pattern).
     *
     * @var Checkin_MKT192_LogCleanup
     */
    private static $instance = null;

    /**
     * Lấy instance của class.
     *
     * @return Checkin_MKT192_LogCleanup
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor.
     */
    private function __construct() {
        $this->init_hooks();
    }

    /**
     * Khởi tạo các WordPress hooks.
     */
    private function init_hooks() {
        // Đăng ký custom schedule interval (mỗi 2 ngày)
        add_filter('cron_schedules', [$this, 'add_two_days_schedule']);

        // Đăng ký cron event
        add_action('init', [$this, 'schedule_log_cleanup']);

        // Cleanup logs action
        add_action('checkin_mkt192_cleanup_logs', [$this, 'do_cleanup_logs']);
    }

    /**
     * Thêm custom schedule interval (mỗi 2 ngày).
     *
     * @param array $schedules WordPress cron schedules.
     * @return array Modified schedules.
     */
    public function add_two_days_schedule($schedules) {
        $schedules['every_two_days'] = [
            'interval' => 2 * DAY_IN_SECONDS,
            'display'  => __('Mỗi 2 ngày', 'checkin-mkt192-wp')
        ];
        return $schedules;
    }

    /**
     * Schedule cron event nếu chưa có.
     */
    public function schedule_log_cleanup() {
        if (!wp_next_scheduled('checkin_mkt192_cleanup_logs')) {
            // Schedule vào 23:59 (59 seconds before midnight)
            $timestamp = strtotime('tomorrow') - 60;
            wp_schedule_event($timestamp, 'every_two_days', 'checkin_mkt192_cleanup_logs');
        }
    }

    /**
     * Thực hiện cleanup logs.
     */
    public function do_cleanup_logs() {
        $log_dir = dirname(__FILE__, 2) . '/rest-api/logs/';

        if (!file_exists($log_dir)) {
            return;
        }

        $files         = glob($log_dir . '*.log');
        $deleted_count = 0;
        $failed_count  = 0;
        $deleted_files = [];

        foreach ($files as $file) {
            // File giữ lại, không xoá theo chu kỳ:
            //  - cleanup_history.log: nhật ký của chính cron này
            //  - update_invoice.log : dấu vết mọi lần sửa hoá đơn — cần cho đối chất
            //    với thợ (ai tích lý do không ảnh, lúc nào). Xoá 2 ngày/lần là mất bằng
            //    chứng, đã dính một lần hồi 09/2026.
            if (in_array(basename($file), self::KEEP_FILES, true)) {
                $this->trim_if_too_big($file);
                continue;
            }

            if (is_file($file)) {
                $filename = basename($file);
                // Xóa file
                if (@unlink($file)) {
                    $deleted_count++;
                    $deleted_files[] = $filename;
                } else {
                    $failed_count++;
                }
            }
        }

        // Log kết quả vào file riêng
        $this->log_cleanup_result($log_dir, $deleted_count, $failed_count, $deleted_files);
    }

    /**
     * File giữ lại vẫn phải chặn phình vô hạn: quá ngưỡng thì bỏ nửa cũ, giữ nửa mới.
     *
     * @param string $file Đường dẫn file log.
     */
    private function trim_if_too_big($file) {
        if (!is_file($file) || filesize($file) <= self::KEEP_MAX_BYTES) {
            return;
        }

        $content = @file_get_contents($file);
        if ($content === false) {
            return;
        }

        // Cắt từ giữa file, lùi tới đầu bản ghi gần nhất (dòng mở bằng "[")
        $half = (int) floor(strlen($content) / 2);
        $pos  = strpos($content, "\n[", $half);
        $kept = $pos === false ? substr($content, $half) : substr($content, $pos + 1);

        @file_put_contents(
            $file,
            '[' . date('Y-m-d H:i:s') . "] --- log đã cắt bớt phần cũ (quá "
            . round(self::KEEP_MAX_BYTES / 1048576) . "MB) ---\n" . $kept,
            LOCK_EX
        );
    }

    /**
     * Ghi log kết quả cleanup.
     *
     * @param string $log_dir Đường dẫn thư mục log.
     * @param int $deleted_count Số file đã xóa.
     * @param int $failed_count Số file xóa thất bại.
     * @param array $deleted_files Danh sách file đã xóa.
     */
    private function log_cleanup_result($log_dir, $deleted_count, $failed_count, $deleted_files) {
        $cleanup_log = $log_dir . 'cleanup_history.log';
        $timestamp   = date('Y-m-d H:i:s');

        $log_entry = "[{$timestamp}] Cleanup completed: {$deleted_count} files deleted";

        if ($failed_count > 0) {
            $log_entry .= ", {$failed_count} failed";
        }

        if (!empty($deleted_files)) {
            $log_entry .= ' | Deleted: ' . implode(', ', $deleted_files);
        }

        $log_entry .= PHP_EOL;

        error_log($log_entry, 3, $cleanup_log);
    }

    /**
     * Unschedule cron event khi deactivate plugin.
     */
    public static function deactivate() {
        $timestamp = wp_next_scheduled('checkin_mkt192_cleanup_logs');
        if ($timestamp) {
            wp_unschedule_event($timestamp, 'checkin_mkt192_cleanup_logs');
        }
    }
}

// Khởi tạo instance
Checkin_MKT192_LogCleanup::get_instance();