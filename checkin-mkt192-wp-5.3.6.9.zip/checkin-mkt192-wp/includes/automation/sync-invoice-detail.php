<?php
// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class xử lý đồng bộ chi tiết hóa đơn.
 */
class Checkin_MKT192_InvoiceSync {
    /**
     * Đồng bộ dữ liệu hóa đơn từ bảng invoices_data sang invoices_data_detail.
     *
     * @return int Số dòng đã thêm vào bảng chi tiết.
     */
    public static function sync_invoice_details() {
        global $wpdb;

        $source_table = $wpdb->prefix . 'checkin_mkt192_invoices_data';
        $detail_table = $wpdb->prefix . 'checkin_mkt192_invoices_data_detail';
        $products_table = $wpdb->prefix . 'checkin_mkt192_products';
        $services_table = $wpdb->prefix . 'checkin_mkt192_service_data';
        $ctkm_table = $wpdb->prefix . 'checkin_mkt192_ctkm_settings';

        // Log thông báo bắt đầu
        $log_file = __DIR__ . '/logs/sync-invoice-detail.log';
        ini_set('log_errors', 1);
        ini_set('error_log', $log_file);
        file_put_contents($log_file, "Đang đồng bộ dữ liệu từ $source_table sang $detail_table cho hóa đơn trong ngày hôm nay...\n", FILE_APPEND);

        // Lấy khoảng thời gian hôm nay
        $date = new DateTime(current_time('mysql'));
        $today_start = $date->format('Y-m-d 00:00:00');
        $today_end = $date->format('Y-m-d 23:59:59');

        // Lấy danh sách hóa đơn hôm nay
        $invoices = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT invoice_id, services, total, discount, promo_name, created_at
                 FROM $source_table
                 WHERE created_at >= %s AND created_at <= %s",
                $today_start,
                $today_end
            )
        );

        $total_inserted = 0;

        foreach ($invoices as $invoice) {
            $invoice_id = $invoice->invoice_id;
            $services_json = $invoice->services;
            $total_invoice = $invoice->total;
            $discount = $invoice->discount;
            $promo_name = $invoice->promo_name ?? '';
            $created_at = $invoice->created_at;

            if (!$services_json) {
                continue;
            }

            $services = json_decode($services_json, true);
            if (!is_array($services)) {
                file_put_contents($log_file, "❌ Invalid services JSON for invoice $invoice_id\n", FILE_APPEND);
                continue;
            }

            // Xóa dữ liệu cũ của hóa đơn trong bảng chi tiết
            $wpdb->delete($detail_table, ['invoice_id' => $invoice_id]);

            // Lấy thông tin chương trình khuyến mãi (CTKM)
            $ctkm_value = 0;
            $is_ctkm = false;
            if (!empty($promo_name)) {
                $promo_data = $wpdb->get_row(
                    $wpdb->prepare(
                        "SELECT value, promo_type FROM $ctkm_table WHERE ctkm_name = %s",
                        $promo_name
                    )
                );
                if ($promo_data && $promo_data->promo_type === 'ctkm') {
                    $ctkm_value = $promo_data->value !== null ? floatval($promo_data->value) : 0;
                    $is_ctkm = true;
                }
            }

            // Nhóm dịch vụ theo thợ
            $services_by_staff = [];
            foreach ($services as $service) {
                $staff_name = html_entity_decode($service['staff_name'], ENT_QUOTES, 'UTF-8');
                $services_by_staff[$staff_name][] = $service;
            }

            // Lọc các thợ có ít nhất một dịch vụ không phải sản phẩm
            $eligible_staffs = array_filter($services_by_staff, function ($items) {
                foreach ($items as $svc) {
                    if (($svc['type'] ?? 'service') !== 'product') {
                        return true;
                    }
                }
                return false;
            });

            $eligible_staff_count = count($eligible_staffs);
            $discount_per_eligible_staff = $eligible_staff_count > 0 ? ($ctkm_value / $eligible_staff_count) : 0;

            foreach ($services_by_staff as $staff_name => $staff_services) {
                $product_indexes = [];
                $service_indexes = [];
                $chemical_indexes = [];
                $all_prices = [];

                // Phân loại dịch vụ/sản phẩm
                foreach ($staff_services as $i => $svc) {
                    $type = $svc['type'] ?? 'service';
                    if ($type === 'product') {
                        $product_indexes[] = $i;
                    } elseif (($svc['service_type'] ?? '') === 'chemical') {
                        $chemical_indexes[$i] = $svc['price'];
                    } else {
                        $service_indexes[$i] = $svc['price'];
                    }
                    $all_prices[$i] = $svc['price'];
                }

                // Phân bổ giảm giá cho dịch vụ và hóa chất
                $discount_map = [];
                if ($discount_per_eligible_staff > 0 && (!empty($service_indexes) || !empty($chemical_indexes))) {
                    $non_product_count = count($service_indexes) + count($chemical_indexes);
                    if ($non_product_count > 0) {
                        $discount_per_item = $discount_per_eligible_staff / $non_product_count;
                        foreach ($service_indexes as $i => $price) {
                            $discount_map[$i] = $discount_per_item;
                        }
                        foreach ($chemical_indexes as $i => $price) {
                            $discount_map[$i] = $discount_per_item;
                        }
                    }
                }

                foreach ($staff_services as $i => $service) {
                    $type = $service['type'] ?? 'service';
                    $item_name = html_entity_decode($service['service_name'], ENT_QUOTES, 'UTF-8');
                    $quantity = isset($service['quantity']) ? $service['quantity'] : 1;

                    // Lấy giá từ bảng products hoặc services
                    $item_price = 0;
                    $service_type = null;
                    if ($type === 'product') {
                        $item_price = $wpdb->get_var($wpdb->prepare(
                            "SELECT price FROM $products_table WHERE product_name = %s",
                            $item_name
                        ));
                    } else {
                        $service_data = $wpdb->get_row($wpdb->prepare(
                            "SELECT service_price, discounted_price, service_type FROM $services_table WHERE service_name = %s",
                            $item_name
                        ));
                        if ($service_data) {
                            $item_price = $is_ctkm && $service_data->discounted_price !== null
                                ? floatval($service_data->service_price)
                                : floatval($service_data->discounted_price ?? $service_data->service_price);
                            $service_type = $service_data->service_type;
                        } else {
                            $item_price = $service['price'];
                        }
                    }

                    $item_price = $item_price !== null ? floatval($item_price) : floatval($service['price']);
                    $subtotal = $item_price * $quantity;
                    $discount = $discount_map[$i] ?? 0;
                    $total = $subtotal - $discount;

                    // Chuẩn bị dữ liệu để chèn
                    $insert_data = [
                        'invoice_id'    => $invoice_id,
                        'service_name'  => $item_name,
                        'type'          => $type,
                        'price'         => $item_price,
                        'quantity'      => $quantity,
                        'subtotal'      => $subtotal,
                        'discount'      => $discount,
                        'total'         => $total,
                        'total_invoice' => floatval($total_invoice),
                        'staff_name'    => $staff_name,
                        'created_at'    => $created_at,
                        'updated_at'    => current_time('mysql')
                    ];

                    if (isset($service['service_id'])) {
                        $insert_data['service_id'] = sanitize_text_field($service['service_id']);
                    }
                    if (isset($service['staff_id'])) {
                        $insert_data['staff_id'] = sanitize_text_field($service['staff_id']);
                    }
                    if ($type !== 'product') {
                        $insert_data['service_type'] = $service_type;
                    }

                    // Chèn vào bảng chi tiết
                    $result = $wpdb->insert($detail_table, $insert_data);
                    if ($result !== false) {
                        $total_inserted++;
                    } else {
                        file_put_contents($log_file, "❌ Failed to insert detail for invoice $invoice_id, service $item_name: " . $wpdb->last_error . "\n", FILE_APPEND);
                    }
                }
            }
        }

        // Log thông báo hoàn tất
        file_put_contents($log_file, "Đồng bộ hoàn tất. Đã thêm $total_inserted dòng mới cho hóa đơn trong ngày hôm nay.\n", FILE_APPEND);

        return $total_inserted;
    }
}

// Chạy đồng bộ nếu file được gọi trực tiếp
if (defined('ABSPATH') && php_sapi_name() === 'cli') {
    Checkin_MKT192_InvoiceSync::sync_invoice_details();
}
?>