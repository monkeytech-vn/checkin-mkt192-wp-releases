<?php

// Require card builder functions
require_once plugin_dir_path(__FILE__) . '../lark/card-builder.php';

add_action('rest_api_init', function () {
    // register_rest_route() for /cashier-confirm-salary
    register_rest_route('vg/v1', '/confirm-salary', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_confirm_salary',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'salary.confirm']),
        'args'                => [
            'staff_name' => [
                'required'          => true,
                'validate_callback' => function($param, $request, $key) {
                    return is_string($param) && !empty(trim($param));
                }
            ],
            'role' => [
                'required'          => true,
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'period' => [
                'required'          => true,
                'validate_callback' => function($param, $request, $key) {
                    return preg_match('/^\d{4}-\d{2}$/', $param);
                }
            ],
            'action' => [
                'required'          => true,
                'validate_callback' => function($param, $request, $key) {
                    return in_array($param, ['approve', 'reconsider']);
                }
            ],
        ],
    ]);

    // register_rest_route() for /confirm-salary-payment (nhân viên xác nhận đã nhận lương)
    register_rest_route('vg/v1', '/confirm-salary-payment', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_confirm_salary_payment',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'salary.confirm']),
        'args'                => [
            'staff_name' => [
                'required'          => true,
                'validate_callback' => function($param, $request, $key) {
                    return is_string($param) && !empty(trim($param));
                }
            ],
            'role' => [
                'required'          => true,
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'period' => [
                'required'          => true,
                'validate_callback' => function($param, $request, $key) {
                    return preg_match('/^\d{4}-\d{2}$/', $param);
                }
            ],
            'payment_confirmed' => [
                'required'          => true,
                'validate_callback' => function($param, $request, $key) {
                    return in_array($param, ['received', 'disputed']);
                }
            ],
        ],
    ]);

    // register_rest_route() for /upload-payment-image
    register_rest_route('vg/v1', '/upload-payment-images', [
        'methods'             => WP_REST_Server::CREATABLE,
        'callback'            => 'checkin_mkt192_handle_upload_payment_images',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'salary.payment']),
        'args'                => [
            'staff_name' => [
                'required'          => true,
                'type'              => 'string',
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'period' => [
                'required'          => true,
                'type'              => 'string',
                'sanitize_callback' => 'sanitize_text_field',
            ],
            // Không yêu cầu payment_image vì nó nằm trong $_FILES
        ],
    ]);

    // register_rest_route() for /salary-data
    register_rest_route('vg/v1', '/cashier-salary-data', [
        'methods'             => 'GET',
        'callback'            => 'checkin_mkt192_get_cashier_salary_data_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'salary.read'])
    ]);

    // Thẻ hoa hồng theo kỳ (admin)
    register_rest_route('vg/v1', '/salary-period-rates', [
        [
            'methods'             => 'GET',
            'callback'            => 'checkin_mkt192_get_period_rates_api',
            'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'salary.calculate']),
        ],
        [
            'methods'             => 'POST',
            'callback'            => 'checkin_mkt192_save_period_rates_api',
            'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'salary.calculate']),
        ],
        [
            'methods'             => 'DELETE',
            'callback'            => 'checkin_mkt192_delete_period_rates_api',
            'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'salary.calculate']),
        ],
    ]);

    // Phiếu thưởng / phiếu trừ (admin)
    register_rest_route('vg/v1', '/salary-adjustments', [
        ['methods' => 'GET',    'callback' => 'checkin_mkt192_get_adjustments_api',    'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'salary.calculate'])],
        ['methods' => 'POST',   'callback' => 'checkin_mkt192_create_adjustment_api',  'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'salary.calculate'])],
        ['methods' => 'DELETE', 'callback' => 'checkin_mkt192_delete_adjustment_api',  'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'salary.calculate'])],
    ]);
    // Cài đặt lương toàn salon + hồ sơ thợ (admin)
    register_rest_route('vg/v1', '/salary-settings', [
        ['methods' => 'GET',  'callback' => 'checkin_mkt192_salary_settings_api', 'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'salary.calculate'])],
        ['methods' => 'POST', 'callback' => 'checkin_mkt192_salary_settings_api', 'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'salary.calculate'])],
    ]);
    register_rest_route('vg/v1', '/salary-diagnostics', [
        'methods'             => 'GET',
        'callback'            => 'checkin_mkt192_salary_diagnostics_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'salary.calculate']),
    ]);
    register_rest_route('vg/v1', '/salary-tiers-migrate', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_salary_tiers_migrate_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'salary.calculate']),
    ]);
    register_rest_route('vg/v1', '/kpi-result', [
        'methods'             => 'GET',
        'callback'            => 'checkin_mkt192_kpi_result_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'salary.read']),
    ]);
    register_rest_route('vg/v1', '/kpi-result/manual', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_kpi_manual_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'salary.calculate']),
    ]);
    register_rest_route('vg/v1', '/staff-profile', [
        'methods'             => 'GET',
        'callback'            => 'checkin_mkt192_staff_profile_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'salary.read']),
    ]);
    // Cài đặt truy thu đánh giá thấp (admin)
    register_rest_route('vg/v1', '/salary-review-penalty', [
        ['methods' => 'GET',  'callback' => 'checkin_mkt192_review_penalty_settings_api', 'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'salary.calculate'])],
        ['methods' => 'POST', 'callback' => 'checkin_mkt192_review_penalty_settings_api', 'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'salary.calculate'])],
    ]);

    register_rest_route('vg/v1', '/hairdresser-salary-data', [
        'methods'             => 'GET',
        'callback'            => 'checkin_mkt192_get_hairdresser_salary_data',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'salary.read'])
    ]);

    register_rest_route('vg/v1', '/evaluate-kpi', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_rest_evaluate_kpi',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'kpi.evaluate'])
    ]);

    // register_rest_route() for /update-cashier-salary
    register_rest_route('vg/v1', '/update-cashier-salary', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_update_cashier_salary_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'salary.calculate']),
        'args'                => [
            'period' => [
                'required'          => true,
                'type'              => 'string',
                'validate_callback' => function($param) {
                    return preg_match('/^\d{4}-\d{2}$/', $param);
                },
            ],
        ],
    ]);

    register_rest_route('vg/v1', '/update-hairdresser-salary', [
    'methods'             => 'POST',
    'callback'            => 'checkin_mkt192_update_hairdresser_salary',
    'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'salary.calculate']),
    'args'                => [
        'period' => [
            'required'          => true,
            'type'              => 'string',
            'validate_callback' => function($param) {
                return preg_match('/^\d{4}-\d{2}$/', $param);
            },
        ],
        'staff_name' => [
            'required'          => false,
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field'
        ]
    ],
]);

    // register_rest_route() for /send-salary-notification
    register_rest_route('vg/v1', '/send-salary-notification', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_send_salary_notification',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'salary.notify']),
        'args'                => [
            'period' => [
                'required'          => true,
                'type'              => 'string',
                'validate_callback' => function($param) {
                    return preg_match('/^\d{4}-\d{2}$/', $param);
                },
                'sanitize_callback' => 'sanitize_text_field'
            ]
        ]
    ]);

    // register_rest_route() for /check-salary-notification-status
    register_rest_route('vg/v1', '/check-salary-notification-status', [
        'methods'             => 'GET',
        'callback'            => 'checkin_mkt192_check_salary_notification_status',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'salary.notify']),
        'args'                => [
            'period' => [
                'required'          => true,
                'type'              => 'string',
                'validate_callback' => function($param) {
                    return preg_match('/^\d{4}-\d{2}$/', $param);
                },
                'sanitize_callback' => 'sanitize_text_field'
            ]
        ]
    ]);

    // register_rest_route() for /update-uniform-fee
    register_rest_route('vg/v1', '/update-uniform-fee', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_update_uniform_fee',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'salary.calculate']),
        'args'                => [
            'staff_name' => [
                'required'          => true,
                'type'              => 'string',
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'period' => [
                'required'          => true,
                'type'              => 'string',
                'validate_callback' => function($param) {
                    return preg_match('/^\d{4}-\d{2}$/', $param);
                },
                'sanitize_callback' => 'sanitize_text_field'
            ],
            'role' => [
                'required'          => true,
                'type'              => 'string',
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'uniform_fee' => [
                'required'          => true,
                'type'              => 'number',
                'validate_callback' => function($param) {
                    return is_numeric($param) && $param >= 0;
                },
            ],
        ]
    ]);

    // === Average Salary (12 tháng) - Admin Only ===
    register_rest_route('vg/v1', '/average-salary', [
        'methods'             => 'GET',
        'callback'            => 'checkin_mkt192_get_average_salary',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'salary.read']),
        'args'                => [
            'staff_name' => [
                'required'          => true,
                'type'              => 'string',
                'sanitize_callback' => 'sanitize_text_field'
            ],
            'role' => [
                'required'          => true,
                'type'              => 'string',
                'sanitize_callback' => 'sanitize_text_field',
                'validate_callback' => function($param) {
                    return in_array($param, ['hairdresser', 'cashier']);
                }
            ],
            'year' => [
                'required'          => false,
                'type'              => 'string',
                'sanitize_callback' => 'sanitize_text_field',
                'validate_callback' => function($param) {
                    return preg_match('/^\d{4}$/', $param);
                }
            ]
        ]
    ]);
});

/**
 * Tên hiển thị (display_name) của nhân viên đang đăng nhập, null nếu không có hồ sơ staff.
 */
function checkin_mkt192_current_staff_display_name() {
    static $cache = false;
    if ($cache !== false) {
        return $cache;
    }
    $cache = null;
    if (is_user_logged_in()) {
        global $wpdb;
        $cache = $wpdb->get_var($wpdb->prepare(
            "SELECT display_name FROM {$wpdb->prefix}checkin_mkt192_staff WHERE user_id = %d LIMIT 1",
            get_current_user_id()
        ));
        $cache = $cache !== null ? (string)$cache : null;
    }
    return $cache;
}

/**
 * Phiếu lương đã "chốt" chưa: nhân viên đã Đồng ý, admin đã tải chứng từ, hoặc đã nhận đủ.
 * Chốt rồi thì không tự tính lại nữa.
 */
function checkin_mkt192_salary_row_is_locked($row) {
    if (!$row) {
        return false;
    }
    return ($row->xac_nhan_luong ?? '') === 'Đồng ý'
        || !empty($row->payment)
        || ($row->status ?? '') === 'received'
        || ($row->xac_nhan_thanh_toan ?? '') === 'Đã nhận đủ';
}

/**
 * Tự tính lương khi nhân viên mở phiếu lương — không cần đợi admin bấm "Tính lương".
 *
 * Điều kiện: chỉ kỳ hiện tại và kỳ liền trước; phiếu chưa chốt; người xem là chính nhân viên
 * đó hoặc có quyền salary.calculate; tối đa 1 lần / 2 phút cho mỗi (vai trò, nhân viên, kỳ).
 * Trả về true nếu vừa tính lại.
 */
function checkin_mkt192_maybe_autocompute_salary($role, $staff_name, $period) {
    global $wpdb;

    if ($staff_name === '' || !preg_match('/^\d{4}-\d{2}$/', $period)) {
        return false;
    }

    $current  = current_time('Y-m');
    $previous = date('Y-m', strtotime($current . '-01 -1 month'));
    if (!in_array($period, [$current, $previous], true)) {
        return false;
    }

    $self = checkin_mkt192_current_staff_display_name();
    if ($self !== $staff_name
        && checkin_mkt192_evaluate_permission_rule(['mode' => 'login', 'scope' => 'salary.calculate']) !== true) {
        return false;
    }

    $table = $role === 'cashier'
        ? $wpdb->prefix . 'checkin_mkt192_cashier_salary'
        : $wpdb->prefix . 'checkin_mkt192_hairdresser_salary';
    $row = $wpdb->get_row($wpdb->prepare(
        "SELECT xac_nhan_luong, payment, status, xac_nhan_thanh_toan FROM {$table} WHERE staff_name = %s AND period = %s LIMIT 1",
        $staff_name,
        $period
    ));
    if (checkin_mkt192_salary_row_is_locked($row)) {
        return false;
    }

    $throttle_key = 'ckm_autosal_' . md5($role . '|' . $staff_name . '|' . $period);
    if (get_transient($throttle_key)) {
        return false;
    }
    set_transient($throttle_key, 1, 2 * MINUTE_IN_SECONDS);

    $request = new WP_REST_Request('POST');
    $request->set_param('period', $period);
    $request->set_param('staff_name', $staff_name);

    if ($role === 'cashier') {
        checkin_mkt192_update_cashier_salary_api($request);
    } else {
        // Kỳ chưa chốt: đánh giá lại KPI theo số liệu mới nhất rồi mới tính lương (KPI trượt trừ % hoa hồng, thưởng SP…)
        if (function_exists('checkin_mkt192_evaluate_kpi_and_update_salary')) {
            checkin_mkt192_evaluate_kpi_and_update_salary($period, $staff_name);
        }
        checkin_mkt192_update_hairdresser_salary($request);
    }
    return true;
}

function checkin_mkt192_get_cashier_salary_data_api(WP_REST_Request $request) {
    global $wpdb;
    $type       = sanitize_text_field($request->get_param('type')); // Chỉ hỗ trợ 'salary'
    $period     = sanitize_text_field($request->get_param('period') ?: date('Y-m'));
    $staff_name = sanitize_text_field($request->get_param('staff_name'));
    $branch_id  = absint($request->get_param('branch_id'));

    try {
        if ($type !== 'salary') {
            return new WP_REST_Response([
                'success' => false,
                'message' => 'Type không hợp lệ. Chỉ hỗ trợ type=salary.'
            ], 400);
        }

        // Lấy dữ liệu từ checkin_mkt192_cashier_salary
        $view_block = $staff_name ? checkin_mkt192_staff_view_block($period) : null;
        if ($view_block) {
            return new WP_REST_Response(['success' => true, 'type' => 'salary', 'auto_computed' => false, 'data' => [], 'view_block' => $view_block], 200);
        }
        $auto_computed = $staff_name ? checkin_mkt192_maybe_autocompute_salary('cashier', $staff_name, $period) : false;

        $query = "SELECT id, staff_name, period, total_hours, advance_salary, level_name, level_start_date,
                hourly_salary, total_salary, standard_hours, total_of_deductions,
                probation_hours, official_hours, probation_hourly_salary, official_hourly_salary,
                product_total, product_count_total, product_salary, actual_salary,
                uniform_fee, xac_nhan_luong, payment, xac_nhan_thanh_toan, status, branch_id, adjustments_json
                  FROM {$wpdb->prefix}checkin_mkt192_cashier_salary
                  WHERE period = %s";
        $params = [$period];
        if ($staff_name) {
            $query .= ' AND staff_name = %s';
            $params[] = $staff_name;
        }
        // Lọc theo branch_id nếu site bật đa chi nhánh và có branch_id được truyền vào
        if (checkin_mkt192_is_multi_branch_enabled() && $branch_id > 0) {
            $query .= ' AND branch_id = %d';
            $params[] = $branch_id;
        }
        $salaries = $wpdb->get_results($wpdb->prepare($query, $params), OBJECT);
        foreach ($salaries as $row) {
            $row->attendance  = checkin_mkt192_attendance_stats((string)$row->staff_name, (string)$row->period);
            $row->avatar      = checkin_mkt192_staff_avatar((string)$row->staff_name);
            $decoded          = !empty($row->adjustments_json) ? json_decode($row->adjustments_json, true) : null;
            $row->adjustments = is_array($decoded) ? $decoded : null;
            unset($row->adjustments_json);
        }

        return new WP_REST_Response([
            'success'       => true,
            'type'          => 'salary',
            'auto_computed' => $auto_computed,
            'data'          => $salaries
        ], 200);
    } catch (Exception $e) {
        checkin_mkt192_log_error('cashier_salary', "Failed to fetch salary data for type: $type, period: $period, staff_name: $staff_name. Error: " . $e->getMessage());
        return new WP_Error('db_error', 'Lỗi truy vấn cơ sở dữ liệu: ' . $e->getMessage(), ['status' => 500]);
    }
}

function checkin_mkt192_update_cashier_salary_api(WP_REST_Request $request) {
    global $wpdb;

    try {
        $period       = sanitize_text_field($request->get_param('period'));
        $staff_filter = sanitize_text_field($request->get_param('staff_name'));
        $start_date   = "$period-01 00:00:00";
        $end_date     = date('Y-m-t 23:59:59', strtotime($start_date));

        // Lấy danh sách nhân viên Thu Ngân từ checkinlogs
        $staff_list = $wpdb->get_col($wpdb->prepare(
            "SELECT DISTINCT display_name
             FROM {$wpdb->prefix}checkin_mkt192_checkinlogs
             WHERE employee_role = 'Thu Ngân'
             AND checkin_time >= %s AND checkin_time <= %s",
            $start_date, $end_date
        ));

        // Chỉ tính cho một người khi được yêu cầu (tự tính lúc nhân viên mở phiếu lương)
        if ($staff_filter !== '') {
            $staff_list = array_values(array_filter($staff_list, function ($name) use ($staff_filter) {
                return $name === $staff_filter;
            }));
        }

        if (empty($staff_list)) {
            return new WP_REST_Response([
                'success' => false,
                'message' => 'Không tìm thấy nhân viên Thu Ngân trong kỳ này.'
            ], 404);
        }

        // Kiểm tra chế độ đa chi nhánh
        $is_multi_branch = checkin_mkt192_is_multi_branch_enabled();

        foreach ($staff_list as $staff_name) {
            // Lấy branch_id của staff nếu bật đa chi nhánh
            $staff_branch_id = 0;
            if ($is_multi_branch) {
                $staff_branch_id = (int) $wpdb->get_var($wpdb->prepare(
                    "SELECT branch_id FROM {$wpdb->prefix}checkin_mkt192_staff WHERE display_name = %s LIMIT 1",
                    $staff_name
                ));
            }

            // Lấy tất cả cấp bậc chồng lấp với kỳ lương
            $levels = $wpdb->get_results($wpdb->prepare(
                "SELECT slh.level_name, slh.start_time, slh.end_time, sls.hourly_salary
                 FROM {$wpdb->prefix}checkin_mkt192_staff_level_history slh
                 LEFT JOIN {$wpdb->prefix}checkin_mkt192_salary_level_settings sls
                     ON slh.level_name = sls.level_name AND sls.role LIKE '%Thu Ngân%'
                 WHERE slh.staff_name = %s
                 AND slh.start_time <= %s
                 AND (slh.end_time IS NULL OR slh.end_time >= %s)
                 ORDER BY slh.start_time ASC",
                $staff_name, $end_date, $start_date
            ), ARRAY_A);

            if (empty($levels)) {
                continue;
            }

            // Xây dựng các khoảng thời gian dựa trên levels
            $intervals     = [];
            $current_start = date('Y-m-d 00:00:00', strtotime($start_date));
            $period_end    = date('Y-m-d 23:59:59', strtotime($end_date));

            foreach ($levels as $level) {
                $level_start = date('Y-m-d 00:00:00', strtotime($level['start_time']));
                $level_end   = $level['end_time'] ? date('Y-m-d 23:59:59', strtotime($level['end_time'])) : $period_end;

                if (strtotime($level_start) > strtotime($current_start)) {
                    $prev_end = date('Y-m-d 23:59:59', strtotime($level_start . ' -1 day'));
                    if (strtotime($prev_end) >= strtotime($current_start)) {
                        $intervals[] = [
                            'start'         => $current_start,
                            'end'           => $prev_end,
                            'level_name'    => 'N/A (Fallback)',
                            'hourly_salary' => 0
                        ];
                    }
                }

                $interval_start = max($current_start, $level_start);
                $interval_end   = min($period_end, $level_end);
                if (strtotime($interval_end) >= strtotime($interval_start)) {
                    $intervals[] = [
                        'start'         => $interval_start,
                        'end'           => $interval_end,
                        'level_name'    => $level['level_name'],
                        'hourly_salary' => floatval($level['hourly_salary'] ?? 0)
                    ];
                }

                $current_start = date('Y-m-d 00:00:00', strtotime($level_end . ' +1 day'));
            }

            if (strtotime($current_start) <= strtotime($period_end)) {
                $intervals[] = [
                    'start'         => $current_start,
                    'end'           => $period_end,
                    'level_name'    => 'N/A (Fallback)',
                    'hourly_salary' => 0
                ];
            }

            // Tính tổng giờ và lương cho từng khoảng
$total_hours             = 0;
$standard_hours          = 0;
$probation_hours         = 0;
$official_hours          = 0;
$probation_salary        = 0;
$official_salary         = 0;
$probation_hourly_salary = 0;
$official_hourly_salary  = 0;
$level_start_date        = '';

// Xác định bậc thử việc và chính thức dựa trên levels
$probation_level = null;
$official_level  = null;
if (count($levels) >= 2) {
    $probation_level = $levels[0]; // Bậc cũ nhất là thử việc
    $official_level  = end($levels); // Bậc mới nhất là chính thức
} elseif (count($levels) == 1) {
    $official_level = $levels[0]; // Nếu chỉ có 1 bậc, mặc định là chính thức
}

foreach ($intervals as $interval) {
    if ($interval['hourly_salary'] == 0) {
        continue;
    }

    $interval_start = $interval['start'];
    $interval_end   = $interval['end'];

    $checkins = $wpdb->get_results($wpdb->prepare(
        "SELECT checkin_time, checkout_time, shift, approval_ot, approval_late
         FROM {$wpdb->prefix}checkin_mkt192_checkinlogs
         WHERE display_name = %s
         AND employee_role = 'Thu Ngân'
         AND checkin_time >= %s AND checkin_time <= %s
         AND status = 'success'",
        $staff_name, $interval_start, $interval_end
    ), ARRAY_A);

    $interval_total_hours    = 0;
    $interval_standard_hours = 0;
    foreach ($checkins as $checkin) {
        $checkin_time  = strtotime($checkin['checkin_time']);
        $checkout_time = $checkin['checkout_time'] ? strtotime($checkin['checkout_time']) : null;

        if (!$checkout_time) {
            continue;
        }

        $shift = $wpdb->get_row($wpdb->prepare(
            "SELECT start_time, end_time
             FROM {$wpdb->prefix}checkin_mkt192_shiftsettings
             WHERE shift_name = %s",
            $checkin['shift']
        ), ARRAY_A);

        $shift_start = $shift ? strtotime(date('Y-m-d', $checkin_time) . ' ' . $shift['start_time']) : $checkin_time;
        $shift_end   = $shift ? strtotime(date('Y-m-d', $checkin_time) . ' ' . $shift['end_time']) : $checkout_time;

        if ($shift_end < $shift_start) {
            $shift_end += 86400;
        }

        $start_time = $checkin_time;
        $end_time   = $checkout_time;

        if (strtolower($checkin['approval_ot'] ?? '') === 'approved') {
            $end_time = $checkout_time;
        } else {
            $start_time = max($checkin_time, $shift_start);
            $end_time   = min($checkout_time, $shift_end);
        }

        if ($end_time > $start_time) {
            $hours = ($end_time - $start_time) / 3600;
            if ($hours > 0 && $hours <= 24) {
                $interval_total_hours += $hours;
            }
        }

        $standard_start_time = max($checkin_time, $shift_start);
        $standard_end_time   = min($checkout_time, $shift_end);
        if ($standard_end_time > $standard_start_time) {
            $hours = ($standard_end_time - $standard_start_time) / 3600;
            if ($hours > 0 && $hours <= 24) {
                $interval_standard_hours += $hours;
            }
        }
    }

    $interval_total_hours = round($interval_total_hours, 2);
    $interval_salary      = round($interval_total_hours * $interval['hourly_salary'], 0);

    // Phân loại dựa trên cấp bậc
    if ($probation_level && $interval['level_name'] === $probation_level['level_name'] && $interval['hourly_salary'] == $probation_level['hourly_salary']) {
        $probation_hours  += $interval_total_hours;
        $probation_salary += $interval_salary;
        $probation_hourly_salary = $interval['hourly_salary'];
    } elseif ($official_level && $interval['level_name'] === $official_level['level_name'] && $interval['hourly_salary'] == $official_level['hourly_salary']) {
        $official_hours  += $interval_total_hours;
        $official_salary += $interval_salary;
        $official_hourly_salary = $interval['hourly_salary'];
    } else {
        // Trường hợp không khớp (hiếm khi xảy ra), gán vào chính thức làm fallback
        $official_hours  += $interval_total_hours;
        $official_salary += $interval_salary;
        $official_hourly_salary = $interval['hourly_salary'];
    }

    $total_hours    += $interval_total_hours;
    $standard_hours += round($interval_standard_hours, 2);
}

            // Tính thưởng sản phẩm
            $product_total       = 0;
            $product_count_total = 0;
            $product_salary      = 0;

            $product_details = $wpdb->get_results($wpdb->prepare(
                "SELECT total
                 FROM {$wpdb->prefix}checkin_mkt192_invoices_data_detail
                 WHERE staff_name = %s
                 AND type = 'product'
                 AND created_at BETWEEN %s AND %s",
                $staff_name, $start_date, $end_date
            ), ARRAY_A);

            $product_totals      = array_column($product_details, 'total');
            $product_total       = array_sum($product_totals);
            $product_count_total = count($product_details);

            $kpi_result = $wpdb->get_row($wpdb->prepare(
                "SELECT product_achieved, product_bonus
                 FROM {$wpdb->prefix}checkin_mkt192_kpi_results
                 WHERE staff_name = %s AND period = %s AND is_evaluated = 1",
                $staff_name, $period
            ));

            if ($kpi_result && $kpi_result->product_achieved == 1) {
                $product_salary = round($product_total * ($kpi_result->product_bonus / 100), 0);
            } elseif ($kpi_result) {
                $product_salary = 0;
            } else {
                if ($product_count_total >= 1) {
                    $product_salary = round($product_total * 0.10, 0);
                } else {
                    $product_salary = 0;
                }
            }

            // Phiếu thưởng / phiếu trừ của thu ngân + phí đồng phục (cột legacy) đã có
            $adjustments = checkin_mkt192_collect_adjustments($staff_name, $period);
            $uniform_fee = floatval($wpdb->get_var($wpdb->prepare(
                "SELECT uniform_fee FROM {$wpdb->prefix}checkin_mkt192_cashier_salary WHERE staff_name = %s AND period = %s LIMIT 1",
                $staff_name, $period
            )) ?: 0);

            // Tính tổng lương
            $total_salary = $probation_salary + $official_salary + $product_salary + $adjustments['bonus_total'];

            // Lấy level mới nhất
            $latest_level = $wpdb->get_row($wpdb->prepare(
                "SELECT slh.level_name, slh.start_time, sls.hourly_salary
                 FROM {$wpdb->prefix}checkin_mkt192_staff_level_history slh
                 LEFT JOIN {$wpdb->prefix}checkin_mkt192_salary_level_settings sls ON slh.level_name = sls.level_name
                 WHERE slh.staff_name = %s
                 ORDER BY slh.start_time DESC
                 LIMIT 1",
                $staff_name
            ), ARRAY_A);
            $level_name       = $latest_level['level_name'] ?? 'N/A';
            $level_start_date = $latest_level['start_time'] ? date('Y-m-d', strtotime($latest_level['start_time'])) : '';
            $hourly_salary    = $latest_level['hourly_salary'] ?? 0;

            // Lấy tiền tạm ứng từ bảng approval_requests mới
            $advance_salary = $wpdb->get_var($wpdb->prepare(
                "SELECT SUM(advance_amount)
                 FROM {$wpdb->prefix}checkin_mkt192_approval_requests
                 WHERE staff_name = %s
                 AND request_type = 'salary_advance'
                 AND status = 'approved'
                 AND request_date LIKE %s",
                $staff_name, "$period%"
            )) ?: 0;

            // Tổng khấu trừ và thực nhận
            $total_of_deductions = $advance_salary + $uniform_fee + $adjustments['deduction_total'];
            $actual_salary       = round($total_salary - $total_of_deductions, 0);

            // Lưu vào DB với kiểm tra lỗi
            $existing_id = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM {$wpdb->prefix}checkin_mkt192_cashier_salary WHERE staff_name = %s AND period = %s",
                $staff_name, $period
            ));

            $data = [
                'staff_name'              => $staff_name,
                'level_name'              => $level_name,
                'total_hours'             => $total_hours,
                'standard_hours'          => $standard_hours,
                'advance_salary'          => $advance_salary,
                'updated_at'              => current_time('mysql'),
                'level_start_date'        => $level_start_date,
                'hourly_salary'           => $hourly_salary,
                'total_salary'            => $total_salary,
                'total_of_deductions'     => $total_of_deductions,
                'actual_salary'           => $actual_salary,
                'probation_hourly_salary' => $probation_hourly_salary,
                'official_hourly_salary'  => $official_hourly_salary,
                'probation_hours'         => $probation_hours,
                'official_hours'          => $official_hours,
                'product_total'           => (int)$product_total,
                'product_count_total'     => (int)$product_count_total,
                'product_salary'          => (int)$product_salary,
                'adjustments_json'       => $adjustments['items'] ? wp_json_encode($adjustments, JSON_UNESCAPED_UNICODE) : null,
                'period'                  => $period
            ];

            // Thêm branch_id nếu bật chế độ đa chi nhánh
            if ($is_multi_branch && $staff_branch_id > 0) {
                $data['branch_id'] = $staff_branch_id;
            }

            if ($existing_id) {
                $wpdb->update(
                    "{$wpdb->prefix}checkin_mkt192_cashier_salary",
                    $data,
                    ['id' => $existing_id]
                );
            } else {
                $wpdb->insert(
                    "{$wpdb->prefix}checkin_mkt192_cashier_salary",
                    $data
                );
            }
        }

        return new WP_REST_Response([
            'success' => true,
            'message' => 'Cập nhật bảng lương Thu Ngân thành công'
        ], 200);
    } catch (Exception $e) {
        checkin_mkt192_log_error('cashier_salary', 'Lỗi: ' . $e->getMessage());
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Lỗi hệ thống: ' . $e->getMessage()
        ], 500);
    }
}

/**
 * Tính % hoa hồng hiệu lực cho một khoản lương.
 *
 * Ưu tiên tỷ lệ suy ra từ số đã lưu (lương / doanh số) vì đó là con số thực
 * đã trả cho thợ tại kỳ đó; chỉ khi doanh số = 0 (không suy được) mới rơi về
 * cài đặt bậc hiện tại.
 */
function checkin_mkt192_effective_commission_percent($salary_amount, $base_amount, $fallback_percent) {
    $base = floatval($base_amount);
    if ($base > 0) {
        return round(floatval($salary_amount) / $base * 100, 2);
    }
    return round(floatval($fallback_percent), 2);
}



/* =====================================================================
   CÀI ĐẶT LƯƠNG TOÀN SALON (option checkin_mkt192_salary_settings)
   ===================================================================== */

function checkin_mkt192_salary_settings_defaults() {
    return [
        'pay_period'        => 'month',      // 'month' — theo tuần chưa hỗ trợ (kỳ lương là YYYY-MM toàn hệ thống)
        'staff_view'        => 'always',     // 'always' = nhân viên xem tạm tính kỳ đang chạy · 'after_day' = kỳ T chỉ hiện từ ngày N tháng T+1
        'staff_view_day'    => 5,
        'kpi_changes_level' => false,        // KPI tự hạ/khôi phục cấp bậc (cơ chế cũ) — mặc định tắt từ khi có 4 hạng Barber
        // mode: percent = truy thu % giá trị hoá đơn · fixed = phạt số tiền cố định mỗi hoá đơn (Kent bỏ kiểu "truy thu hoa hồng" 10/09/2026)
        'review_penalty'    => ['enabled' => false, 'mode' => 'percent', 'value' => 0, 'threshold' => 3],
        'no_image_penalty'  => [
            'enabled'       => false,
            'mode'          => 'percent',
            'value'         => 0,
            'skip_guest'    => true,          // bỏ qua khách vãng lai (customer_name / lý do "Khách vãng lai")
            'valid_reasons' => ['Khách khó tính', 'Khách vãng lai', 'Khách vội đi về', 'Khách ko cắt tóc', 'Khách lớn tuổi'], // lý do hợp lệ → không truy thu
        ],
        'card_defaults'     => [             // mặc định khi tạo thẻ hoa hồng đầu tiên cho thợ
            'product_percent'     => 10,
            'product_min_qty'     => 1,
            'overtime_percent'    => 10,
            'kpi_required'        => ['feedback', 'post_fb'],
            'kpi_penalty_percent' => 5,
            'kpi_penalty_scope'   => 'service',
            'kpi_penalty_mode'    => 'once',
        ],
    ];
}

/** Chuẩn hoá mảng cài đặt (đã gộp defaults). */
function checkin_mkt192_normalize_salary_settings($saved) {
    $d     = checkin_mkt192_salary_settings_defaults();
    $saved = is_array($saved) ? $saved : [];
    // Tương thích: option truy thu đánh giá riêng (bản 5.3.4.8) nếu chưa gộp
    if (!isset($saved['review_penalty'])) {
        $legacy = get_option('checkin_mkt192_review_penalty', null);
        if (is_array($legacy)) {
            $saved['review_penalty'] = $legacy;
        }
    }
    $out = array_replace_recursive($d, $saved);
    if (isset($saved['card_defaults']['kpi_required'])) {
        $out['card_defaults']['kpi_required'] = array_values((array)$saved['card_defaults']['kpi_required']);
    }
    $out['pay_period']        = 'month';
    $out['staff_view']        = ($out['staff_view'] ?? 'always') === 'after_day' ? 'after_day' : 'always';
    $out['staff_view_day']    = max(1, min(28, (int)$out['staff_view_day']));
    $out['kpi_changes_level'] = (bool)$out['kpi_changes_level'];
    // Kiểu cũ 'commission' (bản 5.3.6.0–5.3.6.1) → về 'percent' với mức 0: admin phải nhập mức trước khi bật
    $mode_ok = function ($m) { return $m === 'fixed' ? 'fixed' : 'percent'; };
    $rp = $out['review_penalty'];
    if (($rp['mode'] ?? '') === 'commission') { $rp['mode'] = 'percent'; $rp['value'] = 0; }
    $out['review_penalty'] = [
        'enabled'   => (bool)($rp['enabled'] ?? false),
        'mode'      => $mode_ok($rp['mode'] ?? 'percent'),
        'value'     => max(0, floatval($rp['value'] ?? 0)),
        'threshold' => max(1, min(5, (int)($rp['threshold'] ?? 3))),
    ];
    if ($out['review_penalty']['mode'] === 'percent') $out['review_penalty']['value'] = min(100, $out['review_penalty']['value']);
    $ni = $out['no_image_penalty'];
    if (isset($saved['no_image_penalty']['valid_reasons'])) {
        $ni['valid_reasons'] = array_values((array)$saved['no_image_penalty']['valid_reasons']);
    }
    if (($ni['mode'] ?? '') === 'commission') { $ni['mode'] = 'percent'; $ni['value'] = 0; }
    $out['no_image_penalty'] = [
        'enabled'       => (bool)($ni['enabled'] ?? false),
        'mode'          => $mode_ok($ni['mode'] ?? 'percent'),
        'value'         => max(0, floatval($ni['value'] ?? 0)),
        'skip_guest'    => (bool)($ni['skip_guest'] ?? true),
        'valid_reasons' => array_values(array_filter(array_map('sanitize_text_field', (array)($ni['valid_reasons'] ?? [])))),
    ];
    if ($out['no_image_penalty']['mode'] === 'percent') $out['no_image_penalty']['value'] = min(100, $out['no_image_penalty']['value']);
    $cd = $out['card_defaults'];
    $out['card_defaults'] = [
        'product_percent'     => max(0, min(100, round(floatval($cd['product_percent']), 2))),
        'product_min_qty'     => max(0, (int)$cd['product_min_qty']),
        'overtime_percent'    => max(0, min(100, round(floatval($cd['overtime_percent']), 2))),
        'kpi_required'        => array_values(array_intersect(['feedback', 'post_fb', 'service', 'product'], (array)$cd['kpi_required'])),
        'kpi_penalty_percent' => max(0, min(100, round(floatval($cd['kpi_penalty_percent']), 2))),
        'kpi_penalty_scope'   => in_array($cd['kpi_penalty_scope'], ['service', 'chemical', 'both'], true) ? $cd['kpi_penalty_scope'] : 'service',
        'kpi_penalty_mode'    => ($cd['kpi_penalty_mode'] ?? 'once') === 'each' ? 'each' : 'once',
    ];
    return $out;
}

function checkin_mkt192_salary_settings($reload = false) {
    static $cache = null;
    if ($cache === null || $reload) {
        $cache = checkin_mkt192_normalize_salary_settings(get_option('checkin_mkt192_salary_settings', []));
    }
    return $cache;
}

/** GET/POST /salary-settings */
function checkin_mkt192_salary_settings_api(WP_REST_Request $request) {
    if ($request->get_method() === 'GET') {
        return ['success' => true, 'data' => checkin_mkt192_salary_settings(true), 'tiers' => checkin_mkt192_barber_tiers()];
    }
    $cur  = checkin_mkt192_salary_settings(true);
    $body = $request->get_json_params() ?: $request->get_params();
    $new  = $cur;
    if (isset($body['staff_view']))        $new['staff_view'] = sanitize_text_field($body['staff_view']);
    if (isset($body['staff_view_day']))    $new['staff_view_day'] = (int)$body['staff_view_day'];
    if (isset($body['kpi_changes_level'])) $new['kpi_changes_level'] = filter_var($body['kpi_changes_level'], FILTER_VALIDATE_BOOLEAN);
    if (isset($body['review_penalty']) && is_array($body['review_penalty'])) {
        $rp = $body['review_penalty'];
        $new['review_penalty'] = [
            'enabled'   => filter_var($rp['enabled'] ?? false, FILTER_VALIDATE_BOOLEAN),
            'mode'      => sanitize_text_field($rp['mode'] ?? 'percent'),
            'value'     => floatval($rp['value'] ?? 0),
            'threshold' => (int)($rp['threshold'] ?? 3),
        ];
        if ($new['review_penalty']['enabled'] && $new['review_penalty']['value'] <= 0) {
            return new WP_Error('invalid_value', 'Truy thu đánh giá thấp: nhập mức truy thu (% giá trị hoá đơn hoặc số tiền cố định) trước khi bật.', ['status' => 400]);
        }
    }
    if (isset($body['no_image_penalty']) && is_array($body['no_image_penalty'])) {
        $ni = $body['no_image_penalty'];
        $new['no_image_penalty'] = [
            'enabled'       => filter_var($ni['enabled'] ?? false, FILTER_VALIDATE_BOOLEAN),
            'mode'          => sanitize_text_field($ni['mode'] ?? 'percent'),
            'value'         => floatval($ni['value'] ?? 0),
            'skip_guest'    => filter_var($ni['skip_guest'] ?? true, FILTER_VALIDATE_BOOLEAN),
            'valid_reasons' => array_values(array_filter(array_map('sanitize_text_field', (array)($ni['valid_reasons'] ?? [])))),
        ];
        if ($new['no_image_penalty']['enabled'] && $new['no_image_penalty']['value'] <= 0) {
            return new WP_Error('invalid_value', 'Truy thu hoá đơn không ảnh: nhập mức truy thu (% giá trị hoá đơn hoặc số tiền cố định) trước khi bật.', ['status' => 400]);
        }
    }
    if (isset($body['card_defaults']) && is_array($body['card_defaults'])) {
        $new['card_defaults'] = array_replace($cur['card_defaults'], array_intersect_key($body['card_defaults'], $cur['card_defaults']));
    }
    $new = checkin_mkt192_normalize_salary_settings($new);
    update_option('checkin_mkt192_salary_settings', $new, false);
    return ['success' => true, 'data' => checkin_mkt192_salary_settings(true), 'message' => 'Đã lưu cài đặt lương.'];
}

/**
 * Nhân viên (không có quyền tính lương) có được xem phiếu kỳ này chưa?
 * Trả về null nếu được xem, ngược lại trả mảng lý do.
 */
function checkin_mkt192_staff_view_block($period) {
    if (checkin_mkt192_evaluate_permission_rule(['mode' => 'login', 'scope' => 'salary.calculate']) === true) {
        return null;
    }
    $cfg = checkin_mkt192_salary_settings();
    if ($cfg['staff_view'] !== 'after_day' || !preg_match('/^\d{4}-\d{2}$/', $period)) {
        return null;
    }
    $next_month   = date('Y-m', strtotime($period . '-01 +1 month'));
    $visible_from = $next_month . '-' . str_pad((string)$cfg['staff_view_day'], 2, '0', STR_PAD_LEFT);
    if (current_time('Y-m-d') >= $visible_from) {
        return null;
    }
    return [
        'hidden'       => true,
        'visible_from' => $visible_from,
        'message'      => 'Phiếu lương kỳ này sẽ hiển thị từ ngày ' . date('d/m/Y', strtotime($visible_from)) . '.',
    ];
}

/* =====================================================================
   4 HẠNG BARBER (cấp bậc thợ là danh hiệu; hoa hồng theo thẻ từng kỳ)
   ===================================================================== */

function checkin_mkt192_barber_tiers() {
    return [
        ['name' => 'Barber Thử Việc',      'order' => 1, 'service' => 0,  'chemical' => 0],
        ['name' => 'Barber Chính Thức',    'order' => 2, 'service' => 30, 'chemical' => 10],
        ['name' => 'Barber Chuyên Nghiệp', 'order' => 3, 'service' => 40, 'chemical' => 15],
        ['name' => 'Barber Master',        'order' => 4, 'service' => 45, 'chemical' => 20],
    ];
}

/**
 * Đọc % dịch vụ / hoá chất từ mã trong tên bậc cũ khi bảng cài đặt không có dòng tương ứng:
 * "Cao cấp 3 (C45_20)" → 45/20 · "Cao cấp 2.5 (45-15)" → 45/15 · "Pro Worker (P0_40)" → 40/0 (thợ phụ).
 */
function checkin_mkt192_parse_level_percents($level_name) {
    if (preg_match('/\(\s*C(\d+(?:\.\d+)?)_(\d+(?:\.\d+)?)\s*\)/u', $level_name, $m)) {
        return ['service' => floatval($m[1]), 'chemical' => floatval($m[2])];
    }
    if (preg_match('/\(\s*P\d+_(\d+(?:\.\d+)?)\s*\)/u', $level_name, $m)) {
        return ['service' => floatval($m[1]), 'chemical' => 0];
    }
    if (preg_match('/\(\s*(\d+(?:\.\d+)?)\s*[-_\/]\s*(\d+(?:\.\d+)?)\s*\)/u', $level_name, $m)) {
        return ['service' => floatval($m[1]), 'chemical' => floatval($m[2])];
    }
    return null;
}

/** Tên hạng theo % dịch vụ cũ: 0 → Thử Việc · < 40 → Chính Thức · ≥ 40 → Chuyên Nghiệp (Kent chốt 10/09/2026). */
function checkin_mkt192_tier_for_service_percent($pct) {
    $pct = floatval($pct);
    if ($pct <= 0)  return 'Barber Thử Việc';
    if ($pct < 40)  return 'Barber Chính Thức';
    return 'Barber Chuyên Nghiệp';
}

/**
 * Migration một lần: gom bậc thợ về 4 hạng Barber.
 *  1. Mỗi thợ đang hoạt động chưa có thẻ hoa hồng kỳ hiện tại → tạo thẻ (source=migrated) từ % bậc cũ ⇒ lương không đổi.
 *  2. staff_level_history: giữ tên cũ ở legacy_level_name, đổi level_name theo % (Vũ Phương → Master ở bậc đang active).
 *  3. salary_level_settings: bỏ các bậc thợ cũ, thêm 4 hạng (role 'Thợ Chính').
 */
function checkin_mkt192_migrate_barber_tiers() {
    global $wpdb;
    if (get_option('checkin_mkt192_barber_tiers_migrated')) {
        return false;
    }
    $p        = $wpdb->prefix;
    $settings = $wpdb->get_results("SELECT id, level_name, service_salary, chemical_salary, role FROM {$p}checkin_mkt192_salary_level_settings WHERE role LIKE '%Thợ%'");
    $old_pct  = [];
    foreach ($settings ?: [] as $row) {
        $old_pct[$row->level_name] = ['service' => floatval($row->service_salary), 'chemical' => floatval($row->chemical_salary)];
    }
    $masters = apply_filters('checkin_mkt192_barber_master_staff', ['Vũ Phương']);
    $period  = current_time('Y-m');
    $audit   = ['cards' => [], 'history' => [], 'skipped' => [], 'at' => current_time('mysql')];
    $cashier_levels = $wpdb->get_col("SELECT level_name FROM {$p}checkin_mkt192_salary_level_settings WHERE role NOT LIKE '%Thợ%'");
    // % của một bậc thợ cũ: bảng cài đặt → mã trong tên → null (không phải bậc thợ)
    $pct_of = function ($level_name) use (&$old_pct, $cashier_levels) {
        if (isset($old_pct[$level_name])) return $old_pct[$level_name];
        if (in_array($level_name, $cashier_levels, true)) return null;
        $parsed = checkin_mkt192_parse_level_percents($level_name);
        if ($parsed) $old_pct[$level_name] = $parsed;
        return $parsed;
    };

    // 1. Thẻ hoa hồng giữ % cho từng thợ
    $staffs = $wpdb->get_col("SELECT display_name FROM {$p}checkin_mkt192_staff WHERE user_role LIKE '%Thợ%' AND status != 'DELETED'");
    foreach ($staffs ?: [] as $name) {
        if (checkin_mkt192_resolve_period_rates($name, $period, true)) {
            continue; // đã có thẻ (kể cả kế thừa) → không đụng
        }
        $level = $wpdb->get_row($wpdb->prepare(
            "SELECT level_name FROM {$p}checkin_mkt192_staff_level_history WHERE staff_name = %s ORDER BY is_active DESC, start_time DESC LIMIT 1", $name
        ));
        $pct = $level ? $pct_of($level->level_name) : null;
        if (!$pct) {
            $audit['skipped'][] = [$name, $level ? $level->level_name : '(không có bậc)'];
            continue;
        }
        $cd  = checkin_mkt192_salary_settings()['card_defaults'];
        $wpdb->insert(checkin_mkt192_period_rates_table(), [
            'staff_name'          => $name,
            'period'              => $period,
            'service_percent'     => $pct['service'],
            'chemical_percent'    => $pct['chemical'],
            'product_percent'     => $cd['product_percent'],
            'product_min_qty'     => $cd['product_min_qty'],
            'overtime_percent'    => $cd['overtime_percent'],
            'kpi_penalty_percent' => $cd['kpi_penalty_percent'],
            'kpi_penalty_scope'   => $cd['kpi_penalty_scope'],
            'kpi_penalty_mode'    => $cd['kpi_penalty_mode'],
            'kpi_required'        => implode(',', $cd['kpi_required']),
            'note'                => 'Chuyển từ bậc ' . $level->level_name . ' khi gom về 4 hạng Barber',
            'source'              => 'migrated',
        ]);
        $audit['cards'][] = [$name, $level->level_name, $pct['service'], $pct['chemical']];
    }

    // 2. Lịch sử cấp bậc → tên hạng, giữ tên cũ
    $rows = $wpdb->get_results("SELECT id, staff_name, level_name, is_active, start_time FROM {$p}checkin_mkt192_staff_level_history ORDER BY staff_name, start_time, id");
    $latest_by_staff = [];
    $tier_names = array_column(checkin_mkt192_barber_tiers(), 'name');
    foreach ($rows ?: [] as $r) {
        if (in_array($r->level_name, $tier_names, true) || !$pct_of($r->level_name)) continue; // đã là hạng / bậc thu ngân
        $latest_by_staff[$r->staff_name] = (int)$r->id; // dòng cuối theo start_time
    }
    foreach ($rows ?: [] as $r) {
        if (in_array($r->level_name, $tier_names, true)) continue;
        $pct = $pct_of($r->level_name);
        if (!$pct) continue;
        $tier = checkin_mkt192_tier_for_service_percent($pct['service']);
        if (in_array($r->staff_name, $masters, true) && ((int)$r->is_active === 1 || $latest_by_staff[$r->staff_name] === (int)$r->id)) {
            $tier = 'Barber Master';
        }
        $wpdb->update("{$p}checkin_mkt192_staff_level_history", ['legacy_level_name' => $r->level_name, 'level_name' => $tier], ['id' => (int)$r->id]);
        $audit['history'][] = [$r->staff_name, $r->level_name, $tier, $r->start_time];
    }

    // 3. Bảng bậc: thay bậc thợ cũ bằng 4 hạng
    $wpdb->query("DELETE FROM {$p}checkin_mkt192_salary_level_settings WHERE role LIKE '%Thợ%'");
    foreach (checkin_mkt192_barber_tiers() as $t) {
        $wpdb->insert("{$p}checkin_mkt192_salary_level_settings", [
            'level_name' => $t['name'], 'base_salary' => 0, 'service_salary' => $t['service'], 'chemical_salary' => $t['chemical'],
            'hourly_salary' => 0, 'video_salary' => 0, 'role' => 'Thợ Chính',
        ]);
    }

    update_option('checkin_mkt192_barber_tiers_migrated', current_time('mysql'), true);
    update_option('checkin_mkt192_barber_tiers_migration_log', $audit, false);
    error_log('Checkin MKT192: migrated barber tiers — ' . count($audit['cards']) . ' cards, ' . count($audit['history']) . ' history rows');
    return true;
}

/** GET /salary-diagnostics — trạng thái db/migration để soi từ xa (admin). */
function checkin_mkt192_salary_diagnostics_api(WP_REST_Request $request) {
    global $wpdb;
    $p = $wpdb->prefix;
    $col = function ($table, $column) use ($wpdb, $p) { return !empty($wpdb->get_results("SHOW COLUMNS FROM {$p}checkin_mkt192_{$table} LIKE '{$column}'")); };
    $tbl = function ($table) use ($wpdb, $p) { return $wpdb->get_var("SHOW TABLES LIKE '{$p}checkin_mkt192_{$table}'") === "{$p}checkin_mkt192_{$table}"; };
    return ['success' => true, 'data' => [
        'plugin_version'     => defined('CHECKIN_MKT192_VERSION') ? CHECKIN_MKT192_VERSION : null,
        'db_version'         => get_option('checkin_mkt192_db_version'),
        'tiers_migrated_at'  => get_option('checkin_mkt192_barber_tiers_migrated'),
        'tiers_migration_log'=> get_option('checkin_mkt192_barber_tiers_migration_log'),
        'tables'             => ['salary_period_rates' => $tbl('salary_period_rates'), 'salary_adjustments' => $tbl('salary_adjustments')],
        'columns'            => ['hairdresser_salary.rates_json' => $col('hairdresser_salary', 'rates_json'), 'hairdresser_salary.adjustments_json' => $col('hairdresser_salary', 'adjustments_json'), 'staff_level_history.legacy_level_name' => $col('staff_level_history', 'legacy_level_name'), 'salary_period_rates.kpi_penalty_mode' => $tbl('salary_period_rates') ? $col('salary_period_rates', 'kpi_penalty_mode') : false],
        'thợ_levels'         => $wpdb->get_results("SELECT level_name, service_salary, chemical_salary FROM {$p}checkin_mkt192_salary_level_settings WHERE role LIKE '%Thợ%' ORDER BY id"),
        'cards'              => (int)$wpdb->get_var("SELECT COUNT(*) FROM {$p}checkin_mkt192_salary_period_rates"),
        'function_exists'    => function_exists('checkin_mkt192_migrate_barber_tiers'),
    ]];
}

/** POST /salary-tiers-migrate — chạy migration 4 hạng (idempotent) rồi trả chẩn đoán. force=1 để chạy lại khi cờ đã bật. */
function checkin_mkt192_salary_tiers_migrate_api(WP_REST_Request $request) {
    if (filter_var($request->get_param('force'), FILTER_VALIDATE_BOOLEAN)) {
        delete_option('checkin_mkt192_barber_tiers_migrated');
    }
    $ran = checkin_mkt192_migrate_barber_tiers();
    $diag = checkin_mkt192_salary_diagnostics_api($request);
    $diag['ran'] = $ran;
    return $diag;
}

/**
 * KPI chỉ ÁP VÀO LƯƠNG khi kỳ đã hết (period < tháng hiện tại). Kỳ đang chạy = phiếu tạm tính: vẫn đánh giá để hiện
 * thanh tiến trình cho thợ theo dõi, nhưng không trừ % KPI, không cắt thưởng sản phẩm — Kent chốt 10/09/2026.
 */
function checkin_mkt192_kpi_applies($period) {
    return preg_match('/^\d{4}-\d{2}$/', (string)$period) && $period < current_time('Y-m');
}

/** Mã hoá đơn trong kỳ có dòng dịch vụ/sản phẩm của thợ (distinct). */
function checkin_mkt192_staff_period_invoice_ids($staff_name, $start, $end) {
    global $wpdb;
    $ids = $wpdb->get_col($wpdb->prepare(
        "SELECT DISTINCT invoice_id FROM {$wpdb->prefix}checkin_mkt192_invoices_data_detail WHERE staff_name = %s AND created_at BETWEEN %s AND %s AND invoice_id <> ''",
        $staff_name, $start, $end
    ));
    return array_values(array_filter(array_map('strval', $ids ?: [])));
}

/**
 * KPI Google Maps = số hoá đơn trong kỳ của thợ có ảnh đánh giá (cột invoices_data.image_feedback) — Kent chốt 10/09/2026.
 * Làm 2 bước (lấy mã HĐ của thợ rồi đếm trên invoices_data) thay cho JOIN: hai bảng trên VG tạo ở thời điểm khác nhau,
 * JOIN theo invoice_id có thể lỗi lệch collation → get_var trả null → đếm ra 0 dù có ảnh (Hoàng Huy 08/2026: 30 HĐ → 0).
 */
function checkin_mkt192_count_feedback_invoices($staff_name, $start, $end) {
    global $wpdb;
    $ids = checkin_mkt192_staff_period_invoice_ids($staff_name, $start, $end);
    if (!$ids) return 0;
    $count = 0;
    foreach (array_chunk($ids, 500) as $chunk) {
        $ph = implode(',', array_fill(0, count($chunk), '%s'));
        $count += (int)$wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}checkin_mkt192_invoices_data
             WHERE invoice_id IN ($ph) AND created_at BETWEEN %s AND %s
             AND image_feedback IS NOT NULL AND image_feedback <> '' AND image_feedback <> '[]' AND image_feedback <> 'null'",
            array_merge($chunk, [$start, $end])
        ));
    }
    return $count;
}

/** Số ngày công thực tế của thợ trong khoảng (theo check-in thành công). */
function checkin_mkt192_working_days_between($staff_name, $start, $end) {
    global $wpdb;
    return (int)$wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(DISTINCT DATE(checkin_time)) FROM {$wpdb->prefix}checkin_mkt192_checkinlogs WHERE display_name = %s AND status = 'success' AND checkin_time BETWEEN %s AND %s",
        $staff_name, $start, $end
    ));
}

/**
 * Số bài FB phải đạt theo cách tính của KPI:
 *  - workdays: `post_fb_kpi` = số bài mỗi ngày công → phải đạt = kpi × số ngày công thực tế;
 *  - count   : `post_fb_kpi` = số bài cố định trong kỳ.
 */
function checkin_mkt192_post_fb_required($mode, $kpi, $working_days) {
    $kpi = (float)$kpi;
    if ($kpi <= 0) return 0;
    if ($mode === 'workdays') return (int)ceil($kpi * max(0, (int)$working_days));
    return (int)ceil($kpi);
}

/**
 * Số thực tế các KPI của (thợ, kỳ) tính trực tiếp từ dữ liệu — dùng khi kpi_results chưa lưu (bản cũ) và khi đánh giá.
 * feedback = số hoá đơn trong kỳ của thợ có ảnh đánh giá Google Maps (cột invoices_data.image_feedback).
 */
function checkin_mkt192_kpi_actuals($staff_name, $period) {
    global $wpdb;
    $p = $wpdb->prefix;
    if (!preg_match('/^\d{4}-\d{2}$/', $period)) return null;
    $start = $period . '-01 00:00:00';
    $end   = date('Y-m-t 23:59:59', strtotime($start));
    $service = $wpdb->get_var($wpdb->prepare("SELECT service_total FROM {$p}checkin_mkt192_hairdresser_salary WHERE staff_name = %s AND period = %s", $staff_name, $period));
    if ($service === null) {
        $service = $wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(total),0) FROM {$p}checkin_mkt192_invoices_data_detail WHERE staff_name = %s AND service_type = 'service' AND created_at BETWEEN %s AND %s", $staff_name, $start, $end));
    }
    $product_qty   = (int)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(GREATEST(quantity,1)),0) FROM {$p}checkin_mkt192_invoices_data_detail WHERE staff_name = %s AND type = 'product' AND created_at BETWEEN %s AND %s", $staff_name, $start, $end));
    $product_total = (float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(total),0) FROM {$p}checkin_mkt192_invoices_data_detail WHERE staff_name = %s AND type = 'product' AND created_at BETWEEN %s AND %s", $staff_name, $start, $end));
    $posts = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$p}checkin_mkt192_social_posts WHERE staff_name = %s AND post_type = 'facebook' AND post_date BETWEEN %s AND %s", $staff_name, $start, $end));
    $feedback = checkin_mkt192_count_feedback_invoices($staff_name, $start, $end);
    $days     = checkin_mkt192_working_days_between($staff_name, $start, $end);
    return ['service' => (float)$service, 'product_qty' => $product_qty, 'product_total' => $product_total, 'post_fb' => $posts, 'feedback' => $feedback, 'working_days' => $days];
}

/** Đọc kết quả KPI của (thợ, kỳ) dạng chuẩn cho UI (thanh tiến trình). */
function checkin_mkt192_kpi_result_view($staff_name, $period) {
    global $wpdb;
    $r = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}checkin_mkt192_kpi_results WHERE staff_name = %s AND period = %s LIMIT 1", $staff_name, $period));
    if (!$r) return null;
    $manual = !empty($r->manual_json) ? json_decode($r->manual_json, true) : [];
    $manual = is_array($manual) ? $manual : [];
    // Kết quả đánh giá ở bản cũ chưa lưu số thực tế → tính tại chỗ để thanh tiến trình không rỗng
    if ($r->service_actual === null || $r->product_actual === null || $r->post_fb_actual === null || $r->feedback_actual === null) {
        $act = checkin_mkt192_kpi_actuals($staff_name, $period);
        if ($act) {
            if ($r->service_actual === null)  $r->service_actual  = $act['service'];
            if ($r->product_actual === null)  $r->product_actual  = $r->product_kpi_type === 'san_pham' ? $act['product_qty'] : $act['product_total'];
            if ($r->post_fb_actual === null)  $r->post_fb_actual  = $act['post_fb'];
            if ($r->feedback_actual === null) $r->feedback_actual = $act['feedback'];
            if ($r->working_days === null)    $r->working_days    = $act['working_days'];
            if ($r->post_fb_required === null && (float)$r->post_fb_kpi > 0) {
                // Bản cũ (trước 5.3.6.2): KPI/tháng quy theo ngày công/30
                $r->post_fb_required = $act['working_days'] > 0 ? (int)ceil((float)$r->post_fb_kpi * $act['working_days'] / 30) : (int)$r->post_fb_kpi;
            }
        }
    }
    // Cách tính KPI đăng bài: workdays (N bài/ngày công) · count (số bài cố định) · legacy (bản cũ: KPI/tháng quy theo ngày công)
    $post_mode = $r->post_fb_mode ?: ((float)$r->post_fb_kpi > 0 && $r->post_fb_required !== null && (int)$r->post_fb_required !== (int)$r->post_fb_kpi ? 'legacy' : 'count');
    if ($r->working_days === null && (float)$r->post_fb_kpi > 0 && preg_match('/^\d{4}-\d{2}$/', $period)) {
        // Bản ghi cũ chưa lưu số ngày công → đếm tại chỗ để ghi chú "N ngày công" không rỗng
        $r->working_days = checkin_mkt192_working_days_between($staff_name, $period . '-01 00:00:00', date('Y-m-t 23:59:59', strtotime($period . '-01')));
    }
    $item = function ($key, $label, $target, $actual, $achieved, $bonus, $penalty, $unit, $required = null) use ($manual) {
        $target = floatval($target); $actual = $actual === null ? null : floatval($actual);
        $pct = $target > 0 && $actual !== null ? min(100, round($actual / ($required ?? $target) * 100)) : ($target > 0 ? 0 : 100);
        return ['key' => $key, 'label' => $label, 'target' => $target, 'required' => $required !== null ? floatval($required) : null, 'actual' => $actual, 'percent' => $pct,
                'achieved' => (int)$achieved === 1, 'bonus' => (int)$bonus, 'penalty' => (int)$penalty, 'unit' => $unit,
                'manual' => array_key_exists($key, $manual) && $manual[$key] !== null && $manual[$key] !== '' ? (int)$manual[$key] : null, 'no_target' => $target <= 0];
    };
    return [
        'staff_name'   => $staff_name,
        'period'       => $period,
        'is_evaluated' => (int)$r->is_evaluated === 1,
        'updated_at'   => $r->updated_at,
        'manual_note'  => $manual['note'] ?? '',
        'items'        => [
            $item('service',  'Doanh số dịch vụ',   $r->service_kpi,  $r->service_actual,  $r->service_achieved,  $r->service_bonus,  $r->service_penalty, 'đ'),
            $item('product',  $r->product_kpi_type === 'san_pham' ? 'Bán sản phẩm (số lượng)' : 'Doanh thu sản phẩm', $r->product_kpi, $r->product_actual, $r->product_achieved, 0, 0, $r->product_kpi_type === 'san_pham' ? 'SP' : 'đ'),
            array_merge($item('post_fb',  'Content Fb',  $r->post_fb_kpi,  $r->post_fb_actual,  $r->post_fb_achieved,  $r->post_fb_bonus,  0, 'bài', $r->post_fb_required),
                        ['mode' => $post_mode, 'working_days' => $r->working_days === null ? null : (int)$r->working_days]),
            $item('feedback', 'Đánh giá Google Maps', $r->feedback_kpi, $r->feedback_actual, $r->feedback_achieved, $r->feedback_bonus, 0, 'lượt'),
        ],
        'product_bonus_percent' => (int)$r->product_bonus,
    ];
}

/** GET /kpi-result?staff_name&period — nhân viên xem của mình, admin xem tất cả. */
function checkin_mkt192_kpi_result_api(WP_REST_Request $request) {
    $period = sanitize_text_field($request->get_param('period'));
    $name   = sanitize_text_field($request->get_param('staff_name'));
    if ($name === '' || $name === 'me') $name = (string)checkin_mkt192_current_staff_display_name();
    if (!preg_match('/^\d{4}-\d{2}$/', $period) || $name === '') {
        return new WP_Error('invalid_params', 'Tham số không hợp lệ', ['status' => 400]);
    }
    if ($name !== checkin_mkt192_current_staff_display_name()
        && checkin_mkt192_evaluate_permission_rule(['mode' => 'login', 'scope' => 'salary.calculate']) !== true) {
        return new WP_Error('rest_forbidden', 'Bạn chỉ xem được KPI của mình.', ['status' => 403]);
    }
    $out = ['success' => true, 'data' => checkin_mkt192_kpi_result_view($name, $period)];
    if (filter_var($request->get_param('live'), FILTER_VALIDATE_BOOLEAN)
        && checkin_mkt192_evaluate_permission_rule(['mode' => 'login', 'scope' => 'salary.calculate']) === true) {
        $out['live'] = checkin_mkt192_kpi_actuals($name, $period); // số tính trực tiếp từ dữ liệu, chưa lưu
    }
    return $out;
}

/** POST /kpi-result/manual — admin ghi đè Đạt/Không đạt từng KPI (null = tự động), rồi đánh giá lại + tính lương. */
function checkin_mkt192_kpi_manual_api(WP_REST_Request $request) {
    global $wpdb;
    $period = sanitize_text_field($request->get_param('period'));
    $name   = sanitize_text_field($request->get_param('staff_name'));
    if (!preg_match('/^\d{4}-\d{2}$/', $period) || $name === '') {
        return new WP_Error('invalid_params', 'Tham số không hợp lệ', ['status' => 400]);
    }
    if (checkin_mkt192_salary_locked_for('Thợ', $name, $period)) {
        return new WP_Error('salary_locked', 'Phiếu lương kỳ này đã chốt, không sửa KPI được.', ['status' => 409]);
    }
    $body   = $request->get_json_params() ?: $request->get_params();
    $manual = [];
    foreach (['service', 'product', 'post_fb', 'feedback'] as $k) {
        $v = $body['overrides'][$k] ?? ($body[$k] ?? null);
        $manual[$k] = ($v === null || $v === '' || $v === 'auto') ? null : ((int)$v === 1 ? 1 : 0);
    }
    $manual['note'] = mb_substr(sanitize_text_field((string)($body['note'] ?? '')), 0, 255);
    $manual['by']   = get_current_user_id();
    $manual['at']   = current_time('mysql');
    $table = $wpdb->prefix . 'checkin_mkt192_kpi_results';
    $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$table} WHERE staff_name = %s AND period = %s", $name, $period));
    $json = wp_json_encode($manual, JSON_UNESCAPED_UNICODE);
    if ($exists) {
        $wpdb->update($table, ['manual_json' => $json], ['id' => (int)$exists]);
    } else {
        $wpdb->insert($table, ['staff_name' => $name, 'period' => $period, 'manual_json' => $json, 'updated_at' => current_time('mysql'), 'is_evaluated' => 0]);
    }
    $eval = checkin_mkt192_evaluate_kpi_and_update_salary($period, $name);
    checkin_mkt192_recompute_salary_for('Thợ', $name, $period);
    return ['success' => true, 'message' => 'Đã lưu ghi đè KPI, đánh giá lại và tính lại lương.', 'data' => checkin_mkt192_kpi_result_view($name, $period), 'evaluate' => $eval];
}

/* =====================================================================
   HỒ SƠ THỢ: thông tin công việc + lịch sử cấp bậc / hoa hồng / phiếu lương
   ===================================================================== */

/** GET /staff-profile?staff_name= */
function checkin_mkt192_staff_profile_api(WP_REST_Request $request) {
    global $wpdb;
    $p    = $wpdb->prefix;
    $name = sanitize_text_field($request->get_param('staff_name'));
    if ($name === '' || $name === 'me') {
        $name = (string)checkin_mkt192_current_staff_display_name();
    }
    if ($name === '') {
        return new WP_Error('missing_staff', 'Thiếu staff_name', ['status' => 400]);
    }
    // Nhân viên chỉ xem được hồ sơ của chính mình; admin/quyền tính lương xem tất cả
    if ($name !== checkin_mkt192_current_staff_display_name()
        && checkin_mkt192_evaluate_permission_rule(['mode' => 'login', 'scope' => 'salary.calculate']) !== true) {
        return new WP_Error('rest_forbidden', 'Bạn chỉ xem được hồ sơ của mình.', ['status' => 403]);
    }
    $staff = $wpdb->get_row($wpdb->prepare(
        "SELECT id, employee_id, display_name, user_role, status, branch, branch_id, avatar, phone, user_email, birthday FROM {$p}checkin_mkt192_staff WHERE display_name = %s LIMIT 1", $name
    ));
    if (!$staff) {
        return new WP_Error('not_found', 'Không tìm thấy nhân viên', ['status' => 404]);
    }
    $is_hairdresser = stripos((string)$staff->user_role, 'Thợ') !== false;

    // Lịch sử cấp bậc (mới → cũ), gộp các dòng liên tiếp cùng hạng
    $levels = $wpdb->get_results($wpdb->prepare(
        "SELECT id, level_name, legacy_level_name, start_time, end_time, is_active, `condition` FROM {$p}checkin_mkt192_staff_level_history WHERE staff_name = %s ORDER BY start_time ASC, id ASC", $name
    ));
    $level_history = [];
    foreach ($levels ?: [] as $l) {
        $last = $level_history ? $level_history[count($level_history) - 1] : null;
        if ($last && $last['level_name'] === $l->level_name) {
            $i = count($level_history) - 1;
            $row_active = (int)$l->is_active === 1;
            $level_history[$i]['is_active'] = $last['is_active'] || $row_active;
            $level_history[$i]['end_time']  = $l->end_time;
            // Tên bậc cũ: ưu tiên dòng đang active (lương thực tế tính theo dòng này), không thì lấy dòng mới nhất
            if (!empty($l->legacy_level_name) && ($row_active || empty($level_history[$i]['legacy_from_active']))) {
                $level_history[$i]['legacy_level_name']  = $l->legacy_level_name;
                $level_history[$i]['legacy_from_active'] = $row_active;
            }
            continue;
        }
        $level_history[] = [
            'id' => (int)$l->id, 'level_name' => $l->level_name, 'legacy_level_name' => $l->legacy_level_name,
            'legacy_from_active' => (int)$l->is_active === 1,
            'start_time' => $l->start_time, 'end_time' => $l->end_time, 'is_active' => (int)$l->is_active === 1, 'condition' => $l->condition,
        ];
    }
    $level_history = array_reverse($level_history);
    $current_level = null;
    foreach ($level_history as $lh) { if ($lh['is_active']) { $current_level = $lh; break; } }
    if (!$current_level && $level_history) { $current_level = $level_history[0]; }

    // Lịch sử hoa hồng: từ thẻ theo kỳ (chỉ ghi khi đổi so với kỳ trước)
    $commission_history = [];
    if ($is_hairdresser) {
        $cards = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM " . checkin_mkt192_period_rates_table() . " WHERE staff_name = %s ORDER BY period ASC", $name
        ));
        $prev = null;
        $fmt  = function ($v) { return rtrim(rtrim(number_format((float)$v, 2, '.', ''), '0'), '.'); };
        foreach ($cards ?: [] as $c) {
            $n   = checkin_mkt192_normalize_period_rates($c);
            $sig = [$n['service_percent'], $n['chemical_percent'], $n['product_percent'], $n['product_min_qty'], $n['overtime_percent'], $n['kpi_penalty_percent'], $n['kpi_penalty_scope'], $n['kpi_penalty_mode'], implode(',', $n['kpi_required'])];
            if ($prev !== null && $sig === $prev['sig']) { $prev = ['sig' => $sig, 'n' => $n]; continue; }
            $changes = [];
            if ($prev) {
                $pn = $prev['n'];
                foreach ([['service_percent', 'Dịch vụ'], ['chemical_percent', 'Hoá chất'], ['product_percent', 'Sản phẩm'], ['overtime_percent', 'Tăng ca'], ['kpi_penalty_percent', 'Trừ KPI']] as $pair) {
                    [$k, $label] = $pair;
                    if ($pn[$k] != $n[$k]) $changes[] = sprintf('%s %s%% → %s%%', $label, $fmt($pn[$k]), $fmt($n[$k]));
                }
                if ($pn['product_min_qty'] != $n['product_min_qty']) $changes[] = sprintf('Ngưỡng SP %d → %d', $pn['product_min_qty'], $n['product_min_qty']);
                if ($pn['kpi_penalty_scope'] !== $n['kpi_penalty_scope'] || $pn['kpi_penalty_mode'] !== $n['kpi_penalty_mode'] || $pn['kpi_required'] !== $n['kpi_required']) $changes[] = 'Đổi luật KPI';
            }
            $editor = !empty($c->updated_by) ? get_userdata((int)$c->updated_by) : null;
            $commission_history[] = [
                'period'     => $c->period,
                'source'     => $n['source'],
                'rates'      => $n,
                'changes'    => $changes,
                'note'       => $n['note'],
                'updated_by' => $editor ? $editor->display_name : ($n['source'] === 'manual' ? 'Admin' : 'Hệ thống'),
                'updated_at' => $c->updated_at,
            ];
            $prev = ['sig' => $sig, 'n' => $n];
        }
        $commission_history = array_reverse($commission_history);
    }

    // Lịch sử phiếu lương (12 kỳ gần nhất)
    $table = $is_hairdresser ? 'checkin_mkt192_hairdresser_salary' : 'checkin_mkt192_cashier_salary';
    $rows  = $wpdb->get_results($wpdb->prepare(
        "SELECT period, level_name, total_salary, total_of_deductions, actual_salary, xac_nhan_luong, payment, xac_nhan_thanh_toan, status FROM {$p}{$table} WHERE staff_name = %s ORDER BY period DESC LIMIT 12", $name
    ));
    $salary_history = [];
    foreach ($rows ?: [] as $r) {
        $salary_history[] = [
            'period' => $r->period, 'level_name' => $r->level_name, 'total_salary' => (int)$r->total_salary,
            'total_of_deductions' => (int)$r->total_of_deductions, 'actual_salary' => (int)$r->actual_salary,
            'xac_nhan_luong' => $r->xac_nhan_luong, 'payment' => $r->payment ? true : false, 'xac_nhan_thanh_toan' => $r->xac_nhan_thanh_toan, 'status' => $r->status,
            'locked' => checkin_mkt192_salary_row_is_locked($r),
        ];
    }

    $period        = current_time('Y-m');
    $current_rates = $is_hairdresser ? checkin_mkt192_resolve_period_rates($name, $period, false) : null;
    $first_level   = $levels ? $levels[0] : null;

    return ['success' => true, 'data' => [
        'staff' => [
            'id' => (int)$staff->id, 'employee_id' => $staff->employee_id, 'display_name' => $staff->display_name, 'user_role' => $staff->user_role,
            'status' => $staff->status, 'branch' => $staff->branch, 'branch_id' => $staff->branch_id, 'avatar' => $staff->avatar, 'phone' => $staff->phone,
            'joined_at' => $first_level ? $first_level->start_time : null,
        ],
        'is_hairdresser'     => $is_hairdresser,
        'current_level'      => $current_level,
        'current_rates'      => $current_rates,
        'level_history'      => $level_history,
        'commission_history' => $commission_history,
        'salary_history'     => $salary_history,
        'attendance'         => checkin_mkt192_attendance_stats($name, $period),
        'tiers'              => checkin_mkt192_barber_tiers(),
    ]];
}

/* =====================================================================
   PHIẾU THƯỞNG / PHIẾU TRỪ (salary_adjustments) + TRUY THU ĐÁNH GIÁ THẤP
   ===================================================================== */

function checkin_mkt192_adjustments_table() {
    global $wpdb;
    return $wpdb->prefix . 'checkin_mkt192_salary_adjustments';
}

/** Cài đặt truy thu khi khách đánh giá thấp (toàn salon, WP option). */
function checkin_mkt192_review_penalty_settings() {
    return checkin_mkt192_salary_settings(true)['review_penalty'];
}

/** Lý do not_image của một hoá đơn → mảng chuỗi. */
function checkin_mkt192_invoice_not_image_reasons($raw) {
    if (empty($raw)) return [];
    if (is_array($raw)) return array_map('strval', $raw);
    $decoded = json_decode($raw, true);
    if (is_array($decoded)) return array_map('strval', $decoded);
    return array_values(array_filter(array_map('trim', explode(',', (string)$raw))));
}

/** Hoá đơn có ảnh chưa? (`images` là JSON mảng URL) */
function checkin_mkt192_invoice_has_images($raw) {
    if (empty($raw) || $raw === '[]' || $raw === 'null') return false;
    $decoded = json_decode($raw, true);
    if (is_array($decoded)) return count(array_filter($decoded)) > 0;
    return trim((string)$raw) !== '';
}

/**
 * Truy thu TỰ ĐỘNG theo cài đặt lương cho (thợ, kỳ). Chạy mỗi lần tính lương, idempotent:
 *  1. Gỡ dấu vết cũ do chính hệ thống tạo (marker kind='marker' → bỏ is_penalty; xoá phiếu trừ source review/no_image).
 *  2. Gom hoá đơn vi phạm: đánh giá ≤ N★ (online + offline theo ngày đánh giá trong kỳ) · hoá đơn không ảnh
 *     (bỏ khách vãng lai, bỏ lý do hợp lệ).
 *  3. Áp theo mode: percent → phiếu trừ = % giá trị phần của thợ trên hoá đơn; fixed → phiếu trừ số tiền cố định.
 *  (Kiểu 'commission' — đánh dấu is_penalty như truy thu tay — đã bỏ ở 5.3.6.2; bước 1 vẫn gỡ marker cũ nếu còn.)
 */
function checkin_mkt192_sync_auto_penalties($staff_name, $period) {
    global $wpdb;
    $p     = $wpdb->prefix;
    $table = checkin_mkt192_adjustments_table();
    if (!preg_match('/^\d{4}-\d{2}$/', $period) || $staff_name === '') {
        return ['review' => 0, 'no_image' => 0];
    }
    $start = $period . '-01 00:00:00';
    $end   = date('Y-m-t 23:59:59', strtotime($start));

    // 1. Hoàn tác dấu vết cũ
    $markers = $wpdb->get_results($wpdb->prepare(
        "SELECT id, ref_id FROM {$table} WHERE staff_name = %s AND period = %s AND kind = 'marker' AND source IN ('review','no_image')",
        $staff_name, $period
    ));
    foreach ($markers ?: [] as $m) {
        if ($m->ref_id !== '') {
            $wpdb->update("{$p}checkin_mkt192_invoices_data_detail", ['is_penalty' => 0], ['invoice_id' => $m->ref_id, 'staff_name' => $staff_name, 'is_penalty' => 1]);
        }
    }
    // Marker category='ignored' = admin đã bấm "Bỏ qua" truy thu HĐ đó → giữ lại, không tạo lại phiếu trừ cho HĐ ấy
    $ignored = array_flip(array_filter(array_map('strval', $wpdb->get_col($wpdb->prepare(
        "SELECT ref_id FROM {$table} WHERE staff_name = %s AND period = %s AND kind = 'marker' AND category = 'ignored'", $staff_name, $period
    )) ?: [])));
    $wpdb->query($wpdb->prepare("DELETE FROM {$table} WHERE staff_name = %s AND period = %s AND source IN ('review','no_image') AND category <> 'ignored'", $staff_name, $period)); // gồm deduction + base_penalty

    $cfg      = checkin_mkt192_salary_settings();
    $rp       = $cfg['review_penalty'];
    $ni       = $cfg['no_image_penalty'];
    $flagged  = []; // invoice_id => ['source'=>..., 'label'=>...]

    // 2a. Đánh giá thấp — tính theo KỲ CỦA HOÁ ĐƠN (không theo ngày đánh giá):
    //   • hoá đơn thuộc kỳ này → truy thu ngay tại kỳ này;
    //   • hoá đơn thuộc kỳ trước ĐÃ TRẢ LƯƠNG (khách đánh giá muộn) → không sửa kỳ cũ, tạo khoản "truy thu bù" ở kỳ này
    //     theo mức đang cài (% giá trị hoá đơn / cố định), chỉ khi chưa bù ở kỳ nào khác.
    $late = []; // invoice_id => info truy thu bù
    if ($rp['enabled']) {
        $t   = $rp['threshold'];
        // Không JOIN invoices_data (trên VG JOIN theo invoice_id trả rỗng — lệch collation); lấy ngày hoá đơn bằng IN (...)
        $sql = "SELECT invoice_id, service_rating, staff_rating, created_at AS review_at FROM {$p}checkin_mkt192_customer_reviews_online WHERE staff_name = %s AND (service_rating <= %d OR staff_rating <= %d)
                UNION ALL
                SELECT invoice_id, service_rating, staff_rating, created_at AS review_at FROM {$p}checkin_mkt192_customer_reviews_off WHERE staff_name = %s AND (service_rating <= %d OR staff_rating <= %d)";
        $reviews = $wpdb->get_results($wpdb->prepare($sql, $staff_name, $t, $t, $staff_name, $t, $t)) ?: [];
        $inv_dates = [];
        $rv_ids = array_values(array_unique(array_filter(array_map(function ($r) { return (string)$r->invoice_id; }, $reviews))));
        foreach (array_chunk($rv_ids, 500) as $chunk) {
            $ph = implode(',', array_fill(0, count($chunk), '%s'));
            foreach ($wpdb->get_results($wpdb->prepare("SELECT invoice_id, created_at FROM {$p}checkin_mkt192_invoices_data WHERE invoice_id IN ($ph)", $chunk)) ?: [] as $ir) {
                $inv_dates[(string)$ir->invoice_id] = (string)$ir->created_at;
            }
        }
        foreach ($reviews as $rv) {
            $inv = (string)$rv->invoice_id;
            if ($inv === '' || isset($flagged[$inv]) || isset($late[$inv]) || isset($ignored[$inv])) continue;
            $invoice_at = $inv_dates[$inv] ?? '';
            if (($invoice_at ?: (string)$rv->review_at) > $end) continue; // hoá đơn sau kỳ này
            $rv->invoice_at = $invoice_at;
            $rating     = min((int)$rv->service_rating, (int)$rv->staff_rating);
            $inv_period = substr((string)($rv->invoice_at ?: $rv->review_at), 0, 7);
            $info = ['source' => 'review', 'mode' => $rp['mode'], 'value' => $rp['value'], 'label' => "đánh giá {$rating}★", 'date' => substr((string)$rv->review_at, 0, 10)];
            if ($inv_period === $period) {
                $flagged[$inv] = $info;
            } elseif ($inv_period < $period && checkin_mkt192_salary_locked_for('Thợ', $staff_name, $inv_period)) {
                // đã bù ở kỳ khác rồi thì thôi
                $done = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$table} WHERE staff_name = %s AND source = 'review' AND category = 'review_late' AND ref_id = %s AND period <> %s LIMIT 1", $staff_name, $inv, $period));
                if (!$done) { $info['inv_period'] = $inv_period; $late[$inv] = $info; }
            }
            // kỳ trước chưa trả lương → tính lại kỳ đó sẽ tự truy thu, không đụng ở đây
        }
    }

    // 2b. Hoá đơn không ảnh
    if ($ni['enabled']) {
        // 2 bước, không JOIN (JOIN invoices_data ↔ detail theo invoice_id trả rỗng trên VG — bài học KPI Google Maps 5.3.6.2)
        $rows = [];
        foreach (array_chunk(checkin_mkt192_staff_period_invoice_ids($staff_name, $start, $end), 500) as $chunk) {
            $ph   = implode(',', array_fill(0, count($chunk), '%s'));
            $part = $wpdb->get_results($wpdb->prepare(
                "SELECT invoice_id, images, not_image, customer_name, customer_phone, created_at
                 FROM {$p}checkin_mkt192_invoices_data
                 WHERE invoice_id IN ($ph) AND created_at BETWEEN %s AND %s AND (status IS NULL OR status <> 'cancelled')",
                array_merge($chunk, [$start, $end])
            ));
            if ($part) $rows = array_merge($rows, $part);
        }
        $valid = array_map('mb_strtolower', $ni['valid_reasons']);
        foreach ($rows ?: [] as $inv_row) {
            $inv = (string)$inv_row->invoice_id;
            if ($inv === '' || isset($flagged[$inv]) || isset($ignored[$inv])) continue;
            if (checkin_mkt192_invoice_has_images($inv_row->images)) continue;
            $reasons = checkin_mkt192_invoice_not_image_reasons($inv_row->not_image);
            // Ghi chú do hệ thống thêm ("Hệ thống bù: thợ đã tích nhưng bug v5.3.4.3 không lưu") = thợ ĐÃ chọn lý do → không truy thu
            if (array_filter($reasons, function ($r) { return mb_stripos($r, 'hệ thống bù') === 0; })) continue;
            // VG lưu tên khách chữ in ("KHÁCH VÃNG LAI") → so sánh không phân biệt hoa thường (5.3.6.9: từng truy thu oan 31 HĐ)
            $is_guest = mb_strtolower(trim((string)$inv_row->customer_name)) === 'khách vãng lai' || in_array('khách vãng lai', array_map('mb_strtolower', $reasons), true);
            if ($ni['skip_guest'] && $is_guest) continue;
            $has_valid = count(array_intersect(array_map('mb_strtolower', $reasons), $valid)) > 0;
            if ($has_valid) continue;
            $flagged[$inv] = ['source' => 'no_image', 'mode' => $ni['mode'], 'value' => $ni['value'], 'label' => 'không ảnh' . ($reasons ? ' (' . implode(', ', $reasons) . ')' : ''), 'date' => substr((string)$inv_row->created_at, 0, 10)];
        }
    }

    // 2c. Truy thu bù cho hoá đơn kỳ đã trả: theo mode hiện tại — % giá trị phần của thợ trên hoá đơn đó, hoặc số tiền cố định
    $counts = ['review' => 0, 'no_image' => 0, 'review_late' => 0, 'ignored' => count($ignored)];
    foreach ($late as $inv => $f) {
        // Kỳ đó đã trả lương → không sửa doanh số cũ; thu lại bằng phiếu trừ = hoa hồng đã trả trên phần dịch vụ/hoá chất × %
        $lines = $wpdb->get_results($wpdb->prepare("SELECT service_type, SUM(total) AS total FROM {$p}checkin_mkt192_invoices_data_detail WHERE invoice_id = %s AND staff_name = %s AND service_type IN ('service','chemical') GROUP BY service_type", $inv, $staff_name));
        $old = $wpdb->get_row($wpdb->prepare("SELECT service_total, penalty_service, service_salary, chemical_total, penalty_chemical, chemical_salary FROM {$p}checkin_mkt192_hairdresser_salary WHERE staff_name = %s AND period = %s", $staff_name, $f['inv_period']));
        $svc_pct  = $old && ($old->service_total - $old->penalty_service) > 0 ? $old->service_salary / ($old->service_total - $old->penalty_service) : 0;
        $chem_pct = $old && ($old->chemical_total - $old->penalty_chemical) > 0 ? $old->chemical_salary / ($old->chemical_total - $old->penalty_chemical) : 0;
        $paid_commission = 0;
        foreach ($lines ?: [] as $ln) $paid_commission += (float)$ln->total * ($ln->service_type === 'chemical' ? $chem_pct : $svc_pct);
        if ($f['mode'] === 'percent') { $amount = round($paid_commission * $f['value'] / 100); $how = "thu lại {$f['value']}% hoa hồng đã trả"; }
        else { $amount = round($f['value']); $how = 'phạt cố định'; }
        if ($amount <= 0) continue;
        $wpdb->insert($table, [
            'staff_name' => $staff_name, 'role' => 'Thợ', 'period' => $period, 'kind' => 'deduction', 'category' => 'review_late',
            'title' => mb_substr("Truy thu bù HĐ {$inv} (kỳ " . substr($f['inv_period'], 5, 2) . '/' . substr($f['inv_period'], 0, 4) . " đã trả) · {$f['label']} · {$how}", 0, 191),
            'unit_price' => $amount, 'quantity' => 1, 'amount' => $amount,
            'note' => 'Khách đánh giá ngày ' . $f['date'] . ' sau khi kỳ đó đã thanh toán', 'source' => 'review', 'ref_id' => $inv,
        ]);
        $counts['review_late']++;
    }

    // 3. Áp
    //  • percent: trừ N% doanh số DỊCH VỤ / HOÁ CHẤT của hoá đơn khỏi doanh số trước khi nhân hoa hồng (kind base_penalty,
    //    category = service|chemical). 100% = bỏ hẳn hoá đơn khỏi doanh số như admin truy thu tay; sản phẩm vẫn tính.
    //    Dòng admin đã truy thu tay (is_penalty=1) không trừ lần hai.
    //  • fixed: phiếu trừ số tiền cố định vào Khấu trừ.
    foreach ($flagged as $inv => $f) {
        $made = false;
        if ($f['mode'] === 'percent') {
            $lines = $wpdb->get_results($wpdb->prepare(
                "SELECT service_type, SUM(total) AS total FROM {$p}checkin_mkt192_invoices_data_detail
                 WHERE invoice_id = %s AND staff_name = %s AND service_type IN ('service','chemical') AND is_penalty = 0 GROUP BY service_type",
                $inv, $staff_name
            ));
            foreach ($lines ?: [] as $ln) {
                $amount = round((float)$ln->total * $f['value'] / 100);
                if ($amount <= 0) continue;
                $wpdb->insert($table, [
                    'staff_name' => $staff_name, 'role' => 'Thợ', 'period' => $period, 'kind' => 'base_penalty', 'category' => $ln->service_type,
                    'title' => mb_substr("HĐ {$inv} · {$f['label']} · trừ {$f['value']}% doanh số " . ($ln->service_type === 'chemical' ? 'hoá chất' : 'dịch vụ'), 0, 191),
                    'unit_price' => $amount, 'quantity' => 1, 'amount' => $amount,
                    'note' => 'Tự động theo cài đặt lương · ngày ' . $f['date'], 'source' => $f['source'], 'ref_id' => $inv,
                ]);
                $made = true;
            }
        } else {
            $amount = round($f['value']);
            if ($amount > 0) {
                $wpdb->insert($table, [
                    'staff_name' => $staff_name, 'role' => 'Thợ', 'period' => $period, 'kind' => 'deduction', 'category' => $f['source'],
                    'title' => mb_substr("HĐ {$inv} · {$f['label']} · phạt", 0, 191), 'unit_price' => $amount, 'quantity' => 1, 'amount' => $amount,
                    'note' => 'Tự động theo cài đặt lương · ngày ' . $f['date'], 'source' => $f['source'], 'ref_id' => $inv,
                ]);
                $made = true;
            }
        }
        if ($made) $counts[$f['source']]++;
    }
    return $counts;
}

/** Tương thích tên cũ. */
function checkin_mkt192_sync_review_penalties($staff_name, $period) {
    return checkin_mkt192_sync_auto_penalties($staff_name, $period)['review'];
}

/** Gom phiếu thưởng/trừ của (nhân viên, kỳ) → tổng + danh sách để lưu snapshot. */
function checkin_mkt192_collect_adjustments($staff_name, $period) {
    global $wpdb;
    $rows = $wpdb->get_results($wpdb->prepare(
        "SELECT id, kind, category, title, unit_price, quantity, amount, note, source, ref_id, created_at
         FROM " . checkin_mkt192_adjustments_table() . " WHERE staff_name = %s AND period = %s ORDER BY kind DESC, id ASC",
        $staff_name, $period
    ), ARRAY_A);
    $out = ['bonus_total' => 0, 'deduction_total' => 0, 'items' => []];
    foreach ($rows ?: [] as $r) {
        $amt  = (int)round(floatval($r['amount']));
        $kind = in_array($r['kind'], ['bonus', 'deduction', 'marker', 'base_penalty'], true) ? $r['kind'] : 'deduction';
        if ($kind === 'bonus') { $out['bonus_total'] += $amt; } elseif ($kind === 'deduction') { $out['deduction_total'] += $amt; }
        $out['items'][] = [
            'id'         => (int)$r['id'],
            'kind'       => $kind,
            'category'   => $r['category'],
            'title'      => $r['title'],
            'unit_price' => (int)round(floatval($r['unit_price'])),
            'quantity'   => (float)$r['quantity'],
            'amount'     => $amt,
            'note'       => $r['note'],
            'source'     => $r['source'],
            'ref_id'     => $r['ref_id'],
        ];
    }
    return $out;
}

function checkin_mkt192_recompute_salary_for($role, $staff_name, $period) {
    $req = new WP_REST_Request('POST');
    $req->set_param('period', $period);
    $req->set_param('staff_name', $staff_name);
    if ($role === 'Thu Ngân') {
        return checkin_mkt192_update_cashier_salary_api($req);
    }
    return checkin_mkt192_update_hairdresser_salary($req);
}

function checkin_mkt192_salary_locked_for($role, $staff_name, $period) {
    global $wpdb;
    $table = $role === 'Thu Ngân' ? $wpdb->prefix . 'checkin_mkt192_cashier_salary' : $wpdb->prefix . 'checkin_mkt192_hairdresser_salary';
    $row = $wpdb->get_row($wpdb->prepare(
        "SELECT xac_nhan_luong, payment, status, xac_nhan_thanh_toan FROM {$table} WHERE staff_name = %s AND period = %s LIMIT 1",
        $staff_name, $period
    ));
    return checkin_mkt192_salary_row_is_locked($row);
}

/** GET /salary-adjustments?period=&staff_name= */
function checkin_mkt192_get_adjustments_api(WP_REST_Request $request) {
    $period     = sanitize_text_field($request->get_param('period'));
    $staff_name = sanitize_text_field($request->get_param('staff_name'));
    $role       = sanitize_text_field($request->get_param('role')) ?: 'Thợ';
    if (!preg_match('/^\d{4}-\d{2}$/', $period) || $staff_name === '') {
        return new WP_Error('invalid_params', 'Tham số không hợp lệ', ['status' => 400]);
    }
    $data           = checkin_mkt192_collect_adjustments($staff_name, $period);
    $data['locked'] = checkin_mkt192_salary_locked_for($role, $staff_name, $period);
    $data['review_penalty'] = checkin_mkt192_review_penalty_settings();
    return ['success' => true, 'data' => $data];
}

/** POST /salary-adjustments — tạo phiếu thưởng/trừ rồi tính lại lương kỳ đó. */
function checkin_mkt192_create_adjustment_api(WP_REST_Request $request) {
    global $wpdb;
    $period     = sanitize_text_field($request->get_param('period'));
    $staff_name = sanitize_text_field($request->get_param('staff_name'));
    $role       = sanitize_text_field($request->get_param('role')) === 'Thu Ngân' ? 'Thu Ngân' : 'Thợ';
    $kind       = sanitize_text_field($request->get_param('kind')) === 'deduction' ? 'deduction' : 'bonus';
    $category   = sanitize_text_field($request->get_param('category')) ?: 'other';
    $title      = mb_substr(sanitize_text_field((string)$request->get_param('title')), 0, 191);
    $unit_price = max(0, round(floatval($request->get_param('unit_price'))));
    $quantity   = max(0.01, round(floatval($request->get_param('quantity') ?: 1), 2));
    $amount     = $request->get_param('amount') !== null && $request->get_param('amount') !== ''
        ? max(0, round(floatval($request->get_param('amount'))))
        : round($unit_price * $quantity);
    $note       = mb_substr(sanitize_text_field((string)$request->get_param('note')), 0, 255);

    if (!preg_match('/^\d{4}-\d{2}$/', $period) || $staff_name === '') {
        return new WP_Error('invalid_params', 'Tham số không hợp lệ', ['status' => 400]);
    }
    if ($title === '' || $amount <= 0) {
        return new WP_Error('invalid_amount', 'Cần tên phiếu và số tiền > 0', ['status' => 400]);
    }
    if (checkin_mkt192_salary_locked_for($role, $staff_name, $period)) {
        return new WP_Error('salary_locked', 'Phiếu lương kỳ này đã chốt, không thêm phiếu thưởng/trừ được. Tạo ở kỳ sau.', ['status' => 409]);
    }
    $ok = $wpdb->insert(checkin_mkt192_adjustments_table(), [
        'staff_name' => $staff_name, 'role' => $role, 'period' => $period, 'kind' => $kind, 'category' => $category,
        'title' => $title, 'unit_price' => $unit_price, 'quantity' => $quantity, 'amount' => $amount, 'note' => $note,
        'source' => 'manual', 'created_by' => get_current_user_id(),
    ]);
    if ($ok === false) {
        return new WP_Error('db_error', 'Không lưu được phiếu: ' . $wpdb->last_error, ['status' => 500]);
    }
    checkin_mkt192_recompute_salary_for($role, $staff_name, $period);
    return ['success' => true, 'id' => (int)$wpdb->insert_id, 'message' => ($kind === 'bonus' ? 'Đã thêm phiếu thưởng' : 'Đã thêm phiếu trừ') . ', lương đã tính lại.'];
}

/** DELETE /salary-adjustments — xoá một phiếu (id) rồi tính lại. */
function checkin_mkt192_delete_adjustment_api(WP_REST_Request $request) {
    global $wpdb;
    $id  = absint($request->get_param('id'));
    $row = $id ? $wpdb->get_row($wpdb->prepare("SELECT staff_name, role, period, source, kind, category, ref_id, title FROM " . checkin_mkt192_adjustments_table() . " WHERE id = %d", $id)) : null;
    if (!$row) {
        return new WP_Error('not_found', 'Không tìm thấy phiếu', ['status' => 404]);
    }
    if (checkin_mkt192_salary_locked_for($row->role, $row->staff_name, $row->period)) {
        return new WP_Error('salary_locked', 'Phiếu lương kỳ này đã chốt, không xoá được.', ['status' => 409]);
    }
    $auto = in_array($row->source, ['review', 'no_image'], true);
    if ($auto && in_array($row->kind, ['deduction', 'base_penalty'], true) && $row->ref_id !== '') {
        // Truy thu tự động: xoá thẳng thì lần tính lại sau sẽ mọc lại → đổi thành marker "Bỏ qua" để sync chừa HĐ này ra;
        // một hoá đơn có thể có 2 dòng (dịch vụ + hoá chất) → gom về 1 marker, xoá dòng còn lại
        $wpdb->query($wpdb->prepare(
            "DELETE FROM " . checkin_mkt192_adjustments_table() . " WHERE staff_name = %s AND period = %s AND ref_id = %s AND source IN ('review','no_image') AND id <> %d",
            $row->staff_name, $row->period, $row->ref_id, $id
        ));
        $label = preg_replace('/ · trừ .*$/u', '', preg_replace('/^Truy thu (bù )?/u', '', $row->title));
        $wpdb->update(checkin_mkt192_adjustments_table(), [
            'kind' => 'marker', 'category' => 'ignored', 'unit_price' => 0, 'amount' => 0,
            'title' => mb_substr('Bỏ qua truy thu · ' . $label, 0, 191),
            'note'  => 'Admin bỏ qua ngày ' . current_time('d/m/Y H:i') . ' · bấm Khôi phục để truy thu lại',
        ], ['id' => $id]);
        checkin_mkt192_recompute_salary_for($row->role, $row->staff_name, $row->period);
        return ['success' => true, 'message' => 'Đã bỏ qua truy thu hoá đơn này, lương đã tính lại.', 'ignored' => true];
    }
    $wpdb->delete(checkin_mkt192_adjustments_table(), ['id' => $id]);
    checkin_mkt192_recompute_salary_for($row->role, $row->staff_name, $row->period);
    $msg = $auto && $row->category === 'ignored' ? 'Đã khôi phục truy thu hoá đơn này, lương đã tính lại.' : 'Đã xoá phiếu, lương đã tính lại.';
    return ['success' => true, 'message' => $msg];
}

/** GET/POST /salary-review-penalty — cài đặt truy thu đánh giá thấp (toàn salon). */
function checkin_mkt192_review_penalty_settings_api(WP_REST_Request $request) {
    if ($request->get_method() === 'GET') {
        return ['success' => true, 'data' => checkin_mkt192_review_penalty_settings()];
    }
    $cfg = [
        'enabled'   => filter_var($request->get_param('enabled'), FILTER_VALIDATE_BOOLEAN),
        'mode'      => sanitize_text_field($request->get_param('mode')) === 'fixed' ? 'fixed' : 'percent',
        'value'     => max(0, floatval($request->get_param('value'))),
        'threshold' => max(1, min(5, (int)($request->get_param('threshold') ?: 3))),
    ];
    if ($cfg['mode'] === 'percent') {
        $cfg['value'] = min(100, $cfg['value']);
    }
    $all = get_option('checkin_mkt192_salary_settings', []);
    $all = is_array($all) ? $all : [];
    $all['review_penalty'] = $cfg;
    update_option('checkin_mkt192_salary_settings', $all, false);
    return ['success' => true, 'data' => checkin_mkt192_salary_settings(true)['review_penalty'], 'message' => 'Đã lưu cài đặt truy thu đánh giá thấp. Áp dụng khi tính lại lương các phiếu chưa chốt.'];
}

/** Avatar nhân viên theo display_name (cache theo request). */
function checkin_mkt192_staff_avatar($staff_name) {
    static $cache = [];
    global $wpdb;
    if (!array_key_exists($staff_name, $cache)) {
        $cache[$staff_name] = (string)$wpdb->get_var($wpdb->prepare(
            "SELECT avatar FROM {$wpdb->prefix}checkin_mkt192_staff WHERE display_name = %s LIMIT 1", $staff_name
        ));
    }
    return $cache[$staff_name] !== '' ? $cache[$staff_name] : null;
}

/**
 * Thống kê chấm công của một nhân viên trong kỳ — hiện trên đầu phiếu lương.
 * working_days: ngày có check-in thành công · late_days: ngày đi trễ (late_minutes > 0)
 * leave_days: ngày nghỉ phép đã duyệt · overtime_days: ngày có hoá đơn tăng ca (thợ) hoặc đơn tăng ca đã duyệt.
 */
function checkin_mkt192_attendance_stats($staff_name, $period) {
    global $wpdb;
    if ($staff_name === '' || !preg_match('/^\d{4}-\d{2}$/', $period)) {
        return null;
    }
    $start = $period . '-01 00:00:00';
    $end   = date('Y-m-t 23:59:59', strtotime($start));
    $logs  = $wpdb->prefix . 'checkin_mkt192_checkinlogs';

    $working = (int)$wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(DISTINCT DATE(checkin_time)) FROM {$logs}
         WHERE display_name = %s AND status = 'success' AND checkin_time BETWEEN %s AND %s",
        $staff_name, $start, $end
    ));
    $late = $wpdb->get_row($wpdb->prepare(
        "SELECT COUNT(DISTINCT DATE(checkin_time)) AS days, COALESCE(SUM(late_minutes), 0) AS minutes FROM {$logs}
         WHERE display_name = %s AND late_minutes > 0 AND checkin_time BETWEEN %s AND %s",
        $staff_name, $start, $end
    ));
    $leave = (int)$wpdb->get_var($wpdb->prepare(
        "SELECT COALESCE(SUM(COALESCE(leave_total_days, 1)), 0) FROM {$wpdb->prefix}checkin_mkt192_approval_requests
         WHERE staff_name = %s AND request_type = 'leave' AND status = 'approved'
         AND leave_start_date BETWEEN %s AND %s",
        $staff_name, substr($start, 0, 10), substr($end, 0, 10)
    ));
    $overtime = (int)$wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(DISTINCT DATE(created_at)) FROM {$wpdb->prefix}checkin_mkt192_invoices_data_detail
         WHERE staff_name = %s AND is_overtime = 1 AND created_at BETWEEN %s AND %s",
        $staff_name, $start, $end
    ));
    if ($overtime === 0) {
        $overtime = (int)$wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(DISTINCT overtime_date) FROM {$wpdb->prefix}checkin_mkt192_approval_requests
             WHERE staff_name = %s AND request_type = 'overtime' AND status = 'approved'
             AND overtime_date BETWEEN %s AND %s",
            $staff_name, substr($start, 0, 10), substr($end, 0, 10)
        ));
    }

    return [
        'working_days'  => $working,
        'late_days'     => (int)($late->days ?? 0),
        'late_minutes'  => (int)($late->minutes ?? 0),
        'leave_days'    => $leave,
        'overtime_days' => $overtime,
    ];
}

/**
 * Bổ sung % hoa hồng thực tế vào một dòng lương thợ trước khi trả về client.
 *
 * Bảng hairdresser_salary chỉ lưu số tiền, không lưu % đã áp; trước đây frontend
 * đoán % từ tên bậc (mẫu "C45_15") nên tên bậc kiểu "Cao cấp 2.5 (45-15)" ra 0%.
 */
function checkin_mkt192_enrich_hairdresser_salary_row($row) {
    global $wpdb;
    static $level_cache = [];

    if (!is_object($row)) {
        return $row;
    }

    $row->attendance = checkin_mkt192_attendance_stats((string)($row->staff_name ?? ''), (string)($row->period ?? ''));
    $row->avatar     = checkin_mkt192_staff_avatar((string)($row->staff_name ?? ''));
    $row->kpi        = checkin_mkt192_kpi_result_view((string)($row->staff_name ?? ''), (string)($row->period ?? ''));
    $decoded_adj      = !empty($row->adjustments_json) ? json_decode($row->adjustments_json, true) : null;
    $row->adjustments = is_array($decoded_adj) ? $decoded_adj : null;
    unset($row->adjustments_json);
    // Kỳ đang chạy: KPI chỉ hiển thị, chưa áp vào lương (UI ghi chú)
    $row->kpi_provisional = !checkin_mkt192_kpi_applies((string)($row->period ?? ''));
    // Hoá đơn bị truy thu (is_penalty=1 trên dòng của thợ, gồm admin đánh dấu tay lẫn dấu tự động bản cũ) → phiếu ghi rõ HĐ nào, bao nhiêu
    $row->penalty_invoices = [];
    if ((floatval($row->penalty_service ?? 0) > 0 || floatval($row->penalty_chemical ?? 0) > 0) && !empty($row->staff_name) && preg_match('/^\d{4}-\d{2}$/', (string)($row->period ?? ''))) {
        $p_start = $row->period . '-01 00:00:00';
        $p_end   = date('Y-m-t 23:59:59', strtotime($p_start));
        $rows_p  = $wpdb->get_results($wpdb->prepare(
            "SELECT invoice_id, service_type, SUM(total) AS total, MIN(created_at) AS created_at
             FROM {$wpdb->prefix}checkin_mkt192_invoices_data_detail
             WHERE staff_name = %s AND is_penalty = 1 AND created_at BETWEEN %s AND %s
             GROUP BY invoice_id, service_type ORDER BY created_at",
            $row->staff_name, $p_start, $p_end
        ));
        foreach ($rows_p ?: [] as $pi) {
            $row->penalty_invoices[] = ['invoice_id' => $pi->invoice_id, 'service_type' => $pi->service_type, 'total' => (int)$pi->total, 'date' => substr((string)$pi->created_at, 0, 10)];
        }
    }

    $level_name = (string)($row->level_name ?? '');
    if (!array_key_exists($level_name, $level_cache)) {
        $level_cache[$level_name] = $level_name === ''
            ? null
            : $wpdb->get_row($wpdb->prepare(
                "SELECT service_salary, chemical_salary
                 FROM {$wpdb->prefix}checkin_mkt192_salary_level_settings
                 WHERE level_name = %s AND role LIKE %s
                 LIMIT 1",
                $level_name,
                '%Thợ%'
            ));
    }
    $level_setting = $level_cache[$level_name];
    // Phiếu tính theo bậc cũ (trước gom hạng): tỷ lệ suy từ tiền/doanh số đã đúng; chỉ dùng cài đặt hạng khi doanh số = 0.

    $kpi = null;
    if (!empty($row->staff_name) && !empty($row->period)) {
        $kpi = $wpdb->get_row($wpdb->prepare(
            "SELECT product_achieved, product_bonus
             FROM {$wpdb->prefix}checkin_mkt192_kpi_results
             WHERE staff_name = %s AND period = %s AND is_evaluated = 1
             LIMIT 1",
            $row->staff_name,
            $row->period
        ));
    }

    $service_base  = floatval($row->service_total ?? 0)  - floatval($row->penalty_service ?? 0);
    $chemical_base = floatval($row->chemical_total ?? 0) - floatval($row->penalty_chemical ?? 0);

    // Có ảnh chụp thẻ hoa hồng đã áp (từ bản 5.3.4.7) → đó là sự thật, dùng luôn.
    $applied = null;
    if (!empty($row->rates_json)) {
        $decoded = json_decode($row->rates_json, true);
        if (is_array($decoded)) {
            $applied = $decoded;
        }
    }
    unset($row->rates_json);
    $row->rates_applied = $applied;
    if ($applied) {
        $row->level_service_percent       = round(floatval($applied['service_percent'] ?? 0), 2);
        $row->level_chemical_percent      = round(floatval($applied['chemical_percent'] ?? 0), 2);
        $row->service_commission_percent  = round(floatval($applied['service_percent_effective'] ?? 0), 2);
        $row->chemical_commission_percent = round(floatval($applied['chemical_percent_effective'] ?? 0), 2);
        $row->product_commission_percent  = round(floatval($applied['product_percent_effective'] ?? 0), 2);
        $row->overtime_commission_percent = round(floatval($applied['overtime_percent'] ?? 10), 2);
        $row->product_bonus_source        = 'rates';
        $row->penalty_amount              = (int)round(floatval($row->total_salary ?? 0) * floatval($row->penalty_percent ?? 0) / 100);
        return $row;
    }

    $row->level_service_percent  = $level_setting ? round(floatval($level_setting->service_salary), 2)  : null;
    $row->level_chemical_percent = $level_setting ? round(floatval($level_setting->chemical_salary), 2) : null;

    $row->service_commission_percent  = checkin_mkt192_effective_commission_percent(
        $row->service_salary ?? 0, $service_base, $row->level_service_percent ?? 0
    );
    $row->chemical_commission_percent = checkin_mkt192_effective_commission_percent(
        $row->chemical_salary ?? 0, $chemical_base, $row->level_chemical_percent ?? 0
    );

    // Sản phẩm: KPI đạt → % thưởng KPI; KPI không đạt → 0; chưa đánh giá → 10% mặc định.
    if ($kpi && (int)$kpi->product_achieved === 1) {
        $product_fallback = floatval($kpi->product_bonus);
        $row->product_bonus_source = 'kpi';
    } elseif ($kpi) {
        $product_fallback = 0;
        $row->product_bonus_source = 'kpi_failed';
    } else {
        $product_fallback = 10;
        $row->product_bonus_source = 'default';
    }
    $row->product_commission_percent = checkin_mkt192_effective_commission_percent(
        $row->product_salary ?? 0, $row->product_total ?? 0, $product_fallback
    );

    $row->overtime_commission_percent = checkin_mkt192_effective_commission_percent(
        $row->overtime_salary ?? 0, $row->overtime_total ?? 0, 10
    );

    $row->penalty_amount = (int)round(
        floatval($row->total_salary ?? 0) * floatval($row->penalty_percent ?? 0) / 100
    );

    return $row;
}

/* =====================================================================
   THẺ HOA HỒNG THEO KỲ (salary_period_rates)
   ===================================================================== */

function checkin_mkt192_period_rates_table() {
    global $wpdb;
    return $wpdb->prefix . 'checkin_mkt192_salary_period_rates';
}

/** Chuẩn hoá một dòng thẻ hoa hồng (object DB hoặc array) về mảng số. */
function checkin_mkt192_normalize_period_rates($row, $source = null) {
    if (!$row) {
        return null;
    }
    $r = (array)$row;
    $required = array_values(array_filter(array_map('trim', explode(',', (string)($r['kpi_required'] ?? '')))));
    $scope    = in_array($r['kpi_penalty_scope'] ?? '', ['service', 'chemical', 'both'], true) ? $r['kpi_penalty_scope'] : 'service';
    return [
        'id'                  => isset($r['id']) ? (int)$r['id'] : null,
        'staff_name'          => (string)($r['staff_name'] ?? ''),
        'period'              => (string)($r['period'] ?? ''),
        'service_percent'     => round(floatval($r['service_percent'] ?? 0), 2),
        'chemical_percent'    => round(floatval($r['chemical_percent'] ?? 0), 2),
        'product_percent'     => round(floatval($r['product_percent'] ?? 10), 2),
        'product_min_qty'     => max(0, (int)($r['product_min_qty'] ?? 1)),
        'overtime_percent'    => round(floatval($r['overtime_percent'] ?? 10), 2),
        'kpi_penalty_percent' => round(floatval($r['kpi_penalty_percent'] ?? 0), 2),
        'kpi_penalty_scope'   => $scope,
        'kpi_penalty_mode'    => ($r['kpi_penalty_mode'] ?? 'once') === 'each' ? 'each' : 'once',
        'kpi_required'        => $required,
        'note'                => isset($r['note']) ? (string)$r['note'] : '',
        'source'              => $source ?: (string)($r['source'] ?? 'manual'),
        'from_period'         => (string)($r['from_period'] ?? ($r['period'] ?? '')),
        'updated_at'          => $r['updated_at'] ?? null,
    ];
}

/**
 * Tìm thẻ hoa hồng hiệu lực cho (thợ, kỳ).
 *  1. Có thẻ đúng kỳ → dùng.
 *  2. Không có → lấy thẻ kỳ gần nhất trước đó (kế thừa). $persist_carried = true thì ghi bản sao
 *     source='carried' để lịch sử kỳ này đóng băng.
 *  3. Không có thẻ nào → null (người gọi rơi về cài đặt bậc như cũ).
 */
function checkin_mkt192_resolve_period_rates($staff_name, $period, $persist_carried = false) {
    global $wpdb;
    $table = checkin_mkt192_period_rates_table();

    $exact = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$table} WHERE staff_name = %s AND period = %s LIMIT 1",
        $staff_name, $period
    ));
    if ($exact) {
        return checkin_mkt192_normalize_period_rates($exact);
    }

    $prev = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$table} WHERE staff_name = %s AND period < %s ORDER BY period DESC LIMIT 1",
        $staff_name, $period
    ));
    if (!$prev) {
        return null;
    }

    $rates                = checkin_mkt192_normalize_period_rates($prev, 'carried');
    $rates['from_period'] = $prev->period;
    $rates['period']      = $period;
    $rates['id']          = null;

    if ($persist_carried) {
        $wpdb->insert($table, [
            'staff_name'          => $staff_name,
            'period'              => $period,
            'service_percent'     => $rates['service_percent'],
            'chemical_percent'    => $rates['chemical_percent'],
            'product_percent'     => $rates['product_percent'],
            'product_min_qty'     => $rates['product_min_qty'],
            'overtime_percent'    => $rates['overtime_percent'],
            'kpi_penalty_percent' => $rates['kpi_penalty_percent'],
            'kpi_penalty_scope'   => $rates['kpi_penalty_scope'],
            'kpi_penalty_mode'    => $rates['kpi_penalty_mode'],
            'kpi_required'        => implode(',', $rates['kpi_required']),
            'note'                => $rates['note'] !== '' ? $rates['note'] : ('Kế thừa từ kỳ ' . $prev->period),
            'source'              => 'carried',
            'updated_by'          => null,
        ]);
        $rates['id'] = (int)$wpdb->insert_id;
    }
    return $rates;
}

/**
 * Thẻ mặc định sinh từ cài đặt bậc (dùng để điền form khi thợ chưa có thẻ nào).
 */
function checkin_mkt192_default_period_rates_from_level($staff_name, $period) {
    global $wpdb;
    $level = $wpdb->get_row($wpdb->prepare(
        "SELECT level_name FROM {$wpdb->prefix}checkin_mkt192_staff_level_history WHERE staff_name = %s AND is_active = 1 LIMIT 1",
        $staff_name
    ));
    $setting = $level ? $wpdb->get_row($wpdb->prepare(
        "SELECT service_salary, chemical_salary FROM {$wpdb->prefix}checkin_mkt192_salary_level_settings WHERE level_name = %s AND role LIKE %s LIMIT 1",
        $level->level_name, '%Thợ%'
    )) : null;

    $cd = checkin_mkt192_salary_settings()['card_defaults'];
    return checkin_mkt192_normalize_period_rates([
        'staff_name'          => $staff_name,
        'period'              => $period,
        'service_percent'     => $setting ? $setting->service_salary : 0,
        'chemical_percent'    => $setting ? $setting->chemical_salary : 0,
        'product_percent'     => $cd['product_percent'],
        'product_min_qty'     => $cd['product_min_qty'],
        'overtime_percent'    => $cd['overtime_percent'],
        'kpi_penalty_percent' => $cd['kpi_penalty_percent'],
        'kpi_penalty_scope'   => $cd['kpi_penalty_scope'],
        'kpi_penalty_mode'    => $cd['kpi_penalty_mode'],
        'kpi_required'        => implode(',', $cd['kpi_required']),
        'note'                => $level ? ('Theo bậc ' . $level->level_name) : 'Chưa có bậc',
    ], 'level');
}

/**
 * Áp thẻ hoa hồng + kết quả KPI → % hiệu lực và ảnh chụp để lưu vào rates_json.
 */
function checkin_mkt192_apply_period_rates($rates, $kpi_result, $product_count_total) {
    $failed = [];
    if ($kpi_result && (int)($kpi_result->is_evaluated ?? 1) === 1) {
        foreach ($rates['kpi_required'] as $key) {
            $field = $key . '_achieved';
            if (isset($kpi_result->$field) && (int)$kpi_result->$field !== 1) {
                $failed[] = $key;
            }
        }
    }
    // once: trượt 1 hay nhiều KPI đều trừ một lần · each: trừ theo số KPI trượt (cộng dồn)
    $penalty = $failed ? ($rates['kpi_penalty_mode'] === 'each' ? $rates['kpi_penalty_percent'] * count($failed) : $rates['kpi_penalty_percent']) : 0;
    $on_svc  = in_array($rates['kpi_penalty_scope'], ['service', 'both'], true) ? $penalty : 0;
    $on_chem = in_array($rates['kpi_penalty_scope'], ['chemical', 'both'], true) ? $penalty : 0;

    $product_ok = (int)$product_count_total >= $rates['product_min_qty'];

    return [
        'source'                     => $rates['source'],
        'from_period'                => $rates['from_period'],
        'service_percent'            => $rates['service_percent'],
        'chemical_percent'           => $rates['chemical_percent'],
        'service_percent_effective'  => max(0, round($rates['service_percent'] - $on_svc, 2)),
        'chemical_percent_effective' => max(0, round($rates['chemical_percent'] - $on_chem, 2)),
        'product_percent'            => $rates['product_percent'],
        'product_min_qty'            => $rates['product_min_qty'],
        'product_percent_effective'  => $product_ok ? $rates['product_percent'] : 0,
        'product_threshold_met'      => $product_ok,
        'overtime_percent'           => $rates['overtime_percent'],
        'kpi_required'               => $rates['kpi_required'],
        'kpi_evaluated'              => (bool)$kpi_result,
        'kpi_failed'                 => $failed,
        'kpi_penalty_percent'        => $rates['kpi_penalty_percent'],
        'kpi_penalty_scope'          => $rates['kpi_penalty_scope'],
        'kpi_penalty_mode'           => $rates['kpi_penalty_mode'],
        'kpi_penalty_applied'        => $penalty,
        'note'                       => $rates['note'],
    ];
}

/** Danh sách thợ đang hoạt động (display_name). */
function checkin_mkt192_list_hairdressers($staff_name = '') {
    global $wpdb;
    $sql = "SELECT display_name FROM {$wpdb->prefix}checkin_mkt192_staff WHERE user_role LIKE '%Thợ%' AND status != 'DELETED'";
    if ($staff_name !== '') {
        $sql .= $wpdb->prepare(' AND display_name = %s', $staff_name);
    }
    return $wpdb->get_col($sql . ' ORDER BY display_name ASC');
}

/** GET /salary-period-rates?period=YYYY-MM[&staff_name=] */
function checkin_mkt192_get_period_rates_api(WP_REST_Request $request) {
    global $wpdb;
    $period     = sanitize_text_field($request->get_param('period'));
    $staff_name = sanitize_text_field($request->get_param('staff_name'));
    if (!preg_match('/^\d{4}-\d{2}$/', $period)) {
        return new WP_Error('invalid_period', 'Period không hợp lệ', ['status' => 400]);
    }

    $out = [];
    foreach (checkin_mkt192_list_hairdressers($staff_name) as $name) {
        $rates  = checkin_mkt192_resolve_period_rates($name, $period, false);
        $source = $rates ? $rates['source'] : 'level';
        if (!$rates) {
            $rates = checkin_mkt192_default_period_rates_from_level($name, $period);
        }
        $salary_row = $wpdb->get_row($wpdb->prepare(
            "SELECT xac_nhan_luong, payment, status, xac_nhan_thanh_toan FROM {$wpdb->prefix}checkin_mkt192_hairdresser_salary WHERE staff_name = %s AND period = %s LIMIT 1",
            $name, $period
        ));
        $out[] = [
            'staff_name' => $name,
            'period'     => $period,
            'source'     => $source,
            'locked'     => checkin_mkt192_salary_row_is_locked($salary_row),
            'rates'      => $rates,
        ];
    }
    return ['success' => true, 'data' => $out];
}

/** POST /salary-period-rates — tạo/sửa thẻ cho 1 thợ (hoặc apply_all) rồi tính lại lương kỳ đó. */
function checkin_mkt192_save_period_rates_api(WP_REST_Request $request) {
    global $wpdb;
    $period     = sanitize_text_field($request->get_param('period'));
    $staff_name = sanitize_text_field($request->get_param('staff_name'));
    $apply_all  = filter_var($request->get_param('apply_all'), FILTER_VALIDATE_BOOLEAN);
    if (!preg_match('/^\d{4}-\d{2}$/', $period)) {
        return new WP_Error('invalid_period', 'Period không hợp lệ', ['status' => 400]);
    }
    if (!$apply_all && $staff_name === '') {
        return new WP_Error('missing_staff', 'Thiếu staff_name', ['status' => 400]);
    }

    $pct = function ($key, $default) use ($request) {
        $v = $request->get_param($key);
        $v = ($v === null || $v === '') ? $default : floatval($v);
        return max(0, min(100, round($v, 2)));
    };
    $allowed_kpi  = ['feedback', 'post_fb', 'service', 'product'];
    $kpi_required = $request->get_param('kpi_required');
    $kpi_required = is_array($kpi_required) ? $kpi_required : array_filter(array_map('trim', explode(',', (string)$kpi_required)));
    $kpi_required = array_values(array_intersect($allowed_kpi, array_map('sanitize_text_field', $kpi_required)));
    $scope        = sanitize_text_field($request->get_param('kpi_penalty_scope'));
    $scope        = in_array($scope, ['service', 'chemical', 'both'], true) ? $scope : 'service';
    $mode         = sanitize_text_field($request->get_param('kpi_penalty_mode')) === 'each' ? 'each' : 'once';

    $data = [
        'period'              => $period,
        'service_percent'     => $pct('service_percent', 0),
        'chemical_percent'    => $pct('chemical_percent', 0),
        'product_percent'     => $pct('product_percent', 10),
        'product_min_qty'     => max(0, (int)$request->get_param('product_min_qty')),
        'overtime_percent'    => $pct('overtime_percent', 10),
        'kpi_penalty_percent' => $pct('kpi_penalty_percent', 0),
        'kpi_penalty_scope'   => $scope,
        'kpi_penalty_mode'    => $mode,
        'kpi_required'        => implode(',', $kpi_required),
        'note'                => mb_substr(sanitize_text_field((string)$request->get_param('note')), 0, 255),
        'source'              => 'manual',
        'updated_by'          => get_current_user_id(),
    ];

    $targets = $apply_all ? checkin_mkt192_list_hairdressers() : [$staff_name];
    $table   = checkin_mkt192_period_rates_table();
    $saved   = [];
    $skipped = [];

    foreach ($targets as $name) {
        $salary_row = $wpdb->get_row($wpdb->prepare(
            "SELECT xac_nhan_luong, payment, status, xac_nhan_thanh_toan FROM {$wpdb->prefix}checkin_mkt192_hairdresser_salary WHERE staff_name = %s AND period = %s LIMIT 1",
            $name, $period
        ));
        if (checkin_mkt192_salary_row_is_locked($salary_row)) {
            $skipped[] = $name;
            continue;
        }
        $existing_id = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$table} WHERE staff_name = %s AND period = %s LIMIT 1", $name, $period
        ));
        if ($existing_id) {
            $wpdb->update($table, $data, ['id' => (int)$existing_id]);
        } else {
            $wpdb->insert($table, array_merge($data, ['staff_name' => $name]));
        }
        $saved[] = $name;
    }

    if (!$apply_all && empty($saved)) {
        return new WP_Error('salary_locked', 'Phiếu lương kỳ này đã chốt (nhân viên đã đồng ý hoặc đã thanh toán), không sửa hoa hồng được.', ['status' => 409]);
    }

    // Tính lại lương cho những người vừa đổi thẻ
    foreach ($saved as $name) {
        $req = new WP_REST_Request('POST');
        $req->set_param('period', $period);
        $req->set_param('staff_name', $name);
        checkin_mkt192_update_hairdresser_salary($req);
    }

    return [
        'success'        => true,
        'saved'          => $saved,
        'skipped_locked' => $skipped,
        'message'        => count($saved) . ' thẻ hoa hồng đã lưu' . ($skipped ? ', bỏ qua ' . count($skipped) . ' phiếu đã chốt' : ''),
    ];
}

/** DELETE /salary-period-rates — xoá thẻ kỳ này (quay về kế thừa kỳ trước / theo bậc). */
function checkin_mkt192_delete_period_rates_api(WP_REST_Request $request) {
    global $wpdb;
    $period     = sanitize_text_field($request->get_param('period'));
    $staff_name = sanitize_text_field($request->get_param('staff_name'));
    if (!preg_match('/^\d{4}-\d{2}$/', $period) || $staff_name === '') {
        return new WP_Error('invalid_params', 'Tham số không hợp lệ', ['status' => 400]);
    }
    $salary_row = $wpdb->get_row($wpdb->prepare(
        "SELECT xac_nhan_luong, payment, status, xac_nhan_thanh_toan FROM {$wpdb->prefix}checkin_mkt192_hairdresser_salary WHERE staff_name = %s AND period = %s LIMIT 1",
        $staff_name, $period
    ));
    if (checkin_mkt192_salary_row_is_locked($salary_row)) {
        return new WP_Error('salary_locked', 'Phiếu lương kỳ này đã chốt, không đổi hoa hồng được.', ['status' => 409]);
    }
    $wpdb->delete(checkin_mkt192_period_rates_table(), ['staff_name' => $staff_name, 'period' => $period]);

    $req = new WP_REST_Request('POST');
    $req->set_param('period', $period);
    $req->set_param('staff_name', $staff_name);
    checkin_mkt192_update_hairdresser_salary($req);

    return ['success' => true, 'message' => 'Đã xoá thẻ hoa hồng kỳ ' . $period . ', lương tính lại theo kỳ trước / bậc.'];
}

function checkin_mkt192_get_hairdresser_salary_data(WP_REST_Request $request) {
    global $wpdb;
    $type       = sanitize_text_field($request->get_param('type'));
    $period     = sanitize_text_field($request->get_param('period'));
    $staff_name = sanitize_text_field($request->get_param('staff_name')); // Lấy tham số staff_name
    $branch_id  = absint($request->get_param('branch_id'));

    if ($type !== 'salary' || !preg_match('/^\d{4}-\d{2}$/', $period)) {
        return new WP_Error('invalid_params', 'Tham số không hợp lệ', ['status' => 400]);
    }

    // Cài đặt "ẩn tạm tính": nhân viên chưa được xem kỳ này → trả rỗng kèm lý do
    $view_block = $staff_name ? checkin_mkt192_staff_view_block($period) : null;
    if ($view_block) {
        return ['success' => true, 'auto_computed' => false, 'data' => [], 'view_block' => $view_block];
    }

    // Nhân viên mở phiếu kỳ đang chạy → tự tính lại nếu phiếu chưa chốt
    $auto_computed = $staff_name ? checkin_mkt192_maybe_autocompute_salary('hairdresser', $staff_name, $period) : false;

    // Xây dựng câu truy vấn
    $query = "
        SELECT staff_name, period, level_name, level_start_date, service_total, penalty_service,
               chemical_total, penalty_chemical, product_total, product_count_total, overtime_total,
               service_salary, chemical_salary, product_salary, overtime_salary,
               total_salary, advance_salary, penalty_note, penalty_percent,
               total_of_deductions, actual_salary, working_days, uniform_fee, xac_nhan_luong,
               payment, xac_nhan_thanh_toan, status, branch_id, rates_json, adjustments_json
        FROM {$wpdb->prefix}checkin_mkt192_hairdresser_salary
        WHERE period = %s
    ";
    $params = [$period];

    // Nếu staff_name được cung cấp, thêm điều kiện vào câu truy vấn
    if ($staff_name) {
        $query .= ' AND staff_name = %s';
        $params[] = $staff_name;
    }

    // Lọc theo branch_id nếu site bật đa chi nhánh và có branch_id được truyền vào
    if (checkin_mkt192_is_multi_branch_enabled() && $branch_id > 0) {
        $query .= ' AND branch_id = %d';
        $params[] = $branch_id;
    }

    $salaries = $wpdb->get_results($wpdb->prepare($query, $params));
    $salaries = array_map('checkin_mkt192_enrich_hairdresser_salary_row', $salaries ?: []);

    return [
        'success'       => true,
        'auto_computed' => $auto_computed,
        'data'          => $salaries
    ];
}

function checkin_mkt192_update_hairdresser_salary(WP_REST_Request $request) {
    global $wpdb;
    $period     = sanitize_text_field($request->get_param('period'));
    $staff_name = sanitize_text_field($request->get_param('staff_name'));

    if (!$period || !preg_match('/^\d{4}-\d{2}$/', $period)) {
        return new WP_Error('invalid_period', 'Period không hợp lệ', ['status' => 400]);
    }

    $start_date = "$period-01 00:00:00";
    $end_date   = date('Y-m-t 23:59:59', strtotime($start_date));

    $log_file    = WP_CONTENT_DIR . '/plugins/checkin-mkt192-wp/includes/rest-api/logs/hairdresser_salary_calculation.log';
    $log_message = "=== Bắt đầu tính toán lương cho period $period (" . date('Y-m-d H:i:s') . ") ===\n";
    file_put_contents($log_file, $log_message, FILE_APPEND);

    // Kiểm tra chế độ đa chi nhánh
    $is_multi_branch = checkin_mkt192_is_multi_branch_enabled();

    $query = "SELECT display_name, branch_id FROM {$wpdb->prefix}checkin_mkt192_staff WHERE user_role LIKE '%Thợ%' AND status != 'DELETED'";
    if ($staff_name) {
        $query .= $wpdb->prepare(' AND display_name = %s', $staff_name);
    }
    $staffs = $wpdb->get_results($query);

    if (empty($staffs)) {
        return [
            'success' => true,
            'message' => 'Không có thợ nào để cập nhật lương'
        ];
    }

    // Tracking cho các thợ có vấn đề
    $warnings                      = [];
    $staff_without_level           = [];
    $staff_without_salary_settings = [];

    foreach ($staffs as $staff) {
        // Mặc định các giá trị
        $level_name              = 'N/A';
        $level_start_date        = null;
        $service_salary_percent  = 0;
        $chemical_salary_percent = 0;
        $service_total           = 0;
        $penalty_service         = 0;
        $chemical_total          = 0;
        $penalty_chemical        = 0;
        $product_total           = 0;
        $product_count_total     = 0;
        $overtime_total          = 0;
        $advance_salary          = 0;
        $working_days            = 0;
        $penalty_percent         = 0.00;
        $penalty_note            = null;
        $product_salary          = 0;

        // Thẻ hoa hồng theo kỳ (nếu có) — ưu tiên hơn cấp bậc; kế thừa kỳ trước và ghi bản sao cho kỳ này
        $period_rates  = checkin_mkt192_resolve_period_rates($staff->display_name, $period, true);
        $rates_applied = null;

        // Tính period trước đó (tháng trước)
        $previous_period_start = date('Y-m-01 00:00:00', strtotime($start_date . ' -1 month'));
        $previous_period_end   = date('Y-m-t 23:59:59', strtotime($previous_period_start));

        // Lấy cấp bậc hiện tại (is_active = 1)
        $level = $wpdb->get_row($wpdb->prepare("
            SELECT level_name, legacy_level_name, start_time, is_active
            FROM {$wpdb->prefix}checkin_mkt192_staff_level_history
            WHERE staff_name = %s
            AND is_active = 1
            LIMIT 1
        ", $staff->display_name));

        // Nếu không tìm thấy, lấy cấp bậc của tháng trước
        if (!$level) {
            $level = $wpdb->get_row($wpdb->prepare("
                SELECT level_name, legacy_level_name, start_time, is_active
                FROM {$wpdb->prefix}checkin_mkt192_staff_level_history
                WHERE staff_name = %s
                AND start_time <= %s
                ORDER BY start_time DESC
                LIMIT 1
            ", $staff->display_name, $previous_period_end));
        }

        if ($level) {
            $level_name       = $level->level_name;
            $level_start_date = $level->start_time;

            // Lấy % hoa hồng từ cấp bậc active
            $salary_settings = $wpdb->get_row($wpdb->prepare("
                SELECT service_salary, chemical_salary
                FROM {$wpdb->prefix}checkin_mkt192_salary_level_settings
                WHERE level_name = %s AND role LIKE '%Thợ%'
            ", $level->level_name));

            if ($salary_settings) {
                $service_salary_percent  = floatval($salary_settings->service_salary);
                $chemical_salary_percent = floatval($salary_settings->chemical_salary);
            } elseif (!$period_rates) {
                // Track staff với level nhưng không có salary settings
                $staff_without_salary_settings[] = [
                    'staff_name' => $staff->display_name,
                    'staff_id'   => $staff->ID ?? null,
                    'level_name' => $level->level_name
                ];
            }
        } elseif (!$period_rates) {
            // Track staff không có level
            $staff_without_level[] = [
                'staff_name' => $staff->display_name,
                'staff_id'   => $staff->ID ?? null
            ];
        }

        // Kỳ KHÔNG có thẻ hoa hồng (trước khi gom hạng): % phải là % của BẬC CŨ đã áp cho thợ, không phải % tham chiếu của hạng mới.
        // Ví dụ Hoàng Huy bậc cũ "Cao cấp 2.5 (45-15)" → hạng "Barber Chuyên Nghiệp" (tham chiếu 40/15) — kỳ 08/2026 vẫn phải 45/15.
        $legacy_pct = null;
        if (!$period_rates && $level && !empty($level->legacy_level_name)) {
            $legacy_row = $wpdb->get_row($wpdb->prepare(
                "SELECT service_salary, chemical_salary FROM {$wpdb->prefix}checkin_mkt192_salary_level_settings WHERE level_name = %s LIMIT 1",
                $level->legacy_level_name
            ));
            $legacy_pct = $legacy_row
                ? ['service' => floatval($legacy_row->service_salary), 'chemical' => floatval($legacy_row->chemical_salary)]
                : checkin_mkt192_parse_level_percents($level->legacy_level_name);
            if ($legacy_pct) {
                $service_salary_percent  = $legacy_pct['service'];
                $chemical_salary_percent = $legacy_pct['chemical'];
                $salary_settings         = $salary_settings ?: (object)['service_salary' => $legacy_pct['service'], 'chemical_salary' => $legacy_pct['chemical']];
                $log_message = "Không có thẻ kỳ này → dùng % bậc cũ {$level->legacy_level_name}: DV {$legacy_pct['service']}%, HC {$legacy_pct['chemical']}%\n";
                file_put_contents($log_file, $log_message, FILE_APPEND);
            }
        }

        if ($period_rates) {
            $service_salary_percent  = $period_rates['service_percent'];
            $chemical_salary_percent = $period_rates['chemical_percent'];
        }

        // Truy thu tự động theo cài đặt lương (đánh giá thấp, hoá đơn không ảnh) — phải chạy TRƯỚC khi cộng doanh số
        $auto_penalties = checkin_mkt192_sync_auto_penalties($staff->display_name, $period);
        file_put_contents($log_file, "Truy thu tự động: đánh giá={$auto_penalties['review']}, không ảnh={$auto_penalties['no_image']}\n", FILE_APPEND);

        // Tính các giá trị doanh số và phạt (giữ nguyên, bao gồm product_total và product_count_total)
        if (($level && $salary_settings) || $period_rates) {
            $start_datetime = new DateTime($start_date);
            $end_datetime   = new DateTime($end_date);
            $interval       = new DateInterval('P1D');
            $date_period    = new DatePeriod($start_datetime, $interval, $end_datetime);

            $log_message = "Chi tiết doanh số theo ngày:\n";
            file_put_contents($log_file, $log_message, FILE_APPEND);

            foreach ($date_period as $date) {
                $date_str = $date->format('Y-m-d');

                // Tính service_total, penalty_service (giữ nguyên)
                $service_details = $wpdb->get_results($wpdb->prepare("
                    SELECT total
                    FROM {$wpdb->prefix}checkin_mkt192_invoices_data_detail
                    WHERE staff_name = %s
                    AND service_type = 'service'
                    AND created_at BETWEEN %s AND %s
                ", $staff->display_name, $date_str . ' 00:00:00', $date_str . ' 23:59:59'), ARRAY_A);

                $service_totals = array_column($service_details, 'total');
                $service_sum    = array_sum($service_totals);
                $service_total += $service_sum;

                $log_message = "Ngày $date_str - Doanh số dịch vụ: [" . implode(', ', $service_totals) . "] = $service_sum\n";
                file_put_contents($log_file, $log_message, FILE_APPEND);

                $penalty_service_details = $wpdb->get_results($wpdb->prepare("
                    SELECT total
                    FROM {$wpdb->prefix}checkin_mkt192_invoices_data_detail
                    WHERE staff_name = %s
                    AND service_type = 'service'
                    AND is_penalty = 1
                    AND created_at BETWEEN %s AND %s
                ", $staff->display_name, $date_str . ' 00:00:00', $date_str . ' 23:59:59'), ARRAY_A);

                $penalty_service_totals = array_column($penalty_service_details, 'total');
                $penalty_service_sum    = array_sum($penalty_service_totals);
                $penalty_service += $penalty_service_sum;

                $log_message = "Ngày $date_str - Phạt dịch vụ: [" . implode(', ', $penalty_service_totals) . "] = $penalty_service_sum\n";
                file_put_contents($log_file, $log_message, FILE_APPEND);

                // Tính chemical_total, penalty_chemical (giữ nguyên)
                $chemical_details = $wpdb->get_results($wpdb->prepare("
                    SELECT total
                    FROM {$wpdb->prefix}checkin_mkt192_invoices_data_detail
                    WHERE staff_name = %s
                    AND service_type = 'chemical'
                    AND is_penalty = 0
                    AND created_at BETWEEN %s AND %s
                ", $staff->display_name, $date_str . ' 00:00:00', $date_str . ' 23:59:59'), ARRAY_A);

                $chemical_totals = array_column($chemical_details, 'total');
                $chemical_sum    = array_sum($chemical_totals);
                $chemical_total += $chemical_sum;

                $log_message = "Ngày $date_str - Doanh số hóa chất: [" . implode(', ', $chemical_totals) . "] = $chemical_sum\n";
                file_put_contents($log_file, $log_message, FILE_APPEND);

                $penalty_chemical_details = $wpdb->get_results($wpdb->prepare("
                    SELECT total
                    FROM {$wpdb->prefix}checkin_mkt192_invoices_data_detail
                    WHERE staff_name = %s
                    AND service_type = 'chemical'
                    AND is_penalty = 1
                    AND created_at BETWEEN %s AND %s
                ", $staff->display_name, $date_str . ' 00:00:00', $date_str . ' 23:59:59'), ARRAY_A);

                $penalty_chemical_totals = array_column($penalty_chemical_details, 'total');
                $penalty_chemical_sum    = array_sum($penalty_chemical_totals);
                $penalty_chemical += $penalty_chemical_sum;

                $log_message = "Ngày $date_str - Phạt hóa chất: [" . implode(', ', $penalty_chemical_totals) . "] = $penalty_chemical_sum\n";
                file_put_contents($log_file, $log_message, FILE_APPEND);

                // Tính product_total và product_count_total
                $product_details = $wpdb->get_results($wpdb->prepare("
                    SELECT total, quantity
                    FROM {$wpdb->prefix}checkin_mkt192_invoices_data_detail
                    WHERE staff_name = %s
                    AND type = 'product'
                    AND created_at BETWEEN %s AND %s
                ", $staff->display_name, $date_str . ' 00:00:00', $date_str . ' 23:59:59'), ARRAY_A);

                $product_totals = array_column($product_details, 'total');
                $product_sum    = array_sum($product_totals);
                $product_total += $product_sum;

                // Đếm theo SỐ SẢN PHẨM (một dòng bán 3 chai = 3), không đếm dòng hoá đơn — Kent chốt 09/2026
                $product_count = 0;
                foreach ($product_details as $pd) {
                    $product_count += max(1, (int)($pd['quantity'] ?? 1));
                }
                $product_count_total += $product_count;

                $log_message = "Ngày $date_str - Doanh số sản phẩm: [" . implode(', ', $product_totals) . "] = $product_sum (Số lượng: $product_count)\n";
                file_put_contents($log_file, $log_message, FILE_APPEND);

                // Tính overtime_total (giữ nguyên)
                $overtime_details = $wpdb->get_results($wpdb->prepare("
                    SELECT overtime_value
                    FROM {$wpdb->prefix}checkin_mkt192_invoices_data_detail
                    WHERE staff_name = %s
                    AND is_overtime = 1
                    AND created_at BETWEEN %s AND %s
                ", $staff->display_name, $date_str . ' 00:00:00', $date_str . ' 23:59:59'), ARRAY_A);

                $overtime_totals = array_column($overtime_details, 'overtime_value');
                $overtime_sum    = array_sum($overtime_totals);
                $overtime_total += $overtime_sum;

                $log_message = "Ngày $date_str - Giờ làm thêm: [" . implode(', ', $overtime_totals) . "] = $overtime_sum\n";
                file_put_contents($log_file, $log_message, FILE_APPEND);
            }

            $advance_salary = floatval($wpdb->get_var($wpdb->prepare("
                SELECT SUM(advance_amount)
                FROM {$wpdb->prefix}checkin_mkt192_approval_requests
                WHERE staff_name = %s
                AND request_type = 'salary_advance'
                AND status = 'approved'
                AND request_date BETWEEN %s AND %s
            ", $staff->display_name, $start_date, $end_date)) ?: 0);

            $working_days = floatval($wpdb->get_var($wpdb->prepare("
                SELECT COUNT(DISTINCT DATE(checkin_time))
                FROM {$wpdb->prefix}checkin_mkt192_checkinlogs
                WHERE display_name = %s
                AND status = 'success'
                AND checkin_time BETWEEN %s AND %s
            ", $staff->display_name, $start_date, $end_date)) ?: 0);
        }

        // Cập nhật: Lấy kết quả KPI từ kpi_results
        $kpi_result = $wpdb->get_row($wpdb->prepare("
            SELECT product_achieved, product_bonus, service_achieved, post_fb_achieved, feedback_achieved, is_evaluated
            FROM {$wpdb->prefix}checkin_mkt192_kpi_results
            WHERE staff_name = %s AND period = %s AND is_evaluated = 1
        ", $staff->display_name, $period));
        if ($kpi_result && !checkin_mkt192_kpi_applies($period)) {
            // Kỳ đang chạy (tạm tính): KPI chỉ để theo dõi, chưa áp vào lương
            $kpi_result = null;
            file_put_contents($log_file, "Kỳ $period đang chạy → KPI chỉ hiển thị, chưa áp vào lương\n", FILE_APPEND);
        }

        // Cập nhật logic tính thưởng sản phẩm
        if ($kpi_result && $kpi_result->product_achieved == 1) {
            $product_salary = $product_total * ($kpi_result->product_bonus / 100);
            $log_message    = "Thưởng sản phẩm (KPI đạt): {$kpi_result->product_bonus}% của $product_total = $product_salary\n";
        } elseif ($kpi_result) {
            $product_salary = 0;
            $log_message    = "Thưởng sản phẩm (KPI không đạt): Thưởng = 0\n";
        } else {
            if ($product_count_total >= 1) {
                $product_salary = $product_total * 0.10;
                $log_message    = "Thưởng sản phẩm (Mặc định): Đạt (>=1 sản phẩm: $product_count_total), thưởng 10% của $product_total = $product_salary\n";
            } else {
                $product_salary = 0;
                $log_message    = "Thưởng sản phẩm (Mặc định): Không đạt (0 sản phẩm), thưởng = 0\n";
            }
        }
        file_put_contents($log_file, $log_message, FILE_APPEND);

        // Thẻ hoa hồng theo kỳ: KPI trượt → trừ điểm %, sản phẩm phải đủ ngưỡng, % tăng ca theo thẻ
        $overtime_percent = 10;
        if ($period_rates) {
            $rates_applied           = checkin_mkt192_apply_period_rates($period_rates, $kpi_result, $product_count_total);
            $service_salary_percent  = $rates_applied['service_percent_effective'];
            $chemical_salary_percent = $rates_applied['chemical_percent_effective'];
            $overtime_percent        = $rates_applied['overtime_percent'];
            $product_salary          = $product_total * ($rates_applied['product_percent_effective'] / 100);
            $log_message  = "Thẻ hoa hồng kỳ ({$rates_applied['source']}): DV {$rates_applied['service_percent']}% → {$service_salary_percent}%, HC {$rates_applied['chemical_percent']}% → {$chemical_salary_percent}%";
            $log_message .= ", KPI trượt: " . (implode(',', $rates_applied['kpi_failed']) ?: 'không') . ", SP {$product_count_total}/{$rates_applied['product_min_qty']} → {$rates_applied['product_percent_effective']}%\n";
            file_put_contents($log_file, $log_message, FILE_APPEND);
        }

        // Phiếu thưởng / phiếu trừ (truy thu tự động đã đồng bộ ở trên)
        $adjustments = checkin_mkt192_collect_adjustments($staff->display_name, $period);

        // Phí đồng phục (cột legacy, admin nhập riêng) — giữ nguyên giá trị đã có và cộng vào Tổng trừ
        $uniform_fee = floatval($wpdb->get_var($wpdb->prepare(
            "SELECT uniform_fee FROM {$wpdb->prefix}checkin_mkt192_hairdresser_salary WHERE staff_name = %s AND period = %s LIMIT 1",
            $staff->display_name, $period
        )) ?: 0);

        // Truy thu tự động kiểu % (đánh giá thấp / không ảnh): trừ khỏi DOANH SỐ dịch vụ/hoá chất của hoá đơn đó rồi mới nhân hoa hồng
        // (100% = bỏ hẳn hoá đơn khỏi doanh số như admin truy thu tay; sản phẩm vẫn tính) — Kent chốt 10/09/2026
        $base_pen = $wpdb->get_results($wpdb->prepare(
            "SELECT category, COALESCE(SUM(amount), 0) AS amount FROM " . checkin_mkt192_adjustments_table() . " WHERE staff_name = %s AND period = %s AND kind = 'base_penalty' GROUP BY category",
            $staff->display_name, $period
        ));
        foreach ($base_pen ?: [] as $bp) {
            if ($bp->category === 'service')  $penalty_service  += (float)$bp->amount;
            if ($bp->category === 'chemical') $penalty_chemical += (float)$bp->amount;
        }
        $penalty_service  = min($penalty_service, $service_total);
        $penalty_chemical = min($penalty_chemical, $chemical_total);

        // Tính lương
        $service_salary      = ($service_total - $penalty_service)   * ($service_salary_percent / 100);
        $chemical_salary     = ($chemical_total - $penalty_chemical) * ($chemical_salary_percent / 100);
        $overtime_salary     = $overtime_total                       * ($overtime_percent / 100);
        $total_salary        = $service_salary + $chemical_salary + $product_salary + $overtime_salary + $adjustments['bonus_total'];
        $total_of_deductions = $advance_salary + ($total_salary * ($penalty_percent / 100)) + $uniform_fee + $adjustments['deduction_total'];
        $actual_salary       = $total_salary - $total_of_deductions;
        $log_message = "Phiếu thưởng = {$adjustments['bonus_total']}, Phiếu trừ = {$adjustments['deduction_total']} (" . count($adjustments['items']) . " phiếu)\n";
        file_put_contents($log_file, $log_message, FILE_APPEND);

        $log_message = "Tổng kết cho {$staff->display_name}:\n";
        $log_message .= "Doanh số dịch vụ = $service_total, Phạt dịch vụ = $penalty_service\n";
        $log_message .= "Doanh số hóa chất = $chemical_total, Phạt hóa chất = $penalty_chemical\n";
        $log_message .= "Doanh số sản phẩm = $product_total, Số lượng sản phẩm = $product_count_total\n";
        $log_message .= "Giờ làm thêm = $overtime_total\n";
        $log_message .= "Ứng lương = $advance_salary\n";
        $log_message .= "Số ngày làm = $working_days\n";
        $log_message .= "Lương dịch vụ = $service_salary\n";
        $log_message .= "Lương hóa chất = $chemical_salary\n";
        $log_message .= "Lương sản phẩm = $product_salary\n";
        $log_message .= "Lương làm thêm = $overtime_salary\n";
        $log_message .= "Tổng lương = $total_salary\n";
        $log_message .= "Tổng khấu trừ = $total_of_deductions\n";
        $log_message .= "Thực nhận = $actual_salary\n";
        file_put_contents($log_file, $log_message, FILE_APPEND);

        // Lưu hoặc cập nhật lương (thêm product_count_total)
        $existing_record = $wpdb->get_var($wpdb->prepare("
            SELECT COUNT(*)
            FROM {$wpdb->prefix}checkin_mkt192_hairdresser_salary
            WHERE staff_name = %s AND period = %s
        ", $staff->display_name, $period));

        $data = [
            'staff_name'          => $staff->display_name,
            'period'              => $period,
            'level_name'          => $level_name,
            'level_start_date'    => $level_start_date,
            'service_total'       => (int)$service_total,
            'penalty_service'     => (int)$penalty_service,
            'chemical_total'      => (int)$chemical_total,
            'penalty_chemical'    => (int)$penalty_chemical,
            'product_total'       => (int)$product_total,
            'product_count_total' => (int)$product_count_total,
            'overtime_total'      => (int)$overtime_total,
            'service_salary'      => (int)$service_salary,
            'chemical_salary'     => (int)$chemical_salary,
            'product_salary'      => (int)$product_salary,
            'overtime_salary'     => (int)$overtime_salary,
            'total_salary'        => (int)$total_salary,
            'advance_salary'      => (int)$advance_salary,
            'penalty_note'        => $penalty_note,
            'penalty_percent'     => $penalty_percent,
            'total_of_deductions' => (int)$total_of_deductions,
            'actual_salary'       => (int)$actual_salary,
            'working_days'        => $working_days,
            'rates_json'          => $rates_applied ? wp_json_encode($rates_applied, JSON_UNESCAPED_UNICODE) : null,
            'adjustments_json'    => $adjustments['items'] ? wp_json_encode($adjustments, JSON_UNESCAPED_UNICODE) : null,
            'updated_at'          => current_time('mysql')
        ];

        // Thêm branch_id nếu bật chế độ đa chi nhánh và staff có branch_id > 0
        if ($is_multi_branch && isset($staff->branch_id) && (int)$staff->branch_id > 0) {
            $data['branch_id'] = (int)$staff->branch_id;
        }

        if ($existing_record > 0) {
            $result = $wpdb->update(
                "{$wpdb->prefix}checkin_mkt192_hairdresser_salary",
                $data,
                [
                    'staff_name' => $staff->display_name,
                    'period'     => $period
                ]
            );
        } else {
            $data['xac_nhan_luong']      = null;
            $data['payment']             = null;
            $data['xac_nhan_thanh_toan'] = null;
            $data['status']              = null;
            $result                      = $wpdb->insert("{$wpdb->prefix}checkin_mkt192_hairdresser_salary", $data);
        }

        if ($result === false) {
            $log_message = "Lỗi khi lưu lương cho {$staff->display_name}: " . $wpdb->last_error . "\n";
            file_put_contents($log_file, $log_message, FILE_APPEND);
        } else {
            $log_message = "Lưu lương thành công cho {$staff->display_name}, Rows affected: $result\n";
            file_put_contents($log_file, $log_message, FILE_APPEND);
        }
    }

    $log_message = "=== Kết thúc tính toán lương cho period $period (" . date('Y-m-d H:i:s') . ") ===\n\n";
    file_put_contents($log_file, $log_message, FILE_APPEND);

    // Build warnings array
    if (!empty($staff_without_level)) {
        $warnings[] = [
            'type'    => 'missing_level',
            'message' => 'Các thợ sau chưa được gán cấp bậc (staff_level_history với is_active=1), lương sẽ = 0',
            'staff'   => $staff_without_level
        ];
    }
    if (!empty($staff_without_salary_settings)) {
        $warnings[] = [
            'type'    => 'missing_salary_settings',
            'message' => 'Các thợ sau có cấp bậc nhưng chưa có cài đặt lương (salary_level_settings) cho cấp đó, lương sẽ = 0',
            'staff'   => $staff_without_salary_settings
        ];
    }

    $response = [
        'success' => true,
        'message' => 'Cập nhật lương thợ thành công'
    ];

    if (!empty($warnings)) {
        $response['warnings'] = $warnings;
        $response['message'] .= ' (có ' . count($warnings) . ' cảnh báo)';
    }

    return $response;
}

function checkin_mkt192_rest_evaluate_kpi(WP_REST_Request $request) {
    $period     = sanitize_text_field($request->get_param('period'));
    $staff_name = sanitize_text_field($request->get_param('staff_name'));

    $result = checkin_mkt192_evaluate_kpi_and_update_salary($period, $staff_name);

    if (is_wp_error($result)) {
        return new WP_REST_Response($result, $result->get_error_code());
    }

    return new WP_REST_Response($result, 200);
}

function checkin_mkt192_evaluate_kpi_and_update_salary($period, $staff_name = '') {
    global $wpdb;
    $log_file    = CHECKIN_PLUGIN_DIR . '/includes/rest-api/logs/kpi_evaluation.log';
    $log_message = "=== Bắt đầu đánh giá KPI cho period $period (" . date('Y-m-d H:i:s') . ") ===\n";
    file_put_contents($log_file, $log_message, FILE_APPEND);

    // Validate period format
    if (!preg_match('/^\d{4}-\d{2}$/', $period)) {
        $log_message = "Lỗi: Period không hợp lệ - $period\n";
        file_put_contents($log_file, $log_message, FILE_APPEND);
        return new WP_Error('invalid_period', 'Period không hợp lệ', ['status' => 400]);
    }

    $start_date = "$period-01 00:00:00";
    $end_date   = date('Y-m-t 23:59:59', strtotime($start_date));

    // Tính period trước đó (tháng trước)
    $previous_period_start = date('Y-m-01 00:00:00', strtotime($start_date . ' -1 month'));
    $previous_period_end   = date('Y-m-t 23:59:59', strtotime($previous_period_start));
    $previous_period       = date('Y-m', strtotime($previous_period_start));

    // Get staff list to process
    $query = "SELECT display_name FROM {$wpdb->prefix}checkin_mkt192_staff WHERE user_role LIKE '%Thợ%' AND status != 'DELETED'";
    if ($staff_name) {
        $query .= $wpdb->prepare(' AND display_name = %s', $staff_name);
    }
    $staffs = $wpdb->get_results($query);

    if (empty($staffs)) {
        $log_message = 'Không tìm thấy thợ nào' . ($staff_name ? " với tên $staff_name" : '') . "\n";
        file_put_contents($log_file, $log_message, FILE_APPEND);
        return [
            'success' => true,
            'message' => 'Không có thợ nào để đánh giá KPI'
        ];
    }

    $log_message = 'Tìm thấy ' . count($staffs) . " thợ\n";
    file_put_contents($log_file, $log_message, FILE_APPEND);

    foreach ($staffs as $staff) {
        $log_message = "\nXử lý KPI cho thợ: {$staff->display_name}\n";
        file_put_contents($log_file, $log_message, FILE_APPEND);

        // Reset is_active for all levels for this staff — CHỈ khi cơ chế KPI đổi bậc đang bật
        // (mặc định tắt từ 5.3.5.0: hạng Barber chỉ đổi khi admin đổi; reset ở đây mà không kích hoạt lại sẽ làm thợ mất bậc)
        if (checkin_mkt192_salary_settings()['kpi_changes_level']) {
        $result = $wpdb->update(
            "{$wpdb->prefix}checkin_mkt192_staff_level_history",
            ['is_active'  => 0],
            ['staff_name' => $staff->display_name]
        );
        if ($result === false) {
            $log_message = "Lỗi khi reset is_active cho {$staff->display_name}: " . $wpdb->last_error . "\n";
            file_put_contents($log_file, $log_message, FILE_APPEND);
        } else {
            $log_message = "Reset is_active cho {$staff->display_name}, số bản ghi được cập nhật: $result\n";
            file_put_contents($log_file, $log_message, FILE_APPEND);
        }
        $wpdb->flush();
        }

        // Get all applicable KPI settings and aggregate using MAX
        $kpi_settings_list = $wpdb->get_results($wpdb->prepare("
            SELECT service_kpi, product_kpi_lv1, post_fb_kpi, feedback_kpi,
                   service_bonus, product_bonus_lv1, post_fb_bonus, feedback_bonus,
                   service_penalty, product_penalty_lv1, post_fb_penalty, feedback_penalty,
                   product_kpi_type, post_fb_mode
            FROM {$wpdb->prefix}checkin_mkt192_kpi_settings
            WHERE JSON_CONTAINS(staff_name, %s)
            AND status = 1
            AND start_date <= %s
            AND end_date >= %s
        ", wp_json_encode($staff->display_name, JSON_UNESCAPED_UNICODE), $end_date, $start_date));

        if (empty($kpi_settings_list)) {
            $log_message = "Không tìm thấy cài đặt KPI cho {$staff->display_name} trong khoảng thời gian từ $start_date đến $end_date\n";
            file_put_contents($log_file, $log_message, FILE_APPEND);
            continue;
        }

        // Aggregate KPI settings using MAX (ưu tiên 'san_pham' nếu có)
        $kpi_settings = [
            'service_kpi'         => 0,
            'product_kpi_lv1'     => 0,
            'post_fb_kpi'         => 0,
            'feedback_kpi'        => 0,
            'service_bonus'       => 0,
            'product_bonus_lv1'   => 0,
            'post_fb_bonus'       => 0,
            'feedback_bonus'      => 0,
            'service_penalty'     => 0,
            'product_penalty_lv1' => 0,
            'post_fb_penalty'     => 0,
            'feedback_penalty'    => 0,
            'product_kpi_type'    => 'doanh_thu', // Mặc định
            'post_fb_mode'        => 'count'      // count = số bài cố định · workdays = N bài mỗi ngày công
        ];

        foreach ($kpi_settings_list as $setting) {
            $kpi_settings['service_kpi']         = max($kpi_settings['service_kpi'], floatval($setting->service_kpi));
            $kpi_settings['product_kpi_lv1']     = max($kpi_settings['product_kpi_lv1'], floatval($setting->product_kpi_lv1));
            if (floatval($setting->post_fb_kpi) > $kpi_settings['post_fb_kpi']) {
                // Lấy cách tính của dòng có mục tiêu cao nhất (dòng quyết định post_fb_kpi)
                $kpi_settings['post_fb_mode'] = ($setting->post_fb_mode ?? 'count') === 'workdays' ? 'workdays' : 'count';
            }
            $kpi_settings['post_fb_kpi']         = max($kpi_settings['post_fb_kpi'], floatval($setting->post_fb_kpi));
            $kpi_settings['feedback_kpi']        = max($kpi_settings['feedback_kpi'], floatval($setting->feedback_kpi));
            $kpi_settings['service_bonus']       = max($kpi_settings['service_bonus'], floatval($setting->service_bonus));
            $kpi_settings['product_bonus_lv1']   = max($kpi_settings['product_bonus_lv1'], floatval($setting->product_bonus_lv1));
            $kpi_settings['post_fb_bonus']       = max($kpi_settings['post_fb_bonus'], floatval($setting->post_fb_bonus));
            $kpi_settings['feedback_bonus']      = max($kpi_settings['feedback_bonus'], floatval($setting->feedback_bonus));
            $kpi_settings['service_penalty']     = max($kpi_settings['service_penalty'], floatval($setting->service_penalty));
            $kpi_settings['product_penalty_lv1'] = max($kpi_settings['product_penalty_lv1'], floatval($setting->product_penalty_lv1));
            $kpi_settings['post_fb_penalty']     = max($kpi_settings['post_fb_penalty'], floatval($setting->post_fb_penalty));
            $kpi_settings['feedback_penalty']    = max($kpi_settings['feedback_penalty'], floatval($setting->feedback_penalty));

            // Ưu tiên 'san_pham' nếu có setting với product_kpi_lv1 > 0
            if ($setting->product_kpi_type === 'san_pham' && floatval($setting->product_kpi_lv1) > 0) {
                $kpi_settings['product_kpi_type'] = 'san_pham';
            }
        }

        $log_message = "Cài đặt KPI tổng hợp cho {$staff->display_name}: service_kpi={$kpi_settings['service_kpi']}, product_kpi_lv1={$kpi_settings['product_kpi_lv1']}, product_kpi_type={$kpi_settings['product_kpi_type']}, post_fb_kpi={$kpi_settings['post_fb_kpi']}, feedback_kpi={$kpi_settings['feedback_kpi']}\n";
        file_put_contents($log_file, $log_message, FILE_APPEND);

        // Initialize KPI results
        $kpi_results = [
            'service_kpi_achieved'  => false,
            'product_kpi_achieved'  => false,
            'post_fb_kpi_achieved'  => true,
            'feedback_kpi_achieved' => true
        ];
        // Số thực tế luôn tính (kể cả KPI = 0) để hiển thị thanh tiến trình; không kéo giá trị của thợ trước
        $product_count      = (int)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(GREATEST(quantity,1)),0) FROM {$wpdb->prefix}checkin_mkt192_invoices_data_detail WHERE staff_name = %s AND type = 'product' AND created_at BETWEEN %s AND %s", $staff->display_name, $start_date, $end_date));
        $product_total_eval = (float)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(total),0) FROM {$wpdb->prefix}checkin_mkt192_invoices_data_detail WHERE staff_name = %s AND type = 'product' AND created_at BETWEEN %s AND %s", $staff->display_name, $start_date, $end_date));
        $required_posts     = null;

        // Evaluate service KPI (query trực tiếp từ invoices nếu cần, nhưng dùng salary_data nếu có để nhất quán)
        $salary_data = $wpdb->get_row($wpdb->prepare("
            SELECT service_total
            FROM {$wpdb->prefix}checkin_mkt192_hairdresser_salary
            WHERE staff_name = %s AND period = %s
        ", $staff->display_name, $period));

        $service_total = $salary_data ? $salary_data->service_total : 0;
        if (!$service_total) {
            // Fallback query từ invoices
            $service_total = $wpdb->get_var($wpdb->prepare("
                SELECT SUM(total)
                FROM {$wpdb->prefix}checkin_mkt192_invoices_data_detail
                WHERE staff_name = %s
                AND service_type = 'service'
                AND created_at BETWEEN %s AND %s
            ", $staff->display_name, $start_date, $end_date)) ?: 0;
        }

        if ($kpi_settings['service_kpi'] > 0) {
            $kpi_results['service_kpi_achieved'] = $service_total >= $kpi_settings['service_kpi'];
            $log_message                         = "KPI dịch vụ: $service_total / {$kpi_settings['service_kpi']} => " . ($kpi_results['service_kpi_achieved'] ? 'Đạt' : 'Không đạt') . "\n";
        } else {
            $kpi_results['service_kpi_achieved'] = true;
            $log_message                         = "KPI dịch vụ: Không có yêu cầu => Đạt\n";
        }
        file_put_contents($log_file, $log_message, FILE_APPEND);

        // Evaluate product KPI - Query trực tiếp từ invoices_data_detail
        if ($kpi_settings['product_kpi_lv1'] > 0) {
            if ($kpi_settings['product_kpi_type'] === 'san_pham') {
                // Đếm số lượng sản phẩm
                // Đếm theo SỐ LƯỢNG bán ra (quantity), không đếm số dòng — Kent chốt 10/09/2026
                $product_count = (int)$wpdb->get_var($wpdb->prepare("
                    SELECT COALESCE(SUM(GREATEST(quantity, 1)), 0)
                    FROM {$wpdb->prefix}checkin_mkt192_invoices_data_detail
                    WHERE staff_name = %s
                    AND type = 'product'
                    AND created_at BETWEEN %s AND %s
                ", $staff->display_name, $start_date, $end_date));
                $kpi_results['product_kpi_achieved'] = $product_count >= $kpi_settings['product_kpi_lv1'];
                $log_message                         = "KPI sản phẩm (san_pham): Số lượng $product_count / {$kpi_settings['product_kpi_lv1']} => " . ($kpi_results['product_kpi_achieved'] ? 'Đạt' : 'Không đạt') . "\n";
            } else {
                // Sum doanh thu
                $product_total_eval = $wpdb->get_var($wpdb->prepare("
                    SELECT SUM(total)
                    FROM {$wpdb->prefix}checkin_mkt192_invoices_data_detail
                    WHERE staff_name = %s
                    AND type = 'product'
                    AND created_at BETWEEN %s AND %s
                ", $staff->display_name, $start_date, $end_date)) ?: 0;
                $kpi_results['product_kpi_achieved'] = $product_total_eval >= $kpi_settings['product_kpi_lv1'];
                $log_message                         = "KPI sản phẩm (doanh_thu): Doanh thu $product_total_eval / {$kpi_settings['product_kpi_lv1']} => " . ($kpi_results['product_kpi_achieved'] ? 'Đạt' : 'Không đạt') . "\n";
            }
            file_put_contents($log_file, $log_message, FILE_APPEND);
        } else {
            $kpi_results['product_kpi_achieved'] = true;
            $log_message                         = "KPI sản phẩm: Không có yêu cầu => Đạt\n";
            file_put_contents($log_file, $log_message, FILE_APPEND);
        }

        // Evaluate post_fb KPI (kết hợp với số ngày công)
        $post_count = $wpdb->get_var($wpdb->prepare("
            SELECT COUNT(*)
            FROM {$wpdb->prefix}checkin_mkt192_social_posts
            WHERE staff_name = %s
            AND post_type = 'facebook'
            AND post_date BETWEEN %s AND %s
        ", $staff->display_name, $start_date, $end_date));

        // Lấy số ngày công thực tế
        $actual_working_days = checkin_mkt192_working_days_between($staff->display_name, $start_date, $end_date);

        if ($kpi_settings['post_fb_kpi'] > 0) {
            // Cách tính do admin chọn ở Cài đặt KPI (5.3.6.2):
            //  - workdays: KPI = N bài mỗi ngày công → phải đạt = N × số ngày công thực tế (làm 7 ngày, KPI 1 bài/ngày → 7 bài)
            //  - count   : KPI = số bài cố định trong kỳ, không quy theo ngày công
            $required_posts = checkin_mkt192_post_fb_required($kpi_settings['post_fb_mode'], $kpi_settings['post_fb_kpi'], $actual_working_days);

            $kpi_results['post_fb_kpi_achieved'] = $post_count >= $required_posts;
            $log_message                         = "KPI post FB ({$kpi_settings['post_fb_mode']}): $post_count post / $required_posts post yêu cầu (KPI {$kpi_settings['post_fb_kpi']}, {$actual_working_days} ngày công) => "
                         . ($kpi_results['post_fb_kpi_achieved'] ? 'Đạt' : 'Không đạt') . "\n";
        } else {
            $kpi_results['post_fb_kpi_achieved'] = true;
            $log_message                         = "KPI post FB: Không có yêu cầu => Đạt\n";
        }
        file_put_contents($log_file, $log_message, FILE_APPEND);

        // Evaluate feedback KPI — số hoá đơn trong kỳ của thợ có ảnh đánh giá Google Maps (invoices_data.image_feedback)
        $feedback_count = checkin_mkt192_count_feedback_invoices($staff->display_name, $start_date, $end_date);

        if ($kpi_settings['feedback_kpi'] > 0) {
            $kpi_results['feedback_kpi_achieved'] = $feedback_count >= $kpi_settings['feedback_kpi'];
            $log_message                          = "KPI feedback: $feedback_count / {$kpi_settings['feedback_kpi']} => " . ($kpi_results['feedback_kpi_achieved'] ? 'Đạt' : 'Không đạt') . "\n";
        } else {
            $kpi_results['feedback_kpi_achieved'] = true;
            $log_message                          = "KPI feedback: Không có yêu cầu => Đạt\n";
        }
        file_put_contents($log_file, $log_message, FILE_APPEND);

        // Save or update KPI results
        $kpi_result_data = [
            'staff_name'        => $staff->display_name,
            'period'            => $period,
            'service_kpi'       => $kpi_settings['service_kpi'],
            'service_achieved'  => $kpi_results['service_kpi_achieved'] ? 1 : 0,
            'service_bonus'     => $kpi_results['service_kpi_achieved'] ? $kpi_settings['service_bonus'] : 0,
            'service_penalty'   => $kpi_results['service_kpi_achieved'] ? 0 : $kpi_settings['service_penalty'],
            'product_kpi'       => $kpi_settings['product_kpi_lv1'],
            'product_achieved'  => $kpi_results['product_kpi_achieved'] ? 1 : 0,
            'product_bonus'     => $kpi_results['product_kpi_achieved'] ? $kpi_settings['product_bonus_lv1'] : 0,
            'product_kpi_type'  => $kpi_settings['product_kpi_type'],
            'post_fb_kpi'       => $kpi_settings['post_fb_kpi'],
            'post_fb_achieved'  => $kpi_results['post_fb_kpi_achieved'] ? 1 : 0,
            'post_fb_bonus'     => $kpi_results['post_fb_kpi_achieved'] ? $kpi_settings['post_fb_bonus'] : 0,
            'feedback_kpi'      => $kpi_settings['feedback_kpi'],
            'feedback_achieved' => $kpi_results['feedback_kpi_achieved'] ? 1 : 0,
            'feedback_bonus'    => $kpi_results['feedback_kpi_achieved'] ? $kpi_settings['feedback_bonus'] : 0,
            'service_actual'    => (int)round(floatval($service_total)),
            'product_actual'    => $kpi_settings['product_kpi_type'] === 'san_pham' ? (float)($product_count ?? 0) : (float)($product_total_eval ?? 0),
            'post_fb_actual'    => (int)$post_count,
            'post_fb_required'  => isset($required_posts) ? (int)$required_posts : (int)$kpi_settings['post_fb_kpi'],
            'post_fb_mode'      => $kpi_settings['post_fb_mode'],
            'working_days'      => (int)$actual_working_days,
            'feedback_actual'   => (int)$feedback_count,
            'updated_at'        => current_time('mysql'),
            'is_evaluated'      => 1
        ];

        // Ghi đè tay của admin (manual_json: {service: 1|0|null, product: …, post_fb: …, feedback: …, note})
        $manual_raw = $wpdb->get_var($wpdb->prepare("SELECT manual_json FROM {$wpdb->prefix}checkin_mkt192_kpi_results WHERE staff_name = %s AND period = %s", $staff->display_name, $period));
        $manual     = $manual_raw ? json_decode($manual_raw, true) : null;
        if (is_array($manual)) {
            foreach (['service' => ['service_achieved', 'service_bonus', 'service_penalty', 'service_bonus', 'service_penalty'], 'product' => ['product_achieved', 'product_bonus', null, 'product_bonus_lv1', null], 'post_fb' => ['post_fb_achieved', 'post_fb_bonus', null, 'post_fb_bonus', null], 'feedback' => ['feedback_achieved', 'feedback_bonus', null, 'feedback_bonus', null]] as $key => $map) {
                if (!isset($manual[$key]) || $manual[$key] === null || $manual[$key] === '') continue;
                $ok = (int)$manual[$key] === 1;
                $kpi_result_data[$map[0]] = $ok ? 1 : 0;
                $kpi_result_data[$map[1]] = $ok ? $kpi_settings[$map[3]] : 0;
                if ($map[2]) $kpi_result_data[$map[2]] = $ok ? 0 : $kpi_settings[$map[4]];
            }
            $kpi_result_data['manual_json'] = wp_json_encode($manual, JSON_UNESCAPED_UNICODE);
        }

        $existing_kpi_record = $wpdb->get_var($wpdb->prepare("
            SELECT COUNT(*)
            FROM {$wpdb->prefix}checkin_mkt192_kpi_results
            WHERE staff_name = %s AND period = %s
        ", $staff->display_name, $period));

        if ($existing_kpi_record > 0) {
            $result = $wpdb->update(
                "{$wpdb->prefix}checkin_mkt192_kpi_results",
                $kpi_result_data,
                [
                    'staff_name' => $staff->display_name,
                    'period'     => $period
                ]
            );
            $log_message = "Cập nhật KPI results cho {$staff->display_name}, rows affected: " . ($result !== false ? $result : 'lỗi') . "\n";
        } else {
            $result      = $wpdb->insert("{$wpdb->prefix}checkin_mkt192_kpi_results", $kpi_result_data);
            $log_message = "Thêm mới KPI results cho {$staff->display_name}, insert ID: " . ($result !== false ? $result : 'lỗi') . "\n";
        }
        file_put_contents($log_file, $log_message, FILE_APPEND);

        // Determine if required KPIs (except product) are achieved (giữ nguyên)
        $non_product_kpis_achieved = $kpi_results['service_kpi_achieved'] &&
                                    $kpi_results['post_fb_kpi_achieved']  &&
                                    $kpi_results['feedback_kpi_achieved'];

        // Cơ chế KPI tự hạ/khôi phục cấp bậc — mặc định TẮT từ khi có 4 hạng Barber (bật ở Cài đặt lương)
        if (checkin_mkt192_salary_settings()['kpi_changes_level']) {
        // Get current active level (giữ nguyên toàn bộ phần xét bậc từ code gốc của bạn)
        $current_level = $wpdb->get_row($wpdb->prepare("
            SELECT level_name, start_time
            FROM {$wpdb->prefix}checkin_mkt192_staff_level_history
            WHERE staff_name = %s
            AND is_active = 1
            LIMIT 1
        ", $staff->display_name));

        $highest_level = $wpdb->get_row($wpdb->prepare("
            SELECT level_name, start_time
            FROM {$wpdb->prefix}checkin_mkt192_staff_level_history
            WHERE staff_name = %s
            ORDER BY start_time DESC
            LIMIT 1
        ", $staff->display_name));

        $new_level            = null;
        $new_level_start_time = null;

        if (!$current_level) {
            $previous_level = $wpdb->get_row($wpdb->prepare("
                SELECT level_name, start_time
                FROM {$wpdb->prefix}checkin_mkt192_staff_level_history
                WHERE staff_name = %s
                AND start_time <= %s
                ORDER BY start_time DESC
                LIMIT 1
            ", $staff->display_name, $previous_period_end));

            if ($previous_level) {
                $current_level = $previous_level;
                $log_message   = "Sử dụng cấp bậc từ tháng trước: {$current_level->level_name}\n";
                file_put_contents($log_file, $log_message, FILE_APPEND);
            } else {
                $current_level = $highest_level;
                $log_message   = "Sử dụng cấp bậc cao nhất: {$current_level->level_name}\n";
                file_put_contents($log_file, $log_message, FILE_APPEND);
            }
        }

        if ($current_level) {
            $new_level            = $current_level->level_name;
            $new_level_start_time = $current_level->start_time;

            if ($non_product_kpis_achieved) {
                if ($highest_level && $current_level->start_time < $highest_level->start_time) {
                    $new_level            = $highest_level->level_name;
                    $new_level_start_time = $highest_level->start_time;
                    $log_message          = "Đạt non-product KPIs, khôi phục cấp bậc cao nhất: $new_level\n";
                    file_put_contents($log_file, $log_message, FILE_APPEND);
                } else {
                    $log_message = "Đạt non-product KPIs, duy trì cấp bậc: $new_level\n";
                    file_put_contents($log_file, $log_message, FILE_APPEND);
                }
            } else {
                $previous_level = $wpdb->get_row($wpdb->prepare("
                    SELECT level_name, start_time
                    FROM {$wpdb->prefix}checkin_mkt192_staff_level_history
                    WHERE staff_name = %s
                    AND start_time < %s
                    ORDER BY start_time DESC
                    LIMIT 1
                ", $staff->display_name, $current_level->start_time));

                if ($previous_level) {
                    $new_level            = $previous_level->level_name;
                    $new_level_start_time = $previous_level->start_time;
                    $log_message          = "Không đạt non-product KPIs, hạ cấp: $new_level\n";
                    file_put_contents($log_file, $log_message, FILE_APPEND);
                } else {
                    $log_message = "Không đạt non-product KPIs, giữ nguyên cấp bậc: $new_level\n";
                    file_put_contents($log_file, $log_message, FILE_APPEND);
                }
            }
        } else {
            $new_level            = $highest_level ? $highest_level->level_name : 'N/A';
            $new_level_start_time = $highest_level ? $highest_level->start_time : null;
            $log_message          = "Sử dụng cấp bậc cao nhất: $new_level\n";
            file_put_contents($log_file, $log_message, FILE_APPEND);
        }

        // Activate the selected level (giữ nguyên)
        $result = $wpdb->update(
            "{$wpdb->prefix}checkin_mkt192_staff_level_history",
            ['is_active' => 1],
            [
                'staff_name' => $staff->display_name,
                'level_name' => $new_level,
                'start_time' => $new_level_start_time
            ]
        );
        $wpdb->flush();

        if ($result === false) {
            $log_message = "Lỗi kích hoạt cấp bậc $new_level cho {$staff->display_name}: " . $wpdb->last_error . "\n";
            file_put_contents($log_file, $log_message, FILE_APPEND);
        } elseif ($result === 0) {
            // Insert if not exists
            $insert_result = $wpdb->insert(
                "{$wpdb->prefix}checkin_mkt192_staff_level_history",
                [
                    'staff_name' => $staff->display_name,
                    'level_name' => $new_level,
                    'start_time' => $new_level_start_time,
                    'is_active'  => 1,
                    'updated_at' => current_time('mysql')
                ]
            );
            $log_message = "Thêm mới cấp bậc $new_level cho {$staff->display_name}, insert ID: " . ($insert_result !== false ? $insert_result : 'lỗi') . "\n";
            file_put_contents($log_file, $log_message, FILE_APPEND);
        } else {
            $log_message = "Kích hoạt cấp bậc $new_level cho {$staff->display_name}, rows affected: $result\n";
            file_put_contents($log_file, $log_message, FILE_APPEND);
        }
        } // end kpi_changes_level
    }

    $log_message = "=== Kết thúc đánh giá KPI cho period $period (" . date('Y-m-d H:i:s') . ") ===\n\n";
    file_put_contents($log_file, $log_message, FILE_APPEND);

    return [
        'success' => true,
        'message' => 'Đánh giá KPI và cập nhật cấp bậc thành công'
    ];
}

function checkin_mkt192_confirm_salary(WP_REST_Request $request) {
    global $wpdb;

    $staff_name = sanitize_text_field($request->get_param('staff_name'));
    $role       = sanitize_text_field($request->get_param('role'));
    $period     = sanitize_text_field($request->get_param('period'));
    $action     = sanitize_text_field($request->get_param('action'));

    // Xác định giá trị xac_nhan_luong dựa trên action
    $xac_nhan_luong = ($action === 'approve') ? 'Đồng ý' : 'Xin xét lại';

    // Chọn bảng phù hợp theo vai trò để lấy thông tin lương
    $table_cashier_salary     = $wpdb->prefix . 'checkin_mkt192_cashier_salary';
    $table_hairdresser_salary = $wpdb->prefix . 'checkin_mkt192_hairdresser_salary';

    if ($role === 'Thu Ngân') {
        $table_name = $table_cashier_salary;
    } else {
        $table_name = $table_hairdresser_salary;
    }

    // Lấy thông tin lương thực nhận từ database
    $salary_data = $wpdb->get_row($wpdb->prepare(
        "SELECT actual_salary, total_salary, total_of_deductions FROM {$table_name} WHERE staff_name = %s AND period = %s",
        $staff_name,
        $period
    ));

    // 1. Cập nhật cột xac_nhan_luong trong bảng TRƯỚC
    $result = $wpdb->update(
        $table_name,
        [
            'xac_nhan_luong' => $xac_nhan_luong,
            'status'         => 'confirmed'
        ],
        [
            'staff_name' => $staff_name,
            'period'     => $period
        ],
        ['%s', '%s'],
        ['%s', '%s']
    );

    if ($result === false) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Lỗi khi cập nhật cơ sở dữ liệu: ' . $wpdb->last_error,
        ], 500);
    }

    // 2. Push notification: Thông báo cho admin khi nhân viên xác nhận phiếu lương (không phụ thuộc Lark)
    if (function_exists('checkin_push_notify_salary_slip_confirmed')) {
        // Lấy branch_id của nhân viên
        $staff_user = get_user_by('login', $staff_name);
        $branch_id  = null;
        if ($staff_user) {
            $branch_id = get_user_meta($staff_user->ID, 'branch_id', true);
        }
        checkin_push_notify_salary_slip_confirmed($staff_name, $period, $branch_id);
    }

    // 3. Gửi Lark webhook (nếu Lark được bật, không block nếu lỗi)
    $lark_success = true;
    $lark_message = '';
    if (function_exists('is_lark_enabled') && is_lark_enabled()) {
        $webhook_url = 'https://open.larksuite.com/open-apis/bot/v2/hook/92f2f080-e65a-44de-a14b-fa9287b70da7';

        // Sử dụng card builder - LOẠI 2: Xác nhận phiếu lương (Group quản lý)
        $payload = [
            'msg_type' => 'interactive',
            'card'     => build_salary_report_confirmation_card(
                $staff_name,
                $role,
                $period,
                $salary_data->total_salary        ?? 0,
                $salary_data->total_of_deductions ?? 0,
                $salary_data->actual_salary       ?? 0,
                $action,
                $xac_nhan_luong
            )
        ];

        $response = wp_remote_post($webhook_url, [
            'method'  => 'POST',
            'headers' => ['Content-Type' => 'application/json'],
            'body'    => json_encode($payload),
            'timeout' => 30,
        ]);

        if (is_wp_error($response)) {
            $lark_success = false;
            $lark_message = 'Lark webhook lỗi: ' . $response->get_error_message();
        } else {
            $http_code = wp_remote_retrieve_response_code($response);
            if ($http_code !== 200) {
                $lark_success = false;
                $lark_message = 'Lark webhook trả về mã lỗi: ' . $http_code;
            }
        }
    }

    return new WP_REST_Response([
        'success'      => true,
        'message'      => 'Xác nhận phiếu lương thành công.',
        'lark_sent'    => $lark_success,
        'lark_message' => $lark_message,
    ], 200);
}

/**
 * Xử lý nhân viên xác nhận đã nhận lương
 * POST /vg/v1/confirm-salary-payment
 */
function checkin_mkt192_confirm_salary_payment(WP_REST_Request $request) {
    global $wpdb;

    $staff_name        = sanitize_text_field($request->get_param('staff_name'));
    $role              = sanitize_text_field($request->get_param('role'));
    $period            = sanitize_text_field($request->get_param('period'));
    $payment_confirmed = sanitize_text_field($request->get_param('payment_confirmed'));

    // Xác định giá trị xac_nhan_thanh_toan dựa trên payment_confirmed
    $xac_nhan_thanh_toan = ($payment_confirmed === 'received') ? 'Đã nhận đủ' : 'Chưa nhận được';
    $status_value        = $payment_confirmed; // 'received' hoặc 'disputed'

    // Chọn bảng phù hợp theo vai trò
    $table_cashier_salary     = $wpdb->prefix . 'checkin_mkt192_cashier_salary';
    $table_hairdresser_salary = $wpdb->prefix . 'checkin_mkt192_hairdresser_salary';

    if ($role === 'Thu Ngân') {
        $table_name = $table_cashier_salary;
    } else {
        $table_name = $table_hairdresser_salary;
    }

    // Cập nhật xac_nhan_thanh_toan và status trong bảng
    $result = $wpdb->update(
        $table_name,
        [
            'xac_nhan_thanh_toan' => $xac_nhan_thanh_toan,
            'status'              => $status_value
        ],
        [
            'staff_name' => $staff_name,
            'period'     => $period
        ],
        ['%s', '%s'], // Định dạng cho xac_nhan_thanh_toan và status
        ['%s', '%s']  // Định dạng cho staff_name và period
    );

    if ($result === false) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Lỗi khi cập nhật cơ sở dữ liệu: ' . $wpdb->last_error,
        ], 500);
    }

    // Push notification: Thông báo cho admin khi nhân viên xác nhận thanh toán
    if (function_exists('checkin_push_notify_salary_payment_confirmed')) {
        // Lấy branch_id của nhân viên
        $staff_user = get_user_by('login', $staff_name);
        $branch_id  = null;
        if ($staff_user) {
            $branch_id = get_user_meta($staff_user->ID, 'branch_id', true);
        }
        checkin_push_notify_salary_payment_confirmed($staff_name, $period, $payment_confirmed, $branch_id);
    }

    return new WP_REST_Response([
        'success' => true,
        'message' => 'Xác nhận thanh toán lương thành công.',
        'data'    => [
            'staff_name'           => $staff_name,
            'period'               => $period,
            'xac_nhan_thanh_toan'  => $xac_nhan_thanh_toan,
            'status'               => $status_value
        ]
    ], 200);
}

function checkin_mkt192_handle_upload_payment_images(WP_REST_Request $request) {
    // Require file để sử dụng wp_handle_upload() trong REST API context
    if (!function_exists('wp_handle_upload')) {
        require_once(ABSPATH . 'wp-admin/includes/file.php');
    }

    $nonce = $request->get_header('X-WP-Nonce');
    if (!wp_verify_nonce($nonce, 'wp_rest')) {
        return new WP_Error('invalid_nonce', 'Nonce không hợp lệ.', ['status' => 403]);
    }

    if (!isset($_FILES['payment_images']) || empty($_FILES['payment_images']['name'][0])) {
        return new WP_Error('no_file', 'Thiếu tham số: payment_images.', ['status' => 400]);
    }

    $staff_name = sanitize_text_field($request->get_param('staff_name'));
    $period     = sanitize_text_field($request->get_param('period'));
    $role       = sanitize_text_field($request->get_param('role'));

    if (!$staff_name || !$period) {
        return new WP_Error('missing_params', 'Thiếu tham số: staff_name hoặc period.', ['status' => 400]);
    }

    $allowed_types      = ['jpg', 'jpeg', 'png', 'gif'];
    $upload_dir         = wp_upload_dir();
    $period             = sanitize_text_field($request->get_param('period'));
    list($year, $month) = explode('-', $period);
    $custom_upload_path = $upload_dir['basedir'] . '/checkin-mkt192-wp/salary-payment/' . $year . '/' . $month . '/';
    $custom_upload_url  = $upload_dir['baseurl'] . '/checkin-mkt192-wp/salary-payment/' . $year . '/' . $month . '/';

    // Tạo thư mục nếu chưa tồn tại
    if (!file_exists($custom_upload_path)) {
        wp_mkdir_p($custom_upload_path);
    }

    $payment_urls = [];
    $files        = $_FILES['payment_images'];
    $file_count   = count($files['name']);

    for ($i = 0; $i < $file_count; $i++) {
        $file_type = pathinfo($files['name'][$i], PATHINFO_EXTENSION);
        if (!in_array(strtolower($file_type), $allowed_types)) {
            return new WP_Error('invalid_file_type', 'Định dạng file không được hỗ trợ: ' . $files['name'][$i], ['status' => 400]);
        }

        $file = [
            'name'     => $files['name'][$i],
            'type'     => $files['type'][$i],
            'tmp_name' => $files['tmp_name'][$i],
            'error'    => $files['error'][$i],
            'size'     => $files['size'][$i]
        ];

        $upload_overrides = [
            'test_form'  => false,
            'upload_dir' => $custom_upload_path
        ];

        // Tạm thời ghi đè hàm wp_upload_dir để sử dụng thư mục tùy chỉnh
        add_filter('upload_dir', function ($dirs) use ($custom_upload_path, $custom_upload_url) {
            $dirs['path'] = $custom_upload_path;
            $dirs['url']  = $custom_upload_url;
            return $dirs;
        });

        $uploaded_file = wp_handle_upload($file, $upload_overrides);

        // Xóa bộ lọc sau khi upload
        remove_filter('upload_dir', '__return_false');

        if ($uploaded_file && !isset($uploaded_file['error'])) {
            $payment_urls[] = $uploaded_file['url'];
        } else {
            return new WP_Error('upload_error', 'Lỗi khi tải file: ' . $uploaded_file['error'], ['status' => 400]);
        }
    }

    global $wpdb;

    // Chọn bảng phù hợp theo vai trò
    $table_cashier_salary     = $wpdb->prefix . 'checkin_mkt192_cashier_salary';
    $table_hairdresser_salary = $wpdb->prefix . 'checkin_mkt192_hairdresser_salary';
    $table_name               = ($role === 'Thu Ngân') ? $table_cashier_salary : $table_hairdresser_salary;

    $existing = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $table_name WHERE staff_name = %s AND period = %s",
        $staff_name,
        $period
    ));

    if (!$existing) {
        return new WP_Error('no_record', 'Không tìm thấy bản ghi lương.', ['status' => 404]);
    }

    // Lấy danh sách URL hiện tại (nếu có) và thêm các URL mới
    $existing_payment = !empty($existing->payment) ? json_decode($existing->payment, true) : [];
    if (!is_array($existing_payment)) {
        $existing_payment = [];
    }
    $payment_urls = array_merge($existing_payment, $payment_urls);

    // Cập nhật cột payment và status
    $updated = $wpdb->update(
        $table_name,
        [
            'payment' => json_encode($payment_urls),
            'status'  => 'payment pending'
        ],
        [
            'staff_name' => $staff_name,
            'period'     => $period
        ],
        ['%s', '%s'], // định dạng cho các cột được cập nhật
        ['%s', '%s']  // định dạng cho điều kiện WHERE
    );

    if ($updated === false) {
        return new WP_Error('db_error', 'Lỗi cập nhật cơ sở dữ liệu.', ['status' => 500]);
    }

    // Gửi thông báo thanh toán lương nếu Lark được bật
    if (is_lark_enabled()) {
        require_once(dirname(__FILE__, 2) . '/lark/send_salary_notification.php');
        $salary_data = [
            'staff_name'    => $staff_name,
            'period'        => $period,
            'actual_salary' => $existing->actual_salary
        ];
        send_salary_payment_notification($salary_data);
    }

    // Gửi push notification cho nhân viên về thanh toán
    if (function_exists('checkin_mkt192_notify_salary_payment')) {
        checkin_mkt192_notify_salary_payment($staff_name, $period);
    }

    return new WP_REST_Response([
        'success' => true,
        'message' => 'Ảnh thanh toán đã được lưu thành công.',
        'data'    => ['payment_urls' => $payment_urls]
    ], 200);
}

/**
 * Gửi thông báo phiếu lương đến Group chung
 */
function checkin_mkt192_send_salary_notification(WP_REST_Request $request) {
    global $wpdb;

    $period         = sanitize_text_field($request->get_param('period'));
    $roles          = $request->get_param('roles'); // Array: ['cashier', 'hairdresser']
    $branch_filters = $request->get_param('branch_filters'); // Array: { cashier: [], hairdresser: [] }

    // Fallback cho backward compatibility
    if (empty($roles)) {
        $roles = ['cashier', 'hairdresser'];
    }
    if (empty($branch_filters)) {
        $branch_filters = ['cashier' => [], 'hairdresser' => []];
    }

    // Xác định bảng
    $table_cashier_salary     = $wpdb->prefix . 'checkin_mkt192_cashier_salary';
    $table_hairdresser_salary = $wpdb->prefix . 'checkin_mkt192_hairdresser_salary';

    $cashier_salaries     = [];
    $hairdresser_salaries = [];
    $is_multi_branch      = checkin_mkt192_is_multi_branch_enabled();

    // Lấy danh sách Thu Ngân (nếu được chọn)
    if (in_array('cashier', $roles)) {
        $cashier_query  = "SELECT staff_name, actual_salary, branch_id FROM $table_cashier_salary WHERE period = %s";
        $cashier_params = [$period];

        // Filter theo branch nếu có
        $cashier_branches = isset($branch_filters['cashier']) ? $branch_filters['cashier'] : [];
        if ($is_multi_branch && !empty($cashier_branches)) {
            $placeholders = implode(',', array_fill(0, count($cashier_branches), '%d'));
            $cashier_query .= " AND branch_id IN ($placeholders)";
            $cashier_params = array_merge($cashier_params, array_map('intval', $cashier_branches));
        }

        $cashier_salaries = $wpdb->get_results($wpdb->prepare($cashier_query, $cashier_params));
    }

    // Lấy danh sách Thợ (nếu được chọn)
    if (in_array('hairdresser', $roles)) {
        $hairdresser_query  = "SELECT staff_name, actual_salary, branch_id FROM $table_hairdresser_salary WHERE period = %s";
        $hairdresser_params = [$period];

        // Filter theo branch nếu có
        $hairdresser_branches = isset($branch_filters['hairdresser']) ? $branch_filters['hairdresser'] : [];
        if ($is_multi_branch && !empty($hairdresser_branches)) {
            $placeholders = implode(',', array_fill(0, count($hairdresser_branches), '%d'));
            $hairdresser_query .= " AND branch_id IN ($placeholders)";
            $hairdresser_params = array_merge($hairdresser_params, array_map('intval', $hairdresser_branches));
        }

        $hairdresser_salaries = $wpdb->get_results($wpdb->prepare($hairdresser_query, $hairdresser_params));
    }

    // Kiểm tra có phiếu lương không
    if (empty($cashier_salaries) && empty($hairdresser_salaries)) {
        return new WP_REST_Response([
            'success' => false,
            'message' => "Không tìm thấy phiếu lương nào trong tháng $period với các điều kiện đã chọn"
        ], 404);
    }

    // Tạo nội dung thông báo
    list($year, $month) = explode('-', $period);
    $total_count        = count($cashier_salaries) + count($hairdresser_salaries);

    // Tạo mô tả đối tượng nhận thông báo
    $recipient_desc = [];
    if (in_array('cashier', $roles)) {
        $recipient_desc[] = 'Thu Ngân';
    }
    if (in_array('hairdresser', $roles)) {
        $recipient_desc[] = 'Thợ';
    }
    $recipient_text = implode(' & ', $recipient_desc);

    // Biến theo dõi trạng thái gửi Lark
    $lark_sent    = false;
    $lark_message = '';

    // Chỉ gửi thông báo Lark nếu Lark được bật
    require_once plugin_dir_path(__FILE__) . '../lark/lark-utils.php';
    if (function_exists('is_lark_enabled') && is_lark_enabled()) {
        // Load Bot Manager
        require_once plugin_dir_path(__FILE__) . '../lark/class-checkin-mkt192-message-bot-manager.php';
        require_once plugin_dir_path(__FILE__) . '../lark/card-builder.php';
        $bot_manager = Checkin_MKT192_Message_Bot_Manager::get_instance();

        // Lấy bot theo loại thông báo salary_report
        $bot = $bot_manager->get_bot_by_notification_type('salary_report');
        if ($bot) {
            // Sử dụng card builder - LOẠI 1: Thông báo phiếu lương (Group nhân viên)
            // Note: Card này không cần staff_name cụ thể vì gửi cho toàn bộ group
            $message_card = build_salary_report_notification_card($recipient_text, "{$month}/{$year}");

            // Gửi thông báo qua Bot Manager
            $result = $bot_manager->send_message('salary_report', null, $message_card);

            if (is_wp_error($result)) {
                $lark_message = 'Lỗi khi gửi thông báo Lark: ' . $result->get_error_message();
            } elseif (isset($result['code']) && $result['code'] === 0) {
                $lark_sent    = true;
                $lark_message = 'Đã gửi thông báo qua Lark';
            } else {
                $lark_message = 'Lỗi từ Lark API: ' . ($result['msg'] ?? 'Unknown error');
            }
        } else {
            $lark_message = 'Không tìm thấy bot được cấu hình cho loại thông báo phiếu lương (salary_report)';
        }
    } else {
        $lark_message = 'Lark chưa được bật, bỏ qua gửi thông báo Lark';
    }

    // Không lưu trạng thái đã gửi vào options nếu chỉ gửi cho một phần
    // Chỉ lưu nếu gửi cho TẤT CẢ (cả 2 roles và không có branch filter)
    $is_full_send = count($roles) === 2
        && empty($branch_filters['cashier'] ?? [])
        && empty($branch_filters['hairdresser'] ?? []);

    if ($is_full_send) {
        $notification_sent_key = 'salary_notification_sent_' . $period;
        update_option($notification_sent_key, current_time('mysql'), false);
    }

    // Gửi push notification cho các nhân viên được chọn (không phụ thuộc Lark)
    $push_sent = false;
    if (function_exists('checkin_mkt192_notify_salary_slip')) {
        // Thu thập danh sách tên nhân viên
        $all_staff_names = [];
        foreach ($cashier_salaries as $salary) {
            $all_staff_names[] = $salary->staff_name;
        }
        foreach ($hairdresser_salaries as $salary) {
            $all_staff_names[] = $salary->staff_name;
        }

        // Gửi push cho từng nhân viên
        foreach ($all_staff_names as $staff_name) {
            checkin_mkt192_notify_salary_slip($staff_name, $period);
        }
        $push_sent = true;
    }

    // Trả về kết quả thành công (push notification vẫn được gửi dù Lark có lỗi hoặc không bật)
    $response_message = 'Đã gửi thông báo phiếu lương thành công';
    if ($lark_sent) {
        $response_message .= ' (bao gồm Lark)';
    } elseif (function_exists('is_lark_enabled') && is_lark_enabled()) {
        $response_message .= ' (Lark: ' . $lark_message . ')';
    }

    return new WP_REST_Response([
        'success'    => true,
        'message'    => $response_message,
        'count'      => $total_count,
        'sent_at'    => current_time('mysql'),
        'lark_sent'  => $lark_sent,
        'push_sent'  => $push_sent
    ], 200);
}

/**
 * Kiểm tra trạng thái đã gửi thông báo phiếu lương
 */
function checkin_mkt192_check_salary_notification_status(WP_REST_Request $request) {
    $period                = sanitize_text_field($request->get_param('period'));
    $notification_sent_key = 'salary_notification_sent_' . $period;
    $sent_at               = get_option($notification_sent_key, false);

    return new WP_REST_Response([
        'success' => true,
        'sent'    => (bool) $sent_at,
        'sent_at' => $sent_at ? $sent_at : null
    ], 200);
}

/**
 * Cập nhật phí đồng phục cho nhân viên
 */
function checkin_mkt192_update_uniform_fee(WP_REST_Request $request) {
    global $wpdb;

    $staff_name  = sanitize_text_field($request->get_param('staff_name'));
    $period      = sanitize_text_field($request->get_param('period'));
    $role        = sanitize_text_field($request->get_param('role'));
    $uniform_fee = floatval($request->get_param('uniform_fee'));

    // Xác định bảng dựa trên vai trò
    $table_cashier_salary     = $wpdb->prefix . 'checkin_mkt192_cashier_salary';
    $table_hairdresser_salary = $wpdb->prefix . 'checkin_mkt192_hairdresser_salary';
    $table_name               = ($role === 'Thu Ngân') ? $table_cashier_salary : $table_hairdresser_salary;

    // Kiểm tra bản ghi tồn tại
    $existing = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $table_name WHERE staff_name = %s AND period = %s",
        $staff_name,
        $period
    ));

    if (!$existing) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Không tìm thấy bản ghi lương cho nhân viên này.'
        ], 404);
    }

    // Tính toán lại total_of_deductions và actual_salary
    $advance_salary      = floatval($existing->advance_salary ?? 0);
    $total_salary        = floatval($existing->total_salary ?? 0);
    $penalty_percent     = floatval($existing->penalty_percent ?? 0);
    $penalty_amount      = $total_salary * ($penalty_percent / 100);
    $adj_deduct          = function_exists('checkin_mkt192_collect_adjustments') ? checkin_mkt192_collect_adjustments($staff_name, $period)['deduction_total'] : 0;
    $total_of_deductions = $advance_salary + $penalty_amount + $uniform_fee + $adj_deduct;
    $actual_salary       = $total_salary - $total_of_deductions;

    // Cập nhật uniform_fee, total_of_deductions và actual_salary
    $result = $wpdb->update(
        $table_name,
        [
            'uniform_fee'         => $uniform_fee,
            'total_of_deductions' => $total_of_deductions,
            'actual_salary'       => $actual_salary,
        ],
        [
            'staff_name' => $staff_name,
            'period'     => $period
        ],
        ['%f', '%f', '%f'],
        ['%s', '%s']
    );

    if ($result === false) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Lỗi khi cập nhật cơ sở dữ liệu: ' . $wpdb->last_error
        ], 500);
    }

    return new WP_REST_Response([
        'success'       => true,
        'message'       => 'Cập nhật phí đồng phục thành công',
        'uniform_fee'   => $uniform_fee,
        'actual_salary' => $actual_salary
    ], 200);
}

/**
 * API: Lấy lương trung bình 12 tháng trong năm
 * GET /vg/v1/average-salary?staff_name=X&role=hairdresser|cashier&year=2025
 */
function checkin_mkt192_get_average_salary(WP_REST_Request $request) {
    global $wpdb;

    $staff_name = sanitize_text_field($request->get_param('staff_name'));
    $role       = sanitize_text_field($request->get_param('role'));
    $year       = sanitize_text_field($request->get_param('year'));

    // Mặc định: năm hiện tại nếu không truyền
    if (empty($year) || !preg_match('/^\d{4}$/', $year)) {
        $year = date('Y');
    }

    // Chọn bảng dựa trên role
    $table = ($role === 'cashier')
        ? "{$wpdb->prefix}checkin_mkt192_cashier_salary"
        : "{$wpdb->prefix}checkin_mkt192_hairdresser_salary";

    // Lấy tất cả record trong năm được chỉ định
    $salaries = $wpdb->get_results($wpdb->prepare(
        "SELECT period, actual_salary, total_salary, total_of_deductions
         FROM {$table}
         WHERE staff_name = %s AND period LIKE %s
         ORDER BY period ASC",
        $staff_name,
        $year . '-%'
    ), ARRAY_A);

    if (empty($salaries)) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Không tìm thấy dữ liệu lương cho nhân viên này.'
        ], 404);
    }

    // Tính tổng và trung bình (đã sắp xếp ASC từ query)
    $total_actual   = 0;
    $months_count   = count($salaries);
    $monthly_data   = [];

    foreach ($salaries as $s) {
        $actual = intval($s['actual_salary']);
        $total_actual += $actual;

        $monthly_data[] = [
            'period'              => $s['period'],
            'actual_salary'       => $actual,
            'total_salary'        => intval($s['total_salary']),
            'total_of_deductions' => intval($s['total_of_deductions']),
        ];
    }

    $average_salary = round($total_actual / $months_count, 0);

    return new WP_REST_Response([
        'success'        => true,
        'staff_name'     => $staff_name,
        'role'           => $role,
        'months_count'   => $months_count,
        'monthly_data'   => $monthly_data,
        'total_actual'   => $total_actual,
        'average_salary' => $average_salary
    ], 200);
}
