<?php

// Register REST API endpoints for Products
add_action('rest_api_init', function () {
    // GET: Fetch all products (Public - for staff to select when creating invoices)
    register_rest_route('vg/v1', '/products', [
        'methods'             => 'GET',
        'callback'            => 'get_products',
        'permission_callback' => '__return_true' // Public - staff need to see products to add to invoices
    ]);

    // POST: Create a new product
    register_rest_route('vg/v1', '/products', [
        'methods'             => 'POST',
        'callback'            => 'create_product',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'products.create'])
    ]);

    // PUT: Update a product
    register_rest_route('vg/v1', '/products/(?P<id>[a-zA-Z0-9]+)', [
        'methods'             => 'PUT',
        'callback'            => 'update_product',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'products.update'])
    ]);

    // DELETE: Delete a product
    register_rest_route('vg/v1', '/products/(?P<id>[a-zA-Z0-9]+)', [
        'methods'             => 'DELETE',
        'callback'            => 'delete_product',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'products.delete'])
    ]);
});

function get_products($request) {
    global $wpdb;
    $table_name  = $wpdb->prefix . 'checkin_mkt192_products';
    $group_table = $wpdb->prefix . 'checkin_mkt192_product_groups';
    $staff_table = $wpdb->prefix . 'checkin_mkt192_staff';

    // Get branch_id from request parameter
    // Nếu không có branch_id, trả về tất cả sản phẩm (admin mode)
    $branch_id = $request->get_param('branch_id');
    $branch_id = ($branch_id !== null && $branch_id !== '') ? intval($branch_id) : null;

    // Build WHERE clause for branch filtering - chỉ filter khi có branch_id cụ thể
    $where_clause = '';
    if ($branch_id !== null && $branch_id > 0) {
        // Include products from user's branch OR products with no branch (shared items)
        $where_clause = $wpdb->prepare(
            ' WHERE (p.branch_id = %d OR p.branch_id IS NULL OR p.branch_id = 0) ',
            $branch_id
        );
    }

    $products = $wpdb->get_results("
        SELECT p.id,
               p.product_name,
               p.product_group_id,
               p.price,
               p.branch_id,
               p.stock,
               p.description,
               g.group_code AS group_code
        FROM $table_name p
        LEFT JOIN $group_table g ON p.product_group_id = g.id
        $where_clause
    ", ARRAY_A);

    if ($wpdb->last_error) {
        error_log('Error fetching products: ' . $wpdb->last_error);
        return new WP_Error('db_error', 'Lỗi khi lấy danh sách sản phẩm: ' . $wpdb->last_error, ['status' => 500]);
    }

    foreach ($products as &$product) {
        if (isset($product['price'])) {
            $product['price_formatted'] = number_format((float)$product['price'], 0, '.', ',');
        }
    }

    return rest_ensure_response([
        'success' => true,
        'data'    => $products,
    ]);
}

function create_product($request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'checkin_mkt192_products';
    $data       = $request->get_json_params();

    if (empty($data['product_name'])) {
        return new WP_Error('invalid_data', 'Tên sản phẩm là bắt buộc', ['status' => 400]);
    }

    $id = !empty($data['id']) ? sanitize_text_field($data['id']) : 'SP' . str_pad($wpdb->get_var("SELECT COUNT(*) FROM $table_name") + 1, 3, '0', STR_PAD_LEFT);

    $existing = $wpdb->get_var($wpdb->prepare("SELECT id FROM $table_name WHERE id = %s", $id));
    if ($existing) {
        return new WP_Error('duplicate_id', 'ID sản phẩm đã tồn tại', ['status' => 400]);
    }

    if (!empty($data['product_group_id'])) {
        $group_table_name = $wpdb->prefix . 'checkin_mkt192_product_groups';
        $group_exists     = $wpdb->get_var($wpdb->prepare("SELECT id FROM $group_table_name WHERE id = %d", intval($data['product_group_id'])));
        if (!$group_exists) {
            return new WP_Error('invalid_group', 'Nhóm sản phẩm không tồn tại', ['status' => 400]);
        }
    }

    $branch_id = isset($data['branch_id']) ? intval($data['branch_id']) : 0;

    $result = $wpdb->insert($table_name, [
        'id'                  => $id,
        'product_name'        => sanitize_text_field($data['product_name']),
        'product_group_id'    => !empty($data['product_group_id']) ? intval($data['product_group_id']) : null,
        'price'               => floatval($data['price'] ?? 0),
        'stock'               => intval($data['stock'] ?? 0),
        'description'         => sanitize_textarea_field($data['description'] ?? ''),
        'branch_id'           => $branch_id,
        'created_at'          => current_time('mysql'),
        'updated_at'          => current_time('mysql'),
    ]);

    if ($result === false) {
        error_log('Create product error: ' . $wpdb->last_error);
        return new WP_Error('db_error', 'Lỗi khi thêm sản phẩm: ' . $wpdb->last_error, ['status' => 500]);
    }

    return rest_ensure_response([
        'success' => true,
        'message' => 'Thêm sản phẩm thành công',
        'data'    => ['id' => $id],
    ]);
}

function update_product($request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'checkin_mkt192_products';
    $id         = $request['id'];
    $data       = $request->get_json_params();

    $existing = $wpdb->get_var($wpdb->prepare("SELECT id FROM $table_name WHERE id = %s", $id));
    if (!$existing) {
        return new WP_Error('not_found', 'Không tìm thấy sản phẩm với ID này', ['status' => 404]);
    }

    if (empty($data['product_name'])) {
        return new WP_Error('invalid_data', 'Tên sản phẩm là bắt buộc', ['status' => 400]);
    }

    if (!empty($data['product_group_id'])) {
        $group_table_name = $wpdb->prefix . 'checkin_mkt192_product_groups';
        $group_exists     = $wpdb->get_var($wpdb->prepare("SELECT id FROM $group_table_name WHERE id = %d", intval($data['product_group_id'])));
        if (!$group_exists) {
            return new WP_Error('invalid_group', 'Nhóm sản phẩm không tồn tại', ['status' => 400]);
        }
    }

    $branch_id = isset($data['branch_id']) ? intval($data['branch_id']) : 0;

    $result = $wpdb->update($table_name, [
        'product_name'        => sanitize_text_field($data['product_name']),
        'product_group_id'    => !empty($data['product_group_id']) ? intval($data['product_group_id']) : null,
        'price'               => floatval($data['price'] ?? 0),
        'stock'               => intval($data['stock'] ?? 0),
        'description'         => sanitize_textarea_field($data['description'] ?? ''),
        'branch_id'           => $branch_id,
        'updated_at'          => current_time('mysql'),
    ], ['id' => $id]);

    if ($result === false) {
        error_log('Update product error: ' . $wpdb->last_error);
        return new WP_Error('db_error', 'Lỗi khi cập nhật sản phẩm: ' . $wpdb->last_error, ['status' => 500]);
    }

    return rest_ensure_response([
        'success' => true,
        'message' => 'Cập nhật sản phẩm thành công',
    ]);
}

function delete_product($request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'checkin_mkt192_products';
    $id         = $request['id'];

    $result = $wpdb->delete($table_name, ['id' => $id]);

    if ($result === false) {
        error_log('Delete product error: ' . $wpdb->last_error);
        return new WP_Error('db_error', 'Lỗi khi xóa sản phẩm: ' . $wpdb->last_error, ['status' => 500]);
    }

    return rest_ensure_response([
        'success' => true,
        'message' => 'Xóa sản phẩm thành công',
    ]);
}
?>
