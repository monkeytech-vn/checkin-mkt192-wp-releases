<?php

/**
 * Cash Shift Management API
 * API quản lý ca thu ngân (giao nhận ca)
 *
 * @package Checkin_MKT192
 * @subpackage REST_API
 */

add_action('rest_api_init', function () {
    // ===================================
    // CURRENT SHIFT ENDPOINTS
    // ===================================

    // Lấy ca đang mở của user hiện tại
    register_rest_route('vg/v1', '/cash-shifts/current', [
        'methods'             => 'GET',
        'callback'            => 'checkin_mkt192_get_current_cash_shift',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login'])
    ]);

    // Mở ca mới
    register_rest_route('vg/v1', '/cash-shifts/open', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_open_cash_shift',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login'])
    ]);

    // Kết ca
    register_rest_route('vg/v1', '/cash-shifts/(?P<id>\d+)/close', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_close_cash_shift',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login'])
    ]);

    // ===================================
    // TRANSACTION ENDPOINTS (Phiếu thu/chi)
    // ===================================

    // Lấy danh sách phiếu thu/chi trong ca
    register_rest_route('vg/v1', '/cash-shifts/(?P<id>\d+)/transactions', [
        'methods'             => 'GET',
        'callback'            => 'checkin_mkt192_get_cash_shift_transactions',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login'])
    ]);

    // Tạo phiếu thu/chi mới
    register_rest_route('vg/v1', '/cash-shifts/(?P<id>\d+)/transactions', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_create_cash_transaction',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login'])
    ]);

    // Xóa phiếu thu/chi
    register_rest_route('vg/v1', '/cash-shifts/transactions/(?P<id>\d+)', [
        'methods'             => 'DELETE',
        'callback'            => 'checkin_mkt192_delete_cash_transaction',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login'])
    ]);

    // Lấy doanh số realtime trong ca đang mở
    register_rest_route('vg/v1', '/cash-shifts/(?P<id>\d+)/sales', [
        'methods'             => 'GET',
        'callback'            => 'checkin_mkt192_get_cash_shift_sales',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login'])
    ]);

    // ===================================
    // HISTORY ENDPOINTS
    // ===================================

    // Lấy lịch sử ca
    register_rest_route('vg/v1', '/cash-shifts/history', [
        'methods'             => 'GET',
        'callback'            => 'checkin_mkt192_get_cash_shift_history',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login'])
    ]);

    // Chi tiết ca
    register_rest_route('vg/v1', '/cash-shifts/(?P<id>\d+)', [
        'methods'             => 'GET',
        'callback'            => 'checkin_mkt192_get_cash_shift_detail',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login'])
    ]);

    // Xóa lịch sử ca - chỉ cho phép user có quyền shift.delete_history
    register_rest_route('vg/v1', '/cash-shifts/(?P<id>\d+)', [
        'methods'             => 'DELETE',
        'callback'            => 'checkin_mkt192_delete_cash_shift',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'shift.delete_history'])
    ]);

    // Lấy doanh số trong ngày trước khi mở ca (dùng khi mở ca mới)
    register_rest_route('vg/v1', '/cash-shifts/pre-open-sales', [
        'methods'             => 'GET',
        'callback'            => 'checkin_mkt192_get_pre_open_sales',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login'])
    ]);

    // ===================================
    // REPORT ENDPOINTS
    // ===================================

    // Lấy tổng phiếu chi theo khoảng thời gian (dùng cho báo cáo)
    register_rest_route('vg/v1', '/cash-shifts/total-expenses', [
        'methods'             => 'GET',
        'callback'            => 'checkin_mkt192_get_total_expenses',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login'])
    ]);
});

// Force flush rewrite rules khi cash shift API mới được thêm
add_action('init', function() {
    $option_key      = 'checkin_mkt192_cash_shift_api_version';
    $current_version = '1.1.0'; // Bump version để force re-check
    if (get_option($option_key) !== $current_version) {
        flush_rewrite_rules();
        update_option($option_key, $current_version);
    }
}, 999);

// ===================================
// API CALLBACK FUNCTIONS
// ===================================

/**
 * Lấy ca đang mở của user hiện tại
 */
function checkin_mkt192_get_current_cash_shift(WP_REST_Request $request) {
    global $wpdb;
    $current_user_id = get_current_user_id();
    $table           = $wpdb->prefix . 'checkin_mkt192_cash_shifts';

    // Lấy branch_id từ request hoặc cookie
    $branch_id = intval($request->get_param('branch_id') ?: 0);
    if (!$branch_id) {
        $branch_id = isset($_COOKIE['checkinBranchId']) ? intval($_COOKIE['checkinBranchId']) : 0;
    }

    // Kiểm tra chế độ đa chi nhánh
    $multi_branch_enabled = get_option('checkin_branch_mode_enabled', '0') === '1';

    // Debug log
    error_log("[CashShift] get_current - branch_id: $branch_id, multi_branch: " . ($multi_branch_enabled ? 'true' : 'false') . ", user_id: $current_user_id");

    try {
        // ✅ FIXED: Luôn tìm ca đang mở của chi nhánh (nếu có branch_id)
        // Điều này cho phép hiển thị ca đang mở cho tất cả users cùng chi nhánh
        $shift = null;

        if ($branch_id > 0) {
            // Có branch_id: Tìm ca đang mở của chi nhánh đó
            $shift = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM $table WHERE branch_id = %d AND status = 'open' ORDER BY start_time DESC LIMIT 1",
                $branch_id
            ), ARRAY_A);
            error_log("[CashShift] get_current - Query by branch_id: $branch_id, found: " . ($shift ? $shift['id'] : 'null'));
        }

        // Nếu không tìm thấy theo branch hoặc không có branch_id, tìm theo user
        if (!$shift) {
            $shift = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM $table WHERE staff_id = %d AND status = 'open' ORDER BY start_time DESC LIMIT 1",
                $current_user_id
            ), ARRAY_A);
            error_log("[CashShift] get_current - Query by user_id: $current_user_id, found: " . ($shift ? $shift['id'] : 'null'));
        }

        if (!$shift) {
            return new WP_REST_Response(['success' => true, 'data' => null], 200);
        }

        // ✅ Thêm flag để frontend biết ca này có phải của user hiện tại không
        $shift['is_own_shift'] = intval($shift['staff_id']) === intval($current_user_id);
        error_log("[CashShift] get_current - shift_staff_id: {$shift['staff_id']}, current_user_id: $current_user_id, is_own_shift: " . ($shift['is_own_shift'] ? 'true' : 'false'));

        return new WP_REST_Response(['success' => true, 'data' => $shift], 200);
    } catch (Exception $e) {
        return new WP_Error('fetch_failed', 'Lỗi khi lấy thông tin ca: ' . $e->getMessage(), ['status' => 500]);
    }
}

/**
 * Mở ca mới
 */
function checkin_mkt192_open_cash_shift(WP_REST_Request $request) {
    global $wpdb;
    $data         = $request->get_json_params();
    $current_user = wp_get_current_user();
    $table        = $wpdb->prefix . 'checkin_mkt192_cash_shifts';

    $opening_balance          = isset($data['opening_balance']) ? floatval($data['opening_balance']) : 0;
    $opening_transfer_balance = isset($data['opening_transfer_balance']) ? floatval($data['opening_transfer_balance']) : 0;
    $note                     = isset($data['note']) ? sanitize_textarea_field($data['note']) : '';
    $branch_id                = isset($data['branch_id']) ? intval($data['branch_id']) : 0;
    $include_pre_open_sales   = isset($data['include_pre_open_sales']) ? (bool)$data['include_pre_open_sales'] : false;
    $pre_open_start_time      = isset($data['pre_open_start_time']) ? sanitize_text_field($data['pre_open_start_time']) : null;

    // Debug log
    error_log('[CashShift] open_cash_shift - Request data: ' . json_encode($data));
    error_log('[CashShift] open_cash_shift - branch_id from request: ' . $branch_id);
    error_log('[CashShift] open_cash_shift - include_pre_open_sales: ' . ($include_pre_open_sales ? 'true' : 'false'));
    error_log('[CashShift] open_cash_shift - opening_transfer_balance: ' . $opening_transfer_balance);

    // Lấy branch_id từ cookie/session nếu không có trong request
    if (!$branch_id) {
        $branch_id = isset($_COOKIE['checkinBranchId']) ? intval($_COOKIE['checkinBranchId']) : 0;
        error_log('[CashShift] open_cash_shift - branch_id from cookie: ' . $branch_id);
    }

    // Fallback: Lấy từ query parameter
    if (!$branch_id) {
        $branch_id = intval($request->get_param('branch_id') ?: 0);
        error_log('[CashShift] open_cash_shift - branch_id from query param: ' . $branch_id);
    }

    error_log('[CashShift] open_cash_shift - Final branch_id: ' . $branch_id);

    try {
        // Kiểm tra xem user đã có ca đang mở chưa
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table WHERE staff_id = %d AND status = 'open'",
            $current_user->ID
        ));

        if ($existing > 0) {
            return new WP_Error('shift_already_open', 'Bạn đang có ca chưa kết thúc. Vui lòng kết ca trước.', ['status' => 400]);
        }

        // ✅ FIXED: Kiểm tra xem chi nhánh đã có ca đang mở của người khác chưa
        $multi_branch_enabled = get_option('checkin_branch_mode_enabled', '0') === '1';
        if ($multi_branch_enabled && $branch_id > 0) {
            $branch_open_shift = $wpdb->get_row($wpdb->prepare(
                "SELECT id, staff_name FROM $table WHERE branch_id = %d AND status = 'open' LIMIT 1",
                $branch_id
            ), ARRAY_A);

            if ($branch_open_shift) {
                return new WP_Error(
                    'branch_shift_already_open',
                    'Chi nhánh này đang có ca mở bởi ' . $branch_open_shift['staff_name'] . '. Vui lòng đợi ca hiện tại kết thúc.',
                    ['status' => 400, 'current_shift_owner' => $branch_open_shift['staff_name']]
                );
            }
        }

        if ($existing > 0) {
            return new WP_Error('shift_already_open', 'Bạn đang có ca chưa kết thúc. Vui lòng kết ca trước.', ['status' => 400]);
        }

        // ✅ FIXED: start_time luôn là thời điểm mở ca thực tế
        // Logic gộp doanh số ảnh hưởng đến sales_start_time (thời điểm bắt đầu tính doanh số)
        $start_time = current_time('mysql');

        // Nếu gộp doanh số, sales_start_time = pre_open_start_time (thời điểm kết thúc ca trước hoặc đầu ngày)
        // Nếu không gộp, sales_start_time = NULL (sẽ dùng start_time)
        $sales_start_time = null;
        if ($include_pre_open_sales && $pre_open_start_time) {
            $sales_start_time = $pre_open_start_time;
        }

        error_log('[CashShift] open_cash_shift - include_pre_open_sales: ' . ($include_pre_open_sales ? 'true' : 'false'));
        error_log('[CashShift] open_cash_shift - start_time (always current time): ' . $start_time);
        error_log('[CashShift] open_cash_shift - sales_start_time: ' . ($sales_start_time ?: 'NULL (will use start_time)'));

        // Tạo ca mới
        $insert_data = [
            'staff_id'                 => $current_user->ID,
            'staff_name'               => $current_user->display_name,
            'branch_id'                => $branch_id,
            'opening_balance'          => $opening_balance,
            'opening_transfer_balance' => $opening_transfer_balance,
            'sales_revenue'            => 0,
            'total_receipts'           => 0,
            'total_payments'           => 0,
            'status'                   => 'open',
            'note'                     => $note,
            'start_time'               => $start_time,
        ];

        $insert_format = ['%d', '%s', '%d', '%f', '%f', '%f', '%f', '%f', '%s', '%s', '%s'];

        // Chỉ thêm sales_start_time nếu có giá trị (khi gộp doanh số)
        if ($sales_start_time) {
            $insert_data['sales_start_time'] = $sales_start_time;
            $insert_format[]                 = '%s';
        }

        $result = $wpdb->insert($table, $insert_data, $insert_format);

        if ($result === false) {
            throw new Exception('Không thể mở ca: ' . $wpdb->last_error);
        }

        $shift_id  = $wpdb->insert_id;
        $new_shift = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table WHERE id = %d",
            $shift_id
        ), ARRAY_A);

        return new WP_REST_Response(['success' => true, 'data' => $new_shift, 'message' => 'Đã mở ca thành công'], 200);
    } catch (Exception $e) {
        return new WP_Error('open_failed', 'Lỗi khi mở ca: ' . $e->getMessage(), ['status' => 500]);
    }
}

/**
 * Kết ca
 */
function checkin_mkt192_close_cash_shift(WP_REST_Request $request) {
    global $wpdb;
    $shift_id        = intval($request->get_param('id'));
    $data            = $request->get_json_params();
    $current_user_id = get_current_user_id();
    $table           = $wpdb->prefix . 'checkin_mkt192_cash_shifts';

    $actual_balance       = isset($data['actual_balance']) ? floatval($data['actual_balance']) : 0;
    $handover_to          = isset($data['handover_to']) ? sanitize_text_field($data['handover_to']) : '';
    $handover_to_id_param = isset($data['handover_to_id']) && is_numeric($data['handover_to_id']) ? intval($data['handover_to_id']) : null;
    $handover_to_name     = isset($data['handover_to_name']) ? sanitize_text_field($data['handover_to_name']) : '';
    $handover_method      = isset($data['handover_method']) ? sanitize_text_field($data['handover_method']) : 'cash';
    $note                 = isset($data['note']) ? sanitize_textarea_field($data['note']) : '';
    $difference_reason    = isset($data['difference_reason']) ? sanitize_textarea_field($data['difference_reason']) : '';

    try {
        // Kiểm tra ca tồn tại và thuộc về user hiện tại
        $shift = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table WHERE id = %d AND staff_id = %d AND status = 'open'",
            $shift_id,
            $current_user_id
        ), ARRAY_A);

        if (!$shift) {
            return new WP_Error('shift_not_found', 'Không tìm thấy ca hoặc ca không thuộc về bạn', ['status' => 404]);
        }

        // Tính toán doanh số từ invoices trong khoảng thời gian ca
        // ✅ FIXED: Sử dụng sales_start_time nếu có (khi gộp doanh số trước mở ca)
        $start_time     = !empty($shift['sales_start_time']) ? $shift['sales_start_time'] : $shift['start_time'];
        $branch_id      = intval($shift['branch_id'] ?? 0);
        $invoices_table = $wpdb->prefix . 'checkin_mkt192_invoices_data';

        // Kiểm tra chế độ đa chi nhánh
        $multi_branch_enabled = get_option('checkin_branch_mode_enabled', '0') === '1';
        $branch_filter        = '';
        if ($multi_branch_enabled && $branch_id > 0) {
            $branch_filter = $wpdb->prepare(' AND branch_id = %d', $branch_id);
        }

        // ✅ FIXED: Dùng paid_at để tính doanh số ca (nhất quán với get_sales API)
        // Lấy tổng doanh số tiền mặt từ các hóa đơn đã thanh toán trong ca
        $sales_revenue = $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(total), 0) FROM $invoices_table
             WHERE paid_at >= %s
             AND payment_method = 'cash'
             AND status = 'paid'" . $branch_filter,
            $start_time
        ));

        // Xử lý handover_to - nếu là "self" thì lưu user hiện tại, nếu có ID từ frontend thì dùng nó
        $handover_to_id = null;
        if ($handover_to === 'self') {
            $handover_to_id   = $current_user_id;
            $handover_to_name = 'Tự giữ';
        } elseif (!empty($handover_to_id_param)) {
            // Frontend gửi ID người nhận từ dropdown
            $handover_to_id = $handover_to_id_param;
            // Nếu chưa có handover_to_name, lấy từ user
            if (empty($handover_to_name)) {
                $handover_user = get_user_by('id', $handover_to_id);
                if ($handover_user) {
                    $handover_to_name = $handover_user->display_name;
                }
            }
        } elseif (!empty($handover_to) && is_numeric($handover_to) && $handover_to !== 'other') {
            // Fallback: handover_to là numeric (user ID)
            $handover_to_id = intval($handover_to);
            // Nếu chưa có handover_to_name, lấy từ user
            if (empty($handover_to_name)) {
                $handover_user = get_user_by('id', $handover_to_id);
                if ($handover_user) {
                    $handover_to_name = $handover_user->display_name;
                }
            }
        }
        // Nếu handover_to === 'other', handover_to_id sẽ là null và handover_to_name được dùng

        // Lấy tổng phiếu thu/chi
        $transactions_table = $wpdb->prefix . 'checkin_mkt192_cash_transactions';
        $total_receipts     = $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(amount), 0) FROM $transactions_table WHERE shift_id = %d AND type = 'receipt'",
            $shift_id
        ));
        $total_payments = $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(amount), 0) FROM $transactions_table WHERE shift_id = %d AND type = 'payment'",
            $shift_id
        ));

        // Tính số dư cuối ca dự kiến
        $opening_balance = floatval($shift['opening_balance']);
        $closing_balance = $opening_balance + floatval($sales_revenue) + floatval($total_receipts) - floatval($total_payments);

        // Cập nhật ca
        $result = $wpdb->update(
            $table,
            [
                'sales_revenue'     => $sales_revenue,
                'total_receipts'    => $total_receipts,
                'total_payments'    => $total_payments,
                'closing_balance'   => $closing_balance,
                'actual_balance'    => $actual_balance,
                'difference_reason' => $difference_reason,
                'status'            => 'closed',
                'handover_to'       => $handover_to_id,
                'handover_to_name'  => $handover_to_name,
                'handover_method'   => $handover_method,
                'note'              => $note,
                'end_time'          => current_time('mysql'),
            ],
            ['id' => $shift_id],
            ['%f', '%f', '%f', '%f', '%f', '%s', '%s', '%d', '%s', '%s', '%s', '%s'],
            ['%d']
        );

        if ($result === false) {
            throw new Exception('Không thể kết ca: ' . $wpdb->last_error);
        }

        return new WP_REST_Response([
            'success' => true,
            'message' => 'Đã kết ca thành công',
            'data'    => [
                'closing_balance' => $closing_balance,
                'actual_balance'  => $actual_balance,
                'difference'      => $actual_balance - $closing_balance
            ]
        ], 200);
    } catch (Exception $e) {
        return new WP_Error('close_failed', 'Lỗi khi kết ca: ' . $e->getMessage(), ['status' => 500]);
    }
}

/**
 * Lấy danh sách phiếu thu/chi trong ca
 */
function checkin_mkt192_get_cash_shift_transactions(WP_REST_Request $request) {
    global $wpdb;
    $shift_id = intval($request->get_param('id'));
    $table    = $wpdb->prefix . 'checkin_mkt192_cash_transactions';

    try {
        $transactions = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table WHERE shift_id = %d ORDER BY created_at DESC",
            $shift_id
        ), ARRAY_A);

        return new WP_REST_Response(['success' => true, 'data' => $transactions], 200);
    } catch (Exception $e) {
        return new WP_Error('fetch_failed', 'Lỗi khi lấy phiếu thu/chi: ' . $e->getMessage(), ['status' => 500]);
    }
}

/**
 * Tạo phiếu thu/chi mới
 */
function checkin_mkt192_create_cash_transaction(WP_REST_Request $request) {
    global $wpdb;
    $shift_id     = intval($request->get_param('id'));
    $data         = $request->get_json_params();
    $current_user = wp_get_current_user();

    $shifts_table       = $wpdb->prefix . 'checkin_mkt192_cash_shifts';
    $transactions_table = $wpdb->prefix . 'checkin_mkt192_cash_transactions';

    $type   = isset($data['type']) ? sanitize_text_field($data['type']) : '';
    $amount = isset($data['amount']) ? floatval($data['amount']) : 0;
    $reason = isset($data['reason']) ? sanitize_text_field($data['reason']) : '';
    $note   = isset($data['note']) ? sanitize_textarea_field($data['note']) : '';

    // Validate
    if (!in_array($type, ['receipt', 'payment'])) {
        return new WP_Error('invalid_type', 'Loại phiếu không hợp lệ', ['status' => 400]);
    }
    if ($amount <= 0) {
        return new WP_Error('invalid_amount', 'Số tiền không hợp lệ', ['status' => 400]);
    }
    if (empty($reason)) {
        return new WP_Error('missing_reason', 'Vui lòng nhập lý do', ['status' => 400]);
    }

    try {
        // Kiểm tra ca đang mở
        $shift = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $shifts_table WHERE id = %d AND status = 'open'",
            $shift_id
        ), ARRAY_A);

        if (!$shift) {
            return new WP_Error('shift_not_open', 'Ca đã đóng hoặc không tồn tại', ['status' => 400]);
        }

        // Lấy branch_id từ shift
        $branch_id = intval($shift['branch_id'] ?? 0);

        // Tạo phiếu
        $result = $wpdb->insert(
            $transactions_table,
            [
                'shift_id'        => $shift_id,
                'branch_id'       => $branch_id,
                'type'            => $type,
                'amount'          => $amount,
                'reason'          => $reason,
                'note'            => $note,
                'created_by'      => $current_user->ID,
                'created_by_name' => $current_user->display_name,
                'created_at'      => current_time('mysql'),
            ],
            ['%d', '%d', '%s', '%f', '%s', '%s', '%d', '%s', '%s']
        );

        if ($result === false) {
            throw new Exception('Không thể tạo phiếu: ' . $wpdb->last_error);
        }

        $transaction_id = $wpdb->insert_id;

        // Cập nhật tổng thu/chi trong ca
        if ($type === 'receipt') {
            $wpdb->query($wpdb->prepare(
                "UPDATE $shifts_table SET total_receipts = total_receipts + %f WHERE id = %d",
                $amount, $shift_id
            ));
        } else {
            $wpdb->query($wpdb->prepare(
                "UPDATE $shifts_table SET total_payments = total_payments + %f WHERE id = %d",
                $amount, $shift_id
            ));
        }

        $new_transaction = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $transactions_table WHERE id = %d",
            $transaction_id
        ), ARRAY_A);

        return new WP_REST_Response(['success' => true, 'data' => $new_transaction, 'message' => 'Đã tạo phiếu thành công'], 200);
    } catch (Exception $e) {
        return new WP_Error('create_failed', 'Lỗi khi tạo phiếu: ' . $e->getMessage(), ['status' => 500]);
    }
}

/**
 * Xóa phiếu thu/chi
 */
function checkin_mkt192_delete_cash_transaction(WP_REST_Request $request) {
    global $wpdb;
    $transaction_id = intval($request->get_param('id'));

    $shifts_table       = $wpdb->prefix . 'checkin_mkt192_cash_shifts';
    $transactions_table = $wpdb->prefix . 'checkin_mkt192_cash_transactions';

    try {
        // Lấy thông tin phiếu
        $transaction = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $transactions_table WHERE id = %d",
            $transaction_id
        ), ARRAY_A);

        if (!$transaction) {
            return new WP_Error('not_found', 'Không tìm thấy phiếu', ['status' => 404]);
        }

        // Kiểm tra ca còn mở không
        $shift = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $shifts_table WHERE id = %d",
            $transaction['shift_id']
        ), ARRAY_A);

        if (!$shift || $shift['status'] !== 'open') {
            return new WP_Error('shift_closed', 'Không thể xóa phiếu trong ca đã đóng', ['status' => 400]);
        }

        // Xóa phiếu
        $result = $wpdb->delete($transactions_table, ['id' => $transaction_id], ['%d']);

        if ($result === false) {
            throw new Exception('Không thể xóa phiếu: ' . $wpdb->last_error);
        }

        // Cập nhật tổng thu/chi trong ca
        $amount = floatval($transaction['amount']);
        if ($transaction['type'] === 'receipt') {
            $wpdb->query($wpdb->prepare(
                "UPDATE $shifts_table SET total_receipts = total_receipts - %f WHERE id = %d",
                $amount, $transaction['shift_id']
            ));
        } else {
            $wpdb->query($wpdb->prepare(
                "UPDATE $shifts_table SET total_payments = total_payments - %f WHERE id = %d",
                $amount, $transaction['shift_id']
            ));
        }

        return new WP_REST_Response(['success' => true, 'message' => 'Đã xóa phiếu thành công'], 200);
    } catch (Exception $e) {
        return new WP_Error('delete_failed', 'Lỗi khi xóa phiếu: ' . $e->getMessage(), ['status' => 500]);
    }
}

/**
 * Lấy lịch sử ca
 */
function checkin_mkt192_get_cash_shift_history(WP_REST_Request $request) {
    global $wpdb;
    $filter          = sanitize_text_field($request->get_param('filter') ?: 'today');
    $current_user_id = get_current_user_id();
    $table           = $wpdb->prefix . 'checkin_mkt192_cash_shifts';
    $branch_id       = intval($request->get_param('branch_id') ?: 0);

    // Xác định khoảng thời gian - sử dụng timezone của WordPress
    $wp_timezone = wp_timezone();
    $now_dt      = new DateTime('now', $wp_timezone);
    $now         = $now_dt->format('Y-m-d H:i:s');

    switch ($filter) {
        case 'today':
            $start_dt = new DateTime('today', $wp_timezone);
            $end_dt   = new DateTime('tomorrow', $wp_timezone);
            $end_dt->modify('-1 second');
            break;
        case 'yesterday':
            $start_dt = new DateTime('yesterday', $wp_timezone);
            $end_dt   = new DateTime('today', $wp_timezone);
            $end_dt->modify('-1 second');
            break;
        case 'thisWeek':
            $start_dt = new DateTime('monday this week', $wp_timezone);
            $end_dt   = new DateTime('tomorrow', $wp_timezone);
            $end_dt->modify('-1 second');
            break;
        case 'thisMonth':
            $start_dt = new DateTime('first day of this month', $wp_timezone);
            $start_dt->setTime(0, 0, 0);
            $end_dt   = new DateTime('tomorrow', $wp_timezone);
            $end_dt->modify('-1 second');
            break;
        default:
            $start_dt = new DateTime('today', $wp_timezone);
            $end_dt   = new DateTime('tomorrow', $wp_timezone);
            $end_dt->modify('-1 second');
    }

    $start_date = $start_dt->format('Y-m-d H:i:s');
    $end_date   = $end_dt->format('Y-m-d H:i:s');

    // Debug log
    error_log("[CashShift] get_cash_shift_history - filter: $filter, start_date: $start_date, end_date: $end_date, now: $now");

    try {
        // Kiểm tra quyền xem tất cả (Quản lý/Admin)
        $user         = wp_get_current_user();
        $can_view_all = in_array('administrator', (array) $user->roles) ||
                        user_can($user, 'manage_options')               ||
                        checkin_mkt192_user_has_permission($current_user_id, 'cash_shift.view_all');

        $query  = "SELECT * FROM $table WHERE start_time BETWEEN %s AND %s";
        $params = [$start_date, $end_date];

        // Nếu không có quyền xem tất cả, chỉ xem của mình
        if (!$can_view_all) {
            $query .= ' AND staff_id = %d';
            $params[] = $current_user_id;
        }

        if ($branch_id > 0) {
            $query .= ' AND branch_id = %d';
            $params[] = $branch_id;
        }

        $query .= ' ORDER BY start_time DESC LIMIT 50';

        $shifts = $wpdb->get_results($wpdb->prepare($query, $params), ARRAY_A);

        // Kiểm tra chế độ đa chi nhánh
        $multi_branch_enabled = get_option('checkin_branch_mode_enabled', '0') === '1';

        // Tính doanh số realtime cho mỗi ca
        $invoices_table = $wpdb->prefix . 'checkin_mkt192_invoices_data';
        foreach ($shifts as &$shift) {
            // ✅ FIXED: Sử dụng sales_start_time nếu có (khi gộp doanh số trước mở ca)
            $shift_start    = !empty($shift['sales_start_time']) ? $shift['sales_start_time'] : $shift['start_time'];
            $shift_end      = $shift['status'] === 'open' ? current_time('mysql') : ($shift['end_time'] ?: current_time('mysql'));
            $shift_branch   = intval($shift['branch_id'] ?? 0);

            // Branch filter cho invoices
            $branch_filter = '';
            if ($multi_branch_enabled && $shift_branch > 0) {
                $branch_filter = $wpdb->prepare(' AND branch_id = %d', $shift_branch);
            }

            // ✅ FIXED: Dùng paid_at để tính doanh số ca
            // paid_at chỉ được set 1 lần khi thanh toán, không thay đổi khi sửa hóa đơn sau này

            // Doanh số tiền mặt
            $cash_revenue = $wpdb->get_var($wpdb->prepare(
                "SELECT COALESCE(SUM(total), 0) FROM $invoices_table
                 WHERE paid_at >= %s AND paid_at <= %s
                 AND payment_method = 'cash' AND status = 'paid'" . $branch_filter,
                $shift_start, $shift_end
            ));

            // Lấy phần tiền mặt từ thanh toán kết hợp
            $combined_rows = $wpdb->get_results($wpdb->prepare(
                "SELECT combined_payment_details FROM $invoices_table
                 WHERE paid_at >= %s AND paid_at <= %s
                 AND payment_method = 'combined'
                 AND status = 'paid'" . $branch_filter,
                $shift_start, $shift_end
            ), ARRAY_A);

            $combined_cash     = 0;
            $combined_transfer = 0;
            if (!empty($combined_rows)) {
                foreach ($combined_rows as $row) {
                    if (!empty($row['combined_payment_details'])) {
                        $details = json_decode($row['combined_payment_details'], true);
                        if (is_array($details)) {
                            $combined_cash     += floatval($details['cash'] ?? 0);
                            $combined_transfer += floatval($details['bank'] ?? 0);
                        }
                    }
                }
            }

            $cash_revenue = floatval($cash_revenue) + $combined_cash;

            // Số hóa đơn tiền mặt
            $cash_invoice_count = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM $invoices_table
                 WHERE paid_at >= %s AND paid_at <= %s
                 AND payment_method = 'cash' AND status = 'paid'" . $branch_filter,
                $shift_start, $shift_end
            ));

            // Doanh số chuyển khoản
            $transfer_revenue = $wpdb->get_var($wpdb->prepare(
                "SELECT COALESCE(SUM(total), 0) FROM $invoices_table
                 WHERE paid_at >= %s AND paid_at <= %s
                 AND payment_method IN ('bank', 'momo', 'zalopay') AND status = 'paid'" . $branch_filter,
                $shift_start, $shift_end
            ));

            $transfer_revenue = floatval($transfer_revenue) + $combined_transfer;

            // Số hóa đơn chuyển khoản
            $transfer_invoice_count = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM $invoices_table
                 WHERE paid_at >= %s AND paid_at <= %s
                 AND payment_method IN ('bank', 'momo', 'zalopay') AND status = 'paid'" . $branch_filter,
                $shift_start, $shift_end
            ));

            // Số hóa đơn kết hợp
            $combined_invoice_count = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM $invoices_table
                 WHERE paid_at >= %s AND paid_at <= %s
                 AND payment_method = 'combined' AND status = 'paid'" . $branch_filter,
                $shift_start, $shift_end
            ));

            $shift['cash_revenue']           = floatval($cash_revenue);
            $shift['cash_invoice_count']     = intval($cash_invoice_count);
            $shift['transfer_revenue']       = floatval($transfer_revenue);
            $shift['transfer_invoice_count'] = intval($transfer_invoice_count);
            $shift['combined_invoice_count'] = intval($combined_invoice_count);
            $shift['total_revenue']          = floatval($cash_revenue)     + floatval($transfer_revenue);
            $shift['invoice_count']          = intval($cash_invoice_count) + intval($transfer_invoice_count) + intval($combined_invoice_count);
        }

        return new WP_REST_Response(['success' => true, 'data' => $shifts], 200);
    } catch (Exception $e) {
        return new WP_Error('fetch_failed', 'Lỗi khi lấy lịch sử ca: ' . $e->getMessage(), ['status' => 500]);
    }
}

/**
 * Chi tiết ca
 */
function checkin_mkt192_get_cash_shift_detail(WP_REST_Request $request) {
    global $wpdb;
    $shift_id           = intval($request->get_param('id'));
    $shifts_table       = $wpdb->prefix . 'checkin_mkt192_cash_shifts';
    $transactions_table = $wpdb->prefix . 'checkin_mkt192_cash_transactions';

    try {
        $shift = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $shifts_table WHERE id = %d",
            $shift_id
        ), ARRAY_A);

        if (!$shift) {
            return new WP_Error('not_found', 'Không tìm thấy ca', ['status' => 404]);
        }

        // Lấy danh sách phiếu thu/chi
        $transactions = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $transactions_table WHERE shift_id = %d ORDER BY created_at DESC",
            $shift_id
        ), ARRAY_A);

        $shift['transactions'] = $transactions;

        // Tính doanh số realtime
        $invoices_table = $wpdb->prefix . 'checkin_mkt192_invoices_data';
        // ✅ FIXED: Sử dụng sales_start_time nếu có (khi gộp doanh số trước mở ca)
        $shift_start    = !empty($shift['sales_start_time']) ? $shift['sales_start_time'] : $shift['start_time'];
        $shift_end      = $shift['status'] === 'open' ? current_time('mysql') : ($shift['end_time'] ?: current_time('mysql'));
        $shift_branch   = intval($shift['branch_id'] ?? 0);

        // Kiểm tra chế độ đa chi nhánh
        $multi_branch_enabled = get_option('checkin_branch_mode_enabled', '0') === '1';
        $branch_filter        = '';
        if ($multi_branch_enabled && $shift_branch > 0) {
            $branch_filter = $wpdb->prepare(' AND branch_id = %d', $shift_branch);
        }

        // ✅ FIXED: Dùng paid_at để tính doanh số ca

        // Doanh số tiền mặt
        $cash_revenue = $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(total), 0) FROM $invoices_table
             WHERE paid_at >= %s AND paid_at <= %s
             AND payment_method = 'cash' AND status = 'paid'" . $branch_filter,
            $shift_start, $shift_end
        ));

        // Lấy phần tiền mặt từ thanh toán kết hợp
        $combined_rows_detail = $wpdb->get_results($wpdb->prepare(
            "SELECT combined_payment_details FROM $invoices_table
             WHERE paid_at >= %s AND paid_at <= %s
             AND payment_method = 'combined'
             AND status = 'paid'" . $branch_filter,
            $shift_start, $shift_end
        ), ARRAY_A);

        $combined_cash_detail     = 0;
        $combined_transfer_detail = 0;
        if (!empty($combined_rows_detail)) {
            foreach ($combined_rows_detail as $row) {
                if (!empty($row['combined_payment_details'])) {
                    $details = json_decode($row['combined_payment_details'], true);
                    if (is_array($details)) {
                        $combined_cash_detail     += floatval($details['cash'] ?? 0);
                        $combined_transfer_detail += floatval($details['bank'] ?? 0);
                    }
                }
            }
        }

        $cash_revenue = floatval($cash_revenue) + $combined_cash_detail;

        // Số hóa đơn tiền mặt
        $cash_invoice_count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $invoices_table
             WHERE paid_at >= %s AND paid_at <= %s
             AND payment_method = 'cash' AND status = 'paid'" . $branch_filter,
            $shift_start, $shift_end
        ));

        // Doanh số chuyển khoản
        $transfer_revenue = $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(total), 0) FROM $invoices_table
             WHERE paid_at >= %s AND paid_at <= %s
             AND payment_method IN ('bank', 'momo', 'zalopay') AND status = 'paid'" . $branch_filter,
            $shift_start, $shift_end
        ));

        $transfer_revenue = floatval($transfer_revenue) + $combined_transfer_detail;

        // Số hóa đơn chuyển khoản
        $transfer_invoice_count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $invoices_table
             WHERE paid_at >= %s AND paid_at <= %s
             AND payment_method IN ('bank', 'momo', 'zalopay') AND status = 'paid'" . $branch_filter,
            $shift_start, $shift_end
        ));

        // Số hóa đơn kết hợp
        $combined_invoice_count_detail = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $invoices_table
             WHERE paid_at >= %s AND paid_at <= %s
             AND payment_method = 'combined' AND status = 'paid'" . $branch_filter,
            $shift_start, $shift_end
        ));

        $shift['cash_revenue']           = floatval($cash_revenue);
        $shift['cash_invoice_count']     = intval($cash_invoice_count);
        $shift['transfer_revenue']       = floatval($transfer_revenue);
        $shift['transfer_invoice_count'] = intval($transfer_invoice_count);
        $shift['combined_invoice_count'] = intval($combined_invoice_count_detail);
        $shift['total_revenue']          = floatval($cash_revenue)     + floatval($transfer_revenue);
        $shift['invoice_count']          = intval($cash_invoice_count) + intval($transfer_invoice_count) + intval($combined_invoice_count_detail);

        return new WP_REST_Response(['success' => true, 'data' => $shift], 200);
    } catch (Exception $e) {
        return new WP_Error('fetch_failed', 'Lỗi khi lấy chi tiết ca: ' . $e->getMessage(), ['status' => 500]);
    }
}

/**
 * Xóa lịch sử ca làm việc
 * Chỉ cho phép user có quyền shift.delete_history
 */
function checkin_mkt192_delete_cash_shift(WP_REST_Request $request) {
    global $wpdb;
    $shift_id           = intval($request->get_param('id'));
    $shifts_table       = $wpdb->prefix . 'checkin_mkt192_cash_shifts';
    $transactions_table = $wpdb->prefix . 'checkin_mkt192_cash_transactions';

    try {
        // Check if shift exists
        $shift = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $shifts_table WHERE id = %d",
            $shift_id
        ), ARRAY_A);

        if (!$shift) {
            return new WP_Error('not_found', 'Không tìm thấy ca', ['status' => 404]);
        }

        // Start transaction
        $wpdb->query('START TRANSACTION');

        // Delete all transactions for this shift first
        $wpdb->delete($transactions_table, ['shift_id' => $shift_id], ['%d']);

        // Delete the shift
        $deleted = $wpdb->delete($shifts_table, ['id' => $shift_id], ['%d']);

        if ($deleted === false) {
            $wpdb->query('ROLLBACK');
            return new WP_Error('delete_failed', 'Lỗi xóa ca: ' . $wpdb->last_error, ['status' => 500]);
        }

        $wpdb->query('COMMIT');

        // Log the deletion
        checkin_mkt192_log_error('cash_shift', sprintf(
            'Shift #%d deleted by user #%d (staff: %s, branch: %d, opened: %s)',
            $shift_id,
            get_current_user_id(),
            $shift['staff_id']   ?? 'N/A',
            $shift['branch_id']  ?? 0,
            $shift['start_time'] ?? 'N/A'
        ));

        return new WP_REST_Response([
            'success' => true,
            'message' => 'Đã xóa ca thành công'
        ], 200);

    } catch (Exception $e) {
        $wpdb->query('ROLLBACK');
        return new WP_Error('delete_failed', 'Lỗi khi xóa ca: ' . $e->getMessage(), ['status' => 500]);
    }
}

/**
 * Lấy doanh số realtime trong ca đang mở
 */
function checkin_mkt192_get_cash_shift_sales(WP_REST_Request $request) {
    global $wpdb;
    $shift_id       = intval($request->get_param('id'));
    $shifts_table   = $wpdb->prefix . 'checkin_mkt192_cash_shifts';
    $invoices_table = $wpdb->prefix . 'checkin_mkt192_invoices_data';

    try {
        // Lấy thông tin ca
        $shift = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $shifts_table WHERE id = %d",
            $shift_id
        ), ARRAY_A);

        if (!$shift) {
            return new WP_Error('not_found', 'Không tìm thấy ca', ['status' => 404]);
        }

        // ✅ FIXED: Sử dụng sales_start_time nếu có (khi gộp doanh số trước mở ca)
        // Ngược lại dùng start_time của ca
        $start_time = !empty($shift['sales_start_time']) ? $shift['sales_start_time'] : $shift['start_time'];
        $end_time   = $shift['status'] === 'open' ? current_time('mysql') : $shift['end_time'];
        $branch_id  = intval($shift['branch_id'] ?? 0);

        error_log('[CashShift] get_sales - shift_id: ' . $shift_id);
        error_log('[CashShift] get_sales - sales_start_time: ' . ($shift['sales_start_time'] ?: 'NULL'));
        error_log('[CashShift] get_sales - using start_time: ' . $start_time);

        // Kiểm tra chế độ đa chi nhánh
        $multi_branch_enabled = get_option('checkin_branch_mode_enabled', '0') === '1';
        $branch_filter        = '';
        if ($multi_branch_enabled && $branch_id > 0) {
            $branch_filter = $wpdb->prepare(' AND branch_id = %d', $branch_id);
        }

        // ✅ FIXED: Dùng paid_at để tính doanh số ca

        // Lấy doanh số tiền mặt (bao gồm phần tiền mặt từ thanh toán kết hợp)
        $cash_revenue = $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(total), 0) FROM $invoices_table
             WHERE paid_at >= %s AND paid_at <= %s
             AND payment_method = 'cash'
             AND status = 'paid'" . $branch_filter,
            $start_time, $end_time
        ));

        // Lấy phần tiền mặt từ thanh toán kết hợp
        $combined_cash = $wpdb->get_results($wpdb->prepare(
            "SELECT combined_payment_details FROM $invoices_table
             WHERE paid_at >= %s AND paid_at <= %s
             AND payment_method = 'combined'
             AND status = 'paid'" . $branch_filter,
            $start_time, $end_time
        ), ARRAY_A);

        $combined_cash_total     = 0;
        $combined_transfer_total = 0;
        if (!empty($combined_cash)) {
            foreach ($combined_cash as $row) {
                if (!empty($row['combined_payment_details'])) {
                    $details = json_decode($row['combined_payment_details'], true);
                    if (is_array($details)) {
                        $combined_cash_total     += floatval($details['cash'] ?? 0);
                        $combined_transfer_total += floatval($details['bank'] ?? 0);
                    }
                }
            }
        }

        $cash_revenue = floatval($cash_revenue) + $combined_cash_total;

        // Số hóa đơn tiền mặt
        $cash_invoice_count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $invoices_table
             WHERE paid_at >= %s AND paid_at <= %s
             AND payment_method = 'cash'
             AND status = 'paid'" . $branch_filter,
            $start_time, $end_time
        ));

        // Lấy doanh số chuyển khoản (bank, momo, zalopay) + phần chuyển khoản từ kết hợp
        $transfer_revenue = $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(total), 0) FROM $invoices_table
             WHERE paid_at >= %s AND paid_at <= %s
             AND payment_method IN ('bank', 'momo', 'zalopay')
             AND status = 'paid'" . $branch_filter,
            $start_time, $end_time
        ));

        $transfer_revenue = floatval($transfer_revenue) + $combined_transfer_total;

        // Số hóa đơn chuyển khoản
        $transfer_invoice_count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $invoices_table
             WHERE paid_at >= %s AND paid_at <= %s
             AND payment_method IN ('bank', 'momo', 'zalopay')
             AND status = 'paid'" . $branch_filter,
            $start_time, $end_time
        ));

        // Số hóa đơn kết hợp
        $combined_invoice_count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $invoices_table
             WHERE paid_at >= %s AND paid_at <= %s
             AND payment_method = 'combined'
             AND status = 'paid'" . $branch_filter,
            $start_time, $end_time
        ));

        // Lấy tổng tips tiền mặt
        $cash_tips = $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(tips), 0) FROM $invoices_table
             WHERE paid_at >= %s AND paid_at <= %s
             AND payment_method = 'cash'
             AND status = 'paid'" . $branch_filter,
            $start_time, $end_time
        ));

        // Lấy tổng tips chuyển khoản
        $transfer_tips = $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(tips), 0) FROM $invoices_table
             WHERE paid_at >= %s AND paid_at <= %s
             AND payment_method IN ('bank', 'momo', 'zalopay')
             AND status = 'paid'" . $branch_filter,
            $start_time, $end_time
        ));

        return new WP_REST_Response([
            'success' => true,
            'data'    => [
                'cash_revenue'           => floatval($cash_revenue),
                'cash_invoice_count'     => intval($cash_invoice_count),
                'transfer_revenue'       => floatval($transfer_revenue),
                'transfer_invoice_count' => intval($transfer_invoice_count),
                'combined_invoice_count' => intval($combined_invoice_count),
                'total_revenue'          => floatval($cash_revenue) + floatval($transfer_revenue),
                'cash_tips'              => floatval($cash_tips),
                'transfer_tips'          => floatval($transfer_tips),
                'total_tips'             => floatval($cash_tips)        + floatval($transfer_tips),
                'invoice_count'          => intval($cash_invoice_count) + intval($transfer_invoice_count) + intval($combined_invoice_count),
                'start_time'             => $start_time,
                'end_time'               => $end_time
            ]
        ], 200);
    } catch (Exception $e) {
        return new WP_Error('fetch_failed', 'Lỗi khi lấy doanh số: ' . $e->getMessage(), ['status' => 500]);
    }
}

/**
 * Lấy doanh số trong ngày trước khi mở ca
 * Dùng để hiển thị khi thu ngân mở ca mới và quyết định có gộp doanh số hay không
 */
function checkin_mkt192_get_pre_open_sales(WP_REST_Request $request) {
    global $wpdb;
    $invoices_table = $wpdb->prefix . 'checkin_mkt192_invoices_data';
    $shifts_table   = $wpdb->prefix . 'checkin_mkt192_cash_shifts';

    // Lấy branch_id từ request hoặc cookie
    $branch_id = intval($request->get_param('branch_id') ?: 0);
    if (!$branch_id) {
        $branch_id = isset($_COOKIE['checkinBranchId']) ? intval($_COOKIE['checkinBranchId']) : 0;
    }

    // Kiểm tra chế độ đa chi nhánh
    $multi_branch_enabled = get_option('checkin_branch_mode_enabled', '0') === '1';
    $branch_filter        = '';
    if ($multi_branch_enabled && $branch_id > 0) {
        $branch_filter = $wpdb->prepare(' AND branch_id = %d', $branch_id);
    }

    try {
        // Lấy thời gian bắt đầu ngày hôm nay (00:00:00)
        $today_start = date('Y-m-d 00:00:00', strtotime(current_time('mysql')));
        $now         = current_time('mysql');

        // Tìm ca cuối cùng đã đóng trong ngày (nếu có)
        $last_closed_shift = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $shifts_table
             WHERE status IN ('closed', 'handover_completed')
             AND DATE(start_time) = DATE(%s)
             " . ($multi_branch_enabled && $branch_id > 0 ? ' AND branch_id = %d' : '') . '
             ORDER BY end_time DESC LIMIT 1',
            $multi_branch_enabled && $branch_id > 0 ? [$now, $branch_id] : [$now]
        ), ARRAY_A);

        // Thời gian bắt đầu tính doanh số: sau ca cuối cùng đóng hoặc từ đầu ngày
        $start_time = $last_closed_shift ? $last_closed_shift['end_time'] : $today_start;

        // === OPTIMIZED: Gộp tất cả thống kê invoice vào 1 query duy nhất ===
        // ✅ FIXED: Dùng paid_at để tính doanh số
        $invoice_stats = $wpdb->get_row($wpdb->prepare(
            "SELECT
                -- Tiền mặt
                SUM(CASE WHEN payment_method = 'cash' THEN total ELSE 0 END) as cash_revenue,
                SUM(CASE WHEN payment_method = 'cash' THEN tips ELSE 0 END) as cash_tips,
                SUM(CASE WHEN payment_method = 'cash' THEN 1 ELSE 0 END) as cash_count,
                -- Chuyển khoản
                SUM(CASE WHEN payment_method IN ('bank', 'momo', 'zalopay') THEN total ELSE 0 END) as transfer_revenue,
                SUM(CASE WHEN payment_method IN ('bank', 'momo', 'zalopay') THEN tips ELSE 0 END) as transfer_tips,
                SUM(CASE WHEN payment_method IN ('bank', 'momo', 'zalopay') THEN 1 ELSE 0 END) as transfer_count,
                -- Combined payment details (lấy ra để parse riêng)
                GROUP_CONCAT(CASE WHEN payment_method = 'combined' THEN combined_payment_details ELSE NULL END SEPARATOR '|||') as combined_details
            FROM $invoices_table
            WHERE status = 'paid'
            AND paid_at >= %s
            AND paid_at <= %s" . $branch_filter,
            $start_time, $now
        ));

        $cash_revenue           = floatval($invoice_stats->cash_revenue ?? 0);
        $cash_tips              = floatval($invoice_stats->cash_tips ?? 0);
        $cash_invoice_count     = intval($invoice_stats->cash_count ?? 0);
        $transfer_revenue       = floatval($invoice_stats->transfer_revenue ?? 0);
        $transfer_tips          = floatval($invoice_stats->transfer_tips ?? 0);
        $transfer_invoice_count = intval($invoice_stats->transfer_count ?? 0);

        // Parse combined payment details
        if (!empty($invoice_stats->combined_details)) {
            $combined_parts = explode('|||', $invoice_stats->combined_details);
            foreach ($combined_parts as $json) {
                if (!empty($json)) {
                    $details = json_decode($json, true);
                    if (is_array($details)) {
                        $cash_revenue     += floatval($details['cash'] ?? 0);
                        $transfer_revenue += floatval($details['bank'] ?? 0);
                    }
                }
            }
        }

        $has_pre_open_sales = ($cash_revenue + $transfer_revenue) > 0;

        // Tính số dư CK của ca trước (để gợi ý cho ca mới)
        $last_shift_transfer_balance = 0;
        if ($last_closed_shift) {
            // Số dư CK cuối ca = Số dư CK đầu ca + Doanh số CK trong ca
            $last_opening_transfer = floatval($last_closed_shift['opening_transfer_balance'] ?? 0);
            $last_transfer_revenue = floatval($last_closed_shift['transfer_revenue'] ?? 0);

            // Nếu không có transfer_revenue trong shift (cột không tồn tại), tính lại từ invoices
            if ($last_transfer_revenue == 0) {
                // ✅ FIXED: Sử dụng sales_start_time nếu có (khi gộp doanh số trước mở ca)
                $last_shift_start  = !empty($last_closed_shift['sales_start_time'])
                    ? $last_closed_shift['sales_start_time']
                    : $last_closed_shift['start_time'];
                $last_shift_end    = $last_closed_shift['end_time'];
                $last_shift_branch = intval($last_closed_shift['branch_id'] ?? 0);

                $last_branch_filter = '';
                if ($multi_branch_enabled && $last_shift_branch > 0) {
                    $last_branch_filter = $wpdb->prepare(' AND branch_id = %d', $last_shift_branch);
                }

                // Lấy doanh số CK thuần (không bao gồm combined)
                $last_transfer_revenue = $wpdb->get_var($wpdb->prepare(
                    "SELECT COALESCE(SUM(total), 0) FROM $invoices_table
                     WHERE paid_at >= %s AND paid_at <= %s
                     AND payment_method IN ('bank', 'momo', 'zalopay')
                     AND status = 'paid'" . $last_branch_filter,
                    $last_shift_start, $last_shift_end
                ));

                // Cộng thêm phần CK từ thanh toán kết hợp (combined)
                $combined_transfer = 0;
                $combined_rows     = $wpdb->get_results($wpdb->prepare(
                    "SELECT combined_payment_details FROM $invoices_table
                     WHERE paid_at >= %s AND paid_at <= %s
                     AND payment_method = 'combined'
                     AND status = 'paid'" . $last_branch_filter,
                    $last_shift_start, $last_shift_end
                ), ARRAY_A);

                if (!empty($combined_rows)) {
                    foreach ($combined_rows as $row) {
                        if (!empty($row['combined_payment_details'])) {
                            $details = json_decode($row['combined_payment_details'], true);
                            if (is_array($details)) {
                                $combined_transfer += floatval($details['bank'] ?? 0);
                            }
                        }
                    }
                }

                $last_transfer_revenue = floatval($last_transfer_revenue) + $combined_transfer;
            }

            $last_shift_transfer_balance = $last_opening_transfer + floatval($last_transfer_revenue);
        }

        return new WP_REST_Response([
            'success' => true,
            'data'    => [
                'has_pre_open_sales'            => $has_pre_open_sales,
                'start_time'                    => $start_time,
                'end_time'                      => $now,
                'last_closed_shift'             => $last_closed_shift,
                'last_shift_transfer_balance'   => floatval($last_shift_transfer_balance),
                'cash_revenue'                  => floatval($cash_revenue),
                'cash_invoice_count'            => intval($cash_invoice_count),
                'transfer_revenue'              => floatval($transfer_revenue),
                'transfer_invoice_count'        => intval($transfer_invoice_count),
                'total_revenue'                 => floatval($cash_revenue) + floatval($transfer_revenue),
                'cash_tips'                     => floatval($cash_tips),
                'transfer_tips'                 => floatval($transfer_tips),
                'total_tips'                    => floatval($cash_tips)        + floatval($transfer_tips),
                'invoice_count'                 => intval($cash_invoice_count) + intval($transfer_invoice_count),
            ]
        ], 200);
    } catch (Exception $e) {
        return new WP_Error('fetch_failed', 'Lỗi khi lấy doanh số: ' . $e->getMessage(), ['status' => 500]);
    }
}

/**
 * Helper: Kiểm tra quyền user
 */
function checkin_mkt192_user_has_permission($user_id, $permission) {
    // Kiểm tra trong bảng user_permissions nếu có
    global $wpdb;
    $table = $wpdb->prefix . 'checkin_mkt192_user_permissions';

    // Check if table exists
    if ($wpdb->get_var("SHOW TABLES LIKE '$table'") !== $table) {
        return false;
    }

    $has_permission = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $table WHERE user_id = %d AND permission = %s",
        $user_id, $permission
    ));

    return $has_permission > 0;
}

/**
 * Lấy tổng phiếu chi theo khoảng thời gian (dùng cho báo cáo)
 */
function checkin_mkt192_get_total_expenses(WP_REST_Request $request) {
    global $wpdb;
    $filter    = sanitize_text_field($request->get_param('filter') ?: 'today');
    $branch_id = intval($request->get_param('branch_id') ?: 0);

    // Lấy start_date và end_date từ request (cho filter custom)
    $custom_start = sanitize_text_field($request->get_param('start_date') ?: '');
    $custom_end   = sanitize_text_field($request->get_param('end_date') ?: '');

    $transactions_table = $wpdb->prefix . 'checkin_mkt192_cash_transactions';

    // Xác định khoảng thời gian - sử dụng timezone của WordPress
    $wp_timezone = wp_timezone();
    $now_dt      = new DateTime('now', $wp_timezone);

    switch ($filter) {
        case 'today':
            $start_dt = new DateTime('today', $wp_timezone);
            $end_dt   = new DateTime('tomorrow', $wp_timezone);
            $end_dt->modify('-1 second');
            break;
        case 'yesterday':
            $start_dt = new DateTime('yesterday', $wp_timezone);
            $end_dt   = new DateTime('today', $wp_timezone);
            $end_dt->modify('-1 second');
            break;
        case 'thisWeek':
            $start_dt = new DateTime('monday this week', $wp_timezone);
            $end_dt   = new DateTime('tomorrow', $wp_timezone);
            $end_dt->modify('-1 second');
            break;
        case 'thisMonth':
            $start_dt = new DateTime('first day of this month', $wp_timezone);
            $start_dt->setTime(0, 0, 0);
            $end_dt   = new DateTime('tomorrow', $wp_timezone);
            $end_dt->modify('-1 second');
            break;
        case 'lastMonth':
            $start_dt = new DateTime('first day of last month', $wp_timezone);
            $start_dt->setTime(0, 0, 0);
            $end_dt   = new DateTime('last day of last month', $wp_timezone);
            $end_dt->setTime(23, 59, 59);
            break;
        case 'custom':
            if ($custom_start && $custom_end) {
                $start_dt = new DateTime($custom_start, $wp_timezone);
                $start_dt->setTime(0, 0, 0);
                $end_dt   = new DateTime($custom_end, $wp_timezone);
                $end_dt->setTime(23, 59, 59);
            } else {
                $start_dt = new DateTime('today', $wp_timezone);
                $end_dt   = new DateTime('tomorrow', $wp_timezone);
                $end_dt->modify('-1 second');
            }
            break;
        default:
            $start_dt = new DateTime('today', $wp_timezone);
            $end_dt   = new DateTime('tomorrow', $wp_timezone);
            $end_dt->modify('-1 second');
    }

    $start_date = $start_dt->format('Y-m-d H:i:s');
    $end_date   = $end_dt->format('Y-m-d H:i:s');

    try {
        // Kiểm tra bảng tồn tại
        if ($wpdb->get_var("SHOW TABLES LIKE '$transactions_table'") !== $transactions_table) {
            return new WP_REST_Response([
                'success'        => true,
                'total_expenses' => 0,
                'total_receipts' => 0,
                'message'        => 'Bảng transactions chưa được tạo'
            ], 200);
        }

        // Branch filter
        $branch_filter        = '';
        $multi_branch_enabled = get_option('checkin_branch_mode_enabled', '0') === '1';
        if ($multi_branch_enabled && $branch_id > 0) {
            $branch_filter = $wpdb->prepare(' AND branch_id = %d', $branch_id);
        }

        // Tổng phiếu chi (payment)
        $total_expenses = $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(amount), 0) FROM $transactions_table
             WHERE type = 'payment'
             AND created_at BETWEEN %s AND %s" . $branch_filter,
            $start_date, $end_date
        ));

        // Tổng phiếu thu (receipt) - để tham khảo
        $total_receipts = $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(amount), 0) FROM $transactions_table
             WHERE type = 'receipt'
             AND created_at BETWEEN %s AND %s" . $branch_filter,
            $start_date, $end_date
        ));

        return new WP_REST_Response([
            'success'        => true,
            'total_expenses' => floatval($total_expenses),
            'total_receipts' => floatval($total_receipts),
            'filter'         => $filter,
            'start_date'     => $start_date,
            'end_date'       => $end_date
        ], 200);
    } catch (Exception $e) {
        return new WP_Error('fetch_failed', 'Lỗi khi lấy tổng chi: ' . $e->getMessage(), ['status' => 500]);
    }
}
