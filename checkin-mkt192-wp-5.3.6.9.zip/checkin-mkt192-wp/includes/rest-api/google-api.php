<?php

/**
 * Google REST API Endpoints
 *
 * @package    Checkin_MKT192_WP
 * @subpackage REST_API
 * @since      5.1.1
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Register Google Settings REST API routes
 */
function checkin_register_google_api_routes() {
    // GET/POST /wp-json/vg/v1/google-settings
    register_rest_route('vg/v1', '/google-settings', [
        [
            'methods'             => 'GET',
            'callback'            => 'checkin_get_google_settings',
            'permission_callback' => function () {
                return current_user_can('manage_options');
            },
        ],
        [
            'methods'             => 'POST',
            'callback'            => 'checkin_save_google_settings',
            'permission_callback' => function () {
                return current_user_can('manage_options');
            },
        ],
    ]);
}
add_action('rest_api_init', 'checkin_register_google_api_routes');

/**
 * Get Google account settings
 *
 * @param WP_REST_Request $request
 * @return WP_REST_Response
 */
function checkin_get_google_settings($request) {
    $email    = get_option('checkin_google_account_email', '');
    $name     = get_option('checkin_google_account_name', '');
    $verified = get_option('checkin_google_account_verified', false);
    $picture  = get_option('checkin_google_account_picture', '');

    if (empty($email)) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'No Google account connected',
            'data'    => null,
        ], 200);
    }

    return new WP_REST_Response([
        'success' => true,
        'message' => 'Google account info retrieved',
        'data'    => [
            'email'          => $email,
            'name'           => $name,
            'email_verified' => $verified,
            'picture'        => $picture,
        ],
    ], 200);
}

/**
 * Save Google account settings
 *
 * @param WP_REST_Request $request
 * @return WP_REST_Response
 */
function checkin_save_google_settings($request) {
    $params = $request->get_json_params();

    // Handle clear_account flag (for reconnect)
    if (isset($params['clear_account']) && $params['clear_account']) {
        delete_option('checkin_google_account_email');
        delete_option('checkin_google_account_name');
        delete_option('checkin_google_account_verified');
        delete_option('checkin_google_account_picture');

        return new WP_REST_Response([
            'success' => true,
            'message' => 'Google account info cleared',
        ], 200);
    }

    // Validate required fields
    if (empty($params['email'])) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Email is required',
        ], 400);
    }

    // Save account info
    update_option('checkin_google_account_email', sanitize_email($params['email']));
    update_option('checkin_google_account_name', sanitize_text_field($params['name'] ?? ''));
    update_option('checkin_google_account_verified', (bool) ($params['email_verified'] ?? false));
    update_option('checkin_google_account_picture', esc_url_raw($params['picture'] ?? ''));

    return new WP_REST_Response([
        'success' => true,
        'message' => 'Google account info saved successfully',
        'data'    => [
            'email'          => $params['email'],
            'name'           => $params['name'] ?? '',
            'email_verified' => (bool) ($params['email_verified'] ?? false),
            'picture'        => $params['picture'] ?? '',
        ],
    ], 200);
}