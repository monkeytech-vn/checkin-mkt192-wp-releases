<?php

add_action('rest_api_init', function () {
    // Admin: Upload logo cửa hàng
    register_rest_route('vg/v1', '/upload-logo', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_upload_logo_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'settings.update'])
    ]);

    // Admin: Upload ảnh bìa
    register_rest_route('vg/v1', '/upload-banner', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_upload_banner_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'settings.update'])
    ]);

    // Admin: Xem thống kê dashboard
    register_rest_route('vg/v1', '/dashboard-stats', [
        'methods'             => 'GET',
        'callback'            => 'checkin_mkt192_get_dashboard_stats_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'settings.read'])
    ]);

    // Public/Staff: Xem gallery hình ảnh
    register_rest_route('vg/v1', '/gallery', [
        'methods'             => 'GET',
        'callback'            => 'get_gallery_images',
        'permission_callback' => '__return_true', // Public - gallery display
    ]);

    // Admin: Cập nhật Zalo config (require login)
    register_rest_route('vg/v1', '/update-zalo-user-domain', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_update_zalo_user_domain',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'settings.update']),
    ]);

    // System: Cập nhật Zalo config từ ngrok (require API token)
    register_rest_route('vg/v1', '/system/update-zalo-user-domain', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_update_zalo_user_domain',
        'permission_callback' => 'checkin_mkt192_check_api_permission',
    ]);
});

/**
 * API Upload logo
 */
function checkin_mkt192_upload_logo_api(WP_REST_Request $request) {
    if (!isset($_FILES['shop_logo'])) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Không có file được tải lên.'
        ], 400);
    }

    $file   = $_FILES['shop_logo'];
    $upload = wp_handle_upload($file, ['test_form' => false]);

    if (!isset($upload['error'])) {
        update_option('checkin_logo_url', esc_url_raw($upload['url']));
        return new WP_REST_Response([
            'success' => true,
            'message' => 'Logo đã được cập nhật!',
            'url'     => esc_url($upload['url']),
        ], 200);
    }

    return new WP_REST_Response([
        'success' => false,
        'message' => 'Lỗi tải logo: ' . $upload['error']
    ], 500);
}

/**
 * API Upload ảnh bìa
 */
function checkin_mkt192_upload_banner_api(WP_REST_Request $request) {
    if (!isset($_FILES['shop_banner'])) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Không có file được tải lên.'
        ], 400);
    }

    $file   = $_FILES['shop_banner'];
    $upload = wp_handle_upload($file, ['test_form' => false]);

    if (!isset($upload['error'])) {
        update_option('checkin_banner_url', esc_url_raw($upload['url']));
        return new WP_REST_Response([
            'success' => true,
            'message' => 'Ảnh bìa đã được cập nhật!',
            'url'     => esc_url($upload['url']),
        ], 200);
    }

    return new WP_REST_Response([
        'success' => false,
        'message' => 'Lỗi tải ảnh bìa: ' . $upload['error']
    ], 500);
}

/**
 * API Thống kê Dashboard
 */
function checkin_mkt192_get_dashboard_stats_api(WP_REST_Request $request) {
    global $wpdb;

    $filter    = sanitize_text_field($request->get_param('filter') ?? 'today');
    $where     = '';
    $date_cond = '';

    switch ($filter) {
        case 'today':
            $where = 'DATE(checkin_time) = CURDATE()';
            break;
        case 'yesterday':
            $where = 'DATE(checkin_time) = CURDATE() - INTERVAL 1 DAY';
            break;
        case 'this_week':
            $where = 'YEARWEEK(checkin_time, 1) = YEARWEEK(CURDATE(), 1)';
            break;
        case 'this_month':
            $where = 'MONTH(checkin_time) = MONTH(CURDATE()) AND YEAR(checkin_time) = YEAR(CURDATE())';
            break;
        case 'last_month':
            $where = 'MONTH(checkin_time) = MONTH(CURDATE() - INTERVAL 1 MONTH) AND YEAR(checkin_time) = YEAR(CURDATE() - INTERVAL 1 MONTH)';
            break;
        default:
            $where = 'DATE(checkin_time) = CURDATE()';
    }

    try {
        $table = "{$wpdb->prefix}checkin_mkt192_checkinlogs";

        $total_checkins = (int) $wpdb->get_var("SELECT COUNT(DISTINCT employee_id) FROM $table WHERE $where");

        $late_data          = $wpdb->get_row("SELECT COUNT(*) AS late_count, SUM(late_minutes) AS total_late_minutes FROM $table WHERE $where AND late_minutes > 0", ARRAY_A);
        $late_count         = (int) ($late_data['late_count'] ?? 0);
        $total_late_minutes = (int) ($late_data['total_late_minutes'] ?? 0);

        $total_penalty = (int) $wpdb->get_var("SELECT SUM(penalty_amount) FROM $table WHERE $where AND penalty_amount > 0");

        $completed       = (int) $wpdb->get_var("SELECT COUNT(*) FROM $table WHERE $where AND status = 'success'");
        $completion_rate = $total_checkins > 0 ? round(($completed / $total_checkins) * 100, 2) : 0;

        $shifts = $wpdb->get_results("SELECT shift, COUNT(*) AS count FROM $table WHERE $where GROUP BY shift", ARRAY_A);

        $status_data = $wpdb->get_results("SELECT status, COUNT(*) AS count FROM $table WHERE $where GROUP BY status", ARRAY_A);

        $late_employees = $wpdb->get_results("
            SELECT employee_id, display_name, shift, late_minutes, checkin_time, penalty_amount
            FROM $table
            WHERE $where AND late_minutes > 0
            ORDER BY checkin_time DESC
        ", ARRAY_A);

        foreach ($late_employees as &$employee) {
            $display_name = sanitize_text_field($employee['display_name']);
            $checkin_time = sanitize_text_field($employee['checkin_time']);

            $late_request = $wpdb->get_row($wpdb->prepare("
                SELECT status FROM {$wpdb->prefix}checkin_mkt192_approval_requests
                WHERE staff_name = %s
                AND request_type = 'late_early'
                AND late_early_date = DATE(%s)
                ORDER BY updated_at DESC LIMIT 1
            ", $display_name, $checkin_time), ARRAY_A);

            if ($late_request) {
                $employee['late_status'] = $late_request['status'] === 'approved' ? 'Đi trễ có phép' : $late_request['status'];
                if ($late_request['status'] === 'approved') {
                    $wpdb->update($table, ['penalty_amount' => 0], [
                        'employee_id'  => $employee['employee_id'],
                        'checkin_time' => $employee['checkin_time']
                    ]);
                    $employee['penalty_amount'] = 0;
                }
            } else {
                $employee['late_status'] = 'Đi trễ không phép';
            }
        }
        unset($employee);

        $late_trend = [];
        if ($filter === 'this_week') {
            $late_trend = $wpdb->get_results("
                SELECT DATE(checkin_time) as date, AVG(late_minutes) as avg_late
                FROM $table
                WHERE YEARWEEK(checkin_time, 1) = YEARWEEK(CURDATE(), 1)
                GROUP BY DATE(checkin_time)
            ", ARRAY_A);
        }

        return new WP_REST_Response([
            'success' => true,
            'data'    => [
                'total_checkins'     => $total_checkins,
                'late_count'         => $late_count,
                'total_late_minutes' => $total_late_minutes,
                'total_penalty'      => $total_penalty,
                'completion_rate'    => $completion_rate,
                'shifts'             => $shifts,
                'status_data'        => $status_data,
                'late_employees'     => $late_employees,
                'late_trend'         => $late_trend,
            ]
        ], 200);

    } catch (Exception $e) {
        error_log('[Dashboard Stats Error] ' . $e->getMessage());
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Lỗi hệ thống: ' . $e->getMessage()
        ], 500);
    }
}

function get_gallery_images(WP_REST_Request $request) {
    try {
        // Lấy đường dẫn thư mục ảnh
        $upload_dir         = wp_upload_dir();
        $gallery_image_dir  = $upload_dir['baseurl'] . '/checkin-mkt192-wp/home/media/';
        $gallery_image_path = $upload_dir['basedir'] . '/checkin-mkt192-wp/home/media/';

        // Debug: Ghi log đường dẫn thư mục
        error_log('Gallery image path: ' . $gallery_image_path);
        error_log('Gallery image URL: ' . $gallery_image_dir);

        // Lấy danh sách file ảnh
        $image_files = glob($gallery_image_path . '*.{jpg,png,gif}', GLOB_BRACE);
        $image_files = array_map('basename', $image_files);

        // Debug: Ghi log danh sách file ảnh
        error_log('Gallery image files found: ' . print_r($image_files, true));

        // Chuẩn bị danh sách ảnh
        $images = array_map(function ($file) use ($gallery_image_dir) {
            return [
                'url' => $gallery_image_dir . rawurlencode($file),
                'alt' => 'Gallery Image'
            ];
        }, $image_files);

        return new WP_REST_Response([
            'success' => true,
            'data'    => $images,
            'message' => 'Lấy danh sách ảnh gallery thành công'
        ], 200);
    } catch (Exception $e) {
        error_log('get_gallery_images error: ' . $e->getMessage());
        return new WP_REST_Response(['success' => false, 'message' => 'Lỗi hệ thống: ' . $e->getMessage()], 500);
    }
}

/**
 * API Cập nhật Zalo User Domain
 */
function checkin_mkt192_update_zalo_user_domain(WP_REST_Request $request) {
    $new_domain = sanitize_text_field($request['domain']);
    if (empty($new_domain)) {
        return new WP_Error('invalid_domain', __('Domain không hợp lệ', 'checkin-mkt192'), ['status' => 400]);
    }

    update_option('checkin_zalo_user_domain', $new_domain);
    return new WP_REST_Response([
        'success' => true,
        'message' => __('Đã cập nhật Zalo User Domain thành công', 'checkin-mkt192'),
        'domain'  => $new_domain,
    ], 200);
}

/**
 * Kiểm tra quyền truy cập API
 */
function checkin_mkt192_check_api_permission(WP_REST_Request $request) {
    $token          = $request->get_header('X-Checkin-API-Token');
    $expected_token = 'OwWE94Td1w12VP5BRZeo9UnqTRLOPdAP'; //Tự tạo
    if ($token === $expected_token) {
        return true;
    }
    return new WP_Error('rest_forbidden', __('Không có quyền truy cập', 'checkin-mkt192'), ['status' => 403]);
}
