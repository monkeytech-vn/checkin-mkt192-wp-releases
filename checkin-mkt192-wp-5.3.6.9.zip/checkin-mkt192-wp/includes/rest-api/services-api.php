<?php

// Register REST API endpoints for Services
add_action('rest_api_init', function () {
    // GET: Fetch all services (PUBLIC - for home page)
    register_rest_route('vg/v1', '/services', [
        'methods'             => 'GET',
        'callback'            => 'get_services',
        'permission_callback' => '__return_true' // Public endpoint for website
    ]);

    register_rest_route('vg/v1', '/service-images', [
        'methods'             => 'GET',
        'callback'            => 'get_service_images',
        'permission_callback' => '__return_true', // Public endpoint for website
    ]);

    // POST: Create a new service
    register_rest_route('vg/v1', '/services', [
        'methods'             => 'POST',
        'callback'            => 'create_service',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'services.create'])
    ]);

    // PUT: Update a service
    register_rest_route('vg/v1', '/services/(?P<service_id>[a-zA-Z0-9]+)', [
        'methods'             => 'PUT',
        'callback'            => 'update_service',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'services.update'])
    ]);

    // DELETE: Delete a service
    register_rest_route('vg/v1', '/services/(?P<service_id>[a-zA-Z0-9]+)', [
        'methods'             => 'DELETE',
        'callback'            => 'delete_service',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'services.delete'])
    ]);
});

function get_services($request) {
    global $wpdb;
    $table_name  = $wpdb->prefix . 'checkin_mkt192_service_data';
    $group_table = $wpdb->prefix . 'checkin_mkt192_service_groups';

    // Lấy branch_id parameter từ request
    // Nếu không có branch_id, trả về tất cả dịch vụ (admin mode)
    $branch_id = $request->get_param('branch_id');
    $branch_id = ($branch_id !== null && $branch_id !== '') ? intval($branch_id) : null;

    // Xây dựng WHERE clause - chỉ filter khi có branch_id cụ thể
    $where_clause = '';
    if ($branch_id !== null && $branch_id > 0) {
        $where_clause = $wpdb->prepare('WHERE s.branch_id = %d OR s.branch_id IS NULL OR s.branch_id = 0', $branch_id);
    }

    $query = "
        SELECT s.service_id,
               s.service_name,
               s.service_group_id,
               s.service_price,
               s.branch_id,
               s.sort_order,
               s.service_type,
               s.service_description,
               s.discounted_price,
               g.name AS service_group
        FROM $table_name s
        LEFT JOIN $group_table g ON s.service_group_id = g.id
        $where_clause
    ";

    $services = $wpdb->get_results($query, ARRAY_A);

    // Format lại giá
    foreach ($services as &$service) {
        if (isset($service['service_price'])) {
            $service['service_price_formatted'] = number_format((float)$service['service_price'], 0, '.', ',');
        }
        if (isset($service['discounted_price'])) {
            $service['discounted_price_formatted'] = number_format((float)$service['discounted_price'], 0, '.', ',');
        }
    }

    return rest_ensure_response([
        'success' => true,
        'data'    => $services,
    ]);
}

function get_service_images(WP_REST_Request $request) {
    global $wpdb;

    // Dữ liệu giả định, bạn có thể lấy từ cơ sở dữ liệu hoặc cấu hình
    $service_images = [
        [
            'service_name' => 'Cắt tóc',
            'image_url'    => CHECKIN_PLUGIN_URL . 'frontend/assets/images/service-section/cat-toc.jpg',
            'alt'          => 'Hình ảnh dịch vụ cắt tóc'
        ],
        [
            'service_name' => 'Cạo mặt',
            'image_url'    => CHECKIN_PLUGIN_URL . 'frontend/assets/images/service-section/cao-mat.jpg',
            'alt'          => 'Hình ảnh dịch vụ cắt tóc'
        ],
        [
            'service_name' => 'Ráy tai',
            'image_url'    => CHECKIN_PLUGIN_URL . 'frontend/assets/images/service-section/ray-tai.jpg',
            'alt'          => 'Hình ảnh dịch vụ cắt tóc'
        ],
        [
            'service_name' => 'Uốn tóc',
            'image_url'    => CHECKIN_PLUGIN_URL . 'frontend/assets/images/service-section/uon-toc.jpg',
            'alt'          => 'Hình ảnh dịch vụ uốn tóc'
        ],
        [
            'service_name' => 'Nhuộm tóc',
            'image_url'    => CHECKIN_PLUGIN_URL . 'frontend/assets/images/service-section/nhuom-toc.jpg',
            'alt'          => 'Hình ảnh dịch vụ nhuộm tóc'
        ],
        [
            'service_name' => 'Massage mặt',
            'image_url'    => CHECKIN_PLUGIN_URL . 'frontend/assets/images/service-section/massage-mat.jpg',
            'alt'          => 'Hình ảnh dịch vụ massage mặt'
        ]
    ];

    return new WP_REST_Response([
        'success' => true,
        'data'    => $service_images
    ], 200);
}

function create_service($request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'checkin_mkt192_service_data';
    $data       = $request->get_json_params();

    if (empty($data['service_name'])) {
        return new WP_Error('invalid_data', 'Tên dịch vụ là bắt buộc', ['status' => 400]);
    }

    // Tạo service_id nếu không được cung cấp
    $service_id = !empty($data['service_id']) ? sanitize_text_field($data['service_id']) : 'DV' . str_pad($wpdb->get_var("SELECT COUNT(*) FROM $table_name") + 1, 3, '0', STR_PAD_LEFT);

    // Kiểm tra service_id đã tồn tại
    $existing = $wpdb->get_var($wpdb->prepare("SELECT service_id FROM $table_name WHERE service_id = %s", $service_id));
    if ($existing) {
        return new WP_Error('duplicate_id', 'ID dịch vụ đã tồn tại', ['status' => 400]);
    }

    // Kiểm tra service_group_id nếu có
    if (!empty($data['service_group_id'])) {
        $group_table_name = $wpdb->prefix . 'checkin_mkt192_service_groups';
        $group_exists     = $wpdb->get_var($wpdb->prepare("SELECT id FROM $group_table_name WHERE id = %d", intval($data['service_group_id'])));
        if (!$group_exists) {
            return new WP_Error('invalid_group', 'Nhóm dịch vụ không tồn tại', ['status' => 400]);
        }
    }

    // Xử lý sort_order
    $sort_order = isset($data['sort_order']) && $data['sort_order'] !== '' ? intval($data['sort_order']) : null;
    if ($sort_order === null) {
        $max_sort_order = $wpdb->get_var("SELECT MAX(sort_order) FROM $table_name");
        $sort_order     = $max_sort_order !== null ? intval($max_sort_order) + 1 : 1;
    }

    // Xử lý discounted_price: gán NULL nếu giá trị là 0 hoặc rỗng
    $discounted_price = isset($data['discounted_price']) && $data['discounted_price'] !== '' && floatval($data['discounted_price']) !== 0 ? floatval($data['discounted_price']) : null;

    $branch_id = isset($data['branch_id']) ? intval($data['branch_id']) : 0;

    $result = $wpdb->insert($table_name, [
        'service_id'          => $service_id,
        'service_name'        => sanitize_text_field($data['service_name']),
        'service_group_id'    => !empty($data['service_group_id']) ? intval($data['service_group_id']) : null,
        'service_group'       => !empty($data['service_group']) ? sanitize_text_field($data['service_group']) : null,
        'service_type'        => in_array($data['service_type'], ['service', 'chemical']) ? sanitize_text_field($data['service_type']) : 'service',
        'service_price'       => floatval($data['service_price'] ?? 0),
        'service_description' => sanitize_textarea_field($data['service_description'] ?? ''),
        'sort_order'          => $sort_order,
        'discounted_price'    => $discounted_price,
        'branch_id'           => $branch_id,
    ]);

    if ($result === false) {
        error_log('Create service error: ' . $wpdb->last_error); // Debug lỗi DB
        return new WP_Error('db_error', 'Lỗi khi thêm dịch vụ: ' . $wpdb->last_error, ['status' => 500]);
    }

    return rest_ensure_response([
        'success' => true,
        'message' => 'Thêm dịch vụ thành công',
        'data'    => ['service_id' => $service_id],
    ]);
}

function update_service($request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'checkin_mkt192_service_data';
    $service_id = $request['service_id'];
    $data       = $request->get_json_params();

    $existing = $wpdb->get_var($wpdb->prepare("SELECT service_id FROM $table_name WHERE service_id = %s", $service_id));
    if (!$existing) {
        return new WP_Error('not_found', 'Không tìm thấy dịch vụ với ID này', ['status' => 404]);
    }

    if (empty($data['service_name'])) {
        return new WP_Error('invalid_data', 'Tên dịch vụ là bắt buộc', ['status' => 400]);
    }

    // Kiểm tra service_group_id nếu có
    if (!empty($data['service_group_id'])) {
        $group_table_name = $wpdb->prefix . 'checkin_mkt192_service_groups';
        $group_exists     = $wpdb->get_var($wpdb->prepare("SELECT id FROM $group_table_name WHERE id = %d", intval($data['service_group_id'])));
        if (!$group_exists) {
            return new WP_Error('invalid_group', 'Nhóm dịch vụ không tồn tại', ['status' => 400]);
        }
    }

    // Xử lý sort_order
    $sort_order = isset($data['sort_order']) && $data['sort_order'] !== '' ? intval($data['sort_order']) : null;
    if ($sort_order === null) {
        $max_sort_order = $wpdb->get_var("SELECT MAX(sort_order) FROM $table_name");
        $sort_order     = $max_sort_order !== null ? intval($max_sort_order) + 1 : 1;
    }

    // Xử lý discounted_price: gán NULL nếu giá trị là 0 hoặc rỗng
    $discounted_price = isset($data['discounted_price']) && $data['discounted_price'] !== '' && floatval($data['discounted_price']) !== 0 ? floatval($data['discounted_price']) : null;

    $branch_id = isset($data['branch_id']) ? intval($data['branch_id']) : 0;

    $result = $wpdb->update($table_name, [
        'service_name'        => sanitize_text_field($data['service_name']),
        'service_group_id'    => !empty($data['service_group_id']) ? intval($data['service_group_id']) : null,
        'service_group'       => !empty($data['service_group']) ? sanitize_text_field($data['service_group']) : null,
        'service_type'        => in_array($data['service_type'], ['service', 'chemical']) ? sanitize_text_field($data['service_type']) : 'service',
        'service_price'       => floatval($data['service_price'] ?? 0),
        'service_description' => sanitize_textarea_field($data['service_description'] ?? ''),
        'sort_order'          => $sort_order,
        'discounted_price'    => $discounted_price,
        'branch_id'           => $branch_id,
    ], ['service_id' => $service_id]);

    if ($result === false) {
        error_log('Update service error: ' . $wpdb->last_error); // Debug lỗi DB
        return new WP_Error('db_error', 'Lỗi khi cập nhật dịch vụ: ' . $wpdb->last_error, ['status' => 500]);
    }

    return rest_ensure_response([
        'success' => true,
        'message' => 'Cập nhật dịch vụ thành công',
    ]);
}

function delete_service($request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'checkin_mkt192_service_data';
    $service_id = $request['service_id'];

    $result = $wpdb->delete($table_name, ['service_id' => $service_id]);

    if ($result === false) {
        error_log('Delete service error: ' . $wpdb->last_error); // Debug lỗi DB
        return new WP_Error('db_error', 'Lỗi khi xóa dịch vụ: ' . $wpdb->last_error, ['status' => 500]);
    }

    return rest_ensure_response([
        'success' => true,
        'message' => 'Xóa dịch vụ thành công',
    ]);
}
?>
