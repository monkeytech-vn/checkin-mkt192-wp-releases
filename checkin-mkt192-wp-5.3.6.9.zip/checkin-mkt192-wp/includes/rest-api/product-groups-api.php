<?php

// Register REST API endpoints for Product Groups
add_action('rest_api_init', function () {
    // GET: Fetch all product groups (Public - for staff to see product categories)
    register_rest_route('vg/v1', '/product-groups', [
        'methods'             => 'GET',
        'callback'            => 'get_product_groups',
        'permission_callback' => '__return_true' // Public - staff need to see product groups to select products
    ]);

    // POST: Create a new product group
    register_rest_route('vg/v1', '/product-groups', [
        'methods'             => 'POST',
        'callback'            => 'create_product_group',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'product_group.create'])
    ]);

    // PUT: Update a product group
    register_rest_route('vg/v1', '/product-groups/(?P<id>\d+)', [
        'methods'             => 'PUT',
        'callback'            => 'update_product_group',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'product_group.update'])
    ]);

    // DELETE: Delete a product group
    register_rest_route('vg/v1', '/product-groups/(?P<id>\d+)', [
        'methods'             => 'DELETE',
        'callback'            => 'delete_product_group',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'product_group.delete'])
    ]);
});

function get_product_groups($request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'checkin_mkt192_product_groups';
    $groups     = $wpdb->get_results("SELECT id, group_name, group_code, description FROM $table_name", ARRAY_A);

    if ($wpdb->last_error) {
        error_log('Error fetching product groups: ' . $wpdb->last_error);
        return new WP_Error('db_error', 'Lỗi khi lấy danh sách nhóm sản phẩm: ' . $wpdb->last_error, ['status' => 500]);
    }

    $groups = array_map(function($group) {
        return [
            'id'                => $group['id'],
            'group_code'        => $group['group_code'], // Sử dụng group_code làm tên hiển thị
            'group_name'        => $group['group_name'],
            'description'       => $group['description']
        ];
    }, $groups);

    return rest_ensure_response([
        'success' => true,
        'data'    => $groups,
    ]);
}

function create_product_group($request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'checkin_mkt192_product_groups';
    $data       = $request->get_json_params();

    if (empty($data['name'])) {
        return new WP_Error('invalid_data', 'Tên nhóm sản phẩm là bắt buộc', ['status' => 400]);
    }

    $group_code = strtoupper(sanitize_title($data['name']));
    $existing   = $wpdb->get_var($wpdb->prepare("SELECT group_code FROM $table_name WHERE group_code = %s", $group_code));
    if ($existing) {
        return new WP_Error('duplicate_code', 'Mã nhóm sản phẩm đã tồn tại', ['status' => 400]);
    }

    $result = $wpdb->insert($table_name, [
        'group_name'  => sanitize_text_field($data['name']),
        'group_code'  => $group_code,
        'description' => isset($data['description']) ? sanitize_textarea_field($data['description']) : null,
        'created_at'  => current_time('mysql'),
        'updated_at'  => current_time('mysql'),
    ]);

    if ($result === false) {
        error_log('Create product group error: ' . $wpdb->last_error);
        return new WP_Error('db_error', 'Lỗi khi thêm nhóm sản phẩm: ' . $wpdb->last_error, ['status' => 500]);
    }

    return rest_ensure_response([
        'success' => true,
        'message' => 'Thêm nhóm sản phẩm thành công',
        'data'    => ['id' => $wpdb->insert_id],
    ]);
}

function update_product_group($request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'checkin_mkt192_product_groups';
    $id         = $request['id'];
    $data       = $request->get_json_params();

    if (empty($data['name'])) {
        return new WP_Error('invalid_data', 'Tên nhóm sản phẩm là bắt buộc', ['status' => 400]);
    }

    $group_code = strtoupper(sanitize_title($data['name']));
    $existing   = $wpdb->get_var($wpdb->prepare(
        "SELECT group_code FROM $table_name WHERE group_code = %s AND id != %d",
        $group_code, $id
    ));
    if ($existing) {
        return new WP_Error('duplicate_code', 'Mã nhóm sản phẩm đã tồn tại', ['status' => 400]);
    }

    $result = $wpdb->update($table_name, [
        'group_name'  => sanitize_text_field($data['name']),
        'group_code'  => $group_code,
        'description' => isset($data['description']) ? sanitize_textarea_field($data['description']) : null,
        'updated_at'  => current_time('mysql'),
    ], ['id' => $id]);

    if ($result === false) {
        error_log('Update product group error: ' . $wpdb->last_error);
        return new WP_Error('db_error', 'Lỗi khi cập nhật nhóm sản phẩm: ' . $wpdb->last_error, ['status' => 500]);
    }

    return rest_ensure_response([
        'success' => true,
        'message' => 'Cập nhật nhóm sản phẩm thành công',
    ]);
}

function delete_product_group($request) {
    global $wpdb;
    $table_name    = $wpdb->prefix . 'checkin_mkt192_product_groups';
    $product_table = $wpdb->prefix . 'checkin_mkt192_products';
    $id            = $request['id'];

    $in_use = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $product_table WHERE product_group_id = %d", $id));
    if ($in_use > 0) {
        return new WP_Error('group_in_use', 'Không thể xóa nhóm này vì đang được sử dụng', ['status' => 400]);
    }

    $result = $wpdb->delete($table_name, ['id' => $id]);

    if ($result === false) {
        error_log('Delete product group error: ' . $wpdb->last_error);
        return new WP_Error('db_error', 'Lỗi khi xóa nhóm sản phẩm: ' . $wpdb->last_error, ['status' => 500]);
    }

    return rest_ensure_response([
        'success' => true,
        'message' => 'Xóa nhóm sản phẩm thành công',
    ]);
}
?>