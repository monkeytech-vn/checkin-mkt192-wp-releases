<?php
/**
 * Zalo Social Login API
 * Handles OAuth login flow for customer-facing Zalo login (Social API, NOT OA API)
 * 
 * Flow:
 * 1. Frontend generates code_verifier + code_challenge (PKCE)
 * 2. Frontend redirects user to Zalo OAuth → user grants permission → redirect back with code
 * 3. Frontend sends code + code_verifier to this API
 * 4. This API exchanges code for access_token → calls userinfo → returns zalo_id, name, avatar
 * 5. Frontend links zalo_social_id ↔ phone if needed
 */

add_action('rest_api_init', function () {
    // Exchange OAuth code for Zalo user info
    register_rest_route('vg/v1', '/zalo-social-login', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_zalo_social_login',
        'permission_callback' => '__return_true'
    ]);

    // Link zalo_social_id with customer phone
    register_rest_route('vg/v1', '/zalo-social-link', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_zalo_social_link',
        'permission_callback' => '__return_true'
    ]);

    // Get Zalo Social App config (app_id only, no secrets to frontend)
    register_rest_route('vg/v1', '/zalo-social-config', [
        'methods'             => 'GET',
        'callback'            => 'checkin_mkt192_get_zalo_social_config',
        'permission_callback' => '__return_true'
    ]);
});

/**
 * Exchange OAuth code for Zalo user info, then check if zalo_social_id is linked to a customer
 */
function checkin_mkt192_zalo_social_login(WP_REST_Request $request) {
    $data = $request->get_json_params();
    $code           = sanitize_text_field($data['code'] ?? '');
    $code_verifier  = sanitize_text_field($data['code_verifier'] ?? '');

    if (empty($code) || empty($code_verifier)) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Thiếu code hoặc code_verifier'
        ], 400);
    }

    // Get Zalo App config — fallback to Zalo OA config if Social-specific not set
    $app_id     = get_option('checkin_zalo_social_app_id', '') ?: get_option('checkin_zalo_oa_app_id', '');
    $app_secret = get_option('checkin_zalo_social_app_secret', '') ?: get_option('checkin_zalo_oa_secret_key', '');

    if (empty($app_id) || empty($app_secret)) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Chưa cấu hình Zalo Social App'
        ], 400);
    }

    // Step 1: Exchange code for access_token (Zalo Social API v4)
    $token_url = 'https://oauth.zaloapp.com/v4/access_token';
    $token_response = wp_remote_post($token_url, [
        'headers' => [
            'Content-Type' => 'application/x-www-form-urlencoded',
            'secret_key'   => $app_secret,
        ],
        'body' => [
            'app_id'        => $app_id,
            'code'          => $code,
            'grant_type'    => 'authorization_code',
            'code_verifier' => $code_verifier,
        ],
        'timeout' => 15,
    ]);

    if (is_wp_error($token_response)) {
        checkin_mkt192_log_error('zalo_social', 'Token exchange failed', [
            'error' => $token_response->get_error_message()
        ]);
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Lỗi kết nối Zalo: ' . $token_response->get_error_message()
        ], 500);
    }

    $token_body = json_decode(wp_remote_retrieve_body($token_response), true);

    if (empty($token_body['access_token'])) {
        checkin_mkt192_log_error('zalo_social', 'No access_token in response', [
            'response' => $token_body
        ]);
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Không thể lấy access token từ Zalo: ' . ($token_body['error_description'] ?? $token_body['error_name'] ?? 'Unknown')
        ], 400);
    }

    $access_token = $token_body['access_token'];

    // Step 2: Get user info from Zalo
    $user_info_url = 'https://graph.zalo.me/v2.0/me?fields=id,name,picture';
    $user_response = wp_remote_get($user_info_url, [
        'headers' => [
            'access_token' => $access_token,
        ],
        'timeout' => 15,
    ]);

    if (is_wp_error($user_response)) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Lỗi khi lấy thông tin Zalo'
        ], 500);
    }

    $user_data = json_decode(wp_remote_retrieve_body($user_response), true);

    if (empty($user_data['id'])) {
        checkin_mkt192_log_error('zalo_social', 'No user id in response', [
            'response' => $user_data
        ]);
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Không thể lấy thông tin người dùng Zalo'
        ], 400);
    }

    $zalo_id = sanitize_text_field($user_data['id']);
    $zalo_name = sanitize_text_field($user_data['name'] ?? '');
    $zalo_avatar = '';

    // Avatar is nested: picture.data.url
    if (!empty($user_data['picture']['data']['url'])) {
        $zalo_avatar = esc_url_raw($user_data['picture']['data']['url']);
    }

    // Step 3: Check if this zalo_social_id is already linked to a customer
    global $wpdb;
    $customer_table = $wpdb->prefix . 'bookingmkt192_customer_data';
    $linked_customer = $wpdb->get_row($wpdb->prepare(
        "SELECT customer_id, customer_name, customer_phone, membership_level
         FROM $customer_table
         WHERE id_zalo = %s
         LIMIT 1",
        $zalo_id
    ));

    if ($linked_customer) {
        // Already linked — return customer data for auto-search
        return new WP_REST_Response([
            'success'  => true,
            'linked'   => true,
            'zalo_id'  => $zalo_id,
            'zalo_name'   => $zalo_name,
            'zalo_avatar' => $zalo_avatar,
            'customer' => [
                'customer_id'      => $linked_customer->customer_id,
                'customer_name'    => $linked_customer->customer_name,
                'customer_phone'   => $linked_customer->customer_phone,
                'membership_level' => $linked_customer->membership_level,
            ]
        ], 200);
    }

    // Not linked yet — return Zalo info so frontend can show linking form
    return new WP_REST_Response([
        'success'     => true,
        'linked'      => false,
        'zalo_id'     => $zalo_id,
        'zalo_name'   => $zalo_name,
        'zalo_avatar' => $zalo_avatar,
    ], 200);
}

/**
 * Link a Zalo Social ID with a customer phone number
 */
function checkin_mkt192_zalo_social_link(WP_REST_Request $request) {
    $data = $request->get_json_params();
    $zalo_id = sanitize_text_field($data['zalo_id'] ?? '');
    $phone   = sanitize_text_field($data['phone'] ?? '');

    if (empty($zalo_id) || empty($phone)) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Thiếu Zalo ID hoặc số điện thoại'
        ], 400);
    }

    // Normalize phone: remove leading 0, keep digits only
    $phone = preg_replace('/[^0-9]/', '', $phone);
    if (strpos($phone, '0') === 0) {
        $phone = substr($phone, 1);
    }

    global $wpdb;
    $customer_table = $wpdb->prefix . 'bookingmkt192_customer_data';

    // Find customer by phone
    $customer = $wpdb->get_row($wpdb->prepare(
        "SELECT customer_id, customer_name, customer_phone, membership_level
         FROM $customer_table
         WHERE customer_phone = %s
         LIMIT 1",
        $phone
    ));

    if (!$customer) {
        // Customer not found — frontend should redirect to registration
        return new WP_REST_Response([
            'success'   => false,
            'not_found' => true,
            'phone'     => $phone,
            'message'   => 'Không tìm thấy khách hàng. Bạn sẽ được chuyển đến trang đăng ký thành viên.'
        ], 200); // 200 so frontend can handle gracefully
    }

    // Check if customer has registered as a member (has name + membership level)
    $is_member = !empty($customer->customer_name) && !empty($customer->membership_level);
    if (!$is_member) {
        // Link zalo_social_id first, then redirect to registration
        $wpdb->update(
            $customer_table,
            ['id_zalo' => $zalo_id],
            ['customer_id' => $customer->customer_id],
            ['%s'],
            ['%s']
        );
        return new WP_REST_Response([
            'success'            => true,
            'needs_registration'  => true,
            'phone'              => $customer->customer_phone ?: $phone,
            'message'            => 'Bạn chưa đăng ký thành viên. Chuyển đến trang đăng ký để hoàn tất.'
        ], 200);
    }

    // Check if another customer already has this zalo_social_id
    $existing = $wpdb->get_var($wpdb->prepare(
        "SELECT customer_id FROM $customer_table WHERE id_zalo = %s AND customer_id != %d",
        $zalo_id,
        $customer->customer_id
    ));

    if ($existing) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Tài khoản Zalo này đã được liên kết với SĐT khác.'
        ], 409);
    }

    // Link zalo_social_id to this customer
    $result = $wpdb->update(
        $customer_table,
        ['id_zalo' => $zalo_id],
        ['customer_id' => $customer->customer_id],
        ['%s'],
        ['%s']
    );

    if ($result === false) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Lỗi khi liên kết tài khoản'
        ], 500);
    }

    checkin_mkt192_log_info('zalo_social', 'Linked Zalo Social account', [
        'zalo_id'     => $zalo_id,
        'customer_id' => $customer->customer_id,
        'phone'       => $phone,
    ]);

    return new WP_REST_Response([
        'success'  => true,
        'message'  => 'Liên kết thành công!',
        'customer' => [
            'customer_id'      => $customer->customer_id,
            'customer_name'    => $customer->customer_name,
            'customer_phone'   => $customer->customer_phone,
            'membership_level' => $customer->membership_level,
        ]
    ], 200);
}

/**
 * Return Zalo Social App ID to the frontend (no secret exposed)
 */
function checkin_mkt192_get_zalo_social_config(WP_REST_Request $request) {
    // Only enable Zalo Social Login if site has Zalo OA enabled
    $use_zalo_oa_raw = get_option('checkin_use_zalo_oa', 'no');
    $use_zalo_oa = in_array($use_zalo_oa_raw, ['yes', '1', 1, true, 'true'], true) ? 'yes' : 'no';

    if ($use_zalo_oa !== 'yes') {
        // Zalo OA not enabled — return empty config so frontend hides login section
        return new WP_REST_Response([
            'success' => true,
            'data'    => [
                'app_id'       => '',
                'callback_url' => '',
            ]
        ], 200);
    }

    // Fallback to Zalo OA config if Social-specific not set
    $app_id       = get_option('checkin_zalo_social_app_id', '') ?: get_option('checkin_zalo_oa_app_id', '');
    $callback_url = get_option('checkin_zalo_social_callback_url', '');

    // Auto-generate callback_url from checkin_domain (same as other Zalo integrations)
    if (empty($callback_url)) {
        $domain = get_option('checkin_domain', '');
        if (!empty($domain)) {
            $callback_url = "https://{$domain}/customer-member";
        } else {
            $callback_url = home_url('/customer-member');
        }
    }

    return new WP_REST_Response([
        'success' => true,
        'data'    => [
            'app_id'       => $app_id,
            'callback_url' => $callback_url,
        ]
    ], 200);
}
