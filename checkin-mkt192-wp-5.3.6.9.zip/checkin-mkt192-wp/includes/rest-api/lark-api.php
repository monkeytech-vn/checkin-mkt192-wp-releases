<?php

// Exit if accessed directly.
if (!defined('ABSPATH')) {
    exit;
}

add_action('rest_api_init', function () {
    register_rest_route('vg/v1', '/lark-callback', [
        'methods'             => 'POST',
        'callback'            => 'handle_lark_callback',
        'permission_callback' => '__return_true',
    ]);

    // DEPRECATED: Các endpoint sync từ Lark đã ngưng sử dụng
    // Tất cả các loại đơn (leave, late_early, salary_advance) giờ được tạo trực tiếp trên website
    // thông qua /vg/v1/approval-requests API
    // - /sync-leave-requests
    // - /sync-late-requests
    // - /sync-advance-salary

    register_rest_route('vg/v1', '/lark/get-member-id', [
        'methods'             => 'POST',
        'callback'            => 'get_lark_member_id',
        'permission_callback' => function () {
            return current_user_can('manage_options');
        },
    ]);
});

require_once(dirname(__FILE__, 2) . '/lark/lark-utils.php');
require_once(dirname(__FILE__, 2) . '/lark/card-builder.php');
require_once(dirname(__FILE__, 2) . '/lark/cache-utils.php');
require_once(dirname(__FILE__, 2) . '/lark/send_salary_notification.php');
require_once(dirname(__FILE__, 2) . '/lark/send_stock_transaction_notification.php');

/**
 * Verify Lark webhook signature
 * @param string $body Raw request body
 * @param string $timestamp Request timestamp header
 * @param string $signature Request signature header
 * @return bool
 */
function verify_lark_signature($body, $timestamp, $signature) {
    $verification_token = get_option('lark_verification_token', '');
    if (empty($verification_token)) {
        // If no token configured, skip verification (backward compatibility)
        return true;
    }

    // Lark signature: sha256(timestamp + nonce + encrypt_key + body)
    $expected = hash('sha256', $timestamp . $verification_token . $body);
    return hash_equals($expected, $signature);
}

/**
 * Handle Lark callback
 */
function handle_lark_callback() {
    global $wpdb;

    $body = file_get_contents('php://input');
    $data = json_decode($body, true);

    // Đặt header Content-Type
    header('Content-Type: application/json; charset=utf-8');

    // Verify signature (skip for URL verification)
    if (!isset($data['type']) || $data['type'] !== 'url_verification') {
        $timestamp = isset($_SERVER['HTTP_X_LARK_REQUEST_TIMESTAMP']) ? $_SERVER['HTTP_X_LARK_REQUEST_TIMESTAMP'] : '';
        $signature = isset($_SERVER['HTTP_X_LARK_SIGNATURE']) ? $_SERVER['HTTP_X_LARK_SIGNATURE'] : '';

        if (!empty(get_option('lark_verification_token', '')) && !verify_lark_signature($body, $timestamp, $signature)) {
            CacheManager::write_log('Invalid Lark signature', ['timestamp' => $timestamp], 'lark_callback_log.log');
            echo json_encode(['success' => false, 'message' => 'Invalid signature']);
            http_response_code(401);
            exit;
        }
    }

    // Kiểm tra xem Lark có được bật không (trừ URL verification)
    if (!isset($data['type']) || $data['type'] !== 'url_verification') {
        if (!is_lark_enabled()) {
            CacheManager::write_log('Lark is disabled, rejecting callback', $data, 'lark_callback_log.log');
            echo json_encode(['success' => false, 'message' => 'Lark is disabled']);
            http_response_code(403);
            exit;
        }
    }

    // Xử lý xác minh URL
    if (isset($data['type']) && $data['type'] === 'url_verification') {
        if (!isset($data['challenge'])) {
            CacheManager::write_log('Missing challenge in URL verification request', $data, 'lark_callback_log.log');
            echo json_encode(['success' => false, 'message' => 'Missing challenge code']);
            http_response_code(400);
            exit;
        }
        $response = json_encode(['challenge' => $data['challenge']], JSON_UNESCAPED_UNICODE);
        CacheManager::write_log('URL verification response', ['response' => $response], 'lark_callback_log.log');
        echo $response;
        http_response_code(200);
        exit;
    }

    // Load Bot Manager để lấy bot credentials
    require_once(dirname(__FILE__, 2) . '/lark/class-checkin-mkt192-message-bot-manager.php');
    $bot_manager = Checkin_MKT192_Message_Bot_Manager::get_instance();

    // Lấy bot cho inventory/salary notifications (những loại dùng interactive bot với approval)
    // Thử inventory trước vì đa số callback là từ stock transactions
    $bot = $bot_manager->get_bot_by_notification_type('inventory');

    // Nếu không tìm thấy, thử salary (cho salary payment confirmations)
    if (!$bot) {
        $bot = $bot_manager->get_bot_by_notification_type('salary');
    }

    if (!$bot || $bot->bot_type !== 'interactive') {
        $error_message = 'No interactive bot found for handling callbacks';
        CacheManager::write_log($error_message, [], 'lark_callback_log.log');
        echo json_encode(['success' => false, 'message' => $error_message]);
        http_response_code(500);
        exit;
    }

    $chat_id            = $bot->chat_id;
    $app_id             = $bot->app_id;
    $app_secret         = $bot->app_secret;
    $verification_token = 'nYjX7Y3ZH7AEhp3N6gwtjgZR53mO8N17';

    $start_time = microtime(true);

    // Ghi log yêu cầu
    CacheManager::write_log('Received Lark request', [
        'raw_body'        => $body,
        'parsed_data'     => $data,
        'processing_time' => 0
    ], 'lark_callback_log.log');

    // Kiểm tra cấu trúc yêu cầu
    if (!isset($data['header']['event_type'])) {
        CacheManager::write_log('Invalid request structure', $data, 'lark_callback_log.log');
        echo json_encode(['success' => false, 'message' => 'Invalid request structure']);
        http_response_code(400);
        exit;
    }

    // Xử lý sự kiện card.action.trigger
    if ($data['header']['event_type'] === 'card.action.trigger') {
        $token = $data['header']['token'] ?? '';
        if ($token !== $verification_token) {
            CacheManager::write_log('Invalid header token', ['token' => $token], 'lark_callback_log.log');
            echo json_encode(['success' => false, 'message' => 'Invalid header token']);
            http_response_code(400);
            exit;
        }

        $action_value    = $data['event']['action']['value']            ?? [];
        $open_message_id = $data['event']['context']['open_message_id'] ?? '';
        $card_token      = $data['event']['token']                      ?? '';
        $transaction_id  = sanitize_text_field($action_value['id'] ?? '');
        $status          = sanitize_text_field($action_value['trang_thai'] ?? '');
        $action_type     = sanitize_text_field($action_value['type'] ?? 'inventory_transaction');

        if (!$transaction_id || !$status || !$open_message_id || !$card_token || !in_array($status, ['ĐÃ DUYỆT', 'KHÔNG DUYỆT'])) {
            CacheManager::write_log('Invalid callback data', [
                'action_value'    => $action_value,
                'open_message_id' => $open_message_id,
                'card_token'      => $card_token,
                'status'          => $status,
                'action_type'     => $action_type
            ], 'lark_callback_log.log');
            echo json_encode(['success' => false, 'message' => 'Invalid data']);
            http_response_code(400);
            exit;
        }

        $is_salary_action  = in_array($action_type, ['salary_confirmation', 'salary_payment'], true);
        $cache_prefix      = $is_salary_action ? CACHE_PREFIX_SALARY : CACHE_PREFIX_INVENTORY;
        $fallback_callback = $is_salary_action ? 'get_salary_data_from_db' : 'get_inventory_data_from_db';

        $cached_data = CacheManager::get($transaction_id, $cache_prefix, $fallback_callback);

        if (!$cached_data) {
            CacheManager::write_log('Failed to retrieve data from cache or database', [
                'transaction_id' => $transaction_id,
                'action_type'    => $action_type,
                'cache_prefix'   => $cache_prefix
            ], 'lark_callback_log.log');
            echo json_encode(['success' => false, 'message' => 'Failed to retrieve data']);
            http_response_code(500);
            exit;
        }

        // Lưu cache nếu dữ liệu được lấy từ database
        if (!get_transient("{$cache_prefix}_{$transaction_id}")) {
            CacheManager::store($transaction_id, $cached_data, $cache_prefix);
        }

        // Xác định status_value và status_color dựa theo loại action
        if ($is_salary_action) {
            $status_value  = $status === 'ĐÃ DUYỆT' ? '✅ Đã nhận đủ' : '❌ Chưa nhận được';
            $toast_message = $status === 'ĐÃ DUYỆT' ? 'Xác nhận thành công' : 'Đã gửi yêu cầu xét lại';
        } else {
            $status_value  = $status === 'ĐÃ DUYỆT' ? '✅ Đã Duyệt' : '❌ Không Duyệt';
            $toast_message = $status === 'ĐÃ DUYỆT' ? 'Đã duyệt thành công' : 'Đã từ chối';
        }
        $status_color = $status === 'ĐÃ DUYỆT' ? 'green' : 'red';
        $card         = build_callback_card($transaction_id, $status_value, $status_color, [CacheManager::class, 'write_log'], $action_type);

        if ($card === false) {
            CacheManager::write_log('Error building card', [
                'transaction_id' => $transaction_id,
                'status'         => $status,
                'action_type'    => $action_type,
                'cached_data'    => $cached_data
            ], 'lark_callback_log.log');
            echo json_encode(['success' => false, 'message' => 'Error building card']);
            http_response_code(500);
            exit;
        }

        $db_updated = false;
        if ($is_salary_action) {
            $staff_name = sanitize_text_field($action_value['staff_name'] ?? '');
            $period     = sanitize_text_field($action_value['period'] ?? '');
            $db_updated = update_salary_payment_confirmation($transaction_id, $staff_name, $period, $status);
            if (!$db_updated) {
                CacheManager::write_log('Error updating salary status', [
                    'transaction_id' => $transaction_id,
                    'staff_name'     => $staff_name,
                    'status'         => $status
                ], 'lark_callback_log.log');
                echo json_encode(['success' => false, 'message' => 'Error updating salary status']);
                http_response_code(500);
                exit;
            }
        } else {
            $db_updated = update_transaction_status($transaction_id, $status);
            if (!$db_updated) {
                CacheManager::write_log('Error updating inventory transaction status', [
                    'transaction_id' => $transaction_id,
                    'status'         => $status
                ], 'lark_callback_log.log');
                echo json_encode(['success' => false, 'message' => 'Error updating inventory transaction status']);
                http_response_code(500);
                exit;
            }
        }

        $toast_type    = $status    === 'ĐÃ DUYỆT' ? 'success' : 'error';
        $response      = [
            'toast' => [
                'type'    => $toast_type,
                'content' => $toast_message,
                'i18n'    => [
                    'zh_cn' => $status === 'ĐÃ DUYỆT' ? '卡片交互成功' : '卡片交互失败',
                    'en_us' => $status === 'ĐÃ DUYỆT' ? 'Card action success' : 'Card action failed'
                ]
            ],
            'card' => $card
        ];

        CacheManager::delete($transaction_id, $cache_prefix);

        $end_time        = microtime(true);
        $processing_time = $end_time - $start_time;
        if ($processing_time > 3) {
            CacheManager::write_log('Callback processing time exceeded 3 seconds', [
                'transaction_id'  => $transaction_id,
                'processing_time' => $processing_time
            ], 'lark_callback_log.log');
        }

        CacheManager::write_log('Returning Update Now response with toast and card', [
            'card_token'      => $card_token,
            'response'        => $response,
            'processing_time' => $processing_time
        ], 'lark_callback_log.log');
        echo json_encode($response, JSON_UNESCAPED_UNICODE);
        http_response_code(200);
        exit;
    }

    CacheManager::write_log('Unsupported request', $data, 'lark_callback_log.log');
    echo json_encode(['success' => false, 'message' => 'Unsupported request']);
    http_response_code(400);
    exit;
}

/**
 * Get salary data from database when cache is unavailable
 */
function get_salary_data_from_db($transaction_id) {
    global $wpdb;
    $table_cashier_salary     = $wpdb->prefix . 'checkin_mkt192_cashier_salary';
    $table_hairdresser_salary = $wpdb->prefix . 'checkin_mkt192_hairdresser_salary';
    $table_staff              = $wpdb->prefix . 'checkin_mkt192_staff';

    $salary_data = $wpdb->get_row($wpdb->prepare(
        "SELECT staff_name, actual_salary, period FROM $table_cashier_salary WHERE transaction_id = %s AND xac_nhan_thanh_toan IS NOT NULL
         UNION
         SELECT staff_name, actual_salary, period FROM $table_hairdresser_salary WHERE transaction_id = %s AND xac_nhan_thanh_toan IS NOT NULL",
        $transaction_id, $transaction_id
    ));

    if (!$salary_data) {
        CacheManager::write_log("No salary data found for transaction_id '$transaction_id'", [], 'lark_callback_log.log');
        return false;
    }

    return [
        'staff_name'       => $salary_data->staff_name,
        'actual_salary'    => $salary_data->actual_salary,
        'period'           => $salary_data->period,
        'transaction_type' => 'PAYROLL'
    ];
}

/**
 * Get inventory data from database when cache is unavailable
 */
function get_inventory_data_from_db($transaction_id) {
    global $wpdb;
    $table_transactions = $wpdb->prefix . 'checkin_mkt192_inventory_transactions';
    $table_staff        = $wpdb->prefix . 'checkin_mkt192_staff';

    $transaction_data = $wpdb->get_results($wpdb->prepare(
        "SELECT product_id, product_name, quantity, note, transaction_type, staff_name
         FROM $table_transactions
         WHERE transaction_id = %s",
        $transaction_id
    ));

    if (!$transaction_data) {
        CacheManager::write_log("No inventory data found for transaction_id '$transaction_id'", [], 'lark_callback_log.log');
        return false;
    }

    $employee_name  = $transaction_data[0]->staff_name;
    $employee_ou_id = $wpdb->get_var($wpdb->prepare(
        "SELECT ou_id FROM $table_staff WHERE display_name = %s",
        $employee_name
    ));

    if (!$employee_ou_id) {
        CacheManager::write_log("No ou_id found for employee '$employee_name'", [], 'lark_callback_log.log');
        return false;
    }

    $transactions = array_map(function ($row) {
        return [
            'product_id'   => $row->product_id,
            'product_name' => $row->product_name,
            'quantity'     => $row->quantity
        ];
    }, $transaction_data);

    return [
        'employee_name'    => $employee_name,
        'employee_ou_id'   => $employee_ou_id,
        'transaction_type' => $transaction_data[0]->transaction_type,
        'transaction_id'   => $transaction_id,
        'transactions'     => $transactions,
        'note'             => $transaction_data[0]->note
    ];
}

function handle_sync_leave_requests(WP_REST_Request $request) {
    // [DEPRECATED] Hàm này đã ngưng sử dụng - đơn nghỉ phép giờ được tạo trực tiếp trên website
    return new WP_REST_Response([
        'status_code' => 410,
        'body'        => [
            'status'  => 'deprecated',
            'message' => 'This sync endpoint is deprecated. Leave requests are now created directly on the website.'
        ]
    ], 410);

    // === CODE CŨ - KHÔNG CÒN SỬ DỤNG ===
    // Kiểm tra Lark có được bật không
    if (!is_lark_enabled()) {
        return new WP_REST_Response([
            'status_code' => 403,
            'body'        => [
                'status'  => 'error',
                'message' => 'Lark is disabled.'
            ]
        ], 403);
    }

    global $wpdb;

    $table_name   = $wpdb->prefix . 'checkin_mkt192_approval_requests';
    $decoded_data = json_decode($request->get_body(), true);

    if (empty($decoded_data)) {
        return new WP_REST_Response([
            'status_code' => 400,
            'body'        => [
                'status'  => 'error',
                'message' => 'No data received or invalid JSON format.'
            ]
        ], 400);
    }

    file_put_contents(__DIR__ . '/logs/leave_requests_log.log', print_r($decoded_data, true), FILE_APPEND);

    $request_no       = $decoded_data['request_no']       ?? null;
    $leave_status     = $decoded_data['leave_status']     ?? null;
    $hairdresser_name = $decoded_data['hairdresser_name'] ?? null;
    $leave_start_date = $decoded_data['leave_start_date'] ?? null;
    $leave_end_date   = $decoded_data['leave_end_date']   ?? null;
    $leave_total_date = $decoded_data['leave_total_date'] ?? null;

    if (!$request_no || !$leave_status || !$hairdresser_name || !$leave_start_date) {
        return new WP_REST_Response([
            'status_code' => 400,
            'body'        => [
                'status'  => 'error',
                'message' => 'Missing required fields: request_no, leave_status, hairdresser_name, and leave_start_date are required.'
            ]
        ], 400);
    }

    $current_date = current_time('Y-m-d');
    $is_past_date = strtotime($leave_start_date) < strtotime($current_date);

    // Tìm theo request_no (lark request id) trong bảng mới
    $existing = $wpdb->get_row(
        $wpdb->prepare("SELECT * FROM $table_name WHERE request_id = %s OR (staff_name = %s AND request_type = 'leave' AND leave_start_date = %s)",
        $request_no, $hairdresser_name, $leave_start_date)
    );

    // Map status từ Lark sang status mới
    $mapped_status = strtolower($leave_status) === 'approved' ? 'approved' :
                     (strtolower($leave_status) === 'rejected' ? 'rejected' : 'pending');

    if ($existing) {
        $wpdb->update(
            $table_name,
            [
                'status'           => $mapped_status,
                'leave_start_date' => $leave_start_date,
                'leave_end_date'   => $leave_end_date,
                'updated_at'       => current_time('mysql'),
            ],
            ['id' => $existing->id],
            ['%s', '%s', '%s', '%s'],
            ['%d']
        );

        return new WP_REST_Response([
            'status_code' => 200,
            'body'        => [
                'status'  => 'success',
                'message' => 'Leave request updated successfully.'
            ]
        ], 200);
    } else {
        // Tạo mới nếu chưa có (từ Lark callback)
        $inserted = $wpdb->insert(
            $table_name,
            [
                'request_id'       => $request_no,
                'request_type'     => 'leave',
                'status'           => $mapped_status,
                'staff_name'       => $hairdresser_name,
                'leave_type'       => 'annual',
                'leave_start_date' => $leave_start_date,
                'leave_end_date'   => $leave_end_date,
                'reason'           => 'Synced from Lark',
                'created_at'       => current_time('mysql'),
                'updated_at'       => current_time('mysql'),
            ],
            ['%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s']
        );

        if ($inserted === false) {
            return new WP_REST_Response([
                'status_code' => 500,
                'body'        => [
                    'status'  => 'failure',
                    'message' => 'Database insert failed: ' . $wpdb->last_error
                ]
            ], 500);
        }

        return new WP_REST_Response([
            'status_code' => 200,
            'body'        => [
                'status'  => 'success',
                'message' => 'Leave request added successfully.'
            ]
        ], 200);
    }
    // === KẾT THÚC CODE CŨ === */
}

function handle_sync_late_requests(WP_REST_Request $request) {
    // [DEPRECATED] Hàm này đã ngưng sử dụng - đơn đi trễ/về sớm giờ được tạo trực tiếp trên website
    return new WP_REST_Response([
        'status_code' => 410,
        'body'        => [
            'status'  => 'deprecated',
            'message' => 'This sync endpoint is deprecated. Late/early requests are now created directly on the website.'
        ]
    ], 410);

    // === CODE CŨ - KHÔNG CÒN SỬ DỤNG ===
    // Kiểm tra Lark có được bật không
    if (!is_lark_enabled()) {
        return new WP_REST_Response([
            'status_code' => 403,
            'body'        => [
                'status'  => 'error',
                'message' => 'Lark is disabled.'
            ]
        ], 403);
    }

    global $wpdb;

    $table_approval_requests = $wpdb->prefix . 'checkin_mkt192_approval_requests';
    $table_checkinlogs       = $wpdb->prefix . 'checkin_mkt192_checkinlogs';

    $decoded_data = json_decode($request->get_body(), true);

    if (empty($decoded_data)) {
        return new WP_REST_Response([
            'status_code' => 400,
            'body'        => [
                'status'  => 'error',
                'message' => 'Không nhận được dữ liệu hoặc định dạng JSON không hợp lệ.'
            ]
        ], 400);
    }

    // Ghi log
    file_put_contents(__DIR__ . '/logs/late_requests_log.log', print_r($decoded_data, true), FILE_APPEND);

    $request_no      = $decoded_data['request_no']     ?? null;
    $status          = $decoded_data['status']         ?? null;
    $staff_name      = $decoded_data['staff_name']     ?? null;
    $late_date       = $decoded_data['late_date']      ?? null;
    $time_late       = $decoded_data['time_late']      ?? null;
    $time_late_note  = $decoded_data['time_late_note'] ?? null;
    $note            = $decoded_data['note']           ?? null;

    if (!$request_no || !$status || !$staff_name || !$late_date) {
        return new WP_REST_Response([
            'status_code' => 400,
            'body'        => [
                'status'  => 'error',
                'message' => 'Thiếu các trường bắt buộc: request_no, status, staff_name và late_date.'
            ]
        ], 400);
    }

    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $late_date) || !strtotime($late_date)) {
        return new WP_REST_Response([
            'status_code' => 400,
            'body'        => [
                'status'  => 'error',
                'message' => 'Định dạng late_date không hợp lệ. Sử dụng YYYY-MM-DD.'
            ]
        ], 400);
    }

    if ($time_late !== null && (strlen($time_late) > 191 || !is_string($time_late))) {
        return new WP_REST_Response([
            'status_code' => 400,
            'body'        => [
                'status'  => 'error',
                'message' => 'time_late không hợp lệ. Phải là chuỗi tối đa 191 ký tự.'
            ]
        ], 400);
    }

    $existing = $wpdb->get_row($wpdb->prepare("
        SELECT * FROM $table_approval_requests WHERE request_id = %s OR (staff_name = %s AND request_type = 'late_early' AND late_early_date = %s)
    ", $request_no, $staff_name, $late_date));

    // Map status từ Lark sang status mới
    $mapped_status = strtolower($status) === 'approved' ? 'approved' :
                     (strtolower($status) === 'rejected' ? 'rejected' : 'pending');

    try {
        if ($existing) {
            $wpdb->update(
                $table_approval_requests,
                [
                    'status'     => $mapped_status,
                    'reason'     => $note,
                    'updated_at' => current_time('mysql')
                ],
                ['id' => $existing->id],
                ['%s', '%s', '%s'],
                ['%d']
            );
            $action = 'cập nhật';
        } else {
            // Parse time_late để lấy số phút
            $late_minutes = 0;
            if (preg_match('/(\d+)/', $time_late, $matches)) {
                $late_minutes = intval($matches[1]);
            }

            $wpdb->insert(
                $table_approval_requests,
                [
                    'request_id'         => $request_no,
                    'request_type'       => 'late_early',
                    'status'             => $mapped_status,
                    'staff_name'         => $staff_name,
                    'late_early_type'    => 'late',
                    'late_early_date'    => $late_date,
                    'late_early_minutes' => $late_minutes,
                    'reason'             => $note ?: $time_late_note,
                    'created_at'         => current_time('mysql'),
                    'updated_at'         => current_time('mysql')
                ],
                ['%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s']
            );
            $action = 'thêm mới';
        }

        // Cập nhật checkinlogs nếu được duyệt
        if ($mapped_status === 'approved') {
            $wpdb->query($wpdb->prepare("
                UPDATE $table_checkinlogs
                SET approval_late = %s, penalty_amount = 0
                WHERE display_name = %s AND DATE(checkin_time) = %s
            ", 'approved', $staff_name, $late_date));
        }

        return new WP_REST_Response([
            'status_code' => 200,
            'body'        => [
                'status'  => 'success',
                'message' => "Đơn xin đi trễ được {$action} thành công, trạng thái đi trễ và tiền phạt đã được cập nhật ở Bảng Điểm Danh."
            ]
        ], 200);
    } catch (Exception $e) {
        file_put_contents(__DIR__ . '/logs/db_errors.log', $e->getMessage() . PHP_EOL, FILE_APPEND);
        return new WP_REST_Response([
            'status_code' => 500,
            'body'        => [
                'status'  => 'failure',
                'message' => 'Lỗi cơ sở dữ liệu: ' . $e->getMessage()
            ]
        ], 500);
    }
}

function handle_sync_advance_salary_request(WP_REST_Request $request) {
    // [DEPRECATED] Hàm này đã ngưng sử dụng - đơn ứng lương giờ được tạo trực tiếp trên website
    return new WP_REST_Response([
        'status_code' => 410,
        'body'        => [
            'status'  => 'deprecated',
            'message' => 'This sync endpoint is deprecated. Salary advance requests are now created directly on the website.'
        ]
    ], 410);

    // === CODE CŨ - KHÔNG CÒN SỬ DỤNG ===
    // Kiểm tra Lark có được bật không
    if (!is_lark_enabled()) {
        return new WP_REST_Response([
            'status_code' => 403,
            'body'        => [
                'status'  => 'error',
                'message' => 'Lark is disabled.'
            ]
        ], 403);
    }

    global $wpdb;

    $table_name   = $wpdb->prefix . 'checkin_mkt192_approval_requests';
    $decoded_data = json_decode($request->get_body(), true);

    // Kiểm tra JSON không hợp lệ hoặc rỗng
    if (empty($decoded_data)) {
        return new WP_REST_Response([
            'status_code' => 400,
            'body'        => [
                'status'  => 'error',
                'message' => 'Không nhận được dữ liệu hoặc định dạng JSON không hợp lệ.'
            ]
        ], 400);
    }

    // Ghi log để gỡ lỗi
    file_put_contents(__DIR__ . '/logs/advance_salary_log.log', print_r($decoded_data, true), FILE_APPEND);

    // Trích xuất dữ liệu
    $request_no      = $decoded_data['request_no']     ?? null;
    $status          = $decoded_data['status']         ?? null;
    $staff_name      = $decoded_data['staff_name']     ?? null;
    $advance_date    = $decoded_data['advance_date']   ?? null;
    $advance_amount  = $decoded_data['advance_amount'] ?? null;
    $note            = $decoded_data['note']           ?? null;

    // Kiểm tra các trường bắt buộc
    if (!$request_no || !$status || !$staff_name || !$advance_date || !$advance_amount) {
        return new WP_REST_Response([
            'status_code' => 400,
            'body'        => [
                'status'  => 'error',
                'message' => 'Thiếu các trường bắt buộc: request_no, status, staff_name, advance_date và advance_amount.'
            ]
        ], 400);
    }

    // Kiểm tra định dạng ngày
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $advance_date) || !strtotime($advance_date)) {
        return new WP_REST_Response([
            'status_code' => 400,
            'body'        => [
                'status'  => 'error',
                'message' => 'Định dạng advance_date không hợp lệ. Sử dụng YYYY-MM-DD.'
            ]
        ], 400);
    }

    // Kiểm tra advance_amount là số dương
    if (!is_numeric($advance_amount) || $advance_amount <= 0) {
        return new WP_REST_Response([
            'status_code' => 400,
            'body'        => [
                'status'  => 'error',
                'message' => 'advance_amount phải là số dương.'
            ]
        ], 400);
    }

    try {
        // Kiểm tra request_id đã tồn tại chưa trong bảng mới
        $existing = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM $table_name WHERE request_id = %s OR (staff_name = %s AND request_type = 'salary_advance' AND request_date = %s)",
            $request_no, $staff_name, $advance_date)
        );

        // Map status từ Lark sang status mới
        $mapped_status = strtolower($status) === 'approved' ? 'approved' :
                         (strtolower($status) === 'rejected' ? 'rejected' : 'pending');

        if ($existing) {
            // Nếu đã tồn tại -> UPDATE
            $wpdb->update(
                $table_name,
                [
                    'status'         => $mapped_status,
                    'advance_amount' => $advance_amount,
                    'reason'         => $note,
                    'updated_at'     => current_time('mysql')
                ],
                ['id' => $existing->id],
                ['%s', '%f', '%s', '%s'],
                ['%d']
            );

            return new WP_REST_Response([
                'status_code' => 200,
                'body'        => [
                    'status'  => 'success',
                    'message' => 'Đơn ứng lương được cập nhật thành công.'
                ]
            ], 200);
        } else {
            // Nếu chưa tồn tại -> INSERT vào bảng mới
            $inserted = $wpdb->insert(
                $table_name,
                [
                    'request_id'     => $request_no,
                    'request_type'   => 'salary_advance',
                    'status'         => $mapped_status,
                    'staff_name'     => $staff_name,
                    'request_date'   => $advance_date,
                    'advance_amount' => $advance_amount,
                    'reason'         => $note ?: 'Synced from Lark',
                    'created_at'     => current_time('mysql'),
                    'updated_at'     => current_time('mysql')
                ],
                ['%s', '%s', '%s', '%s', '%s', '%f', '%s', '%s', '%s']
            );

            if ($inserted === false) {
                return new WP_REST_Response([
                    'status_code' => 500,
                    'body'        => [
                        'status'  => 'failure',
                        'message' => 'Lỗi khi thêm đơn ứng lương: ' . $wpdb->last_error
                    ]
                ], 500);
            }

            return new WP_REST_Response([
                'status_code' => 200,
                'body'        => [
                    'status'  => 'success',
                    'message' => 'Đơn ứng lương được thêm mới thành công.'
                ]
            ], 200);
        }
    } catch (Exception $e) {
        file_put_contents(__DIR__ . '/logs/db_errors.log', $e->getMessage() . PHP_EOL, FILE_APPEND);
        return new WP_REST_Response([
            'status_code' => 500,
            'body'        => [
                'status'  => 'failure',
                'message' => 'Lỗi hệ thống: ' . $e->getMessage()
            ]
        ], 500);
    }
}

/**
 * Lấy member_id (ou_id) từ Lark dựa trên display_name
 */
function get_lark_member_id(WP_REST_Request $request) {
    $params       = $request->get_json_params();
    $display_name = sanitize_text_field($params['display_name'] ?? '');

    // Ghi log request ban đầu
    CacheManager::write_log('=== GET_LARK_MEMBER_ID REQUEST ===', [
        'display_name'   => $display_name,
        'request_params' => $params
    ], 'lark_member_id_debug.log');

    if (empty($display_name)) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Thiếu display_name'
        ], 400);
    }

    try {
        // Load Bot Manager để lấy bot credentials
        require_once(dirname(__FILE__, 2) . '/lark/class-checkin-mkt192-message-bot-manager.php');
        $bot_manager = Checkin_MKT192_Message_Bot_Manager::get_instance();

        // Lấy bot cho inventory/salary notifications (những loại dùng interactive bot với approval)
        // Thử inventory trước vì đa số callback là từ stock transactions
        $bot = $bot_manager->get_bot_by_notification_type('inventory');

        // Nếu không tìm thấy, thử salary (cho salary payment confirmations)
        if (!$bot) {
            $bot = $bot_manager->get_bot_by_notification_type('salary');
        }

        if (!$bot || $bot->bot_type !== 'interactive') {
            throw new Exception('Không tìm thấy interactive bot để lấy Lark credentials');
        }

        $app_id     = $bot->app_id;
        $app_secret = $bot->app_secret;
        $chat_id    = $bot->chat_id;

        CacheManager::write_log('Bot credentials retrieved', [
            'app_id'   => $app_id,
            'chat_id'  => $chat_id,
            'bot_type' => $bot->bot_type
        ], 'lark_member_id_debug.log');

        // Lấy access token từ Lark
        $token = get_lark_tenant_access_token($app_id, $app_secret);
        if (!$token) {
            throw new Exception('Không thể lấy Lark access token');
        }

        CacheManager::write_log('Access token retrieved', [
            'token_preview' => substr($token, 0, 20) . '...'
        ], 'lark_member_id_debug.log');

        // Gọi API Lark để lấy danh sách members
        $url = "https://open.larksuite.com/open-apis/im/v1/chats/{$chat_id}/members?member_id_type=open_id";

        CacheManager::write_log('Calling Lark API', [
            'url'     => $url,
            'chat_id' => $chat_id
        ], 'lark_member_id_debug.log');

        $response = wp_remote_get($url, [
            'headers' => [
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'application/json'
            ],
            'timeout' => 30
        ]);

        if (is_wp_error($response)) {
            throw new Exception('Lỗi khi gọi Lark API: ' . $response->get_error_message());
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);

        // Ghi log toàn bộ response từ Lark
        CacheManager::write_log('=== LARK API RESPONSE ===', [
            'status_code' => wp_remote_retrieve_response_code($response),
            'body'        => $body
        ], 'lark_member_id_debug.log');

        if (!isset($body['data']['items']) || empty($body['data']['items'])) {
            CacheManager::write_log('No members found in response', [
                'body_structure' => array_keys($body)
            ], 'lark_member_id_debug.log');

            return new WP_REST_Response([
                'success' => false,
                'message' => 'Không tìm thấy danh sách members từ Lark'
            ], 404);
        }

        // Ghi log danh sách tất cả members
        CacheManager::write_log('All members from Lark', [
            'total_members' => count($body['data']['items']),
            'members'       => array_map(function ($m) {
                return [
                    'member_id'  => $m['member_id']  ?? 'N/A',
                    'name'       => $m['name']       ?? 'N/A',
                    'tenant_key' => $m['tenant_key'] ?? 'N/A'
                ];
            }, $body['data']['items'])
        ], 'lark_member_id_debug.log');

        // Tìm member_id dựa trên display_name
        // So sánh không phân biệt hoa thường và bỏ dấu tiếng Việt
        $normalized_display_name = strtolower(remove_accents($display_name));

        CacheManager::write_log('Starting name matching', [
            'original_name'   => $display_name,
            'normalized_name' => $normalized_display_name
        ], 'lark_member_id_debug.log');

        foreach ($body['data']['items'] as $member) {
            $member_name            = $member['name'] ?? '';
            $normalized_member_name = strtolower(remove_accents($member_name));

            $similarity = 0;
            similar_text($normalized_display_name, $normalized_member_name, $similarity);

            // Ghi log chi tiết từng comparison
            CacheManager::write_log('Comparing names', [
                'input_name'         => $display_name,
                'input_normalized'   => $normalized_display_name,
                'lark_name'          => $member_name,
                'lark_normalized'    => $normalized_member_name,
                'similarity_percent' => $similarity,
                'strpos_check_1'     => strpos($normalized_member_name, $normalized_display_name) !== false,
                'strpos_check_2'     => strpos($normalized_display_name, $normalized_member_name) !== false,
                'member_id'          => $member['member_id']
            ], 'lark_member_id_debug.log');

            // So sánh tương đối: thegiap vs Thế Giáp
            if (strpos($normalized_member_name, $normalized_display_name) !== false ||
                strpos($normalized_display_name, $normalized_member_name) !== false ||
                $similarity > 70) {

                CacheManager::write_log('=== MATCH FOUND ===', [
                    'input_name'   => $display_name,
                    'matched_name' => $member_name,
                    'member_id'    => $member['member_id'],
                    'similarity'   => $similarity
                ], 'lark_member_id_debug.log');

                return new WP_REST_Response([
                    'success' => true,
                    'data'    => [
                        'member_id' => $member['member_id'],
                        'name'      => $member['name']
                    ]
                ], 200);
            }
        }

        // Không tìm thấy
        CacheManager::write_log('=== NO MATCH FOUND ===', [
            'input_name'  => $display_name,
            'searched_in' => count($body['data']['items']) . ' members'
        ], 'lark_member_id_debug.log');

        return new WP_REST_Response([
            'success' => false,
            'message' => "Không tìm thấy member với tên: {$display_name}"
        ], 404);

    } catch (Exception $e) {
        CacheManager::write_log('=== ERROR ===', [
            'display_name' => $display_name,
            'error'        => $e->getMessage(),
            'trace'        => $e->getTraceAsString()
        ], 'lark_member_id_debug.log');

        return new WP_REST_Response([
            'success' => false,
            'message' => 'Lỗi hệ thống: ' . $e->getMessage()
        ], 500);
    }
}
?>
