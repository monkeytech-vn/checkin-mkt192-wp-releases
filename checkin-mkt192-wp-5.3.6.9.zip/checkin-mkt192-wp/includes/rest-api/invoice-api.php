<?php

// ===================================
// MIGRATION: Thêm cột paid_at vào invoices_data
// ===================================
add_action('plugins_loaded', function() {
    global $wpdb;
    $invoices_table = $wpdb->prefix . 'checkin_mkt192_invoices_data';

    // Kiểm tra bảng tồn tại
    if ($wpdb->get_var("SHOW TABLES LIKE '$invoices_table'") === $invoices_table) {
        // Kiểm tra cột paid_at đã tồn tại chưa
        $column_exists = $wpdb->get_results("SHOW COLUMNS FROM $invoices_table LIKE 'paid_at'");
        if (empty($column_exists)) {
            // Thêm cột paid_at - thời điểm thanh toán, chỉ set 1 lần khi chuyển sang status='paid'
            $wpdb->query("ALTER TABLE $invoices_table ADD COLUMN paid_at DATETIME DEFAULT NULL COMMENT 'Thời điểm thanh toán - dùng để tính doanh số ca' AFTER updated_at");
            $wpdb->query("ALTER TABLE $invoices_table ADD KEY idx_paid_at (paid_at)");

            // Backfill: Cập nhật paid_at cho các hóa đơn đã thanh toán
            // Dùng updated_at nếu có, nếu không dùng created_at
            $wpdb->query("UPDATE $invoices_table SET paid_at = COALESCE(updated_at, created_at) WHERE status = 'paid' AND paid_at IS NULL");

            error_log('[Invoice] Migration: Added paid_at column and backfilled data');
        }
    }
});

add_action('rest_api_init', function () {
    // register_rest_route() for /invoices
    register_rest_route('vg/v1', '/invoices/(?P<invoice_id>[a-zA-Z0-9_-]+)', [
        [
            'methods'             => 'GET',
            'callback'            => 'checkin_mkt192_get_invoices_api',
            // Yêu cầu login + kiểm tra scope nếu có cấu hình role: invoices.read
            'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'invoices.read'])
        ],
        [
            'methods'             => 'PUT',
            'callback'            => 'checkin_mkt192_update_invoice_api',
            // Yêu cầu login + scope: invoices.update
            'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'invoices.update'])
        ],
        [
            'methods'             => 'DELETE',
            'callback'            => 'checkin_mkt192_delete_invoice_api',
            // Yêu cầu login + scope: invoices.delete
            'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'invoices.delete'])
        ]
    ]);

    register_rest_route('vg/v1', '/invoices', [
        [
            'methods'             => 'GET',
            'callback'            => 'checkin_mkt192_get_invoices_api',
            'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'invoices.read'])
        ],
        [
            'methods'             => 'POST',
            'callback'            => 'checkin_mkt192_create_invoice_api',
            'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'invoices.create'])
        ]
    ]);

    register_rest_route('vg/v1', '/staff-invoices', [
        [
            'methods'             => 'GET',
            'callback'            => 'checkin_mkt192_get_staff_invoices_api',
            'permission_callback' => checkin_mkt192_permission('login')
        ]
    ]);

    register_rest_route('vg/v1', '/invoices/(?P<invoice_id>[a-zA-Z0-9_-]+)/payment-for-page-review', [
        [
            'methods'             => 'PUT',
            'callback'            => 'checkin_mkt192_update_invoice_api',
            // Public (giữ nguyên hành vi cũ) – có thể chuyển sang token/cap sau
            'permission_callback' => checkin_mkt192_permission('public')
        ]
    ]);

    // register_rest_route() for /send-invoice-message-type-zalo
    register_rest_route('vg/v1', '/send-invoice-message-type-zalo', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_send_invoice_message',
        // Public (giữ nguyên)
        'permission_callback' => checkin_mkt192_permission('public')
    ]);

    register_rest_route('vg/v1', '/invoices/(?P<invoice_id>[a-zA-Z0-9_-]+)/penalty', [
        'methods'             => 'PUT',
        'callback'            => 'checkin_mkt192_update_penalty_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'invoice.penalty'])
    ]);

    register_rest_route('vg/v1', '/invoices/(?P<invoice_id>[a-zA-Z0-9_-]+)/change-staff', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_change_invoice_staff_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'invoice.penalty'])
    ]);
});

    /**
 * Get invoices
 */
function checkin_mkt192_get_invoices_api(WP_REST_Request $request) {
    global $wpdb;
    $invoices_table = $wpdb->prefix . 'checkin_mkt192_invoices_data';
    $details_table  = $wpdb->prefix . 'checkin_mkt192_invoices_data_detail';

    try {
        // Set múi giờ Việt Nam

        // Lấy ngày hôm nay
        $today = date('Y-m-d');

        // Lấy tham số staff_name (nếu có)
        $staff_name = $request->get_param('staff_name');

        // Xây dựng query cơ bản cho hóa đơn
        $query = $wpdb->prepare(
            "SELECT i.* FROM $invoices_table i WHERE DATE(i.created_at) = %s",
            $today
        );

        // Nếu có staff_name, join với bảng details để lọc
        if ($staff_name) {
            $query = $wpdb->prepare(
                "SELECT DISTINCT i.*
                FROM $invoices_table i
                INNER JOIN $details_table d ON i.invoice_id = d.invoice_id
                WHERE DATE(i.created_at) = %s AND d.staff_name = %s",
                $today,
                $staff_name
            );
        }

        // Thêm ORDER BY
        $query .= ' ORDER BY i.created_at DESC';

        // Thêm LIMIT nếu có
        if ($request->get_param('limit')) {
            $limit = (int)$request->get_param('limit');
            $query .= $wpdb->prepare(' LIMIT %d', $limit);
        }

        // Thực thi query lấy hóa đơn
        $invoices = $wpdb->get_results($query, ARRAY_A);

        // Kiểm tra nếu không có hóa đơn
        if (empty($invoices)) {
            return new WP_REST_Response([
                'success' => true,
                'data'    => [],
                'message' => 'Không tìm thấy hóa đơn nào cho ngày hôm nay' . ($staff_name ? ' với staff_name: ' . $staff_name : '')
            ], 200);
        }

        // Lấy chi tiết dịch vụ cho từng hóa đơn
        foreach ($invoices as &$invoice) {
            // Lấy dịch vụ từ bảng details
            $details_query = $wpdb->prepare(
                "SELECT service_id, service_name, price, staff_id, staff_name, is_overtime
                FROM $details_table
                WHERE invoice_id = %s",
                $invoice['invoice_id']
            );
            $services = $wpdb->get_results($details_query, ARRAY_A);

            // Kiểm tra xem hóa đơn có dịch vụ tăng ca không
            $has_overtime = false;
            foreach ($services as $service) {
                if (isset($service['is_overtime']) && $service['is_overtime'] == 1) {
                    $has_overtime = true;
                    break;
                }
            }
            $invoice['has_overtime'] = $has_overtime;

            // Gán mảng services
            $invoice['services'] = array_map(function($service) {
                return [
                    'service_id'   => $service['service_id'],
                    'service_name' => $service['service_name'],
                    'price'        => (float)$service['price'],
                    'staff_id'     => $service['staff_id'],
                    'staff_name'   => $service['staff_name']
                ];
            }, $services);

            // Parse JSON cho images (nếu vẫn lưu dưới dạng JSON)
            if (!empty($invoice['images']) && is_string($invoice['images'])) {
                $decoded_images    = json_decode($invoice['images'], true);
                $invoice['images'] = $decoded_images !== null ? $decoded_images : [];
            } else {
                $invoice['images'] = [];
            }
        }

        return new WP_REST_Response([
            'success' => true,
            'data'    => $invoices,
            'message' => 'Lấy hóa đơn thành công'
        ], 200);

    } catch (Exception $e) {
        error_log('Get cashier invoices today error: ' . $e->getMessage());
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Lỗi hệ thống: ' . $e->getMessage()
        ], 500);
    }

}

/**
 * Create a new invoice
 */
function checkin_mkt192_create_invoice_api(WP_REST_Request $request) {
    $log_dir = __DIR__ . '/logs';
    if (!file_exists($log_dir)) {
        mkdir($log_dir, 0755, true);
    }

    global $wpdb;
    $invoices_table = $wpdb->prefix . 'checkin_mkt192_invoices_data';

    $wpdb->suppress_errors(true);

    try {
        // Start a transaction
        $wpdb->query('START TRANSACTION');

        // Get and sanitize input data
        $data = $request->get_json_params();

        // Tạo mã hóa đơn: HDyymmddxxx
        $date   = new DateTime(current_time('mysql'));
        $year   = $date->format('y');
        $month  = $date->format('m');
        $day    = $date->format('d');
        $prefix = "HD{$year}{$month}{$day}";

        // Tìm mã hóa đơn LỚN NHẤT trong ngày hiện tại (theo invoice_id, không phải created_at)
        // FIX: Sử dụng MAX(invoice_id) thay vì ORDER BY created_at DESC để tránh race condition
        $max_invoice_id = $wpdb->get_var($wpdb->prepare(
            "SELECT MAX(invoice_id) FROM $invoices_table
             WHERE invoice_id LIKE %s",
            $prefix . '%'
        ));

        // Xác định số thứ tự
        $sequence = 1; // Mặc định bắt đầu từ 1
        if ($max_invoice_id && preg_match('/HD\d{6}(\d{3})/', $max_invoice_id, $matches)) {
            $sequence = intval($matches[1]) + 1; // Tăng số thứ tự từ mã lớn nhất
        }

        // Tạo mã hóa đơn
        $sequence_str = str_pad($sequence, 3, '0', STR_PAD_LEFT);
        $invoice_id   = "{$prefix}{$sequence_str}";

        // Kiểm tra xem invoice_id có bị trùng không
        $existing_invoice = $wpdb->get_var($wpdb->prepare(
            "SELECT invoice_id FROM $invoices_table WHERE invoice_id = %s",
            $invoice_id
        ));

        if ($existing_invoice) {
            throw new Exception('Mã hóa đơn đã tồn tại: ' . $invoice_id);
        }

        // Ưu tiên lấy branch_id từ request (chi nhánh user đã chọn trong app)
        // Lấy chi nhánh CHÍNH của user - dùng cho việc gán invoice vào chi nhánh
        // Chi nhánh chính (branch_id) là chi nhánh mặc định khi tạo dữ liệu mới
        $branch_id = 0;
        if (!empty($data['branch_id'])) {
            $branch_id = intval($data['branch_id']);
        } else {
            // Fallback: Lấy chi nhánh CHÍNH từ staff profile
            $branch_id = checkin_mkt192_get_staff_primary_branch_id();
        }

        $insert_data = [
            'invoice_id'               => sanitize_text_field($invoice_id),
            'booking_id'               => sanitize_text_field($data['booking_id'] ?? ''),
            'customer_id'              => sanitize_text_field($data['customer_id']),
            'customer_name'            => html_entity_decode(sanitize_text_field($data['customer_name']), ENT_QUOTES, 'UTF-8'),
            'customer_phone'           => sanitize_text_field($data['customer_phone']),
            'new_customer'             => $data['new_customer'] ? html_entity_decode(sanitize_text_field($data['new_customer']), ENT_QUOTES, 'UTF-8') : null,
            'promo_code'               => sanitize_text_field($data['promo_code'] ?? ''),
            'promo_status'             => sanitize_text_field($data['promo_status'] ?? ''),
            'membership_label'         => html_entity_decode(sanitize_text_field($data['membership_label'] ?? ''), ENT_QUOTES, 'UTF-8'),
            'services'                 => wp_json_encode($data['services'], JSON_UNESCAPED_UNICODE),
            'cashier'                  => null,
            'payment_method'           => $data['payment_method'] ? sanitize_text_field($data['payment_method']) : null,
            'combined_payment_details' => isset($data['combined_payment_details']) ? wp_json_encode($data['combined_payment_details'], JSON_UNESCAPED_UNICODE) : null,
            'promo_name'               => html_entity_decode(sanitize_text_field($data['promo_name'] ?? ''), ENT_QUOTES, 'UTF-8'),
            'subtotal'                 => floatval($data['subtotal']),
            'discount'                 => floatval($data['discount']),
            'tips'                     => floatval($data['tips']),
            'total'                    => floatval($data['total']),
            'status'                   => sanitize_text_field($data['status']),
            'created_user'             => html_entity_decode(sanitize_text_field($data['created_user']), ENT_QUOTES, 'UTF-8'),
            'branch_id'                => $branch_id,
            'created_at'               => $date->format('Y-m-d H:i:s'),
            // ✅ FIXED: Set paid_at nếu tạo hóa đơn với status = 'paid'
            'paid_at'                  => ($data['status'] === 'paid') ? $date->format('Y-m-d H:i:s') : null,
        ];

        $format = ['%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%f', '%f', '%f', '%f', '%s', '%s', '%d', '%s', '%s'];

        // Ghi log dữ liệu insert_data
        $log_content = '[' . date('Y-m-d H:i:s') . "] Tạo hóa đơn mới ID: $invoice_id\n" .
                       "Dữ liệu lưu vào DB:\n" .
                       json_encode($insert_data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) . "\n";
        file_put_contents($log_dir . '/create_invoice.log', $log_content, FILE_APPEND);

        // Insert invoice into invoices table
        $inserted = $wpdb->insert($invoices_table, $insert_data, $format);

        if ($inserted === false) {
            throw new Exception('Lỗi khi tạo hóa đơn: ' . $wpdb->last_error);
        }

        // Commit transaction
        $wpdb->query('COMMIT');

        // Trigger async details sync
        $services    = $data['services'] ?? [];
        $sync_result = true;
        if (!empty($services) && is_array($services)) {
            $sync_result = sync_invoice_details($invoice_id, $data, $insert_data);
        }

        return new WP_REST_Response([
            'success' => true,
            'data'    => $insert_data,
            'message' => 'Hóa đơn đã được tạo' . ($sync_result ? ' và đồng bộ thành công' : ', nhưng đồng bộ chi tiết thất bại')
        ], 201);

    } catch (Exception $e) {
        // Rollback transaction on error
        $wpdb->query('ROLLBACK');
        file_put_contents($log_dir . '/create_invoice.log', '[' . date('Y-m-d H:i:s') . '] Lỗi khi tạo hóa đơn: ' . $e->getMessage() . "\n", FILE_APPEND);
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Lỗi hệ thống: ' . $e->getMessage()
        ], 500);
    } finally {
        // Re-enable error reporting
        $wpdb->suppress_errors(false);
    }
}

/**
 * Update an invoice
 */
function checkin_mkt192_update_invoice_api(WP_REST_Request $request) {
    $log_dir = __DIR__ . '/logs';
    if (!file_exists($log_dir)) {
        mkdir($log_dir, 0755, true);
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'checkin_mkt192_invoices_data';
    $invoice_id = $request->get_param('invoice_id');
    $data       = $request->get_json_params();

    // Suppress WordPress database error output
    $wpdb->suppress_errors(true);

    try {
        // Start a transaction
        $wpdb->query('START TRANSACTION');

        // Validate invoice_id
        if (empty($invoice_id)) {
            throw new Exception('Thiếu invoice_id');
        }

        // Check if invoice exists
        $existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table_name WHERE invoice_id = %s", $invoice_id));
        if (!$existing) {
            throw new Exception('Hóa đơn không tồn tại');
        }

        // Define fields for invoices table
        $fields = [
            'payment_method'           => ['sanitize' => 'sanitize_text_field', 'format' => '%s'],
            'combined_payment_details' => ['sanitize' => function($value) { return wp_json_encode($value, JSON_UNESCAPED_UNICODE); }, 'format' => '%s'],
            'status'                   => ['sanitize' => 'sanitize_text_field', 'format' => '%s'],
            'cashier'                  => ['sanitize' => 'sanitize_text_field', 'format' => '%s'],
            'tips'                     => ['sanitize' => 'floatval', 'format' => '%f'],
            'total'                    => ['sanitize' => 'floatval', 'format' => '%f'],
            'promo_code'               => ['sanitize' => 'sanitize_text_field', 'format' => '%s'],
            'promo_name'               => ['sanitize' => 'sanitize_text_field', 'format' => '%s'],
            'discount'                 => ['sanitize' => 'floatval', 'format' => '%f'],
            'customer_id'              => ['sanitize' => 'sanitize_text_field', 'format' => '%s'],
            'services'                 => ['sanitize' => 'wp_json_encode', 'format' => '%s'],
            'booking_id'               => ['sanitize' => 'sanitize_text_field', 'format' => '%s'],
            'customer_name'            => ['sanitize' => 'sanitize_text_field', 'format' => '%s'],
            'customer_phone'           => ['sanitize' => 'sanitize_text_field', 'format' => '%s'],
            // 'images' cố tình KHÔNG có ở đây: trường này chỉ được ghi bởi upload API
            // và cron convert WebP (qua Checkin_MKT192_Invoice_Images). Nhận images từ
            // client sẽ ghi đè mất URL WebP mà cron vừa cập nhật (client giữ bản cũ
            // là temp URL đã bị xoá file) → ảnh "biến mất" hàng loạt.
            'not_image'                => ['sanitize' => function($value) { return html_entity_decode(is_array($value) ? wp_json_encode($value, JSON_UNESCAPED_UNICODE) : sanitize_text_field($value), ENT_QUOTES, 'UTF-8'); }, 'format' => '%s'],
            'promo_status'             => ['sanitize' => 'sanitize_text_field', 'format' => '%s'],
            'membership_label'         => ['sanitize' => 'sanitize_text_field', 'format' => '%s'],
            'subtotal'                 => ['sanitize' => 'floatval', 'format' => '%f'],
            'updated_at'               => ['sanitize' => 'sanitize_text_field', 'format' => '%s'],
        ];

        $update_data = [];
        $format      = [];

        // ⚠️ 'not_image' BẮT BUỘC nằm trong danh sách này: nút "Not Image" trong app thợ chỉ hiện
        // với hóa đơn đã thanh toán, nếu chặn thì lý do không có ảnh bị nuốt im lặng (bug 09/2026).
        $allowed_fields_if_paid = ['payment_method', 'combined_payment_details', 'tips', 'total', 'not_image'];

        // Field client gửi lên nhưng bị từ chối vì hóa đơn đã thanh toán — phải báo lại,
        // tuyệt đối không im lặng trả success (xem bug not_image 09/2026).
        $rejected_fields = [];

        foreach ($fields as $key => $config) {
            if (array_key_exists($key, $data)) {
                // Nếu đã thanh toán, chỉ cho phép sửa các field trong $allowed_fields_if_paid
                if ($existing->status === 'paid' && !in_array($key, $allowed_fields_if_paid, true)) {
                    $rejected_fields[] = $key;
                    continue;
                }

                $sanitize = $config['sanitize'];
                // Xử lý đặc biệt cho promo_name khi là null
                if ($key === 'promo_name' && $data[$key] === null) {
                    $update_data[$key] = null;
                } else {
                    $update_data[$key] = is_callable($sanitize) ? $sanitize($data[$key]) : $sanitize($data[$key]);
                }
                $format[] = $config['format'];
            }
        }

        // Mọi field client gửi đều bị từ chối → báo lỗi thay vì ghi mỗi updated_at rồi trả success
        if (empty($update_data) && !empty($rejected_fields)) {
            $wpdb->query('ROLLBACK');
            file_put_contents(
                $log_dir . '/update_invoice.log',
                '[' . date('Y-m-d H:i:s') . "] TỪ CHỐI cập nhật hóa đơn $invoice_id (đã thanh toán) - field bị chặn: "
                . implode(', ', $rejected_fields) . "\n",
                FILE_APPEND
            );
            return new WP_REST_Response([
                'success'         => false,
                'code'            => 'invoice_locked_paid',
                'message'         => 'Hóa đơn đã thanh toán nên không lưu được: ' . implode(', ', $rejected_fields),
                'rejected_fields' => $rejected_fields
            ], 409);
        }

        // Nếu hóa đơn đã thanh toán và có cập nhật tips, tính lại total
        if ($existing->status === 'paid' && isset($data['tips'])) {
            $new_tips             = floatval($data['tips']);
            $update_data['total'] = floatval($existing->subtotal) - floatval($existing->discount) + $new_tips;
            if (!in_array('%f', $format)) {
                $format[] = '%f';
            }
        }

        // Set updated_at if not provided
        if (!isset($data['updated_at'])) {
            $update_data['updated_at'] = current_time('mysql');
            $format[]                  = '%s';
        }

        // ✅ FIXED: Set paid_at khi chuyển status thành 'paid' lần đầu
        // paid_at chỉ được set 1 lần duy nhất, dùng để tính doanh số ca
        if (isset($data['status']) && $data['status'] === 'paid' && empty($existing->paid_at)) {
            $update_data['paid_at'] = current_time('mysql');
            $format[]               = '%s';
        }

        // Preserve created_user
        $update_data['created_user'] = $existing->created_user;
        $format[]                    = '%s';

        if (empty($update_data)) {
            throw new Exception('Không có dữ liệu để cập nhật');
        }

        // Perform update on invoices table
        $updated = $wpdb->update(
            $table_name,
            $update_data,
            ['invoice_id' => $invoice_id],
            $format,
            ['%s']
        );

        if ($updated === false) {
            throw new Exception('Lỗi khi cập nhật hóa đơn: ' . $wpdb->last_error);
        }

        // Ghi log dữ liệu insert_data
        $log_content = '[' . date('Y-m-d H:i:s') . "] Cập nhật hóa đơn ID: $invoice_id\n" .
                       "Dữ liệu lưu vào DB:\n" .
                       json_encode($update_data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) . "\n";
        if (!empty($rejected_fields)) {
            $log_content .= 'Field bị từ chối (hóa đơn đã thanh toán): ' . implode(', ', $rejected_fields) . "\n";
        }
        file_put_contents($log_dir . '/update_invoice.log', $log_content, FILE_APPEND);

        // Commit transaction
        $wpdb->query('COMMIT');

        // ✅ Gửi thông báo push khi hóa đơn được thanh toán
        if (isset($data['status']) && $data['status'] === 'paid' && empty($existing->paid_at)) {
            file_put_contents($log_dir . '/payment_notification.log', '[' . date('Y-m-d H:i:s') . "] Điều kiện thông báo thanh toán đúng - invoice_id: $invoice_id\n", FILE_APPEND);

            if (function_exists('checkin_mkt192_notify_payment_success')) {
                // Lấy staff_user_id từ created_user
                $staff_user_id = null;
                if (!empty($existing->created_user)) {
                    $staff_user_id = $wpdb->get_var($wpdb->prepare(
                        "SELECT user_id FROM {$wpdb->prefix}checkin_mkt192_staff WHERE display_name = %s",
                        $existing->created_user
                    ));
                    file_put_contents($log_dir . '/payment_notification.log', '[' . date('Y-m-d H:i:s') . "] Tìm staff_user_id từ created_user: {$existing->created_user} => $staff_user_id\n", FILE_APPEND);
                }
                checkin_mkt192_notify_payment_success($staff_user_id, [
                    'invoice_id'    => $invoice_id,
                    'total'         => $data['total'] ?? $existing->total,
                    'customer_name' => $existing->customer_name,
                    'branch_id'     => $existing->branch_id ?? null
                ]);
            } else {
                file_put_contents($log_dir . '/payment_notification.log', '[' . date('Y-m-d H:i:s') . "] Hàm checkin_mkt192_notify_payment_success không tồn tại!\n", FILE_APPEND);
            }
        }

        // Trigger async details sync
        $sync_result = sync_invoice_details($invoice_id, $data, $existing);

        return new WP_REST_Response([
            'success' => true,
            'message' => 'Cập nhật hóa đơn thành công' . ($sync_result ? '' : ', nhưng đồng bộ chi tiết thất bại')
        ], 200);

    } catch (Exception $e) {
        // Rollback transaction on error
        $wpdb->query('ROLLBACK');
        file_put_contents($log_dir . '/update_invoice.log', '[' . date('Y-m-d H:i:s') . "] Lỗi khi cập nhật hóa đơn $invoice_id: " . $e->getMessage() . "\n", FILE_APPEND);
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Lỗi hệ thống: ' . $e->getMessage()
        ], 500);
    } finally {
        // Re-enable error reporting
        $wpdb->suppress_errors(false);
    }
}

function sync_invoice_details($invoice_id, $data, $existing) {
    $log_dir = __DIR__ . '/logs';
    if (!file_exists($log_dir)) {
        mkdir($log_dir, 0755, true);
    }
    file_put_contents($log_dir . '/sync_invoice_details.log', '[' . date('Y-m-d H:i:s') . "] Bắt đầu đồng bộ chi tiết hóa đơn $invoice_id\n", FILE_APPEND);

    global $wpdb;
    $details_table      = $wpdb->prefix . 'checkin_mkt192_invoices_data_detail';
    $products_table     = $wpdb->prefix . 'checkin_mkt192_products';
    $services_table     = $wpdb->prefix . 'checkin_mkt192_service_data';
    $transactions_table = $wpdb->prefix . 'checkin_mkt192_inventory_transactions';
    $ctkm_table         = $wpdb->prefix . 'checkin_mkt192_ctkm_settings';
    $staff_table        = $wpdb->prefix . 'checkin_mkt192_staff';
    $booking_table      = $wpdb->prefix . 'bookingmkt192_booking_data';

    try {
        $wpdb->query('START TRANSACTION');

        // Handle $existing as either object or array
        $is_object = is_object($existing);
        $services  = isset($data['services']) && is_array($data['services'])
            ? $data['services']
            : json_decode($is_object ? $existing->services : $existing['services'], true);
        if (!is_array($services)) throw new Exception('Dữ liệu services không hợp lệ');

        $existing_details  = $wpdb->get_results($wpdb->prepare("SELECT service_id, quantity, type FROM $details_table WHERE invoice_id = %s", $invoice_id), ARRAY_A);
        $existing_products = array_filter($existing_details, fn($d) => isset($d['type']) && $d['type'] === 'product');

        $new_product_ids = array_filter(array_column($services, 'service_id'), function($id) use ($services) {
            foreach ($services as $s) {
                if (isset($s['service_id'], $s['type']) && $s['service_id'] == $id && $s['type'] === 'product') return true;
            }
            return false;
        });
        $existing_product_ids = array_column($existing_products, 'service_id');

        // Lấy branch_id từ hóa đơn hiện tại
        $invoice_branch_id = $is_object ? ($existing->branch_id ?? 0) : ($existing['branch_id'] ?? 0);

        $deleted_product_ids = array_diff($existing_product_ids, $new_product_ids);
        foreach ($deleted_product_ids as $product_id) {
            $existing_detail = reset(array_filter($existing_products, fn($d) => $d['service_id'] == $product_id));
            $quantity        = isset($existing_detail['quantity']) ? intval($existing_detail['quantity']) : 1;
            handle_inventory_update($product_id, $quantity, 'IN', "Hoàn kho do xóa sản phẩm khỏi hóa đơn $invoice_id", current_time('mysql'), intval($invoice_branch_id));
        }

        $wpdb->delete($details_table, ['invoice_id' => $invoice_id], ['%s']);

        $promo_name = $data['promo_name'] ?? ($is_object ? ($existing->promo_name ?? '') : ($existing['promo_name'] ?? ''));
        $ctkm_value = 0;
        $is_ctkm    = false;
        if (!empty($promo_name)) {
            $promo_data = $wpdb->get_row($wpdb->prepare("SELECT value, promo_type FROM $ctkm_table WHERE ctkm_name = %s", $promo_name));
            if ($promo_data && $promo_data->promo_type === 'ctkm') {
                $ctkm_value = $promo_data->value ? floatval($promo_data->value) : 0;
                $is_ctkm    = true;
            }
        }

        $unique_staff_names = array_unique(array_column($services, 'staff_name'));
        $staff_count        = count($unique_staff_names);
        $discount_per_staff = $staff_count > 0 ? ($ctkm_value / $staff_count) : 0;

        // Tính tips cho các thợ (không áp dụng cho thợ bán sản phẩm)
        $tips            = isset($data['tips']) ? floatval($data['tips']) : floatval($is_object ? ($existing->tips ?? 0) : ($existing['tips'] ?? 0));
        $eligible_staffs = array_filter($services, function($service) {
            return ($service['type'] ?? 'service') !== 'product';
        });
        $unique_eligible_staff_names = array_unique(array_column($eligible_staffs, 'staff_name'));
        $eligible_staff_count        = count($unique_eligible_staff_names);
        $tips_per_staff              = $eligible_staff_count > 0 ? ($tips / $eligible_staff_count) : 0;

        // Lấy status từ data hoặc existing
        $status = isset($data['status']) ? sanitize_text_field($data['status']) : ($is_object ? ($existing->status ?? '') : ($existing['status'] ?? ''));

        $services_by_staff = [];
        foreach ($services as $service) {
            $staff_name                       = html_entity_decode(sanitize_text_field($service['staff_name']), ENT_QUOTES, 'UTF-8');
            $services_by_staff[$staff_name][] = $service;
        }

        foreach ($services_by_staff as $staff_name => $staff_services) {
            $discount_map     = [];
            $service_indexes  = [];
            $chemical_indexes = [];

            foreach ($staff_services as $index => $item) {
                $type = $item['type'] ?? 'service';
                if ($type === 'product') continue;
                $service_type = $item['service_type'] ?? '';
                if ($service_type === 'chemical') {
                    $chemical_indexes[$index] = $item['price'];
                } else {
                    $service_indexes[$index] = $item['price'];
                }
            }

            // Chỉ tính giảm giá nếu có dịch vụ hoặc hóa chất
            if ($discount_per_staff > 0 && (!empty($service_indexes) || !empty($chemical_indexes))) {
                // Lấy danh sách thợ duy nhất có dịch vụ hoặc hóa chất
                $eligible_staffs = array_filter($services_by_staff, function ($items) {
                    foreach ($items as $svc) {
                        if (($svc['type'] ?? 'service') !== 'product') return true;
                    }
                    return false;
                });
                $eligible_staff_count = count($eligible_staffs);

                if ($eligible_staff_count > 0) {
                    $discount_per_eligible_staff = $ctkm_value / $eligible_staff_count;
                    $non_product_count           = count($service_indexes) + count($chemical_indexes);
                    if ($non_product_count > 0) {
                        $discount_per_item = $discount_per_eligible_staff / $non_product_count;
                        foreach ($service_indexes as $i => $price) {
                            $discount_map[$i] = $discount_per_item;
                        }
                        foreach ($chemical_indexes as $i => $price) {
                            $discount_map[$i] = $discount_per_item;
                        }
                    }
                }
            }

            // Cập nhật trạng thái staff theo status hóa đơn
            if (in_array($status, ['pending', 'paid'])) {
                $new_status = ($status === 'pending') ? 'BUSY' : 'ON';
                $wpdb->update(
                    $staff_table,
                    ['status'       => $new_status],
                    ['display_name' => $staff_name],
                    ['%s'],
                    ['%s']
                );
            }

            if ($is_object ? isset($existing->booking_id) : isset($existing['booking_id'])) {
                $booking_status = ($status === 'paid') ? 'success' : 'pending';
                $booking_id     = $is_object ? $existing->booking_id : $existing['booking_id'];
                $wpdb->update(
                    $booking_table,
                    ['status'     => $booking_status],
                    ['id_booking' => $booking_id],
                    ['%s'],
                    ['%s']
                );
            }

            foreach ($staff_services as $i => $service) {
                $type      = $service['type'] ?? 'service';
                $item_name = html_entity_decode(sanitize_text_field($service['service_name']), ENT_QUOTES, 'UTF-8');
                $quantity  = $service['quantity'] ?? 1;

                $item_price   = 0;
                $service_type = null;

                if ($type === 'product') {
                    $item_price = $wpdb->get_var($wpdb->prepare("SELECT price FROM $products_table WHERE product_name = %s", $item_name));
                } else {
                    $service_data = $wpdb->get_row($wpdb->prepare("SELECT service_price, discounted_price, service_type FROM $services_table WHERE service_name = %s", $item_name));
                    if ($service_data) {
                        $item_price   = $is_ctkm && $service_data->discounted_price !== null ? floatval($service_data->service_price) : ($service_data->discounted_price ?? $service_data->service_price);
                        $service_type = $service_data->service_type;
                    } else {
                        $item_price = $service['price'];
                    }
                }

                $item_price    = $item_price ?? $service['price'];
                $subtotal      = $item_price * $quantity;
                $discount      = $discount_map[$i] ?? 0;
                $total         = $subtotal - $discount;
                $total_invoice = floatval($data['total'] ?? ($is_object ? $existing->total : $existing['total']));

                // Kiểm tra tăng ca: Nếu hóa đơn phát sinh từ 20:30 trở đi
                $created_at     = $is_object ? $existing->created_at : $existing['created_at'];
                $created_time   = strtotime($created_at);
                $created_hour   = (int)date('H', $created_time);
                $created_minute = (int)date('i', $created_time);
                $is_overtime    = 0;
                $overtime_value = 0;

                // Chỉ áp dụng tăng ca cho dịch vụ (không phải sản phẩm) và từ 20:30 trở đi
                if ($type !== 'product' && ($created_hour > 20 || ($created_hour == 20 && $created_minute >= 30))) {
                    $is_overtime    = 1;
                    $overtime_value = $total; // Ghi nhận giá trị total vào overtime_value
                }

                $detail_data = [
                    'invoice_id'     => $invoice_id,
                    'service_name'   => $item_name,
                    'type'           => $type,
                    'price'          => $item_price,
                    'quantity'       => $quantity,
                    'subtotal'       => $subtotal,
                    'discount'       => $discount,
                    'total'          => $total,
                    'tips'           => $type === 'product' ? 0 : $tips_per_staff,
                    'total_invoice'  => $total_invoice,
                    'status'         => $status,
                    'staff_name'     => $staff_name,
                    'is_overtime'    => $is_overtime,
                    'overtime_value' => $overtime_value,
                    'branch_id'      => $is_object ? ($existing->branch_id ?? 0) : ($existing['branch_id'] ?? 0),
                    'created_at'     => $is_object ? $existing->created_at : $existing['created_at'],
                    'updated_at'     => current_time('mysql')
                ];

                // Ghi log dữ liệu insert_data
                $log_content = '[' . date('Y-m-d H:i:s') . "] Đồng bộ hóa đơn ID: $invoice_id\n" .
                       "Dữ liệu lưu vào DB:\n" .
                       json_encode($detail_data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT) . "\n";
                file_put_contents($log_dir . '/sync_invoice_details.log', $log_content, FILE_APPEND);

                if (isset($service['service_id'])) $detail_data['service_id'] = sanitize_text_field($service['service_id']);
                if (isset($service['staff_id'])) $detail_data['staff_id']     = sanitize_text_field($service['staff_id']);
                if ($type !== 'product') $detail_data['service_type']         = $service_type;

                $wpdb->insert($details_table, $detail_data);

                if ($type === 'product' && isset($service['service_id'])) {
                    $product_id        = sanitize_text_field($service['service_id']);
                    $filtered_products = array_filter($existing_products, fn($d) => $d['service_id'] == $product_id);
                    $existing_detail   = $filtered_products ? reset($filtered_products) : false;
                    $old_quantity      = $existing_detail ? intval($existing_detail['quantity']) : 0;
                    $stock_change      = $quantity - $old_quantity;
                    if ($stock_change != 0) {
                        $txn_type = $stock_change > 0 ? 'OUT' : 'IN';
                        $txn_qty  = abs($stock_change);
                        $txn_note = $stock_change > 0 ? "Xuất kho cho hóa đơn $invoice_id" : "Hoàn kho do chỉnh sửa số lượng hóa đơn $invoice_id";
                        handle_inventory_update($product_id, $txn_qty, $txn_type, $txn_note, current_time('mysql'), intval($invoice_branch_id));
                    }
                }
            }
        }

        $wpdb->query('COMMIT');
        return true;
    } catch (Exception $e) {
        $wpdb->query('ROLLBACK');
        file_put_contents($log_dir . '/sync_invoice_details.log', '[' . date('Y-m-d H:i:s') . "] Lỗi khi đồng bộ chi tiết hóa đơn $invoice_id: " . $e->getMessage() . "\n", FILE_APPEND);
        return false;
    }
}

/**
 * Handle inventory updates and transaction logging
 * @param int $product_id ID của sản phẩm
 * @param int $quantity Số lượng thay đổi
 * @param string $transaction_type Loại giao dịch ('IN' hoặc 'OUT')
 * @param string $note Ghi chú giao dịch
 * @param string $transaction_date Thời gian giao dịch
 * @param int $branch_id ID chi nhánh của hóa đơn (0 nếu single-branch)
 * @throws Exception Nếu có lỗi khi cập nhật tồn kho hoặc ghi giao dịch
 */
function handle_inventory_update($product_id, $quantity, $transaction_type, $note, $transaction_date, $branch_id = 0) {
    global $wpdb;
    $products_table     = $wpdb->prefix . 'checkin_mkt192_products';
    $transactions_table = $wpdb->prefix . 'checkin_mkt192_inventory_transactions';

    // Find product
    $product = $wpdb->get_row($wpdb->prepare("SELECT id, stock FROM $products_table WHERE id = %d", $product_id));
    if (!$product) {
        throw new Exception("Sản phẩm với ID {$product_id} không tồn tại");
    }

    // Calculate new stock
    $new_stock = $transaction_type === 'OUT' ? $product->stock - $quantity : $product->stock + $quantity;
    if ($new_stock < 0) {
        throw new Exception("Sản phẩm với ID {$product_id} không đủ tồn kho. Tồn kho hiện tại: {$product->stock}");
    }

    // Update stock
    $updated_stock = $wpdb->update(
        $products_table,
        ['stock' => $new_stock, 'updated_at' => current_time('mysql')],
        ['id'    => $product->id],
        ['%d', '%s'],
        ['%d']
    );

    if ($updated_stock === false) {
        throw new Exception('Lỗi khi cập nhật tồn kho sản phẩm: ' . $wpdb->last_error);
    }

    // Generate transaction_id cho giao dịch từ bán hàng (auto-approved)
    $auto_transaction_id = 'SALE-' . date('YmdHis') . '-' . substr(uniqid(), -4);

    // Insert transaction record với status 'HOÀN THÀNH' (tự động duyệt khi bán hàng)
    // Lưu branch_id để tracking theo chi nhánh khi bật multi-branch mode
    $transaction_inserted = $wpdb->insert($transactions_table, [
        'product_id'       => $product->id,
        'transaction_type' => $transaction_type,
        'quantity'         => $quantity,
        'transaction_date' => $transaction_date,
        'note'             => $note,
        'transaction_id'   => $auto_transaction_id,
        'status'           => 'HOÀN THÀNH',
        'branch_id'        => intval($branch_id),
        'created_at'       => current_time('mysql'),
        'updated_at'       => current_time('mysql')
    ], ['%d', '%s', '%d', '%s', '%s', '%s', '%s', '%d', '%s', '%s']);

    if ($transaction_inserted === false) {
        throw new Exception('Lỗi khi ghi giao dịch kho: ' . $wpdb->last_error);
    }
}

function checkin_mkt192_delete_invoice_api(WP_REST_Request $request) {
    global $wpdb;
    $invoices_table     = $wpdb->prefix . 'checkin_mkt192_invoices_data';
    $details_table      = $wpdb->prefix . 'checkin_mkt192_invoices_data_detail';
    $products_table     = $wpdb->prefix . 'checkin_mkt192_products';
    $transactions_table = $wpdb->prefix . 'checkin_mkt192_inventory_transactions';
    $invoice_id         = sanitize_text_field($request->get_param('invoice_id'));

    // Get invoice info before deletion for push notification
    $invoice_info = $wpdb->get_row($wpdb->prepare(
        "SELECT invoice_id, customer_name, total, branch_id FROM $invoices_table WHERE invoice_id = %s",
        $invoice_id
    ), ARRAY_A);

    // Get current user info for notification
    $current_user = wp_get_current_user();
    $deleted_by   = $current_user->display_name ?: $current_user->user_login;

    // Suppress database error output
    $wpdb->suppress_errors(true);

    try {
        // Start transaction
        $wpdb->query('START TRANSACTION');

        // Check if invoice exists
        $existing = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $invoices_table WHERE invoice_id = %s", $invoice_id));
        if ($existing == 0) {
            $wpdb->query('ROLLBACK');
            return new WP_REST_Response([
                'success' => false,
                'message' => 'Hóa đơn không tồn tại'
            ], 404);
        }

        // Get all product-related details for this invoice (bao gồm quantity)
        $details = $wpdb->get_results($wpdb->prepare(
            "SELECT service_id, quantity FROM $details_table WHERE invoice_id = %s AND service_id IN (SELECT id FROM $products_table)",
            $invoice_id
        ));

        // Lấy branch_id từ invoice để ghi vào transaction
        $invoice_branch_id = isset($invoice_info['branch_id']) ? intval($invoice_info['branch_id']) : 0;

        // Revert stock for each product với đúng số lượng
        foreach ($details as $detail) {
            $product = $wpdb->get_row($wpdb->prepare("SELECT stock FROM $products_table WHERE id = %d", $detail->service_id));
            if ($product) {
                $quantity_to_revert = isset($detail->quantity) ? intval($detail->quantity) : 1;
                $new_stock          = $product->stock + $quantity_to_revert; // Revert đúng số lượng
                $updated_stock      = $wpdb->update(
                    $products_table,
                    ['stock' => $new_stock, 'updated_at' => current_time('mysql')],
                    ['id'    => $detail->service_id],
                    ['%d', '%s'],
                    ['%d']
                );

                if ($updated_stock === false) {
                    throw new Exception('Lỗi khi hoàn tác tồn kho: ' . $wpdb->last_error);
                }

                // Generate transaction_id cho giao dịch hoàn kho (auto-approved)
                $revert_transaction_id = 'REVERT-' . date('YmdHis') . '-' . substr(uniqid(), -4);

                // Insert revert transaction với status 'HOÀN THÀNH' (tự động duyệt) và đúng số lượng
                // Lưu branch_id để tracking theo chi nhánh khi bật multi-branch mode
                $transaction_inserted = $wpdb->insert($transactions_table, [
                    'product_id'       => $detail->service_id,
                    'transaction_type' => 'IN',
                    'quantity'         => $quantity_to_revert,
                    'transaction_date' => current_time('mysql'),
                    'note'             => "Hoàn tác xuất kho $quantity_to_revert sp cho hóa đơn $invoice_id bị xóa",
                    'transaction_id'   => $revert_transaction_id,
                    'status'           => 'HOÀN THÀNH',
                    'branch_id'        => $invoice_branch_id,
                    'created_at'       => current_time('mysql'),
                    'updated_at'       => current_time('mysql')
                ], ['%d', '%s', '%d', '%s', '%s', '%s', '%s', '%d', '%s', '%s']);

                if ($transaction_inserted === false) {
                    throw new Exception('Lỗi khi ghi giao dịch hoàn tác: ' . $wpdb->last_error);
                }
            }
        }

        // Delete invoice details
        $deleted_details = $wpdb->delete($details_table, ['invoice_id' => $invoice_id], ['%s']);
        if ($deleted_details === false) {
            throw new Exception('Lỗi khi xóa chi tiết hóa đơn: ' . $wpdb->last_error);
        }

        // Delete invoice
        $deleted_invoice = $wpdb->delete($invoices_table, ['invoice_id' => $invoice_id], ['%s']);
        if ($deleted_invoice === false) {
            throw new Exception('Lỗi khi xóa hóa đơn: ' . $wpdb->last_error);
        }

        // Commit transaction
        $wpdb->query('COMMIT');

        // Send push notification to managers/cashiers about deleted invoice
        if ($invoice_info && function_exists('checkin_mkt192_notify_invoice_deleted')) {
            $invoice_info['deleted_by'] = $deleted_by;
            checkin_mkt192_notify_invoice_deleted($invoice_info);
        }

        return new WP_REST_Response([
            'success' => true,
            'message' => 'Xóa hóa đơn, chi tiết và hoàn tác tồn kho thành công'
        ], 200);

    } catch (Exception $e) {
        // Rollback transaction on error
        $wpdb->query('ROLLBACK');
        error_log('Delete invoice error: ' . $e->getMessage());
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Lỗi hệ thống: ' . $e->getMessage()
        ], 500);
    } finally {
        // Re-enable error reporting
        $wpdb->suppress_errors(false);
    }
}

function checkin_mkt192_get_staff_invoices_api(WP_REST_Request $request) {
    global $wpdb;
    $invoices_table        = $wpdb->prefix . 'checkin_mkt192_invoices_data';
    $details_table         = $wpdb->prefix . 'checkin_mkt192_invoices_data_detail';
    $reviews_online_table  = $wpdb->prefix . 'checkin_mkt192_customer_reviews_online';
    $reviews_offline_table = $wpdb->prefix . 'checkin_mkt192_customer_reviews_off';

    try {
        date_default_timezone_set('Asia/Ho_Chi_Minh');
        // Kiểm tra quyền view_all_invoices thay vì role
        $current_user = wp_get_current_user();
        $display_name = ($current_user && $current_user->exists()) ? trim($current_user->display_name) : '';
        $current_role = function_exists('checkin_mkt192_get_current_staff_role') ? checkin_mkt192_get_current_staff_role() : null;
        $can_view_all = $current_role && function_exists('checkin_mkt192_role_has_scope') ? checkin_mkt192_role_has_scope($current_role, 'invoices.read') : false;

        // Lấy tham số lọc thời gian
        $filter     = sanitize_text_field($request->get_param('filter') ?: 'today');
        $start_date = sanitize_text_field($request->get_param('start_date'));
        $end_date   = sanitize_text_field($request->get_param('end_date'));
        $branch_id  = intval($request->get_param('branch_id') ?: 0);

        // Lấy chi nhánh CHÍNH để filter invoices
        // Chi nhánh chính (branch_id) dùng để lọc dữ liệu theo chi nhánh mặc định của user
        if (checkin_mkt192_is_multi_branch_enabled()) {
            // Nếu branch_id không được cung cấp, lấy chi nhánh CHÍNH từ staff profile
            if (empty($branch_id)) {
                $branch_id = checkin_mkt192_get_staff_primary_branch_id();
            }
        } else {
            // Multi-branch mode disabled: không filter theo branch
            $branch_id = 0;
        }

        // Xây dựng điều kiện thời gian
        $date_condition = '';
        $params         = [];

        // Ưu tiên sử dụng start_date và end_date nếu được cung cấp
        if ($filter === 'custom' && $start_date && $end_date) {
            $start_datetime = date('Y-m-d 00:00:00', strtotime($start_date));
            $end_datetime   = date('Y-m-d 23:59:59', strtotime($end_date));
            $date_condition = 'i.created_at BETWEEN %s AND %s';
            $params[]       = $start_datetime;
            $params[]       = $end_datetime;
        } else {
            switch ($filter) {
                case 'today':
                    $date_condition = 'DATE(i.created_at) = %s';
                    $params[]       = date('Y-m-d');
                    break;
                case 'yesterday':
                    $date_condition = 'DATE(i.created_at) = %s';
                    $params[]       = date('Y-m-d', strtotime('-1 day'));
                    break;
                case '7days':
                    $date_condition = 'i.created_at >= %s';
                    $params[]       = date('Y-m-d 00:00:00', strtotime('-7 days'));
                    break;
                case 'thisMonth':
                    $date_condition = 'YEAR(i.created_at) = %d AND MONTH(i.created_at) = %d';
                    $params[]       = date('Y');
                    $params[]       = date('m');
                    break;
                case 'lastMonth':
                    $date_condition = 'YEAR(i.created_at) = %d AND MONTH(i.created_at) = %d';
                    $params[]       = date('Y', strtotime('-1 month'));
                    $params[]       = date('m', strtotime('-1 month'));
                    break;
                case 'thisYear':
                    // Lấy tất cả hóa đơn từ đầu năm hiện tại đến nay
                    $date_condition = 'YEAR(i.created_at) = %d';
                    $params[]       = date('Y');
                    break;
                default:
                    $date_condition = 'DATE(i.created_at) = %s';
                    $params[]       = date('Y-m-d');
            }
        }

        // Xây dựng query dựa trên permission
        if ($can_view_all) {
            // Có quyền view_all_invoices: Lấy tất cả hóa đơn (trong branch của họ)
            $branch_condition = !empty($branch_id) ? 'AND i.branch_id = %d' : '';
            $branch_params    = !empty($branch_id) ? [$branch_id] : [];

            $query = $wpdb->prepare(
                "SELECT i.*
                FROM $invoices_table i
                WHERE $date_condition $branch_condition
                ORDER BY i.created_at DESC",
                array_merge($params, $branch_params)
            );
        } else {
            // Không có quyền view_all: Chỉ xem hóa đơn của chính mình theo display_name
            if (empty($display_name)) {
                return new WP_REST_Response([
                    'success' => false,
                    'message' => 'Không xác định được nhân viên hiện tại để lọc hóa đơn.'
                ], 400);
            }
            $branch_condition = !empty($branch_id) ? 'AND i.branch_id = %d' : '';
            $branch_params    = !empty($branch_id) ? [$branch_id] : [];

            // Tối ưu: Lấy invoice_ids trước, sau đó query invoices
            $invoice_ids_query = $wpdb->prepare(
                "SELECT DISTINCT d.invoice_id
                FROM $details_table d
                WHERE d.staff_name = %s",
                $display_name
            );
            $invoice_ids = $wpdb->get_col($invoice_ids_query);

            if (empty($invoice_ids)) {
                return new WP_REST_Response([
                    'success' => true,
                    'data'    => [],
                    'message' => 'Không tìm thấy hóa đơn nào cho nhân viên: ' . $display_name
                ], 200);
            }

            $placeholders = implode(',', array_fill(0, count($invoice_ids), '%s'));
            $query        = $wpdb->prepare(
                "SELECT i.*
                FROM $invoices_table i
                WHERE i.invoice_id IN ($placeholders) AND $date_condition $branch_condition
                ORDER BY i.created_at DESC",
                array_merge($invoice_ids, $params, $branch_params)
            );
        }

        // Thêm LIMIT nếu có
        if ($request->get_param('limit')) {
            $limit = (int)$request->get_param('limit');
            $query .= $wpdb->prepare(' LIMIT %d', $limit);
        }

        // Thực thi query lấy hóa đơn
        $invoices = $wpdb->get_results($query, ARRAY_A);

        // Kiểm tra nếu không có hóa đơn
        if (empty($invoices)) {
            return new WP_REST_Response([
                'success' => true,
                'data'    => [],
                'message' => 'Không tìm thấy hóa đơn nào' . (!$can_view_all && $display_name ? (' cho nhân viên: ' . $display_name) : '')
            ], 200);
        }

        // Lấy chi tiết dịch vụ cho từng hóa đơn
        foreach ($invoices as &$invoice) {
            // Lấy details từng invoice (original simple query)
            $services = $wpdb->get_results($wpdb->prepare(
                "SELECT service_id, service_name, price, staff_id, staff_name, quantity, total, type, service_type, is_penalty, is_overtime, overtime_value
                FROM $details_table
                WHERE invoice_id = %s",
                $invoice['invoice_id']
            ), ARRAY_A);

            // Kiểm tra xem hóa đơn có dịch vụ tăng ca không
            $has_overtime = false;
            foreach ($services as $service) {
                if (isset($service['is_overtime']) && $service['is_overtime'] == 1) {
                    $has_overtime = true;
                    break;
                }
            }
            $invoice['has_overtime'] = $has_overtime;

            $invoice['services'] = array_map(function($service) {
                return [
                    'service_id'     => $service['service_id'],
                    'service_name'   => $service['service_name'],
                    'price'          => (float)$service['price'],
                    'staff_id'       => $service['staff_id'],
                    'staff_name'     => $service['staff_name'],
                    'quantity'       => (int)$service['quantity'],
                    'total'          => (float)$service['total'],
                    'type'           => $service['type'],
                    'service_type'   => $service['service_type'],
                    'is_penalty'     => (bool)$service['is_penalty'],
                    'is_overtime'    => (bool)$service['is_overtime'],
                    'overtime_value' => (int)$service['overtime_value'],
                ];
            }, $services);

            // Parse JSON cho images
            if (!empty($invoice['images']) && is_string($invoice['images'])) {
                $decoded_images    = json_decode($invoice['images'], true);
                $invoice['images'] = $decoded_images !== null ? $decoded_images : [];
            } else {
                $invoice['images'] = [];
            }

            // Parse JSON cho not_image
            if (!empty($invoice['not_image']) && is_string($invoice['not_image'])) {
                $decoded_not_image    = json_decode($invoice['not_image'], true);
                $invoice['not_image'] = $decoded_not_image !== null ? $decoded_not_image : [];
            } else {
                $invoice['not_image'] = [];
            }

            // Lấy reviews cho từng invoice (original simple query)
            $online_review = $wpdb->get_row($wpdb->prepare(
                "SELECT service_rating, staff_rating FROM $reviews_online_table WHERE invoice_id = %s",
                $invoice['invoice_id']
            ), ARRAY_A);

            $offline_review = $wpdb->get_row($wpdb->prepare(
                "SELECT service_rating, staff_rating FROM $reviews_offline_table WHERE invoice_id = %s",
                $invoice['invoice_id']
            ), ARRAY_A);

            $invoice['reviews'] = [
                'online'  => $online_review ? [
                    'service_rating' => (int)$online_review['service_rating'],
                    'staff_rating'   => (int)$online_review['staff_rating']
                ] : null,
                'offline' => $offline_review ? [
                    'service_rating' => (int)$offline_review['service_rating'],
                    'staff_rating'   => (int)$offline_review['staff_rating']
                ] : null,
            ];
        }

        return new WP_REST_Response([
            'success' => true,
            'data'    => $invoices,
            'message' => 'Lấy hóa đơn thành công'
        ], 200);

    } catch (Exception $e) {
        error_log('Get staff invoices error: ' . $e->getMessage());
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Lỗi hệ thống: ' . $e->getMessage()
        ], 500);
    }
}

require_once(dirname(__FILE__, 2) . '/zalo/class-checkin-mkt192-zalo-invoice-message.php');

function checkin_mkt192_send_invoice_message($request) {
    global $wpdb;
    $invoices_table = $wpdb->prefix . 'checkin_mkt192_invoices_data';

    $params     = $request->get_params();
    $invoice_id = isset($params['invoice_id']) ? sanitize_text_field($params['invoice_id']) : '';

    if (!$invoice_id) {
        $invoice = $wpdb->get_row("SELECT * FROM $invoices_table WHERE status = 'paid' ORDER BY created_at DESC LIMIT 1");
    } else {
        $invoice = $wpdb->get_row($wpdb->prepare("SELECT * FROM $invoices_table WHERE invoice_id = %s", $invoice_id));
    }

    if (!$invoice) {
        return rest_ensure_response(['success' => false, 'message' => 'Không tìm thấy hóa đơn.']);
    }

    if ($invoice->customer_name === 'Khách vãng lai') {
        return rest_ensure_response(['success' => false, 'message' => 'Không gửi tin nhắn Zalo cho khách vãng lai.']);
    }

    $result = Checkin_MKT192_ZaloInvoiceMessage::send_invoice_message($invoice);

    return rest_ensure_response($result);
}

function checkin_mkt192_update_penalty_api(WP_REST_Request $request) {
    global $wpdb;
    $details_table = $wpdb->prefix . 'checkin_mkt192_invoices_data_detail';
    $invoice_id    = sanitize_text_field($request->get_param('invoice_id'));
    $data          = $request->get_json_params();
    $services      = $data['services'] ?? [];
    $reasons       = $data['reasons']  ?? [];

    // Debug log
    $current_user = wp_get_current_user();
    $role         = function_exists('checkin_mkt192_get_current_staff_role') ? checkin_mkt192_get_current_staff_role() : 'unknown';
    error_log("Penalty API called by user: {$current_user->display_name} (ID: {$current_user->ID}), role: {$role}, invoice_id: {$invoice_id}");

    if (empty($services) || !is_array($services)) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Dữ liệu dịch vụ không hợp lệ'
        ], 400);
    }

    $wpdb->query('START TRANSACTION');

    try {
        $updated = 0;
        foreach ($services as $svc) {
            $service_name = sanitize_text_field($svc['service_name']);
            $staff_name   = sanitize_text_field($svc['staff_name']);

            $result = $wpdb->update(
                $details_table,
                ['is_penalty' => 1],
                [
                    'invoice_id'    => $invoice_id,
                    'service_name'  => $service_name,
                    'staff_name'    => $staff_name
                ],
                ['%d'],
                ['%s', '%s', '%s']
            );

            if ($result === false) {
                throw new Exception('Lỗi cập nhật: ' . $wpdb->last_error);
            }
            $updated += $result;
        }

        $wpdb->query('COMMIT');

        // Gửi thông báo Lark sau khi thành công
        if ($updated > 0 && is_lark_enabled()) {
            require_once(__DIR__ . '/../lark/send_penalty_notification.php');
            $penalty_data = [
                'invoice_id' => $invoice_id,
                'reasons'    => $reasons,
                'services'   => $services
            ];
            $notification_result = send_penalty_notifications($penalty_data);
            // Log kết quả gửi thông báo nhưng không làm fail API nếu gửi thông báo fail
            if (!$notification_result['success']) {
                error_log('Failed to send penalty notifications: ' . json_encode($notification_result));
            }
        }

        return new WP_REST_Response([
            'success' => true,
            'message' => "Đã đánh dấu truy thu phạt cho $updated dịch vụ"
        ], 200);

    } catch (Exception $e) {
        $wpdb->query('ROLLBACK');
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Lỗi: ' . $e->getMessage()
        ], 500);
    }
}

function checkin_mkt192_change_invoice_staff_api(WP_REST_Request $request) {
    global $wpdb;
    $invoices_table     = $wpdb->prefix . 'checkin_mkt192_invoices_data';
    $details_table      = $wpdb->prefix . 'checkin_mkt192_invoices_data_detail';
    $invoice_id         = sanitize_text_field($request->get_param('invoice_id'));
    $data               = $request->get_json_params();
    $services_to_change = $data['services'] ?? [];

    if (empty($services_to_change) || !is_array($services_to_change)) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Dữ liệu không hợp lệ: không có dịch vụ nào được chọn.'
        ], 400);
    }

    $wpdb->query('START TRANSACTION');

    try {
        $updated_count = 0;
        foreach ($services_to_change as $svc) {
            if (empty($svc['service_name']) || empty($svc['staff_name']) || empty($svc['new_staff_id']) || empty($svc['new_staff_name'])) {
                throw new Exception('Dữ liệu dịch vụ hoặc thợ mới không đầy đủ.');
            }

            $service_name   = sanitize_text_field($svc['service_name']);
            $staff_name     = sanitize_text_field($svc['staff_name']);
            $new_staff_id   = sanitize_text_field($svc['new_staff_id']);
            $new_staff_name = sanitize_text_field($svc['new_staff_name']);

            // 1. Lấy dữ liệu của dịch vụ gốc (bao gồm cả dịch vụ đã bị penalty)
            $original_service = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM $details_table WHERE invoice_id = %s AND service_name = %s AND staff_name = %s",
                $invoice_id, $service_name, $staff_name
            ), ARRAY_A);

            if (!$original_service) {
                // Có thể dịch vụ đã được xử lý, bỏ qua để tránh lỗi
                continue;
            }

            // 2. Đánh dấu dịch vụ gốc là đã bị truy thu (nếu chưa bị)
            if ($original_service['is_penalty'] == 0) {
                $penalty_update_result = $wpdb->update(
                    $details_table,
                    ['is_penalty' => 1, 'updated_at' => current_time('mysql')],
                    ['id'         => $original_service['id']],
                    ['%d', '%s'],
                    ['%d']
                );

                if ($penalty_update_result === false) {
                    throw new Exception('Lỗi khi đánh dấu truy thu cho dịch vụ cũ: ' . $wpdb->last_error);
                }
            }

            // 3. Tạo một bản ghi dịch vụ mới cho thợ mới
            $new_service_data = $original_service;
            unset($new_service_data['id']); // Xóa ID để tạo bản ghi mới
            $new_service_data['staff_id']   = $new_staff_id;
            $new_service_data['staff_name'] = $new_staff_name;
            $new_service_data['is_penalty'] = 0; // Dịch vụ mới không bị phạt
            $new_service_data['updated_at'] = current_time('mysql');
            // Giữ nguyên created_at để không ảnh hưởng tới báo cáo gốc

            $insert_result = $wpdb->insert($details_table, $new_service_data);

            if ($insert_result === false) {
                throw new Exception('Lỗi khi tạo dịch vụ mới cho thợ được chuyển đổi: ' . $wpdb->last_error);
            }

            $updated_count++;
        }

        if ($updated_count > 0) {
            // 2. Cập nhật cột `services` JSON trong bảng chính
            $invoice_data = $wpdb->get_row($wpdb->prepare("SELECT services FROM $invoices_table WHERE invoice_id = %s", $invoice_id));
            if ($invoice_data) {
                $services_json = json_decode($invoice_data->services, true);

                if (is_array($services_json)) {
                    foreach ($services_to_change as $svc_to_change) {
                        foreach ($services_json as $key => $service_item) {
                            if ($service_item['service_name'] === $svc_to_change['service_name'] && $service_item['staff_name'] === $svc_to_change['staff_name']) {
                                $services_json[$key]['staff_id']   = $svc_to_change['new_staff_id'];
                                $services_json[$key]['staff_name'] = $svc_to_change['new_staff_name'];
                                break;
                            }
                        }
                    }

                    $wpdb->update(
                        $invoices_table,
                        ['services'   => wp_json_encode($services_json, JSON_UNESCAPED_UNICODE)],
                        ['invoice_id' => $invoice_id],
                        ['%s'],
                        ['%s']
                    );
                }
            }
        }

        if ($updated_count == 0) {
             throw new Exception('Không tìm thấy dịch vụ nào để chuyển đổi.');
        }

        $wpdb->query('COMMIT');

        // Gửi thông báo Lark sau khi thành công
        if ($updated_count > 0 && is_lark_enabled()) {
            require_once(__DIR__ . '/../lark/send_penalty_notification.php');

            // Lấy reasons từ request (nếu có), nếu không thì dùng default
            $reasons = $data['reasons'] ?? ['change_staff'];

            // Tạo note về thợ mới được chuyển đổi
            $staff_change_notes = array_map(function($svc) {
                return $svc['service_name'] . ' → ' . $svc['new_staff_name'];
            }, $services_to_change);
            $staff_change_note = 'Dịch vụ bị truy thu sẽ được chuyển đổi cho: ' . implode(', ', $staff_change_notes);

            $penalty_data = [
                'invoice_id' => $invoice_id,
                'reasons'    => $reasons,
                'note'       => $staff_change_note, // Thêm note về thợ mới
                'services'   => array_map(function($svc) {
                    return [
                        'service_name' => $svc['service_name'],
                        'staff_name'   => $svc['staff_name'] // Staff cũ bị penalty
                    ];
                }, $services_to_change)
            ];
            $notification_result = send_penalty_notifications($penalty_data);
            // Log kết quả gửi thông báo nhưng không làm fail API nếu gửi thông báo fail
            if (!$notification_result['success']) {
                error_log('Failed to send change staff penalty notifications: ' . json_encode($notification_result));
            }
        }

        return new WP_REST_Response([
            'success' => true,
            'message' => "Đã chuyển đổi $updated_count dịch vụ và truy thu thợ cũ thành công!"
        ], 200);

    } catch (Exception $e) {
        $wpdb->query('ROLLBACK');
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Lỗi: ' . $e->getMessage()
        ], 500);
    }
}
