<?php

add_action('rest_api_init', function () {
    register_rest_route('vg/v1', '/zalo-settings', [
        'methods'             => 'GET',
        'callback'            => 'get_zalo_settings',
        'permission_callback' => '__return_true' // Cần thêm kiểm tra quyền truy cập thực tế
    ]);

    register_rest_route('vg/v1', '/zalo-settings', [
        'methods'             => 'POST',
        'callback'            => 'save_zalo_settings',
        'permission_callback' => '__return_true' // Cần thêm kiểm tra quyền truy cập thực tế
    ]);

    register_rest_route('vg/v1', '/zalo-webhook', [
        'methods'             => 'GET',
        'callback'            => 'handle_zalo_webhook',
        'permission_callback' => '__return_true', // Cho phép truy cập không cần xác thực WordPress (tuỳ chỉnh theo nhu cầu bảo mật)
    ]);

    register_rest_route('vg/v1', '/zalo-settings/get-tokens', [
        'methods'             => 'POST',
        'callback'            => 'get_zalo_tokens',
        'permission_callback' => '__return_true' // Thay bằng kiểm tra quyền thực tế
    ]);

    register_rest_route('vg/v1', '/zalo-settings/refresh-tokens', [
        'methods'             => 'POST',
        'callback'            => 'refresh_zalo_tokens',
        'permission_callback' => '__return_true' // Thay bằng kiểm tra quyền thực tế
    ]);

    register_rest_route('vg/v1', '/zalo-templates', [
        'methods'             => 'GET',
        'callback'            => 'get_zalo_templates',
        'permission_callback' => '__return_true'
    ]);

    register_rest_route('vg/v1', '/zalo-template-detail', [
        'methods'             => 'GET',
        'callback'            => 'get_zalo_template_detail',
        'permission_callback' => '__return_true'
    ]);
});

function get_zalo_settings(WP_REST_Request $request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'checkin_mkt192_zalo_config';

    $config      = $wpdb->get_row("SELECT * FROM $table_name LIMIT 1");
    $use_zalo_oa = get_option('checkin_use_zalo_oa', '0');

    if ($config) {
        return new WP_REST_Response(
            [
                'success' => true,
                'data'    => array_merge(
                    (array) $config,
                    ['use_zalo_oa' => $use_zalo_oa]
                )
            ],
            200
        );
    } else {
        return new WP_REST_Response(
            [
                'success' => false,
                'message' => 'Không tìm thấy cấu hình',
                'data'    => ['use_zalo_oa' => $use_zalo_oa]
            ],
            404
        );
    }
}

function save_zalo_settings(WP_REST_Request $request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'checkin_mkt192_zalo_config';
    $data       = $request->get_json_params();

    $app_id      = sanitize_text_field($data['app_id']);
    $app_secret  = sanitize_text_field($data['app_secret']);
    $clear_token = isset($data['clear_token']) && $data['clear_token'] === true;

    if (!$app_id || !$app_secret) {
        return new WP_REST_Response(['success' => false, 'message' => 'Dữ liệu không hợp lệ'], 400);
    }

    $existing = $wpdb->get_row("SELECT id FROM $table_name LIMIT 1");

    $update_data = [
        'app_id'     => $app_id,
        'app_secret' => $app_secret
    ];

    // Nếu có flag clear_token, xóa access_token và refresh_token cũ
    if ($clear_token) {
        $update_data['access_token']  = '';
        $update_data['refresh_token'] = '';
    }

    if ($existing) {
        $result = $wpdb->update(
            $table_name,
            $update_data,
            ['id' => $existing->id]
        );
    } else {
        $result = $wpdb->insert(
            $table_name,
            $update_data
        );
    }

    if ($result !== false) {
        // Sinh PKCE code verifier và code challenge
        $code_verifier = checkin_mkt192_generate_code_verifier();
        $code_challenge = checkin_mkt192_generate_code_challenge($code_verifier);
        update_option('checkin_zalo_code_verifier', $code_verifier);

        $state = wp_generate_password(12, false);
        $redirect_uri = rest_url('vg/v1/zalo-webhook');
        $auth_url = 'https://oauth.zaloapp.com/v4/oa/permission?' . http_build_query([
            'app_id'         => $app_id,
            'redirect_uri'   => $redirect_uri,
            'code_challenge' => $code_challenge,
            'state'          => $state
        ]);

        $message = 'Cập nhật cấu hình thành công';
        if ($clear_token) {
            $message .= ' (đã xóa token cũ)';
        }
        return new WP_REST_Response([
            'success'  => true,
            'message'  => $message,
            'auth_url' => $auth_url,
            'state'    => $state
        ], 200);
    } else {
        return new WP_REST_Response(['success' => false, 'message' => 'Cập nhật thất bại'], 500);
    }
}

function handle_zalo_webhook(WP_REST_Request $request) {
    $code  = $request->get_param('code');
    $state = $request->get_param('state');

    if (!$code || !$state) {
        return new WP_REST_Response(['success' => false, 'message' => 'Thiếu tham số code hoặc state'], 400);
    }

    // Lấy app_id và app_secret từ database
    global $wpdb;
    $table_name = $wpdb->prefix . 'checkin_mkt192_zalo_config';
    $config     = $wpdb->get_row("SELECT app_id, app_secret FROM $table_name LIMIT 1");

    if (!$config) {
        return new WP_REST_Response(['success' => false, 'message' => 'App ID hoặc App Secret không được thiết lập'], 400);
    }

    $appId     = $config->app_id;
    $appSecret = $config->app_secret;

    // Gọi API Zalo để lấy access_token và refresh_token
    $code_verifier = get_option('checkin_zalo_code_verifier', '');
    $tokenUrl      = 'https://oauth.zaloapp.com/v4/oa/access_token';
    $tokenParams   = [
        'code'          => $code,
        'app_id'        => $appId,
        'grant_type'    => 'authorization_code',
        'code_verifier' => $code_verifier
    ];

    $response = wp_remote_post($tokenUrl, [
        'method'  => 'POST',
        'headers' => [
            'Content-Type' => 'application/x-www-form-urlencoded',
            'secret_key'   => $appSecret
        ],
        'body'    => $tokenParams,
        'timeout' => 30
    ]);

    if (is_wp_error($response)) {
        $error = $response->get_error_message();
        checkin_mkt192_log_error('zalo_token', 'HTTP Error when getting Zalo token', ['error' => $error]);
        return new WP_REST_Response(['success' => false, 'message' => 'Lỗi kết nối API: ' . $error], 500);
    }

    $responseBody = wp_remote_retrieve_body($response);
    $httpCode     = wp_remote_retrieve_response_code($response);

    if ($httpCode !== 200) {
        checkin_mkt192_log_error('zalo_token', 'Non-200 HTTP Code when getting Zalo token', [
            'http_code' => $httpCode,
            'response'  => $responseBody
        ]);
    }

    $tokenResult = json_decode($responseBody, true);

    if (isset($tokenResult['access_token']) && isset($tokenResult['refresh_token'])) {
        $accessToken  = $tokenResult['access_token'];
        $refreshToken = $tokenResult['refresh_token'];

        // Lưu access_token và refresh_token vào database
        $existing = $wpdb->get_row("SELECT id FROM $table_name LIMIT 1");
        if ($existing) {
            $wpdb->update(
                $table_name,
                [
                    'access_token'  => $accessToken,
                    'refresh_token' => $refreshToken
                ],
                ['id' => $existing->id]
            );
        } else {
            $wpdb->insert(
                $table_name,
                [
                    'app_id'        => $appId,
                    'app_secret'    => $appSecret,
                    'access_token'  => $accessToken,
                    'refresh_token' => $refreshToken
                ]
            );
        }

        // Gọi API để lấy thông tin OA
        $oaUrl = 'https://openapi.zalo.me/v2.0/oa/getoa';
        $ch    = curl_init();
        curl_setopt($ch, CURLOPT_URL, $oaUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'access_token: ' . $accessToken
        ]);
        $oaResponse = curl_exec($ch);

        if (curl_errno($ch)) {
            $error = curl_error($ch);
            checkin_mkt192_log_error('zalo_oa', 'cURL Error when getting Zalo OA info', ['error' => $error]);
        }
        $oaHttpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if ($oaHttpCode !== 200) {
            checkin_mkt192_log_error('zalo_oa', 'Non-200 HTTP Code when getting Zalo OA info', [
                'http_code' => $oaHttpCode,
                'response'  => $oaResponse
            ]);
        }
        curl_close($ch);

        $oaResult = json_decode($oaResponse, true);

        if (isset($oaResult['data'])) {
            $oaData = $oaResult['data'];
            // Chuyển đổi định dạng ngày từ MM/DD/YYYY sang YYYY-MM-DD
            $packageValidThroughDate = $oaData['package_valid_through_date'];
            $date                    = DateTime::createFromFormat('m/d/Y', $packageValidThroughDate);
            $formattedDate           = $date ? $date->format('Y-m-d') : '0000-00-00';

            // Lưu thông tin OA vào database
            if ($existing) {
                $wpdb->update(
                    $table_name,
                    [
                        'oa_id'                      => $oaData['oa_id'],
                        'oa_name'                    => $oaData['name'],
                        'is_verified'                => $oaData['is_verified'],
                        'num_follower'               => $oaData['num_follower'],
                        'package_name'               => $oaData['package_name'],
                        'package_valid_through_date' => $formattedDate
                    ],
                    ['id' => $existing->id]
                );
            } else {
                $wpdb->insert(
                    $table_name,
                    [
                        'app_id'                     => $appId,
                        'app_secret'                 => $appSecret,
                        'access_token'               => $accessToken,
                        'refresh_token'              => $refreshToken,
                        'oa_id'                      => $oaData['oa_id'],
                        'oa_name'                    => $oaData['name'],
                        'is_verified'                => $oaData['is_verified'],
                        'num_follower'               => $oaData['num_follower'],
                        'package_name'               => $oaData['package_name'],
                        'package_valid_through_date' => $formattedDate
                    ]
                );
            }

            // Đóng popup window thay vì redirect
            // JavaScript sẽ đóng window này và polling sẽ phát hiện token
            echo '<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Zalo OAuth Success</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            color: white;
        }
        .container {
            text-align: center;
            padding: 40px;
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
        }
        .checkmark {
            width: 80px;
            height: 80px;
            margin: 0 auto 20px;
            border-radius: 50%;
            background: #4caf50;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 48px;
            animation: scaleIn 0.3s ease-out;
        }
        @keyframes scaleIn {
            from { transform: scale(0); }
            to { transform: scale(1); }
        }
        h1 { font-size: 24px; margin-bottom: 10px; font-weight: 600; }
        p { font-size: 14px; opacity: 0.9; margin-bottom: 20px; }
        .spinner {
            width: 40px;
            height: 40px;
            margin: 20px auto;
            border: 4px solid rgba(255, 255, 255, 0.3);
            border-top-color: white;
            border-radius: 50%;
            animation: spin 0.8s linear infinite;
        }
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="checkmark">✓</div>
        <h1>Kết nối thành công!</h1>
        <p>Đang xử lý thông tin...</p>
        <div class="spinner"></div>
    </div>
    <script>
        setTimeout(() => {
            window.close();
            // Nếu không tự đóng được (một số browser chặn)
            document.body.innerHTML = `
                <div class="container">
                    <div class="checkmark">✓</div>
                    <h1>Kết nối thành công!</h1>
                    <p>Cửa sổ này sẽ tự động đóng...</p>
                    <p style="margin-top: 20px;">
                        <a href="javascript:window.close();" style="color: white; text-decoration: underline;">
                            Bấm vào đây nếu chưa đóng
                        </a>
                    </p>
                </div>
            `;
        }, 1500);
    </script>
</body>
</html>';
            exit;
        } else {
            return new WP_REST_Response(['success' => false, 'message' => 'Không thể lấy thông tin OA: ' . ($oaResult['message'] ?? 'Không có thông tin lỗi')], 400);
        }
    } else {
        return new WP_REST_Response(['success' => false, 'message' => 'Không thể lấy token từ Zalo: ' . ($tokenResult['error'] ?? $tokenResult['message'] ?? 'Không có thông tin lỗi')], 400);
    }
}

function get_zalo_tokens(WP_REST_Request $request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'checkin_mkt192_zalo_config';
    $data       = $request->get_json_params();

    $app_id     = sanitize_text_field($data['app_id']);
    $app_secret = sanitize_text_field($data['app_secret']);
    $code       = sanitize_text_field($data['code']);

    if (!$app_id || !$app_secret || !$code) {
        return new WP_REST_Response(['success' => false, 'message' => 'App ID, App Secret và Code không được để trống'], 400);
    }

    $code_verifier = get_option('checkin_zalo_code_verifier', '');

    $url  = 'https://oauth.zaloapp.com/v4/oa/access_token';
    $body = [
        'code'          => $code,
        'app_id'        => $app_id,
        'grant_type'    => 'authorization_code',
        'code_verifier' => $code_verifier
    ];

    $headers = [
        'secret_key'   => $app_secret,
        'Content-Type' => 'application/x-www-form-urlencoded'
    ];

    $response = wp_remote_post($url, [
        'method'  => 'POST',
        'headers' => $headers,
        'body'    => $body,
        'timeout' => 30
    ]);

    if (is_wp_error($response)) {
        return new WP_REST_Response(['success' => false, 'message' => 'Lỗi kết nối Zalo API: ' . $response->get_error_message()], 500);
    }

    $response_body = wp_remote_retrieve_body($response);
    $result        = json_decode($response_body, true);

    if (isset($result['access_token']) && isset($result['refresh_token'])) {
        $existing = $wpdb->get_row("SELECT id FROM $table_name LIMIT 1");
        if ($existing) {
            $wpdb->update(
                $table_name,
                [
                    'app_id'        => $app_id,
                    'app_secret'    => $app_secret,
                    'access_token'  => $result['access_token'],
                    'refresh_token' => $result['refresh_token']
                ],
                ['id' => $existing->id]
            );
        } else {
            $wpdb->insert(
                $table_name,
                [
                    'app_id'        => $app_id,
                    'app_secret'    => $app_secret,
                    'access_token'  => $result['access_token'],
                    'refresh_token' => $result['refresh_token']
                ]
            );
        }

        return new WP_REST_Response(['success' => true, 'data' => $result], 200);
    } else {
        return new WP_REST_Response(['success' => false, 'message' => 'Không thể lấy token từ Zalo: ' . ($result['message'] ?? 'Không rõ nguyên nhân')], 400);
    }
}

function refresh_zalo_tokens(WP_REST_Request $request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'checkin_mkt192_zalo_config';

    $config = $wpdb->get_row("SELECT * FROM $table_name LIMIT 1");
    if (!$config) {
        return new WP_REST_Response(['success' => false, 'message' => 'Không tìm thấy cấu hình'], 404);
    }

    $app_id        = $config->app_id;
    $app_secret    = $config->app_secret;
    $refresh_token = $config->refresh_token;

    $url  = 'https://oauth.zaloapp.com/v4/oa/access_token';
    $data = [
        'refresh_token' => $refresh_token,
        'app_id'        => $app_id,
        'grant_type'    => 'refresh_token'
    ];

    $headers = [
        'secret_key'   => $app_secret,
        'Content-Type' => 'application/x-www-form-urlencoded'
    ];

    $response = wp_remote_post($url, [
        'method'  => 'POST',
        'headers' => $headers,
        'body'    => $data,
        'timeout' => 30
    ]);

    if (is_wp_error($response)) {
        return new WP_REST_Response(['success' => false, 'message' => 'Lỗi kết nối Zalo API: ' . $response->get_error_message()], 500);
    }

    $body   = wp_remote_retrieve_body($response);
    $result = json_decode($body, true);

    if (isset($result['access_token']) && isset($result['refresh_token'])) {
        $wpdb->update(
            $table_name,
            [
                'access_token'  => $result['access_token'],
                'refresh_token' => $result['refresh_token']
            ],
            ['id' => $config->id]
        );
        return new WP_REST_Response(['success' => true, 'data' => $result], 200);
    } else {
        return new WP_REST_Response(['success' => false, 'message' => 'Không thể làm mới token: ' . ($result['message'] ?? 'Không rõ nguyên nhân')], 400);
    }
}

function refresh_zalo_tokens_cron() {
    global $wpdb;

    // Tên bảng trong database
    $table_name = $wpdb->prefix . 'checkin_mkt192_zalo_config';

    // Lấy app_id, app_secret, và refresh_token từ bảng
    $config = $wpdb->get_row("SELECT app_id, app_secret, refresh_token FROM $table_name LIMIT 1");

    if (!$config) {
        checkin_mkt192_log_error('zalo_cron', 'Không tìm thấy cấu hình Zalo trong database khi refresh token');
        return;
    }

    // Thông tin API của Zalo
    $url  = 'https://oauth.zaloapp.com/v4/oa/access_token';
    $data = [
        'refresh_token' => $config->refresh_token,
        'app_id'        => $config->app_id,
        'grant_type'    => 'refresh_token'
    ];

    // Tạo chữ ký (code verifier) cho yêu cầu
    $code_verifier = $config->app_secret;
    $headers       = [
        'secret_key'   => $config->app_secret,
        'Content-Type' => 'application/x-www-form-urlencoded'
    ];

    // Gửi yêu cầu tới API Zalo
    $response = wp_remote_post($url, [
        'method'  => 'POST',
        'headers' => $headers,
        'body'    => $data,
        'timeout' => 30
    ]);

    // Kiểm tra lỗi khi gửi yêu cầu
    if (is_wp_error($response)) {
        checkin_mkt192_log_error('zalo_cron', 'Lỗi khi gọi API Zalo refresh token', ['error' => $response->get_error_message()]);
        return;
    }

    // Lấy dữ liệu từ phản hồi
    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    // Kiểm tra phản hồi từ Zalo
    if (isset($data['access_token']) && isset($data['refresh_token'])) {
        // Cập nhật access_token và refresh_token mới vào database
        $wpdb->update(
            $table_name,
            [
                'access_token'  => $data['access_token'],
                'refresh_token' => $data['refresh_token']
            ],
            ['app_id' => $config->app_id],
            ['%s', '%s'],
            ['%s']
        );
        checkin_mkt192_log_info('zalo_cron', 'Làm mới token Zalo thành công');
    } else {
        checkin_mkt192_log_error('zalo_cron', 'Lỗi khi làm mới token Zalo', ['response' => $data]);
    }
}

/**
 * Lấy danh sách ZBS template từ Zalo Business API
 * Chỉ lấy template có trạng thái ENABLE (status=1)
 */
function get_zalo_templates(WP_REST_Request $request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'checkin_mkt192_zalo_config';
    $config     = $wpdb->get_row("SELECT access_token FROM $table_name LIMIT 1");

    if (!$config || empty($config->access_token)) {
        return new WP_REST_Response(['success' => false, 'message' => 'Chưa kết nối Zalo OA hoặc access token không hợp lệ'], 401);
    }

    $offset = $request->get_param('offset') ?? 0;
    $limit  = $request->get_param('limit') ?? 100;

    $url = add_query_arg([
        'offset' => intval($offset),
        'limit'  => intval($limit),
        'status' => 1, // ENABLE only
    ], 'https://business.openapi.zalo.me/template/all');

    $response = wp_remote_get($url, [
        'headers' => [
            'Content-Type'  => 'application/json',
            'access_token'  => $config->access_token,
        ],
        'timeout' => 15,
    ]);

    if (is_wp_error($response)) {
        return new WP_REST_Response(['success' => false, 'message' => 'Lỗi kết nối: ' . $response->get_error_message()], 500);
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    if (isset($data['error']) && $data['error'] !== 0) {
        return new WP_REST_Response([
            'success' => false,
            'message' => $data['message'] ?? 'Lỗi từ Zalo API',
            'error'   => $data['error'],
        ], 400);
    }

    return new WP_REST_Response([
        'success'  => true,
        'data'     => $data['data'] ?? [],
        'metadata' => $data['metadata'] ?? [],
    ], 200);
}

/**
 * Lấy chi tiết ZBS template từ Zalo Business API
 */
function get_zalo_template_detail(WP_REST_Request $request) {
    global $wpdb;
    $table_name  = $wpdb->prefix . 'checkin_mkt192_zalo_config';
    $config      = $wpdb->get_row("SELECT access_token FROM $table_name LIMIT 1");
    $template_id = $request->get_param('template_id');

    if (!$config || empty($config->access_token)) {
        return new WP_REST_Response(['success' => false, 'message' => 'Chưa kết nối Zalo OA'], 401);
    }

    if (empty($template_id)) {
        return new WP_REST_Response(['success' => false, 'message' => 'Thiếu template_id'], 400);
    }

    $url = add_query_arg([
        'template_id' => sanitize_text_field($template_id),
    ], 'https://business.openapi.zalo.me/template/info/v2');

    $response = wp_remote_get($url, [
        'headers' => [
            'Content-Type'  => 'application/json',
            'access_token'  => $config->access_token,
        ],
        'timeout' => 15,
    ]);

    if (is_wp_error($response)) {
        return new WP_REST_Response(['success' => false, 'message' => 'Lỗi kết nối: ' . $response->get_error_message()], 500);
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    if (isset($data['error']) && $data['error'] !== 0) {
        return new WP_REST_Response([
            'success' => false,
            'message' => $data['message'] ?? 'Lỗi từ Zalo API',
            'error'   => $data['error'],
        ], 400);
    }

    return new WP_REST_Response([
        'success' => true,
        'data'    => $data['data'] ?? [],
    ], 200);
}

/**
 * Sinh PKCE code verifier (chuỗi ngẫu nhiên từ 43 đến 128 ký tự).
 */
function checkin_mkt192_generate_code_verifier() {
    $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~';
    $verifier = '';
    for ($i = 0; $i < 43; $i++) {
        $verifier .= $chars[random_int(0, strlen($chars) - 1)];
    }
    return $verifier;
}

/**
 * Sinh PKCE code challenge = Base64URL-ENCODE(SHA256(ASCII(code_verifier)))
 */
function checkin_mkt192_generate_code_challenge($verifier) {
    $hash = hash('sha256', $verifier, true);
    $base64 = base64_encode($hash);
    $base64url = strtr($base64, '+/', '-_');
    return rtrim($base64url, '=');
}