<?php

// Register REST API endpoints for Service Groups
add_action('rest_api_init', function () {
    // GET: Fetch all service groups
    register_rest_route('vg/v1', '/service-groups', [
        'methods'             => 'GET',
        'callback'            => 'get_service_groups',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'service_group.read'])
    ]);

    // POST: Create a new service group
    register_rest_route('vg/v1', '/service-groups', [
        'methods'             => 'POST',
        'callback'            => 'create_service_group',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'service_group.create'])
    ]);

    // PUT: Update a service group
    register_rest_route('vg/v1', '/service-groups/(?P<id>\d+)', [
        'methods'             => 'PUT',
        'callback'            => 'update_service_group',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'service_group.update'])
    ]);

    // DELETE: Delete a service group
    register_rest_route('vg/v1', '/service-groups/(?P<id>\d+)', [
        'methods'             => 'DELETE',
        'callback'            => 'delete_service_group',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'service_group.delete'])
    ]);
});

function get_service_groups($request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'checkin_mkt192_service_groups';
    $groups     = $wpdb->get_results("SELECT * FROM $table_name", ARRAY_A);
    return rest_ensure_response([
        'success' => true,
        'data'    => $groups,
    ]);
}

function create_service_group($request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'checkin_mkt192_service_groups';
    $data       = $request->get_json_params();

    if (empty($data['name'])) {
        return new WP_Error('invalid_data', 'Tên nhóm dịch vụ là bắt buộc', ['status' => 400]);
    }

    $result = $wpdb->insert($table_name, [
        'name' => sanitize_text_field($data['name']),
    ]);

    if ($result === false) {
        return new WP_Error('db_error', 'Lỗi khi thêm nhóm dịch vụ: ' . $wpdb->last_error, ['status' => 500]);
    }

    return rest_ensure_response([
        'success' => true,
        'message' => 'Thêm nhóm dịch vụ thành công',
        'data'    => ['id' => $wpdb->insert_id],
    ]);
}

function update_service_group($request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'checkin_mkt192_service_groups';
    $id         = $request['id'];
    $data       = $request->get_json_params();

    if (empty($data['name'])) {
        return new WP_Error('invalid_data', 'Tên nhóm dịch vụ là bắt buộc', ['status' => 400]);
    }

    $result = $wpdb->update($table_name, [
        'name' => sanitize_text_field($data['name']),
    ], ['id' => $id]);

    if ($result === false) {
        return new WP_Error('db_error', 'Lỗi khi cập nhật nhóm dịch vụ: ' . $wpdb->last_error, ['status' => 500]);
    }

    return rest_ensure_response([
        'success' => true,
        'message' => 'Cập nhật nhóm dịch vụ thành công',
    ]);
}

function delete_service_group($request) {
    global $wpdb;
    $table_name    = $wpdb->prefix . 'checkin_mkt192_service_groups';
    $service_table = $wpdb->prefix . 'checkin_mkt192_service_data';
    $id            = $request['id'];

    // Kiểm tra xem nhóm có đang được sử dụng
    $in_use = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $service_table WHERE service_group = %d", $id));
    if ($in_use > 0) {
        return new WP_Error('group_in_use', 'Không thể xóa nhóm này vì đang được sử dụng', ['status' => 400]);
    }

    $result = $wpdb->delete($table_name, ['id' => $id]);

    if ($result === false) {
        return new WP_Error('db_error', 'Lỗi khi xóa nhóm dịch vụ: ' . $wpdb->last_error, ['status' => 500]);
    }

    return rest_ensure_response([
        'success' => true,
        'message' => 'Xóa nhóm dịch vụ thành công',
    ]);
}
?>