<?php

add_action('rest_api_init', function () {
    // Endpoint để lấy danh sách tất cả ca làm việc
    register_rest_route('vg/v1', '/shifts', [
        'methods'             => 'GET',
        'callback'            => 'checkin_mkt192_get_shifts_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'shift.read'])
    ]);

    // Endpoint để thêm ca làm việc mới
    register_rest_route('vg/v1', '/shifts', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_save_shift_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'shift.create']),
    ]);

    // Endpoint để cập nhật ca làm việc
    register_rest_route('vg/v1', '/shifts/(?P<id>\d+)', [
        'methods'             => 'PUT',
        'callback'            => 'checkin_mkt192_update_shift_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'shift.update']),
    ]);

    // Endpoint để xóa ca làm việc
    register_rest_route('vg/v1', '/shifts/(?P<id>\d+)', [
        'methods'             => 'DELETE',
        'callback'            => 'checkin_mkt192_delete_shift_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'shift.delete']),
    ]);
});

function checkin_mkt192_get_shifts_api(WP_REST_Request $request) {
    global $wpdb;

    try {
        $branch_id = intval($request->get_param('branch_id') ?: 0);

        $query = "SELECT id, shift_group, shift_name, start_time, end_time, branch_id, early_checkin, late_checkin, late_allowed, early_checkout, late_checkout
             FROM {$wpdb->prefix}checkin_mkt192_shiftsettings";

        if ($branch_id > 0) {
            $query .= $wpdb->prepare(' WHERE branch_id = %d', $branch_id);
        }

        $query .= ' ORDER BY shift_name';

        $shifts = $wpdb->get_results($query, ARRAY_A);
        return new WP_REST_Response(['success' => true, 'data' => $shifts], 200);
    } catch (Exception $e) {
        file_put_contents(
            CHECKIN_PLUGIN_DIR . '/includes/rest-api/logs/shift_errors.log',
            date('Y-m-d H:i:s') . ' - Failed to fetch shifts: ' . $e->getMessage() . "\n",
            FILE_APPEND
        );
        return new WP_Error('fetch_failed', 'Lỗi khi lấy danh sách ca: ' . $e->getMessage(), ['status' => 500]);
    }
}

function checkin_mkt192_save_shift_api(WP_REST_Request $request) {
    global $wpdb;
    $data = $request->get_json_params();

    $shift_group    = isset($data['shift_group']) ? sanitize_text_field($data['shift_group']) : '';
    $shift_name     = isset($data['shift_name']) ? sanitize_text_field($data['shift_name']) : '';
    $start_time     = isset($data['start_time']) ? sanitize_text_field($data['start_time']) : '';
    $end_time       = isset($data['end_time']) ? sanitize_text_field($data['end_time']) : '';
    $branch_id      = isset($data['branch_id']) ? intval($data['branch_id']) : 0;
    $early_checkin  = isset($data['early_checkin']) ? intval($data['early_checkin']) : 0;
    $late_checkin   = isset($data['late_checkin']) ? intval($data['late_checkin']) : 0;
    $late_allowed   = isset($data['late_allowed']) ? intval($data['late_allowed']) : 0;
    $early_checkout = isset($data['early_checkout']) ? intval($data['early_checkout']) : 0;
    $late_checkout  = isset($data['late_checkout']) ? intval($data['late_checkout']) : 0;

    if (empty($shift_name) || empty($start_time) || empty($end_time)) {
        return new WP_Error('missing_required_fields', 'Thiếu thông tin bắt buộc: tên ca, giờ bắt đầu, hoặc giờ kết thúc', ['status' => 400]);
    }

    try {
        // Cho phép trùng tên ca vì nhiều vai trò có thể có cùng loại ca
        $result = $wpdb->insert(
            "{$wpdb->prefix}checkin_mkt192_shiftsettings",
            [
                'shift_group'    => $shift_group,
                'shift_name'     => $shift_name,
                'start_time'     => $start_time,
                'end_time'       => $end_time,
                'branch_id'      => $branch_id,
                'early_checkin'  => $early_checkin,
                'late_checkin'   => $late_checkin,
                'late_allowed'   => $late_allowed,
                'early_checkout' => $early_checkout,
                'late_checkout'  => $late_checkout
            ],
            ['%s', '%s', '%s', '%s', '%d', '%d', '%d', '%d', '%d', '%d']
        );

        if ($result === false) {
            throw new Exception('Không thể thêm ca làm việc');
        }

        return new WP_REST_Response(['success' => true, 'message' => 'Thêm ca làm việc thành công'], 200);
    } catch (Exception $e) {
        file_put_contents(
            CHECKIN_PLUGIN_DIR . '/includes/rest-api/logs/shift_errors.log',
            date('Y-m-d H:i:s') . ' - Failed to save shift: ' . $e->getMessage() . "\n",
            FILE_APPEND
        );
        return new WP_Error('save_failed', 'Lỗi khi thêm ca: ' . $e->getMessage(), ['status' => 500]);
    }
}

function checkin_mkt192_update_shift_api(WP_REST_Request $request) {
    global $wpdb;
    $id   = intval($request->get_param('id'));
    $data = $request->get_json_params();

    $shift_group    = isset($data['shift_group']) ? sanitize_text_field($data['shift_group']) : '';
    $shift_name     = isset($data['shift_name']) ? sanitize_text_field($data['shift_name']) : '';
    $start_time     = isset($data['start_time']) ? sanitize_text_field($data['start_time']) : '';
    $end_time       = isset($data['end_time']) ? sanitize_text_field($data['end_time']) : '';
    $branch_id      = isset($data['branch_id']) ? intval($data['branch_id']) : 0;
    $early_checkin  = isset($data['early_checkin']) ? intval($data['early_checkin']) : 0;
    $late_checkin   = isset($data['late_checkin']) ? intval($data['late_checkin']) : 0;
    $late_allowed   = isset($data['late_allowed']) ? intval($data['late_allowed']) : 0;
    $early_checkout = isset($data['early_checkout']) ? intval($data['early_checkout']) : 0;
    $late_checkout  = isset($data['late_checkout']) ? intval($data['late_checkout']) : 0;

    if (empty($id)) {
        return new WP_Error('missing_shift_id', 'Vui lòng cung cấp ID ca làm việc', ['status' => 400]);
    }

    if (empty($shift_name) || empty($start_time) || empty($end_time)) {
        return new WP_Error('missing_required_fields', 'Thiếu thông tin bắt buộc: tên ca, giờ bắt đầu, hoặc giờ kết thúc', ['status' => 400]);
    }

    try {
        // Ghi log dữ liệu đầu vào
        file_put_contents(
            CHECKIN_PLUGIN_DIR . '/includes/rest-api/logs/shift_errors.log',
            date('Y-m-d H:i:s') . " - Update shift ID {$id}: input data = shift_group='{$shift_group}', shift_name='{$shift_name}', start_time='{$start_time}', end_time='{$end_time}', branch_id='{$branch_id}'\n",
            FILE_APPEND
        );

        // Kiểm tra xem ca có tồn tại không
        $exists = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}checkin_mkt192_shiftsettings WHERE id = %d",
            $id
        ));

        // Ghi log để gỡ lỗi
        file_put_contents(
            CHECKIN_PLUGIN_DIR . '/includes/rest-api/logs/shift_errors.log',
            date('Y-m-d H:i:s') . " - Checking existence of shift ID {$id}: exists = {$exists}\n",
            FILE_APPEND
        );

        if ($exists == 0) {
            return new WP_Error('shift_not_found', 'Không tìm thấy ca làm việc với ID này', ['status' => 404]);
        }

        // Cho phép trùng tên ca vì nhiều vai trò có thể có cùng loại ca
        $result = $wpdb->update(
            "{$wpdb->prefix}checkin_mkt192_shiftsettings",
            [
                'shift_group'    => $shift_group,
                'shift_name'     => $shift_name,
                'start_time'     => $start_time,
                'end_time'       => $end_time,
                'branch_id'      => $branch_id,
                'early_checkin'  => $early_checkin,
                'late_checkin'   => $late_checkin,
                'late_allowed'   => $late_allowed,
                'early_checkout' => $early_checkout,
                'late_checkout'  => $late_checkout
            ],
            ['id' => $id],
            ['%s', '%s', '%s', '%s', '%d', '%d', '%d', '%d', '%d', '%d'],
            ['%d']
        );

        // Ghi log kết quả cập nhật
        file_put_contents(
            CHECKIN_PLUGIN_DIR . '/includes/rest-api/logs/shift_errors.log',
            date('Y-m-d H:i:s') . " - Update shift ID {$id}: result = {$result} (type: " . gettype($result) . '), last_error = ' . $wpdb->last_error . "\n",
            FILE_APPEND
        );

        if ($result === false) {
            throw new Exception('Không thể cập nhật ca làm việc: ' . $wpdb->last_error);
        }

        return new WP_REST_Response(['success' => true, 'message' => 'Cập nhật ca làm việc thành công'], 200);
    } catch (Exception $e) {
        file_put_contents(
            CHECKIN_PLUGIN_DIR . '/includes/rest-api/logs/shift_errors.log',
            date('Y-m-d H:i:s') . " - Failed to update shift ID {$id}: " . $e->getMessage() . "\n",
            FILE_APPEND
        );
        return new WP_Error('update_failed', 'Lỗi khi cập nhật ca: ' . $e->getMessage(), ['status' => 500]);
    }
}

function checkin_mkt192_delete_shift_api(WP_REST_Request $request) {
    global $wpdb;
    $id = intval($request->get_param('id'));

    try {
        // Kiểm tra xem ca có tồn tại không
        $exists = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}checkin_mkt192_shiftsettings WHERE id = %d",
            $id
        ));

        // Ghi log để gỡ lỗi
        file_put_contents(
            CHECKIN_PLUGIN_DIR . '/includes/rest-api/logs/shift_errors.log',
            date('Y-m-d H:i:s') . " - Checking existence of shift ID {$id}: exists = {$exists}\n",
            FILE_APPEND
        );

        if ($exists == 0) {
            return new WP_Error('shift_not_found', 'Không tìm thấy ca làm việc để xóa', ['status' => 404]);
        }

        // Thực hiện xóa
        $result = $wpdb->delete(
            "{$wpdb->prefix}checkin_mkt192_shiftsettings",
            ['id' => $id],
            ['%d']
        );

        // Ghi log kết quả xóa
        file_put_contents(
            CHECKIN_PLUGIN_DIR . '/includes/rest-api/logs/shift_errors.log',
            date('Y-m-d H:i:s') . " - Delete shift ID {$id}: result = {$result}\n",
            FILE_APPEND
        );

        if ($result === false || $result === 0) {
            throw new Exception('Không thể xóa ca làm việc');
        }

        return new WP_REST_Response(['success' => true, 'message' => 'Xóa ca làm việc thành công'], 200);
    } catch (Exception $e) {
        file_put_contents(
            CHECKIN_PLUGIN_DIR . '/includes/rest-api/logs/shift_errors.log',
            date('Y-m-d H:i:s') . " - Failed to delete shift ID {$id}: " . $e->getMessage() . "\n",
            FILE_APPEND
        );
        return new WP_Error('delete_failed', 'Lỗi khi xóa ca: ' . $e->getMessage(), ['status' => 500]);
    }
}
?>
