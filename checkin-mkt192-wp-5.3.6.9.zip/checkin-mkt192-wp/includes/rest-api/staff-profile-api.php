<?php

add_action('rest_api_init', function () {
    // Endpoint tạo người dùng WordPress mới
    register_rest_route('vg/v1', '/create-user', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_create_user_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'staff.create']),
        'args'                => [
            'user_login' => [
                'required'          => true,
                'type'              => 'string',
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'user_email' => [
                'required'          => true,
                'type'              => 'string',
                'sanitize_callback' => 'sanitize_email',
            ],
            'display_name' => [
                'required'          => true,
                'type'              => 'string',
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'user_pass' => [
                'required'          => true,
                'type'              => 'string',
                'sanitize_callback' => 'sanitize_text_field',
            ],
        ],
    ]);

    register_rest_route('vg/v1', '/staff', [
        'methods'             => 'GET',
        'callback'            => 'checkin_mkt192_get_staff_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'staff.read'])
    ]);
    register_rest_route('vg/v1', '/staff', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_save_staff_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'staff.create'])
    ]);
    register_rest_route('vg/v1', '/staff/(?P<id>\d+)', [
        'methods'             => 'PUT',
        'callback'            => 'checkin_mkt192_update_staff_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'staff.update'])
    ]);
    register_rest_route('vg/v1', '/staff/(?P<id>\d+)', [
        'methods'             => 'DELETE',
        'callback'            => 'checkin_mkt192_delete_staff_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'staff.delete'])
    ]);

    register_rest_route('vg/v1', '/staff-status', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_update_staff_status',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'staff.update_status'])
    ]);

    // User Profile - Self-service endpoints
    register_rest_route('vg/v1', '/user-profile', [
        'methods'             => 'GET',
        'callback'            => 'checkin_mkt192_wp_get_user_profile',
        'permission_callback' => function () { return is_user_logged_in(); } // Self-service, no scope needed
    ]);

    register_rest_route('vg/v1', '/staff-update-avatar', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_wp_staff_update_user_avatar',
        'permission_callback' => function () { return is_user_logged_in(); } // Self-service, no scope needed
    ]);

    // Endpoint cập nhật hồ sơ
    register_rest_route('vg/v1', '/staff-update-profile', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt_update_user_profile',
        'permission_callback' => function () { return is_user_logged_in(); } // Self-service, no scope needed
    ]);

    // register_rest_route() for /update-checkin-post
    register_rest_route('vg/v1', '/staff-update-social-post', [
    'methods'             => 'POST',
    'callback'            => 'checkin_mkt192_wp_staff_update_social_post',
    'permission_callback' => '__return_true', // Public for webhooks/extensions
    'args'                => [
        'display_name' => [
            'required'          => true,
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
        ],
        'post_type' => [
            'required'          => true,
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
        ],
        'post_id' => [
            'required'          => true,
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
        ],
        'post_date' => [
            'required'          => true,
            'type'              => 'string',
            'validate_callback' => function($param) {
                return preg_match('/^\d{4}-\d{2}-\d{2}$/', $param);
            },
        ],
        'nonce' => [
            'required'          => true,
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
        ],
    ],
]);
});

function checkin_mkt192_create_user_api(WP_REST_Request $request) {
    $user_login   = sanitize_text_field($request['user_login']);
    $user_email   = sanitize_email($request['user_email']);
    $display_name = sanitize_text_field($request['display_name']);
    $user_pass    = sanitize_text_field($request['user_pass']);

    // Kiểm tra user_login đã tồn tại
    if (username_exists($user_login)) {
        return new WP_Error('username_exists', 'Tên đăng nhập đã tồn tại', ['status' => 400]);
    }

    // Kiểm tra email đã tồn tại
    if (email_exists($user_email)) {
        return new WP_Error('email_exists', 'Email đã tồn tại', ['status' => 400]);
    }

    // Tạo người dùng mới với role mặc định là 'staff'
    $user_id = wp_insert_user([
        'user_login'   => $user_login,
        'user_email'   => $user_email,
        'display_name' => $display_name,
        'user_pass'    => $user_pass,
        'role'         => 'staff', // Role mặc định
    ]);

    if (is_wp_error($user_id)) {
        file_put_contents(
            __DIR__ . '/../lark/logs/staff_errors.log',
            date('Y-m-d H:i:s') . ' - Failed to create user: ' . $user_id->get_error_message() . "\n",
            FILE_APPEND
        );
        return new WP_Error('create_user_failed', 'Không thể tạo người dùng: ' . $user_id->get_error_message(), ['status' => 500]);
    }

    return new WP_REST_Response([
        'success' => true,
        'data'    => ['user_id' => $user_id],
        'message' => 'Tạo người dùng thành công',
    ], 200);
}

function checkin_mkt192_get_staff_api(WP_REST_Request $request) {
    global $wpdb;

    try {
        $is_admin = false;

        $context = $request->get_param('context');
        if ($context === 'admin') {
            $is_admin = true;
        }

        // Lấy branch_id từ request - null nghĩa là lấy tất cả
        $branch_id_param = $request->get_param('branch_id');
        $branch_id       = ($branch_id_param !== null && $branch_id_param !== '') ? intval($branch_id_param) : null;

        // Query tất cả staff trước, filter sau bằng PHP để xử lý JSON chính xác
        $where_sql = '';
        if (!$is_admin) {
            $where_sql = "WHERE status != 'DELETED'";
        }

        $query = "SELECT user_id, employee_id, display_name, user_email, user_role, user_login, avatar, status, branch, branch_id, phone
                  FROM {$wpdb->prefix}checkin_mkt192_staff
                  {$where_sql}
                  ORDER BY display_name ASC";

        $all_staff = $wpdb->get_results($query, OBJECT);

        // Parse branch JSON và filter
        $staff = [];

        foreach ($all_staff as $member) {
            $branch_data = [];

            if (!empty($member->branch)) {
                // Thử parse JSON trước
                $decoded = json_decode($member->branch, true);
                if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
                    $branch_data = array_map('intval', $decoded);
                } elseif (is_numeric($member->branch)) {
                    // Nếu là số đơn lẻ (legacy data)
                    $branch_data = [intval($member->branch)];
                }
            }

            // Fallback to branch_id nếu branch trống
            if (empty($branch_data) && !empty($member->branch_id)) {
                $branch_data = [intval($member->branch_id)];
            }
            $member->user_branch = $branch_data;

            // Filter theo branch_id nếu có
            if ($branch_id !== null && $branch_id > 0) {
                // Kiểm tra xem nhân viên có thuộc chi nhánh này không
                if (in_array((int)$branch_id, $branch_data, false)) {
                    $staff[] = $member;
                }
            } else {
                // Không filter - lấy tất cả
                $staff[] = $member;
            }
        }

        if (empty($staff)) {
            return new WP_REST_Response([
                'success' => true,
                'data'    => [],
                'message' => 'Không tìm thấy nhân viên nào.'
            ], 200);
        }

        return new WP_REST_Response([
            'success' => true,
            'data'    => $staff
        ], 200);
    } catch (Exception $e) {
        file_put_contents(__DIR__ . '/../lark/logs/staff_errors.log', date('Y-m-d H:i:s') . ' - Failed to fetch staff: ' . $e->getMessage() . "\n", FILE_APPEND);
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Lỗi hệ thống: ' . $e->getMessage()
        ], 500);
    }
}

function checkin_mkt192_save_staff_api(WP_REST_Request $request) {
    global $wpdb;
    $data = $request->get_json_params();

    $employee_id  = sanitize_text_field($data['employee_id'] ?? '');
    $user_login   = sanitize_text_field($data['user_login'] ?? '');
    $display_name = sanitize_text_field($data['display_name'] ?? '');
    $user_email   = sanitize_email($data['user_email'] ?? '');
    $user_role    = sanitize_text_field($data['user_role'] ?? '');

    // Hỗ trợ cả branch_ids (mảng) và branch_id (đơn lẻ) để backward compatible
    $branch_ids = isset($data['branch_ids']) && is_array($data['branch_ids']) ? array_map('intval', $data['branch_ids']) : [];
    if (empty($branch_ids) && isset($data['branch_id'])) {
        $branch_ids = [intval($data['branch_id'])];
    }
    // Lưu branch_id đầu tiên làm primary branch (backward compatible)
    $branch_id = !empty($branch_ids) ? $branch_ids[0] : 0;
    // Lưu tất cả branch_ids dưới dạng JSON trong cột 'branch'
    $branch_json = !empty($branch_ids) ? json_encode($branch_ids) : '';

    $user_id      = intval($data['user_id'] ?? 0);
    $ou_id        = sanitize_text_field($data['ou_id'] ?? '1'); // Lấy ou_id từ request

    if (empty($user_login) || empty($user_email) || empty($display_name)) {
        return new WP_REST_Response(['success' => false, 'message' => 'Thiếu user_login, user_email hoặc display_name'], 400);
    }

    try {
        // Kiểm tra trùng lặp user_email trong bảng staff
        $email_exists = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}checkin_mkt192_staff WHERE user_email = %s AND user_id != %d AND status != 'DELETED'",
            $user_email,
            $user_id
        ));

        if ($email_exists > 0) {
            return new WP_Error('email_exists', 'Email đã tồn tại trong bảng nhân viên', ['status' => 400]);
        }

        // Tìm người dùng trong wp_users
        $user = get_user_by('login', $user_login);
        if (!$user && $user_id) {
            $user = get_user_by('id', $user_id);
        }

        if (!$user) {
            return new WP_REST_Response(['success' => false, 'message' => 'Người dùng không tồn tại trong WordPress'], 404);
        }

        $user_id = $user->ID;

        // Cập nhật wp_users
        $result = wp_update_user([
            'ID'           => $user_id,
            'display_name' => $display_name,
            'user_email'   => $user_email
        ]);

        if (is_wp_error($result)) {
            file_put_contents(__DIR__ . '/../lark/logs/staff_errors.log', date('Y-m-d H:i:s') . " - Failed to update wp_users for user_login: $user_login - " . $result->get_error_message() . "\n", FILE_APPEND);
            return new WP_REST_Response(['success' => false, 'message' => 'Lỗi cập nhật WordPress user'], 500);
        }

        // Đồng bộ role WordPress
        $wp_user = new WP_User($user_id);
        if ($user_role === 'Quản Lý') {
            $wp_user->set_role('administrator');
        } elseif ($user_role === 'Thu Ngân') {
            $wp_user->set_role('cashier');
        } else {
            $wp_user->set_role('staff');
        }

        // Tìm trong bảng staff theo user_id
        $existing_id = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}checkin_mkt192_staff WHERE user_id = %d",
            $user_id
        ));

        if ($existing_id) {
            // Nếu tồn tại, cập nhật (bao gồm ou_id và branch JSON)
            $wpdb->update(
                "{$wpdb->prefix}checkin_mkt192_staff",
                [
                    'user_id'      => $user_id,
                    'employee_id'  => $employee_id,
                    'display_name' => $display_name,
                    'user_email'   => $user_email,
                    'user_role'    => $user_role,
                    'branch_id'    => $branch_id,
                    'branch'       => $branch_json, // Lưu mảng branch_ids dưới dạng JSON
                    'ou_id'        => $ou_id
                ],
                ['user_id' => $user_id]
            );
        } else {
            // Nếu không có, chèn mới (bao gồm ou_id và branch JSON)
            $wpdb->insert(
                "{$wpdb->prefix}checkin_mkt192_staff",
                [
                    'user_id'      => $user_id,
                    'employee_id'  => $employee_id,
                    'user_login'   => $user_login,
                    'display_name' => $display_name,
                    'user_email'   => $user_email,
                    'user_role'    => $user_role,
                    'branch_id'    => $branch_id,
                    'branch'       => $branch_json, // Lưu mảng branch_ids dưới dạng JSON
                    'ou_id'        => $ou_id,
                    'status'       => 'ON'
                ]
            );
        }

        return new WP_REST_Response([
            'success' => true,
            'message' => 'Nhân viên đã được lưu',
            'data'    => ['user_id' => $user_id]
        ], 200);
    } catch (Exception $e) {
        file_put_contents(__DIR__ . '/../lark/logs/staff_errors.log', date('Y-m-d H:i:s') . ' - Save staff error: ' . $e->getMessage() . "\n", FILE_APPEND);
        return new WP_REST_Response(['success' => false, 'message' => 'Lỗi hệ thống: ' . $e->getMessage()], 500);
    }
}

function checkin_mkt192_update_staff_api(WP_REST_Request $request) {
    global $wpdb;
    $id   = intval($request->get_param('id'));
    $data = $request->get_json_params();

    $employee_id  = sanitize_text_field($data['employee_id'] ?? '');
    $user_login   = sanitize_text_field($data['user_login'] ?? '');
    $display_name = sanitize_text_field($data['display_name'] ?? '');
    $user_email   = sanitize_email($data['user_email'] ?? '');
    $user_role    = sanitize_text_field($data['user_role'] ?? '');

    // Hỗ trợ cả branch_ids (mảng) và branch_id (đơn lẻ) để backward compatible
    $branch_ids = isset($data['branch_ids']) && is_array($data['branch_ids']) ? array_map('intval', $data['branch_ids']) : [];
    if (empty($branch_ids) && isset($data['branch_id'])) {
        $branch_ids = [intval($data['branch_id'])];
    }
    // Lưu branch_id đầu tiên làm primary branch (backward compatible)
    $branch_id = !empty($branch_ids) ? $branch_ids[0] : 0;
    // Lưu tất cả branch_ids dưới dạng JSON trong cột 'branch'
    $branch_json = !empty($branch_ids) ? json_encode($branch_ids) : '';

    $ou_id        = sanitize_text_field($data['ou_id'] ?? '1'); // Lấy ou_id từ request, mặc định là '1'

    if (empty($id)) {
        return new WP_Error('missing_id', 'Thiếu ID nhân viên', ['status' => 400]);
    }

    if (empty($user_login) || empty($user_email) || empty($display_name)) {
        return new WP_Error('missing_data', 'Thiếu user_login, user_email hoặc display_name', ['status' => 400]);
    }

    try {
        // Kiểm tra xem nhân viên có tồn tại không
        $exists = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}checkin_mkt192_staff WHERE user_id = %d AND status != 'DELETED'",
            $id
        ));

        if ($exists == 0) {
            return new WP_Error('staff_not_found', 'Không tìm thấy nhân viên với ID này', ['status' => 404]);
        }

        // Kiểm tra xem user_login có bị trùng với nhân viên khác không (loại trừ chính user_id hiện tại)
        $login_exists = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}checkin_mkt192_staff WHERE user_login = %s AND user_id != %d AND status != 'DELETED'",
            $user_login,
            $id
        ));

        if ($login_exists > 0) {
            return new WP_Error('duplicate_user_login', 'Tên đăng nhập đã tồn tại', ['status' => 400]);
        }

        // Kiểm tra email trùng lặp (loại trừ chính user_id hiện tại)
        if (email_exists($user_email) && email_exists($user_email) != $id) {
            return new WP_Error('email_exists', 'Email đã tồn tại', ['status' => 400]);
        }

        // Cập nhật wp_users
        $user = get_user_by('id', $id);
        if (!$user) {
            return new WP_Error('user_not_found', 'Không tìm thấy người dùng WordPress với ID này', ['status' => 404]);
        }

        $wp_result = wp_update_user([
            'ID'           => $id,
            'user_login'   => $user_login,
            'display_name' => $display_name,
            'user_email'   => $user_email
        ]);

        if (is_wp_error($wp_result)) {
            throw new Exception('Lỗi cập nhật WordPress user: ' . $wp_result->get_error_message());
        }

        // Đồng bộ role WordPress
        $wp_user = new WP_User($id);
        if ($user_role === 'Quản Lý') {
            $wp_user->set_role('administrator');
        } elseif ($user_role === 'Thu Ngân') {
            $wp_user->set_role('cashier');
        } else {
            $wp_user->set_role('staff');
        }

        // Lấy thông tin cũ trước khi cập nhật để sync vào invoices và booking
        $old_data = $wpdb->get_row($wpdb->prepare(
            "SELECT display_name, employee_id FROM {$wpdb->prefix}checkin_mkt192_staff WHERE user_id = %d",
            $id
        ));
        $old_display_name = $old_data ? $old_data->display_name : null;
        $old_employee_id  = $old_data ? $old_data->employee_id : null;

        // Cập nhật bảng staff (bao gồm ou_id và branch JSON)
        $result = $wpdb->update(
            "{$wpdb->prefix}checkin_mkt192_staff",
            [
                'user_id'      => $id,
                'employee_id'  => $employee_id,
                'user_login'   => $user_login,
                'display_name' => $display_name,
                'user_email'   => $user_email,
                'user_role'    => $user_role,
                'branch_id'    => $branch_id,
                'branch'       => $branch_json, // Lưu mảng branch_ids dưới dạng JSON
                'ou_id'        => $ou_id
            ],
            ['user_id' => $id],
            ['%d', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s'],
            ['%d']
        );

        if ($result === false) {
            throw new Exception('Không thể cập nhật nhân viên');
        }

        // Nếu display_name hoặc employee_id thay đổi, cập nhật trong invoices và booking
        $name_changed = $old_display_name && $old_display_name  !== $display_name;
        $id_changed   = $old_employee_id  && $old_employee_id   !== $employee_id;

        // Nếu tên thay đổi, cần rename thư mục avatar và cập nhật đường dẫn
        if ($name_changed) {
            $upload_dir = wp_upload_dir();
            $base_path  = $upload_dir['basedir'] . '/checkin-mkt192-wp/staff/';

            // Tìm thư mục cũ thực tế bằng cách scan thư mục có pattern {user_id}-*
            $old_dir_actual = null;
            $dirs           = glob($base_path . $id . '-*', GLOB_ONLYDIR);
            if (!empty($dirs)) {
                $old_dir_actual = $dirs[0]; // Lấy thư mục đầu tiên tìm thấy
            }

            $new_dir_name = $id . '-' . sanitize_file_name($display_name);
            $new_dir      = $base_path . $new_dir_name;

            // Rename thư mục nếu tìm thấy thư mục cũ và khác với thư mục mới
            if ($old_dir_actual && $old_dir_actual !== $new_dir && is_dir($old_dir_actual)) {
                rename($old_dir_actual, $new_dir);

                // Lấy tất cả URLs từ database
                $staff_record = $wpdb->get_row($wpdb->prepare(
                    "SELECT avatar, cccd_front, cccd_back FROM {$wpdb->prefix}checkin_mkt192_staff WHERE user_id = %d",
                    $id
                ), ARRAY_A);

                if ($staff_record) {
                    $old_folder_name = basename($old_dir_actual);
                    $new_folder_name = $new_dir_name;

                    $update_data = [];

                    // Cập nhật avatar
                    if (!empty($staff_record['avatar'])) {
                        $new_avatar_url        = str_replace($old_folder_name, $new_folder_name, $staff_record['avatar']);
                        $update_data['avatar'] = $new_avatar_url;
                        update_user_meta($id, 'custom_avatar', $new_avatar_url);
                    }

                    // Cập nhật cccd_front
                    if (!empty($staff_record['cccd_front'])) {
                        $new_cccd_front_url        = str_replace($old_folder_name, $new_folder_name, $staff_record['cccd_front']);
                        $update_data['cccd_front'] = $new_cccd_front_url;
                        update_user_meta($id, 'cccd_front', $new_cccd_front_url);
                    }

                    // Cập nhật cccd_back
                    if (!empty($staff_record['cccd_back'])) {
                        $new_cccd_back_url        = str_replace($old_folder_name, $new_folder_name, $staff_record['cccd_back']);
                        $update_data['cccd_back'] = $new_cccd_back_url;
                        update_user_meta($id, 'cccd_back', $new_cccd_back_url);
                    }

                    // Update database nếu có thay đổi
                    if (!empty($update_data)) {
                        $wpdb->update(
                            "{$wpdb->prefix}checkin_mkt192_staff",
                            $update_data,
                            ['user_id' => $id],
                            array_fill(0, count($update_data), '%s'),
                            ['%d']
                        );
                    }
                }
            }
        }

        if ($name_changed || $id_changed) {
            // 1. Update created_user trong invoices_data
            if ($name_changed) {
                $wpdb->update(
                    "{$wpdb->prefix}checkin_mkt192_invoices_data",
                    ['created_user' => $display_name],
                    ['created_user' => $old_display_name],
                    ['%s'],
                    ['%s']
                );
            }

            // 2. Update staff_id và staff_name trong services JSON của invoices_data
            // Luôn tìm theo tên vì tên luôn có trong JSON, staff_id có thể không có
            $invoices = $wpdb->get_results(
                "SELECT invoice_id, services FROM {$wpdb->prefix}checkin_mkt192_invoices_data WHERE services LIKE '%" . $wpdb->esc_like($old_display_name) . "%'",
                ARRAY_A
            );

            $updated_services_count = 0;
            foreach ($invoices as $invoice) {
                $services = json_decode($invoice['services'], true);
                if (is_array($services)) {
                    $updated = false;
                    foreach ($services as &$service) {
                        // Kiểm tra và update staff_name
                        if ($name_changed && isset($service['staff_name']) && $service['staff_name'] === $old_display_name) {
                            $service['staff_name'] = $display_name;
                            $updated               = true;
                        }
                        // Kiểm tra và update staff_id (nếu field này tồn tại)
                        if ($id_changed && isset($service['staff_id']) && $service['staff_id'] === $old_employee_id) {
                            $service['staff_id'] = $employee_id;
                            $updated             = true;
                        }
                    }
                    if ($updated) {
                        $wpdb->update(
                            "{$wpdb->prefix}checkin_mkt192_invoices_data",
                            ['services'   => wp_json_encode($services, JSON_UNESCAPED_UNICODE)],
                            ['invoice_id' => $invoice['invoice_id']],
                            ['%s'],
                            ['%s']
                        );
                        $updated_services_count++;
                    }
                }
            }

            // 3. Update invoices_data_detail
            if ($name_changed) {
                $wpdb->update(
                    "{$wpdb->prefix}checkin_mkt192_invoices_data_detail",
                    ['staff_name' => $display_name],
                    ['staff_name' => $old_display_name],
                    ['%s'],
                    ['%s']
                );
            }

            // 4. Update booking_data
            if ($name_changed) {
                $wpdb->update(
                    "{$wpdb->prefix}bookingmkt192_booking_data",
                    ['hairdresser_name' => $display_name],
                    ['hairdresser_name' => $old_display_name],
                    ['%s'],
                    ['%s']
                );
            }

            $log_message = 'Updated staff info:';
            if ($name_changed) $log_message .= " name '{$old_display_name}' -> '{$display_name}'";
            if ($id_changed) $log_message   .= " id '{$old_employee_id}' -> '{$employee_id}'";
            $log_message                    .= " - Services JSON updated: {$updated_services_count} invoices";

            file_put_contents(
                CHECKIN_PLUGIN_DIR . '/../lark/../lark/logs/staff_errors.log',
                date('Y-m-d H:i:s') . ' - ' . $log_message . "\n",
                FILE_APPEND
            );
        }

        return new WP_REST_Response([
            'success' => true,
            'message' => 'Cập nhật nhân viên thành công',
            'data'    => ['user_id' => $id]
        ], 200);
    } catch (Exception $e) {
        file_put_contents(
            CHECKIN_PLUGIN_DIR . '/../lark/logs/staff_errors.log',
            date('Y-m-d H:i:s') . " - Failed to update staff ID {$id}: " . $e->getMessage() . "\n",
            FILE_APPEND
        );
        return new WP_Error('update_failed', 'Lỗi khi cập nhật nhân viên: ' . $e->getMessage(), ['status' => 500]);
    }
}

function checkin_mkt192_delete_staff_api(WP_REST_Request $request) {
    global $wpdb;
    $user_id = intval($request->get_param('id'));

    try {
        // Lấy user_login từ wp_users dựa trên user_id
        $user = get_user_by('id', $user_id);
        if (!$user) {
            return new WP_REST_Response(['success' => false, 'message' => 'Không tìm thấy người dùng trong WordPress'], 404);
        }
        $user_login = $user->user_login;

        // Xóa bản ghi trong checkin_mkt192_staff dựa trên user_login
        $deleted = $wpdb->delete(
            "{$wpdb->prefix}checkin_mkt192_staff",
            ['user_login' => $user_login]
        );

        if ($deleted === 0) {
            file_put_contents(__DIR__ . '/../lark/logs/staff_errors.log', date('Y-m-d H:i:s') . " - No staff record found to delete for user_login: $user_login\n", FILE_APPEND);
        }

        // Xóa tất cả user meta liên quan đến user_id
        $meta_deleted = $wpdb->delete(
            "{$wpdb->prefix}usermeta",
            ['user_id' => $user_id],
            ['%d']
        );

        if ($meta_deleted === false) {
            file_put_contents(__DIR__ . '/../lark/logs/staff_errors.log', date('Y-m-d H:i:s') . " - Failed to delete user meta for user_id: $user_id\n", FILE_APPEND);
        }

        // Xóa người dùng trong wp_users
        require_once(ABSPATH . 'wp-admin/includes/user.php');
        $deleted = wp_delete_user($user_id);

        if ($deleted === false) {
            file_put_contents(__DIR__ . '/../lark/logs/staff_errors.log', date('Y-m-d H:i:s') . " - Failed to delete WordPress user with ID: $user_id\n", FILE_APPEND);
            return new WP_REST_Response(['success' => false, 'message' => 'Không thể xóa người dùng trong WordPress'], 500);
        }

        return new WP_REST_Response(['success' => true, 'message' => 'Xóa nhân viên, người dùng và thông tin meta thành công'], 200);
    } catch (Exception $e) {
        file_put_contents(__DIR__ . '/../lark/logs/staff_errors.log', date('Y-m-d H:i:s') . " - Delete staff error for user_id $user_id: " . $e->getMessage() . "\n", FILE_APPEND);
        return new WP_REST_Response(['success' => false, 'message' => 'Lỗi hệ thống: ' . $e->getMessage()], 500);
    }
}

function checkin_mkt192_wp_get_user_profile(WP_REST_Request $request) {
    global $wpdb;

    if (!is_user_logged_in()) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Bạn chưa đăng nhập.'
        ], 401);
    }

    $current_user  = wp_get_current_user();
    $user_id       = $current_user->ID;
    $user_login    = $current_user->user_login;
    $display_name  = $current_user->display_name;
    $user_email    = $current_user->user_email;
    $custom_avatar = get_user_meta($user_id, 'custom_avatar', true);
    $avatar_url    = $custom_avatar ?: get_avatar_url($user_id);

    try {
        // Lấy dữ liệu từ bảng wp_checkin_mkt192_staff
        $staff_data = $wpdb->get_row($wpdb->prepare(
            "SELECT employee_id, user_role, facebook_url, tiktok_url, birthday, gender, address, is_cccd
             FROM {$wpdb->prefix}checkin_mkt192_staff
             WHERE user_login = %s",
            $user_login
        ), ARRAY_A);

        $employee_id  = $staff_data ? $staff_data['employee_id'] : '';
        $user_role    = $staff_data ? $staff_data['user_role'] : 'Chưa xác định';
        $facebook_url = $staff_data ? $staff_data['facebook_url'] : get_user_meta($user_id, 'facebook_url', true);
        $tiktok_url   = $staff_data ? $staff_data['tiktok_url'] : get_user_meta($user_id, 'tiktok_url', true);
        $birthday     = $staff_data ? $staff_data['birthday'] : get_user_meta($user_id, 'birthday', true);
        $address      = $staff_data ? $staff_data['address'] : get_user_meta($user_id, 'address', true);
        $is_cccd      = $staff_data ? $staff_data['is_cccd'] : 0;
        $gender       = $staff_data ? $staff_data['gender'] : 'male';

        switch ($gender) {
            case 'male':
                $gender_display = 'Nam';
                break;
            case 'female':
                $gender_display = 'Nữ';
                break;
            case 'other':
                $gender_display = 'Khác';
                break;
            default:
                $gender_display = '';
        }

        if (empty($staff_data)) {
            error_log(date('Y-m-d H:i:s') . " - No staff data found for user_login: $user_login");
        }
    } catch (Exception $e) {
        error_log(date('Y-m-d H:i:s') . ' - Failed to fetch staff data: ' . $e->getMessage());
        return new WP_Error('db_error', 'Lỗi truy vấn cơ sở dữ liệu.', ['status' => 500]);
    }

    $checkin_logs  = [];
    $late_count    = 0;
    $total_penalty = 0.0;

    try {
        // Lấy checkin logs dựa trên user_login
        $checkin_logs = $wpdb->get_results($wpdb->prepare(
            "SELECT *
             FROM {$wpdb->prefix}checkin_mkt192_checkinlogs
             WHERE display_name = %s
             ORDER BY checkin_time DESC
             LIMIT 30",
            $display_name
        ), OBJECT);

        foreach ($checkin_logs as $log) {
            if ($log->status_late == 1) $late_count++;
            if ($log->penalty_amount > 0) $total_penalty += floatval($log->penalty_amount);
        }
    } catch (Exception $e) {
        error_log(date('Y-m-d H:i:s') . ' - Failed to fetch checkin logs: ' . $e->getMessage());
    }

    $response = [
        'success' => true,
        'data'    => [
            'display_name'  => $display_name,
            'user_role'     => $user_role,
            'gender'        => $gender_display,
            'avatar_url'    => $avatar_url,
            'employee_id'   => $employee_id,
            'email'         => $user_email,
            'facebook'      => $facebook_url ?: '',
            'tiktok'        => $tiktok_url ?: '',
            'birthday'      => $birthday ?: '',
            'address'       => $address ?: '',
            'is_cccd'       => (int) $is_cccd,
            'late_count'    => $late_count,
            'total_penalty' => $total_penalty,
            'checkin_logs'  => $checkin_logs
        ]
    ];

    return rest_ensure_response($response);
}

function checkin_mkt192_wp_staff_update_user_avatar(WP_REST_Request $request) {
    global $wpdb;
    // Verify nonce
    $nonce = $request->get_header('X-WP-Nonce');
    if (!wp_verify_nonce($nonce, 'wp_rest')) {
        return new WP_Error('invalid_nonce', 'Nonce không hợp lệ.', ['status' => 403]);
    }

    // Check if file is uploaded
    if (empty($_FILES['checkin-mkt-custom-avatar-file'])) {
        return new WP_Error('no_file', 'Không có file được tải lên.', ['status' => 400]);
    }

    // Get current user
    $user = wp_get_current_user();
    if (!$user->exists()) {
        return new WP_Error('no_user', 'Không tìm thấy người dùng.', ['status' => 401]);
    }

    // Lấy display_name từ request nếu có, nếu không thì dùng display_name hiện tại
    $params       = $request->get_params();
    $display_name = isset($params['display_name']) ? sanitize_text_field($params['display_name']) : $user->display_name;

    // Handle file upload
    $file          = $_FILES['checkin-mkt-custom-avatar-file'];
    $uploaded_file = checkin_mkt_handle_upload($file, 'avatar', $user->ID, $display_name);

    if ($uploaded_file && !isset($uploaded_file['error'])) {
        $table_name = $wpdb->prefix . 'checkin_mkt192_staff';

        // Update avatar URL in the database
        $avatar_url = $uploaded_file['url'];
        $updated    = $wpdb->update(
            $table_name,
            ['avatar'     => $avatar_url],
            ['user_login' => $user->user_login],
            ['%s'],
            ['%s']
        );

        if ($updated === false) {
            file_put_contents(__DIR__ . '/../lark/logs/user_profile_errors.log', date('Y-m-d H:i:s') . " - Failed to update avatar in database for user_login: {$user->user_login}\n", FILE_APPEND);
            return new WP_Error('db_error', 'Lỗi khi cập nhật cơ sở dữ liệu.', ['status' => 500]);
        }

        // Update WordPress user meta for avatar
        update_user_meta($user->ID, 'custom_avatar', $avatar_url);

        return new WP_REST_Response([
            'success'    => true,
            'message'    => 'Ảnh đại diện đã được cập nhật.',
            'avatar_url' => $avatar_url
        ], 200);
    } else {
        file_put_contents(__DIR__ . '/../lark/logs/user_profile_errors.log', date('Y-m-d H:i:s') . ' - Upload error: ' . ($uploaded_file['error'] ?? 'Unknown error') . "\n", FILE_APPEND);
        return new WP_Error('upload_error', 'Lỗi khi tải file: ' . ($uploaded_file['error'] ?? 'Unknown error'), ['status' => 400]);
    }
}

// Cập nhật thông tin hồ sơ
function checkin_mkt_update_user_profile(WP_REST_Request $request) {
    global $wpdb;

    // Debug mode - chỉ log khi cần debug
    $debug_mode = defined('WP_DEBUG') && WP_DEBUG;
    $log_file   = __DIR__ . '/../lark/logs/user_profile_errors.log';

    $user = wp_get_current_user();

    if (!$user->ID) {
        return new WP_Error('not_logged_in', 'User not logged in', ['status' => 401]);
    }

    $user_id    = $user->ID;
    $user_login = $user->user_login;
    $params     = $request->get_params();
    $files      = $request->get_file_params();

    $allowed_fields = ['display_name', 'email', 'birthday', 'gender', 'address', 'facebook', 'tiktok'];
    $update_data    = [];

    foreach ($allowed_fields as $field) {
        if (isset($params[$field])) {
            $value = sanitize_text_field($params[$field]);

            // Chuẩn hóa gender
            if ($field === 'gender') {
                $lower_value = mb_strtolower($value, 'UTF-8');
                $value       = match (true) {
                    in_array($lower_value, ['nam', 'male'], true)           => 'male',
                    in_array($lower_value, ['nữ', 'nu', 'female'], true)    => 'female',
                    in_array($lower_value, ['khác', 'khac', 'other'], true) => 'other',
                    default                                                 => $value, // Giữ nguyên giá trị nếu đã hợp lệ (male/female/other)
                };
            }

            $update_data[$field] = $value;
        }
    }

    // Handle avatar upload - require_once chỉ 1 lần ở đầu
    require_once(ABSPATH . 'wp-admin/includes/file.php');

    $avatar_url = get_user_meta($user_id, 'custom_avatar', true) ?: get_avatar_url($user_id);
    if (!empty($files['avatar'])) {
        $display_name = isset($update_data['display_name']) ? $update_data['display_name'] : $user->display_name;
        $upload       = checkin_mkt_handle_upload($files['avatar'], 'avatar', $user_id, $display_name);
        if ($upload && !isset($upload['error']) && isset($upload['url'])) {
            $avatar_url = (string) $upload['url'];
            update_user_meta($user_id, 'custom_avatar', $avatar_url);
        } else {
            return new WP_Error('upload_failed', 'Failed to upload avatar: ' . ($upload['error'] ?? 'Unknown error'), ['status' => 500]);
        }
    }

    // Handle CCCD upload
    $staff_data = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}checkin_mkt192_staff WHERE user_id = %d AND user_login = %s", $user_id, $user_login));
    $cccd_front = $staff_data ? ($staff_data->cccd_front ?? '') : '';
    $cccd_back  = $staff_data ? ($staff_data->cccd_back ?? '') : '';
    $is_cccd    = $staff_data ? ($staff_data->is_cccd ?? 0) : 0;

    // CHỈ upload CCCD khi user thực sự chọn file mới (kiểm tra tmp_name)
    if (!empty($files['cccd_front']) && !empty($files['cccd_front']['tmp_name'])) {
        $display_name = isset($update_data['display_name']) ? $update_data['display_name'] : $user->display_name;
        $upload       = checkin_mkt_handle_upload($files['cccd_front'], 'cccd_front', $user_id, $display_name);
        if ($upload && !isset($upload['error']) && isset($upload['url'])) {
            $cccd_front = (string) $upload['url'];
            update_user_meta($user_id, 'cccd_front', $cccd_front);
            $is_cccd = 1;
        } else {
            return new WP_Error('upload_failed', 'Failed to upload CCCD front: ' . ($upload['error'] ?? 'Unknown error'), ['status' => 500]);
        }
    }

    if (!empty($files['cccd_back']) && !empty($files['cccd_back']['tmp_name'])) {
        $display_name = isset($update_data['display_name']) ? $update_data['display_name'] : $user->display_name;
        $upload       = checkin_mkt_handle_upload($files['cccd_back'], 'cccd_back', $user_id, $display_name);
        if ($upload && !isset($upload['error']) && isset($upload['url'])) {
            $cccd_back = (string) $upload['url'];
            update_user_meta($user_id, 'cccd_back', $cccd_back);
            $is_cccd = 1;
        } else {
            return new WP_Error('upload_failed', 'Failed to upload CCCD back: ' . ($upload['error'] ?? 'Unknown error'), ['status' => 500]);
        }
    }

    // Update email
    if (!empty($update_data['email']) && $update_data['email'] !== $user->user_email) {
        if (is_email($update_data['email'])) {
            $email_exists = email_exists($update_data['email']);
            if ($email_exists && $email_exists !== $user_id) {
                return new WP_Error('email_exists', 'Email already in use', ['status' => 400]);
            }
            wp_update_user(['ID' => $user_id, 'user_email' => $update_data['email']]);
        } else {
            return new WP_Error('invalid_email', 'Invalid email format', ['status' => 400]);
        }
    }

    // Update display name and handle directory renaming
    if (!empty($update_data['display_name']) && $update_data['display_name'] !== $user->display_name) {
        wp_update_user(['ID' => $user_id, 'display_name' => $update_data['display_name']]);

        $upload_dir = wp_upload_dir();
        $base_path  = $upload_dir['basedir'] . '/checkin-mkt192-wp/staff/';

        // Tìm thư mục cũ thực tế bằng cách scan thư mục có pattern {user_id}-*
        $old_dir_actual = null;
        $dirs           = glob($base_path . $user_id . '-*', GLOB_ONLYDIR);
        if (!empty($dirs)) {
            $old_dir_actual = $dirs[0]; // Lấy thư mục đầu tiên tìm thấy
        }

        $new_dir_name = $user_id . '-' . sanitize_file_name($update_data['display_name']);
        $new_dir      = $base_path . $new_dir_name;

        // Rename thư mục nếu tìm thấy thư mục cũ và khác với thư mục mới
        if ($old_dir_actual && $old_dir_actual !== $new_dir && is_dir($old_dir_actual)) {
            rename($old_dir_actual, $new_dir);

            $old_folder_name = basename($old_dir_actual);
            $new_folder_name = $new_dir_name;

            // Cập nhật avatar URL
            if ($avatar_url) {
                $avatar_url = str_replace($old_folder_name, $new_folder_name, $avatar_url);
                update_user_meta($user_id, 'custom_avatar', $avatar_url);
            }

            // Cập nhật cccd_front URL
            if ($cccd_front) {
                $cccd_front = str_replace($old_folder_name, $new_folder_name, $cccd_front);
                update_user_meta($user_id, 'cccd_front', $cccd_front);
            }

            // Cập nhật cccd_back URL
            if ($cccd_back) {
                $cccd_back = str_replace($old_folder_name, $new_folder_name, $cccd_back);
                update_user_meta($user_id, 'cccd_back', $cccd_back);
            }
        }
    }

    // Lấy thông tin cũ từ database trước khi update (bao gồm cả employee_id)
    $old_display_name = $staff_data ? $staff_data->display_name : null;
    $old_employee_id  = $staff_data ? $staff_data->employee_id : null;
    $new_display_name = $update_data['display_name']  ?? $user->display_name;
    $new_employee_id  = ($staff_data && $staff_data->employee_id) ? $staff_data->employee_id : 'EMP' . str_pad($user_id, 6, '0', STR_PAD_LEFT);

    // Sync to wp_checkin_mkt192_staff
    $staff_update_data = [
        'user_id'      => $user_id,
        'user_login'   => $user_login,
        'employee_id'  => $new_employee_id,
        'ou_id'        => ($staff_data && isset($staff_data->ou_id)) ? $staff_data->ou_id : '1',
        'display_name' => $new_display_name,
        'user_email'   => $update_data['email']        ?? $user->user_email,
        'user_role'    => ($staff_data && isset($staff_data->user_role)) ? $staff_data->user_role : '',
        'facebook_url' => $update_data['facebook']     ?? (($staff_data && isset($staff_data->facebook_url)) ? $staff_data->facebook_url : ''),
        'tiktok_url'   => $update_data['tiktok']       ?? (($staff_data && isset($staff_data->tiktok_url)) ? $staff_data->tiktok_url : ''),
        'birthday'     => $update_data['birthday']     ?? (($staff_data && isset($staff_data->birthday)) ? $staff_data->birthday : null),
        'gender'       => $update_data['gender']       ?? (($staff_data && isset($staff_data->gender)) ? $staff_data->gender : 'male'),
        'address'      => $update_data['address']      ?? (($staff_data && isset($staff_data->address)) ? $staff_data->address : ''),
        'is_cccd'      => $is_cccd,
        'cccd_front'   => (string) $cccd_front,
        'cccd_back'    => (string) $cccd_back,
        'avatar'       => (string) $avatar_url,
        'status'       => ($staff_data && isset($staff_data->status)) ? $staff_data->status : 'ON',
    ];

    if ($staff_data) {
        $wpdb->update(
            "{$wpdb->prefix}checkin_mkt192_staff",
            $staff_update_data,
            ['user_id' => $user_id, 'user_login' => $user_login],
            ['%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s'],
            ['%d', '%s']
        );
    } else {
        $wpdb->insert(
            "{$wpdb->prefix}checkin_mkt192_staff",
            $staff_update_data,
            ['%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s']
        );
    }

    // Nếu display_name hoặc employee_id thay đổi, cập nhật trong invoices và booking
    // CHÚ Ý: Đây là task nặng, có thể chạy async/background trong tương lai
    $name_changed = $old_display_name && $old_display_name  !== $new_display_name;
    $id_changed   = $old_employee_id  && $old_employee_id   !== $new_employee_id;

    if ($name_changed || $id_changed) {
        // Update created_user column in invoices_data
        if ($name_changed) {
            $wpdb->update(
                "{$wpdb->prefix}checkin_mkt192_invoices_data",
                ['created_user' => $new_display_name],
                ['created_user' => $old_display_name],
                ['%s'],
                ['%s']
            );
        }

        // Update staff_id và staff_name in services JSON column in invoices_data
        // Giới hạn chỉ update 100 invoices gần nhất để tránh timeout
        $invoices_table         = "{$wpdb->prefix}checkin_mkt192_invoices_data";
        $invoices_with_services = $wpdb->get_results($wpdb->prepare(
            "SELECT invoice_id, services FROM {$invoices_table} WHERE services LIKE %s ORDER BY invoice_id DESC LIMIT 100",
            '%' . $wpdb->esc_like($old_display_name) . '%'
        ), ARRAY_A);

        foreach ($invoices_with_services as $invoice) {
            $services = json_decode($invoice['services'], true);
            if (is_array($services)) {
                $updated = false;
                foreach ($services as &$service) {
                    if ($name_changed && isset($service['staff_name']) && $service['staff_name'] === $old_display_name) {
                        $service['staff_name'] = $new_display_name;
                        $updated               = true;
                    }
                    if ($id_changed && isset($service['staff_id']) && $service['staff_id'] === $old_employee_id) {
                        $service['staff_id'] = $new_employee_id;
                        $updated             = true;
                    }
                }
                if ($updated) {
                    $wpdb->update(
                        $invoices_table,
                        ['services'   => wp_json_encode($services, JSON_UNESCAPED_UNICODE)],
                        ['invoice_id' => $invoice['invoice_id']],
                        ['%s'],
                        ['%s']
                    );
                }
            }
        }

        // Update invoices_data_detail (giới hạn 1000 records)
        if ($name_changed) {
            $wpdb->query($wpdb->prepare(
                "UPDATE {$wpdb->prefix}checkin_mkt192_invoices_data_detail SET staff_name = %s WHERE staff_name = %s LIMIT 1000",
                $new_display_name,
                $old_display_name
            ));
        }

        // Update booking_data (giới hạn 500 records)
        if ($name_changed) {
            $wpdb->query($wpdb->prepare(
                "UPDATE {$wpdb->prefix}bookingmkt192_booking_data SET hairdresser_name = %s WHERE hairdresser_name = %s LIMIT 500",
                $new_display_name,
                $old_display_name
            ));
        }
    }

    return new WP_REST_Response([
        'success' => true,
        'message' => 'Cập nhật hồ sơ thành công'
    ], 200);
}

function checkin_mkt192_wp_staff_update_social_post($request) {
    global $wpdb;

    // Lấy các tham số từ yêu cầu
    $display_name = $request['display_name'];
    $post_type    = $request['post_type'];
    $post_id      = $request['post_id'];
    $post_date    = $request['post_date'];
    $nonce        = $request['nonce'];

    // Kiểm tra nonce
    if (!wp_verify_nonce($nonce, 'wp_rest')) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Nonce không hợp lệ.',
        ], 403);
    }

    // Kiểm tra định dạng ngày
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $post_date)) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Định dạng ngày không hợp lệ. Vui lòng dùng YYYY-MM-DD.',
        ], 400);
    }

    // Tên bảng social_posts
    $social_table = $wpdb->prefix . 'checkin_mkt192_social_posts';

    // Kiểm tra xem post_id đã tồn tại chưa
    $query = $wpdb->prepare(
        "SELECT id FROM $social_table WHERE post_id = %s AND post_type = %s",
        $post_id,
        $post_type
    );
    $existing_post = $wpdb->get_row($query);

    if ($existing_post) {
        return new WP_REST_Response([
            'success' => true,
            'message' => 'Bài đăng đã tồn tại, bỏ qua cập nhật.',
        ], 200);
    }

    // Thêm bài đăng mới vào bảng social_posts
    $inserted = $wpdb->insert(
        $social_table,
        [
            'staff_name' => $display_name,
            'post_type'  => $post_type,
            'post_id'    => $post_id,
            'post_date'  => $post_date
        ],
        ['%s', '%s', '%s', '%s']
    );

    if ($inserted === false) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Lỗi khi thêm bài đăng vào cơ sở dữ liệu.',
        ], 500);
    }

    return new WP_REST_Response([
        'success' => true,
        'message' => 'Thêm bài đăng vào social_posts thành công.',
    ], 200);
}

function checkin_mkt192_update_staff_status($request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'checkin_mkt192_staff';

    $params     = $request->get_json_params();
    $staff_name = isset($params['staff_name']) ? sanitize_text_field($params['staff_name']) : '';
    $status     = isset($params['status']) && in_array($params['status'], ['ON', 'OFF', 'BUSY', 'PAUSE', 'ARCHIVED', 'DELETED'], true) ? $params['status'] : 'ON';

    if (empty($staff_name)) {
        return new WP_Error('invalid_data', 'Thiếu hoặc sai staff_name', ['status' => 400]);
    }

    // Log để debug
    error_log('Staff name received: ' . $staff_name);

    // Kiểm tra bản ghi tồn tại
    $existing_record = $wpdb->get_row(
        $wpdb->prepare("SELECT * FROM $table_name WHERE display_name = %s", $staff_name)
    );

    if (!$existing_record) {
        error_log('No record found for display_name: ' . $staff_name);
        return new WP_Error('no_record', 'Không tìm thấy nhân viên với display_name này', ['status' => 404]);
    }

    // Trạng thái, kèm SĐT nếu chuyển sang tạm dừng (hiện ở trang chủ cho khách gọi)
    $fields  = ['status' => $status];
    $formats = ['%s'];

    if (array_key_exists('phone', $params)) {
        $fields['phone'] = sanitize_text_field($params['phone']);
        $formats[]       = '%s';
    }

    $updated = $wpdb->update(
        $table_name,
        $fields,
        ['display_name' => $staff_name],
        $formats,
        ['%s']
    );

    if ($updated === false) {
        error_log('Update failed for display_name: ' . $staff_name);
        return new WP_Error('update_failed', 'Không thể cập nhật trạng thái', ['status' => 500]);
    }

    return [
        'success' => true,
        'message' => 'Cập nhật trạng thái thành công',
        'data'    => [
            'staff_name' => $staff_name,
            'status'     => $status
        ]
    ];
}

function checkin_mkt_custom_upload_dir($uploads, $user_id = null, $display_name = null) {
    $user = wp_get_current_user();
    
    // Sử dụng user_id và display_name từ tham số (nếu có) hoặc lấy từ user hiện tại
    $target_user_id = !empty($user_id) ? intval($user_id) : ($user ? $user->ID : 0);
    if (!$target_user_id) {
        return $uploads;
    }

    $target_display_name = !empty($display_name) ? sanitize_file_name($display_name) : ($user ? sanitize_file_name($user->display_name) : '');
    if (empty($target_display_name)) {
        $target_display_name = 'default';
    }

    // Tạo đường dẫn với định dạng user_id-display_name
    $custom_dir        = '/checkin-mkt192-wp/staff/' . $target_user_id . '-' . $target_display_name;
    $uploads['path']   = $uploads['basedir'] . $custom_dir;
    $uploads['url']    = $uploads['baseurl'] . $custom_dir;
    $uploads['subdir'] = $custom_dir;

    // Tạo thư mục nếu chưa tồn tại
    if (!file_exists($uploads['path'])) {
        wp_mkdir_p($uploads['path']);
    }

    // Tìm và xóa các thư mục cũ có cùng user_id nhưng display_name khác
    $base_upload_dir = $uploads['basedir'] . '/checkin-mkt192-wp/staff/';
    if (is_dir($base_upload_dir)) {
        $dirs = glob($base_upload_dir . $target_user_id . '-*', GLOB_ONLYDIR);
        foreach ($dirs as $dir) {
            $dir_name = basename($dir);
            if ($dir_name !== $target_user_id . '-' . $target_display_name) {
                // Xóa thư mục cũ
                checkin_mkt_delete_directory($dir);
            }
        }
    }

    return $uploads;
}

function checkin_mkt_delete_directory($dir) {
    if (!is_dir($dir)) {
        return;
    }
    $files = array_diff(scandir($dir), ['.', '..']);
    foreach ($files as $file) {
        $path = "$dir/$file";
        is_dir($path) ? checkin_mkt_delete_directory($path) : unlink($path);
    }
    rmdir($dir);
}

function checkin_mkt_custom_filename($file, $type) {
    $info      = pathinfo($file['name']);
    $ext       = '.webp'; // Ép định dạng thành webp
    $timestamp = time();

    // Đặt tên file theo loại
    switch ($type) {
        case 'avatar':
            $file['name'] = 'avt_' . $timestamp . $ext;
            break;
        case 'cccd_front':
            $file['name'] = 'cccd_1_' . $timestamp . $ext;
            break;
        case 'cccd_back':
            $file['name'] = 'cccd_2_' . $timestamp . $ext;
            break;
        default:
            $file['name'] = 'file_' . $timestamp . $ext;
    }


    return $file;
}

function checkin_mkt_handle_upload($file, $type, $user_id = null, $display_name = null) {
    add_filter('upload_dir', function($uploads) use ($user_id, $display_name) {
        return checkin_mkt_custom_upload_dir($uploads, $user_id, $display_name);
    });
    add_filter('wp_handle_upload_prefilter', function($file) use ($type) {
        return checkin_mkt_custom_filename($file, $type);
    });

    // require_once đã được gọi ở function gọi, không cần gọi lại

    $upload_overrides = ['test_form' => false];
    $upload           = wp_handle_upload($file, $upload_overrides);

    if ($upload && !isset($upload['error'])) {
        $file_path = $upload['file'];
        $info      = pathinfo($file_path);

        // Chỉ convert nếu không phải webp
        if (strtolower($info['extension']) !== 'webp') {
            $image = null;
            switch (strtolower($info['extension'])) {
                case 'jpg':
                case 'jpeg':
                    $image = @imagecreatefromjpeg($file_path);
                    break;
                case 'png':
                    $image = @imagecreatefrompng($file_path);
                    break;
                case 'gif':
                    $image = @imagecreatefromgif($file_path);
                    break;
            }

            if ($image) {
                $new_file_path = $info['dirname'] . '/' . $info['filename'] . '.webp';
                if (imagewebp($image, $new_file_path, 80)) {
                    imagedestroy($image);
                    if ($file_path !== $new_file_path) {
                        @unlink($file_path); // Xóa file gốc, suppress warning
                    }
                    $upload['file'] = $new_file_path;
                    $upload['url']  = str_replace($info['basename'], $info['filename'] . '.webp', $upload['url']);
                    $upload['type'] = 'image/webp';
                } else {
                    imagedestroy($image);
                    // Giữ file gốc nếu convert thất bại, không return error
                }
            }
            // Nếu không tạo được image resource, giữ file gốc
        }
    }

    remove_filter('upload_dir', 'checkin_mkt_custom_upload_dir');
    remove_filter('wp_handle_upload_prefilter', 'checkin_mkt_custom_filename');

    return $upload;
}
