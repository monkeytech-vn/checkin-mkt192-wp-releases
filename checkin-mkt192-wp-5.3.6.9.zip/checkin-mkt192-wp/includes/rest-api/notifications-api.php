<?php

/**
 * Notifications Management API
 *
 * REST API endpoints for managing homepage and staff notifications
 * Supports image/video uploads, push notifications, and scheduling
 *
 * @package Checkin_MKT192_WP
 * @since 7.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

// =============================================================================
// REST API ROUTES
// =============================================================================

add_action('rest_api_init', function () {
    // Get all notifications (with filters)
    register_rest_route('vg/v1', '/notifications', [
        'methods'             => 'GET',
        'callback'            => 'checkin_notifications_get_all',
        'permission_callback' => function () {
            return current_user_can('manage_options') || current_user_can('edit_posts');
        }
    ]);

    // Create notification
    register_rest_route('vg/v1', '/notifications', [
        'methods'             => 'POST',
        'callback'            => 'checkin_notifications_create',
        'permission_callback' => function () {
            return current_user_can('manage_options');
        }
    ]);

    // Get single notification
    register_rest_route('vg/v1', '/notifications/(?P<id>\d+)', [
        'methods'             => 'GET',
        'callback'            => 'checkin_notifications_get_single',
        'permission_callback' => function () {
            return current_user_can('manage_options') || current_user_can('edit_posts');
        }
    ]);

    // Update notification
    register_rest_route('vg/v1', '/notifications/(?P<id>\d+)', [
        'methods'             => 'PUT',
        'callback'            => 'checkin_notifications_update',
        'permission_callback' => function () {
            return current_user_can('manage_options');
        }
    ]);

    // Delete notification
    register_rest_route('vg/v1', '/notifications/(?P<id>\d+)', [
        'methods'             => 'DELETE',
        'callback'            => 'checkin_notifications_delete',
        'permission_callback' => function () {
            return current_user_can('manage_options');
        }
    ]);

    // Get active notifications for frontend (public)
    register_rest_route('vg/v1', '/notifications/active', [
        'methods'             => 'GET',
        'callback'            => 'checkin_notifications_get_active',
        'permission_callback' => '__return_true'
    ]);

    // Track notification view
    register_rest_route('vg/v1', '/notifications/(?P<id>\d+)/view', [
        'methods'             => 'POST',
        'callback'            => 'checkin_notifications_track_view',
        'permission_callback' => '__return_true'
    ]);

    // Get notification viewers (staff notifications only)
    register_rest_route('vg/v1', '/notifications/(?P<id>\d+)/viewers', [
        'methods'             => 'GET',
        'callback'            => 'checkin_notifications_get_viewers',
        'permission_callback' => function () {
            return current_user_can('manage_options') || current_user_can('edit_posts');
        }
    ]);

    // Update sort order (bulk)
    register_rest_route('vg/v1', '/notifications/reorder', [
        'methods'             => 'POST',
        'callback'            => 'checkin_notifications_reorder',
        'permission_callback' => function () {
            return current_user_can('manage_options');
        }
    ]);
});

// =============================================================================
// API HANDLERS
// =============================================================================

/**
 * Get all notifications with filters
 */
function checkin_notifications_get_all($request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'checkin_mkt192_notifications';

    $type      = sanitize_text_field($request->get_param('type') ?? '');
    $status    = sanitize_text_field($request->get_param('status') ?? 'all');
    $branch_id = sanitize_text_field($request->get_param('branch_id') ?? '');
    $page      = absint($request->get_param('page') ?? 1);
    $per_page  = absint($request->get_param('per_page') ?? 12);

    $offset = ($page - 1) * $per_page;

    // Build query
    $where_clauses = ['1=1'];
    $params        = [];

    // Only filter by type if specified (not empty or 'all')
    if (!empty($type) && $type !== 'all') {
        $where_clauses[] = 'type = %s';
        $params[]        = $type;
    }

    if ($status !== 'all') {
        $where_clauses[] = 'status = %s';
        $params[]        = $status;
    }

    if (!empty($branch_id)) {
        $where_clauses[] = "(branches IS NULL OR branches = '' OR branches LIKE %s)";
        $params[]        = '%"' . $branch_id . '"%';
    }

    $where_sql = implode(' AND ', $where_clauses);

    // Get total count
    if (!empty($params)) {
        $count_sql = $wpdb->prepare(
            "SELECT COUNT(*) FROM $table_name WHERE $where_sql",
            ...$params
        );
    } else {
        $count_sql = "SELECT COUNT(*) FROM $table_name WHERE $where_sql";
    }
    $total = $wpdb->get_var($count_sql);

    // Get notifications
    $query_params = array_merge($params, [$per_page, $offset]);

    $sql = $wpdb->prepare(
        "SELECT * FROM $table_name WHERE $where_sql ORDER BY sort_order ASC, created_at DESC LIMIT %d OFFSET %d",
        ...$query_params
    );
    $notifications = $wpdb->get_results($sql, ARRAY_A);

    // Parse branches JSON
    foreach ($notifications as &$notification) {
        $notification['branches'] = json_decode($notification['branches'], true) ?? [];
    }

    return rest_ensure_response([
        'success'     => true,
        'data'        => $notifications,
        'total'       => (int) $total,
        'page'        => $page,
        'per_page'    => $per_page,
        'total_pages' => ceil($total / $per_page)
    ]);
}

/**
 * Create new notification
 */
function checkin_notifications_create($request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'checkin_mkt192_notifications';

    $title          = sanitize_text_field($request->get_param('title') ?? '');
    $content        = wp_kses_post($request->get_param('content') ?? '');
    $type           = sanitize_text_field($request->get_param('type') ?? 'homepage');
    $status         = sanitize_text_field($request->get_param('status') ?? 'draft');
    $link           = esc_url_raw($request->get_param('link') ?? '');
    $start_date     = sanitize_text_field($request->get_param('start_date') ?? '');
    $end_date       = sanitize_text_field($request->get_param('end_date') ?? '');
    $branches       = $request->get_param('branches') ?? '[]';
    $send_push      = $request->get_param('send_push')   === '1' ? 1 : 0;
    $show_in_app    = $request->get_param('show_in_app') === '1' ? 1 : 0;
    $aspect_ratio   = sanitize_text_field($request->get_param('aspect_ratio') ?? '16:9');
    $sort_order     = absint($request->get_param('sort_order') ?? 0);
    $slide_duration = absint($request->get_param('slide_duration') ?? 5);

    // Validate required fields
    if (empty($title)) {
        return new WP_Error('missing_title', 'Tiêu đề là bắt buộc', ['status' => 400]);
    }
    if (empty($content)) {
        return new WP_Error('missing_content', 'Nội dung là bắt buộc', ['status' => 400]);
    }

    // Handle media upload
    $media_url  = null;
    $media_type = null;

    if (!empty($_FILES['media']) && $_FILES['media']['error'] === UPLOAD_ERR_OK) {
        $upload_result = checkin_notifications_handle_media_upload($_FILES['media']);
        if (is_wp_error($upload_result)) {
            return $upload_result;
        }
        $media_url  = $upload_result['url'];
        $media_type = $upload_result['type'];
    } elseif (!empty($request->get_param('media_url'))) {
        // Handle media URL (from URL input, not file upload)
        $media_url_param = $request->get_param('media_url');
        $media_url       = esc_url_raw($media_url_param);
        // Determine media type from URL extension
        $extension        = strtolower(pathinfo(parse_url($media_url_param, PHP_URL_PATH), PATHINFO_EXTENSION));
        $video_extensions = ['mp4', 'webm', 'ogg', 'mov'];
        $media_type       = in_array($extension, $video_extensions) ? 'video' : 'image';
    }

    // Format dates
    $start_date_formatted = !empty($start_date) ? date('Y-m-d H:i:s', strtotime($start_date)) : null;
    $end_date_formatted   = !empty($end_date) ? date('Y-m-d H:i:s', strtotime($end_date)) : null;

    // Update status based on dates
    if ($status === 'active' && !empty($start_date_formatted)) {
        $now = current_time('mysql');
        if ($start_date_formatted > $now) {
            $status = 'scheduled';
        }
    }

    // Insert notification
    $result = $wpdb->insert($table_name, [
        'type'           => $type,
        'title'          => $title,
        'content'        => $content,
        'media_url'      => $media_url,
        'media_type'     => $media_type,
        'aspect_ratio'   => $aspect_ratio,
        'link'           => $link,
        'status'         => $status,
        'start_date'     => $start_date_formatted,
        'end_date'       => $end_date_formatted,
        'sort_order'     => $sort_order,
        'slide_duration' => $slide_duration,
        'branches'       => $branches,
        'send_push'      => $send_push,
        'show_in_app'    => $show_in_app,
        'created_by'     => get_current_user_id(),
        'created_at'     => current_time('mysql'),
        'updated_at'     => current_time('mysql')
    ]);

    if ($result === false) {
        return new WP_Error('db_error', 'Không thể tạo thông báo', ['status' => 500]);
    }

    $notification_id = $wpdb->insert_id;

    // Send push notification if type is staff and send_push is enabled
    if ($type === 'staff' && $send_push && $status === 'active') {
        checkin_notifications_send_push($notification_id, $title, $content, $branches);
    }

    // Send Lark notification if type is staff and Lark is enabled
    if ($type === 'staff' && $status === 'active') {
        checkin_notifications_send_lark($notification_id, $title, $content, $type);
    }

    return rest_ensure_response([
        'success' => true,
        'message' => 'Tạo thông báo thành công',
        'data'    => ['id' => $notification_id]
    ]);
}

/**
 * Get single notification
 */
function checkin_notifications_get_single($request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'checkin_mkt192_notifications';

    $id           = absint($request['id']);
    $notification = $wpdb->get_row(
        $wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $id),
        ARRAY_A
    );

    if (!$notification) {
        return new WP_Error('not_found', 'Không tìm thấy thông báo', ['status' => 404]);
    }

    $notification['branches'] = json_decode($notification['branches'], true) ?? [];

    return rest_ensure_response([
        'success' => true,
        'data'    => $notification
    ]);
}

/**
 * Update notification
 */
function checkin_notifications_update($request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'checkin_mkt192_notifications';

    $id = absint($request['id']);

    // Check if notification exists
    $existing = $wpdb->get_row(
        $wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $id)
    );

    if (!$existing) {
        return new WP_Error('not_found', 'Không tìm thấy thông báo', ['status' => 404]);
    }

    // Prepare update data
    $update_data = [
        'updated_at' => current_time('mysql')
    ];

    // Only update provided fields
    $fields = ['title', 'content', 'type', 'status', 'link', 'branches', 'send_push', 'show_in_app', 'aspect_ratio', 'sort_order', 'slide_duration'];

    foreach ($fields as $field) {
        $value = $request->get_param($field);
        if ($value === null && isset($_POST[$field])) {
            $value = $_POST[$field];
        }

        if ($value !== null) {
            if ($field === 'title') {
                $update_data[$field] = sanitize_text_field($value);
            } elseif ($field === 'content') {
                $update_data[$field] = wp_kses_post($value);
            } elseif ($field === 'link') {
                $update_data[$field] = esc_url_raw($value);
            } elseif ($field === 'send_push' || $field === 'show_in_app') {
                $update_data[$field] = $value === '1' ? 1 : 0;
            } elseif ($field === 'sort_order' || $field === 'slide_duration') {
                $update_data[$field] = absint($value);
            } else {
                $update_data[$field] = sanitize_text_field($value);
            }
        }
    }

    // Handle dates
    $start_date = $request->get_param('start_date');
    $end_date   = $request->get_param('end_date');

    if ($start_date !== null) {
        $update_data['start_date'] = !empty($start_date) ? date('Y-m-d H:i:s', strtotime($start_date)) : null;
    }
    if ($end_date !== null) {
        $update_data['end_date'] = !empty($end_date) ? date('Y-m-d H:i:s', strtotime($end_date)) : null;
    }

    // Handle media URL (from URL input, not file upload)
    $media_url_param = $request->get_param('media_url');
    if (!empty($media_url_param) && empty($_FILES['media'])) {
        $update_data['media_url']  = esc_url_raw($media_url_param);
        // Determine media type from URL extension
        $extension                 = strtolower(pathinfo(parse_url($media_url_param, PHP_URL_PATH), PATHINFO_EXTENSION));
        $video_extensions          = ['mp4', 'webm', 'ogg', 'mov'];
        $update_data['media_type'] = in_array($extension, $video_extensions) ? 'video' : 'image';
    }

    // Handle media upload
    if (!empty($_FILES['media']) && $_FILES['media']['error'] === UPLOAD_ERR_OK) {
        $upload_result = checkin_notifications_handle_media_upload($_FILES['media']);
        if (is_wp_error($upload_result)) {
            return $upload_result;
        }
        $update_data['media_url']  = $upload_result['url'];
        $update_data['media_type'] = $upload_result['type'];

        // Delete old media if exists
        if (!empty($existing->media_url)) {
            $old_file = str_replace(wp_upload_dir()['baseurl'], wp_upload_dir()['basedir'], $existing->media_url);
            if (file_exists($old_file)) {
                wp_delete_file($old_file);
            }
        }
    }

    // Update in database
    $result = $wpdb->update($table_name, $update_data, ['id' => $id]);

    if ($result === false) {
        return new WP_Error('db_error', 'Không thể cập nhật thông báo', ['status' => 500]);
    }

    // Get updated notification for sending messages
    $updated_notification = $wpdb->get_row(
        $wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $id)
    );

    // Determine if we should send notifications
    // Send if:
    // 1. Status changed to active (scheduled -> active)
    // 2. Notification was already active and we're updating it (edit existing active notification)
    $is_status_changed_to_active = isset($update_data['status'])                                                                                                                                                                                                                                           && $update_data['status'] === 'active' && $existing->status !== 'active';
    $is_active_and_updated       = $updated_notification->status                                                                                                                                                                                                                              === 'active' && ($existing->type === $updated_notification->type);

    error_log('[Notifications] Update notification ID: ' . $id);
    error_log('[Notifications] Status changed to active: ' . ($is_status_changed_to_active ? 'yes' : 'no'));
    error_log('[Notifications] Is active and updated: ' . ($is_active_and_updated ? 'yes' : 'no'));
    error_log('[Notifications] Type: ' . $updated_notification->type);

    if ($is_status_changed_to_active || $is_active_and_updated) {
        if ($updated_notification->type === 'staff') {
            error_log('[Notifications] Sending push and Lark for staff notification');
            // Send push notification
            $branches = $updated_notification->branches ?? '[]';
            checkin_notifications_send_push($updated_notification->id, $updated_notification->title, $updated_notification->content, $branches);

            // Send Lark notification
            checkin_notifications_send_lark($updated_notification->id, $updated_notification->title, $updated_notification->content, $updated_notification->type);
        }
    }

    return rest_ensure_response([
        'success' => true,
        'message' => 'Cập nhật thông báo thành công'
    ]);
}

/**
 * Delete notification
 */
function checkin_notifications_delete($request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'checkin_mkt192_notifications';

    $id = absint($request['id']);

    // Get notification to delete media
    $notification = $wpdb->get_row(
        $wpdb->prepare("SELECT media_url FROM $table_name WHERE id = %d", $id)
    );

    if (!$notification) {
        return new WP_Error('not_found', 'Không tìm thấy thông báo', ['status' => 404]);
    }

    // Delete media file if exists
    if (!empty($notification->media_url)) {
        $file_path = str_replace(wp_upload_dir()['baseurl'], wp_upload_dir()['basedir'], $notification->media_url);
        if (file_exists($file_path)) {
            wp_delete_file($file_path);
        }
    }

    // Delete from database
    $result = $wpdb->delete($table_name, ['id' => $id]);

    if ($result === false) {
        return new WP_Error('db_error', 'Không thể xóa thông báo', ['status' => 500]);
    }

    return rest_ensure_response([
        'success' => true,
        'message' => 'Đã xóa thông báo thành công'
    ]);
}

/**
 * Get active notifications for frontend
 */
function checkin_notifications_get_active($request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'checkin_mkt192_notifications';

    $type      = sanitize_text_field($request->get_param('type') ?? 'homepage');
    $branch_id = sanitize_text_field($request->get_param('branch_id') ?? '');
    $limit     = absint($request->get_param('limit') ?? 5);

    $now = current_time('mysql');

    $sql = $wpdb->prepare(
        "SELECT id, title, content, media_url, media_type, aspect_ratio, link, sort_order, slide_duration
         FROM $table_name
         WHERE type = %s
           AND status = 'active'
           AND (start_date IS NULL OR start_date <= %s)
           AND (end_date IS NULL OR end_date >= %s)
         ORDER BY sort_order ASC, created_at DESC
         LIMIT %d",
        $type, $now, $now, $limit
    );

    $notifications = $wpdb->get_results($sql, ARRAY_A);

    // Filter by branch if specified
    if (!empty($branch_id)) {
        $notifications = array_filter($notifications, function($n) use ($branch_id) {
            $branches = json_decode($n['branches'] ?? '[]', true);
            return empty($branches) || in_array($branch_id, $branches);
        });
    }

    return rest_ensure_response([
        'success' => true,
        'data'    => array_values($notifications)
    ]);
}

/**
 * Track notification view
 * For staff notifications, also track which user viewed
 */
function checkin_notifications_track_view($request) {
    global $wpdb;
    $table_name  = $wpdb->prefix . 'checkin_mkt192_notifications';
    $views_table = $wpdb->prefix . 'checkin_mkt192_notification_views';

    $id      = absint($request['id']);
    $user_id = get_current_user_id();

    // Get notification to check type
    $notification = $wpdb->get_row($wpdb->prepare(
        "SELECT type FROM $table_name WHERE id = %d",
        $id
    ));

    if (!$notification) {
        return rest_ensure_response(['success' => false, 'message' => 'Notification not found']);
    }

    // Update total views count
    $wpdb->query(
        $wpdb->prepare(
            "UPDATE $table_name SET views = views + 1 WHERE id = %d",
            $id
        )
    );

    // For staff notifications, track individual user views (if logged in)
    if ($notification->type === 'staff' && $user_id > 0) {
        // Insert or ignore if already viewed
        $wpdb->query(
            $wpdb->prepare(
                "INSERT IGNORE INTO $views_table (notification_id, user_id, viewed_at)
                 VALUES (%d, %d, %s)",
                $id, $user_id, current_time('mysql')
            )
        );
    }

    return rest_ensure_response(['success' => true]);
}

/**
 * Get list of users who viewed a notification
 */
function checkin_notifications_get_viewers($request) {
    global $wpdb;
    $views_table         = $wpdb->prefix . 'checkin_mkt192_notification_views';
    $notifications_table = $wpdb->prefix . 'checkin_mkt192_notifications';

    $id = absint($request['id']);

    // Check if notification exists and is staff type
    $notification = $wpdb->get_row($wpdb->prepare(
        "SELECT type, views FROM $notifications_table WHERE id = %d",
        $id
    ));

    if (!$notification) {
        return new WP_Error('not_found', 'Không tìm thấy thông báo', ['status' => 404]);
    }

    if ($notification->type !== 'staff') {
        return new WP_Error('invalid_type', 'Chỉ hỗ trợ thông báo nhân viên', ['status' => 400]);
    }

    // Get viewers with user info
    $viewers = $wpdb->get_results($wpdb->prepare(
        "SELECT v.user_id, v.viewed_at, u.display_name, u.user_email
         FROM $views_table v
         LEFT JOIN {$wpdb->users} u ON v.user_id = u.ID
         WHERE v.notification_id = %d
         ORDER BY v.viewed_at DESC",
        $id
    ), ARRAY_A);

    // Add avatar URLs
    foreach ($viewers as &$viewer) {
        $viewer['avatar'] = get_avatar_url($viewer['user_id'], ['size' => 48]);
        // Get user role
        $user           = get_userdata($viewer['user_id']);
        $viewer['role'] = $user ? implode(', ', $user->roles) : '';
    }

    return rest_ensure_response([
        'success' => true,
        'data'    => [
            'total_views'  => (int) $notification->views,
            'unique_views' => count($viewers),
            'viewers'      => $viewers
        ]
    ]);
}

// =============================================================================
// HELPER FUNCTIONS
// =============================================================================

/**
 * Handle media file upload
 */
function checkin_notifications_handle_media_upload($file) {
    // Validate file type
    $allowed_types = [
        'image/jpeg',
        'image/png',
        'image/gif',
        'image/webp',
        'video/mp4',
        'video/webm'
    ];

    if (!in_array($file['type'], $allowed_types)) {
        return new WP_Error('invalid_type', 'Định dạng file không được hỗ trợ', ['status' => 400]);
    }

    // Validate file size (10MB max)
    $max_size = 10 * 1024 * 1024;
    if ($file['size'] > $max_size) {
        return new WP_Error('file_too_large', 'File quá lớn. Tối đa 10MB', ['status' => 400]);
    }

    // Create upload directory
    $upload_dir        = wp_upload_dir();
    $notifications_dir = $upload_dir['basedir'] . '/notifications';

    if (!file_exists($notifications_dir)) {
        wp_mkdir_p($notifications_dir);
    }

    // Generate unique filename
    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename  = 'notification_' . time() . '_' . wp_generate_uuid4() . '.' . $extension;
    $filepath  = $notifications_dir . '/' . $filename;

    // Move uploaded file
    if (!move_uploaded_file($file['tmp_name'], $filepath)) {
        return new WP_Error('upload_failed', 'Không thể tải lên file', ['status' => 500]);
    }

    // Determine media type
    $media_type = strpos($file['type'], 'video') !== false ? 'video' : 'image';

    return [
        'url'  => $upload_dir['baseurl'] . '/notifications/' . $filename,
        'type' => $media_type
    ];
}

/**
 * Send push notification to staff using the centralized push notification system
 *
 * @param int $notification_id The notification ID
 * @param string $title The notification title
 * @param string $content The notification content
 * @param string $branches_json JSON encoded array of branch IDs
 * @return bool Success status
 */
function checkin_notifications_send_push($notification_id, $title, $content, $branches_json) {
    // Check if push notifications are enabled
    if (get_option('checkin_push_enabled', '0') !== '1') {
        error_log('[Notifications] Push notifications are disabled');
        return false;
    }

    // Check if checkin_push_send_to_users function exists
    if (!function_exists('checkin_push_send_to_users')) {
        error_log('[Notifications] Push notification system not available');
        return false;
    }

    // Check if staff_announcement notification type is enabled
    if (function_exists('checkin_push_is_notification_enabled') && !checkin_push_is_notification_enabled('staff_announcement')) {
        error_log('[Notifications] staff_announcement notification type is disabled');
        return false;
    }

    $branches = json_decode($branches_json, true) ?? [];

    // Get target users based on roles from push notification settings
    $allowed_roles = ['administrator', 'cashier', 'staff']; // Default roles
    if (function_exists('checkin_push_get_notification_roles')) {
        $allowed_roles = checkin_push_get_notification_roles('staff_announcement');
    }

    // Get all users with allowed roles
    $user_query = new WP_User_Query([
        'role__in' => $allowed_roles,
        'fields'   => 'ID',
    ]);
    $user_ids = $user_query->get_results();

    if (empty($user_ids)) {
        error_log('[Notifications] No users found with roles: ' . implode(', ', $allowed_roles));
        return false;
    }

    // Filter users by branch if branches are specified
    if (!empty($branches) && function_exists('checkin_push_filter_users_by_roles_and_branch')) {
        $filtered_user_ids = [];
        foreach ($branches as $branch_id) {
            $branch_users      = checkin_push_filter_users_by_roles_and_branch($user_ids, $allowed_roles, $branch_id);
            $filtered_user_ids = array_merge($filtered_user_ids, $branch_users);
        }
        $user_ids = array_unique($filtered_user_ids);
    }

    if (empty($user_ids)) {
        error_log('[Notifications] No users found after branch filtering');
        return false;
    }

    // Prepare notification content
    $clean_content = wp_strip_all_tags($content);
    $short_content = wp_trim_words($clean_content, 30, '...');

    // Build notification data
    $notification_data = [
        'title' => $title,
        'body'  => $short_content,
        'url'   => home_url('/app-tho?notification=' . $notification_id),
        'data'  => [
            'type'            => 'staff_announcement',
            'notification_id' => $notification_id,
        ],
    ];

    // Log for debugging
    error_log('[Notifications] Sending push to ' . count($user_ids) . ' users');
    error_log('[Notifications] Push data: ' . json_encode($notification_data));

    // Send using centralized push notification system
    $result = checkin_push_send_to_users($user_ids, $notification_data);

    if ($result['success']) {
        error_log('[Notifications] Push sent successfully: ' . ($result['sent'] ?? 0) . ' recipients');
        return true;
    } else {
        error_log('[Notifications] Push failed: ' . ($result['message'] ?? 'Unknown error'));
        return false;
    }
}

/**
 * Send Lark notification for staff announcements
 * Sends to Lark Group if Lark integration is enabled
 *
 * @param int    $notification_id Notification ID
 * @param string $title          Notification title
 * @param string $content        Notification content
 * @param string $type          Notification type (homepage/staff)
 *
 * @return bool Whether notification was sent successfully
 */
function checkin_notifications_send_lark($notification_id, $title, $content, $type) {
    // Check if Lark is enabled and configured
    if (get_option('checkin_use_lark', '0') !== '1') {
        return false;
    }

    // Only send for staff notifications
    if ($type !== 'staff') {
        return false;
    }

    // Load Lark helper
    $lark_helper_file = plugin_dir_path(__FILE__) . '../lark/class-checkin-mkt192-lark-helper.php';
    if (!file_exists($lark_helper_file)) {
        error_log('[Notifications] Lark helper not found');
        return false;
    }

    require_once $lark_helper_file;

    // Load Bot Manager to get appropriate bot
    $bot_manager_file = plugin_dir_path(__FILE__) . '../lark/class-checkin-mkt192-message-bot-manager.php';
    if (!file_exists($bot_manager_file)) {
        error_log('[Notifications] Lark Bot Manager not found');
        return false;
    }

    require_once $bot_manager_file;

    // Get bot manager instance
    if (!class_exists('Checkin_MKT192_Message_Bot_Manager')) {
        error_log('[Notifications] Lark Bot Manager class not found');
        return false;
    }

    $bot_manager = Checkin_MKT192_Message_Bot_Manager::get_instance();

    // Use 'general' type for general staff notifications
    // This maps to the appropriate webhook bot configured for general notifications
    $bot = $bot_manager->get_bot_by_notification_type('general');

    if (!$bot) {
        error_log('[Notifications] No Lark bot configured for "general" notification type');
        return false;
    }

    // Load card builder to create notification card
    $card_builder_file = plugin_dir_path(__FILE__) . '../lark/card-builder.php';
    if (!file_exists($card_builder_file)) {
        error_log('[Notifications] Card builder not found');
        return false;
    }

    require_once $card_builder_file;

    // Check if card builder function exists
    if (!function_exists('build_staff_notification_card')) {
        error_log('[Notifications] build_staff_notification_card function not found');
        return false;
    }

    // Build notification card
    $card = build_staff_notification_card($title, $content, $notification_id);

    error_log('[Notifications] Sending Lark message for notification ID: ' . $notification_id);
    error_log('[Notifications] Using bot: ' . $bot->bot_name . ' (Type: ' . $bot->bot_type . ')');

    // Send via bot manager (pass card data as third parameter)
    $result = $bot_manager->send_message('general', null, $card);

    if (is_wp_error($result)) {
        error_log('[Notifications] Lark send error: ' . $result->get_error_message());
        return false;
    }

    if (isset($result['code']) && $result['code'] === 0) {
        error_log('[Notifications] Lark notification sent successfully: ' . ($result['data']['message_id'] ?? 'unknown'));
        return true;
    }

    error_log('[Notifications] Lark send failed: ' . json_encode($result));
    return false;
}

// =============================================================================

// SCHEDULED STATUS UPDATE
// =============================================================================

/**
 * Update notification statuses based on dates
 */
function checkin_notifications_update_statuses() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'checkin_mkt192_notifications';
    $now        = current_time('mysql');

    // Activate scheduled notifications
    $wpdb->query($wpdb->prepare(
        "UPDATE $table_name
         SET status = 'active'
         WHERE status = 'scheduled'
           AND start_date IS NOT NULL
           AND start_date <= %s",
        $now
    ));

    // Expire active notifications
    $wpdb->query($wpdb->prepare(
        "UPDATE $table_name
         SET status = 'expired'
         WHERE status = 'active'
           AND end_date IS NOT NULL
           AND end_date < %s",
        $now
    ));
}

// Schedule cron job for status updates
if (!wp_next_scheduled('checkin_notifications_status_check')) {
    wp_schedule_event(time(), 'hourly', 'checkin_notifications_status_check');
}
add_action('checkin_notifications_status_check', 'checkin_notifications_update_statuses');

// =============================================================================
// REORDER NOTIFICATIONS
// =============================================================================

/**
 * Update sort order for multiple notifications (drag & drop)
 */
function checkin_notifications_reorder($request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'checkin_mkt192_notifications';

    $body  = $request->get_json_params();
    $items = $body['items'] ?? [];

    if (empty($items) || !is_array($items)) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Dữ liệu không hợp lệ'
        ], 400);
    }

    $updated = 0;
    foreach ($items as $item) {
        $id         = absint($item['id'] ?? 0);
        $sort_order = absint($item['sort_order'] ?? 0);

        if ($id > 0) {
            $result = $wpdb->update(
                $table_name,
                ['sort_order' => $sort_order, 'updated_at' => current_time('mysql')],
                ['id'         => $id],
                ['%d', '%s'],
                ['%d']
            );
            if ($result !== false) {
                $updated++;
            }
        }
    }

    return new WP_REST_Response([
        'success' => true,
        'message' => "Đã cập nhật thứ tự {$updated} thông báo",
        'updated' => $updated
    ]);
}
