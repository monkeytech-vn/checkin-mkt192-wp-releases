# Hệ thống Logging mới

## Tổng quan

Đã chuyển đổi từ việc log tất cả vào `debug.log` sang hệ thống log riêng biệt cho từng module trong thư mục `includes/rest-api/logs/`.

## Cấu trúc

### Log Helper (`includes/rest-api/log-helper.php`)

Cung cấp các functions để log:

```php
// Log ERROR (luôn ghi, không phụ thuộc WP_DEBUG)
checkin_mkt192_log_error('filename', 'Error message', ['context' => 'data']);

// Log INFO (chỉ ghi khi WP_DEBUG = true)
checkin_mkt192_log_info('filename', 'Info message', ['context' => 'data']);

// Log DEBUG (chỉ ghi khi WP_DEBUG = true)
checkin_mkt192_log_debug('filename', 'Debug message', ['context' => 'data']);

// Log với custom level
checkin_mkt192_log('filename', 'Message', 'WARNING', ['context' => 'data']);
```

### Log Files

Tất cả log files được lưu trong `includes/rest-api/logs/`:

- `permission.log` - Lỗi phân quyền
- `zalo_token.log` - Lỗi Zalo token
- `zalo_oa.log` - Lỗi Zalo OA API
- `zalo_cron.log` - Cron refresh token
- `zalo_update_user.log` - Cập nhật user details trên Zalo
- `zalo_update_custom.log` - Cập nhật custom info trên Zalo
- `zalo_tag.log` - Tag follower trên Zalo
- `zalo_send_message.log` - Gửi message Zalo
- `customer_registration.log` - Đăng ký thành viên
- `customer_create.log` - Tạo customer
- `customer_update.log` - Cập nhật customer
- `login.log` - Lỗi đăng nhập
- `cleanup_history.log` - Lịch sử dọn dẹp log

## Auto Cleanup

### Cron Job

Class `Checkin_MKT192_LogCleanup` (trong `includes/automation/`) tự động:

- Chạy mỗi 2 ngày vào 23:59
- Xóa tất cả log files trong `includes/rest-api/logs/`
- Ghi lịch sử vào `cleanup_history.log`

### Kích hoạt

Cron được tự động schedule khi plugin activate.

### Hủy schedule

Cron được tự động unschedule khi plugin deactivate.

## Thay đổi chính

### Permission.php

- **Trước:** Log mọi check scope → spam debug.log
- **Sau:** Chỉ log ERROR khi permission denied

### Zalo-api.php

- **Trước:** Log mọi HTTP request → spam debug.log
- **Sau:** Chỉ log ERROR khi có lỗi (cURL error, non-200 HTTP code)

### Login.php

- **Trước:** `error_log('Bad Signed JSON signature!')`
- **Sau:** `checkin_mkt192_log_error('login', 'Bad Signed JSON signature...', context)`

### Customer-api.php

- **Trước:** Log trực tiếp vào debug.log
- **Sau:**
  - `customer_registration.log` - Lỗi đăng ký thành viên
  - `zalo_*.log` - Lỗi các API Zalo
  - Context đầy đủ (customer_id, error, trace)

## Lợi ích

✅ **Debug.log nhẹ hơn** - Không còn spam từ permission checks
✅ **Dễ debug** - Mỗi module có log riêng
✅ **Context đầy đủ** - JSON format với data liên quan
✅ **Tự động dọn dẹp** - Không lo log files tích tụ
✅ **Production-ready** - Chỉ log ERROR ngoài debug mode

## Ví dụ sử dụng

### Thêm log vào file mới

```php
// 1. Include log-helper.php (đã có trong rest-api-init.php)

// 2. Log ERROR
if ($result === false) {
    checkin_mkt192_log_error('my_module', 'Operation failed', [
        'user_id' => $user_id,
        'error' => $wpdb->last_error
    ]);
}

// 3. Log INFO (development only)
checkin_mkt192_log_info('my_module', 'Operation successful', [
    'processed_items' => count($items)
]);
```

### Format log entry

```
[2024-11-10 14:30:45] [ERROR] Operation failed | Context: {
    "user_id": "123",
    "error": "Duplicate entry"
}
```

## Test

1. Đăng ký thành viên mới → check `customer_registration.log`
2. Sai permission → check `permission.log`
3. Refresh Zalo token → check `zalo_cron.log`
4. Đợi 2 ngày → check `cleanup_history.log`
