<?php

add_action('rest_api_init', function () {
    // Staff Levels - GET (List/read staff level history)
    register_rest_route('vg/v1', '/staff-levels', [
        'methods'             => 'GET',
        'callback'            => 'checkin_mkt192_get_staff_levels_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'staff_level.read'])
    ]);
    // Staff Levels - POST (Create/assign new staff level)
    register_rest_route('vg/v1', '/staff-levels', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_save_staff_level_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'staff_level.create'])
    ]);
    // Staff Levels - PUT (Update staff level assignment)
    register_rest_route('vg/v1', '/staff-levels/(?P<id>\d+)', [
        'methods'             => 'PUT',
        'callback'            => 'checkin_mkt192_update_staff_level_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'staff_level.update'])
    ]);
    // Staff Levels - DELETE (Remove staff level record)
    register_rest_route('vg/v1', '/staff-levels/(?P<id>\d+)', [
        'methods'             => 'DELETE',
        'callback'            => 'checkin_mkt192_delete_staff_level_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'staff_level.delete'])
    ]);
});

function checkin_mkt192_get_staff_levels_api(WP_REST_Request $request) {
    global $wpdb;

    try {
        $staff_name = sanitize_text_field($request->get_param('staff_name'));
        $date       = sanitize_text_field($request->get_param('date'));

        // Khởi tạo câu truy vấn cơ bản
        $query = "SELECT id, role, staff_id, staff_name, level_name, start_time, end_time
                  FROM {$wpdb->prefix}checkin_mkt192_staff_level_history";
        $params     = [];
        $conditions = [];

        // Nếu có staff_name và date, lấy cấp bậc hiện tại tại thời điểm date
        if ($staff_name && $date) {
            $conditions[] = 'staff_name = %s';
            $conditions[] = 'start_time <= %s';
            $conditions[] = '(end_time IS NULL OR end_time >= %s)';
            $params       = [$staff_name, $date, $date];
            $query .= ' WHERE ' . implode(' AND ', $conditions);
            $query .= ' ORDER BY start_time DESC LIMIT 1';
        } else {
            // Nếu không có tham số, lấy toàn bộ lịch sử cấp bậc
            $query .= ' ORDER BY start_time DESC';
        }

        $levels = $wpdb->get_results($wpdb->prepare($query, $params), OBJECT);

        if (empty($levels)) {
            return new WP_REST_Response([
                'success' => false,
                'message' => 'Không tìm thấy dữ liệu cấp bậc'
            ], 404);
        }

        return new WP_REST_Response([
            'success' => true,
            'data'    => $staff_name && $date ? $levels[0] : $levels
        ], 200);
    } catch (Exception $e) {
        file_put_contents(__DIR__ . '/logs/staff_level_errors.log', date('Y-m-d H:i:s') . ' - Failed to fetch staff levels: ' . $e->getMessage() . "\n", FILE_APPEND);
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Lỗi hệ thống'
        ], 500);
    }
}

function checkin_mkt192_save_staff_level_api(WP_REST_Request $request) {
    global $wpdb;
    $data = $request->get_json_params();

    $staff_id   = sanitize_text_field($data['staff_id'] ?? '');
    $staff_name = sanitize_text_field($data['staff_name'] ?? '');
    $role       = sanitize_text_field($data['role'] ?? '');
    $status     = sanitize_text_field($data['status'] ?? '');
    $level_name = sanitize_text_field($data['level_name'] ?? '');
    $start_time = !empty($data['start_time']) ? date('Y-m-d', strtotime($data['start_time'])) : null;
    $end_time   = !empty($data['end_time']) ? date('Y-m-d', strtotime($data['end_time'])) : null;
    $condition  = sanitize_textarea_field($data['condition'] ?? '');

    if (empty($level_name)) {
        return new WP_REST_Response(['success' => false, 'message' => 'Tên cấp nhân viên không được để trống'], 400);
    }

    try {
        $wpdb->insert(
            "{$wpdb->prefix}checkin_mkt192_staff_level_history",
            [
                'staff_id'   => $staff_id,
                'staff_name' => $staff_name,
                'role'       => $role,
                'status'     => $status,
                'level_name' => $level_name,
                'start_time' => $start_time,
                'end_time'   => $end_time,
                'condition'  => $condition
            ]
        );
        return new WP_REST_Response(['success' => true, 'message' => 'Thêm cấp nhân viên thành công'], 200);
    } catch (Exception $e) {
        file_put_contents(__DIR__ . '/logs/staff_level_errors.log', date('Y-m-d H:i:s') . ' - Save staff level error: ' . $e->getMessage() . "\n", FILE_APPEND);
        return new WP_REST_Response(['success' => false, 'message' => 'Lỗi hệ thống: ' . $e->getMessage()], 500);
    }
}

function checkin_mkt192_update_staff_level_api(WP_REST_Request $request) {
    global $wpdb;
    $id   = $request->get_param('id');
    $data = $request->get_json_params();

    $staff_id   = sanitize_text_field($data['staff_id'] ?? '');
    $staff_name = sanitize_text_field($data['staff_name'] ?? '');
    $role       = sanitize_text_field($data['role'] ?? '');
    $status     = sanitize_text_field($data['status'] ?? '');
    $level_name = sanitize_text_field($data['level_name'] ?? '');
    $start_time = !empty($data['start_time']) ? date('Y-m-d', strtotime($data['start_time'])) : null;
    $end_time   = !empty($data['end_time']) ? date('Y-m-d', strtotime($data['end_time'])) : null;
    $condition  = sanitize_textarea_field($data['condition'] ?? '');

    try {
        $level_exists = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}checkin_mkt192_staff_level_history WHERE id = %d",
            $id
        ));

        if (!$level_exists) {
            return new WP_REST_Response(['success' => false, 'message' => 'Cấp nhân viên không tồn tại'], 404);
        }

        $wpdb->update(
            "{$wpdb->prefix}checkin_mkt192_staff_level_history",
            [
                'staff_id'   => $staff_id,
                'staff_name' => $staff_name,
                'role'       => $role,
                'status'     => $status,
                'level_name' => $level_name,
                'start_time' => $start_time,
                'end_time'   => $end_time,
                'condition'  => $condition
            ],
            ['id' => $id]
        );
        return new WP_REST_Response(['success' => true, 'message' => 'Cập nhật cấp nhân viên thành công'], 200);
    } catch (Exception $e) {
        file_put_contents(__DIR__ . '/logs/staff_level_errors.log', date('Y-m-d H:i:s') . ' - Update staff level error: ' . $e->getMessage() . "\n", FILE_APPEND);
        return new WP_REST_Response(['success' => false, 'message' => 'Lỗi hệ thống: ' . $e->getMessage()], 500);
    }
}

function checkin_mkt192_delete_staff_level_api(WP_REST_Request $request) {
    global $wpdb;
    $id = $request->get_param('id');
    try {
        $wpdb->delete(
            "{$wpdb->prefix}checkin_mkt192_staff_level_history",
            ['id' => $id]
        );
        return new WP_REST_Response(['success' => true, 'message' => 'Xóa cấp nhân viên thành công'], 200);
    } catch (Exception $e) {
        file_put_contents(__DIR__ . '/logs/staff_level_errors.log', date('Y-m-d H:i:s') . ' - Delete staff level error: ' . $e->getMessage() . "\n", FILE_APPEND);
        return new WP_REST_Response(['success' => false, 'message' => 'Lỗi hệ thống'], 500);
    }
}