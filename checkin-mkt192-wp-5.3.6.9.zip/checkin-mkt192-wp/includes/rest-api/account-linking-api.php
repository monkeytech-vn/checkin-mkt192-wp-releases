<?php

/**
 * Account Linking API - Liên kết tài khoản mạng xã hội mới với tài khoản hiện có
 *
 * Use cases:
 * - User mất tài khoản Google/Facebook cũ và tạo tài khoản mới
 * - User muốn liên kết tài khoản mạng xã hội khác với tài khoản hiện tại
 *
 * Xác minh quyền sở hữu bằng: username + employee_id hoặc username + birthday
 *
 * @package Checkin_MKT192_WP
 * @since 5.3.1
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Đăng ký REST API endpoints cho account linking
 */
add_action('rest_api_init', function () {

    // Endpoint để xác minh và liên kết tài khoản (đơn giản hóa)
    register_rest_route('vg/v1', '/account-linking/verify', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt_verify_and_link_account',
        'permission_callback' => '__return_true',
    ]);

    // Endpoint để lấy danh sách tài khoản liên kết
    register_rest_route('vg/v1', '/account-linking/linked-accounts', [
        'methods'             => 'GET',
        'callback'            => 'checkin_mkt_get_linked_accounts',
        'permission_callback' => function () {
            return is_user_logged_in();
        },
    ]);

    // Endpoint để hủy liên kết tài khoản mạng xã hội
    register_rest_route('vg/v1', '/account-linking/unlink', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt_unlink_social_account',
        'permission_callback' => function () {
            return is_user_logged_in();
        },
    ]);
});

/**
 * Xác minh và liên kết tài khoản
 *
 * Yêu cầu: username + (employee_id HOẶC birthday)
 * Đây là thông tin chỉ nhân viên đó mới biết
 */
function checkin_mkt_verify_and_link_account(WP_REST_Request $request) {
    global $wpdb;

    $params               = $request->get_json_params();
    $username             = sanitize_text_field($params['username'] ?? '');
    $employee_id          = sanitize_text_field($params['employee_id'] ?? '');
    $birthday             = sanitize_text_field($params['birthday'] ?? ''); // Format: YYYY-MM-DD
    $new_email            = sanitize_email($params['new_email'] ?? '');
    $provider             = sanitize_text_field($params['provider'] ?? 'google');
    $remember             = $params['remember'] ?? true;
    $update_primary_email = !empty($params['update_primary_email']); // Đổi email chính

    // Validate input
    if (empty($username)) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Vui lòng nhập tên đăng nhập (username) của tài khoản cũ.',
        ], 400);
    }

    if (empty($employee_id) && empty($birthday)) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Vui lòng nhập mã nhân viên hoặc ngày sinh để xác minh.',
        ], 400);
    }

    // Tìm user theo username
    $user = get_user_by('login', $username);
    if (!$user) {
        // Thử tìm theo email (có thể user nhập email thay vì username)
        $user = get_user_by('email', $username);
    }

    if (!$user) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Không tìm thấy tài khoản với username này.',
        ], 404);
    }

    // Lấy thông tin staff
    $staff_table = $wpdb->prefix . 'checkin_mkt192_staff';
    $staff       = $wpdb->get_row($wpdb->prepare(
        "SELECT id, user_id, employee_id, display_name, user_email, user_login, birthday, status
         FROM $staff_table
         WHERE (user_id = %d OR user_login = %s) AND status != 'DELETED'",
        $user->ID,
        $user->user_login
    ));

    if (!$staff) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Không tìm thấy thông tin nhân viên liên kết với tài khoản này.',
        ], 404);
    }

    // Xác minh quyền sở hữu
    $verified = false;

    // Cách 1: Xác minh bằng employee_id
    if (!empty($employee_id)) {
        if (strtolower(trim($staff->employee_id)) === strtolower(trim($employee_id))) {
            $verified = true;
        }
    }

    // Cách 2: Xác minh bằng birthday (nếu chưa verify bằng employee_id)
    if (!$verified && !empty($birthday) && !empty($staff->birthday)) {
        // Chuẩn hóa format ngày
        $input_date = date('Y-m-d', strtotime($birthday));
        $staff_date = date('Y-m-d', strtotime($staff->birthday));

        if ($input_date === $staff_date) {
            $verified = true;
        }
    }

    if (!$verified) {
        // Ghi log để phát hiện brute force
        checkin_mkt192_log_info('account-linking', 'Verification failed', [
            'username'    => $username,
            'employee_id' => $employee_id ? '***' : 'not provided',
            'birthday'    => $birthday ? '***' : 'not provided',
            'ip'          => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
        ]);

        return new WP_REST_Response([
            'success' => false,
            'message' => 'Thông tin xác minh không chính xác. Vui lòng kiểm tra lại mã nhân viên hoặc ngày sinh.',
        ], 401);
    }

    // Xác minh thành công - thực hiện liên kết
    $linking_data = [
        'staff_id'             => $staff->id,
        'user_id'              => $user->ID,
        'new_email'            => $new_email,
        'provider'             => $provider,
        'old_email'            => $staff->user_email,
        'update_primary_email' => $update_primary_email,
    ];

    $result = checkin_mkt_complete_account_linking($linking_data);

    if (is_wp_error($result)) {
        return new WP_REST_Response([
            'success' => false,
            'message' => $result->get_error_message(),
        ], 500);
    }

    // Đăng nhập user
    wp_set_current_user($user->ID);
    wp_set_auth_cookie($user->ID, $remember);
    do_action('wp_login', $user->user_login, $user);
    wp_set_current_user($user->ID);

    $new_nonce    = wp_create_nonce('wp_rest');
    $profile_data = function_exists('checkin_mkt_get_profile_data_for_user')
        ? checkin_mkt_get_profile_data_for_user($user->ID)
        : null;

    return new WP_REST_Response([
        'success' => true,
        'message' => 'Liên kết tài khoản thành công! Lần sau bạn có thể đăng nhập trực tiếp bằng tài khoản ' . ucfirst($provider) . ' mới.',
        'nonce'   => $new_nonce,
        'profile' => $profile_data,
    ], 200);
}

/**
 * Hoàn tất quá trình liên kết tài khoản
 */
function checkin_mkt_complete_account_linking($linking_data) {
    global $wpdb;

    $user_id              = $linking_data['user_id'];
    $new_email            = $linking_data['new_email'];
    $provider             = $linking_data['provider'];
    $old_email            = $linking_data['old_email'];
    $update_primary_email = $linking_data['update_primary_email'] ?? false;

    // Lưu thông tin liên kết vào user meta
    $linked_accounts = get_user_meta($user_id, 'linked_social_accounts', true);
    if (!is_array($linked_accounts)) {
        $linked_accounts = [];
    }

    $linked_accounts[$provider] = [
        'email'      => $new_email,
        'linked_at'  => current_time('mysql'),
        'is_primary' => empty($linked_accounts),
    ];

    update_user_meta($user_id, 'linked_social_accounts', $linked_accounts);

    // Xử lý email
    if (!empty($new_email) && $new_email !== $old_email) {
        $secondary_emails = get_user_meta($user_id, 'secondary_emails', true);
        if (!is_array($secondary_emails)) {
            $secondary_emails = [];
        }

        if ($update_primary_email) {
            // Đổi email chính thành email mới
            // 1. Lưu email cũ vào secondary_emails
            if (!in_array($old_email, $secondary_emails)) {
                $secondary_emails[] = $old_email;
            }
            // 2. Xóa email mới khỏi secondary nếu có
            $secondary_emails = array_values(array_diff($secondary_emails, [$new_email]));
            update_user_meta($user_id, 'secondary_emails', $secondary_emails);

            // 3. Cập nhật email chính trong wp_users
            wp_update_user([
                'ID'         => $user_id,
                'user_email' => $new_email,
            ]);

            // 4. Cập nhật email trong bảng staff
            $staff_table = $wpdb->prefix . 'checkin_mkt192_staff';
            $wpdb->update(
                $staff_table,
                ['user_email' => $new_email],
                ['user_id'    => $user_id],
                ['%s'],
                ['%d']
            );
        } else {
            // Giữ email cũ làm chính, thêm email mới vào secondary
            if (!in_array($new_email, $secondary_emails)) {
                $secondary_emails[] = $new_email;
                update_user_meta($user_id, 'secondary_emails', $secondary_emails);
            }
        }
    }

    // Ghi log
    checkin_mkt192_log_info('account-linking', 'Account linked successfully', [
        'user_id'   => $user_id,
        'new_email' => checkin_mkt_mask_email($new_email),
        'provider'  => $provider,
    ]);

    return true;
}

/**
 * Lấy danh sách tài khoản đã liên kết
 */
function checkin_mkt_get_linked_accounts(WP_REST_Request $request) {
    $user_id = get_current_user_id();

    $linked_accounts  = get_user_meta($user_id, 'linked_social_accounts', true);
    $secondary_emails = get_user_meta($user_id, 'secondary_emails', true);

    if (!is_array($linked_accounts)) {
        $linked_accounts = [];
    }

    if (!is_array($secondary_emails)) {
        $secondary_emails = [];
    }

    // Mask emails cho bảo mật
    $masked_accounts = [];
    foreach ($linked_accounts as $provider => $data) {
        $masked_accounts[$provider] = [
            'masked_email' => checkin_mkt_mask_email($data['email']),
            'linked_at'    => $data['linked_at'],
            'is_primary'   => $data['is_primary'] ?? false,
        ];
    }

    return new WP_REST_Response([
        'success'          => true,
        'linked_accounts'  => $masked_accounts,
        'secondary_emails' => array_map('checkin_mkt_mask_email', $secondary_emails),
    ], 200);
}

/**
 * Hủy liên kết tài khoản mạng xã hội
 */
function checkin_mkt_unlink_social_account(WP_REST_Request $request) {
    $user_id  = get_current_user_id();
    $params   = $request->get_json_params();
    $provider = sanitize_text_field($params['provider'] ?? '');

    if (empty($provider)) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Vui lòng chọn tài khoản cần hủy liên kết.',
        ], 400);
    }

    $linked_accounts = get_user_meta($user_id, 'linked_social_accounts', true);

    if (!is_array($linked_accounts) || !isset($linked_accounts[$provider])) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Không tìm thấy tài khoản liên kết.',
        ], 404);
    }

    // Xóa email khỏi secondary emails
    $email_to_remove  = $linked_accounts[$provider]['email'];
    $secondary_emails = get_user_meta($user_id, 'secondary_emails', true);

    if (is_array($secondary_emails)) {
        $secondary_emails = array_filter($secondary_emails, function ($email) use ($email_to_remove) {
            return $email !== $email_to_remove;
        });
        update_user_meta($user_id, 'secondary_emails', array_values($secondary_emails));
    }

    // Xóa tài khoản liên kết
    unset($linked_accounts[$provider]);
    update_user_meta($user_id, 'linked_social_accounts', $linked_accounts);

    // Ghi log
    checkin_mkt192_log_info('account-linking', 'Social account unlinked', [
        'user_id'  => $user_id,
        'provider' => $provider,
    ]);

    return new WP_REST_Response([
        'success' => true,
        'message' => 'Đã hủy liên kết tài khoản.',
    ], 200);
}

/**
 * Mask email để bảo mật (ví dụ: t***@example.com)
 */
function checkin_mkt_mask_email($email) {
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return '***@***.***';
    }

    $parts    = explode('@', $email);
    $name     = $parts[0];
    $domain   = $parts[1];

    $name_len = strlen($name);
    if ($name_len <= 2) {
        $masked_name = $name[0] . '***';
    } else {
        $masked_name = $name[0] . str_repeat('*', $name_len - 2) . substr($name, -1);
    }

    $domain_parts = explode('.', $domain);
    if (strlen($domain_parts[0]) > 2) {
        $domain_parts[0] = $domain_parts[0][0] . '***';
    }

    return $masked_name . '@' . implode('.', $domain_parts);
}

/**
 * Log helper
 */
if (!function_exists('checkin_mkt192_log_info')) {
    function checkin_mkt192_log_info($context, $message, $data = []) {
        if (function_exists('checkin_mkt192_log_error')) {
            checkin_mkt192_log_error($context, '[INFO] ' . $message, $data);
        } else {
            error_log("[Checkin MKT192][$context] $message: " . wp_json_encode($data));
        }
    }
}
