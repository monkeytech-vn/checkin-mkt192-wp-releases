<?php

add_action('rest_api_init', function () {
    // Xem danh sách khách hàng (dùng scope đã cấu hình trong vai trò)
    register_rest_route('vg/v1', '/customers', [
        'methods'             => 'GET',
        'callback'            => 'checkin_mkt192_get_customers_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'customer.read'])
    ]);

    // Staff: Upload ảnh khách hàng (trong quá trình phục vụ)
    register_rest_route('vg/v1', '/upload-customer-image', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_upload_customer_image_api',
        'permission_callback' => function () { return is_user_logged_in(); } // Self-service for staff
    ]);

    // Staff: Upload ảnh feedback
    register_rest_route('vg/v1', '/upload-feedback-image', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_upload_feedback_image_api',
        'permission_callback' => function () { return is_user_logged_in(); } // Self-service for staff
    ]);

    // Admin: Tạo khách hàng mới
    register_rest_route('vg/v1', '/customers', [
    'methods'             => 'POST',
    'callback'            => 'checkin_mkt192_create_customer_api',
    'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'customer.create']),
    'args'                => [
        'customer_phone' => [
            'required'          => true,
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'validate_callback' => function ($param) {
                return preg_match('/^[0-9]{10,11}$/', $param); // Số điện thoại 10-11 số
            },
        ],
        'customer_name' => [
            'required'          => true,
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
        ],
        'customer_birthday' => [
            'required'          => false,
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'validate_callback' => function ($param) {
                return empty($param) || preg_match('/^\d{4}-\d{2}-\d{2}$/', $param); // Định dạng YYYY-MM-DD
            },
        ],
    ],
]);

     // Public: Tra cứu thông tin khuyến mãi của khách (booking form)
     register_rest_route('vg/v1', '/customer-promo', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_get_customer_member',
        'permission_callback' => '__return_true', // Public endpoint
    ]);

    // Public: Đăng ký thành viên (từ Zalo OA)
    register_rest_route('vg/v1', '/customer-registration', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_customer_registration_api',
        'permission_callback' => '__return_true', // Public endpoint
        'args'                => [
            'customer_phone' => [
                'required'          => false, // Validate trong hàm xử lý
                'type'              => 'string',
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'customer_name' => [
                'required'          => false, // Validate trong hàm xử lý
                'type'              => 'string',
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'customer_birthday' => [
                'required'          => false,
                'type'              => 'string',
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'gender' => [
                'required'          => false,
                'type'              => 'string',
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'email' => [
                'required'          => false,
                'type'              => 'string',
                'sanitize_callback' => 'sanitize_email',
            ],
            'address' => [
                'required'          => false,
                'type'              => 'string',
                'sanitize_callback' => 'sanitize_textarea_field',
            ],
            'id_zalo' => [
                'required'          => false,
                'type'              => 'string',
                'sanitize_callback' => 'sanitize_text_field',
            ],
        ],
    ]);

    // Staff: Cập nhật thông tin khách hàng
    register_rest_route('vg/v1', '/customers/(?P<customer_id>[A-Za-z0-9]+)', [
        'methods'             => 'PUT',
        'callback'            => 'checkin_mkt192_update_customer_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'customer.update']),
        'args'                => [
            'customer_id' => [
                'required'          => true,
                'validate_callback' => function($param) {
                    // Chấp nhận cả chữ và số (VG0004, 123, etc.)
                    return preg_match('/^[A-Za-z0-9]+$/', $param);
                }
            ]
        ]
    ]);

    // Public: Lấy chi tiết hóa đơn theo mã (code) hoặc ngày tạo - trả về thông tin dùng cho modal
    register_rest_route('vg/v1', '/invoice-detail', [
        'methods'             => 'GET',
        'callback'            => 'checkin_mkt192_get_invoice_detail',
        'permission_callback' => '__return_true',
        'args'                => [
            'code' => [
                'required'          => false,
                'type'              => 'string',
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'created_at' => [
                'required'          => false,
                'type'              => 'string',
                'sanitize_callback' => 'sanitize_text_field',
            ],
        ],
    ]);
});

function checkin_mkt192_update_customer_api(WP_REST_Request $request) {
    global $wpdb;

    // Lấy customer_id dưới dạng string để hỗ trợ cả ID dạng VG0004 và 123
    $customer_id = sanitize_text_field($request->get_param('customer_id'));
    $data        = $request->get_json_params();

    if (empty($customer_id)) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'ID khách hàng không hợp lệ'
        ], 400);
    }

    // Kiểm tra khách hàng có tồn tại không - dùng %s thay vì %d để hỗ trợ string ID
    $customer = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}bookingmkt192_customer_data WHERE customer_id = %s",
        $customer_id
    ));

    if (!$customer) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Không tìm thấy khách hàng'
        ], 404);
    }

    // Chuẩn bị dữ liệu update
    $update_data = [];

    if (isset($data['customer_name'])) {
        $update_data['customer_name'] = sanitize_text_field($data['customer_name']);
    }

    if (isset($data['customer_phone'])) {
        $phone = sanitize_text_field($data['customer_phone']);
        // Chuẩn hóa: bỏ số 0 đầu nếu có
        $phone = ltrim($phone, '0');

        if (!preg_match('/^[0-9]{9,10}$/', $phone)) {
            return new WP_REST_Response([
                'success' => false,
                'message' => 'Số điện thoại không hợp lệ'
            ], 400);
        }

        $update_data['customer_phone'] = $phone;
    }

    if (isset($data['customer_birthday'])) {
        $update_data['customer_birthday'] = sanitize_text_field($data['customer_birthday']);
    }

    // ✅ Hỗ trợ update status_code (CÓ HIỆU LỰC, KHÔNG ÁP DỤNG, HẾT HẠN SỬ DỤNG)
    if (isset($data['status_code'])) {
        $allowed_statuses = ['CÓ HIỆU LỰC', 'KHÔNG ÁP DỤNG', 'HẾT HẠN SỬ DỤNG'];
        $status_code      = sanitize_text_field($data['status_code']);

        if (in_array($status_code, $allowed_statuses, true)) {
            $update_data['status_code'] = $status_code;
        }
    }

    if (empty($update_data)) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Không có dữ liệu để cập nhật'
        ], 400);
    }

    // Lưu thông tin cũ để update booking
    $old_phone = $customer->customer_phone;
    $old_name  = $customer->customer_name;

    // Thực hiện update customer - dùng %s cho customer_id để hỗ trợ cả string ID
    $result = $wpdb->update(
        $wpdb->prefix . 'bookingmkt192_customer_data',
        $update_data,
        ['customer_id' => $customer_id],
        array_fill(0, count($update_data), '%s'),
        ['%s']
    );

    if ($result === false) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Lỗi cập nhật dữ liệu: ' . $wpdb->last_error
        ], 500);
    }

    // Cập nhật thông tin trong booking table nếu phone hoặc name thay đổi
    $booking_updates = [];
    $booking_updated = 0;

    if (isset($update_data['customer_phone']) && $update_data['customer_phone'] !== $old_phone) {
        // Tạo phone variants cho query
        $old_without_zero = ltrim($old_phone, '0');
        $old_with_zero    = (strlen($old_without_zero) === 9) ? '0' . $old_without_zero : $old_phone;
        $new_phone        = $update_data['customer_phone'];

        // Update booking với cả 2 format số cũ (có và không có số 0)
        $booking_result = $wpdb->query($wpdb->prepare(
            "UPDATE {$wpdb->prefix}bookingmkt192_booking_data
             SET customer_phone = %s
             WHERE customer_phone IN (%s, %s)",
            $new_phone,
            $old_without_zero,
            $old_with_zero
        ));

        if ($booking_result !== false) {
            $booking_updated += $booking_result;
            $booking_updates[] = 'phone';
        }
    }

    if (isset($update_data['customer_name']) && $update_data['customer_name'] !== $old_name) {
        // Tạo phone variants của customer để tìm tất cả booking
        $phone_for_name_update = isset($update_data['customer_phone']) ? $update_data['customer_phone'] : $old_phone;
        $without_zero          = ltrim($phone_for_name_update, '0');
        $with_zero             = (strlen($without_zero) === 9) ? '0' . $without_zero : $phone_for_name_update;

        // Update booking theo tên cũ HOẶC số điện thoại (cả 2 format)
        $booking_result = $wpdb->query($wpdb->prepare(
            "UPDATE {$wpdb->prefix}bookingmkt192_booking_data
             SET customer_name = %s
             WHERE customer_name = %s OR customer_phone IN (%s, %s)",
            $update_data['customer_name'],
            $old_name,
            $without_zero,
            $with_zero
        ));

        if ($booking_result !== false) {
            $booking_updated += $booking_result;
            if (!in_array('name', $booking_updates)) {
                $booking_updates[] = 'name';
            }
        }
    }

    $response_data = [
        'customer_id'    => $customer_id,
        'updated_fields' => array_keys($update_data)
    ];

    if ($booking_updated > 0) {
        $response_data['booking_updated'] = $booking_updated;
        $response_data['booking_fields']  = $booking_updates;
    }

    return new WP_REST_Response([
        'success' => true,
        'message' => 'Cập nhật thông tin khách hàng thành công' .
                     ($booking_updated > 0 ? " (đã cập nhật {$booking_updated} booking)" : ''),
        'data'    => $response_data
    ], 200);
}

function checkin_mkt192_get_customers_api(WP_REST_Request $request) {
    global $wpdb;

    try {
        // Lấy tham số 'phone' và 'branch_id' từ request
        $phone     = $request->get_param('phone');
        $branch_id = intval($request->get_param('branch_id') ?: 0);

        // Đặt múi giờ Việt Nam để xác định ngày hôm nay
        $today = date('Y-m-d');

        // Khởi tạo truy vấn cơ bản cho bảng khách hàng
        $query = "SELECT customer_id, customer_phone, customer_name, name_zalo, id_zalo,
                         customer_birthday, membership_level, follower_zalo, hairdresser_name,
                         customer_address, new_checkin, new_code, status_code, new_customer, branch_id,
                         date_new_member
                  FROM {$wpdb->prefix}bookingmkt192_customer_data";

        // Thêm điều kiện WHERE nếu có tham số phone hoặc branch_id
        $where_conditions = [];

        if (!empty($phone)) {
            // Tạo variants của số điện thoại (có và không có số 0 đầu) để search
            $without_zero = ltrim($phone, '0');
            $with_zero    = (strlen($without_zero) === 9) ? '0' . $without_zero : $phone;

            // Escape values for direct use in query
            $where_conditions[] = $wpdb->prepare('customer_phone IN (%s, %s)', $without_zero, $with_zero);
        }

        if (!empty($branch_id)) {
            $where_conditions[] = $wpdb->prepare('branch_id = %d', $branch_id);
        }

        if (!empty($where_conditions)) {
            $query .= ' WHERE ' . implode(' AND ', $where_conditions);
        }

        // Sắp xếp theo customer_name
        $query .= ' ORDER BY customer_name ASC';

        // Thực thi truy vấn trực tiếp (không cần prepare vì đã sử dụng prepare cho từng điều kiện)
        $customers = $wpdb->get_results($query, OBJECT);

        if (empty($customers)) {
            return new WP_REST_Response([
                'success' => false,
                'message' => 'Không tìm thấy khách hàng nào.'
            ], 404);
        }

        // Định nghĩa mainBaseUrl
        $mainBaseUrl = WP_CONTENT_URL . '/uploads/checkin-mkt192-wp/customer_image/';

        // Xử lý dữ liệu customer_images cho từng khách hàng
        foreach ($customers as &$customer) {
            $customerId = $customer->customer_id;

            // Lấy invoice mới nhất có images (không phụ thuộc vào ngày để tránh lỗi timezone)
            $invoice = $wpdb->get_row($wpdb->prepare(
                "SELECT images, invoice_id, customer_id, created_at
                 FROM {$wpdb->prefix}checkin_mkt192_invoices_data
                 WHERE customer_id = %s
                 AND images IS NOT NULL
                 AND images != ''
                 AND images != '[]'
                 ORDER BY created_at DESC
                 LIMIT 1",
                $customerId
            ), OBJECT);

            if ($invoice && !empty($invoice->images)) {
                // Có invoice với images - decode và sử dụng
                $images = json_decode($invoice->images, true);

                if (is_array($images) && !empty($images)) {
                    $customer->customer_images = $images;
                } else {
                    $customer->customer_images = [];
                }
            } else {
                // Không còn sử dụng customer_images từ bảng customer_data (đã xóa cột)
                $customer->customer_images = [];
            }
        }

        return new WP_REST_Response([
            'success' => true,
            'data'    => $customers
        ], 200);
    } catch (Exception $e) {
        file_put_contents(__DIR__ . '/logs/get_customer_errors.log', date('Y-m-d H:i:s') . ' - Failed to fetch customers: ' . $e->getMessage() . "\n", FILE_APPEND);
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Lỗi hệ thống: ' . $e->getMessage()
        ], 500);
    }
}

function checkin_mkt192_create_customer_api(WP_REST_Request $request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'bookingmkt192_customer_data';

    $data = $request->get_json_params();

    try {
        // Kiểm tra dữ liệu đầu vào
        if (empty($data['customer_phone']) || empty($data['customer_name'])) {
            return new WP_REST_Response(['success' => false, 'message' => 'Số điện thoại và tên khách hàng là bắt buộc.'], 400);
        }

        $phone = sanitize_text_field($data['customer_phone']);
        if (!preg_match('/^[0-9]{9,10}$/', $phone)) {
            return new WP_REST_Response(['success' => false, 'message' => 'Số điện thoại không hợp lệ.'], 400);
        }

        $name = sanitize_text_field($data['customer_name']);
        if (strlen($name) < 2) {
            return new WP_REST_Response(['success' => false, 'message' => 'Tên khách hàng phải có ít nhất 2 ký tự.'], 400);
        }

        $birthday = !empty($data['customer_birthday']) ? sanitize_text_field($data['customer_birthday']) : null;
        if ($birthday) {
            $date = DateTime::createFromFormat('Y-m-d', $birthday);
            if (!$date || $date->format('Y-m-d') !== $birthday || $date > new DateTime()) {
                return new WP_REST_Response(['success' => false, 'message' => 'Ngày sinh không hợp lệ hoặc trong tương lai.'], 400);
            }
        }

        // Kiểm tra khách hàng đã tồn tại
        $existing_customer = $wpdb->get_var($wpdb->prepare(
            "SELECT customer_id FROM $table_name WHERE customer_phone = %s",
            $phone
        ));
        if ($existing_customer) {
            return new WP_REST_Response(['success' => false, 'message' => 'Số điện thoại đã tồn tại.'], 400);
        }

        // Tạo customer_id
        $last_customer = $wpdb->get_var("SELECT customer_id FROM $table_name ORDER BY customer_id DESC LIMIT 1");
        $next_number   = 1;
        if ($last_customer && preg_match('/^VG(\d{4})$/', $last_customer, $matches)) {
            $next_number = (int)$matches[1] + 1;
        }
        $customer_id = sprintf('VG%04d', $next_number);

        // Lấy chi nhánh CHÍNH từ staff profile để gán cho customer mới
        // Chi nhánh chính (branch_id) dùng khi tạo dữ liệu mới
        $branch_id = checkin_mkt192_get_staff_primary_branch_id();

        // Chuẩn bị dữ liệu
        $insert_data = [
            'customer_id'       => $customer_id,
            'customer_phone'    => $phone,
            'customer_name'     => $name,
            'customer_birthday' => $birthday,
            'membership_level'  => null,
            'follower_zalo'     => 0,
            'new_checkin'       => current_time('mysql'),
            'new_code'          => null,
            'status_code'       => null,
            'new_customer'      => sanitize_text_field($data['new_customer']),
            'branch_id'         => $branch_id,
            'created_at'        => current_time('mysql')
        ];

        // Chèn dữ liệu
        $format   = ['%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%d', '%s'];
        $inserted = $wpdb->insert($table_name, $insert_data, $format);

        if ($inserted === false) {
            checkin_mkt192_log_error('customer_create', 'Create customer error', [
                'error'       => $wpdb->last_error,
                'customer_id' => $customer_id
            ]);
            return new WP_REST_Response(['success' => false, 'message' => 'Lỗi khi lưu khách hàng: ' . $wpdb->last_error], 500);
        }

        // Trả về phản hồi đúng định dạng
        return new WP_REST_Response([
            'success' => true,
            'message' => 'Tạo khách hàng thành công',
            'data'    => [
                'customer_id'       => $customer_id,
                'customer_phone'    => $phone,
                'customer_name'     => $name,
                'customer_birthday' => $birthday,
                'new_customer'      => $insert_data['new_customer'],
                'customer_images'   => [] // Ảnh sẽ lưu trong invoice.images
            ]
        ], 201);
    } catch (Exception $e) {
        checkin_mkt192_log_error('customer_create', 'Create customer error', [
            'error' => $e->getMessage(),
            'trace' => $e->getTraceAsString()
        ]);
        return new WP_REST_Response(['success' => false, 'message' => 'Lỗi hệ thống: ' . $e->getMessage()], 500);
    }
}

/**
 * Upload image for invoice
 */
/**
 * 🚀 CHUNK Upload Customer Image API - Fastest method (based on mau.php)
 * Receives multiple files in ONE request → saves to temp → updates DB
 */
function checkin_mkt192_upload_customer_image_api($request) {
    $start_time = microtime(true);
    $log_file   = __DIR__ . '/logs/upload_customer_image.log';

    try {
        // Use request params instead of $_POST for better security
        $customer_id     = sanitize_text_field($request->get_param('customer_id') ?? '');
        $invoice_id      = sanitize_text_field($request->get_param('invoice_id') ?? '');
        $customer_images = sanitize_text_field($request->get_param('customer_images') ?? '');

        if (empty($customer_id)) {
            return new WP_Error('missing_customer_id', 'Missing customer_id', ['status' => 400]);
        }

        // Setup temp directory
        $temp_dir = WP_CONTENT_DIR . '/uploads/checkin-mkt192-wp/temp/';
        $temp_url = WP_CONTENT_URL . '/uploads/checkin-mkt192-wp/temp/';

        if (!is_dir($temp_dir)) {
            wp_mkdir_p($temp_dir);
        }

        // Check for files - support both images[] (multiple) and image (single)
        $files = isset($_FILES['images']) ? $_FILES['images'] : null;
        if (empty($files) && isset($_FILES['image'])) {
            // Single file upload - convert to array format
            $files = [
                'name'     => [$_FILES['image']['name']],
                'tmp_name' => [$_FILES['image']['tmp_name']],
                'error'    => [$_FILES['image']['error']],
                'size'     => [$_FILES['image']['size']]
            ];
        }

        if (empty($files['name']) || !is_array($files['name'])) {
            return new WP_Error('no_files', 'No files uploaded', ['status' => 400]);
        }

        $uploaded_urls      = [];
        $uploaded_files     = [];
        $expected_filenames = array_filter(explode(',', $customer_images));

        // Get random suffix from frontend to ensure unique filenames
        $random_suffix = sanitize_text_field($request->get_param('random') ?? '');
        $unique_id     = $random_suffix ?: uniqid();

        // Update DB immediately (like mau.php) - Using Transaction and Row Locking to prevent race conditions
        $existing_images = [];
        $invoice_locked  = false;

        if (!empty($invoice_id)) {
            global $wpdb;
            $invoice_table = $wpdb->prefix . 'checkin_mkt192_invoices_data';

            $wpdb->query('START TRANSACTION');
            $invoice_locked = true;

            // Select with FOR UPDATE locks the row until transaction ends
            $existing_images_str = $wpdb->get_var($wpdb->prepare(
                "SELECT images FROM $invoice_table WHERE invoice_id = %s FOR UPDATE",
                $invoice_id
            ));

            if ($existing_images_str) {
                if (str_starts_with($existing_images_str, '[')) {
                    $existing_images = json_decode($existing_images_str, true) ?: [];
                } else {
                    $existing_images = array_filter(explode(',', $existing_images_str));
                }
            }
        }

        $base_index = count($existing_images);

        // Process each file with MIME type validation
        $allowed_mimes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];

        foreach ($files['name'] as $key => $name) {
            if ($files['error'][$key] !== UPLOAD_ERR_OK) {
                error_log("File error: $name, code: " . $files['error'][$key]);
                continue;
            }

            // Validate MIME type for security
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mime  = $finfo->file($files['tmp_name'][$key]);
            if (!in_array($mime, $allowed_mimes)) {
                error_log("Invalid MIME type: $mime for file: $name");
                continue;
            }

            // Use sequential index based on current count in database
            // Format: KH123_timestamp_randomSuffix_index.ext (index starts at 1, 2, 3...)
            $file_index = $base_index + $key + 1;
            $filename  = $expected_filenames[$key] ?? $customer_id . '_' . time() . '_' . $unique_id . '_' . $file_index . '.' . pathinfo($name, PATHINFO_EXTENSION);
            $filepath  = $temp_dir . $filename;

            if (move_uploaded_file($files['tmp_name'][$key], $filepath)) {
                $uploaded_files[] = $filename;
                $uploaded_urls[]  = $temp_url . $filename;
            }
        }

        if (empty($uploaded_files)) {
            if ($invoice_locked) {
                $wpdb->query('ROLLBACK');
            }
            return new WP_Error('no_files_uploaded', 'No files were uploaded', ['status' => 400]);
        }

        if (!empty($invoice_id) && $invoice_locked) {
            $new_images      = array_merge($existing_images, $uploaded_urls);
            $new_images      = array_values(array_unique($new_images)); // Filter unique URLs
            $new_images_json = json_encode($new_images, JSON_UNESCAPED_SLASHES);

            $updated = $wpdb->update(
                $invoice_table,
                ['images'     => $new_images_json],
                ['invoice_id' => $invoice_id],
                ['%s'],
                ['%s']
            );

            if ($updated !== false) {
                $wpdb->query('COMMIT');
            } else {
                $wpdb->query('ROLLBACK');
            }
        }

        // Save metadata to JSON (for cronjob to process WebP conversion)
        $checkin_date   = date('Ymd');
        // Sanitize customer_id to prevent path traversal
        $safe_customer_id = preg_replace('/[^a-zA-Z0-9_-]/', '', $customer_id);
        
        // Use a unique name including unique_id to prevent concurrent write race conditions
        $json_file        = $temp_dir . "temp_{$safe_customer_id}_{$unique_id}_{$checkin_date}.json";
        $json_data        = [
            'customer_id' => $customer_id,
            'invoice_id'  => $invoice_id,
            'filenames'   => $uploaded_files,
            'urls'        => $uploaded_urls,
            'created_at'  => current_time('mysql')
        ];

        // Write directly to unique file (no locking or overwrites possible)
        file_put_contents($json_file, json_encode($json_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

        $total_duration = round((microtime(true) - $start_time) * 1000, 1);
        error_log('✅ CHUNK Upload: ' . count($uploaded_files) . " files in {$total_duration}ms");

        return [
            'success' => true,
            'data'    => [
                'url'             => implode(',', $uploaded_urls),
                'customer_images' => implode(',', $uploaded_files),
                'server_ms'       => $total_duration, // thời gian PHP xử lý — client dùng tách "chậm do mạng" vs "chậm do server"
            ]
        ];

    } catch (Exception $e) {
        error_log('❌ Upload error: ' . $e->getMessage());
        return new WP_Error('server_error', $e->getMessage(), ['status' => 500]);
    }
}

// ============================================================
// Legacy compression function - NO LONGER USED
// Compression now handled by cronjob (WebP conversion)
// ============================================================

/**
 * 🚀 CHUNK Upload Feedback Image API - Fastest method (based on mau.php)
 * Receives multiple files in ONE request → saves to temp → updates DB
 */
function checkin_mkt192_upload_feedback_image_api($request) {
    $start_time = microtime(true);

    try {
        // Use request params instead of $_POST for better security
        $customer_id     = sanitize_text_field($request->get_param('customer_id') ?? '');
        $invoice_id      = sanitize_text_field($request->get_param('invoice_id') ?? '');
        $customer_images = sanitize_text_field($request->get_param('customer_images') ?? '');

        if (empty($customer_id)) {
            return new WP_Error('missing_customer_id', 'Missing customer_id', ['status' => 400]);
        }

        // Setup temp directory for feedback
        $temp_dir = WP_CONTENT_DIR . '/uploads/checkin-mkt192-wp/temp-feedback-image/';
        $temp_url = WP_CONTENT_URL . '/uploads/checkin-mkt192-wp/temp-feedback-image/';

        if (!is_dir($temp_dir)) {
            wp_mkdir_p($temp_dir);
        }

        // Check for files - support both images[] (multiple) and image (single)
        $files = isset($_FILES['images']) ? $_FILES['images'] : null;
        if (empty($files) && isset($_FILES['image'])) {
            $files = [
                'name'     => [$_FILES['image']['name']],
                'tmp_name' => [$_FILES['image']['tmp_name']],
                'error'    => [$_FILES['image']['error']],
                'size'     => [$_FILES['image']['size']]
            ];
        }

        if (empty($files['name']) || !is_array($files['name'])) {
            return new WP_Error('no_files', 'No files uploaded', ['status' => 400]);
        }

        $uploaded_urls      = [];
        $uploaded_files     = [];
        $expected_filenames = array_filter(explode(',', $customer_images));

        // Get random suffix from frontend to ensure unique filenames
        $random_suffix = sanitize_text_field($request->get_param('random') ?? '');
        $unique_id     = $random_suffix ?: uniqid();

        // Update image_feedback in DB - Using Transaction and Row Locking to prevent race conditions
        $existing       = [];
        $invoice_locked = false;

        if (!empty($invoice_id)) {
            global $wpdb;
            $invoice_table = $wpdb->prefix . 'checkin_mkt192_invoices_data';

            $wpdb->query('START TRANSACTION');
            $invoice_locked = true;

            // Select with FOR UPDATE locks the row until transaction ends
            $existing_str = $wpdb->get_var($wpdb->prepare(
                "SELECT image_feedback FROM $invoice_table WHERE invoice_id = %s FOR UPDATE",
                $invoice_id
            ));

            if ($existing_str) {
                if (str_starts_with($existing_str, '[')) {
                    $existing = json_decode($existing_str, true) ?: [];
                } else {
                    $existing = array_filter(explode(',', $existing_str));
                }
            }
        }

        $base_index = count($existing);

        // Process each file with MIME type validation
        $allowed_mimes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];

        foreach ($files['name'] as $key => $name) {
            if ($files['error'][$key] !== UPLOAD_ERR_OK) {
                error_log("Feedback file error: $name, code: " . $files['error'][$key]);
                continue;
            }

            // Validate MIME type for security
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mime  = $finfo->file($files['tmp_name'][$key]);
            if (!in_array($mime, $allowed_mimes)) {
                error_log("Invalid MIME type: $mime for feedback file: $name");
                continue;
            }

            // Use sequential index based on current count in database
            // Format: feedback_KH123_timestamp_randomSuffix_index.ext (index starts at 1, 2, 3...)
            $file_index = $base_index + $key + 1;
            $filename  = $expected_filenames[$key] ?? 'feedback_' . $customer_id . '_' . time() . '_' . $unique_id . '_' . $file_index . '.' . pathinfo($name, PATHINFO_EXTENSION);
            $filepath  = $temp_dir . $filename;

            if (move_uploaded_file($files['tmp_name'][$key], $filepath)) {
                $uploaded_files[] = $filename;
                $uploaded_urls[]  = $temp_url . $filename;
            }
        }

        if (empty($uploaded_files)) {
            if ($invoice_locked) {
                $wpdb->query('ROLLBACK');
            }
            return new WP_Error('no_files_uploaded', 'No files were uploaded', ['status' => 400]);
        }

        if (!empty($invoice_id) && $invoice_locked) {
            $new_images = array_merge($existing, $uploaded_urls);
            $new_images = array_values(array_unique($new_images)); // Filter unique URLs
            $new_json   = json_encode($new_images, JSON_UNESCAPED_SLASHES);

            $updated = $wpdb->update(
                $invoice_table,
                ['image_feedback' => $new_json],
                ['invoice_id'     => $invoice_id],
                ['%s'],
                ['%s']
            );

            // Insert to image_feedback table
            $created_data = $wpdb->get_row($wpdb->prepare(
                "SELECT created_user, created_at FROM $invoice_table WHERE invoice_id = %s",
                $invoice_id
            ), ARRAY_A);

            $inserted = true;
            if ($created_data) {
                $image_feedback_table = $wpdb->prefix . 'checkin_mkt192_image_feedback';
                $insert_res = $wpdb->insert(
                    $image_feedback_table,
                    [
                        'staff_name'    => $created_data['created_user'],
                        'image'         => $new_json,
                        'feedback_date' => $created_data['created_at']
                    ],
                    ['%s', '%s', '%s']
                );
                if ($insert_res === false) {
                    $inserted = false;
                }
            }

            if ($updated !== false && $inserted) {
                $wpdb->query('COMMIT');
            } else {
                $wpdb->query('ROLLBACK');
            }
        }

        // Save metadata to JSON
        $checkin_date = date('Ymd');
        // Sanitize customer_id to prevent path traversal
        $safe_customer_id = preg_replace('/[^a-zA-Z0-9_-]/', '', $customer_id);
        
        // Use a unique name including unique_id to prevent concurrent write race conditions
        $json_file        = $temp_dir . "temp_feedback_{$safe_customer_id}_{$unique_id}_{$checkin_date}.json";
        $json_data        = [
            'customer_id' => $customer_id,
            'invoice_id'  => $invoice_id,
            'filenames'   => $uploaded_files,
            'urls'        => $uploaded_urls,
            'is_feedback' => true,
            'created_at'  => current_time('mysql')
        ];

        // Write directly to unique file (no locking or overwrites possible)
        file_put_contents($json_file, json_encode($json_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

        $total_duration = round((microtime(true) - $start_time) * 1000, 1);
        error_log('✅ CHUNK Feedback Upload: ' . count($uploaded_files) . " files in {$total_duration}ms");

        return [
            'success' => true,
            'data'    => [
                'url'             => implode(',', $uploaded_urls),
                'customer_images' => implode(',', $uploaded_files),
                'server_ms'       => $total_duration,
            ]
        ];

    } catch (Exception $e) {
        error_log('❌ Feedback upload error: ' . $e->getMessage());
        return new WP_Error('server_error', $e->getMessage(), ['status' => 500]);
    }
}

function checkin_mkt192_get_customer_member(WP_REST_Request $request) {
    global $wpdb;

    // Get raw body and decode JSON
    $body = $request->get_body();
    $data = json_decode($body, true);

    // Lưu dữ liệu vào log để kiểm tra
    file_put_contents(__DIR__ . '/logs/customer-booking-input.log', date('Y-m-d H:i:s') . ' - Customer Promo Request Body: ' . print_r($body, true) . "\n", FILE_APPEND);
    file_put_contents(__DIR__ . '/logs/customer-booking-input.log', date('Y-m-d H:i:s') . ' - Decoded Data: ' . print_r($data, true) . "\n", FILE_APPEND);

    // Check if customerInput exists and sanitize
    $customer_input = isset($data['customerInput']) ? sanitize_text_field($data['customerInput']) : '';

    if (empty($customer_input)) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Vui lòng nhập số điện thoại hoặc mã khách hàng.',
            'debug'   => ['body' => $body, 'decoded' => $data]
        ], 400);
    }

    // Normalize phone number by removing leading zeros
    $normalized_input = preg_replace('/^(0|84)/', '', $customer_input);

    // Create phone variants for comprehensive search (same as booking API)
    $phone_variants = [$customer_input, $normalized_input];
    if (strlen($normalized_input) === 9) {
        $phone_variants[] = '0' . $normalized_input; // Add version with 0
    }
    // Remove duplicates
    $phone_variants = array_unique($phone_variants);

    try {
        // Fetch customer data (including customer_phone)
        // Build query with multiple phone variants
        $placeholders = implode(' OR customer_phone = ', array_fill(0, count($phone_variants), '%s'));
        $query_params = array_merge($phone_variants, [$customer_input, $normalized_input]);

        $customer_data = $wpdb->get_row($wpdb->prepare("
            SELECT customer_id, customer_phone, new_code, new_checkin, membership_level, customer_name, customer_birthday
            FROM {$wpdb->prefix}bookingmkt192_customer_data
            WHERE customer_phone = $placeholders OR customer_id = %s OR customer_id = %s
        ", $query_params), ARRAY_A);

        if (!$customer_data) {
            return new WP_REST_Response([
                'success' => false,
                'message' => 'Không tìm thấy khách hàng với số điện thoại hoặc mã khách hàng cung cấp.'
            ], 404);
        }

        // Fetch visit history from invoices (last 6 months)
        $visit_history = [];
        try {
            $six_months_ago = date('Y-m-d H:i:s', strtotime('-6 months'));
            $invoices       = $wpdb->get_results($wpdb->prepare(
                "SELECT invoice_id, created_at FROM {$wpdb->prefix}checkin_mkt192_invoices_data
                 WHERE customer_id = %s AND created_at >= %s
                 ORDER BY created_at DESC",
                $customer_data['customer_id'],
                $six_months_ago
            ));

            if ($invoices) {
                foreach ($invoices as $invoice) {
                    $visit_history[] = [
                        'invoice_id'   => $invoice->invoice_id,
                        'code'         => $invoice->invoice_id, // Use invoice_id as code
                        'created_at'   => $invoice->created_at,
                        'date_display' => date('d/m/Y', strtotime($invoice->created_at))
                    ];
                }
            }
        } catch (Exception $e) {
            file_put_contents(__DIR__ . '/logs/customer_promo_errors.log', date('Y-m-d H:i:s') . ' - Failed to fetch visit history: ' . $e->getMessage() . "\n", FILE_APPEND);
            // Fallback: Use new_checkin if invoice query fails
            if (!empty($customer_data['new_checkin'])) {
                $visit_history = [[
                    'invoice_id'   => null,
                    'code'         => null,
                    'created_at'   => $customer_data['new_checkin'],
                    'date_display' => date('d/m/Y', strtotime($customer_data['new_checkin']))
                ]];
            }
        }

        // Ensure we always have at least one visit history entry
        if (empty($visit_history) && !empty($customer_data['new_checkin'])) {
            $visit_history = [[
                'invoice_id'   => null,
                'code'         => null,
                'created_at'   => $customer_data['new_checkin'],
                'date_display' => date('d/m/Y', strtotime($customer_data['new_checkin']))
            ]];
        }

        // Debug log
        file_put_contents(__DIR__ . '/logs/visit_history_debug.log', date('Y-m-d H:i:s') . ' - Customer: ' . $customer_data['customer_id'] . ' - Visit history count: ' . count($visit_history) . ' - Data: ' . json_encode($visit_history) . "\n", FILE_APPEND);

        // Fetch images from latest invoice
        $images = [];
        $avatar = null;
        try {
            // Create phone variants for invoice search (handle 0 prefix)
            $phone           = $customer_data['customer_phone'];
            $without_zero    = ltrim($phone, '0');
            $with_zero       = (strlen($without_zero) === 9) ? '0' . $without_zero : $phone;

            $latest_invoice = $wpdb->get_row($wpdb->prepare(
                "SELECT images FROM {$wpdb->prefix}checkin_mkt192_invoices_data
                 WHERE (customer_id = %s OR customer_phone IN (%s, %s))
                   AND images IS NOT NULL AND images != '' AND images != '[]'
                 ORDER BY created_at DESC LIMIT 1",
                $customer_data['customer_id'],
                $without_zero,
                $with_zero
            ));

            if ($latest_invoice && !empty($latest_invoice->images)) {
                $decoded = json_decode($latest_invoice->images, true);
                if (is_array($decoded) && !empty($decoded)) {
                    $images = $decoded;
                    $avatar = $images[0];
                }
            }
        } catch (Exception $e) {
            file_put_contents(__DIR__ . '/logs/customer_promo_errors.log', date('Y-m-d H:i:s') . ' - Failed to fetch customer images: ' . $e->getMessage() . "\n", FILE_APPEND);
            $images = [];
            $avatar = null;
        }

        // Calculate promo status based on new_checkin
        $promo_status = 'Hết hạn sử dụng';
        $issue_date   = null;
        $expiry_date  = null;
        if (!empty($customer_data['new_checkin'])) {
            $issue_date       = date('d/m/Y', strtotime($customer_data['new_checkin']));
            $new_checkin_time = strtotime($customer_data['new_checkin']);
            $current_time     = time();
            // Đồng bộ logic với JS: so sánh số ngày đã làm tròn
            $days_diff        = floor(($current_time - $new_checkin_time) / (60 * 60 * 24));
            if ($days_diff <= 30) {
                $promo_status = 'Có hiệu lực';
            }
            $expiry_date = date('d/m/Y', strtotime($customer_data['new_checkin'] . ' + 30 days'));
        }

        // Prepare response data
        $response_data = [
            'customerName'    => $customer_data['customer_name'],
            'customerPhone'   => $customer_data['customer_phone'],
            'birthday'        => $customer_data['customer_birthday'] ? date('d/m/Y', strtotime($customer_data['customer_birthday'])) : null,
            'visitHistory'    => $visit_history,
            'promoCode'       => $customer_data['new_code'],
            'membershipLevel' => $customer_data['membership_level'],
            'issueDate'       => $issue_date,
            'expiry'          => $expiry_date,
            'promoStatus'     => $promo_status,
            'avatar'          => $avatar,
            'images'          => $images
        ];

        // Determine promo type and discount based on membership level
        $promo_type = $customer_data['membership_level'] === 'VIP' ? 'VIP' : 'Thành Viên';
        $discount   = $customer_data['membership_level'] === 'VIP' ? '30% Giảm Giá' : '20.000đ';

        $response_data['promoType'] = $promo_type;
        $response_data['discount']  = $discount;

        // Luôn trả về success: true và showDetails: true để hiển thị thông tin thành viên
        // Chỉ thay đổi message tùy theo trạng thái
        $success   = true;
        $message   = '';
        $http_code = 200;

        if ($customer_data['membership_level'] !== 'Thành Viên' && $customer_data['membership_level'] !== 'VIP') {
            $message                    = 'Khách hàng chưa phải là thành viên. Vui lòng đăng ký thành viên để nhận ưu đãi.';
            $response_data['promoCode'] = null;
            $response_data['promoType'] = null;
            $response_data['discount']  = null;
        } elseif ($promo_status !== 'Có hiệu lực') {
            $message = 'Mã khuyến mãi đã hết hạn. Vui lòng ghé shop để nhận mã mới.';
        } else {
            $message = 'Mã khuyến mãi còn hiệu lực. Vui lòng xuất trình khi thanh toán.';
        }

        return new WP_REST_Response(array_merge($response_data, [
            'success'     => $success,
            'showDetails' => true,
            'message'     => $message
        ]), $http_code);
    } catch (Exception $e) {
        file_put_contents(__DIR__ . '/logs/customer_promo_errors.log', date('Y-m-d H:i:s') . ' - Failed to fetch customer promo: ' . $e->getMessage() . "\n", FILE_APPEND);
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Đã xảy ra lỗi server. Vui lòng thử lại sau.'
        ], 500);
    }
}

/**
 * API Đăng ký thành viên (Public - từ Zalo OA)
 */
function checkin_mkt192_customer_registration_api(WP_REST_Request $request) {
    global $wpdb;

    try {
        // Support cả JSON và form-urlencoded data
        $data = $request->get_json_params();
        if (empty($data)) {
            // Fallback: Nếu không có JSON, lấy từ form params (HTML form submit)
            $data = [
                'customer_phone'    => $request->get_param('customer_phone'),
                'customer_name'     => $request->get_param('customer_name'),
                'customer_birthday' => $request->get_param('customer_birthday'),
                'gender'            => $request->get_param('gender'),
                'email'             => $request->get_param('email'),
                'address'           => $request->get_param('address'),
                'id_zalo'           => $request->get_param('id_zalo'),
                'name_zalo'         => $request->get_param('name_zalo'),
                'follower_zalo'     => $request->get_param('follower_zalo'),
            ];

            checkin_mkt192_log('customer_registration', 'Received form-urlencoded data (HTML form submit)', 'INFO', [
                'data' => $data
            ]);
        }

        // Validate required fields
        $customer_phone = sanitize_text_field($data['customer_phone'] ?? '');
        $customer_name  = sanitize_text_field($data['customer_name'] ?? '');

        if (empty($customer_phone) || empty($customer_name)) {
            checkin_mkt192_log_error('customer_registration', 'Missing required fields', [
                'phone_empty'   => empty($customer_phone),
                'name_empty'    => empty($customer_name),
                'received_data' => $data
            ]);
            return new WP_REST_Response([
                'success' => false,
                'message' => 'Vui lòng nhập đầy đủ thông tin bắt buộc.'
            ], 400);
        }

        // Chuẩn hóa số điện thoại: bỏ số 0 đầu nếu có
        $customer_phone_normalized = ltrim($customer_phone, '0');

        // Validate số điện thoại sau khi chuẩn hóa (phải có 9 số)
        if (!preg_match('/^[0-9]{9}$/', $customer_phone_normalized)) {
            checkin_mkt192_log_error('customer_registration', 'Invalid phone format', [
                'phone_original'   => $customer_phone,
                'phone_normalized' => $customer_phone_normalized
            ]);
            return new WP_REST_Response([
                'success' => false,
                'message' => 'Số điện thoại không hợp lệ. Vui lòng nhập số điện thoại 10 chữ số (bắt đầu bằng 0).'
            ], 400);
        }

        // Chuẩn hóa tên khách hàng (UPPERCASE)
        $customer_name = strtoupper(trim($customer_name));

        // Optional fields
        $customer_birthday = sanitize_text_field($data['customer_birthday'] ?? '');
        $gender            = sanitize_text_field($data['gender'] ?? '');
        $email             = sanitize_email($data['email'] ?? '');
        $address           = sanitize_textarea_field($data['address'] ?? '');
        $id_zalo           = sanitize_text_field($data['id_zalo'] ?? '');
        $name_zalo         = sanitize_text_field($data['name_zalo'] ?? '');
        $follower_zalo     = sanitize_text_field($data['follower_zalo'] ?? '');

        // Sanitize name_zalo: Nếu có ký tự lạ (?, %, etc) hoặc rỗng, dùng customer_name
        if (!empty($name_zalo)) {
            // Kiểm tra có ký tự không hợp lệ (?, %, hoặc các ký tự điều khiển)
            if (preg_match('/[?%\x00-\x1F\x7F]/', $name_zalo)) {
                checkin_mkt192_log('customer_registration', 'name_zalo has invalid chars, using customer_name', 'WARNING', [
                    'name_zalo_original' => $name_zalo,
                    'customer_name'      => $customer_name
                ]);
                $name_zalo = $customer_name;
            }
        } else {
            // Nếu name_zalo rỗng, dùng customer_name
            $name_zalo = $customer_name;
        }

        // Log thông tin đăng ký nhận được
        checkin_mkt192_log('customer_registration', 'Registration request received', 'INFO', [
            'phone'         => $customer_phone,
            'name'          => $customer_name,
            'id_zalo'       => $id_zalo ?: 'null',
            'name_zalo'     => $name_zalo ?: 'null',
            'follower_zalo' => $follower_zalo ?: 'null'
        ]);

        // Kiểm tra có sử dụng Zalo OA không
        $use_zalo_oa_raw = get_option('checkin_use_zalo_oa', 'no');
        // Normalize: Support cả 'yes', '1', 1, true
        $use_zalo_oa = in_array($use_zalo_oa_raw, ['yes', '1', 1, true, 'true'], true) ? 'yes' : 'no';

        // Kiểm tra xem khách hàng đã tồn tại chưa (theo số điện thoại - dò cả có 0 và không có 0)
        $existing_customer = $wpdb->get_row($wpdb->prepare(
            "SELECT customer_id, customer_name, customer_phone, membership_level, id_zalo, name_zalo, follower_zalo
             FROM {$wpdb->prefix}bookingmkt192_customer_data
             WHERE customer_phone = %s OR customer_phone = %s",
            $customer_phone_normalized,
            $customer_phone
        ));

        if ($existing_customer) {
            // ===== TRƯỜNG HỢP 1: Khách hàng đã tồn tại =====
            checkin_mkt192_log('customer_registration', 'Existing customer found - updating', 'INFO', [
                'customer_id' => $existing_customer->customer_id,
                'old_name'    => $existing_customer->customer_name,
                'new_name'    => $customer_name
            ]);

            // Chuẩn hóa số điện thoại: LUÔN lưu dạng KHÔNG CÓ 0 đầu (9 số) vào DB
            // Đảm bảo nhất quán với DB hiện tại
            $phone_to_save = $customer_phone_normalized; // Lưu số KHÔNG có 0 đầu (9 số)

            $update_data = [
                'customer_phone'    => $phone_to_save, // Lưu số KHÔNG có 0 đầu (9 số)
                'customer_name'     => $customer_name,
                'updated_at'        => current_time('mysql', false),  // Luôn update lúc sửa
            ];

            // Cập nhật các trường optional nếu có giá trị
            if (!empty($customer_birthday)) {
                $update_data['customer_birthday'] = $customer_birthday;
            }
            if (!empty($gender)) {
                $update_data['customer_gender'] = $gender;
            }
            if (!empty($email)) {
                $update_data['customer_email'] = $email;
            }
            if (!empty($address)) {
                $update_data['customer_address'] = $address;
            }

            // Cập nhật thông tin Zalo nếu đang sử dụng Zalo OA
            if ($use_zalo_oa === 'yes') {
                // Cập nhật id_zalo: LUÔN update nếu có giá trị mới
                if (!empty($id_zalo)) {
                    $update_data['id_zalo'] = $id_zalo;
                }

                // Cập nhật name_zalo: LUÔN update nếu có giá trị mới
                if (!empty($name_zalo)) {
                    $update_data['name_zalo'] = $name_zalo;
                }

                // Cập nhật follower_zalo: LUÔN update nếu có giá trị
                if (!empty($follower_zalo)) {
                    $is_follower                  = in_array(strtolower($follower_zalo), ['true', '1', 'yes']);
                    $update_data['follower_zalo'] = $is_follower ? 'Có' : 'Không';
                }
            }

            // Nếu chưa phải thành viên, nâng cấp lên Thành Viên
            if ($existing_customer->membership_level !== 'Thành Viên' && $existing_customer->membership_level !== 'VIP') {
                $update_data['membership_level'] = 'Thành Viên';
                // Khi nâng cấp lên Thành Viên, set date_new_member nếu chưa có
                if (empty($existing_customer->date_new_member)) {
                    $update_data['date_new_member'] = current_time('mysql', false);
                }
                // Nếu chưa có created_at (record cũ chưa được set), set nó
                if (empty($existing_customer->created_at)) {
                    $update_data['created_at'] = current_time('mysql', false);
                }
            }

            // Tạo mảng format cho wpdb->update
            $format = array_fill(0, count($update_data), '%s');

            $update_result = $wpdb->update(
                $wpdb->prefix . 'bookingmkt192_customer_data',
                $update_data,
                ['customer_id' => $existing_customer->customer_id],
                $format,
                ['%s']
            );

            // Log lỗi nếu update failed
            if ($update_result === false) {
                checkin_mkt192_log_error('customer_update', 'Customer update failed', [
                    'error'       => $wpdb->last_error,
                    'customer_id' => $existing_customer->customer_id
                ]);
            }

            // ===== AUTO-UPDATE BOOKINGS & INVOICES KHI TÊN THAY ĐỔI =====
            $booking_updated = 0;
            $invoice_updated = 0;
            $old_name        = $existing_customer->customer_name;
            $old_phone       = $existing_customer->customer_phone;

            // Nếu tên hoặc phone thay đổi → cập nhật bookings
            if ($customer_name !== $old_name || $phone_to_save !== $old_phone) {
                // Tạo phone variants để tìm tất cả bookings
                $without_zero = ltrim($old_phone, '0');
                $with_zero    = (strlen($without_zero) === 9) ? '0' . $without_zero : $old_phone;

                // Update bookings by name OR phone (cả 2 variants)
                $booking_result = $wpdb->query($wpdb->prepare(
                    "UPDATE {$wpdb->prefix}bookingmkt192_booking_data
                     SET customer_name = %s, customer_phone = %s
                     WHERE customer_name = %s OR customer_phone IN (%s, %s)",
                    $customer_name,
                    $phone_to_save,
                    $old_name,
                    $without_zero,
                    $with_zero
                ));

                if ($booking_result !== false) {
                    $booking_updated = $booking_result;
                }

                // Update invoices
                $invoice_result = $wpdb->query($wpdb->prepare(
                    "UPDATE {$wpdb->prefix}checkin_mkt192_invoices_data
                     SET customer_name = %s, customer_phone = %s
                     WHERE customer_id = %s",
                    $customer_name,
                    $phone_to_save,
                    $existing_customer->customer_id
                ));

                if ($invoice_result !== false) {
                    $invoice_updated = $invoice_result;
                }
            }

            // Cập nhật thông tin user trên Zalo OA + Gửi thông báo
            if ($use_zalo_oa === 'yes' && (!empty($id_zalo) || !empty($existing_customer->id_zalo))) {
                $zalo_user_id = $id_zalo ?: $existing_customer->id_zalo;

                // 1. Cập nhật shared_info trên Zalo (name, phone, address, dob)
                checkin_mkt192_update_zalo_user_details(
                    $zalo_user_id,
                    $existing_customer->customer_id,
                    $customer_name,
                    $phone_to_save,
                    $update_data['membership_level'] ?? $existing_customer->membership_level
                );

                // 2. Cập nhật custom_info trên Zalo (display_name, zcb_*, process_tag, etc.)
                checkin_mkt192_update_zalo_custom_info(
                    $zalo_user_id,
                    $existing_customer->customer_id,
                    $customer_name,
                    $phone_to_save,
                    $update_data['customer_birthday'] ?? $existing_customer->customer_birthday,
                    $update_data['customer_email']    ?? '',
                    $update_data['customer_address']  ?? '',
                    $update_data['membership_level']  ?? $existing_customer->membership_level,
                    $update_data['name_zalo']         ?? $existing_customer->name_zalo
                );

                // 3. Gửi thông báo chúc mừng
                checkin_mkt192_send_zalo_registration_notification(
                    $zalo_user_id,
                    $customer_name,
                    $update_data['membership_level'] ?? $existing_customer->membership_level
                );
            }

            // Lấy lại thông tin customer mới nhất từ DB để đảm bảo đầy đủ
            $updated_customer = $wpdb->get_row($wpdb->prepare(
                "SELECT customer_id, customer_name, customer_phone, membership_level, id_zalo, name_zalo, follower_zalo
                 FROM {$wpdb->prefix}bookingmkt192_customer_data
                 WHERE customer_id = %s",
                $existing_customer->customer_id
            ));

            // Chuẩn bị response data
            $response_data = [
                'customer_id'      => $updated_customer->customer_id,
                'customer_name'    => $updated_customer->customer_name,
                'customer_phone'   => $updated_customer->customer_phone,
                'membership_level' => $updated_customer->membership_level,
            ];

            // Chỉ thêm các trường Zalo nếu brand sử dụng Zalo OA
            if ($use_zalo_oa === 'yes') {
                $response_data['id_zalo']       = $updated_customer->id_zalo ?: null;
                $response_data['name_zalo']     = $updated_customer->name_zalo ?: null;
                $response_data['follower_zalo'] = $updated_customer->follower_zalo ?: null;
            }

            return new WP_REST_Response([
                'success'  => true,
                'message'  => 'Đăng ký thành viên thành công!',
                'customer' => $response_data,
            ], 200);
        }

        // ===== TRƯỜNG HỢP 2: Khách hàng mới =====
        checkin_mkt192_log('customer_registration', 'New customer - creating new record', 'INFO', [
            'phone'     => $customer_phone,
            'name'      => $customer_name,
            'id_zalo'   => $id_zalo ?: 'null',
            'name_zalo' => $name_zalo ?: 'null'
        ]);

        // Tạo customer_id tự động theo logic tương tự modal thêm khách hàng
        // Format: KH + số thứ tự 4 chữ số (dựa vào khách mới nhất trong DB)
        $last_customer = $wpdb->get_var(
            "SELECT customer_id FROM {$wpdb->prefix}bookingmkt192_customer_data
             WHERE customer_id LIKE 'KH%'
             ORDER BY customer_id DESC LIMIT 1"
        );

        if ($last_customer) {
            // Lấy 4 chữ số cuối và tăng lên 1
            $last_number = (int) substr($last_customer, 2); // Bỏ 2 ký tự "KH"
            $new_number  = $last_number + 1;
        } else {
            // Nếu chưa có khách nào, bắt đầu từ 1
            $new_number = 1;
        }
        $customer_id = 'KH' . str_pad($new_number, 4, '0', STR_PAD_LEFT);

        // Chuẩn hóa số điện thoại: LUÔN lưu dạng KHÔNG CÓ 0 đầu (9 số) vào DB
        // Đảm bảo nhất quán với DB hiện tại
        $phone_to_save = $customer_phone_normalized; // Lưu số KHÔNG có 0 đầu (9 số)

        // Chuẩn bị dữ liệu insert
        $insert_data = [
            'customer_id'       => $customer_id,
            'customer_phone'    => $phone_to_save, // Lưu số KHÔNG có 0 đầu (9 số)
            'customer_name'     => $customer_name,
            'customer_birthday' => $customer_birthday ?: null,
            'customer_gender'   => $gender ?: null,
            'customer_email'    => $email ?: null,
            'customer_address'  => $address ?: null,
            'membership_level'  => 'Thành Viên',
            'new_customer'      => 'true', // Đánh dấu khách mới
            'created_at'        => current_time('mysql', false),  // Ngày tạo record
            'date_new_member'   => current_time('mysql', false),  // Ngày trở thành thành viên
        ];

        // Chỉ thêm các trường liên quan Zalo nếu brand sử dụng Zalo OA
        if ($use_zalo_oa === 'yes') {
            $insert_data['id_zalo']   = $id_zalo ?: null;
            $insert_data['name_zalo'] = $name_zalo ?: null;

            // Xử lý follower_zalo: Zalo gửi "true"/"false" hoặc "1"/"0"
            if (!empty($follower_zalo)) {
                $is_follower                  = in_array(strtolower($follower_zalo), ['true', '1', 'yes']);
                $insert_data['follower_zalo'] = $is_follower ? 'Có' : 'Không';
            } else {
                $insert_data['follower_zalo'] = 'Có'; // Default nếu không có thông tin
            }
        }

        // Insert new customer
        $insert_result = $wpdb->insert(
            $wpdb->prefix . 'bookingmkt192_customer_data',
            $insert_data,
            array_fill(0, count($insert_data), '%s')
        );

        if ($insert_result === false) {
            checkin_mkt192_log_error('customer_registration', 'Customer insert failed', [
                'error'         => $wpdb->last_error,
                'customer_name' => $customer_name,
                'phone'         => $phone_to_save,
                'customer_id'   => $customer_id
            ]);
            return new WP_REST_Response([
                'success' => false,
                'message' => 'Không thể tạo tài khoản. Vui lòng thử lại.'
            ], 500);
        }

        // Log thành công
        checkin_mkt192_log('customer_registration', 'New customer created successfully', 'INFO', [
            'customer_id'      => $customer_id,
            'customer_name'    => $customer_name,
            'phone'            => $phone_to_save,
            'membership_level' => 'Thành Viên',
            'id_zalo'          => $id_zalo ?: 'null'
        ]);

        // Cập nhật thông tin Zalo OA + Gửi thông báo (chỉ khi có sử dụng Zalo OA)
        if ($use_zalo_oa === 'yes' && !empty($id_zalo)) {
            // 1. Cập nhật shared_info trên Zalo
            checkin_mkt192_update_zalo_user_details(
                $id_zalo,
                $customer_id,
                $customer_name,
                $phone_to_save,
                'Thành Viên'
            );

            // 2. Cập nhật custom_info trên Zalo
            checkin_mkt192_update_zalo_custom_info(
                $id_zalo,
                $customer_id,
                $customer_name,
                $phone_to_save,
                $customer_birthday ?: '',
                $email ?: '',
                $address ?: '',
                'Thành Viên',
                $name_zalo ?: $customer_name
            );

            // 3. Gửi thông báo chúc mừng
            checkin_mkt192_send_zalo_registration_notification(
                $id_zalo,
                $customer_name,
                'Thành Viên'
            );
        }

        return new WP_REST_Response([
            'success'  => true,
            'message'  => 'Đăng ký thành viên thành công!',
            'customer' => [
                'customer_id'      => $customer_id,
                'customer_name'    => $customer_name,
                'customer_phone'   => $phone_to_save,
                'membership_level' => 'Thành Viên',
                'new_customer'     => 'true',
            ],
        ], 201);

    } catch (Exception $e) {
        checkin_mkt192_log_error('customer_registration', 'Customer registration error', [
            'error' => $e->getMessage(),
            'trace' => $e->getTraceAsString()
        ]);
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Đã xảy ra lỗi. Vui lòng thử lại sau.'
        ], 500);
    }
}

/**
 * Helper function: Cập nhật thông tin user trên Zalo OA
 * API: https://developers.zalo.me/docs/official-account/quan-ly/quan-ly-thong-tin-nguoi-dung/cap-nhat-chi-tiet-nguoi-dung
 */
function checkin_mkt192_update_zalo_user_details($user_id_zalo, $customer_id, $customer_name, $customer_phone, $membership_level) {
    // Lấy access token từ database
    global $wpdb;
    $zalo_config = $wpdb->get_row(
        "SELECT access_token FROM {$wpdb->prefix}checkin_mkt192_zalo_config WHERE id = 1"
    );

    if (!$zalo_config || empty($zalo_config->access_token)) {
        checkin_mkt192_log_error('zalo_update_user', 'Zalo access token not found when updating user details', [
            'customer_id' => $customer_id
        ]);
        return false;
    }

    $access_token = $zalo_config->access_token;

    // Lấy thông tin customer để gửi Zalo
    $customer_data = $wpdb->get_row($wpdb->prepare(
        "SELECT customer_address, name_zalo, customer_birthday
         FROM {$wpdb->prefix}bookingmkt192_customer_data
         WHERE customer_id = %s",
        $customer_id
    ), OBJECT);

    // Gọi Zalo API để cập nhật user detail
    // Endpoint: POST https://openapi.zalo.me/v3.0/oa/user/update
    $api_url = 'https://openapi.zalo.me/v3.0/oa/user/update';

    // Format phone cho Zalo API: cần +84 + 9 số (không có 0 đầu)
    // Ví dụ: 09876543210 -> 84987654321 hoặc +84987654321
    $phone_for_zalo = $customer_phone; // Giả sử đã là 9 số không có 0 đầu
    if (strlen($phone_for_zalo) === 9 && preg_match('/^[0-9]{9}$/', $phone_for_zalo)) {
        // Nếu là 9 số, thêm +84 prefix
        $phone_for_zalo = '+84' . $phone_for_zalo;
    } elseif (strlen($phone_for_zalo) === 10 && preg_match('/^0[0-9]{9}$/', $phone_for_zalo)) {
        // Nếu là 10 số với 0 đầu, bỏ 0 và thêm +84
        $phone_for_zalo = '+84' . ltrim($phone_for_zalo, '0');
    } elseif (!preg_match('/^\+84|^84/', $phone_for_zalo)) {
        // Nếu chưa có +84 hoặc 84 prefix, thêm +84
        $phone_for_zalo = '+84' . ltrim($phone_for_zalo, '0');
    }
    // Validation cuối cùng
    if (!preg_match('/^\+84[0-9]{9}$/', $phone_for_zalo)) {
        checkin_mkt192_log_error('zalo_update_user', 'Invalid phone format for Zalo API after processing', [
            'original_phone'  => $customer_phone,
            'formatted_phone' => $phone_for_zalo,
            'customer_id'     => $customer_id
        ]);
        return false;
    }

    // Tạo shared_info object theo format của Zalo
    $shared_info = [
        'name'        => $customer_data->name_zalo ?: $customer_name,  // Ưu tiên name_zalo
        'phone'       => $phone_for_zalo,
        'address'     => $customer_data->customer_address ?: 'TP. Hồ Chí Minh',
        'city_id'     => 79,   // 79. TP. Hồ Chí Minh (hardcode)
        'district_id' => 761   // 761. Quận 12 (hardcode)
    ];

    // Thêm user_dob nếu có birthday (format: dd/mm/yyyy)
    if (!empty($customer_data->customer_birthday)) {
        $birthday                = date('d/m/Y', strtotime($customer_data->customer_birthday));
        $shared_info['user_dob'] = $birthday;
    }

    // Cấu trúc đúng theo Zalo API: user_external_id và user_alias cùng cấp với user_id
    $params = [
        'user_id'          => (string) $user_id_zalo,
        'shared_info'      => $shared_info,
        'user_alias'       => $customer_name,
        'user_external_id' => $customer_id
    ];

    $response = wp_remote_post($api_url, [
        'headers' => [
            'Content-Type' => 'application/json',
            'access_token' => $access_token,
        ],
        'body'    => json_encode($params),
        'timeout' => 30,
    ]);

    if (is_wp_error($response)) {
        checkin_mkt192_log_error('zalo_update_user', 'Zalo update user details error', [
            'error'       => $response->get_error_message(),
            'customer_id' => $customer_id
        ]);
        return false;
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    if (isset($data['error']) && $data['error'] !== 0) {
        checkin_mkt192_log_error('zalo_update_user', 'Zalo API update user failed', [
            'response'        => $data,
            'customer_id'     => $customer_id,
            'formatted_phone' => $phone_for_zalo
        ]);
        return false;
    }

    // Log thành công
    checkin_mkt192_log('zalo_update_user', 'Zalo user details updated successfully', 'INFO', [
        'customer_id'     => $customer_id,
        'user_id_zalo'    => $user_id_zalo,
        'formatted_phone' => $phone_for_zalo,
        'request_payload' => $params,
        'response'        => $data
    ]);

    return true;
}

/**
 * Helper function: Cập nhật custom info của user trên Zalo OA
 * API: https://developers.zalo.me/docs/official-account/quan-ly/quan-ly-thong-tin-nguoi-dung/cap-nhat-thong-tin-tuy-chinh
 */
function checkin_mkt192_update_zalo_custom_info($user_id_zalo, $customer_id, $customer_name, $customer_phone, $customer_birthday, $customer_email, $customer_address, $membership_level, $name_zalo) {
    // Lấy access token
    global $wpdb;
    $zalo_config = $wpdb->get_row(
        "SELECT access_token FROM {$wpdb->prefix}checkin_mkt192_zalo_config WHERE id = 1"
    );

    if (!$zalo_config || empty($zalo_config->access_token)) {
        checkin_mkt192_log_error('zalo_update_custom', 'Zalo access token not found when updating custom info', [
            'customer_id' => $customer_id
        ]);
        return false;
    }

    $access_token = $zalo_config->access_token;

    // Gọi API: POST https://openapi.zalo.me/v3.0/oa/user/update/custominfo
    $api_url = 'https://openapi.zalo.me/v3.0/oa/user/update/custominfo';

    // Format phone cho Zalo API: cần +84 + 9 số (không có 0 đầu)
    // Ví dụ: 09876543210 -> 84987654321 hoặc +84987654321
    $phone_for_zalo = $customer_phone; // Giả sử đã là 9 số không có 0 đầu
    if (strlen($phone_for_zalo) === 9 && preg_match('/^[0-9]{9}$/', $phone_for_zalo)) {
        // Nếu là 9 số, thêm +84 prefix
        $phone_for_zalo = '+84' . $phone_for_zalo;
    } elseif (strlen($phone_for_zalo) === 10 && preg_match('/^0[0-9]{9}$/', $phone_for_zalo)) {
        // Nếu là 10 số với 0 đầu, bỏ 0 và thêm +84
        $phone_for_zalo = '+84' . ltrim($phone_for_zalo, '0');
    } elseif (!preg_match('/^\+84|^84/', $phone_for_zalo)) {
        // Nếu chưa có +84 hoặc 84 prefix, thêm +84
        $phone_for_zalo = '+84' . ltrim($phone_for_zalo, '0');
    }
    // Validation cuối cùng
    if (!preg_match('/^\+84[0-9]{9}$/', $phone_for_zalo)) {
        checkin_mkt192_log_error('zalo_update_user', 'Invalid phone format for Zalo API after processing', [
            'original_phone'  => $customer_phone,
            'formatted_phone' => $phone_for_zalo,
            'customer_id'     => $customer_id
        ]);
        return false;
    }

    // Chuẩn bị custom_info theo mapping của bạn
    $custom_info = [
        'zcb_name'         => $customer_name,                // Tên khách hàng
        'zcb_phone'        => $phone_for_zalo,               // Số điện thoại
        'zcb_email'        => $customer_email ?: 'khongcungcap@gmail.com',         // Email
        'zcb_address'      => $customer_address ?: '',       // Địa chỉ
        'zcb_birthday'     => $customer_birthday ? date('d/m/Y', strtotime($customer_birthday)) : '', // Ngày sinh dd/mm/yyyy
    ];

    $params = [
        'user_id'     => $user_id_zalo,
        'custom_info' => $custom_info
    ];

    $response = wp_remote_post($api_url, [
        'headers' => [
            'Content-Type' => 'application/json',
            'access_token' => $access_token,
        ],
        'body'    => json_encode($params),
        'timeout' => 30,
    ]);

    if (is_wp_error($response)) {
        checkin_mkt192_log_error('zalo_update_custom', 'Zalo update custom info error', [
            'error'       => $response->get_error_message(),
            'customer_id' => $customer_id
        ]);
        return false;
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    if (isset($data['error']) && $data['error'] !== 0) {
        checkin_mkt192_log_error('zalo_update_custom', 'Zalo API update custom info failed', [
            'response'    => $data,
            'customer_id' => $customer_id
        ]);
        return false;
    }

    // Log thành công
    checkin_mkt192_log('zalo_update_custom', 'Zalo custom info updated successfully', 'INFO', [
        'customer_id'  => $customer_id,
        'user_id_zalo' => $user_id_zalo,
        'response'     => $data
    ]);

    return true;
}

/**
 * Helper function: Gắn tag cho follower trên Zalo OA
 * API: https://developers.zalo.me/docs/official-account/quan-ly/quan-ly-nhan/gan-nhan-cho-nguoi-quan-tam
 */
function checkin_mkt192_tag_zalo_follower($user_id_zalo, $membership_level) {
    // Lấy access token
    global $wpdb;
    $zalo_config = $wpdb->get_row(
        "SELECT access_token FROM {$wpdb->prefix}checkin_mkt192_zalo_config WHERE id = 1"
    );

    if (!$zalo_config || empty($zalo_config->access_token)) {
        checkin_mkt192_log_error('zalo_tag', 'Zalo access token not found for tagging', [
            'user_id_zalo' => $user_id_zalo
        ]);
        return false;
    }

    $access_token = $zalo_config->access_token;

    // Gọi API: POST https://openapi.zalo.me/v2.0/oa/tag/tagfollower
    $api_url = 'https://openapi.zalo.me/v2.0/oa/tag/tagfollower';

    // Map membership_level sang tag name trên Zalo OA
    $tag_map = [
        'Thành Viên' => 'Member',
        'VIP'        => 'VIP'
    ];
    $tag_name = $tag_map[$membership_level] ?? 'Member';

    $params = [
        'user_id'  => (string) $user_id_zalo,
        'tag_name' => $tag_name  // "Member" hoặc "VIP"
    ];

    $response = wp_remote_post($api_url, [
        'headers' => [
            'Content-Type' => 'application/json',
            'access_token' => $access_token,
        ],
        'body'    => json_encode($params),
        'timeout' => 30,
    ]);

    if (is_wp_error($response)) {
        checkin_mkt192_log_error('zalo_tag', 'Zalo tag follower error', [
            'error'        => $response->get_error_message(),
            'user_id_zalo' => $user_id_zalo
        ]);
        return false;
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    if (isset($data['error']) && $data['error'] !== 0) {
        checkin_mkt192_log_error('zalo_tag', 'Zalo API tag follower failed', [
            'response'     => $data,
            'user_id_zalo' => $user_id_zalo
        ]);
        return false;
    }

    return true;
}

/**
 * Helper function: Gửi thông báo đăng ký thành viên qua Zalo OA
 */
function checkin_mkt192_send_zalo_registration_notification($user_id_zalo, $customer_name, $membership_level) {
    // Lấy access token từ database
    global $wpdb;
    $zalo_config = $wpdb->get_row(
        "SELECT access_token FROM {$wpdb->prefix}checkin_mkt192_zalo_config WHERE id = 1"
    );

    if (!$zalo_config || empty($zalo_config->access_token)) {
        checkin_mkt192_log_error('zalo_send_message', 'Zalo access token not found when sending registration notification', [
            'user_id_zalo' => $user_id_zalo
        ]);
        return false;
    }

    $access_token = $zalo_config->access_token;

    // Tạo message chúc mừng đăng ký thành công
    $promo_value = ($membership_level === 'VIP') ? 'giảm 30%/tổng bill khi sử dụng dịch vụ vào lần kế tiếp' : 'Mã khuyến mãi thành viên khi sử dụng dịch vụ vào lần kế tiếp';

    $message = "🎉 Chúc mừng {$customer_name}!\n\n" .
               "Bạn đã đăng ký thành viên thành công tại Van Group Barbershop.\n\n" .
               "✨ Cấp độ: {$membership_level}\n" .
               "🎁 Ưu đãi: {$promo_value}\n\n" .
               "Cảm ơn bạn đã tin tưởng và sử dụng dịch vụ! 💈\n" .
               "──────────────\n" .
               "🎟️ MÃ KHUYẾN MÃI THÀNH VIÊN:\n\n" .
               "ℹ️ Thông tin:\n" .
               "- Mã sẽ luôn được cấp mới và gửi kèm theo PHIẾU ĐÁNH GIÁ DỊCH VỤ hoặc tại nút \"MÃ KM\" bên dưới.\n" .
               "- Giá trị: Giảm giá 20k trên tổng hóa đơn.\n\n" .
               "⚠️ Lưu ý:\n" .
               "- Mỗi mã chỉ có giá trị sử dụng 1 lần.\n" .
               "- Không áp dụng vào T7 & CN hoặc các ngày Lễ, Tết.\n" .
               "- Không áp dụng đồng thời các CTKM khác.\n" .
               "- Chương trình có thể tạm ngưng khi có thông báo chính thức.\n" .
               '- Hạn sử dụng: 30 ngày (kể từ ngày nhận mã).';

    // Gọi Zalo API gửi text message
    $api_url = 'https://openapi.zalo.me/v3.0/oa/message/cs';
    $params  = [
        'recipient' => [
            'user_id' => $user_id_zalo
        ],
        'message' => [
            'text' => $message
        ]
    ];

    $response = wp_remote_post($api_url, [
        'headers' => [
            'Content-Type' => 'application/json',
            'access_token' => $access_token,
        ],
        'body'    => json_encode($params),
        'timeout' => 30,
    ]);

    if (is_wp_error($response)) {
        checkin_mkt192_log_error('zalo_send_message', 'Zalo send message error', [
            'error'        => $response->get_error_message(),
            'user_id_zalo' => $user_id_zalo
        ]);
        return false;
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    if (isset($data['error']) && $data['error'] !== 0) {
        checkin_mkt192_log_error('zalo_send_message', 'Zalo API send message failed', [
            'response'     => $data,
            'user_id_zalo' => $user_id_zalo
        ]);
        return false;
    }

    // Sau khi gửi thông báo thành công, gắn tag cho user
    checkin_mkt192_tag_zalo_follower($user_id_zalo, $membership_level);

    return true;
}

/**
 * Public API: Lấy chi tiết hóa đơn theo mã (invoice_id / invoice_code / id)
 */
function checkin_mkt192_get_invoice_detail(WP_REST_Request $request) {
    global $wpdb;

    $code       = sanitize_text_field($request->get_param('code'));
    $created_at = sanitize_text_field($request->get_param('created_at'));

    if (empty($code) && empty($created_at)) {
        return new WP_REST_Response(['success' => false, 'message' => 'Thiếu tham số code hoặc created_at'], 400);
    }

    $invoice_table = $wpdb->prefix . 'checkin_mkt192_invoices_data';

    try {
        if (!empty($code)) {
            // Tìm theo mã hóa đơn (invoice_id)
            $invoice = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM $invoice_table WHERE invoice_id = %s LIMIT 1",
                $code
            ), ARRAY_A);
        } else {
            // Tìm theo ngày tạo - lấy hóa đơn gần nhất trong ngày đó
            $invoice = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM $invoice_table WHERE DATE(created_at) = %s ORDER BY created_at DESC LIMIT 1",
                $created_at
            ), ARRAY_A);
        }

        if (!$invoice) {
            return new WP_REST_Response(['success' => false, 'message' => 'Không tìm thấy hóa đơn'], 404);
        }

        // Get invoice details from detail table
        $details_table = $wpdb->prefix . 'checkin_mkt192_invoices_data_detail';
        $services      = $wpdb->get_results($wpdb->prepare(
            "SELECT service_name, price, staff_name, quantity, total, type, service_type
             FROM $details_table
             WHERE invoice_id = %s",
            $invoice['invoice_id']
        ), ARRAY_A);

        // Normalize fields and decode JSON columns
        $images = [];
        if (!empty($invoice['images'])) {
            $decoded                        = json_decode($invoice['images'], true);
            if (is_array($decoded)) $images = $decoded;
        }

        $response = [
            'invoice_id'   => $invoice['invoice_id'] ?? null,
            'code'         => $invoice['invoice_id'] ?? null, // Use invoice_id as code
            'created_at'   => $invoice['created_at'] ?? null,
            'images'       => $images,
            'services'     => $services,
            'service_name' => $invoice['service_name'] ?? null,
            'staff_name'   => $invoice['staff_name']   ?? null,
            'cashier_name' => $invoice['cashier']      ?? null,
            'subtotal'     => $invoice['subtotal']     ?? null,
            'discount'     => $invoice['discount']     ?? null,
            'tips'         => $invoice['tips']         ?? null,
            'total'        => $invoice['total']        ?? null,
        ];

        return new WP_REST_Response(['success' => true, 'data' => $response], 200);
    } catch (Exception $e) {
        file_put_contents(__DIR__ . '/logs/invoice_detail_errors.log', date('Y-m-d H:i:s') . ' - ' . $e->getMessage() . "\n", FILE_APPEND);
        return new WP_REST_Response(['success' => false, 'message' => 'Lỗi server'], 500);
    }
}