<?php

add_action('rest_api_init', function () {
    // Endpoint để lấy cài đặt phạt
    register_rest_route('vg/v1', '/penalty-settings', [
        'methods'             => 'GET',
        'callback'            => 'checkin_mkt192_get_penalty_settings_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'penalty.read'])
    ]);
    // Endpoint để cập nhật cài đặt phạt
    register_rest_route('vg/v1', '/penalty-settings', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_update_penalty_settings_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'penalty.update'])
    ]);
});

function checkin_mkt192_get_penalty_settings_api(WP_REST_Request $request) {
    global $wpdb;

    try {
        $settings = $wpdb->get_row("SELECT * FROM {$wpdb->prefix}checkin_mkt192_penalty_settings WHERE id = 1", ARRAY_A);

        if (!$settings) {
            $settings = [
                'id'                    => 1,
                'penalty_enabled'       => 0,
                'fine_amount'           => 0,
                'fine_by_time'          => 0,
                'fine_levels'           => '[]',
                'report_enabled'        => 0,
                'late_count_for_report' => 1,
                'report_penalty_type'   => 'fixed',
                'report_penalty_value'  => 0
            ];
        }

        return new WP_REST_Response(['success' => true, 'data' => $settings], 200);
    } catch (Exception $e) {
        file_put_contents(
            __DIR__ . '/logs/penalty_errors.log',
            date('Y-m-d H:i:s') . ' - Failed to fetch penalty settings: ' . $e->getMessage() . "\n",
            FILE_APPEND
        );
        return new WP_Error('fetch_failed', 'Lỗi khi lấy cài đặt phạt: ' . $e->getMessage(), ['status' => 500]);
    }
}

function checkin_mkt192_update_penalty_settings_api(WP_REST_Request $request) {
    global $wpdb;
    $data = $request->get_json_params();

    $penalty_enabled       = isset($data['penalty_enabled']) ? intval($data['penalty_enabled']) : 0;
    $fine_amount           = isset($data['fine_amount']) ? floatval($data['fine_amount']) : 0;
    $fine_by_time          = isset($data['fine_by_time']) ? intval($data['fine_by_time']) : 0;
    $fine_levels           = isset($data['fine_levels']) ? $data['fine_levels'] : '[]';
    $report_enabled        = isset($data['report_enabled']) ? intval($data['report_enabled']) : 0;
    $late_count_for_report = isset($data['late_count_for_report']) ? intval($data['late_count_for_report']) : 1;
    $report_penalty_type   = isset($data['report_penalty_type']) ? sanitize_text_field($data['report_penalty_type']) : 'fixed';
    $report_penalty_value  = isset($data['report_penalty_value']) ? floatval($data['report_penalty_value']) : 0;

    // Kiểm tra dữ liệu đầu vào
    if ($fine_amount < 0) {
        return new WP_Error('invalid_fine_amount', 'Số tiền phạt không được âm', ['status' => 400]);
    }
    if ($late_count_for_report < 1) {
        return new WP_Error('invalid_late_count', 'Số lần đi muộn phải lớn hơn 0', ['status' => 400]);
    }
    if (!in_array($report_penalty_type, ['fixed', 'percent'])) {
        return new WP_Error('invalid_penalty_type', 'Loại phạt báo cáo không hợp lệ', ['status' => 400]);
    }
    if ($report_penalty_value < 0) {
        return new WP_Error('invalid_penalty_value', 'Giá trị phạt báo cáo không được âm', ['status' => 400]);
    }

    // Xác thực và xử lý fine_levels
    if ($fine_by_time) {
        if (!is_array($fine_levels)) {
            $fine_levels = json_decode($fine_levels, true) ?? [];
        }
        $validated_levels = [];
        foreach ($fine_levels as $level) {
            $range  = sanitize_text_field($level['range'] ?? '');
            $amount = floatval($level['amount'] ?? 0);
            if (!empty($range) && $amount > 0) {
                $validated_levels[] = ['range' => $range, 'amount' => $amount];
            }
        }
        $fine_levels = json_encode($validated_levels);
    } else {
        $fine_levels = '[]';
    }

    try {
        $penalty_table = $wpdb->prefix . 'checkin_mkt192_penalty_settings';
        $row_count     = $wpdb->get_var("SELECT COUNT(*) FROM $penalty_table");

        if ($row_count == 0) {
            $result = $wpdb->insert(
                $penalty_table,
                [
                    'id'                    => 1,
                    'penalty_enabled'       => $penalty_enabled,
                    'fine_amount'           => $fine_amount,
                    'fine_by_time'          => $fine_by_time,
                    'fine_levels'           => $fine_levels,
                    'report_enabled'        => $report_enabled,
                    'late_count_for_report' => $late_count_for_report,
                    'report_penalty_type'   => $report_penalty_type,
                    'report_penalty_value'  => $report_penalty_value
                ],
                ['%d', '%d', '%f', '%d', '%s', '%d', '%d', '%s', '%f']
            );
        } else {
            $result = $wpdb->update(
                $penalty_table,
                [
                    'penalty_enabled'       => $penalty_enabled,
                    'fine_amount'           => $fine_amount,
                    'fine_by_time'          => $fine_by_time,
                    'fine_levels'           => $fine_levels,
                    'report_enabled'        => $report_enabled,
                    'late_count_for_report' => $late_count_for_report,
                    'report_penalty_type'   => $report_penalty_type,
                    'report_penalty_value'  => $report_penalty_value
                ],
                ['id' => 1],
                ['%d', '%f', '%d', '%s', '%d', '%d', '%s', '%f'],
                ['%d']
            );
        }

        file_put_contents(
            __DIR__ . '/logs/penalty_errors.log',
            date('Y-m-d H:i:s') . " - Update penalty settings: result = {$result}\n",
            FILE_APPEND
        );

        if ($result === false) {
            throw new Exception('Không thể cập nhật cài đặt phạt');
        }

        return new WP_REST_Response(['success' => true, 'message' => 'Cập nhật cài đặt phạt thành công'], 200);
    } catch (Exception $e) {
        file_put_contents(
            __DIR__ . '/logs/penalty_errors.log',
            date('Y-m-d H:i:s') . ' - Failed to update penalty settings: ' . $e->getMessage() . "\n",
            FILE_APPEND
        );
        return new WP_Error('update_failed', 'Lỗi khi cập nhật cài đặt phạt: ' . $e->getMessage(), ['status' => 500]);
    }
}
?>