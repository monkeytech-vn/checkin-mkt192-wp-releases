<?php

add_action('rest_api_init', function () {
    // register_rest_route() for /settings/ctkm
    // CTKM Settings - GET (List promotions/campaigns)
    // Public: Cho phép trang customer review (offline/online) load danh sách CTKM
    register_rest_route('vg/v1', '/settings/ctkm', [
        'methods'             => 'GET',
        'callback'            => 'checkin_mkt192_get_ctkm_settings_api',
        'permission_callback' => '__return_true' // Public - customer review pages
    ]);

    // CTKM Settings - POST (Create new promotion)
register_rest_route('vg/v1', '/settings/ctkm', [
    'methods'             => 'POST',
    'callback'            => 'checkin_mkt192_save_ctkm_settings_api',
    'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'promotion.create']),
    'args'                => [
        'ctkm_name' => [
            'required'          => true,
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'validate_callback' => function ($param) {
                return !empty(trim($param)) && strlen($param) <= 100;
            },
        ],
        'value' => [
            'required'          => true,
            'type'              => 'number',
            'validate_callback' => function ($param) {
                return is_numeric($param) && $param >= 0;
            },
        ],
        'description' => [
            'required'          => false,
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_textarea_field',
            'validate_callback' => function ($param) {
                return strlen($param) <= 500;
            },
            'default' => '',
        ],
        'start_date' => [
            'required'          => true,
            'type'              => 'string',
            'validate_callback' => function ($param) {
                return preg_match('/^\d{4}-\d{2}-\d{2}$/', $param);
            },
        ],
        'end_date' => [
            'required'          => true,
            'type'              => 'string',
            'validate_callback' => function ($param) {
                return preg_match('/^\d{4}-\d{2}-\d{2}$/', $param);
            },
        ],
        'membership_label' => [
            'required'          => true,
            'type'              => 'array',
            'sanitize_callback' => function ($param) {
                if (!is_array($param)) {
                    $param = [$param];
                }
                return array_map('sanitize_text_field', $param);
            },
            'validate_callback' => function ($param) {
                if (!is_array($param)) {
                    $param = [$param];
                }
                $valid_values = ['Tất cả', 'Thường', 'Thành Viên', 'VIP'];
                return !empty($param) && count(array_diff($param, $valid_values)) === 0;
            },
        ],
        'status' => [
            'required'          => false,
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'validate_callback' => function ($param) {
                return in_array($param, ['active', 'inactive']);
            },
            'default' => 'active',
        ],
        'applicable_services' => [
            'required'          => false,
            'type'              => 'array',
            'sanitize_callback' => function ($param) {
                if (!is_array($param)) {
                    $param = [];
                }
                return array_map('sanitize_text_field', $param);
            },
            'validate_callback' => function ($param) {
                if (!is_array($param)) {
                    $param = [];
                }
                return true; // Cho phép mảng rỗng hoặc danh sách ID dịch vụ
            },
            'default' => [],
        ],
    ],
]);

// Cập nhật CTKM - PUT (Update existing promotion)
register_rest_route('vg/v1', '/settings/ctkm', [
    'methods'             => 'PUT',
    'callback'            => 'checkin_mkt192_update_ctkm_settings_api',
    'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'promotion.update']),
    'args'                => [
        'ctkm_name' => [
            'required'          => true,
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'validate_callback' => function ($param) {
                return !empty(trim($param)) && strlen($param) <= 100;
            },
        ],
        'value' => [
            'required'          => true,
            'type'              => 'number',
            'validate_callback' => function ($param) {
                return is_numeric($param) && $param >= 0;
            },
        ],
        'description' => [
            'required'          => false,
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_textarea_field',
            'validate_callback' => function ($param) {
                return strlen($param) <= 500;
            },
            'default' => '',
        ],
        'start_date' => [
            'required'          => true,
            'type'              => 'string',
            'validate_callback' => function ($param) {
                return preg_match('/^\d{4}-\d{2}-\d{2}$/', $param);
            },
        ],
        'end_date' => [
            'required'          => true,
            'type'              => 'string',
            'validate_callback' => function ($param) {
                return preg_match('/^\d{4}-\d{2}-\d{2}$/', $param);
            },
        ],
        'membership_label' => [
            'required'          => true,
            'type'              => 'array',
            'sanitize_callback' => function ($param) {
                if (!is_array($param)) {
                    $param = [$param];
                }
                return array_map('sanitize_text_field', $param);
            },
            'validate_callback' => function ($param) {
                if (!is_array($param)) {
                    $param = [$param];
                }
                $valid_values = ['Tất cả', 'Thường', 'Thành Viên', 'VIP'];
                return !empty($param) && count(array_diff($param, $valid_values)) === 0;
            },
        ],
        'status' => [
            'required'          => false,
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'validate_callback' => function ($param) {
                return in_array($param, ['active', 'inactive']);
            },
            'default' => 'active',
        ],
        'applicable_services' => [
            'required'          => false,
            'type'              => 'array',
            'sanitize_callback' => function ($param) {
                if (!is_array($param)) {
                    $param = [];
                }
                return array_map('sanitize_text_field', $param);
            },
            'validate_callback' => function ($param) {
                if (!is_array($param)) {
                    $param = [];
                }
                return true;
            },
            'default' => [],
        ],
    ],
]);

// Xóa CTKM - DELETE (Delete promotion by name)
register_rest_route('vg/v1', '/settings/ctkm/(?P<ctkm_name>[a-zA-Z0-9-_]+)', [
    'methods'             => 'DELETE',
    'callback'            => 'checkin_mkt192_delete_ctkm_settings_api',
    'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'promotion.delete']),
    'args'                => [
        'ctkm_name' => [
            'required'          => true,
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'validate_callback' => function ($param) {
                return !empty(trim($param)) && strlen($param) <= 100;
            },
        ],
    ],
]);

    /**
 * Get all CTKM settings
 */
function checkin_mkt192_get_ctkm_settings_api(WP_REST_Request $request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'checkin_mkt192_ctkm_settings';

    // Lấy tham số promo_type từ request (nếu có)
    $promo_type = $request->get_param('promo_type');

    // Xây dựng câu truy vấn SQL
    $query = "SELECT * FROM $table_name";
    if ($promo_type === 'ctkm' || $promo_type === 'voucher') {
        $query .= $wpdb->prepare(' WHERE promo_type = %s', $promo_type);
    }

    // Thực hiện truy vấn
    $results = $wpdb->get_results($query, ARRAY_A);

    // Xử lý membership_label
    foreach ($results as &$ctkm) {
        $ctkm['membership_label'] = json_decode($ctkm['membership_label'], true);
        if (!is_array($ctkm['membership_label'])) {
            $ctkm['membership_label'] = [$ctkm['membership_label']];
        }
    }

    return new WP_REST_Response([
        'success' => true,
        'data'    => $results
    ], 200);
}

/**
 * Save CTKM settings (POST)
 */
function checkin_mkt192_save_ctkm_settings_api(WP_REST_Request $request) {
    global $wpdb;
    $table_name    = $wpdb->prefix . 'checkin_mkt192_ctkm_settings';
    $service_table = $wpdb->prefix . 'bookingmkt192_service_data';
    $data          = $request->get_json_params();

    try {
        // Kiểm tra CTKM đã tồn tại
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM $table_name WHERE ctkm_name = %s",
            $data['ctkm_name']
        ));

        if ($existing) {
            return new WP_REST_Response(['success' => false, 'message' => 'CTKM hoặc Mã Ưu Đãi đã tồn tại.'], 400);
        }

        // Kiểm tra ngày hợp lệ
        $start_date = DateTime::createFromFormat('Y-m-d', $data['start_date']);
        $end_date   = DateTime::createFromFormat('Y-m-d', $data['end_date']);
        if (!$start_date || !$end_date || $start_date > $end_date) {
            return new WP_REST_Response(['success' => false, 'message' => 'Ngày bắt đầu phải nhỏ hơn hoặc bằng ngày kết thúc.'], 400);
        }

        // Chuẩn bị dữ liệu để lưu
        $membership_label = isset($data['membership_label']) ? $data['membership_label'] : [];
        if (!is_array($membership_label)) {
            $membership_label = [$membership_label];
        }
        $applicable_services = isset($data['applicable_services']) ? $data['applicable_services'] : [];
        if (!is_array($applicable_services)) {
            $applicable_services = [];
        }
        $promo_type     = isset($data['promo_type']) ? sanitize_text_field($data['promo_type']) : 'ctkm';
        $discount_value = floatval($data['value']);

        // Kiểm tra promo_type và applicable_services
        if ($promo_type === 'voucher' && empty($applicable_services)) {
            return new WP_REST_Response(['success' => false, 'message' => 'Mã ưu đãi phải có ít nhất một dịch vụ áp dụng.'], 400);
        }
        if ($promo_type === 'ctkm' && !empty($applicable_services)) {
            $applicable_services = []; // CTKM không nên có applicable_services
        }

        // Bắt đầu transaction
        $wpdb->query('START TRANSACTION');

        $insert_data = [
            'ctkm_name'           => sanitize_text_field($data['ctkm_name']),
            'value'               => $discount_value,
            'description'         => sanitize_textarea_field($data['description']),
            'start_date'          => $data['start_date'],
            'end_date'            => $data['end_date'],
            'membership_label'    => json_encode($membership_label, JSON_UNESCAPED_UNICODE),
            'applicable_services' => json_encode($applicable_services, JSON_UNESCAPED_UNICODE),
            'status'              => sanitize_text_field($data['status']),
            'promo_type'          => $promo_type,
            'created_at'          => current_time('mysql'),
        ];

        $format = ['%s', '%f', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s'];

        // Lưu vào bảng ctkm_settings
        $inserted = $wpdb->insert($table_name, $insert_data, $format);

        if ($inserted === false) {
            $wpdb->query('ROLLBACK');
            error_log('Save CTKM settings error: ' . $wpdb->last_error);
            return new WP_REST_Response(['success' => false, 'message' => 'Lỗi khi lưu CTKM: ' . $wpdb->last_error], 500);
        }

        // Nếu là mã ưu đãi, cập nhật discounted_price trong bảng dịch vụ
        if ($promo_type === 'voucher' && !empty($applicable_services)) {
            foreach ($applicable_services as $service_id) {
                // Lấy service_price hiện tại
                $service = $wpdb->get_row($wpdb->prepare(
                    "SELECT service_price FROM $service_table WHERE service_id = %s",
                    $service_id
                ));

                if ($service) {
                    $discounted_price                            = floatval($service->service_price) - $discount_value;
                    if ($discounted_price < 0) $discounted_price = 0;

                    $updated = $wpdb->update(
                        $service_table,
                        ['discounted_price' => $discounted_price],
                        ['service_id'       => $service_id],
                        ['%f'],
                        ['%s']
                    );

                    if ($updated === false) {
                        $wpdb->query('ROLLBACK');
                        error_log("Update service discounted_price error for service_id $service_id: " . $wpdb->last_error);
                        return new WP_REST_Response(['success' => false, 'message' => 'Lỗi khi cập nhật giá ưu đãi dịch vụ.'], 500);
                    }
                }
            }
        }

        // Commit transaction
        $wpdb->query('COMMIT');

        // Trả về dữ liệu đã lưu
        $insert_data['membership_label']    = $membership_label;
        $insert_data['applicable_services'] = $applicable_services;
        $insert_data['promo_type']          = $promo_type;
        return new WP_REST_Response([
            'success' => true,
            'message' => 'Lưu CTKM thành công',
            'data'    => $insert_data
        ], 200);
    } catch (Exception $e) {
        $wpdb->query('ROLLBACK');
        error_log('Save CTKM settings error: ' . $e->getMessage());
        return new WP_REST_Response(['success' => false, 'message' => 'Lỗi hệ thống: ' . $e->getMessage()], 500);
    }
}

/**
 * Update CTKM settings (PUT)
 */
function checkin_mkt192_update_ctkm_settings_api(WP_REST_Request $request) {
    global $wpdb;
    $table_name    = $wpdb->prefix . 'checkin_mkt192_ctkm_settings';
    $service_table = $wpdb->prefix . 'bookingmkt192_service_data';
    $data          = $request->get_json_params();

    try {
        // Kiểm tra CTKM tồn tại
        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT applicable_services, promo_type FROM $table_name WHERE ctkm_name = %s",
            $data['ctkm_name']
        ));

        if (!$existing) {
            return new WP_REST_Response(['success' => false, 'message' => 'Không tìm thấy CTKM hoặc Mã Ưu Đãi để cập nhật.'], 404);
        }

        // Kiểm tra ngày hợp lệ
        $start_date = DateTime::createFromFormat('Y-m-d', $data['start_date']);
        $end_date   = DateTime::createFromFormat('Y-m-d', $data['end_date']);
        if (!$start_date || !$end_date || $start_date > $end_date) {
            return new WP_REST_Response(['success' => false, 'message' => 'Ngày bắt đầu phải nhỏ hơn hoặc bằng ngày kết thúc.'], 400);
        }

        // Chuẩn bị dữ liệu để cập nhật
        $membership_label = isset($data['membership_label']) ? $data['membership_label'] : [];
        if (!is_array($membership_label)) {
            $membership_label = [$membership_label];
        }
        $applicable_services = isset($data['applicable_services']) ? $data['applicable_services'] : [];
        if (!is_array($applicable_services)) {
            $applicable_services = [];
        }
        $promo_type     = isset($data['promo_type']) ? sanitize_text_field($data['promo_type']) : 'ctkm';
        $discount_value = floatval($data['value']);

        // Kiểm tra promo_type và applicable_services
        if ($promo_type === 'voucher' && empty($applicable_services)) {
            return new WP_REST_Response(['success' => false, 'message' => 'Mã ưu đãi phải có ít nhất một dịch vụ áp dụng.'], 400);
        }
        if ($promo_type === 'ctkm' && !empty($applicable_services)) {
            $applicable_services = [];
        }

        // Bắt đầu transaction
        $wpdb->query('START TRANSACTION');

        $update_data = [
            'ctkm_name'           => sanitize_text_field($data['ctkm_name']),
            'value'               => $discount_value,
            'description'         => sanitize_textarea_field($data['description']),
            'start_date'          => $data['start_date'],
            'end_date'            => $data['end_date'],
            'membership_label'    => json_encode($membership_label, JSON_UNESCAPED_UNICODE),
            'applicable_services' => json_encode($applicable_services, JSON_UNESCAPED_UNICODE),
            'status'              => sanitize_text_field($data['status']),
            'promo_type'          => $promo_type,
        ];

        $where        = ['ctkm_name' => $data['ctkm_name']];
        $format       = ['%s', '%f', '%s', '%s', '%s', '%s', '%s', '%s', '%s'];
        $where_format = ['%s'];

        // Cập nhật bảng ctkm_settings
        $updated = $wpdb->update($table_name, $update_data, $where, $format, $where_format);

        if ($updated === false) {
            $wpdb->query('ROLLBACK');
            error_log('Update CTKM settings error: ' . $wpdb->last_error);
            return new WP_REST_Response(['success' => false, 'message' => 'Lỗi khi cập nhật CTKM: ' . $wpdb->last_error], 500);
        }

        // Nếu là mã ưu đãi, cập nhật discounted_price
        if ($promo_type === 'voucher') {
            // Lấy danh sách dịch vụ cũ
            $old_services = json_decode($existing->applicable_services, true) ?: [];

            // Xóa discounted_price cho các dịch vụ không còn trong applicable_services
            $removed_services = array_diff($old_services, $applicable_services);
            foreach ($removed_services as $service_id) {
                $updated = $wpdb->update(
                    $service_table,
                    ['discounted_price' => null],
                    ['service_id'       => $service_id],
                    ['%s'],
                    ['%s']
                );
                if ($updated === false) {
                    $wpdb->query('ROLLBACK');
                    error_log("Reset service discounted_price error for service_id $service_id: " . $wpdb->last_error);
                    return new WP_REST_Response(['success' => false, 'message' => 'Lỗi khi xóa giá ưu đãi dịch vụ.'], 500);
                }
            }

            // Cập nhật discounted_price cho các dịch vụ mới
            foreach ($applicable_services as $service_id) {
                $service = $wpdb->get_row($wpdb->prepare(
                    "SELECT service_price FROM $service_table WHERE service_id = %s",
                    $service_id
                ));

                if ($service) {
                    $discounted_price                            = floatval($service->service_price) - $discount_value;
                    if ($discounted_price < 0) $discounted_price = 0;

                    $updated = $wpdb->update(
                        $service_table,
                        ['discounted_price' => $discounted_price],
                        ['service_id'       => $service_id],
                        ['%f'],
                        ['%s']
                    );

                    if ($updated === false) {
                        $wpdb->query('ROLLBACK');
                        error_log("Update service discounted_price error for service_id $service_id: " . $wpdb->last_error);
                        return new WP_REST_Response(['success' => false, 'message' => 'Lỗi khi cập nhật giá ưu đãi dịch vụ.'], 500);
                    }
                }
            }
        } elseif ($promo_type === 'ctkm' && !empty($old_services)) {
            // Nếu chuyển từ voucher sang ctkm, xóa discounted_price
            foreach ($old_services as $service_id) {
                $updated = $wpdb->update(
                    $service_table,
                    ['discounted_price' => null],
                    ['service_id'       => $service_id],
                    ['%s'],
                    ['%s']
                );
                if ($updated === false) {
                    $wpdb->query('ROLLBACK');
                    error_log("Reset service discounted_price error for service_id $service_id: " . $wpdb->last_error);
                    return new WP_REST_Response(['success' => false, 'message' => 'Lỗi khi xóa giá ưu đãi dịch vụ.'], 500);
                }
            }
        }

        // Commit transaction
        $wpdb->query('COMMIT');

        // Trả về dữ liệu đã cập nhật
        $update_data['membership_label']    = $membership_label;
        $update_data['applicable_services'] = $applicable_services;
        $update_data['promo_type']          = $promo_type;
        return new WP_REST_Response([
            'success' => true,
            'message' => 'Cập nhật CTKM thành công',
            'data'    => $update_data
        ], 200);
    } catch (Exception $e) {
        $wpdb->query('ROLLBACK');
        error_log('Update CTKM settings error: ' . $e->getMessage());
        return new WP_REST_Response(['success' => false, 'message' => 'Lỗi hệ thống: ' . $e->getMessage()], 500);
    }
}

/**
 * Delete CTKM settings (DELETE)
 */
function checkin_mkt192_delete_ctkm_settings_api(WP_REST_Request $request) {
    global $wpdb;
    $table_name    = $wpdb->prefix . 'checkin_mkt192_ctkm_settings';
    $service_table = $wpdb->prefix . 'bookingmkt192_service_data';
    $ctkm_name     = $request->get_param('ctkm_name');

    try {
        // Kiểm tra CTKM tồn tại
        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT applicable_services, promo_type FROM $table_name WHERE ctkm_name = %s",
            $ctkm_name
        ));

        if (!$existing) {
            return new WP_REST_Response(['success' => false, 'message' => 'Không tìm thấy CTKM hoặc Mã Ưu Đãi.'], 404);
        }

        // Bắt đầu transaction
        $wpdb->query('START TRANSACTION');

        // Xóa CTKM
        $deleted = $wpdb->delete(
            $table_name,
            ['ctkm_name' => sanitize_text_field($ctkm_name)],
            ['%s']
        );

        if ($deleted === false) {
            $wpdb->query('ROLLBACK');
            error_log('Delete CTKM settings error: ' . $wpdb->last_error);
            return new WP_REST_Response(['success' => false, 'message' => 'Lỗi khi xóa CTKM: ' . $wpdb->last_error], 500);
        }

        // Nếu là mã ưu đãi, xóa discounted_price
        if ($existing->promo_type === 'voucher') {
            $applicable_services = json_decode($existing->applicable_services, true) ?: [];
            foreach ($applicable_services as $service_id) {
                $updated = $wpdb->update(
                    $service_table,
                    ['discounted_price' => null],
                    ['service_id'       => $service_id],
                    ['%s'],
                    ['%s']
                );
                if ($updated === false) {
                    $wpdb->query('ROLLBACK');
                    error_log("Reset service discounted_price error for service_id $service_id: " . $wpdb->last_error);
                    return new WP_REST_Response(['success' => false, 'message' => 'Lỗi khi xóa giá ưu đãi dịch vụ.'], 500);
                }
            }
        }

        // Commit transaction
        $wpdb->query('COMMIT');

        return new WP_REST_Response([
            'success' => true,
            'message' => 'Xóa CTKM thành công'
        ], 200);
    } catch (Exception $e) {
        $wpdb->query('ROLLBACK');
        error_log('Delete CTKM settings error: ' . $e->getMessage());
        return new WP_REST_Response(['success' => false, 'message' => 'Lỗi hệ thống: ' . $e->getMessage()], 500);
    }
}
});