<?php

add_action('rest_api_init', function () {
    // Staff: Xem chi tiết đánh giá ở chế độ read-only
    register_rest_route('vg/v1', '/review-detail/(?P<invoice_id>[a-zA-Z0-9_-]+)', [
        'methods'             => 'GET',
        'callback'            => 'checkin_mkt192_get_review_detail',
        'permission_callback' => '__return_true', // Allow staff/admin to view review details
    ]);

    // Public: Khách hàng xem thông tin hóa đơn để đánh giá
    register_rest_route('vg/v1', '/review/invoices/(?P<invoice_id>[a-zA-Z0-9_-]+)', [
    'methods'             => 'GET',
    'callback'            => 'checkin_mkt192_get_invoice_for_review_api',
    'permission_callback' => '__return_true', // Public - customer review form
]);

// Quản lý thông báo đánh giá
register_rest_route('vg/v1', '/notify-review', [
    [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_save_notify_review',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'review.moderate'])
    ],
    [
        'methods'             => 'DELETE',
        'callback'            => 'checkin_mkt192_delete_notify_review',
        'permission_callback' => '__return_true' // Public - customer review pages can dismiss notification
    ]
]);

// Public: Tablet lấy danh sách đánh giá chờ
register_rest_route('vg/v1', '/pending-review', [
    'methods'             => 'GET',
    'callback'            => 'checkin_mkt192_get_pending_review',
    'permission_callback' => '__return_true', // Public - tablet display
]);

// Public: Khách hàng gửi đánh giá
register_rest_route('vg/v1', '/save-reviews', [
    'methods'             => 'POST',
    'callback'            => 'checkin_mkt192_save_review_api',
    'permission_callback' => '__return_true', // Public - customer submit
    'args'                => [
        'invoice_id' => [
            'required'          => true,
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
        ],
        'customer_id' => [
            'required'          => false,
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
        ],
        'customer_name' => [
            'required'          => true,
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
        ],
        'service_rating' => [
            'required'          => true,
            'type'              => 'integer',
            'sanitize_callback' => 'absint',
            'validate_callback' => function ($param) {
                return $param >= 1 && $param <= 5;
            },
        ],
        'staff_rating' => [
            'required'          => true,
            'type'              => 'integer',
            'sanitize_callback' => 'absint',
            'validate_callback' => function ($param) {
                return $param >= 1 && $param <= 5;
            },
        ],
        'feedback' => [
            'required'          => false,
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_textarea_field',
        ],
    ],
]);

// Public: Xem đánh giá của hóa đơn
register_rest_route('vg/v1', '/reviews/(?P<invoice_id>[a-zA-Z0-9_-]+)', [
    'methods'             => 'GET',
    'callback'            => 'checkin_mkt192_get_reviews_by_invoice',
    'permission_callback' => '__return_true', // Public - display reviews
]);
});

function checkin_mkt192_save_review_api(WP_REST_Request $request) {
    global $wpdb;
    $table_reviews_online  = $wpdb->prefix . 'checkin_mkt192_customer_reviews_online';
    $table_reviews_offline = $wpdb->prefix . 'checkin_mkt192_customer_reviews_off';
    $table_invoices        = $wpdb->prefix . 'checkin_mkt192_invoices_data_detail';
    $table_pending_reviews = $wpdb->prefix . 'checkin_mkt192_pending_reviews';
    $staff_table           = $wpdb->prefix . 'checkin_mkt192_staff';
    $data                  = $request->get_json_params();
    $log_file              = __DIR__ . '/logs/send_message_bad_feedback_log.log';

    // Ghi log yêu cầu đầu vào
    $log_entry = '[' . date('Y-m-d H:i:s') . "] Nhận yêu cầu lưu đánh giá\n";
    $log_entry .= 'Data: ' . json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
    $log_entry .= "----------------------------------------\n";
    file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);

    // Xác định mode dựa trên query parameter 'mode'
    $mode          = $request->get_param('mode');
    $is_offline    = ($mode === 'offline');
    $table_reviews = $is_offline ? $table_reviews_offline : $table_reviews_online;

    try {
        // Lấy tất cả các dòng liên quan đến invoice_id
        $invoices = $wpdb->get_results($wpdb->prepare(
            "SELECT invoice_id, service_name, staff_name, created_at
             FROM $table_invoices
             WHERE invoice_id = %s",
            $data['invoice_id']
        ));
        if (empty($invoices)) {
            $log_entry = '[' . date('Y-m-d H:i:s') . "] Hóa đơn không tồn tại\n";
            $log_entry .= 'Data: ' . json_encode(['invoice_id' => $data['invoice_id']], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
            $log_entry .= "----------------------------------------\n";
            file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);
            return new WP_REST_Response(['success' => false, 'message' => 'Hóa đơn không tồn tại'], 404);
        }

        // Gộp service_name và staff_name từ tất cả các dòng
        $service_names = array_unique(array_filter(array_map(function($row) {
            return !empty($row->service_name) ? sanitize_text_field($row->service_name) : null;
        }, $invoices)));
        $staff_names = array_unique(array_filter(array_map(function($row) {
            return !empty($row->staff_name) ? sanitize_text_field($row->staff_name) : null;
        }, $invoices)));
        $service_name = implode(', ', $service_names) ?: null;
        $staff_name   = implode(', ', $staff_names) ?: null;
        $created_at   = $invoices[0]->created_at; // Lấy created_at từ dòng đầu tiên

        // Hàm ánh xạ rating sang văn bản
        $rating_texts = [
            1 => 'Rất tệ',
            2 => 'Chê nha',
            3 => 'Không ưng lắm',
            4 => 'Hài lòng',
            5 => 'Siêu hài lòng'
        ];

        // Kiểm tra xem hóa đơn đã được đánh giá chưa
        $existing_review = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table_reviews WHERE invoice_id = %s",
            $data['invoice_id']
        ));
        if ($existing_review > 0) {
            $log_entry = '[' . date('Y-m-d H:i:s') . "] Hóa đơn đã được đánh giá\n";
            $log_entry .= 'Data: ' . json_encode(['invoice_id' => $data['invoice_id']], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
            $log_entry .= "----------------------------------------\n";
            file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);
            return new WP_REST_Response(['success' => false, 'message' => 'Hóa đơn này đã được đánh giá'], 400);
        }

        // Chuẩn bị dữ liệu đánh giá
        $insert_data = [
            'invoice_id'     => sanitize_text_field($data['invoice_id']),
            'customer_id'    => !empty($data['customer_id']) ? sanitize_text_field($data['customer_id']) : null,
            'customer_name'  => sanitize_text_field($data['customer_name']),
            'service_name'   => $service_name,
            'staff_name'     => $staff_name,
            'service_rating' => absint($data['service_rating']),
            'staff_rating'   => absint($data['staff_rating']),
            'feedback'       => !empty($data['feedback']) ? sanitize_textarea_field($data['feedback']) : null,
            'created_at'     => !empty($created_at) ? $created_at : current_time('mysql'),
            'updated_at'     => current_time('mysql'),
        ];

        // Chèn dữ liệu vào bảng reviews
        $inserted = $wpdb->insert(
            $table_reviews,
            $insert_data,
            ['%s', '%s', '%s', '%s', '%s', '%d', '%d', '%s', '%s', '%s']
        );

        if ($inserted === false) {
            $error_message = 'Lỗi khi lưu đánh giá: ' . $wpdb->last_error;
            $log_entry     = '[' . date('Y-m-d H:i:s') . "] $error_message\n";
            $log_entry .= 'Data: ' . json_encode(['insert_data' => $insert_data], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
            $log_entry .= "----------------------------------------\n";
            file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);
            return new WP_REST_Response(['success' => false, 'message' => $error_message], 500);
        }

        // Cập nhật trạng thái trong bảng pending_reviews thành "Đã xong" (chỉ cho offline)
        if ($is_offline) {
            $updated = $wpdb->update(
                $table_pending_reviews,
                ['status'     => 'Đã xong', 'processed_at' => current_time('mysql')],
                ['invoice_id' => $data['invoice_id']],
                ['%s', '%s'],
                ['%s']
            );

            if ($updated === false) {
                $error_message = 'Lỗi khi cập nhật status trong pending_reviews: ' . $wpdb->last_error;
                $log_entry     = '[' . date('Y-m-d H:i:s') . "] $error_message\n";
                $log_entry .= 'Data: ' . json_encode(['invoice_id' => $data['invoice_id']], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
                $log_entry .= "----------------------------------------\n";
                file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);
            }
        }

        // Lấy staff_id từ bảng checkin_mkt192_staff
        $staff = $wpdb->get_row($wpdb->prepare(
            "SELECT ou_id FROM $staff_table WHERE display_name = %s",
            $insert_data['staff_name']
        ));
        if ($wpdb->last_error) {
            $log_entry = '[' . date('Y-m-d H:i:s') . "] Lỗi database khi truy vấn ou_id\n";
            $log_entry .= 'Error: ' . $wpdb->last_error . "\n";
            $log_entry .= "----------------------------------------\n";
            file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);
        }
        $staffId = $staff ? $staff->ou_id : null;

        // Lấy giá trị checkin_use_zalo_user và checkin_zalo_user_domain
        $use_zalo_webhook  = get_option('checkin_use_zalo_user', '');
        $zalo_user_domain  = get_option('checkin_zalo_user_domain', '');

        // Xử lý đánh giá tệ (service_rating hoặc staff_rating ≤ 3)
        if ($insert_data['service_rating'] <= 3 || $insert_data['staff_rating'] <= 3) {
            $feedback_type     = 'bad';
            $notification_data = [
                'invoice_id'     => $insert_data['invoice_id'],
                'customer_name'  => $insert_data['customer_name'],
                'service_name'   => $insert_data['service_name'] ?: 'Không xác định',
                'staff_name'     => $insert_data['staff_name'] ?: 'Không xác định',
                'service_rating' => $rating_texts[$insert_data['service_rating']] . ' - ' . $insert_data['service_rating'] . '★',
                'staff_rating'   => $rating_texts[$insert_data['staff_rating']] . ' - ' . $insert_data['staff_rating'] . '★',
                'feedback'       => $insert_data['feedback'] ?: 'Không có phản hồi',
                'created_at'     => $insert_data['created_at'],
                'is_offline'     => $is_offline, // Giữ nguyên để tương thích cũ
                'feedback_type'  => $feedback_type,
                'review_mode'    => $is_offline ? 'offline' : 'online',
                'staff_id'       => $staffId
            ];

            // Ghi log trước khi gửi yêu cầu
            $log_entry = '[' . date('Y-m-d H:i:s') . "] Gửi yêu cầu thông báo đánh giá tệ\n";
            $log_entry .= 'Data: ' . json_encode($notification_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
            $log_entry .= "----------------------------------------\n";
            file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);

            if ($use_zalo_webhook === '1') {
                // Gửi qua webhook nếu checkin_use_zalo_user = 1
                $webhook_url = "{$zalo_user_domain}/webhook/n8n-send-message-feedback";
                try {
                    $ch = curl_init($webhook_url);
                    curl_setopt($ch, CURLOPT_HTTPHEADER, [
                        'Content-Type: application/json'
                    ]);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($notification_data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
                    $response   = curl_exec($ch);
                    $http_code  = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                    $curl_error = curl_error($ch);
                    curl_close($ch);

                    $response_data      = json_decode($response, true);
                    $is_webhook_success = ($http_code == 200 && (!isset($response_data['error']) || $response_data['error'] == 0));
                    $message_status     = $is_webhook_success ? 'success' : (isset($response_data['message']) ? $response_data['message'] : ($curl_error ?: 'Unknown error'));

                    $log_entry = '[' . date('Y-m-d H:i:s') . "] webhook | HTTP $http_code\n";
                    $log_entry .= 'Data: ' . json_encode([
                        'payload'    => $notification_data,
                        'response'   => $response_data,
                        'curl_error' => $curl_error
                    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
                    $log_entry .= "----------------------------------------\n";
                    file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);
                } catch (Exception $e) {
                    $error_message = 'Lỗi khi gửi webhook đánh giá tệ: ' . $e->getMessage();
                    $log_entry     = '[' . date('Y-m-d H:i:s') . "] $error_message\n";
                    $log_entry .= 'Data: ' . json_encode(['notification_data' => $notification_data], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
                    $log_entry .= "----------------------------------------\n";
                    file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);
                }
            } else {
                // Gửi qua Lark nếu checkin_use_zalo_user = 0
                $response = wp_remote_post(
                    home_url('wp-content/plugins/checkin-mkt192-wp/includes/lark/send-message-feedback.php'),
                    [
                        'method'  => 'POST',
                        'headers' => ['Content-Type' => 'application/json; charset=utf-8'],
                        'body'    => json_encode($notification_data, JSON_UNESCAPED_UNICODE),
                        'timeout' => 15
                    ]
                );

                if (is_wp_error($response)) {
                    $error_message = 'Lỗi khi gửi thông báo đánh giá tệ: ' . $response->get_error_message();
                    $log_entry     = '[' . date('Y-m-d H:i:s') . "] $error_message\n";
                    $log_entry .= 'Data: ' . json_encode(['notification_data' => $notification_data], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
                    $log_entry .= "----------------------------------------\n";
                    file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);
                } else {
                    $response_code = wp_remote_retrieve_response_code($response);
                    $response_body = wp_remote_retrieve_body($response);
                    $log_entry     = '[' . date('Y-m-d H:i:s') . "] Phản hồi từ send-message-feedback.php\n";
                    $log_entry .= 'Data: ' . json_encode(['http_code' => $response_code, 'body' => $response_body], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
                    $log_entry .= "----------------------------------------\n";
                    file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);
                }
            }
        }
        // Kiểm tra đánh giá tốt (service_rating và staff_rating ≥ 4, chỉ cho online)
        elseif (!$is_offline && $insert_data['service_rating'] >= 4 && $insert_data['staff_rating'] >= 4) {
            $feedback_type     = 'good';
            $notification_data = [
                'invoice_id'     => $insert_data['invoice_id'],
                'customer_name'  => $insert_data['customer_name'],
                'service_name'   => $insert_data['service_name'] ?: 'Không xác định',
                'staff_name'     => $insert_data['staff_name'] ?: 'Không xác định',
                'service_rating' => $rating_texts[$insert_data['service_rating']] . ' - ' . $insert_data['service_rating'] . '⭐',
                'staff_rating'   => $rating_texts[$insert_data['staff_rating']] . ' - ' . $insert_data['staff_rating'] . '⭐',
                'feedback'       => $insert_data['feedback'] ?: 'Không có phản hồi',
                'created_at'     => $insert_data['created_at'],
                'feedback_type'  => $feedback_type,
                'review_mode'    => $is_offline ? 'Đánh giá trực tiếp tại Shop' : 'Đánh giá từ Hóa đơn thanh toán',
                'staff_id'       => $staffId
            ];

            // Ghi log trước khi gửi yêu cầu
            $log_entry = '[' . date('Y-m-d H:i:s') . "] Gửi yêu cầu thông báo đánh giá tốt\n";
            $log_entry .= 'Data: ' . json_encode($notification_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
            $log_entry .= "----------------------------------------\n";
            file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);

            if ($use_zalo_webhook === '1') {
                // Gửi qua webhook nếu checkin_use_zalo_user = 1
                $webhook_url = "{$zalo_user_domain}/webhook/n8n-send-message-feedback";
                try {
                    $ch = curl_init($webhook_url);
                    curl_setopt($ch, CURLOPT_HTTPHEADER, [
                        'Content-Type: application/json'
                    ]);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($notification_data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
                    $response   = curl_exec($ch);
                    $http_code  = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                    $curl_error = curl_error($ch);
                    curl_close($ch);

                    $response_data      = json_decode($response, true);
                    $is_webhook_success = ($http_code == 200 && (!isset($response_data['error']) || $response_data['error'] == 0));
                    $message_status     = $is_webhook_success ? 'success' : (isset($response_data['message']) ? $response_data['message'] : ($curl_error ?: 'Unknown error'));

                    $log_entry = '[' . date('Y-m-d H:i:s') . "] webhook | HTTP $http_code\n";
                    $log_entry .= 'Data: ' . json_encode([
                        'payload'    => $notification_data,
                        'response'   => $response_data,
                        'curl_error' => $curl_error
                    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
                    $log_entry .= "----------------------------------------\n";
                    file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);
                } catch (Exception $e) {
                    $error_message = 'Lỗi khi gửi webhook đánh giá tốt: ' . $e->getMessage();
                    $log_entry     = '[' . date('Y-m-d H:i:s') . "] $error_message\n";
                    $log_entry .= 'Data: ' . json_encode([
                        'notification_data' => $notification_data
                    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
                    $log_entry .= "----------------------------------------\n";
                    file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);
                }
            } else {
                // Gửi qua Lark nếu checkin_use_zalo_user = 0
                $response = wp_remote_post(
                    home_url('wp-content/plugins/checkin-mkt192-wp/includes/lark/send-message-feedback.php'),
                    [
                        'method'  => 'POST',
                        'headers' => ['Content-Type' => 'application/json; charset=utf-8'],
                        'body'    => json_encode($notification_data, JSON_UNESCAPED_UNICODE),
                        'timeout' => 15
                    ]
                );

                if (is_wp_error($response)) {
                    $error_message = 'Lỗi khi gửi thông báo đánh giá tốt: ' . $response->get_error_message();
                    $log_entry     = '[' . date('Y-m-d H:i:s') . "] $error_message\n";
                    $log_entry .= 'Data: ' . json_encode(['notification_data' => $notification_data], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
                    $log_entry .= "----------------------------------------\n";
                    file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);
                } else {
                    $response_code = wp_remote_retrieve_response_code($response);
                    $response_body = wp_remote_retrieve_body($response);
                    $log_entry     = '[' . date('Y-m-d H:i:s') . "] Phản hồi từ send-message-feedback.php\n";
                    $log_entry .= 'Data: ' . json_encode(['http_code' => $response_code, 'body' => $response_body], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
                    $log_entry .= "----------------------------------------\n";
                    file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);
                }
            }
        }

        $log_entry = '[' . date('Y-m-d H:i:s') . "] Lưu đánh giá thành công\n";
        $log_entry .= 'Data: ' . json_encode($insert_data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
        $log_entry .= "----------------------------------------\n";
        file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);

        // Send push notification to staff about new review (chỉ cho review online)
        if (!$is_offline && $staffId && function_exists('checkin_mkt192_notify_new_review')) {
            // Get staff WordPress user ID from ou_id
            $staff_user_id = $wpdb->get_var($wpdb->prepare(
                "SELECT user_id FROM $staff_table WHERE ou_id = %s",
                $staffId
            ));

            // Lấy branch_id từ invoice
            $invoice_branch_id = $wpdb->get_var($wpdb->prepare(
                "SELECT branch_id FROM {$wpdb->prefix}checkin_mkt192_invoices_data WHERE invoice_id = %s",
                $insert_data['invoice_id']
            ));

            if ($staff_user_id) {
                checkin_mkt192_notify_new_review($staff_user_id, [
                    'rating'        => max($insert_data['service_rating'], $insert_data['staff_rating']),
                    'customer_name' => $insert_data['customer_name'],
                    'staff_name'    => $insert_data['staff_name'] ?? '',
                    'invoice_id'    => $insert_data['invoice_id'],
                    'branch_id'     => $invoice_branch_id ? intval($invoice_branch_id) : null,
                    'id'            => $wpdb->insert_id
                ]);
            }
        }

        return new WP_REST_Response([
            'success' => true,
            'message' => 'Đánh giá đã được lưu thành công',
            'data'    => $insert_data
        ], 201);
    } catch (Exception $e) {
        $error_message = 'Lỗi hệ thống: ' . $e->getMessage();
        $log_entry     = '[' . date('Y-m-d H:i:s') . "] $error_message\n";
        $log_entry .= 'Data: ' . json_encode(['data' => $data], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
        $log_entry .= "----------------------------------------\n";
        file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);
        return new WP_REST_Response(['success' => false, 'message' => $error_message], 500);
    }
}

function checkin_mkt192_get_pending_review() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'checkin_mkt192_pending_reviews';

    // Kiểm tra bảng tồn tại
    $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table_name'") === $table_name;
    if (!$table_exists) {
        error_log("Bảng $table_name không tồn tại");
        return new WP_REST_Response(['success' => false, 'message' => "Bảng $table_name không tồn tại"], 500);
    }

    // Kiểm tra và thêm cột is_processed, processed_at nếu chưa tồn tại
    $columns          = $wpdb->get_results("SHOW COLUMNS FROM $table_name");
    $has_is_processed = false;
    $has_processed_at = false;
    foreach ($columns as $column) {
        if ($column->Field === 'is_processed') $has_is_processed = true;
        if ($column->Field === 'processed_at') $has_processed_at = true;
    }

    if (!$has_is_processed) {
        $result = $wpdb->query("ALTER TABLE $table_name ADD is_processed TINYINT DEFAULT 0");
        if ($result === false) {
            error_log("Lỗi khi thêm cột is_processed vào $table_name: " . $wpdb->last_error);
            return new WP_REST_Response(['success' => false, 'message' => 'Lỗi khi cập nhật bảng'], 500);
        }
        error_log("Đã thêm cột is_processed vào $table_name");
    }

    if (!$has_processed_at) {
        $result = $wpdb->query("ALTER TABLE $table_name ADD processed_at DATETIME NULL");
        if ($result === false) {
            error_log("Lỗi khi thêm cột processed_at vào $table_name: " . $wpdb->last_error);
            return new WP_REST_Response(['success' => false, 'message' => 'Lỗi khi cập nhật bảng'], 500);
        }
        error_log("Đã thêm cột processed_at vào $table_name");
    }

    // Lấy invoice_id mới nhất chưa được xử lý hoặc đang xử lý nhưng chưa có status "Đã xong"
    $invoice_id = $wpdb->get_var("SELECT invoice_id FROM $table_name WHERE (is_processed = 0 OR (is_processed = 1 AND (status IS NULL OR status = 'pending'))) ORDER BY created_at DESC LIMIT 1");

    if (!$invoice_id) {
        return new WP_REST_Response(['success' => false, 'message' => 'Không có hóa đơn chờ đánh giá'], 404);
    }

    // Đánh dấu invoice_id là đang xử lý
    $updated = $wpdb->update(
        $table_name,
        ['is_processed' => 1, 'processed_at' => current_time('mysql')],
        ['invoice_id'   => $invoice_id],
        ['%d', '%s'],
        ['%s']
    );

    if ($updated === false) {
        error_log("Lỗi khi đánh dấu invoice_id $invoice_id là đang xử lý: " . $wpdb->last_error);
        return new WP_REST_Response(['success' => false, 'message' => 'Lỗi khi xử lý hóa đơn'], 500);
    }

    // Kiểm tra hóa đơn có hợp lệ (đã thanh toán) bằng trường status
    $invoice_table = $wpdb->prefix . 'checkin_mkt192_invoices_data';
    $invoice       = $wpdb->get_row($wpdb->prepare("SELECT status FROM $invoice_table WHERE invoice_id = %s", $invoice_id), ARRAY_A);

    if (!$invoice) {
        $wpdb->delete($table_name, ['invoice_id' => $invoice_id], ['%s']);
        return new WP_REST_Response(['success' => false, 'message' => 'Hóa đơn không tồn tại'], 404);
    }

    // Lấy thêm cashier từ pending_reviews
    $row = $wpdb->get_row(
        $wpdb->prepare("SELECT invoice_id, cashier FROM $table_name WHERE invoice_id = %s", $invoice_id),
        ARRAY_A
    );

    return new WP_REST_Response([
        'success' => true,
        'data'    => [
            'invoice_id' => $row['invoice_id'],
            'cashier'    => $row['cashier'] ?? null
        ]
    ], 200);
}

function checkin_mkt192_save_notify_review(WP_REST_Request $request) {
    global $wpdb;
    $invoice_id = sanitize_text_field($request['invoice_id']);
    $cashier    = sanitize_text_field($request['cashier']);

    if (empty($invoice_id)) {
        error_log('Thiếu invoice_id trong yêu cầu notify-review');
        return new WP_REST_Response(['success' => false, 'message' => 'Thiếu invoice_id'], 400);
    }

    $table_name = $wpdb->prefix . 'checkin_mkt192_pending_reviews';

    $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table_name'") === $table_name;
    if (!$table_exists) {
        error_log("Bảng $table_name không tồn tại");
        return new WP_REST_Response(['success' => false, 'message' => "Bảng $table_name không tồn tại"], 500);
    }

    // Kiểm tra trạng thái của invoice_id
    $review_status = $wpdb->get_var($wpdb->prepare(
        "SELECT status FROM $table_name WHERE invoice_id = %s",
        $invoice_id
    ));

    if ($review_status === 'Đã xong') {
        error_log("Hóa đơn $invoice_id đã được đánh giá xong");
        return new WP_REST_Response(['success' => true, 'is_completed' => true, 'message' => 'Hóa đơn đã được đánh giá xong'], 200);
    }

    if ($review_status !== null) {
        error_log("Hóa đơn $invoice_id đã được yêu cầu đánh giá, trạng thái: $review_status");
        return new WP_REST_Response(['success' => true, 'is_completed' => false, 'message' => 'Hóa đơn đã được gửi đến Trang đánh giá'], 200);
    }

    // Chèn bản ghi mới nếu hóa đơn chưa tồn tại
    $inserted = $wpdb->insert(
        $table_name,
        [
            'invoice_id'   => $invoice_id,
            'created_at'   => current_time('mysql'),
            'is_processed' => 0,
            'status'       => 'pending',
            'cashier'      => $cashier
        ],
        ['%s', '%s', '%d', '%s', '%s']
    );

    if ($inserted === false) {
        error_log("Lỗi khi lưu invoice_id $invoice_id vào $table_name: " . $wpdb->last_error);
        return new WP_REST_Response(['success' => false, 'message' => 'Lỗi khi lưu thông báo: ' . $wpdb->last_error], 500);
    }

    error_log("Đã lưu thông báo đánh giá cho hóa đơn $invoice_id");
    return new WP_REST_Response(['success' => true, 'is_completed' => false, 'message' => 'Hóa đơn đã được gửi đến Trang đánh giá'], 200);
}

function checkin_mkt192_delete_notify_review(WP_REST_Request $request) {
    global $wpdb;
    $invoice_id = sanitize_text_field($request['invoice_id']);

    if (empty($invoice_id)) {
        error_log('Thiếu invoice_id trong yêu cầu notify-review DELETE');
        return new WP_REST_Response(['success' => false, 'message' => 'Thiếu invoice_id'], 400);
    }

    $table_name = $wpdb->prefix . 'checkin_mkt192_pending_reviews';

    $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table_name'") === $table_name;
    if (!$table_exists) {
        error_log("Bảng $table_name không tồn tại");
        return new WP_REST_Response(['success' => false, 'message' => "Bảng $table_name không tồn tại"], 500);
    }

    // Kiểm tra xem bản ghi có tồn tại không
    $existing_record = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $table_name WHERE invoice_id = %s",
        $invoice_id
    ));

    if ($existing_record == 0) {
        error_log("Không tìm thấy hóa đơn $invoice_id trong $table_name");
        return new WP_REST_Response(['success' => false, 'message' => 'Hóa đơn không tồn tại trong danh sách đánh giá'], 404);
    }

    // Xóa bản ghi
    $deleted = $wpdb->delete(
        $table_name,
        ['invoice_id' => $invoice_id],
        ['%s']
    );

    if ($deleted === false) {
        error_log("Lỗi khi xóa invoice_id $invoice_id từ $table_name: " . $wpdb->last_error);
        return new WP_REST_Response(['success' => false, 'message' => 'Lỗi khi xóa thông báo: ' . $wpdb->last_error], 500);
    }

    error_log("Đã xóa thông báo đánh giá cho hóa đơn $invoice_id");
    return new WP_REST_Response(['success' => true, 'message' => 'Thông báo đánh giá đã được xóa thành công'], 200);
}

function checkin_mkt192_get_invoice_for_review_api(WP_REST_Request $request) {
    global $wpdb;
    $invoice_table  = $wpdb->prefix . 'checkin_mkt192_invoices_data';
    $customer_table = $wpdb->prefix . 'bookingmkt192_customer_data';
    $invoice_id     = $request->get_param('invoice_id');

    try {
        $query = $wpdb->prepare("SELECT invoice_id, booking_id, customer_id, customer_name, customer_phone, membership_label, promo_code, promo_name, promo_status, services, tips, discount, subtotal, total, message_status, message_type, created_at, status, branch_id
                                 FROM $invoice_table WHERE invoice_id = %s", $invoice_id);
        $invoice = $wpdb->get_row($query, ARRAY_A);

        if (!$invoice) {
            error_log("Hóa đơn $invoice_id không tồn tại");
            return new WP_REST_Response(['success' => false, 'message' => 'Hóa đơn không tồn tại'], 404);
        }

        // Lấy new_checkin từ bảng customer_data dựa trên customer_id
        if (!empty($invoice['customer_id'])) {
            $customer_query = $wpdb->prepare("SELECT new_checkin FROM $customer_table WHERE customer_id = %s", $invoice['customer_id']);
            $customer_data  = $wpdb->get_row($customer_query, ARRAY_A);
            if ($customer_data && !empty($customer_data['new_checkin'])) {
                $invoice['last_visit'] = $customer_data['new_checkin'];
            } else {
                $invoice['last_visit'] = null; // Nếu không có new_checkin, trả về null
                error_log("Không tìm thấy new_checkin cho customer_id {$invoice['customer_id']}");
            }
        } else {
            $invoice['last_visit'] = null;
            error_log("Hóa đơn $invoice_id không có customer_id");
        }

        // Giải mã services
        $services = json_decode($invoice['services'], true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            error_log("Lỗi giải mã JSON services cho hóa đơn $invoice_id: " . json_last_error_msg());
            $invoice['services'] = [];
        } else {
            $invoice['services'] = $services ?: [];
        }

        return new WP_REST_Response(['success' => true, 'data' => $invoice], 200);
    } catch (Exception $e) {
        error_log("Get invoice for review error for $invoice_id: " . $e->getMessage());
        return new WP_REST_Response(['success' => false, 'message' => 'Lỗi hệ thống: ' . $e->getMessage()], 500);
    }
}

/**
 * Get review detail for staff view (read-only mode)
 * Shows all review information with emotion selection but no editing allowed
 */
function checkin_mkt192_get_review_detail(WP_REST_Request $request) {
    global $wpdb;
    $invoice_id = $request->get_param('invoice_id');

    if (empty($invoice_id)) {
        return new WP_REST_Response(['success' => false, 'message' => 'Missing invoice_id'], 400);
    }

    $table_online  = $wpdb->prefix . 'checkin_mkt192_customer_reviews_online';
    $table_offline = $wpdb->prefix . 'checkin_mkt192_customer_reviews_off';
    $invoice_table = $wpdb->prefix . 'checkin_mkt192_invoices_data';

    // Get review first - check both online and offline
    $online_review = $wpdb->get_row($wpdb->prepare(
        "SELECT service_rating, staff_rating, feedback, customer_name, service_name, staff_name, created_at FROM $table_online WHERE invoice_id = %s",
        $invoice_id
    ), ARRAY_A);

    $offline_review = $wpdb->get_row($wpdb->prepare(
        "SELECT service_rating, staff_rating, feedback, customer_name, service_name, staff_name, created_at FROM $table_offline WHERE invoice_id = %s",
        $invoice_id
    ), ARRAY_A);

    // Use whichever review exists
    $review = $online_review ?: $offline_review;

    if (!$review) {
        return new WP_REST_Response(['success' => false, 'message' => 'Review not found'], 404);
    }

    // Get invoice info
    $invoice = $wpdb->get_row($wpdb->prepare(
        "SELECT invoice_id, customer_id, customer_name, customer_phone, services, tips, subtotal, total FROM $invoice_table WHERE invoice_id = %s",
        $invoice_id
    ), ARRAY_A);

    if (!$invoice) {
        return new WP_REST_Response(['success' => false, 'message' => 'Invoice not found'], 404);
    }

    // Parse services if needed
    if (!empty($invoice['services'])) {
        $invoice['services'] = json_decode($invoice['services'], true) ?: [];
    }

    // Parse feedback: split by "|" separator or split middle if no separator
    if (!empty($review['feedback'])) {
        // Check if feedback contains pipe separator for service and staff feedback
        if (strpos($review['feedback'], '|') !== false) {
            $parts                      = array_map('trim', explode('|', $review['feedback']));
            $review['service_feedback'] = $parts[0] ?? '';
            $review['staff_feedback']   = $parts[1] ?? '';

            // Remove label prefixes like "Hài lòng dịch vụ:" and "Hài lòng thợ:"
            // Use mb_substr and strpos for better Unicode support
            $service_prefix = 'Hài lòng dịch vụ:';
            $staff_prefix   = 'Hài lòng thợ:';

            if (strpos($review['service_feedback'], $service_prefix) === 0) {
                $review['service_feedback'] = trim(substr($review['service_feedback'], strlen($service_prefix)));
            }
            if (strpos($review['staff_feedback'], $staff_prefix) === 0) {
                $review['staff_feedback'] = trim(substr($review['staff_feedback'], strlen($staff_prefix)));
            }
        } else {
            // If no pipe separator, split by common delimiters and divide in half
            $feedback_parts = array_map('trim', preg_split('/[,;.]/', $review['feedback']));
            $feedback_parts = array_filter($feedback_parts); // Remove empty parts
            $mid            = ceil(count($feedback_parts) / 2);

            $review['service_feedback'] = implode('; ', array_slice($feedback_parts, 0, $mid));
            $review['staff_feedback']   = implode('; ', array_slice($feedback_parts, $mid));
        }
    }

    // Ensure feedback fields exist
    if (empty($review['service_feedback'])) {
        $review['service_feedback'] = '';
    }
    if (empty($review['staff_feedback'])) {
        $review['staff_feedback'] = '';
    }

    return new WP_REST_Response([
        'success' => true,
        'data'    => [
            'invoice'     => $invoice,
            'review'      => $review,
            'is_readonly' => true // Signal frontend this is read-only view
        ]
    ], 200);
}

function checkin_mkt192_get_reviews_by_invoice(WP_REST_Request $request) {
    global $wpdb;
    $invoice_id = $request->get_param('invoice_id');

    $table_online  = $wpdb->prefix . 'checkin_mkt192_customer_reviews_online';
    $table_offline = $wpdb->prefix . 'checkin_mkt192_customer_reviews_off';

    $online_review  = $wpdb->get_row($wpdb->prepare(
        "SELECT service_rating, staff_rating, feedback, created_at FROM $table_online WHERE invoice_id = %s",
        $invoice_id
    ), ARRAY_A);

    $offline_review = $wpdb->get_row($wpdb->prepare(
        "SELECT service_rating, staff_rating, feedback, created_at FROM $table_offline WHERE invoice_id = %s",
        $invoice_id
    ), ARRAY_A);

    return new WP_REST_Response([
        'success' => true,
        'data'    => [
            'online'  => $online_review  ?: null,
            'offline' => $offline_review ?: null
        ]
    ], 200);
}
