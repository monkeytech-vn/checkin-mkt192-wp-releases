<?php

// Load các dependencies trước
require_once(dirname(__FILE__, 2) . '/lark/send_inventory_check_notification.php');
require_once(dirname(__FILE__, 2) . '/lark/send_lark_inventory_notification.php');
require_once(dirname(__FILE__, 2) . '/lark/lark-utils.php');

add_action('rest_api_init', function () {
    // Endpoint để xử lý kiểm kê tồn kho (Create inventory check)
    register_rest_route('vg/v1', '/inventory-check', [
       'methods'             => 'POST',
       'callback'            => 'checkin_mkt192_inventory_check',
       'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'inventory.check'])
    ]);

    // List all inventory checks
    register_rest_route('vg/v1', '/inventory-checks', [
       'methods'             => 'GET',
       'callback'            => 'checkin_mkt192_get_inventory_checks',
       'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'inventory.read'])
    ]);

    // Get specific inventory check detail
    register_rest_route('vg/v1', '/inventory-checks/(?P<check_code>[a-zA-Z0-9\-]+)', [
       'methods'             => 'GET',
       'callback'            => 'checkin_mkt192_get_inventory_check_detail',
       'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'inventory.read'])
    ]);

    // Endpoint để xử lý xuất/nhập kho (Stock transaction)
    register_rest_route('vg/v1', '/stock-transaction', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_stock_transaction',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'inventory.transaction'])
    ]);

    // Upload inventory images
    register_rest_route('vg/v1', '/upload-image-inventory', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_upload_image_to_lark',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'inventory.update']),
        'args'                => [
            'image' => [
                'required' => false // Không require ở đây vì sẽ check trong function
            ]
        ]
    ]);

    // List all inventory transactions
    register_rest_route('vg/v1', '/inventory-transactions', [
        'methods'             => 'GET',
        'callback'            => 'checkin_mkt192_get_inventory_transactions',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'inventory.read'])
    ]);

    // Approve inventory transaction
    register_rest_route('vg/v1', '/inventory-transactions/(?P<transaction_id>[\w\-]+)/approve', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_approve_inventory_transaction',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'inventory.approve']),
        'args'                => [
            'transaction_id' => [
                'required'          => true,
                'type'              => 'string',
                'sanitize_callback' => 'sanitize_text_field',
                'validate_callback' => function($param) {
                    return !empty($param);
                }
            ]
        ]
    ]);

    // Get transaction detail AND Delete inventory transaction (same route, different methods)
    register_rest_route('vg/v1', '/inventory-transactions/(?P<transaction_id>[a-zA-Z0-9\-_]+)', [
        [
            'methods'             => 'GET',
            'callback'            => 'checkin_mkt192_get_inventory_transaction_detail',
            'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'inventory.read'])
        ],
        [
            'methods'             => 'DELETE',
            'callback'            => 'checkin_mkt192_delete_inventory_transaction',
            'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'inventory.delete']),
            'args'                => [
                'transaction_id' => [
                    'required'          => true,
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                ]
            ]
        ]
    ]);
});

function checkin_mkt192_inventory_check(WP_REST_Request $request) {
    $data      = json_decode($request->get_body(), true);
    $inventory = $data['inventory'] ?? [];

    // Kiểm tra dữ liệu đầu vào
    if (empty($inventory)) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Danh sách kiểm kê không hợp lệ'
        ], 400);
    }

    // Tạo unique key dựa trên user_id và timestamp (làm tròn đến 5 giây)
    $user_id       = get_current_user_id();
    $time_window   = floor(time() / 5) * 5; // Làm tròn xuống 5 giây
    $transient_key = "inventory_check_{$user_id}_{$time_window}";

    // Kiểm tra xem request này đã được xử lý chưa
    if (get_transient($transient_key)) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Yêu cầu đang được xử lý, vui lòng đợi...'
        ], 429); // Too Many Requests
    }

    // Đánh dấu request đang được xử lý (tồn tại trong 10 giây)
    set_transient($transient_key, true, 10);

    // Gọi hàm gửi thông báo kiểm kê nếu Lark được bật
    $notification_result = ['success' => true, 'message' => 'Lark disabled'];
    if (is_lark_enabled()) {
        $notification_result = send_inventory_check_notification($inventory, '');
    }

    // Xóa transient sau khi xử lý xong
    delete_transient($transient_key);

    if (!$notification_result['success']) {
        return new WP_REST_Response([
            'success' => false,
            'message' => $notification_result['message']
        ], 500);
    }

    return new WP_REST_Response([
        'success' => true,
        'message' => 'Cập nhật kiểm kê thành công'
    ], 200);
}

/**
 * Lấy danh sách phiếu kiểm kê (có phân trang).
 */
function checkin_mkt192_get_inventory_checks(WP_REST_Request $request) {
    global $wpdb;
    $table_checks = $wpdb->prefix . 'checkin_mkt192_inventory_checks';

    // Lấy tham số phân trang
    $page     = max(1, (int) $request->get_param('page'));
    $per_page = max(1, min(100, (int) $request->get_param('per_page') ?: 20));
    $offset   = ($page - 1) * $per_page;

    // Lấy tham số filter theo ngày
    $date_filter = sanitize_text_field($request->get_param('date') ?? '');
    $branch_id   = intval($request->get_param('branch_id') ?? 0);

    // ✅ CHỈ filter theo branch_id khi multi-branch mode được bật
    // Khi multi-branch disabled, hiển thị TẤT CẢ phiếu kiểm kê (không lọc theo branch)
    $is_multi_branch = function_exists('checkin_mkt192_is_multi_branch_enabled') && checkin_mkt192_is_multi_branch_enabled();
    if (!$is_multi_branch) {
        $branch_id = 0; // Không filter theo branch
    }

    // Build WHERE clause
    $where_clauses = [];
    $where_params  = [];

    if (!empty($date_filter)) {
        if ($date_filter === 'today') {
            $where_clauses[] = 'DATE(check_date) = CURDATE()';
        } else {
            // Assume format YYYY-MM-DD
            $where_clauses[] = 'DATE(check_date) = %s';
            $where_params[]  = $date_filter;
        }
    }

    if ($branch_id > 0) {
        $where_clauses[] = 'branch_id = %d';
        $where_params[]  = $branch_id;
    }

    $where_sql = !empty($where_clauses) ? 'WHERE ' . implode(' AND ', $where_clauses) : '';

    // Đếm tổng số records
    $count_query = "SELECT COUNT(*) FROM $table_checks $where_sql";
    if (!empty($where_params)) {
        $total = $wpdb->get_var($wpdb->prepare($count_query, ...$where_params));
    } else {
        $total = $wpdb->get_var($count_query);
    }

    // Lấy danh sách phiếu kiểm kê
    $select_query = "
        SELECT
            id,
            check_code,
            staff_name,
            check_date,
            total_products,
            mismatched_count,
            status,
            note,
            created_at
        FROM $table_checks
        $where_sql
        ORDER BY check_date DESC, created_at DESC
        LIMIT %d OFFSET %d
    ";

    $query_params = array_merge($where_params, [$per_page, $offset]);
    $checks       = $wpdb->get_results($wpdb->prepare($select_query, ...$query_params));

    return new WP_REST_Response([
        'success'    => true,
        'data'       => $checks,
        'pagination' => [
            'total'        => (int) $total,
            'per_page'     => $per_page,
            'current_page' => $page,
            'total_pages'  => ceil($total / $per_page)
        ]
    ], 200);
}

/**
 * Lấy chi tiết 1 phiếu kiểm kê theo check_code.
 */
function checkin_mkt192_get_inventory_check_detail(WP_REST_Request $request) {
    global $wpdb;
    $table_checks = $wpdb->prefix . 'checkin_mkt192_inventory_checks';
    $check_code   = sanitize_text_field($request->get_param('check_code'));

    if (empty($check_code)) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Mã phiếu kiểm kê không hợp lệ'
        ], 400);
    }

    // Lấy thông tin phiếu kiểm kê
    $check = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $table_checks WHERE check_code = %s",
        $check_code
    ));

    if (!$check) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Không tìm thấy phiếu kiểm kê'
        ], 404);
    }

    // Parse JSON data
    $check->inventory_data = json_decode($check->inventory_data, true);

    return new WP_REST_Response([
        'success' => true,
        'data'    => $check
    ], 200);
}

function checkin_mkt192_stock_transaction(WP_REST_Request $request) {
    global $wpdb;
    $data      = json_decode($request->get_body(), true);
    $type      = sanitize_text_field($data['type'] ?? '');
    $products  = $data['products'] ?? [];
    $reason    = sanitize_text_field($data['reason'] ?? '');
    $image_key = sanitize_text_field($data['image_key'] ?? ''); // Lark image key (cho notification)
    $image_url = sanitize_text_field($data['image_url'] ?? ''); // WordPress URL (cho hiển thị)
    $branch_id = intval($data['branch_id'] ?? 0);

    // ✅ CHỈ lưu branch_id khi multi-branch mode được bật
    // Khi multi-branch disabled, tất cả transaction có branch_id = 0
    $is_multi_branch = function_exists('checkin_mkt192_is_multi_branch_enabled') && checkin_mkt192_is_multi_branch_enabled();
    if (!$is_multi_branch) {
        $branch_id = 0;
    }

    // Log dữ liệu nhận được
    log_inventory_transaction('📥 REQUEST', [
        'type'            => $type,
        'products'        => $products,
        'reason'          => $reason,
        'branch_id'       => $branch_id,
        'is_multi_branch' => $is_multi_branch,
        'image_key'       => $image_key,
        'image_url'       => $image_url
    ]);

    // Kiểm tra dữ liệu đầu vào
    if (!in_array($type, ['in', 'out']) || empty($products)) {
        log_inventory_transaction('❌ FAILED - Invalid data', [
            'error' => 'Type hoặc products không hợp lệ'
        ]);
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Dữ liệu không hợp lệ'
        ], 400);
    }

    // ✅ CẬP NHẬT STOCK VÀO DATABASE
    $table_products     = $wpdb->prefix . 'checkin_mkt192_products';
    $table_transactions = $wpdb->prefix . 'checkin_mkt192_inventory_transactions';
    $updated_count      = 0;
    $errors             = [];
    $skipped            = [];

    // Lấy thông tin staff
    $current_user = wp_get_current_user();
    $staff_name   = $current_user->display_name ?: 'Unknown';

    // Tạo transaction_id unique
    $transaction_id = strtoupper($type) . '-' . date('YmdHis') . '-' . substr(uniqid(), -4);

    foreach ($products as $index => $product) {
        // ✅ Hỗ trợ cả 'id' và 'product_id' từ frontend
        $product_id = sanitize_text_field($product['id'] ?? $product['product_id'] ?? '');
        $quantity   = intval($product['quantity'] ?? 0);

        if (empty($product_id)) {
            $skipped[] = "Sản phẩm #{$index}: Thiếu ID";
            continue;
        }

        if ($quantity <= 0) {
            $skipped[] = "Sản phẩm {$product_id}: Số lượng không hợp lệ ({$quantity})";
            continue;
        }

        // Lấy thông tin sản phẩm hiện tại
        $current_product = $wpdb->get_row($wpdb->prepare(
            "SELECT id, product_name, stock, branch_id FROM $table_products WHERE id = %s",
            $product_id
        ));

        if (!$current_product) {
            $errors[] = "Sản phẩm {$product_id} không tồn tại trong DB";
            continue;
        }

        // Kiểm tra branch_id (nếu có)
        if ($branch_id > 0 && $current_product->branch_id > 0 && $current_product->branch_id != $branch_id) {
            $errors[] = "Sản phẩm {$product_id} không thuộc chi nhánh này";
            continue;
        }

        // ✅ KHÔNG cập nhật stock ngay khi tạo phiếu, chỉ lưu transaction với status 'CHỜ DUYỆT'
        // Stock sẽ được cập nhật khi duyệt phiếu (approve)

        // ✅ LƯU TRANSACTION VÀO BẢNG inventory_transactions
        // image_key: Lark key cho notification, image_url: WordPress URL cho hiển thị
        $result = $wpdb->insert(
            $table_transactions,
            [
                'product_id'       => $product_id,
                'product_name'     => $current_product->product_name,
                'transaction_type' => strtoupper($type),
                'quantity'         => $quantity,
                'transaction_date' => current_time('mysql'),
                'note'             => $reason,
                'staff_name'       => $staff_name,
                'image_key'        => $image_key,
                'image_url'        => $image_url,
                'transaction_id'   => $transaction_id,
                'status'           => 'CHỜ DUYỆT',
                'branch_id'        => $branch_id
            ],
            ['%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d']
        );

        if ($result !== false) {
            $updated_count++;
        } else {
            $errors[] = "Lỗi lưu phiếu {$product_id}: " . $wpdb->last_error;
        }
    }

    // Log kết quả xuất nhập kho
    if ($updated_count > 0) {
        log_inventory_transaction('✅ ' . strtoupper($type), [
            'id'      => $transaction_id,
            'updated' => $updated_count . '/' . count($products)
        ]);
    } else {
        log_inventory_transaction('❌ FAILED', [
            'type'   => $type,
            'errors' => $errors
        ]);
    }

    // ✅ GỬI THÔNG BÁO SAU KHI TẠO PHIẾU (CHỜ DUYỆT)
    if ($updated_count > 0) {
        // Gửi push notification đến Quản lý
        if (function_exists('checkin_push_notify_inventory_pending')) {
            checkin_push_notify_inventory_pending([
                'transaction_id' => $transaction_id,
                'type'           => $type,
                'staff_name'     => $staff_name,
                'product_count'  => $updated_count,
                'branch_id'      => $branch_id
            ]);
        }

        // Kiểm tra nếu Lark enabled thì gửi Lark, ngược lại gửi Zalo webhook
        if (is_lark_enabled()) {
            // Gửi thông báo Lark (chỉ gửi notification, không insert DB)
            $notification_result = send_lark_inventory_notification($transaction_id, $data, $type, $image_key, $staff_name);

            // Log kết quả gửi notification
            if (is_array($notification_result) && isset($notification_result['success']) && $notification_result['success']) {
                log_inventory_transaction('✅ LARK OK', ['id' => $transaction_id]);
            } else {
                $error_msg = is_array($notification_result) ? ($notification_result['message'] ?? 'Unknown error') : 'Failed to send';
                log_inventory_transaction('❌ LARK FAILED', [
                    'id'    => $transaction_id,
                    'error' => $error_msg
                ]);
            }
        } else {
            // Gửi Zalo webhook notification
            send_inventory_transaction_webhook_notification($transaction_id, 'CHỜ DUYỆT');
        }
    }

    return new WP_REST_Response([
        'success'         => true,
        'message'         => "Đã tạo phiếu thành công với {$updated_count}/" . count($products) . ' sản phẩm. Chờ duyệt để cập nhật tồn kho.',
        'transaction_id'  => $transaction_id,
        'open_message_id' => '',
        'updated_count'   => $updated_count,
        'errors'          => $errors
    ], 200);
}

/**
 * Lấy danh sách phiếu xuất/nhập kho
 */
function checkin_mkt192_get_inventory_transactions(WP_REST_Request $request) {
    global $wpdb;
    $table_transactions = $wpdb->prefix . 'checkin_mkt192_inventory_transactions';

    $page      = max(1, (int) $request->get_param('page') ?: 1);
    $per_page  = max(1, min(100, (int) $request->get_param('per_page') ?: 20));
    $offset    = ($page - 1) * $per_page;
    $status    = $request->get_param('status'); // CHỜ DUYỆT, HOÀN THÀNH, TỪ CHỐI
    $branch_id = intval($request->get_param('branch_id') ?? 0);

    // ✅ CHỈ filter theo branch_id khi multi-branch mode được bật
    // Khi multi-branch disabled, hiển thị TẤT CẢ phiếu xuất/nhập (không lọc theo branch)
    $is_multi_branch = function_exists('checkin_mkt192_is_multi_branch_enabled') && checkin_mkt192_is_multi_branch_enabled();
    if (!$is_multi_branch) {
        $branch_id = 0; // Không filter theo branch
    }

    // ✅ Chỉ lấy records có transaction_id (loại bỏ NULL)
    $where = 'transaction_id IS NOT NULL';
    if ($status) {
        $where .= $wpdb->prepare(' AND status = %s', $status);
    }
    if ($branch_id > 0) {
        $where .= $wpdb->prepare(' AND branch_id = %d', $branch_id);
    }

    log_inventory_transaction('📋 GET transactions', [
        'page'            => $page,
        'per_page'        => $per_page,
        'status'          => $status,
        'branch_id'       => $branch_id,
        'is_multi_branch' => $is_multi_branch,
        'where'           => $where
    ]);

    // Đếm tổng
    $total = $wpdb->get_var("SELECT COUNT(DISTINCT transaction_id) FROM $table_transactions WHERE $where");

    log_inventory_transaction('📊 Count result', ['total' => $total]);

    // Lấy danh sách gom theo transaction_id
    $query = $wpdb->prepare("
        SELECT
            transaction_id,
            MIN(id) as id,
            MAX(transaction_type) as transaction_type,
            MAX(transaction_date) as transaction_date,
            MAX(staff_name) as staff_name,
            MAX(status) as status,
            MAX(note) as note,
            MAX(image_key) as image_key,
            MAX(image_url) as image_url,
            MAX(branch_id) as branch_id,
            COUNT(*) as product_count,
            SUM(quantity) as total_quantity,
            GROUP_CONCAT(product_name SEPARATOR ', ') as products
        FROM $table_transactions
        WHERE $where
        GROUP BY transaction_id
        ORDER BY transaction_date DESC
        LIMIT %d OFFSET %d
    ", $per_page, $offset);

    log_inventory_transaction('🔍 Query', ['sql' => $query]);

    $transactions = $wpdb->get_results($query);

    if ($wpdb->last_error) {
        log_inventory_transaction('❌ Query error', ['error' => $wpdb->last_error]);
    }

    log_inventory_transaction('✅ Query result', [
        'count' => count($transactions),
        'first' => $transactions[0] ?? null
    ]);

    return new WP_REST_Response([
        'success'    => true,
        'data'       => $transactions,
        'pagination' => [
            'total'        => (int) $total,
            'per_page'     => $per_page,
            'current_page' => $page,
            'total_pages'  => ceil($total / $per_page)
        ]
    ], 200);
}

/**
 * Lấy chi tiết phiếu xuất/nhập kho
 */
function checkin_mkt192_get_inventory_transaction_detail(WP_REST_Request $request) {
    global $wpdb;
    $table_transactions = $wpdb->prefix . 'checkin_mkt192_inventory_transactions';
    $transaction_id     = sanitize_text_field($request->get_param('transaction_id'));

    log_inventory_transaction('🔍 Get transaction detail', [
        'transaction_id' => $transaction_id,
        'raw_param'      => $request->get_param('transaction_id')
    ]);

    $items = $wpdb->get_results($wpdb->prepare("
        SELECT * FROM $table_transactions WHERE transaction_id = %s
    ", $transaction_id));

    log_inventory_transaction('📦 Query result', [
        'items_count' => count($items),
        'sql_error'   => $wpdb->last_error
    ]);

    if (empty($items)) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Không tìm thấy phiếu'
        ], 404);
    }

    return new WP_REST_Response([
        'success' => true,
        'data'    => [
            'transaction_id'   => $transaction_id,
            'transaction_type' => $items[0]->transaction_type,
            'transaction_date' => $items[0]->transaction_date,
            'staff_name'       => $items[0]->staff_name,
            'status'           => $items[0]->status,
            'note'             => $items[0]->note,
            'image_key'        => $items[0]->image_key,
            'image_url'        => $items[0]->image_url,
            'items'            => $items
        ]
    ], 200);
}

/**
 * Duyệt phiếu xuất/nhập kho
 */
function checkin_mkt192_approve_inventory_transaction(WP_REST_Request $request) {
    global $wpdb;
    $table_transactions = $wpdb->prefix . 'checkin_mkt192_inventory_transactions';
    $table_products     = $wpdb->prefix . 'checkin_mkt192_products';
    $transaction_id     = sanitize_text_field($request->get_param('transaction_id'));

    log_inventory_transaction('🔍 Approve request', [
        'transaction_id' => $transaction_id,
        'user_id'        => get_current_user_id(),
        'request_uri'    => $_SERVER['REQUEST_URI'] ?? ''
    ]);

    // Lấy thông tin các sản phẩm trong phiếu
    $items = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM $table_transactions WHERE transaction_id = %s AND status = 'CHỜ DUYỆT'",
        $transaction_id
    ));

    if (empty($items)) {
        log_inventory_transaction('❌ Approve failed', ['error' => 'Phiếu không tồn tại hoặc đã được duyệt']);
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Phiếu không tồn tại hoặc đã được duyệt'
        ], 404);
    }

    $wpdb->query('START TRANSACTION');

    try {
        // ✅ CẬP NHẬT STOCK CHO TỪNG SẢN PHẨM KHI DUYỆT
        foreach ($items as $item) {
            $product_id       = $item->product_id;
            $quantity         = intval($item->quantity);
            $transaction_type = $item->transaction_type;

            // Lấy stock hiện tại
            $current_product = $wpdb->get_row($wpdb->prepare(
                "SELECT id, stock FROM $table_products WHERE id = %s",
                $product_id
            ));

            if (!$current_product) {
                throw new Exception("Sản phẩm {$product_id} không tồn tại");
            }

            $current_stock = intval($current_product->stock);

            // Tính stock mới
            if ($transaction_type === 'IN') {
                $new_stock = $current_stock + $quantity;
            } else { // 'OUT'
                $new_stock = max(0, $current_stock - $quantity);
            }

            // Update stock
            $stock_result = $wpdb->update(
                $table_products,
                ['stock' => $new_stock, 'updated_at' => current_time('mysql')],
                ['id'    => $product_id],
                ['%d', '%s'],
                ['%s']
            );

            if ($stock_result === false) {
                throw new Exception("Lỗi cập nhật stock cho {$product_id}: " . $wpdb->last_error);
            }
        }

        // Update status thành HOÀN THÀNH
        $result = $wpdb->update(
            $table_transactions,
            ['status'         => 'HOÀN THÀNH'],
            ['transaction_id' => $transaction_id],
            ['%s'],
            ['%s']
        );

        if ($result === false) {
            throw new Exception('Lỗi khi cập nhật status: ' . $wpdb->last_error);
        }

        $wpdb->query('COMMIT');

        log_inventory_transaction('✅ Approve success', ['affected_rows' => $result, 'items_count' => count($items)]);

        // ✅ GỬI THÔNG BÁO SAU KHI DUYỆT
        // Lấy thông tin người duyệt
        $approver      = wp_get_current_user();
        $approved_by   = $approver->display_name ?: 'Quản lý';
        $first_item    = $items[0];
        $staff_name    = $first_item->staff_name ?? '';

        // Tìm user_id của người tạo phiếu từ staff_name
        $staff_user_id = null;
        if (!empty($staff_name)) {
            $staff_table   = $wpdb->prefix . 'checkin_mkt192_staff';
            $staff         = $wpdb->get_row($wpdb->prepare(
                "SELECT user_id FROM $staff_table WHERE display_name = %s",
                $staff_name
            ));
            $staff_user_id = $staff ? $staff->user_id : null;
        }

        // Gửi push notification đến Thu Ngân và người tạo phiếu
        if (function_exists('checkin_push_notify_inventory_approved')) {
            checkin_push_notify_inventory_approved([
                'transaction_id' => $transaction_id,
                'type'           => $first_item->transaction_type,
                'staff_name'     => $staff_name,
                'staff_user_id'  => $staff_user_id,
                'approved_by'    => $approved_by,
                'product_count'  => count($items),
                'branch_id'      => $first_item->branch_id ?? null
            ]);
        }

        // Gửi Zalo webhook notification
        send_inventory_transaction_webhook_notification($transaction_id, 'HOÀN THÀNH');

        return new WP_REST_Response([
            'success' => true,
            'message' => 'Duyệt phiếu thành công'
        ], 200);

    } catch (Exception $e) {
        $wpdb->query('ROLLBACK');
        log_inventory_transaction('❌ Approve failed', ['error' => $e->getMessage()]);
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Lỗi khi duyệt phiếu: ' . $e->getMessage()
        ], 500);
    }
}

/**
 * Xóa phiếu xuất/nhập kho
 */
function checkin_mkt192_delete_inventory_transaction(WP_REST_Request $request) {
    global $wpdb;
    $table_transactions = $wpdb->prefix . 'checkin_mkt192_inventory_transactions';
    $table_products     = $wpdb->prefix . 'checkin_mkt192_products';
    $transaction_id     = sanitize_text_field($request->get_param('transaction_id'));

    log_inventory_transaction('🗑️ Delete request', [
        'transaction_id' => $transaction_id,
        'user_id'        => get_current_user_id()
    ]);

    // Lấy thông tin phiếu trước khi xóa
    $items = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM $table_transactions WHERE transaction_id = %s",
        $transaction_id
    ));

    if (empty($items)) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Không tìm thấy phiếu'
        ], 404);
    }

    $first_item = $items[0];

    // Nếu phiếu đã HOÀN THÀNH, cần hoàn trả stock
    if ($first_item->status === 'HOÀN THÀNH') {
        $wpdb->query('START TRANSACTION');

        try {
            foreach ($items as $item) {
                $product_id       = intval($item->product_id);
                $quantity         = intval($item->quantity);
                $transaction_type = $item->transaction_type;

                // Hoàn trả stock (ngược lại với transaction_type)
                if ($transaction_type === 'IN') {
                    // Phiếu nhập đã thêm stock -> giờ trừ đi
                    $wpdb->query($wpdb->prepare(
                        "UPDATE $table_products SET stock = stock - %d WHERE id = %d",
                        $quantity,
                        $product_id
                    ));
                } else {
                    // Phiếu xuất đã trừ stock -> giờ cộng lại
                    $wpdb->query($wpdb->prepare(
                        "UPDATE $table_products SET stock = stock + %d WHERE id = %d",
                        $quantity,
                        $product_id
                    ));
                }
            }

            // Xóa các records
            $deleted = $wpdb->delete(
                $table_transactions,
                ['transaction_id' => $transaction_id],
                ['%s']
            );

            $wpdb->query('COMMIT');

            log_inventory_transaction('✅ Delete success (with stock restore)', [
                'transaction_id' => $transaction_id,
                'deleted_rows'   => $deleted,
                'items_count'    => count($items)
            ]);
        } catch (Exception $e) {
            $wpdb->query('ROLLBACK');
            log_inventory_transaction('❌ Delete failed', ['error' => $e->getMessage()]);
            return new WP_REST_Response([
                'success' => false,
                'message' => 'Lỗi khi xóa phiếu: ' . $e->getMessage()
            ], 500);
        }
    } else {
        // Phiếu chưa duyệt -> chỉ cần xóa records
        $deleted = $wpdb->delete(
            $table_transactions,
            ['transaction_id' => $transaction_id],
            ['%s']
        );

        if ($deleted === false) {
            log_inventory_transaction('❌ Delete failed', ['error' => $wpdb->last_error]);
            return new WP_REST_Response([
                'success' => false,
                'message' => 'Lỗi khi xóa phiếu: ' . $wpdb->last_error
            ], 500);
        }

        log_inventory_transaction('✅ Delete success', [
            'transaction_id' => $transaction_id,
            'deleted_rows'   => $deleted
        ]);
    }

    return new WP_REST_Response([
        'success' => true,
        'message' => 'Xóa phiếu thành công'
    ], 200);
}

// Hàm ghi log inventory transaction (ngắn gọn)
function log_inventory_transaction($message, $data = []) {
    $log_dir = __DIR__ . '/logs';
    if (!file_exists($log_dir)) {
        mkdir($log_dir, 0755, true);
    }

    $log_file  = $log_dir . '/inventory_transaction.log';
    $timestamp = date('Y-m-d H:i:s');
    $log_entry = "[$timestamp] $message";
    if (!empty($data)) {
        $log_entry .= ' ' . json_encode($data, JSON_UNESCAPED_UNICODE);
    }
    $log_entry .= "\n";
    file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);
}

/**
 * Gửi webhook notification cho phiếu xuất/nhập kho
 */
function send_inventory_transaction_webhook_notification($transaction_id, $status = 'CHỜ DUYỆT') {
    global $wpdb;
    $table_transactions = $wpdb->prefix . 'checkin_mkt192_inventory_transactions';

    // Lấy thông tin phiếu và các sản phẩm
    $items = $wpdb->get_results($wpdb->prepare("
        SELECT * FROM $table_transactions WHERE transaction_id = %s
    ", $transaction_id));

    if (empty($items)) {
        log_inventory_transaction('⚠️ Webhook: Transaction not found', ['transaction_id' => $transaction_id]);
        return;
    }

    $first_item   = $items[0];
    $current_user = wp_get_current_user();

    // Lấy staff_id từ user meta (Zalo UID)
    $staff_zalo_id = get_user_meta($current_user->ID, 'zalo_uid', true);

    // Lấy branch_id từ transaction (việc xuất/nhập đã lưu branch_id)
    $branch_id = intval($first_item->branch_id ?? 0);

    // Nếu không có branch_id trong transaction, fallback sang user meta
    if ($branch_id == 0) {
        $branch_id = get_user_meta($current_user->ID, 'branch_id', true);
    }

    // Query branch_name từ bảng locations (branch_id là ID của location, không phải post)
    $table_locations = $wpdb->prefix . 'checkin_mkt192_locations';
    $branch_name     = 'Tất cả';

    if ($branch_id > 0) {
        $location = $wpdb->get_row($wpdb->prepare(
            "SELECT location_name FROM $table_locations WHERE id = %d LIMIT 1",
            $branch_id
        ));

        if ($location && !empty($location->location_name)) {
            $branch_name = $location->location_name;
        }
    }

    // Chuẩn bị items data - KHÔNG GỬI unit
    $items_data = array_map(function($item) {
        return [
            'product_name' => $item->product_name,
            'quantity'     => (int)$item->quantity
        ];
    }, $items);

    // ✅ Lấy image_url từ image_key (nếu có)
    $image_url = '';
    if (!empty($first_item->image_key)) {
        // Kiểm tra xem image_key có phải URL không (format mới)
        if (filter_var($first_item->image_key, FILTER_VALIDATE_URL)) {
            $image_url = $first_item->image_key;
        } else {
            // Format cũ: lưu JSON array URLs
            $image_keys = json_decode($first_item->image_key, true);
            if (is_array($image_keys) && !empty($image_keys[0])) {
                $image_url = $image_keys[0];
            }
        }

        // Đổi 127.0.0.1 thành hostname 'wordpress' để n8n container có thể access
        $image_url = str_replace('127.0.0.1:18080', 'wordpress:18080', $image_url);
    }

    // Chuẩn bị payload cho n8n
    $payload = [
        'transaction' => [
            'transaction_id'   => $transaction_id,
            'transaction_type' => $first_item->transaction_type,
            'transaction_date' => $first_item->transaction_date,
            'staff_name'       => $first_item->staff_name,
            'staff_id'         => $staff_zalo_id,
            'status'           => $status,
            'branch_name'      => $branch_name,
            'note'             => $first_item->note,
            'image_url'        => $image_url,
            'items'            => $items_data
        ],
        'app_url' => home_url('/app-tho?view=inventory&tab=transactions')
    ];

    // Lấy webhook URL từ settings (option checkin_zalo_user_domain)
    $zalo_user_domain = get_option('checkin_zalo_user_domain', '');
    $webhook_url      = '';

    if (!empty($zalo_user_domain)) {
        $webhook_url = rtrim($zalo_user_domain, '/') . '/webhook/n8n-inventory-transaction-notification';
    } elseif (defined('N8N_INVENTORY_WEBHOOK_URL')) {
        $webhook_url = N8N_INVENTORY_WEBHOOK_URL;
    }

    if (empty($webhook_url)) {
        log_inventory_transaction('⚠️ Webhook: URL not configured', [
            'checkin_zalo_user_domain'  => $zalo_user_domain,
            'N8N_INVENTORY_WEBHOOK_URL' => defined('N8N_INVENTORY_WEBHOOK_URL') ? N8N_INVENTORY_WEBHOOK_URL : 'not defined'
        ]);
        return;
    }

    log_inventory_transaction('📤 Sending webhook notification', [
        'webhook_url'    => $webhook_url,
        'transaction_id' => $transaction_id,
        'status'         => $status
    ]);

    // Gửi webhook async
    wp_remote_post($webhook_url, [
        'body'     => json_encode($payload),
        'headers'  => ['Content-Type' => 'application/json'],
        'timeout'  => 10,
        'blocking' => false // Async
    ]);

    log_inventory_transaction('✅ Webhook notification queued', ['transaction_id' => $transaction_id]);
}

// Hàm upload hình ảnh (lưu vào WordPress uploads và Lark nếu cần)
function checkin_mkt192_upload_image_to_lark(WP_REST_Request $request) {
    $params = $request->get_json_params();

    log_upload_image('📥 Upload request received', [
        'has_image_data' => !empty($params['image_data']),
        'has_filename'   => !empty($params['filename']),
        'params_keys'    => array_keys($params)
    ]);

    // Nhận file từ base64
    if (empty($params['image_data']) || empty($params['filename'])) {
        log_upload_image('❌ Thiếu dữ liệu ảnh hoặc tên file');
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Vui lòng cung cấp file hình ảnh'
        ], 400);
    }

    $image_data = $params['image_data'];
    $filename   = sanitize_file_name($params['filename']);

    // Decode base64
    if (preg_match('/^data:image\/(\w+);base64,/', $image_data, $matches)) {
        $image_extension = $matches[1];
        $image_data      = substr($image_data, strpos($image_data, ',') + 1);
    } else {
        $image_extension = pathinfo($filename, PATHINFO_EXTENSION);
    }

    $image_data = base64_decode($image_data);

    if ($image_data === false) {
        log_upload_image('❌ Lỗi decode base64');
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Dữ liệu ảnh không hợp lệ'
        ], 400);
    }

    // Validate extension
    $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
    if (!in_array(strtolower($image_extension), $allowed_extensions)) {
        log_upload_image('Định dạng file không hỗ trợ', ['extension' => $image_extension]);
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Định dạng file không hỗ trợ. Chỉ chấp nhận JPG, PNG, GIF, WEBP'
        ], 400);
    }

    // ✅ 1. LƯU ẢNH VÀO WORDPRESS UPLOADS
    $upload_dir  = wp_upload_dir();
    $upload_path = $upload_dir['path'] . '/' . wp_unique_filename($upload_dir['path'], $filename);
    $upload_url  = $upload_dir['url'] . '/' . basename($upload_path);

    if (!file_put_contents($upload_path, $image_data)) {
        log_upload_image('❌ Lỗi lưu file', ['path' => $upload_path]);
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Lỗi lưu ảnh vào server'
        ], 500);
    }

    $image_url  = $upload_url;
    $image_path = $upload_path;

    log_upload_image('✅ Đã lưu ảnh vào WordPress uploads', [
        'url'  => $image_url,
        'path' => $image_path
    ]);

    // ✅ 2. UPLOAD LÊN LARK NẾU CÓ LARK ENABLED
    $lark_img_key = '';

    require_once __DIR__ . '/../lark/lark-utils.php';
    if (is_lark_enabled()) {
        require_once __DIR__ . '/../lark/class-checkin-mkt192-message-bot-manager.php';
        $bot_manager = Checkin_MKT192_Message_Bot_Manager::get_instance();
        $bot         = $bot_manager->get_bot_by_notification_type('inventory');

        if ($bot && $bot->bot_type === 'interactive') {
            $app_id     = $bot->app_id;
            $app_secret = $bot->app_secret;
            $token      = get_lark_tenant_access_token($app_id, $app_secret);

            if (!is_wp_error($token)) {
                // Chuẩn bị dữ liệu form-data cho Lark
                $boundary = '----WebKitFormBoundary' . wp_generate_password(16, false);
                $body     = [];
                $body[]   = "--$boundary";
                $body[]   = 'Content-Disposition: form-data; name="image_type"';
                $body[]   = '';
                $body[]   = 'message';
                $body[]   = "--$boundary";
                $body[]   = 'Content-Disposition: form-data; name="image"; filename="' . basename($image_path) . '"';
                $body[]   = 'Content-Type: image/' . $image_extension;
                $body[]   = '';
                $body[]   = file_get_contents($image_path);
                $body[]   = "--$boundary--";
                $body     = implode("\r\n", $body);

                $response = wp_remote_post('https://open.larksuite.com/open-apis/im/v1/images', [
                    'method'  => 'POST',
                    'headers' => [
                        'Authorization' => "Bearer $token",
                        'Content-Type'  => "multipart/form-data; boundary=$boundary"
                    ],
                    'body'    => $body,
                    'timeout' => 30
                ]);

                if (!is_wp_error($response)) {
                    $response_body = json_decode(wp_remote_retrieve_body($response), true);
                    if (isset($response_body['data']['image_key'])) {
                        $lark_img_key = $response_body['data']['image_key'];
                        log_upload_image('✅ Đã upload lên Lark', ['img_key' => $lark_img_key]);
                    }
                }
            }
        }
    }

    // ✅ 3. TRẢ VỀ CẢ URL VÀ IMG_KEY
    return new WP_REST_Response([
        'success'   => true,
        'image_url' => $image_url,
        'img_key'   => $lark_img_key,
        'message'   => 'Upload hình ảnh thành công'
    ], 200);
}

// Hàm ghi log
function log_upload_image($message, $data = []) {
    $log_dir = __DIR__ . '/logs';
    if (!file_exists($log_dir)) {
        mkdir($log_dir, 0755, true);
    }

    $log_file  = $log_dir . '/image_inventory_upload_log.log';
    $timestamp = date('Y-m-d H:i:s');
    $log_entry = "[$timestamp] $message\n";
    if (!empty($data)) {
        $log_entry .= 'Data: ' . json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
    }
    $log_entry .= "----------------------------------------\n";
    file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);
}
