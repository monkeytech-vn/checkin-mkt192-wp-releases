<?php

/**
 * Debug Current User Permissions
 *
 * Usage: POST /wp-json/vg/v1/debug/current-user-permissions
 * Returns detailed info about logged-in user's role and permissions
 */

add_action('rest_api_init', function () {
    register_rest_route('vg/v1/debug', '/current-user-permissions', [
        'methods'             => 'GET',
        'callback'            => 'checkin_mkt192_debug_current_user_permissions',
        'permission_callback' => function() {
            // Only allow admins to access debug endpoints
            return current_user_can('manage_options');
        }
    ]);
});

function checkin_mkt192_debug_current_user_permissions(WP_REST_Request $request) {
    global $wpdb;

    // Get current user ID - this works with WordPress cookies in REST API
    $user_id = get_current_user_id();

    // Debug info
    $debug_info = [
        'get_current_user_id'        => $user_id,
        'is_user_logged_in'          => is_user_logged_in(),
        'wp_get_current_user_id'     => wp_get_current_user() ? wp_get_current_user()->ID : null,
        'cookies_present'            => !empty($_COOKIE),
        'wordpress_logged_in_cookie' => isset($_COOKIE['wordpress_logged_in_' . COOKIEHASH])
    ];

    if (!$user_id) {
        return new WP_REST_Response([
            'error'    => 'No user logged in',
            'user_id'  => null,
            'debug'    => $debug_info,
            'solution' => 'This endpoint must be called from the same browser where you are logged into WordPress admin. Open browser console in the WordPress admin page and run the fetch command there.'
        ], 401);
    }

    // Get staff info
    $staff_table = $wpdb->prefix . 'checkin_mkt192_staff';
    $staff       = $wpdb->get_row($wpdb->prepare(
        "SELECT id, name, email, role_id FROM {$staff_table} WHERE user_id = %d",
        $user_id
    ));

    if (!$staff) {
        return new WP_REST_Response([
            'error'      => 'Staff record not found',
            'user_id'    => $user_id,
            'suggestion' => 'This WordPress user is not linked to any staff record'
        ], 404);
    }

    // Get role info
    $role_table = $wpdb->prefix . 'checkin_mkt192_staff_roles';
    $role       = $wpdb->get_row($wpdb->prepare(
        "SELECT id, role_name, permissions, access_permissions FROM {$role_table} WHERE id = %d",
        $staff->role_id
    ));

    if (!$role) {
        return new WP_REST_Response([
            'error'      => 'Role not found',
            'user_id'    => $user_id,
            'staff_id'   => $staff->id,
            'role_id'    => $staff->role_id,
            'suggestion' => 'Staff has invalid role_id. Assign a valid role to this staff.'
        ], 404);
    }

    // Parse permissions
    $permissions        = json_decode($role->permissions, true);
    $access_permissions = json_decode($role->access_permissions, true);

    // Count permissions
    $module_count = count($permissions);
    $action_count = 0;
    foreach ($permissions as $module => $actions) {
        $action_count += count($actions);
    }

    // Get all available roles
    $all_roles = $wpdb->get_results(
        "SELECT id, role_name, JSON_LENGTH(permissions) as module_count FROM {$role_table} ORDER BY id"
    );

    return new WP_REST_Response([
        'user' => [
            'id'             => $user_id,
            'wordpress_user' => wp_get_current_user()->user_login
        ],
        'staff' => [
            'id'      => $staff->id,
            'name'    => $staff->name,
            'email'   => $staff->email,
            'role_id' => $staff->role_id
        ],
        'current_role' => [
            'id'                 => $role->id,
            'name'               => $role->role_name,
            'module_count'       => $module_count,
            'action_count'       => $action_count,
            'modules'            => array_keys($permissions),
            'access_permissions' => $access_permissions,
            'full_permissions'   => $permissions
        ],
        'available_roles' => $all_roles,
        'suggestions'     => [
            'if_403_errors' => 'Current role does not have required permissions',
            'fix_1'         => 'Update staff.role_id to a role with more permissions',
            'fix_2'         => "Update current role (ID: {$role->id}) to have required permissions",
            'fix_3'         => "Run: UPDATE wp_checkin_mkt192_staff SET role_id = ADMIN_ROLE_ID WHERE id = {$staff->id}"
        ]
    ], 200);
}
