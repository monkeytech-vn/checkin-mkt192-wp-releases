<?php

add_action('rest_api_init', function () {
    // Endpoint cho vai trò
    register_rest_route('vg/v1', '/roles', [
        'methods'             => 'GET',
        'callback'            => 'checkin_mkt192_get_roles_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'role.read'])
    ]);
    register_rest_route('vg/v1', '/roles', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_save_role_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'role.create'])
    ]);
    register_rest_route('vg/v1', '/roles/(?P<id>[0-9]+)', [
        'methods'             => 'PUT',
        'callback'            => 'checkin_mkt192_save_role_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'role.update'])
    ]);
    register_rest_route('vg/v1', '/roles/(?P<id>[0-9]+)', [
        'methods'             => 'DELETE',
        'callback'            => 'checkin_mkt192_delete_role_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'role.delete'])
    ]);
});

function checkin_mkt192_get_roles_api(WP_REST_Request $request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'checkin_mkt192_staff_roles';
    $logFile    = __DIR__ . '/logs/api_errors.log';

    try {
        $roles = $wpdb->get_results("SELECT id, role_name, description, is_active, access_permissions, permissions FROM $table_name ORDER BY role_name ASC", OBJECT);

        // Decode JSON fields
        foreach ($roles as $role) {
            if ($role->permissions) {
                $role->permissions = json_decode($role->permissions, true);
            } else {
                $role->permissions = [];
            }
            if ($role->access_permissions) {
                $role->access_permissions = json_decode($role->access_permissions, true);
            } else {
                $role->access_permissions = [];
            }
            $role->is_active = (bool) $role->is_active;
        }

        if ($wpdb->last_error) {
            file_put_contents($logFile, date('Y-m-d H:i:s') . ' - Failed to fetch roles: ' . $wpdb->last_error . "\n", FILE_APPEND);
            return new WP_REST_Response(['success' => false, 'message' => 'Lỗi hệ thống'], 500);
        }

        return new WP_REST_Response(['success' => true, 'data' => $roles], 200);
    } catch (Exception $e) {
        file_put_contents($logFile, date('Y-m-d H:i:s') . ' - Failed to fetch roles: ' . $e->getMessage() . "\n", FILE_APPEND);
        return new WP_REST_Response(['success' => false, 'message' => 'Lỗi hệ thống'], 500);
    }
}

function checkin_mkt192_save_role_api(WP_REST_Request $request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'checkin_mkt192_staff_roles';
    $logFile    = __DIR__ . '/logs/api_errors.log';

    try {
        $id                     = $request->get_param('id'); // For PUT, id is in URL; for POST, null
        $role_name              = sanitize_text_field($request->get_param('role_name'));
        $description            = sanitize_textarea_field($request->get_param('description'));
        $is_active              = $request->get_param('is_active') ? 1 : 0;
        $paid_leave_days        = intval($request->get_param('paid_leave_days')) ?: 0;
        $permissions_raw        = $request->get_param('permissions');
        $access_permissions_raw = $request->get_param('access_permissions');

        // Handle permissions: could be JSON string or array
        if (is_string($permissions_raw)) {
            $permissions = json_decode($permissions_raw, true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                $permissions = [];
            }
        } elseif (is_array($permissions_raw)) {
            $permissions = $permissions_raw;
        } else {
            $permissions = [];
        }

        // Handle access_permissions: could be JSON string or array
        if (is_string($access_permissions_raw)) {
            $access_permissions = json_decode($access_permissions_raw, true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                $access_permissions = [];
            }
        } elseif (is_array($access_permissions_raw)) {
            $access_permissions = $access_permissions_raw;
        } else {
            $access_permissions = [];
        }

        if (empty($role_name)) {
            return new WP_REST_Response(['success' => false, 'message' => 'Tên vai trò không được để trống'], 400);
        }

        // Validate permissions structure
        if (!is_array($permissions)) {
            $permissions = [];
        }

        // Encode permissions and access_permissions to JSON
        $permissions_json        = json_encode($permissions);
        $access_permissions_json = json_encode($access_permissions);

        if ($id) {
            // Cập nhật vai trò
            $result = $wpdb->update(
                $table_name,
                [
                    'role_name'          => $role_name,
                    'description'        => $description,
                    'is_active'          => $is_active,
                    'paid_leave_days'    => $paid_leave_days,
                    'access_permissions' => $access_permissions_json,
                    'permissions'        => $permissions_json
                ],
                ['id' => $id]
            );
            if ($result === false) {
                file_put_contents($logFile, date('Y-m-d H:i:s') . " - Failed to update role ID $id: " . $wpdb->last_error . "\n", FILE_APPEND);
                return new WP_REST_Response(['success' => false, 'message' => 'Lỗi hệ thống'], 500);
            }
        } else {
            // Thêm vai trò mới
            $result = $wpdb->insert(
                $table_name,
                [
                    'role_name'          => $role_name,
                    'description'        => $description,
                    'is_active'          => $is_active,
                    'paid_leave_days'    => $paid_leave_days,
                    'access_permissions' => $access_permissions_json,
                    'permissions'        => $permissions_json
                ]
            );
            if ($result === false) {
                file_put_contents($logFile, date('Y-m-d H:i:s') . ' - Failed to insert role: ' . $wpdb->last_error . "\n", FILE_APPEND);
                return new WP_REST_Response(['success' => false, 'message' => 'Lỗi hệ thống'], 500);
            }
            $id = $wpdb->insert_id;
        }

        return new WP_REST_Response([
            'success' => true,
            'data'    => [
                'id'                 => $id,
                'role_name'          => $role_name,
                'description'        => $description,
                'is_active'          => $is_active,
                'paid_leave_days'    => $paid_leave_days,
                'access_permissions' => $access_permissions,
                'permissions'        => $permissions
            ]
        ], 200);
    } catch (Exception $e) {
        file_put_contents($logFile, date('Y-m-d H:i:s') . ' - Failed to save role: ' . $e->getMessage() . "\n", FILE_APPEND);
        if (strpos($e->getMessage(), 'Duplicate entry') !== false) {
            return new WP_REST_Response(['success' => false, 'message' => 'Vai trò đã tồn tại'], 400);
        }
        return new WP_REST_Response(['success' => false, 'message' => 'Lỗi hệ thống'], 500);
    }
}

function checkin_mkt192_delete_role_api(WP_REST_Request $request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'checkin_mkt192_staff_roles';
    $logFile    = __DIR__ . '/logs/api_errors.log';

    try {
        $id     = $request->get_param('id');
        $result = $wpdb->delete($table_name, ['id' => $id]);

        if ($result === false) {
            file_put_contents($logFile, date('Y-m-d H:i:s') . " - Failed to delete role ID $id: " . $wpdb->last_error . "\n", FILE_APPEND);
            return new WP_REST_Response(['success' => false, 'message' => 'Lỗi hệ thống'], 500);
        }

        return new WP_REST_Response(['success' => true, 'message' => 'Xóa vai trò thành công'], 200);
    } catch (Exception $e) {
        file_put_contents($logFile, date('Y-m-d H:i:s') . ' - Failed to delete role: ' . $e->getMessage() . "\n", FILE_APPEND);
        return new WP_REST_Response(['success' => false, 'message' => 'Lỗi hệ thống'], 500);
    }
}
?>
