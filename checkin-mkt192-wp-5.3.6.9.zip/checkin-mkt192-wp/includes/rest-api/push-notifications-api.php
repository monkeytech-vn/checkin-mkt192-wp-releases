<?php

/**
 * Push Notifications API - OneSignal Web SDK v16
 *
 * REST API endpoints for managing push notifications via OneSignal
 * Based on official documentation: https://documentation.onesignal.com/docs/en/web-sdk-reference
 *
 * @package Checkin_MKT192_WP
 * @since 6.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Log push notification events
 *
 * @param string $message Log message
 * @param array $data Additional data
 */
function checkin_mkt192_push_log($message, $data = []) {
    $log_dir = __DIR__ . '/logs';
    if (!file_exists($log_dir)) {
        mkdir($log_dir, 0755, true);
    }

    $log_file  = $log_dir . '/push_notifications.log';
    $log_entry = '[' . date('Y-m-d H:i:s') . '] ' . $message;
    if (!empty($data)) {
        $log_entry .= ' | ' . json_encode($data, JSON_UNESCAPED_UNICODE);
    }
    $log_entry .= "\n";

    file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);

    if (WP_DEBUG) {
        error_log("[Push] $message");
    }
}

// =============================================================================
// REST API ROUTES
// =============================================================================

add_action('rest_api_init', function () {
    // Get OneSignal configuration for frontend
    register_rest_route('vg/v1', '/push/config', [
        'methods'             => 'GET',
        'callback'            => 'checkin_push_get_config',
        'permission_callback' => '__return_true'
    ]);

    // Register/sync subscription with server
    register_rest_route('vg/v1', '/push/subscribe', [
        'methods'             => 'POST',
        'callback'            => 'checkin_push_subscribe',
        'permission_callback' => '__return_true'
    ]);

    // Unsubscribe from push notifications
    register_rest_route('vg/v1', '/push/unsubscribe', [
        'methods'             => 'POST',
        'callback'            => 'checkin_push_unsubscribe',
        'permission_callback' => function () {
            return is_user_logged_in();
        }
    ]);

    // Get subscription status
    register_rest_route('vg/v1', '/push/status', [
        'methods'             => 'GET',
        'callback'            => 'checkin_push_status',
        'permission_callback' => function () {
            return is_user_logged_in();
        }
    ]);

    // Update notification preferences
    register_rest_route('vg/v1', '/push/preferences', [
        'methods'             => 'POST',
        'callback'            => 'checkin_push_update_preferences',
        'permission_callback' => function () {
            return is_user_logged_in();
        }
    ]);

    // Send push notification (admin only)
    register_rest_route('vg/v1', '/push/send', [
        'methods'             => 'POST',
        'callback'            => 'checkin_push_send',
        'permission_callback' => function () {
            return current_user_can('manage_options');
        }
    ]);

    // Send test notification to self
    register_rest_route('vg/v1', '/push/test', [
        'methods'             => 'POST',
        'callback'            => 'checkin_push_test',
        'permission_callback' => function () {
            return is_user_logged_in();
        }
    ]);

    // Debug endpoint (admin only)
    register_rest_route('vg/v1', '/push/debug', [
        'methods'             => 'GET',
        'callback'            => 'checkin_push_debug',
        'permission_callback' => function () {
            return current_user_can('manage_options');
        }
    ]);
});

// =============================================================================
// API HANDLERS
// =============================================================================

/**
 * Get OneSignal configuration for frontend initialization
 */
function checkin_push_get_config($request) {
    $enabled = get_option('checkin_push_enabled', '0') === '1';
    $app_id  = get_option('checkin_onesignal_app_id', '');

    if (!$enabled || empty($app_id)) {
        return rest_ensure_response([
            'success' => false,
            'enabled' => false
        ]);
    }

    return rest_ensure_response([
        'success' => true,
        'enabled' => true,
        'config'  => [
            'appId'         => $app_id,
            'safariWebId'   => get_option('checkin_onesignal_safari_web_id', ''),
            'serviceWorker' => [
                'path'  => '/OneSignalSDKWorker.js',
                'scope' => '/'
            ],
            'notifyButton' => [
                'enable' => false
            ],
            'welcomeNotification' => [
                'disable' => true
            ],
            'promptOptions' => [
                'slidedown' => [
                    'prompts' => [
                        [
                            'type'       => 'push',
                            'autoPrompt' => false
                        ]
                    ]
                ]
            ]
        ]
    ]);
}

/**
 * Subscribe/sync push subscription with server
 * Stores OneSignal subscription ID and links to WordPress user
 */
function checkin_push_subscribe($request) {
    global $wpdb;

    $params = json_decode($request->get_body(), true);

    // Log incoming request for debugging
    checkin_mkt192_push_log('📲 ĐĂNG KÝ THÔNG BÁO', [
        'user_id'         => $params['user_id']         ?? get_current_user_id(),
        'subscription_id' => $params['subscription_id'] ?? '',
        'platform'        => $params['platform']        ?? 'web',
    ]);

    $subscription_id    = sanitize_text_field($params['subscription_id'] ?? '');
    $onesignal_id       = sanitize_text_field($params['onesignal_id'] ?? '');
    $external_id        = sanitize_text_field($params['external_id'] ?? '');
    $platform           = sanitize_text_field($params['platform'] ?? 'web');
    $notification_types = $params['notification_types'] ?? null;

    // Get user ID - prioritize session, fallback to request body
    $user_id = get_current_user_id();
    if (!$user_id && !empty($params['user_id'])) {
        $user_id = absint($params['user_id']);
    }

    // Validate subscription ID
    if (empty($subscription_id)) {
        checkin_mkt192_push_log('❌ ĐĂNG KÝ THẤT BẠI - Thiếu subscription_id');
        return new WP_Error('missing_subscription_id', 'Subscription ID is required', ['status' => 400]);
    }

    // Validate user ID
    if (empty($user_id)) {
        checkin_mkt192_push_log('❌ ĐĂNG KÝ THẤT BẠI - Thiếu user_id', [
            'cookie_uid' => get_current_user_id(),
            'param_uid'  => $params['user_id'] ?? null
        ]);
        return new WP_Error('missing_user_id', 'User ID is required. Please login first.', ['status' => 400]);
    }

    // Validate user exists
    $user = get_userdata($user_id);
    if (!$user) {
        checkin_mkt192_push_log('❌ ĐĂNG KÝ THẤT BẠI - User không tồn tại', ['user_id' => $user_id]);
        return new WP_Error('invalid_user', 'User not found', ['status' => 404]);
    }

    $table = $wpdb->prefix . 'checkin_mkt192_push_subscriptions';

    // Default notification types
    if (empty($notification_types)) {
        $notification_types = ['booking', 'invoice', 'review', 'approval', 'salary', 'general', 'staff_announcement'];
    }
    $notification_types_json = json_encode($notification_types);

    // Device info
    $device_info = json_encode([
        'user_agent'    => sanitize_text_field($_SERVER['HTTP_USER_AGENT'] ?? ''),
        'onesignal_id'  => $onesignal_id,
        'external_id'   => $external_id,
        'subscribed_at' => current_time('mysql')
    ], JSON_UNESCAPED_UNICODE);

    // Check existing subscription
    $existing = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM $table WHERE player_id = %s",
        $subscription_id
    ));

    if ($existing) {
        // Update existing
        $update_result = $wpdb->update(
            $table,
            [
                'user_id'            => $user_id,
                'platform'           => $platform,
                'device_info'        => $device_info,
                'notification_types' => $notification_types_json,
                'is_active'          => 1,
                'updated_at'         => current_time('mysql')
            ],
            ['player_id' => $subscription_id],
            ['%d', '%s', '%s', '%s', '%d', '%s'],
            ['%s']
        );

        if ($update_result === false) {
            checkin_mkt192_push_log('❌ CẬP NHẬT ĐĂNG KÝ THẤT BẠI', [
                'error' => $wpdb->last_error,
                'query' => $wpdb->last_query
            ]);
            return new WP_Error('db_error', 'Failed to update subscription: ' . $wpdb->last_error, [
                'status' => 500,
                'debug'  => ['last_error' => $wpdb->last_error, 'last_query' => $wpdb->last_query]
            ]);
        }

        checkin_mkt192_push_log('✅ CẬP NHẬT ĐĂNG KÝ', [
            'user_id'         => $user_id,
            'subscription_id' => $subscription_id,
            'rows_affected'   => $update_result
        ]);
    } else {
        // Insert new
        $result = $wpdb->insert(
            $table,
            [
                'user_id'            => $user_id,
                'player_id'          => $subscription_id,
                'platform'           => $platform,
                'device_info'        => $device_info,
                'notification_types' => $notification_types_json,
                'is_active'          => 1,
                'created_at'         => current_time('mysql'),
                'updated_at'         => current_time('mysql')
            ],
            ['%d', '%s', '%s', '%s', '%s', '%d', '%s', '%s']
        );

        if ($result === false) {
            checkin_mkt192_push_log('❌ THÊM ĐĂNG KÝ THẤT BẠI', [
                'error' => $wpdb->last_error,
                'query' => $wpdb->last_query
            ]);
            return new WP_Error('db_error', 'Failed to save subscription: ' . $wpdb->last_error, [
                'status' => 500,
                'debug'  => ['last_error' => $wpdb->last_error, 'last_query' => $wpdb->last_query]
            ]);
        }

        checkin_mkt192_push_log('✅ TẠO ĐĂNG KÝ MỚI', [
            'user_id'         => $user_id,
            'subscription_id' => $subscription_id,
            'insert_id'       => $wpdb->insert_id
        ]);
    }

    // Store in user meta
    update_user_meta($user_id, 'onesignal_subscription_id', $subscription_id);
    update_user_meta($user_id, 'onesignal_user_id', $onesignal_id);
    update_user_meta($user_id, 'push_notifications_enabled', '1');

    // Set external ID via OneSignal API
    checkin_push_set_external_id($subscription_id, $user_id);

    // Verify it was actually saved
    $verify = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM $table WHERE player_id = %s AND user_id = %d",
        $subscription_id, $user_id
    ));

    checkin_mkt192_push_log('✅ ĐĂNG KÝ THÀNH CÔNG', [
        'user_id'         => $user_id,
        'subscription_id' => $subscription_id,
        'verified_in_db'  => !empty($verify)
    ]);

    return rest_ensure_response([
        'success'            => true,
        'message'            => 'Subscription synced successfully',
        'user_id'            => $user_id,
        'subscription_id'    => $subscription_id,
        'notification_types' => $notification_types,
        'debug'              => [
            'db_verified'   => !empty($verify),
            'db_id'         => $verify,
            'table'         => $table,
            'existing'      => $existing ? 'updated' : 'inserted',
            'cookie_uid'    => get_current_user_id(),
            'param_uid'     => $params['user_id'] ?? null,
            'final_uid'     => $user_id
        ]
    ]);
}

/**
 * Unsubscribe from push notifications
 */
function checkin_push_unsubscribe($request) {
    global $wpdb;

    $params          = json_decode($request->get_body(), true);
    $subscription_id = sanitize_text_field($params['subscription_id'] ?? '');
    $user_id         = get_current_user_id();

    $table = $wpdb->prefix . 'checkin_mkt192_push_subscriptions';

    if ($subscription_id) {
        // Deactivate specific subscription
        $wpdb->update(
            $table,
            ['is_active' => 0, 'updated_at' => current_time('mysql')],
            ['player_id' => $subscription_id],
            ['%d', '%s'],
            ['%s']
        );
    } else {
        // Deactivate all subscriptions for user
        $wpdb->update(
            $table,
            ['is_active' => 0, 'updated_at' => current_time('mysql')],
            ['user_id'   => $user_id],
            ['%d', '%s'],
            ['%d']
        );
    }

    update_user_meta($user_id, 'push_notifications_enabled', '0');

    checkin_mkt192_push_log('🚫 HỦY ĐĂNG KÝ', [
        'user_id'         => $user_id,
        'subscription_id' => $subscription_id
    ]);

    return rest_ensure_response([
        'success' => true,
        'message' => 'Unsubscribed successfully'
    ]);
}

/**
 * Get user's subscription status
 */
function checkin_push_status($request) {
    global $wpdb;

    $user_id = get_current_user_id();
    $table   = $wpdb->prefix . 'checkin_mkt192_push_subscriptions';

    // Get active subscriptions count
    $active_count = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM $table WHERE user_id = %d AND is_active = 1",
        $user_id
    ));

    // Get notification types for user
    $notification_types = $wpdb->get_var($wpdb->prepare(
        "SELECT notification_types FROM $table WHERE user_id = %d AND is_active = 1 ORDER BY updated_at DESC LIMIT 1",
        $user_id
    ));

    $enabled = get_user_meta($user_id, 'push_notifications_enabled', true) === '1';

    return rest_ensure_response([
        'success'            => true,
        'enabled'            => $enabled,
        'subscribed'         => $active_count > 0,
        'device_count'       => (int) $active_count,
        'notification_types' => $notification_types ? json_decode($notification_types, true) : []
    ]);
}

/**
 * Update notification preferences
 */
function checkin_push_update_preferences($request) {
    global $wpdb;

    $params             = json_decode($request->get_body(), true);
    $user_id            = get_current_user_id();
    $notification_types = $params['notification_types'] ?? null;

    // Validate notification types
    $valid_types = ['booking', 'invoice', 'review', 'approval', 'salary', 'general'];
    if (empty($notification_types) || !is_array($notification_types)) {
        return new WP_Error('invalid_types', 'Invalid notification types', ['status' => 400]);
    }

    $notification_types      = array_values(array_intersect($notification_types, $valid_types));
    $notification_types_json = json_encode($notification_types);

    $table = $wpdb->prefix . 'checkin_mkt192_push_subscriptions';

    // Update all active subscriptions for user
    $result = $wpdb->update(
        $table,
        [
            'notification_types' => $notification_types_json,
            'updated_at'         => current_time('mysql')
        ],
        [
            'user_id'   => $user_id,
            'is_active' => 1
        ],
        ['%s', '%s'],
        ['%d', '%d']
    );

    update_user_meta($user_id, 'push_notification_types', $notification_types_json);

    checkin_mkt192_push_log('PREFERENCES UPDATED', [
        'user_id' => $user_id,
        'types'   => $notification_types
    ]);

    return rest_ensure_response([
        'success'            => true,
        'message'            => 'Preferences updated',
        'notification_types' => $notification_types
    ]);
}

/**
 * Send test notification to current user
 */
function checkin_push_test($request) {
    $user_id = get_current_user_id();
    $user    = get_userdata($user_id);

    $result = checkin_push_send_to_users($user_id, [
        'title' => '🔔 Test Notification',
        'body'  => 'Hello ' . $user->display_name . '! Push notifications are working.',
        'url'   => home_url('/user-profile'),
        'data'  => [
            'type'      => 'test',
            'timestamp' => time()
        ]
    ]);

    return rest_ensure_response($result);
}

/**
 * Send push notification (admin endpoint)
 */
function checkin_push_send($request) {
    $params = json_decode($request->get_body(), true);

    $user_ids     = $params['user_ids'] ?? [];
    $notification = [
        'title' => sanitize_text_field($params['title'] ?? 'Notification'),
        'body'  => sanitize_text_field($params['body'] ?? ''),
        'url'   => esc_url_raw($params['url'] ?? home_url()),
        'icon'  => esc_url_raw($params['icon'] ?? ''),
        'image' => esc_url_raw($params['image'] ?? ''),
        'data'  => $params['data'] ?? []
    ];

    if (empty($user_ids)) {
        return new WP_Error('no_users', 'Please select recipients', ['status' => 400]);
    }

    $result = checkin_push_send_to_users($user_ids, $notification);

    if ($result['success']) {
        return rest_ensure_response($result);
    } else {
        return new WP_Error('send_failed', $result['message'], ['status' => 500]);
    }
}

/**
 * Debug endpoint - view subscriptions
 */
function checkin_push_debug($request) {
    global $wpdb;

    $user_id = absint($request->get_param('user_id'));
    $table   = $wpdb->prefix . 'checkin_mkt192_push_subscriptions';

    if ($user_id) {
        $subscriptions = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table WHERE user_id = %d ORDER BY updated_at DESC",
            $user_id
        ), ARRAY_A);
    } else {
        $subscriptions = $wpdb->get_results(
            "SELECT * FROM $table ORDER BY updated_at DESC LIMIT 50",
            ARRAY_A
        );
    }

    // Verify each subscription with OneSignal
    $api_key = get_option('checkin_onesignal_api_key', '');
    $app_id  = get_option('checkin_onesignal_app_id', '');

    if (!empty($api_key) && !empty($app_id)) {
        foreach ($subscriptions as &$sub) {
            $verify                  = checkin_push_verify_subscription($sub['player_id']);
            $sub['onesignal_status'] = $verify;
        }
    }

    return rest_ensure_response([
        'success'       => true,
        'subscriptions' => $subscriptions,
        'config'        => [
            'app_id'  => get_option('checkin_onesignal_app_id', ''),
            'enabled' => get_option('checkin_push_enabled', '0') === '1'
        ]
    ]);
}

/**
 * Verify subscription is still valid on OneSignal
 *
 * @param string $subscription_id
 * @return array Status info
 */
function checkin_push_verify_subscription($subscription_id) {
    $api_key = get_option('checkin_onesignal_api_key', '');
    $app_id  = get_option('checkin_onesignal_app_id', '');

    if (empty($api_key) || empty($app_id) || empty($subscription_id)) {
        return ['valid' => false, 'error' => 'Missing config'];
    }

    $response = wp_remote_get(
        "https://api.onesignal.com/apps/{$app_id}/subscriptions/{$subscription_id}",
        [
            'headers' => [
                'Authorization' => 'Key ' . $api_key,
                'Content-Type'  => 'application/json'
            ],
            'timeout' => 10
        ]
    );

    if (is_wp_error($response)) {
        return ['valid' => false, 'error' => $response->get_error_message()];
    }

    $code = wp_remote_retrieve_response_code($response);
    $body = json_decode(wp_remote_retrieve_body($response), true);

    if ($code === 200 && !empty($body['subscription'])) {
        $sub = $body['subscription'];
        return [
            'valid'              => true,
            'id'                 => $sub['id']                 ?? null,
            'type'               => $sub['type']               ?? null,
            'enabled'            => $sub['enabled']            ?? null,
            'notification_types' => $sub['notification_types'] ?? null,
            'token_exists'       => !empty($sub['token']),
            'web_p256'           => !empty($sub['web_p256']),
            'web_auth'           => !empty($sub['web_auth']),
        ];
    } elseif ($code === 404) {
        return ['valid' => false, 'error' => 'Subscription not found on OneSignal'];
    } else {
        return ['valid' => false, 'error' => $body['errors'][0] ?? "HTTP $code"];
    }
}

// =============================================================================
// CORE FUNCTIONS
// =============================================================================

/**
 * Các loại thông báo và nhóm tương ứng
 *
 * STAFF THƯỜNG có thể chọn:
 * - booking: Lịch hẹn mới, hủy lịch, nhắc lịch
 * - invoice: Hóa đơn thanh toán, truy thu
 * - review: Đánh giá mới
 * - salary: Phiếu lương, thanh toán lương
 * - general: Nhắc check-in, thông báo chung
 * - staff_announcement: Thông báo từ quản lý (tạo từ trang Thông báo)
 *
 * MANAGER/ADMIN nhận TẤT CẢ (không lọc) + thêm:
 * - approval: Đơn xin phép mới, kết quả duyệt
 * - invoice_deleted: Hóa đơn bị xóa
 * - inventory_pending: Phiếu xuất/nhập kho mới cần duyệt
 *
 * CASHIER (Thu Ngân) nhận như STAFF + thêm:
 * - inventory_approved: Phiếu xuất/nhập kho đã được duyệt
 * - KHÔNG nhận: payment_success (hóa đơn thanh toán)
 */
define('CHECKIN_PUSH_STAFF_TYPES', ['booking', 'invoice', 'review', 'salary', 'general', 'staff_announcement']);
define('CHECKIN_PUSH_MANAGER_ONLY_TYPES', ['approval', 'invoice_deleted', 'inventory_pending']);
define('CHECKIN_PUSH_CASHIER_EXTRA_TYPES', ['inventory_approved']); // Thêm cho cashier ngoài staff types
define('CHECKIN_PUSH_PRIVILEGED_ROLES', ['administrator']); // Chỉ administrator - không có role manager trong WP

/**
 * Check if user has privileged role (manager, admin)
 * These users receive ALL notifications without filtering
 * Note: Cashier is NOT privileged - they receive like staff + inventory_approved
 *
 * @param int $user_id WordPress user ID
 * @return bool
 */
function checkin_push_user_is_privileged($user_id) {
    $user = get_userdata($user_id);
    if (!$user) return false;

    foreach (CHECKIN_PUSH_PRIVILEGED_ROLES as $role) {
        if (in_array($role, (array) $user->roles)) {
            return true;
        }
    }
    return false;
}

/**
 * Check if user is a cashier
 * Cashier receives staff notifications + inventory_approved, but NOT payment_success
 *
 * @param int $user_id WordPress user ID
 * @return bool
 */
function checkin_push_user_is_cashier($user_id) {
    $user = get_userdata($user_id);
    if (!$user) return false;
    return in_array('cashier', (array) $user->roles);
}

// =============================================================================
// NOTIFICATION SETTINGS HELPERS
// =============================================================================

/**
 * Get notification settings from database
 * Falls back to default settings if not configured
 *
 * @param string $type Notification type key (e.g., 'booking', 'payment_success')
 * @return array Settings with 'enabled', 'title', 'body', 'roles'
 */
function checkin_push_get_notification_settings($type) {
    // Get saved settings from database - ensure it's an array
    $all_settings = get_option('checkin_push_notification_settings', []);
    if (!is_array($all_settings)) {
        $all_settings = [];
    }

    // Get default settings
    $defaults = checkin_push_get_default_settings($type);

    // Merge saved with defaults
    if (isset($all_settings[$type]) && is_array($all_settings[$type])) {
        return wp_parse_args($all_settings[$type], $defaults);
    }

    return $defaults;
}

/**
 * Get default settings for a notification type
 *
 * @param string $type Notification type key
 * @return array Default settings
 */
function checkin_push_get_default_settings($type) {
    $defaults = [
        // Booking
        'booking' => [
            'enabled' => true,
            'title'   => '📅 Lịch hẹn mới',
            'body'    => '{customer_name} đặt lịch lúc {booking_time}',
            'roles'   => ['administrator', 'staff'],
        ],
        'booking_cancelled' => [
            'enabled' => true,
            'title'   => '❌ Hủy lịch hẹn',
            'body'    => '{customer_name} đã hủy lịch lúc {booking_time}',
            'roles'   => ['administrator', 'staff'],
        ],

        // Invoice
        'payment_success' => [
            'enabled' => true,
            'title'   => '💰 Thanh toán thành công',
            'body'    => 'Hóa đơn #{invoice_id} đã thanh toán: {total}đ',
            'roles'   => ['administrator', 'staff'],
        ],
        'invoice_surcharge' => [
            'enabled' => true,
            'title'   => '⚠️ Hóa đơn truy thu',
            'body'    => 'Hóa đơn #{invoice_id} bị truy thu: {surcharge_amount}đ',
            'roles'   => ['administrator', 'cashier', 'staff'],
        ],
        'invoice_deleted' => [
            'enabled' => true,
            'title'   => '🗑️ Xóa hóa đơn',
            'body'    => 'Hóa đơn #{invoice_id} đã bị xóa bởi {deleted_by}',
            'roles'   => ['administrator', 'cashier'],
        ],

        // Review
        'review' => [
            'enabled' => true,
            'title'   => '⭐ Đánh giá mới',
            'body'    => '{customer_name} đã đánh giá bạn {rating_stars}',
            'roles'   => ['administrator', 'staff'],
        ],

        // Approval
        'approval_request' => [
            'enabled' => true,
            'title'   => '📝 Đơn mới cần duyệt',
            'body'    => '{staff_name} đã gửi đơn {request_type}',
            'roles'   => ['administrator'],
        ],
        'approval_result' => [
            'enabled' => true,
            'title'   => '{status_icon} Đơn {request_type} {status_text}',
            'body'    => 'Đơn {request_type} của bạn đã {status_text}',
            'roles'   => ['staff'],
        ],

        // Salary
        'salary_slip' => [
            'enabled' => true,
            'title'   => '💵 Phiếu lương sẵn sàng',
            'body'    => 'Phiếu lương tháng {month}/{year} đã có',
            'roles'   => ['staff'],
        ],
        'salary_slip_confirmed' => [
            'enabled' => true,
            'title'   => '✅ {staff_name} đã xác nhận phiếu lương',
            'body'    => '{staff_name} đã xác nhận phiếu lương tháng {month}/{year}',
            'roles'   => ['administrator'],
        ],
        'salary_payment' => [
            'enabled' => true,
            'title'   => '🎉 Đã thanh toán lương',
            'body'    => 'Lương tháng {month}/{year} đã được thanh toán!',
            'roles'   => ['staff'],
        ],
        'salary_payment_confirmed' => [
            'enabled' => true,
            'title'   => '🎉 {staff_name} đã xác nhận thanh toán',
            'body'    => '{staff_name} đã xác nhận nhận lương tháng {month}/{year}',
            'roles'   => ['administrator'],
        ],
        'salary_batch' => [
            'enabled' => true,
            'title'   => '💵 Bảng lương {action_text}',
            'body'    => 'Bảng lương tháng {month}/{year} {action_text}',
            'roles'   => ['administrator'],
        ],

        // Inventory
        'inventory_pending' => [
            'enabled' => true,
            'title'   => '📦 Phiếu {type_text} mới cần duyệt',
            'body'    => '{staff_name} đã tạo phiếu {type_text} ({product_count} sản phẩm)',
            'roles'   => ['administrator'],
        ],
        'inventory_approved' => [
            'enabled' => true,
            'title'   => '✅ Phiếu {type_text} đã được duyệt',
            'body'    => 'Phiếu #{transaction_id} của bạn đã được {approved_by} duyệt',
            'roles'   => ['cashier', 'staff'],
        ],

        // Staff Announcement (from Notifications management)
        'staff_announcement' => [
            'enabled' => true,
            'title'   => '📢 {title}',
            'body'    => '{content}',
            'roles'   => ['administrator', 'cashier', 'staff'],
        ],
    ];

    return $defaults[$type] ?? [
        'enabled' => true,
        'title'   => 'Thông báo',
        'body'    => '',
        'roles'   => ['administrator'],
    ];
}

/**
 * Check if a notification type is enabled
 *
 * @param string $type Notification type key
 * @return bool
 */
function checkin_push_is_notification_enabled($type) {
    $settings = checkin_push_get_notification_settings($type);
    return !empty($settings['enabled']);
}

/**
 * Get roles that should receive a notification type
 *
 * @param string $type Notification type key
 * @return array Role slugs
 */
function checkin_push_get_notification_roles($type) {
    $settings = checkin_push_get_notification_settings($type);
    return $settings['roles'] ?? [];
}

/**
 * Filter user IDs by notification settings roles
 * Chỉ giữ lại users có vai trò nằm trong danh sách roles được cấu hình
 *
 * @param int|array $user_ids User ID(s) to filter
 * @param array $allowed_roles Roles allowed from notification settings
 * @return array Filtered user IDs
 */
function checkin_push_filter_users_by_roles($user_ids, $allowed_roles) {
    if (empty($allowed_roles)) {
        return [];
    }

    if (!is_array($user_ids)) {
        $user_ids = [$user_ids];
    }

    $filtered = [];
    foreach ($user_ids as $uid) {
        $user = get_user_by('ID', $uid);
        if (!$user) continue;

        $user_roles = (array) $user->roles;
        // Kiểm tra xem user có bất kỳ vai trò nào trong danh sách allowed không
        if (array_intersect($user_roles, $allowed_roles)) {
            $filtered[] = $uid;
        }
    }

    return $filtered;
}

/**
 * Filter users by both roles AND branch
 * Lọc users theo cả vai trò VÀ chi nhánh
 * User phải có vai trò phù hợp VÀ thuộc chi nhánh (nếu bật đa chi nhánh)
 *
 * @param int|array $user_ids User ID(s) to filter
 * @param array $allowed_roles Roles allowed from notification settings
 * @param int|null $branch_id Branch ID to filter (null = skip branch filter)
 * @return array Filtered user IDs
 */
function checkin_push_filter_users_by_roles_and_branch($user_ids, $allowed_roles, $branch_id = null) {
    // Bước 1: Lọc theo roles trước
    $role_filtered = checkin_push_filter_users_by_roles($user_ids, $allowed_roles);

    if (empty($role_filtered)) {
        return [];
    }

    // Bước 2: Nếu không bật branch mode hoặc không có branch_id -> trả về kết quả từ bước 1
    if (!checkin_push_is_branch_mode_enabled() || empty($branch_id)) {
        return $role_filtered;
    }

    // Bước 3: Lọc tiếp theo chi nhánh
    global $wpdb;
    $table        = $wpdb->prefix . 'checkin_mkt192_staff';
    $placeholders = implode(',', array_fill(0, count($role_filtered), '%d'));
    $branch_id    = intval($branch_id);

    // Query: tìm staff có user_id trong danh sách VÀ branch JSON chứa target branch_id
    $query = $wpdb->prepare(
        "SELECT user_id FROM $table
         WHERE user_id IN ($placeholders)
         AND (
             branch LIKE %s
             OR branch LIKE %s
             OR branch LIKE %s
             OR branch LIKE %s
             OR branch LIKE %s
             OR branch LIKE %s
             OR branch = %s
             OR branch = %s
         )",
        ...array_merge(
            $role_filtered,
            [
                // Number format: [1,2,3]
                '[' . $branch_id . ',%',           // [1,... - đầu array
                '%,' . $branch_id . ',%',          // ,1,... - giữa array
                '%,' . $branch_id . ']',           // ...,1] - cuối array
                // String format: ["1","2","3"]
                '%"' . $branch_id . '"%',          // "1" anywhere
                // Single element
                '[' . $branch_id . ']',            // [1] - single number
                '["' . $branch_id . '"]',          // ["1"] - single string
                // Exact match (legacy - số đơn lẻ)
                (string) $branch_id,               // just "1"
                '"' . $branch_id . '"'             // just "\"1\""
            ]
        )
    );

    $filtered_ids = $wpdb->get_col($query);

    checkin_mkt192_push_log('🏢 FILTER BY ROLES + BRANCH', [
        'branch_id'       => $branch_id,
        'allowed_roles'   => $allowed_roles,
        'input_users'     => $user_ids,
        'after_roles'     => $role_filtered,
        'after_branch'    => $filtered_ids
    ]);

    return array_map('intval', $filtered_ids);
}

/**
 * Replace variables in notification template
 *
 * @param string $template Template string with {variable} placeholders
 * @param array $data Data to replace
 * @return string Replaced string with any unreplaced placeholders removed
 */
function checkin_push_replace_variables($template, $data) {
    foreach ($data as $key => $value) {
        $template = str_replace('{' . $key . '}', $value, $template);
    }
    // Xóa các placeholder còn sót lại (không có trong data)
    // Điều này đảm bảo không hiển thị {variable_name} trong thông báo
    $template = preg_replace('/\{[a-zA-Z_][a-zA-Z0-9_]*\}/', '', $template);
    return $template;
}

/**
 * Build notification content from settings
 *
 * @param string $type Notification type key
 * @param array $data Data for variable replacement
 * @param int|null $branch_id Branch ID for branch name suffix
 * @return array ['title' => string, 'body' => string]
 */
function checkin_push_build_notification_content($type, $data = [], $branch_id = null) {
    $settings = checkin_push_get_notification_settings($type);

    // Add branch_name to data if branch_id provided, or empty string if not available
    if (!isset($data['branch_name'])) {
        if ($branch_id) {
            $data['branch_name'] = checkin_push_get_branch_name($branch_id) ?: '';
        } else {
            // Đảm bảo {branch_name} placeholder luôn được replace (thành empty string nếu không có branch)
            $data['branch_name'] = '';
        }
    }

    // Log để debug
    checkin_mkt192_push_log('🔧 BUILD_NOTIFICATION_CONTENT', [
        'type'           => $type,
        'branch_id'      => $branch_id,
        'data'           => $data,
        'template_title' => $settings['title'],
        'template_body'  => $settings['body']
    ]);

    $title = checkin_push_replace_variables($settings['title'], $data);
    $body  = checkin_push_replace_variables($settings['body'], $data);

    // Cleanup: remove extra spaces from empty placeholders
    $title = preg_replace('/\s+/', ' ', trim($title));
    $body  = preg_replace('/\s+/', ' ', trim($body));

    // Log kết quả sau replace
    checkin_mkt192_push_log('✅ AFTER_REPLACE', [
        'final_title' => $title,
        'final_body'  => $body
    ]);

    return [
        'title' => $title,
        'body'  => $body,
    ];
}

/**
 * Send push notification via OneSignal REST API
 *
 * Logic xử lý notification types:
 * 1. Manager/Admin/Cashier: Nhận TẤT CẢ thông báo (không lọc)
 * 2. Staff thường: Chỉ nhận thông báo trong notification_types họ đã chọn
 * 3. Test notifications: Không lọc
 *
 * @param int|array $user_ids User ID(s) to send to
 * @param array $notification Notification data
 * @return array Result
 */
function checkin_push_send_to_users($user_ids, $notification) {
    global $wpdb;

    if (!is_array($user_ids)) {
        $user_ids = [$user_ids];
    }

    $api_key = get_option('checkin_onesignal_api_key', '');
    $app_id  = get_option('checkin_onesignal_app_id', '');

    if (empty($api_key) || empty($app_id)) {
        return [
            'success' => false,
            'message' => 'OneSignal not configured'
        ];
    }

    $table = $wpdb->prefix . 'checkin_mkt192_push_subscriptions';

    // Map notification type to category for filtering
    $notification_type = null;
    $raw_type          = $notification['data']['type'] ?? null;

    if ($raw_type) {
        $type_mapping = [
            // Booking group
            'booking'           => 'booking',
            'booking_cancelled' => 'booking',
            'booking_reminder'  => 'booking',
            // Invoice group
            'invoice_deleted'   => 'invoice',
            'invoice_surcharge' => 'invoice',
            'payment_success'   => 'invoice',
            // Other groups
            'review'            => 'review',
            'approval_request'  => 'approval', // Đơn mới - chỉ Quản lý nhận
            'approval_result'   => 'approval', // Kết quả duyệt - chỉ Thợ nhận
            'salary_slip'       => 'salary',
            'salary_payment'    => 'salary',
            'salary_batch'      => 'salary',
            'checkin_reminder'  => 'general',
            'general'           => 'general',
            // Inventory notifications
            'inventory_pending'  => 'inventory', // Phiếu mới chờ duyệt - Quản lý nhận
            'inventory_approved' => 'inventory', // Phiếu đã duyệt - Thu Ngân & người tạo nhận
            'test'               => null // Test không lọc
        ];
        $notification_type = $type_mapping[$raw_type] ?? null;
    }

    // Separate users into: privileged (admin/manager), cashier, regular staff
    $privileged_user_ids = [];
    $cashier_user_ids    = [];
    $regular_user_ids    = [];

    foreach ($user_ids as $uid) {
        if (checkin_push_user_is_privileged($uid)) {
            $privileged_user_ids[] = $uid;
        } elseif (checkin_push_user_is_cashier($uid)) {
            $cashier_user_ids[] = $uid;
        } else {
            $regular_user_ids[] = $uid;
        }
    }

    $subscription_ids = [];

    // 1. Get subscriptions for privileged users (NO FILTERING - admin/manager)
    if (!empty($privileged_user_ids)) {
        $placeholders    = implode(',', array_fill(0, count($privileged_user_ids), '%d'));
        $privileged_subs = $wpdb->get_col($wpdb->prepare(
            "SELECT player_id FROM $table WHERE user_id IN ($placeholders) AND is_active = 1",
            ...$privileged_user_ids
        ));
        $subscription_ids = array_merge($subscription_ids, $privileged_subs);

        checkin_mkt192_push_log('👑 QUẢN LÝ (không lọc)', [
            'user_ids'   => $privileged_user_ids,
            'số đăng ký' => count($privileged_subs)
        ]);
    }

    // 2. Get subscriptions for CASHIER (like staff + inventory_approved, NO payment_success)
    if (!empty($cashier_user_ids)) {
        $placeholders = implode(',', array_fill(0, count($cashier_user_ids), '%d'));

        // Cashier nhận: staff types + inventory_approved, KHÔNG nhận payment_success
        $should_send_to_cashier = false;

        if ($raw_type === 'payment_success') {
            // Cashier KHÔNG nhận thông báo thanh toán thông thường
            $should_send_to_cashier = false;
            checkin_mkt192_push_log('💰 THU NGÂN: Bỏ qua payment_success', [
                'cashier_ids' => $cashier_user_ids
            ]);
        } elseif ($raw_type === 'inventory_approved') {
            // Cashier nhận thông báo inventory đã duyệt
            $should_send_to_cashier = true;
        } elseif ($notification_type && in_array($notification_type, CHECKIN_PUSH_STAFF_TYPES)) {
            // Cashier nhận các thông báo staff types
            $should_send_to_cashier = true;
        } elseif (!$notification_type) {
            // Test hoặc không có type
            $should_send_to_cashier = true;
        }

        if ($should_send_to_cashier) {
            $cashier_subs = $wpdb->get_col($wpdb->prepare(
                "SELECT player_id FROM $table WHERE user_id IN ($placeholders) AND is_active = 1",
                ...$cashier_user_ids
            ));
            $subscription_ids = array_merge($subscription_ids, $cashier_subs);

            checkin_mkt192_push_log('💰 THU NGÂN (như staff + inventory)', [
                'user_ids'       => $cashier_user_ids,
                'loại_thông_báo' => $raw_type,
                'số đăng ký'     => count($cashier_subs)
            ]);
        }
    }

    // 3. Get subscriptions for regular staff (FILTER by notification_types)
    if (!empty($regular_user_ids)) {
        $placeholders = implode(',', array_fill(0, count($regular_user_ids), '%d'));

        if ($notification_type) {
            // Lọc theo loại thông báo user đã chọn
            $regular_subs = $wpdb->get_col($wpdb->prepare(
                "SELECT player_id FROM $table
                 WHERE user_id IN ($placeholders)
                 AND is_active = 1
                 AND (notification_types IS NULL OR notification_types LIKE %s)",
                ...array_merge($regular_user_ids, ['%"' . $notification_type . '"%'])
            ));
        } else {
            // Không có type hoặc test -> gửi cho tất cả
            $regular_subs = $wpdb->get_col($wpdb->prepare(
                "SELECT player_id FROM $table WHERE user_id IN ($placeholders) AND is_active = 1",
                ...$regular_user_ids
            ));
        }

        $subscription_ids = array_merge($subscription_ids, $regular_subs);

        checkin_mkt192_push_log('👤 NHÂN VIÊN (có lọc)', [
            'user_ids'         => $regular_user_ids,
            'loại_thông_báo'   => $notification_type,
            'số đăng ký'       => count($regular_subs)
        ]);
    }

    // Remove duplicates
    $subscription_ids = array_unique($subscription_ids);

    // Log subscription IDs being sent - thêm nội dung thông báo
    checkin_mkt192_push_log('📤 ĐANG GỬi THÔNG BÁO', [
        'tiêu_đề'        => $notification['title'] ?? '',
        'nội_dung'       => $notification['body']  ?? '',
        'số_người_nhận'  => count($subscription_ids)
    ]);

    if (empty($subscription_ids)) {
        return [
            'success' => false,
            'message' => 'No active subscriptions found',
            'sent'    => 0
        ];
    }

    // Prepare OneSignal API request
    $data = [
        'app_id'                   => $app_id,
        'include_subscription_ids' => $subscription_ids,
        'headings'                 => ['en' => $notification['title'] ?? 'Notification'],
        'contents'                 => ['en' => $notification['body'] ?? ''],
        'url'                      => $notification['url'] ?? home_url()
    ];

    // Add icon
    if (!empty($notification['icon'])) {
        $data['chrome_web_icon'] = $notification['icon'];
    } else {
        $data['chrome_web_icon'] = CHECKIN_PLUGIN_URL . 'frontend/assets/images/icon-192x192.png';
    }

    // Add badge
    $data['chrome_web_badge'] = CHECKIN_PLUGIN_URL . 'frontend/assets/images/badge-72x72.png';

    // Add image
    if (!empty($notification['image'])) {
        $data['chrome_web_image'] = $notification['image'];
    }

    // Add custom data
    if (!empty($notification['data'])) {
        $data['data'] = $notification['data'];
    }

    // Add action buttons
    if (!empty($notification['buttons'])) {
        $data['web_buttons'] = $notification['buttons'];
    }

    // Send request
    $response = wp_remote_post('https://onesignal.com/api/v1/notifications', [
        'headers' => [
            'Content-Type'  => 'application/json; charset=utf-8',
            'Authorization' => 'Basic ' . $api_key
        ],
        'body'    => json_encode($data),
        'timeout' => 15
    ]);

    if (is_wp_error($response)) {
        checkin_mkt192_push_log('❌ GỬi THẤT BẠI', ['lỗi' => $response->get_error_message()]);
        return [
            'success' => false,
            'message' => $response->get_error_message(),
            'sent'    => 0
        ];
    }

    $body = json_decode(wp_remote_retrieve_body($response), true);
    $code = wp_remote_retrieve_response_code($response);

    if ($code === 200 && !empty($body['id'])) {
        checkin_mkt192_push_log('✅ GỬi THÀNH CÔNG', [
            'mã_thông_báo'  => $body['id'],
            'số_người_nhận' => $body['recipients'] ?? count($subscription_ids)
        ]);
        return [
            'success'         => true,
            'message'         => 'Notification sent successfully',
            'notification_id' => $body['id'],
            'sent'            => $body['recipients'] ?? count($subscription_ids)
        ];
    } else {
        $error = $body['errors'][0] ?? 'Unknown error';
        checkin_mkt192_push_log('❌ LỖI GỬi', ['lỗi' => $error, 'phản_hồi' => $body]);
        return [
            'success' => false,
            'message' => $error,
            'sent'    => 0
        ];
    }
}

/**
 * Set external ID for subscription via OneSignal API
 *
 * @param string $subscription_id OneSignal subscription ID
 * @param int $user_id WordPress user ID
 * @return bool Success
 */
function checkin_push_set_external_id($subscription_id, $user_id) {
    $api_key = get_option('checkin_onesignal_api_key', '');
    $app_id  = get_option('checkin_onesignal_app_id', '');

    if (empty($api_key) || empty($app_id) || empty($subscription_id) || empty($user_id)) {
        return false;
    }

    $external_id = 'user_' . strval($user_id);

    // Step 1: Create/get user with external_id
    $user_response = wp_remote_post("https://api.onesignal.com/apps/{$app_id}/users", [
        'headers' => [
            'Content-Type'  => 'application/json; charset=utf-8',
            'Authorization' => 'Key ' . $api_key
        ],
        'body'    => json_encode([
            'identity' => ['external_id' => $external_id]
        ]),
        'timeout' => 15
    ]);

    $user_code = wp_remote_retrieve_response_code($user_response);

    // 200, 201 = created, 409 = exists (both OK)
    if (!in_array($user_code, [200, 201, 409])) {
        checkin_mkt192_push_log('❌ LỖI TẠO USER', [
            'external_id' => $external_id,
            'http_code'   => $user_code
        ]);
    }

    // Step 2: Transfer subscription to user
    $transfer_response = wp_remote_request(
        "https://api.onesignal.com/apps/{$app_id}/subscriptions/{$subscription_id}/owner",
        [
            'method'  => 'PATCH',
            'headers' => [
                'Content-Type'  => 'application/json; charset=utf-8',
                'Authorization' => 'Key ' . $api_key
            ],
            'body'    => json_encode([
                'identity' => ['external_id' => $external_id]
            ]),
            'timeout' => 15
        ]
    );

    if (is_wp_error($transfer_response)) {
        checkin_mkt192_push_log('❌ LỖI CHUYỂN ĐĂNG KÝ', [
            'subscription_id' => $subscription_id,
            'lỗi'             => $transfer_response->get_error_message()
        ]);
        return false;
    }

    $transfer_code = wp_remote_retrieve_response_code($transfer_response);

    if ($transfer_code >= 200 && $transfer_code < 300) {
        checkin_mkt192_push_log('✅ LIÊN KẾT USER ID', [
            'subscription_id' => $subscription_id,
            'external_id'     => $external_id
        ]);
        return true;
    }

    checkin_mkt192_push_log('❌ LIÊN KẾT THẤT BẠI', [
        'subscription_id' => $subscription_id,
        'http_code'       => $transfer_code
    ]);
    return false;
}

// =============================================================================
// NOTIFICATION HELPER FUNCTIONS
// =============================================================================

/**
 * Get site domain for notification subtitle
 * Returns domain without protocol (e.g., "example.com")
 */
function checkin_push_get_domain() {
    return wp_parse_url(home_url(), PHP_URL_HOST);
}

/**
 * Check if push notifications are enabled
 */
function checkin_push_is_enabled() {
    return get_option('checkin_push_enabled', '0') === '1';
}

/**
 * Check if multi-branch mode is enabled
 * @deprecated Sử dụng checkin_mkt192_is_multi_branch_enabled() từ branch-helpers.php thay thế
 */
function checkin_push_is_branch_mode_enabled() {
    return checkin_mkt192_is_multi_branch_enabled();
}

/**
 * Get branch name by branch_id from locations table
 *
 * Chi nhánh chính (branch_id) dùng để hiển thị tên chi nhánh trong notification
 * Chỉ trả về tên khi chế độ đa chi nhánh được bật
 *
 * @param int $branch_id ID của chi nhánh (từ cột branch_id - chi nhánh CHÍNH)
 * @return string|null Tên chi nhánh hoặc null
 */
function checkin_push_get_branch_name($branch_id) {
    // Sử dụng helper function từ branch-helpers.php
    return checkin_mkt192_get_branch_name($branch_id);
}

/**
 * Build notification body with optional branch suffix
 *
 * @param string $body Nội dung chính
 * @param int|null $branch_id ID của chi nhánh (optional)
 * @return string Body đã format với chi nhánh (nếu có)
 */
function checkin_push_build_body_with_branch($body, $branch_id = null) {
    $branch_name = checkin_push_get_branch_name($branch_id);

    checkin_mkt192_push_log('🏷️ BUILD BODY WITH BRANCH', [
        'branch_id'    => $branch_id,
        'branch_mode'  => checkin_push_is_branch_mode_enabled() ? 'ON' : 'OFF',
        'branch_name'  => $branch_name,
        'original'     => $body
    ]);

    if ($branch_name) {
        return "{$body} [{$branch_name}]";
    }
    return $body;
}

/**
 * Get user IDs by roles
 */
function checkin_push_get_users_by_roles($roles) {
    $user_ids = [];
    foreach ($roles as $role) {
        $users    = get_users(['role' => $role, 'fields' => 'ID']);
        $user_ids = array_merge($user_ids, $users);
    }
    return array_unique($user_ids);
}

/**
 * Get user IDs by roles and branch_id (for multi-branch mode)
 *
 * Logic:
 * - Nếu branch mode tắt hoặc không có branch_id -> trả về tất cả users theo roles
 * - Nếu branch mode bật -> lọc theo cột `branch` (JSON array) trong bảng staff
 *   + Cột `branch` lưu danh sách chi nhánh user được phép: [1,2,3] hoặc ["1","2","3"]
 *   + Cột `branch_id` chỉ là chi nhánh chính, KHÔNG dùng để lọc
 *   + User có branch chứa target branch_id sẽ nhận thông báo
 *
 * @param array $roles Danh sách roles cần lấy
 * @param int|null $branch_id ID chi nhánh cần lọc (từ invoice/booking)
 * @return array User IDs
 */
function checkin_push_get_users_by_roles_and_branch($roles, $branch_id = null) {
    global $wpdb;

    // Lấy tất cả users theo roles trước
    $all_user_ids = checkin_push_get_users_by_roles($roles);

    // Nếu không bật branch mode hoặc không có branch_id -> trả về tất cả
    if (!checkin_push_is_branch_mode_enabled() || empty($branch_id)) {
        checkin_mkt192_push_log('🏢 BRANCH FILTER: Bỏ qua', [
            'branch_mode' => checkin_push_is_branch_mode_enabled() ? 'ON' : 'OFF',
            'branch_id'   => $branch_id,
            'reason'      => empty($branch_id) ? 'Không có branch_id' : 'Branch mode tắt'
        ]);
        return $all_user_ids;
    }

    if (empty($all_user_ids)) {
        return [];
    }

    // Lọc users thuộc chi nhánh này từ bảng staff
    // Chỉ dựa vào cột `branch` (JSON array), KHÔNG dựa vào `branch_id` (chi nhánh chính)
    $table        = $wpdb->prefix . 'checkin_mkt192_staff';
    $placeholders = implode(',', array_fill(0, count($all_user_ids), '%d'));
    $branch_id    = intval($branch_id);

    // Query: tìm staff có user_id trong danh sách VÀ branch JSON chứa target branch_id
    // Các pattern cần match:
    // - [1,2,3] -> số không có quotes
    // - ["1","2","3"] -> string có quotes
    // - [1] hoặc ["1"] -> single element
    $query = $wpdb->prepare(
        "SELECT user_id FROM $table
         WHERE user_id IN ($placeholders)
         AND (
             branch LIKE %s
             OR branch LIKE %s
             OR branch LIKE %s
             OR branch LIKE %s
             OR branch LIKE %s
             OR branch LIKE %s
             OR branch = %s
             OR branch = %s
         )",
        ...array_merge(
            $all_user_ids,
            [
                // Number format: [1,2,3]
                '[' . $branch_id . ',%',           // [1,... - đầu array
                '%,' . $branch_id . ',%',          // ,1,... - giữa array
                '%,' . $branch_id . ']',           // ...,1] - cuối array
                // String format: ["1","2","3"]
                '%"' . $branch_id . '"%',          // "1" anywhere
                // Single element
                '[' . $branch_id . ']',            // [1] - single number
                '["' . $branch_id . '"]',          // ["1"] - single string
                // Exact match (legacy - số đơn lẻ)
                (string) $branch_id,               // just "1"
                '"' . $branch_id . '"'             // just "\"1\""
            ]
        )
    );

    $filtered_ids = $wpdb->get_col($query);

    checkin_mkt192_push_log('🏢 LỌC THEO CHI NHÁNH', [
        'branch_id'      => $branch_id,
        'roles'          => $roles,
        'tổng_users'     => count($all_user_ids),
        'all_user_ids'   => $all_user_ids,
        'sau_lọc'        => count($filtered_ids),
        'user_ids_lọc'   => $filtered_ids,
        'query'          => $query
    ]);

    return array_map('intval', $filtered_ids);
}

// =============================================================================
// 📅 BOOKING NOTIFICATIONS
// =============================================================================

/**
 * Notify staff about new booking
 */
function checkin_push_notify_booking($staff_user_id, $booking) {
    if (!checkin_push_is_enabled()) return;
    if (!checkin_push_is_notification_enabled('booking')) return;

    $booking_id  = $booking['id_booking']     ?? '';
    $phone       = $booking['customer_phone'] ?? '';
    $branch_id   = $booking['branch_id']      ?? null;
    $url_params  = $booking_id ? "booking_id={$booking_id}" : ($phone ? "phone={$phone}" : '');

    // Get notification settings
    $settings = checkin_push_get_notification_settings('booking');

    // Kiểm tra nếu không có roles nào được chọn thì bỏ qua
    if (empty($settings['roles'])) {
        checkin_mkt192_push_log('📅 BOOKING: Bỏ qua - không có vai trò nào được cấu hình');
        return;
    }

    // Lấy tên nhân viên từ staff_user_id
    $staff_name = '';
    if (!empty($staff_user_id)) {
        $staff_user = get_userdata($staff_user_id);
        if ($staff_user) {
            $staff_name = $staff_user->display_name;
        }
    }

    $content = checkin_push_build_notification_content('booking', [
        'customer_name' => $booking['customer_name'] ?? '',
        'staff_name'    => $staff_name,
        'booking_time'  => $booking['booking_time']  ?? '',
    ], $branch_id);

    // Notify staff - chỉ gửi nếu vai trò staff có trong settings VÀ thuộc chi nhánh (nếu bật đa chi nhánh)
    $staff_ids = checkin_push_filter_users_by_roles_and_branch([$staff_user_id], $settings['roles'], $branch_id);
    if (!empty($staff_ids)) {
        checkin_push_send_to_users($staff_ids, [
            'title' => $content['title'],
            'body'  => $content['body'],
            'url'   => home_url('/app-tho?view=bookings' . ($url_params ? "&{$url_params}" : '')),
            'data'  => [
                'type'       => 'booking',
                'booking_id' => $booking_id
            ]
        ]);
    }

    // Notify managers based on settings roles (lọc theo chi nhánh nếu bật đa chi nhánh)
    $roles = array_intersect($settings['roles'], ['administrator']);
    if (!empty($roles)) {
        $manager_ids = array_diff(
            checkin_push_get_users_by_roles_and_branch($roles, $branch_id),
            [$staff_user_id]
        );
        if (!empty($manager_ids)) {
            checkin_push_send_to_users($manager_ids, [
                'title' => $content['title'],
                'body'  => $content['body'],
                'url'   => home_url('/app-tho?view=bookings' . ($url_params ? "&{$url_params}" : '')),
                'data'  => [
                    'type'       => 'booking',
                    'booking_id' => $booking_id
                ]
            ]);
        }
    }
}

/**
 * Notify about booking cancellation
 */
function checkin_push_notify_booking_cancelled($staff_user_id, $booking) {
    if (!checkin_push_is_enabled()) return;
    if (!checkin_push_is_notification_enabled('booking_cancelled')) return;

    $booking_id  = $booking['id_booking']     ?? '';
    $phone       = $booking['customer_phone'] ?? '';
    $branch_id   = $booking['branch_id']      ?? null;
    $url_params  = $booking_id ? "booking_id={$booking_id}" : ($phone ? "phone={$phone}" : '');

    // Get notification settings
    $settings = checkin_push_get_notification_settings('booking_cancelled');

    // Kiểm tra nếu không có roles nào được chọn thì bỏ qua
    if (empty($settings['roles'])) {
        checkin_mkt192_push_log('❌ BOOKING_CANCELLED: Bỏ qua - không có vai trò nào được cấu hình');
        return;
    }

    // Lấy tên nhân viên từ staff_user_id
    $staff_name = '';
    if (!empty($staff_user_id)) {
        $staff_user = get_userdata($staff_user_id);
        if ($staff_user) {
            $staff_name = $staff_user->display_name;
        }
    }

    $content = checkin_push_build_notification_content('booking_cancelled', [
        'customer_name' => $booking['customer_name'] ?? '',
        'staff_name'    => $staff_name,
        'booking_time'  => $booking['booking_time']  ?? '',
    ], $branch_id);

    // Notify staff - chỉ gửi nếu vai trò staff có trong settings VÀ thuộc chi nhánh (nếu bật đa chi nhánh)
    $staff_ids = checkin_push_filter_users_by_roles_and_branch([$staff_user_id], $settings['roles'], $branch_id);
    if (!empty($staff_ids)) {
        checkin_push_send_to_users($staff_ids, [
            'title' => $content['title'],
            'body'  => $content['body'],
            'url'   => home_url('/app-tho?view=bookings' . ($url_params ? "&{$url_params}" : '')),
            'data'  => [
                'type'       => 'booking_cancelled',
                'booking_id' => $booking_id
            ]
        ]);
    }

    // Notify administrators based on settings roles (lọc theo chi nhánh nếu bật đa chi nhánh)
    $roles = array_intersect($settings['roles'], ['administrator']);
    if (!empty($roles)) {
        $manager_ids = array_diff(
            checkin_push_get_users_by_roles_and_branch($roles, $branch_id),
            [$staff_user_id]
        );
        if (!empty($manager_ids)) {
            checkin_push_send_to_users($manager_ids, [
                'title' => $content['title'],
                'body'  => $content['body'],
                'url'   => home_url('/app-tho?view=bookings' . ($url_params ? "&{$url_params}" : '')),
                'data'  => [
                    'type'       => 'booking_cancelled',
                    'booking_id' => $booking_id
                ]
            ]);
        }
    }
}

// =============================================================================
// 🧾 INVOICE NOTIFICATIONS
// =============================================================================

/**
 * Notify about invoice surcharge (truy thu)
 * Cả Thợ và Quản Lý đều nhận được thông báo này
 */
function checkin_push_notify_invoice_surcharge($staff_user_id, $invoice) {
    if (!checkin_push_is_enabled()) return;
    if (!checkin_push_is_notification_enabled('invoice_surcharge')) return;

    $invoice_id   = $invoice['invoice_id'] ?? '';
    $branch_id    = $invoice['branch_id']  ?? null;
    $notified_ids = [];

    // Get notification settings
    $settings = checkin_push_get_notification_settings('invoice_surcharge');

    // Kiểm tra nếu không có roles nào được chọn thì bỏ qua
    if (empty($settings['roles'])) {
        checkin_mkt192_push_log('⚠️ INVOICE_SURCHARGE: Bỏ qua - không có vai trò nào được cấu hình');
        return;
    }

    // Lấy tên nhân viên từ staff_user_id
    $staff_name = '';
    if (!empty($staff_user_id)) {
        $staff_user = get_userdata($staff_user_id);
        if ($staff_user) {
            $staff_name = $staff_user->display_name;
        }
    }

    $content = checkin_push_build_notification_content('invoice_surcharge', [
        'invoice_id'       => $invoice_id,
        'surcharge_amount' => number_format($invoice['surcharge_amount'] ?? 0),
        'staff_name'       => $staff_name,
    ], $branch_id);

    // Notify staff - chỉ gửi nếu vai trò staff có trong settings VÀ thuộc chi nhánh (nếu bật đa chi nhánh)
    if (!empty($staff_user_id)) {
        $staff_ids = checkin_push_filter_users_by_roles_and_branch([$staff_user_id], $settings['roles'], $branch_id);
        if (!empty($staff_ids)) {
            checkin_push_send_to_users($staff_ids, [
                'title' => $content['title'],
                'body'  => $content['body'],
                'url'   => home_url('/app-tho?view=invoices&invoice_id=' . $invoice_id),
                'data'  => [
                    'type'       => 'invoice_surcharge',
                    'invoice_id' => $invoice_id
                ]
            ]);
            $notified_ids[] = $staff_user_id;
        }
    }

    // Notify administrators based on settings roles (lọc theo chi nhánh nếu bật đa chi nhánh)
    $roles = array_intersect($settings['roles'], ['administrator', 'cashier']);
    if (!empty($roles)) {
        $manager_ids = array_diff(
            checkin_push_get_users_by_roles_and_branch($roles, $branch_id),
            $notified_ids
        );
        if (!empty($manager_ids)) {
            checkin_push_send_to_users($manager_ids, [
                'title' => $content['title'],
                'body'  => $content['body'],
                'url'   => home_url('/app-tho?view=invoices&invoice_id=' . $invoice_id),
                'data'  => [
                    'type'       => 'invoice_surcharge',
                    'invoice_id' => $invoice_id
                ]
            ]);
        }
    }
}

/**
 * Notify about invoice deletion
 * Khi bật đa chi nhánh: chỉ gửi cho administrators thuộc chi nhánh của hóa đơn
 */
function checkin_push_notify_invoice_deleted($invoice) {
    if (!checkin_push_is_enabled()) return;
    if (!checkin_push_is_notification_enabled('invoice_deleted')) return;

    $invoice_id = $invoice['invoice_id'] ?? '';
    $deleted_by = $invoice['deleted_by'] ?? 'Ai đó';
    $branch_id  = $invoice['branch_id']  ?? null;

    // Get notification settings
    $settings = checkin_push_get_notification_settings('invoice_deleted');

    // Kiểm tra nếu không có roles nào được chọn thì bỏ qua
    if (empty($settings['roles'])) {
        checkin_mkt192_push_log('🗑️ INVOICE_DELETED: Bỏ qua - không có vai trò nào được cấu hình');
        return;
    }

    $roles = array_intersect($settings['roles'], ['administrator', 'cashier']);

    // Lọc administrators theo chi nhánh nếu bật đa chi nhánh
    $manager_ids = checkin_push_get_users_by_roles_and_branch($roles, $branch_id);
    if (empty($manager_ids)) return;

    $content = checkin_push_build_notification_content('invoice_deleted', [
        'invoice_id' => $invoice_id,
        'deleted_by' => $deleted_by,
    ], $branch_id);

    return checkin_push_send_to_users($manager_ids, [
        'title' => $content['title'],
        'body'  => $content['body'],
        'url'   => home_url('/app-tho?view=invoices'),
        'data'  => [
            'type'       => 'invoice_deleted',
            'invoice_id' => $invoice_id
        ]
    ]);
}

/**
 * Notify about payment success
 * Chỉ gửi cho Staff và Manager (bỏ Cashier để giảm thông báo)
 * Khi bật đa chi nhánh: chỉ gửi cho managers thuộc chi nhánh của hóa đơn
 */
function checkin_push_notify_payment_success($staff_user_id, $invoice) {
    try {
        checkin_mkt192_push_log('📥 PAYMENT_SUCCESS: Nhận yêu cầu thông báo thanh toán', [
            'staff_user_id' => $staff_user_id,
            'invoice'       => $invoice
        ]);

        $push_enabled = checkin_push_is_enabled();
        checkin_mkt192_push_log('📥 PAYMENT_SUCCESS: Push enabled check', ['enabled' => $push_enabled]);

        if (!$push_enabled) {
            checkin_mkt192_push_log('⚠️ PAYMENT_SUCCESS: Push notifications bị tắt');
            return;
        }

        $notification_enabled = checkin_push_is_notification_enabled('payment_success');
        checkin_mkt192_push_log('📥 PAYMENT_SUCCESS: Notification enabled check', ['enabled' => $notification_enabled]);

        if (!$notification_enabled) {
            checkin_mkt192_push_log('⚠️ PAYMENT_SUCCESS: Loại thông báo này bị tắt');
            return;
        }

        $invoice_id   = $invoice['invoice_id'] ?? '';
        $branch_id    = $invoice['branch_id']  ?? null;
    $notified_ids     = [];

    // Get notification settings
    $settings = checkin_push_get_notification_settings('payment_success');

    // Kiểm tra nếu không có roles nào được chọn thì bỏ qua
    if (empty($settings['roles'])) {
        checkin_mkt192_push_log('💰 PAYMENT_SUCCESS: Bỏ qua - không có vai trò nào được cấu hình');
        return;
    }

    $content = checkin_push_build_notification_content('payment_success', [
        'invoice_id' => $invoice_id,
        'total'      => number_format($invoice['total'] ?? 0),
    ], $branch_id);

    checkin_mkt192_push_log('💰 PAYMENT_SUCCESS: Settings loaded', [
        'roles'      => $settings['roles'],
        'enabled'    => $settings['enabled'] ?? true,
        'branch_id'  => $branch_id
    ]);

    // Notify staff - chỉ gửi nếu vai trò staff có trong settings VÀ thuộc chi nhánh (nếu bật đa chi nhánh)
    if (!empty($staff_user_id)) {
        $staff_ids = checkin_push_filter_users_by_roles_and_branch([$staff_user_id], $settings['roles'], $branch_id);
        checkin_mkt192_push_log('💰 PAYMENT_SUCCESS: Staff filter result', [
            'input_staff_id' => $staff_user_id,
            'filtered_ids'   => $staff_ids
        ]);
        if (!empty($staff_ids)) {
            checkin_push_send_to_users($staff_ids, [
                'title' => $content['title'],
                'body'  => $content['body'],
                'url'   => home_url('/app-tho?view=invoices&invoice_id=' . $invoice_id),
                'data'  => [
                    'type'       => 'payment_success',
                    'invoice_id' => $invoice_id
                ]
            ]);
            $notified_ids[] = $staff_user_id;
        }
    }

    // Notify administrators based on settings roles (bỏ cashier - cashier chỉ nhận thông báo truy thu và inventory)
    // Khi bật đa chi nhánh: chỉ gửi cho administrators thuộc chi nhánh của hóa đơn
    $roles = array_intersect($settings['roles'], ['administrator']);
    checkin_mkt192_push_log('💰 PAYMENT_SUCCESS: Admin roles check', [
        'settings_roles' => $settings['roles'],
        'intersect_with' => ['administrator'],
        'result_roles'   => $roles
    ]);

    if (!empty($roles)) {
        $manager_ids = array_diff(
            checkin_push_get_users_by_roles_and_branch($roles, $branch_id),
            $notified_ids
        );

        checkin_mkt192_push_log('🏢 PAYMENT_SUCCESS: Managers sau lọc chi nhánh', [
            'branch_id'        => $branch_id,
            'branch_mode'      => checkin_push_is_branch_mode_enabled() ? 'ON' : 'OFF',
            'manager_ids'      => $manager_ids,
            'already_notified' => $notified_ids
        ]);

        if (!empty($manager_ids)) {
            checkin_push_send_to_users($manager_ids, [
                'title' => $content['title'],
                'body'  => $content['body'],
                'url'   => home_url('/app-tho?view=invoices&invoice_id=' . $invoice_id),
                'data'  => [
                    'type'       => 'payment_success',
                    'invoice_id' => $invoice_id
                ]
            ]);
        }
    } else {
        checkin_mkt192_push_log('⚠️ PAYMENT_SUCCESS: Không có administrator trong roles - không gửi cho quản lý');
    }

    } catch (Exception $e) {
        checkin_mkt192_push_log('❌ PAYMENT_SUCCESS: Exception', [
            'message' => $e->getMessage(),
            'file'    => $e->getFile(),
            'line'    => $e->getLine()
        ]);
    } catch (Error $e) {
        checkin_mkt192_push_log('❌ PAYMENT_SUCCESS: Error', [
            'message' => $e->getMessage(),
            'file'    => $e->getFile(),
            'line'    => $e->getLine()
        ]);
    }
}

// =============================================================================
// ⭐ REVIEW NOTIFICATIONS
// =============================================================================

/**
 * Notify about new review
 */
function checkin_push_notify_review($staff_user_id, $review) {
    if (!checkin_push_is_enabled()) return;
    if (!checkin_push_is_notification_enabled('review')) return;

    $invoice_id = $review['invoice_id'] ?? '';
    $branch_id  = $review['branch_id']  ?? null;
    $stars      = str_repeat('⭐', (int)$review['rating']);
    // Navigate to app-tho with review-detail view (read-only mode for staff to view reviews)
    $review_url = home_url('/app-tho?view=review-detail&invoice_id=' . urlencode($invoice_id));

    // Get notification settings
    $settings = checkin_push_get_notification_settings('review');

    // Kiểm tra nếu không có roles nào được chọn thì bỏ qua
    if (empty($settings['roles'])) {
        checkin_mkt192_push_log('⭐ REVIEW: Bỏ qua - không có vai trò nào được cấu hình');
        return;
    }

    // Lấy tên thợ từ review data - dùng chung cho tất cả recipients
    $staff_name = $review['staff_name'] ?? '';

    // Build notification content với đầy đủ variables để hỗ trợ template tùy chỉnh
    $content = checkin_push_build_notification_content('review', [
        'customer_name' => $review['customer_name'] ?? '',
        'rating_stars'  => $stars,
        'staff_name'    => $staff_name,
    ], $branch_id);

    // Notify staff - chỉ gửi nếu vai trò staff có trong settings VÀ thuộc chi nhánh (nếu bật đa chi nhánh)
    $staff_ids = checkin_push_filter_users_by_roles_and_branch([$staff_user_id], $settings['roles'], $branch_id);
    if (!empty($staff_ids)) {
        checkin_push_send_to_users($staff_ids, [
            'title' => $content['title'],
            'body'  => $content['body'],
            'url'   => $review_url,
            'data'  => [
                'type'       => 'review',
                'rating'     => $review['rating'],
                'invoice_id' => $invoice_id
            ]
        ]);
    }

    // Notify administrators based on settings roles (lọc theo chi nhánh nếu bật đa chi nhánh)
    $roles = array_intersect($settings['roles'], ['administrator']);
    if (!empty($roles)) {
        $manager_ids = array_diff(
            checkin_push_get_users_by_roles_and_branch($roles, $branch_id),
            [$staff_user_id]
        );
        if (!empty($manager_ids)) {
            // Admin cũng dùng cùng content đã build với đầy đủ variables
            checkin_push_send_to_users($manager_ids, [
                'title' => $content['title'],
                'body'  => $content['body'],
                'url'   => $review_url,
                'data'  => [
                    'type'       => 'review',
                    'rating'     => $review['rating'],
                    'invoice_id' => $invoice_id
                ]
            ]);
        }
    }
}

// =============================================================================
// 📝 APPROVAL NOTIFICATIONS (Đơn xin phép - dùng chung cho tất cả loại đơn)
// =============================================================================

/**
 * Notify managers about new approval request
 * Quản lý nhận thông báo khi có đơn mới cần duyệt
 * Khi bật đa chi nhánh: chỉ gửi cho managers thuộc chi nhánh của nhân viên
 *
 * @param string $staff_name Tên nhân viên gửi đơn
 * @param string $request_type Loại đơn (nghỉ phép, tăng ca, công tác...)
 * @param int|null $request_id ID của đơn trong approval_request
 * @param int|null $branch_id ID chi nhánh của nhân viên
 */
function checkin_push_notify_approval_request($staff_name, $request_type, $request_id = null, $branch_id = null) {
    if (!checkin_push_is_enabled()) return;
    if (!checkin_push_is_notification_enabled('approval_request')) return;

    // Get notification settings
    $settings = checkin_push_get_notification_settings('approval_request');

    // Kiểm tra nếu không có roles nào được chọn thì bỏ qua
    if (empty($settings['roles'])) {
        checkin_mkt192_push_log('📝 APPROVAL_REQUEST: Bỏ qua - không có vai trò nào được cấu hình');
        return;
    }

    $roles = array_intersect($settings['roles'], ['administrator']);

    // Lọc administrators theo chi nhánh nếu bật đa chi nhánh
    $manager_ids = checkin_push_get_users_by_roles_and_branch($roles, $branch_id);
    if (empty($manager_ids)) return;

    $content = checkin_push_build_notification_content('approval_request', [
        'staff_name'   => $staff_name,
        'request_type' => $request_type,
    ], $branch_id);

    return checkin_push_send_to_users($manager_ids, [
        'title' => $content['title'],
        'body'  => $content['body'],
        'url'   => home_url('/app-tho?view=dashboard'),
        'data'  => [
            'type'       => 'approval_request',
            'request_id' => $request_id
        ]
    ]);
}

/**
 * Notify staff about approval result
 * Thợ nhận thông báo khi đơn được duyệt/từ chối
 *
 * @param int $staff_user_id WordPress user ID của nhân viên
 * @param string $request_type Loại đơn (nghỉ phép, tăng ca, công tác...)
 * @param string $status Trạng thái: 'approved' hoặc 'rejected'
 * @param int|null $request_id ID của đơn trong approval_request
 */
function checkin_push_notify_approval_result($staff_user_id, $request_type, $status, $request_id = null) {
    if (!checkin_push_is_enabled()) return;
    if (!checkin_push_is_notification_enabled('approval_result')) return;

    // Get notification settings
    $settings = checkin_push_get_notification_settings('approval_result');

    // Kiểm tra nếu không có roles nào được chọn thì bỏ qua
    if (empty($settings['roles'])) {
        checkin_mkt192_push_log('✅ APPROVAL_RESULT: Bỏ qua - không có vai trò nào được cấu hình');
        return;
    }

    // Lọc user theo roles settings
    $filtered_ids = checkin_push_filter_users_by_roles([$staff_user_id], $settings['roles']);
    if (empty($filtered_ids)) {
        checkin_mkt192_push_log('✅ APPROVAL_RESULT: Bỏ qua - user không thuộc vai trò cấu hình');
        return;
    }

    $approved    = $status === 'approved';
    $icon        = $approved ? '✅' : '❌';
    $status_text = $approved ? 'được duyệt' : 'bị từ chối';

    $content = checkin_push_build_notification_content('approval_result', [
        'request_type' => $request_type,
        'status_icon'  => $icon,
        'status_text'  => $status_text,
    ]);

    return checkin_push_send_to_users($filtered_ids, [
        'title' => $content['title'],
        'body'  => $content['body'],
        'url'   => home_url('/app-tho?view=dashboard'),
        'data'  => [
            'type'       => 'approval_result',
            'status'     => $status,
            'request_id' => $request_id
        ]
    ]);
}

// =============================================================================
// 💵 SALARY NOTIFICATIONS
// =============================================================================

/**
 * Notify staff about salary slip
 * Thợ: chuyển về user-profile?tab=salary
 */
function checkin_push_notify_salary_slip($staff_name, $period) {
    if (!checkin_push_is_enabled()) return;
    if (!checkin_push_is_notification_enabled('salary_slip')) return;

    // Get notification settings
    $settings = checkin_push_get_notification_settings('salary_slip');

    // Kiểm tra nếu không có roles nào được chọn thì bỏ qua
    if (empty($settings['roles'])) {
        checkin_mkt192_push_log('💵 SALARY_SLIP: Bỏ qua - không có vai trò nào được cấu hình');
        return;
    }

    global $wpdb;
    $staff_table = $wpdb->prefix . 'checkin_mkt192_staff';

    $staff = $wpdb->get_row($wpdb->prepare(
        "SELECT user_id FROM $staff_table WHERE display_name = %s",
        $staff_name
    ));

    if (!$staff || !$staff->user_id) return;

    // Lọc user theo roles settings
    $filtered_ids = checkin_push_filter_users_by_roles([$staff->user_id], $settings['roles']);
    if (empty($filtered_ids)) {
        checkin_mkt192_push_log('💵 SALARY_SLIP: Bỏ qua - user không thuộc vai trò cấu hình');
        return;
    }

    $parts = explode('-', $period);
    $month = $parts[1] ?? '';
    $year  = $parts[0] ?? '';

    $content = checkin_push_build_notification_content('salary_slip', [
        'month' => $month,
        'year'  => $year,
    ]);

    return checkin_push_send_to_users($filtered_ids, [
        'title' => $content['title'],
        'body'  => $content['body'],
        'url'   => home_url('/user-profile?tab=salary'),
        'data'  => [
            'type'   => 'salary_slip',
            'period' => $period
        ]
    ]);
}

/**
 * Notify staff about salary payment
 * Thợ: chuyển về user-profile?tab=salary
 */
function checkin_push_notify_salary_payment($staff_name, $period) {
    if (!checkin_push_is_enabled()) return;
    if (!checkin_push_is_notification_enabled('salary_payment')) return;

    // Get notification settings
    $settings = checkin_push_get_notification_settings('salary_payment');

    // Check if any roles are configured
    if (empty($settings['roles'])) {
        checkin_mkt192_push_log('💵 SALARY_PAYMENT: Bỏ qua - không có vai trò nào được cấu hình');
        return;
    }

    global $wpdb;
    $staff_table = $wpdb->prefix . 'checkin_mkt192_staff';

    $staff = $wpdb->get_row($wpdb->prepare(
        "SELECT user_id FROM $staff_table WHERE display_name = %s",
        $staff_name
    ));

    if (!$staff || !$staff->user_id) return;

    // Filter user by settings roles
    $filtered_ids = checkin_push_filter_users_by_roles([$staff->user_id], $settings['roles']);
    if (empty($filtered_ids)) {
        checkin_mkt192_push_log('💵 SALARY_PAYMENT: Bỏ qua - user không thuộc vai trò cấu hình');
        return;
    }

    $parts = explode('-', $period);
    $month = $parts[1] ?? '';
    $year  = $parts[0] ?? '';

    $content = checkin_push_build_notification_content('salary_payment', [
        'month' => $month,
        'year'  => $year,
    ]);

    return checkin_push_send_to_users($filtered_ids, [
        'title' => $content['title'],
        'body'  => $content['body'],
        'url'   => home_url('/user-profile?tab=salary'),
        'data'  => [
            'type'   => 'salary_payment',
            'period' => $period
        ]
    ]);
}

/**
 * Notify managers about salary updates (batch salary created/updated)
 * Quản lý: chuyển về admin-setting-frontend
 */
function checkin_push_notify_salary_batch($period, $action = 'created') {
    if (!checkin_push_is_enabled()) return;
    if (!checkin_push_is_notification_enabled('salary_batch')) return;

    // Get notification settings
    $settings = checkin_push_get_notification_settings('salary_batch');

    // Check if any roles are configured
    if (empty($settings['roles'])) {
        checkin_mkt192_push_log('💵 SALARY_BATCH: Bỏ qua - không có vai trò nào được cấu hình');
        return;
    }

    $roles = array_intersect($settings['roles'], ['administrator']);
    if (empty($roles)) {
        checkin_mkt192_push_log('💵 SALARY_BATCH: Bỏ qua - không có vai trò administrator được cấu hình');
        return;
    }

    $manager_ids = checkin_push_get_users_by_roles($roles);
    if (empty($manager_ids)) return;

    $parts       = explode('-', $period);
    $month       = $parts[1] ?? '';
    $year        = $parts[0] ?? '';
    $action_text = $action === 'created' ? 'đã được tạo' : 'đã cập nhật';

    $content = checkin_push_build_notification_content('salary_batch', [
        'month'       => $month,
        'year'        => $year,
        'action_text' => $action_text,
    ]);

    return checkin_push_send_to_users($manager_ids, [
        'title' => $content['title'],
        'body'  => $content['body'],
        'url'   => home_url('/admin-setting-frontend?tab=salary'),
        'data'  => [
            'type'   => 'salary_batch',
            'period' => $period,
            'action' => $action
        ]
    ]);
}

/**
 * Notify admin when staff confirms salary slip
 * Admin: chuyển về admin-setting-frontend?tab=salary
 *
 * @param string $staff_name Tên nhân viên
 * @param string $period Kỳ lương (YYYY-MM)
 * @param int|null $branch_id Chi nhánh của nhân viên
 */
function checkin_push_notify_salary_slip_confirmed($staff_name, $period, $branch_id = null) {
    checkin_mkt192_push_log('💵 SALARY_SLIP_CONFIRMED: Bắt đầu xử lý', [
        'staff_name' => $staff_name,
        'period'     => $period,
        'branch_id'  => $branch_id
    ]);

    if (!checkin_push_is_enabled()) {
        checkin_mkt192_push_log('💵 SALARY_SLIP_CONFIRMED: Bỏ qua - Push notification bị tắt');
        return;
    }
    if (!checkin_push_is_notification_enabled('salary_slip_confirmed')) {
        checkin_mkt192_push_log('💵 SALARY_SLIP_CONFIRMED: Bỏ qua - Loại thông báo salary_slip_confirmed bị tắt');
        return;
    }

    // Get notification settings
    $settings = checkin_push_get_notification_settings('salary_slip_confirmed');
    checkin_mkt192_push_log('💵 SALARY_SLIP_CONFIRMED: Settings', $settings);

    // Check if any roles are configured
    if (empty($settings['roles'])) {
        checkin_mkt192_push_log('💵 SALARY_SLIP_CONFIRMED: Bỏ qua - không có vai trò nào được cấu hình');
        return;
    }

    // Lấy admin/manager theo chi nhánh
    $admin_ids = checkin_push_get_users_by_roles_and_branch($settings['roles'], $branch_id);
    if (empty($admin_ids)) {
        checkin_mkt192_push_log('💵 SALARY_SLIP_CONFIRMED: Không tìm thấy admin nào để gửi thông báo');
        return;
    }

    $parts = explode('-', $period);
    $month = $parts[1] ?? '';
    $year  = $parts[0] ?? '';

    $content = checkin_push_build_notification_content('salary_slip_confirmed', [
        'staff_name' => $staff_name,
        'month'      => $month,
        'year'       => $year,
    ], $branch_id);

    checkin_mkt192_push_log('💵 SALARY_SLIP_CONFIRMED: Gửi thông báo', [
        'staff_name' => $staff_name,
        'period'     => $period,
        'admin_ids'  => $admin_ids,
        'branch_id'  => $branch_id,
        'content'    => $content
    ]);

    return checkin_push_send_to_users($admin_ids, [
        'title' => $content['title'],
        'body'  => $content['body'],
        'url'   => home_url('/admin-setting-frontend?tab=salary'),
        'data'  => [
            'type'       => 'salary_slip_confirmed',
            'staff_name' => $staff_name,
            'period'     => $period
        ]
    ]);
}

/**
 * Notify admin when staff confirms salary payment
 * Admin: chuyển về admin-setting-frontend?tab=salary
 *
 * @param string $staff_name Tên nhân viên
 * @param string $period Kỳ lương (YYYY-MM)
 * @param string $status Trạng thái xác nhận (received/disputed)
 * @param int|null $branch_id Chi nhánh của nhân viên
 */
function checkin_push_notify_salary_payment_confirmed($staff_name, $period, $status = 'received', $branch_id = null) {
    if (!checkin_push_is_enabled()) return;
    if (!checkin_push_is_notification_enabled('salary_payment_confirmed')) return;

    // Get notification settings
    $settings = checkin_push_get_notification_settings('salary_payment_confirmed');

    // Check if any roles are configured
    if (empty($settings['roles'])) {
        checkin_mkt192_push_log('💵 SALARY_PAYMENT_CONFIRMED: Bỏ qua - không có vai trò nào được cấu hình');
        return;
    }

    // Lấy admin/manager theo chi nhánh
    $admin_ids = checkin_push_get_users_by_roles_and_branch($settings['roles'], $branch_id);
    if (empty($admin_ids)) {
        checkin_mkt192_push_log('💵 SALARY_PAYMENT_CONFIRMED: Không tìm thấy admin nào để gửi thông báo');
        return;
    }

    $parts       = explode('-', $period);
    $month       = $parts[1] ?? '';
    $year        = $parts[0] ?? '';
    $status_text = $status === 'received' ? 'đã nhận đủ lương' : 'chưa nhận được lương';

    $content = checkin_push_build_notification_content('salary_payment_confirmed', [
        'staff_name' => $staff_name,
        'month'      => $month,
        'year'       => $year,
        'status'     => $status_text,
    ], $branch_id);

    checkin_mkt192_push_log('💵 SALARY_PAYMENT_CONFIRMED: Gửi thông báo', [
        'staff_name' => $staff_name,
        'period'     => $period,
        'status'     => $status,
        'admin_ids'  => $admin_ids,
        'branch_id'  => $branch_id
    ]);

    return checkin_push_send_to_users($admin_ids, [
        'title' => $content['title'],
        'body'  => $content['body'],
        'url'   => home_url('/admin-setting-frontend?tab=salary'),
        'data'  => [
            'type'       => 'salary_payment_confirmed',
            'staff_name' => $staff_name,
            'period'     => $period,
            'status'     => $status
        ]
    ]);
}

// =============================================================================
// 📢 BROADCAST NOTIFICATIONS
// =============================================================================

// =============================================================================
// 📦 INVENTORY NOTIFICATIONS (Phiếu xuất/nhập kho)
// =============================================================================

/**
 * Notify managers about new inventory transaction (pending approval)
 * Quản lý và Admin nhận thông báo khi có phiếu xuất/nhập kho mới cần duyệt
 *
 * @param array $transaction Thông tin phiếu (transaction_id, type, staff_name, products..., branch_id)
 */
function checkin_push_notify_inventory_pending($transaction) {
    if (!checkin_push_is_enabled()) return;
    if (!checkin_push_is_notification_enabled('inventory_pending')) return;

    // Get notification settings
    $settings = checkin_push_get_notification_settings('inventory_pending');

    // Check if any roles are configured
    if (empty($settings['roles'])) {
        checkin_mkt192_push_log('📦 INVENTORY_PENDING: Bỏ qua - không có vai trò nào được cấu hình');
        return;
    }

    $transaction_id = $transaction['transaction_id'] ?? '';
    $type           = strtoupper($transaction['type'] ?? '');
    $type_text      = $type === 'IN' ? 'Nhập kho' : 'Xuất kho';
    $staff_name     = $transaction['staff_name']    ?? 'Nhân viên';
    $product_count  = $transaction['product_count'] ?? 0;
    $branch_id      = $transaction['branch_id']     ?? null;

    $roles = array_intersect($settings['roles'], ['administrator']);
    if (empty($roles)) {
        checkin_mkt192_push_log('📦 INVENTORY_PENDING: Bỏ qua - không có vai trò administrator được cấu hình');
        return;
    }

    // Lọc administrators theo chi nhánh nếu bật đa chi nhánh
    $manager_ids = checkin_push_get_users_by_roles_and_branch($roles, $branch_id);
    if (empty($manager_ids)) return;

    $content = checkin_push_build_notification_content('inventory_pending', [
        'staff_name'    => $staff_name,
        'type_text'     => $type_text,
        'product_count' => $product_count,
    ], $branch_id);

    checkin_mkt192_push_log('📦 INVENTORY_PENDING: Gửi thông báo phiếu mới', [
        'transaction_id' => $transaction_id,
        'manager_ids'    => $manager_ids,
        'branch_id'      => $branch_id
    ]);

    return checkin_push_send_to_users($manager_ids, [
        'title' => $content['title'],
        'body'  => $content['body'],
        'url'   => home_url('/app-tho?view=inventory&tab=transactions'),
        'data'  => [
            'type'           => 'inventory_pending',
            'transaction_id' => $transaction_id
        ]
    ]);
}

/**
 * Notify cashier and transaction creator about approved inventory transaction
 * Thu Ngân và người tạo phiếu nhận thông báo khi phiếu được duyệt
 *
 * @param array $transaction Thông tin phiếu (transaction_id, type, staff_name, staff_user_id, approved_by, branch_id...)
 */
function checkin_push_notify_inventory_approved($transaction) {
    if (!checkin_push_is_enabled()) return;
    if (!checkin_push_is_notification_enabled('inventory_approved')) return;

    // Get notification settings
    $settings = checkin_push_get_notification_settings('inventory_approved');

    // Check if any roles are configured
    if (empty($settings['roles'])) {
        checkin_mkt192_push_log('📦 INVENTORY_APPROVED: Bỏ qua - không có vai trò nào được cấu hình');
        return;
    }

    $transaction_id = $transaction['transaction_id'] ?? '';
    $type           = strtoupper($transaction['type'] ?? '');
    $type_text      = $type === 'IN' ? 'Nhập kho' : 'Xuất kho';
    $approved_by    = $transaction['approved_by']   ?? 'Quản lý';
    $staff_user_id  = $transaction['staff_user_id'] ?? null;
    $product_count  = $transaction['product_count'] ?? 0;
    $branch_id      = $transaction['branch_id']     ?? null;

    $notified_ids = [];

    // Build content for creator
    $creator_content = checkin_push_build_notification_content('inventory_approved', [
        'transaction_id' => $transaction_id,
        'type_text'      => $type_text,
        'approved_by'    => $approved_by,
    ], $branch_id);

    // Notify the transaction creator (if not the one who approved) - filter by settings roles AND branch
    if (!empty($staff_user_id)) {
        $filtered_creator_ids = checkin_push_filter_users_by_roles_and_branch([$staff_user_id], $settings['roles'], $branch_id);
        if (!empty($filtered_creator_ids)) {
            checkin_push_send_to_users($filtered_creator_ids, [
                'title' => $creator_content['title'],
                'body'  => $creator_content['body'],
                'url'   => home_url('/app-tho?view=inventory&tab=transactions'),
                'data'  => [
                    'type'           => 'inventory_approved',
                    'transaction_id' => $transaction_id
                ]
            ]);
            $notified_ids[] = $staff_user_id;
        }
    }

    // Notify cashiers (Thu Ngân) based on settings roles - lọc theo chi nhánh nếu bật đa chi nhánh
    $cashier_roles = array_intersect($settings['roles'], ['cashier']);
    if (!empty($cashier_roles)) {
        $cashier_ids = array_diff(
            checkin_push_get_users_by_roles_and_branch($cashier_roles, $branch_id),
            $notified_ids
        );

        if (!empty($cashier_ids)) {
            // Build cashier-specific content
            $cashier_content = checkin_push_build_notification_content('inventory_approved', [
                'transaction_id' => $transaction_id,
                'type_text'      => $type_text,
                'approved_by'    => $approved_by,
                'product_count'  => $product_count,
            ], $branch_id);

            checkin_mkt192_push_log('💰 INVENTORY_APPROVED: Gửi thông báo cho Thu Ngân', [
                'transaction_id' => $transaction_id,
                'cashier_ids'    => $cashier_ids,
                'branch_id'      => $branch_id
            ]);

            checkin_push_send_to_users($cashier_ids, [
                'title' => $cashier_content['title'],
                'body'  => $cashier_content['body'],
                'url'   => home_url('/app-tho?view=inventory&tab=transactions'),
                'data'  => [
                    'type'           => 'inventory_approved',
                    'transaction_id' => $transaction_id
                ]
            ]);
        }
    }
}

/**
 * Backward compatibility aliases for inventory notifications
 */
function checkin_mkt192_notify_inventory_pending($transaction) {
    return checkin_push_notify_inventory_pending($transaction);
}

function checkin_mkt192_notify_inventory_approved($transaction) {
    return checkin_push_notify_inventory_approved($transaction);
}

/**
 * Broadcast notification to all or specific role
 */
function checkin_push_broadcast($notification, $role = null) {
    global $wpdb;

    if (!checkin_push_is_enabled()) {
        return ['success' => false, 'message' => 'Push notifications disabled'];
    }

    $table = $wpdb->prefix . 'checkin_mkt192_push_subscriptions';

    $sql = "SELECT DISTINCT ps.user_id
            FROM $table ps
            INNER JOIN {$wpdb->users} u ON ps.user_id = u.ID
            WHERE ps.is_active = 1";

    if ($role) {
        $sql .= $wpdb->prepare(
            " AND EXISTS (
                SELECT 1 FROM {$wpdb->usermeta} um
                WHERE um.user_id = ps.user_id
                AND um.meta_key = %s
                AND um.meta_value LIKE %s
            )",
            $wpdb->prefix . 'capabilities',
            '%"' . $role . '"%'
        );
    }

    $user_ids = $wpdb->get_col($sql);

    if (empty($user_ids)) {
        return ['success' => false, 'message' => 'No subscribers found'];
    }

    return checkin_push_send_to_users($user_ids, $notification);
}

// =============================================================================
// BACKWARD COMPATIBILITY ALIASES
// =============================================================================

// Keep old function names working
function checkin_mkt192_send_push_to_users($user_ids, $notification) {
    return checkin_push_send_to_users($user_ids, $notification);
}

function checkin_mkt192_notify_booking_to_staff($staff_user_id, $booking) {
    return checkin_push_notify_booking($staff_user_id, $booking);
}

function checkin_mkt192_notify_invoice_surcharge($staff_user_id, $invoice) {
    return checkin_push_notify_invoice_surcharge($staff_user_id, $invoice);
}

function checkin_mkt192_notify_new_review($staff_user_id, $review) {
    return checkin_push_notify_review($staff_user_id, $review);
}

function checkin_mkt192_notify_approval_request($staff_name, $request_type, $request_id = null, $branch_id = null) {
    return checkin_push_notify_approval_request($staff_name, $request_type, $request_id, $branch_id);
}

function checkin_mkt192_notify_approval_result($staff_user_id, $request_type, $status, $request_id = null) {
    return checkin_push_notify_approval_result($staff_user_id, $request_type, $status, $request_id);
}

function checkin_mkt192_notify_salary_batch($period, $action = 'created') {
    return checkin_push_notify_salary_batch($period, $action);
}

function checkin_mkt192_notify_salary_slip($staff_name, $period) {
    return checkin_push_notify_salary_slip($staff_name, $period);
}

function checkin_mkt192_notify_salary_payment($staff_name, $period) {
    return checkin_push_notify_salary_payment($staff_name, $period);
}

function checkin_mkt192_notify_booking_cancelled($staff_user_id, $booking) {
    return checkin_push_notify_booking_cancelled($staff_user_id, $booking);
}

function checkin_mkt192_notify_invoice_deleted($invoice) {
    return checkin_push_notify_invoice_deleted($invoice);
}

function checkin_mkt192_notify_payment_success($staff_user_id, $invoice) {
    return checkin_push_notify_payment_success($staff_user_id, $invoice);
}

function checkin_mkt192_broadcast_push($notification, $role = null) {
    return checkin_push_broadcast($notification, $role);
}

function checkin_mkt192_get_users_by_roles($roles) {
    return checkin_push_get_users_by_roles($roles);
}

function checkin_mkt192_set_onesignal_external_id($subscription_id, $user_id) {
    return checkin_push_set_external_id($subscription_id, $user_id);
}
