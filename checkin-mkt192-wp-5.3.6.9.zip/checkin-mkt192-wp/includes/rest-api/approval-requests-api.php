<?php

/**
 * REST API cho quản lý các đơn xin phép (Approval Requests)
 * Hỗ trợ các loại đơn: Đi trễ/Về sớm, Nghỉ phép, Tăng ca, Ứng lương
 */

// Load Lark notification functions
require_once plugin_dir_path(__FILE__) . '../lark/send_approval_request_notification.php';

add_action('rest_api_init', function () {
    // Tạo đơn mới - tất cả user đã login đều có thể tạo đơn cho chính mình
    register_rest_route('vg/v1', '/approval-requests', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_create_approval_request',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login'])
    ]);

    // Lấy danh sách đơn (admin/manager)
    register_rest_route('vg/v1', '/approval-requests', [
        'methods'             => 'GET',
        'callback'            => 'checkin_mkt192_get_approval_requests',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'approval.read'])
    ]);

    // Lấy đơn của user hiện tại - tất cả user đã login
    register_rest_route('vg/v1', '/my-approval-requests', [
        'methods'             => 'GET',
        'callback'            => 'checkin_mkt192_get_my_approval_requests',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login'])
    ]);

    // Lấy chi tiết đơn
    register_rest_route('vg/v1', '/approval-requests/(?P<id>\d+)', [
        'methods'             => 'GET',
        'callback'            => 'checkin_mkt192_get_approval_request_detail',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'approval.read'])
    ]);

    // Duyệt đơn
    register_rest_route('vg/v1', '/approval-requests/(?P<request_id>[a-zA-Z0-9\-_]+)/approve', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_approve_request',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'approval.approve'])
    ]);

    // Từ chối đơn
    register_rest_route('vg/v1', '/approval-requests/(?P<request_id>[a-zA-Z0-9\-_]+)/reject', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_reject_request',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'approval.reject'])
    ]);

    // Hủy đơn (chỉ chủ đơn)
    register_rest_route('vg/v1', '/approval-requests/(?P<request_id>[a-zA-Z0-9\-_]+)/cancel', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_cancel_request',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login'])
    ]);

    // Xóa đơn (admin)
    register_rest_route('vg/v1', '/approval-requests/(?P<request_id>[a-zA-Z0-9\-_]+)', [
        'methods'             => 'DELETE',
        'callback'            => 'checkin_mkt192_delete_request',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'approval.delete'])
    ]);

    // Backward compatibility: Lấy danh sách đơn nghỉ phép (legacy API)
    // Endpoint cũ từ leave-requests-api.php, giờ tích hợp vào đây
    register_rest_route('vg/v1', '/leave-requests', [
        'methods'             => 'GET',
        'callback'            => 'checkin_mkt192_get_leave_requests',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'leave.read'])
    ]);
});

/**
 * Generate unique request ID
 */
function generate_approval_request_id($wpdb, $table_name) {
    $date_prefix  = date('Ymd');
    $max_attempts = 5;
    $attempt      = 0;

    while ($attempt < $max_attempts) {
        // Lấy số thứ tự trong ngày
        $count = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table_name WHERE DATE(created_at) = CURDATE()"
        ));
        $sequence   = str_pad(($count + 1), 3, '0', STR_PAD_LEFT);
        $request_id = "REQ-{$date_prefix}-{$sequence}";

        // Kiểm tra trùng
        $exists = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table_name WHERE request_id = %s",
            $request_id
        ));

        if ($exists == 0) {
            return $request_id;
        }

        $attempt++;
    }

    // Fallback với random suffix
    return "REQ-{$date_prefix}-" . uniqid();
}

/**
 * Tạo đơn xin phép mới
 */
function checkin_mkt192_create_approval_request(WP_REST_Request $request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'checkin_mkt192_approval_requests';

    $data = $request->get_json_params();

    // Validate request_type
    $valid_types  = ['late_early', 'leave', 'overtime', 'salary_advance'];
    $request_type = sanitize_text_field($data['request_type'] ?? '');

    if (!in_array($request_type, $valid_types, true)) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Loại đơn không hợp lệ. Các loại đơn hỗ trợ: ' . implode(', ', $valid_types)
        ], 400);
    }

    // Get current user info
    $user    = wp_get_current_user();
    $user_id = $user->ID;

    // Lấy thông tin nhân viên từ helper function
    $staff = checkin_mkt192_get_staff_data($user_id);

    $staff_name = $staff ? $staff->display_name : $user->display_name;
    $branch     = $staff ? ($staff->branch ?? '') : '';

    // Lấy chi nhánh CHÍNH (primary branch) của nhân viên
    // Chi nhánh chính dùng để gửi thông báo cho quản lý đúng chi nhánh
    $branch_id = checkin_mkt192_get_staff_primary_branch_id($user_id);

    // Common fields
    $reason = sanitize_textarea_field($data['reason'] ?? '');
    if (empty($reason)) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Vui lòng nhập lý do'
        ], 400);
    }

    // Generate unique request_id
    $request_id = generate_approval_request_id($wpdb, $table_name);

    // Prepare insert data based on request_type
    $insert_data = [
        'request_id'   => $request_id,
        'request_type' => $request_type,
        'staff_name'   => $staff_name,
        'staff_id'     => $user_id,
        'request_date' => current_time('Y-m-d'),
        'reason'       => $reason,
        'status'       => 'pending',
        'branch'       => $branch,
        'created_at'   => current_time('mysql'),
        'updated_at'   => current_time('mysql')
    ];

    $format = ['%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%s'];

    // Type-specific validation and data
    switch ($request_type) {
        case 'late_early':
            $late_early_type = sanitize_text_field($data['late_early_type'] ?? '');
            if (!in_array($late_early_type, ['late', 'early'], true)) {
                return new WP_REST_Response([
                    'success' => false,
                    'message' => 'Loại đi trễ/về sớm không hợp lệ'
                ], 400);
            }

            $late_early_date = sanitize_text_field($data['late_early_date'] ?? '');
            if (empty($late_early_date)) {
                return new WP_REST_Response([
                    'success' => false,
                    'message' => 'Vui lòng chọn ngày'
                ], 400);
            }

            $late_early_minutes = intval($data['late_early_minutes'] ?? 0);
            if ($late_early_minutes <= 0 || $late_early_minutes > 480) {
                return new WP_REST_Response([
                    'success' => false,
                    'message' => 'Số phút không hợp lệ (1-480 phút)'
                ], 400);
            }

            $insert_data['late_early_type']    = $late_early_type;
            $insert_data['late_early_date']    = $late_early_date;
            $insert_data['late_early_minutes'] = $late_early_minutes;
            $format                            = array_merge($format, ['%s', '%s', '%d']);
            break;

        case 'leave':
            $leave_start_date = sanitize_text_field($data['leave_start_date'] ?? '');
            $leave_end_date   = sanitize_text_field($data['leave_end_date'] ?? '');

            if (empty($leave_start_date) || empty($leave_end_date)) {
                return new WP_REST_Response([
                    'success' => false,
                    'message' => 'Vui lòng chọn ngày bắt đầu và kết thúc nghỉ'
                ], 400);
            }

            if (strtotime($leave_end_date) < strtotime($leave_start_date)) {
                return new WP_REST_Response([
                    'success' => false,
                    'message' => 'Ngày kết thúc phải sau ngày bắt đầu'
                ], 400);
            }

            $leave_type = sanitize_text_field($data['leave_type'] ?? '');
            if (!in_array($leave_type, ['annual', 'unpaid', 'sick'], true)) {
                return new WP_REST_Response([
                    'success' => false,
                    'message' => 'Loại nghỉ phép không hợp lệ'
                ], 400);
            }

            // Tính tổng số ngày nghỉ
            $start            = new DateTime($leave_start_date);
            $end              = new DateTime($leave_end_date);
            $diff             = $start->diff($end);
            $leave_total_days = $diff->days + 1;

            $insert_data['leave_start_date'] = $leave_start_date;
            $insert_data['leave_end_date']   = $leave_end_date;
            $insert_data['leave_total_days'] = $leave_total_days;
            $insert_data['leave_type']       = $leave_type;
            $format                          = array_merge($format, ['%s', '%s', '%d', '%s']);
            break;

        case 'overtime':
            $overtime_date = sanitize_text_field($data['overtime_date'] ?? '');
            if (empty($overtime_date)) {
                return new WP_REST_Response([
                    'success' => false,
                    'message' => 'Vui lòng chọn ngày tăng ca'
                ], 400);
            }

            $overtime_start_time = sanitize_text_field($data['overtime_start_time'] ?? '');
            $overtime_end_time   = sanitize_text_field($data['overtime_end_time'] ?? '');

            if (empty($overtime_start_time) || empty($overtime_end_time)) {
                return new WP_REST_Response([
                    'success' => false,
                    'message' => 'Vui lòng chọn giờ bắt đầu và kết thúc'
                ], 400);
            }

            // Tính số giờ tăng ca
            $start_ts = strtotime($overtime_start_time);
            $end_ts   = strtotime($overtime_end_time);
            if ($end_ts <= $start_ts) {
                return new WP_REST_Response([
                    'success' => false,
                    'message' => 'Giờ kết thúc phải sau giờ bắt đầu'
                ], 400);
            }
            $overtime_hours = round(($end_ts - $start_ts) / 3600, 2);

            $insert_data['overtime_date']       = $overtime_date;
            $insert_data['overtime_start_time'] = $overtime_start_time;
            $insert_data['overtime_end_time']   = $overtime_end_time;
            $insert_data['overtime_hours']      = $overtime_hours;
            $format                             = array_merge($format, ['%s', '%s', '%s', '%f']);
            break;

        case 'salary_advance':
            $advance_amount = floatval($data['advance_amount'] ?? 0);
            if ($advance_amount <= 0) {
                return new WP_REST_Response([
                    'success' => false,
                    'message' => 'Số tiền ứng phải lớn hơn 0'
                ], 400);
            }

            $insert_data['advance_amount'] = $advance_amount;
            $format                        = array_merge($format, ['%f']);
            break;
    }

    // Insert to database
    $result = $wpdb->insert($table_name, $insert_data, $format);

    if ($result === false) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Không thể tạo đơn: ' . $wpdb->last_error
        ], 500);
    }

    $insert_id = $wpdb->insert_id;

    // Gửi thông báo qua Lark
    $notification_result = ['success' => true, 'message' => 'Lark disabled'];
    if (function_exists('is_lark_enabled') && is_lark_enabled()) {
        $notification_result = send_approval_request_notification($insert_id, $insert_data);

        // Cập nhật lark_message_id nếu gửi thành công
        if ($notification_result['success'] && !empty($notification_result['message_id'])) {
            $wpdb->update(
                $table_name,
                ['lark_message_id' => $notification_result['message_id']],
                ['id'              => $insert_id],
                ['%s'],
                ['%d']
            );
        }
    }

    // Gửi push notification cho managers
    if (function_exists('checkin_mkt192_notify_approval_request')) {
        $request_type_labels = [
            'late_early'     => 'Đi trễ/Về sớm',
            'leave'          => 'Nghỉ phép',
            'overtime'       => 'Tăng ca',
            'salary_advance' => 'Ứng lương'
        ];
        $type_label = $request_type_labels[$request_type] ?? $request_type;
        checkin_mkt192_notify_approval_request($staff_name, $type_label, $insert_id, $branch_id);
    }

    return new WP_REST_Response([
        'success'     => true,
        'message'     => 'Tạo đơn thành công',
        'data'        => [
            'id'           => $insert_id,
            'request_id'   => $request_id,
            'request_type' => $request_type,
            'status'       => 'pending'
        ],
        'notification' => $notification_result
    ], 201);
}

/**
 * Lấy danh sách đơn (cho admin/manager)
 */
function checkin_mkt192_get_approval_requests(WP_REST_Request $request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'checkin_mkt192_approval_requests';

    // Pagination
    $page     = max(1, intval($request->get_param('page') ?? 1));
    $per_page = max(1, min(100, intval($request->get_param('per_page') ?? 20)));
    $offset   = ($page - 1) * $per_page;

    // Filters
    $staff_name   = sanitize_text_field($request->get_param('staff_name') ?? '');
    $request_type = sanitize_text_field($request->get_param('request_type') ?? '');
    $status       = sanitize_text_field($request->get_param('status') ?? '');
    $start_date   = sanitize_text_field($request->get_param('start_date') ?? '');
    $end_date     = sanitize_text_field($request->get_param('end_date') ?? '');
    $branch       = sanitize_text_field($request->get_param('branch') ?? '');

    $where_clauses = [];
    $where_params  = [];

    if (!empty($staff_name)) {
        $where_clauses[] = 'staff_name LIKE %s';
        $where_params[]  = '%' . $wpdb->esc_like($staff_name) . '%';
    }

    if (!empty($request_type)) {
        $where_clauses[] = 'request_type = %s';
        $where_params[]  = $request_type;
    }

    if (!empty($status)) {
        $where_clauses[] = 'status = %s';
        $where_params[]  = $status;
    }

    if (!empty($start_date)) {
        $where_clauses[] = 'DATE(created_at) >= %s';
        $where_params[]  = $start_date;
    }

    if (!empty($end_date)) {
        $where_clauses[] = 'DATE(created_at) <= %s';
        $where_params[]  = $end_date;
    }

    // Branch filter: hỗ trợ cả branch name và branch_id (trong JSON array)
    if (!empty($branch)) {
        // Nếu là số, filter theo branch_id trong JSON array
        if (is_numeric($branch)) {
            // Các patterns để match branch_id trong JSON array:
            // [1] - array 1 phần tử
            // [1,2] - phần tử đầu
            // [2,1,3] - phần tử giữa
            // [2,1] - phần tử cuối
            $where_clauses[] = '(branch LIKE %s OR branch LIKE %s OR branch LIKE %s OR branch LIKE %s)';
            $where_params[]  = '[' . $branch . ']';      // [1] - exact single element
            $where_params[]  = '[' . $branch . ',%';     // [1,... - first element
            $where_params[]  = '%,' . $branch . ',%';    // ...,1,... - middle element
            $where_params[]  = '%,' . $branch . ']';     // ...,1] - last element
        } else {
            $where_clauses[] = 'branch = %s';
            $where_params[]  = $branch;
        }
    }

    $where_sql = !empty($where_clauses) ? 'WHERE ' . implode(' AND ', $where_clauses) : '';

    // Count total
    $count_query = "SELECT COUNT(*) FROM $table_name $where_sql";
    $total       = !empty($where_params)
        ? $wpdb->get_var($wpdb->prepare($count_query, ...$where_params))
        : $wpdb->get_var($count_query);

    // Get data
    $select_query = "SELECT * FROM $table_name $where_sql ORDER BY created_at DESC LIMIT %d OFFSET %d";
    $query_params = array_merge($where_params, [$per_page, $offset]);
    $results      = $wpdb->get_results($wpdb->prepare($select_query, ...$query_params), ARRAY_A);

    return new WP_REST_Response([
        'success' => true,
        'data'    => $results,
        'meta'    => [
            'total'       => intval($total),
            'page'        => $page,
            'per_page'    => $per_page,
            'total_pages' => ceil($total / $per_page)
        ]
    ], 200);
}

/**
 * Lấy danh sách đơn của user hiện tại
 */
function checkin_mkt192_get_my_approval_requests(WP_REST_Request $request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'checkin_mkt192_approval_requests';

    $user_id = get_current_user_id();

    // Pagination
    $page     = max(1, intval($request->get_param('page') ?? 1));
    $per_page = max(1, min(100, intval($request->get_param('per_page') ?? 20)));
    $offset   = ($page - 1) * $per_page;

    // Optional filters
    $request_type = sanitize_text_field($request->get_param('request_type') ?? '');
    $status       = sanitize_text_field($request->get_param('status') ?? '');
    $start_date   = sanitize_text_field($request->get_param('start_date') ?? '');
    $end_date     = sanitize_text_field($request->get_param('end_date') ?? '');

    $where_clauses = ['staff_id = %d'];
    $where_params  = [$user_id];

    if (!empty($request_type)) {
        $where_clauses[] = 'request_type = %s';
        $where_params[]  = $request_type;
    }

    if (!empty($status)) {
        $where_clauses[] = 'status = %s';
        $where_params[]  = $status;
    }

    // Date filters
    if (!empty($start_date)) {
        $where_clauses[] = 'DATE(created_at) >= %s';
        $where_params[]  = $start_date;
    }

    if (!empty($end_date)) {
        $where_clauses[] = 'DATE(created_at) <= %s';
        $where_params[]  = $end_date;
    }

    $where_sql = 'WHERE ' . implode(' AND ', $where_clauses);

    // Count total
    $count_query = "SELECT COUNT(*) FROM $table_name $where_sql";
    $total       = $wpdb->get_var($wpdb->prepare($count_query, ...$where_params));

    // Get data
    $select_query = "SELECT * FROM $table_name $where_sql ORDER BY created_at DESC LIMIT %d OFFSET %d";
    $query_params = array_merge($where_params, [$per_page, $offset]);
    $results      = $wpdb->get_results($wpdb->prepare($select_query, ...$query_params), ARRAY_A);

    return new WP_REST_Response([
        'success' => true,
        'data'    => $results,
        'meta'    => [
            'total'       => intval($total),
            'page'        => $page,
            'per_page'    => $per_page,
            'total_pages' => ceil($total / $per_page)
        ]
    ], 200);
}

/**
 * Lấy chi tiết một đơn
 */
function checkin_mkt192_get_approval_request_detail(WP_REST_Request $request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'checkin_mkt192_approval_requests';

    $id = intval($request->get_param('id'));

    $result = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $table_name WHERE id = %d",
        $id
    ), ARRAY_A);

    if (!$result) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Không tìm thấy đơn'
        ], 404);
    }

    return new WP_REST_Response([
        'success' => true,
        'data'    => $result
    ], 200);
}

/**
 * Duyệt đơn
 */
function checkin_mkt192_approve_request(WP_REST_Request $request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'checkin_mkt192_approval_requests';

    $request_id = sanitize_text_field($request->get_param('request_id'));

    // Lấy đơn
    $approval = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $table_name WHERE request_id = %s",
        $request_id
    ));

    if (!$approval) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Không tìm thấy đơn'
        ], 404);
    }

    if ($approval->status !== 'pending') {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Đơn đã được xử lý'
        ], 400);
    }

    // Get approver info
    $user        = wp_get_current_user();
    $approved_by = $user->display_name;

    // Update status
    $result = $wpdb->update(
        $table_name,
        [
            'status'      => 'approved',
            'approved_by' => $approved_by,
            'approved_at' => current_time('mysql'),
            'updated_at'  => current_time('mysql')
        ],
        ['request_id' => $request_id],
        ['%s', '%s', '%s', '%s'],
        ['%s']
    );

    if ($result === false) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Không thể duyệt đơn: ' . $wpdb->last_error
        ], 500);
    }

    // Nếu là đơn đi trễ/về sớm, cập nhật checkin_logs để xóa tiền phạt
    if ($approval->request_type === 'late_early') {
        $checkinlogs_table = $wpdb->prefix . 'checkin_mkt192_checkinlogs';
        $staff_name        = $approval->staff_name;
        $late_date         = $approval->late_early_date;

        if ($staff_name && $late_date) {
            $wpdb->query($wpdb->prepare("
                UPDATE $checkinlogs_table
                SET approval_late = %s, penalty_amount = 0
                WHERE display_name = %s AND DATE(checkin_time) = %s
            ", 'approved', $staff_name, $late_date));
        }
    }

    // Nếu là đơn tăng ca, cập nhật checkin_logs để ghi nhận tăng ca
    if ($approval->request_type === 'overtime') {
        $checkinlogs_table = $wpdb->prefix . 'checkin_mkt192_checkinlogs';
        $staff_name        = $approval->staff_name;
        $overtime_date     = $approval->overtime_date;

        if ($staff_name && $overtime_date) {
            $wpdb->query($wpdb->prepare("
                UPDATE $checkinlogs_table
                SET approval_ot = %s
                WHERE display_name = %s AND DATE(checkin_time) = %s
            ", 'approved', $staff_name, $overtime_date));
        }
    }

    // Gửi thông báo cập nhật trạng thái qua Lark
    if (function_exists('is_lark_enabled') && is_lark_enabled() && function_exists('send_approval_status_notification')) {
        send_approval_status_notification($request_id, 'approved', $approved_by);
    }

    // Gửi push notification cho nhân viên
    if (function_exists('checkin_mkt192_notify_approval_result')) {
        $request_type_labels = [
            'late_early'     => 'Đi trễ/Về sớm',
            'leave'          => 'Nghỉ phép',
            'overtime'       => 'Tăng ca',
            'salary_advance' => 'Ứng lương'
        ];
        $type_label = $request_type_labels[$approval->request_type] ?? $approval->request_type;
        checkin_mkt192_notify_approval_result($approval->staff_id, $type_label, 'approved', $approval->id);
    }

    return new WP_REST_Response([
        'success' => true,
        'message' => 'Đã duyệt đơn thành công'
    ], 200);
}

/**
 * Từ chối đơn
 */
function checkin_mkt192_reject_request(WP_REST_Request $request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'checkin_mkt192_approval_requests';

    $request_id    = sanitize_text_field($request->get_param('request_id'));
    $data          = $request->get_json_params();
    $reject_reason = sanitize_textarea_field($data['reject_reason'] ?? '');

    // Lấy đơn
    $approval = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $table_name WHERE request_id = %s",
        $request_id
    ));

    if (!$approval) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Không tìm thấy đơn'
        ], 404);
    }

    if ($approval->status !== 'pending') {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Đơn đã được xử lý'
        ], 400);
    }

    // Get approver info
    $user        = wp_get_current_user();
    $approved_by = $user->display_name;

    // Update status
    $result = $wpdb->update(
        $table_name,
        [
            'status'        => 'rejected',
            'approved_by'   => $approved_by,
            'approved_at'   => current_time('mysql'),
            'reject_reason' => $reject_reason,
            'updated_at'    => current_time('mysql')
        ],
        ['request_id' => $request_id],
        ['%s', '%s', '%s', '%s', '%s'],
        ['%s']
    );

    if ($result === false) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Không thể từ chối đơn: ' . $wpdb->last_error
        ], 500);
    }

    // Gửi thông báo cập nhật trạng thái qua Lark
    if (function_exists('is_lark_enabled') && is_lark_enabled() && function_exists('send_approval_status_notification')) {
        send_approval_status_notification($request_id, 'rejected', $approved_by, $reject_reason);
    }

    // Gửi push notification cho nhân viên
    if (function_exists('checkin_mkt192_notify_approval_result')) {
        $request_type_labels = [
            'late_early'     => 'Đi trễ/Về sớm',
            'leave'          => 'Nghỉ phép',
            'overtime'       => 'Tăng ca',
            'salary_advance' => 'Ứng lương'
        ];
        $type_label = $request_type_labels[$approval->request_type] ?? $approval->request_type;
        checkin_mkt192_notify_approval_result($approval->staff_id, $type_label, 'rejected', $approval->id);
    }

    return new WP_REST_Response([
        'success' => true,
        'message' => 'Đã từ chối đơn'
    ], 200);
}

/**
 * Hủy đơn (chỉ chủ đơn)
 */
function checkin_mkt192_cancel_request(WP_REST_Request $request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'checkin_mkt192_approval_requests';

    $request_id = sanitize_text_field($request->get_param('request_id'));
    $user_id    = get_current_user_id();

    // Lấy đơn
    $approval = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $table_name WHERE request_id = %s",
        $request_id
    ));

    if (!$approval) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Không tìm thấy đơn'
        ], 404);
    }

    // Kiểm tra quyền sở hữu
    if (intval($approval->staff_id) !== $user_id) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Bạn không có quyền hủy đơn này'
        ], 403);
    }

    if ($approval->status !== 'pending') {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Chỉ có thể hủy đơn đang chờ duyệt'
        ], 400);
    }

    // Xóa đơn
    $result = $wpdb->delete($table_name, ['request_id' => $request_id], ['%s']);

    if ($result === false) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Không thể hủy đơn: ' . $wpdb->last_error
        ], 500);
    }

    return new WP_REST_Response([
        'success' => true,
        'message' => 'Đã hủy đơn thành công'
    ], 200);
}

/**
 * Xóa đơn (Admin)
 */
function checkin_mkt192_delete_request(WP_REST_Request $request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'checkin_mkt192_approval_requests';

    $request_id = sanitize_text_field($request->get_param('request_id'));

    // Kiểm tra đơn tồn tại
    $approval = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $table_name WHERE request_id = %s",
        $request_id
    ));

    if (!$approval) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Không tìm thấy đơn'
        ], 404);
    }

    // Xóa đơn
    $result = $wpdb->delete($table_name, ['request_id' => $request_id], ['%s']);

    if ($result === false) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Không thể xóa đơn: ' . $wpdb->last_error
        ], 500);
    }

    return new WP_REST_Response([
        'success' => true,
        'message' => 'Đã xóa đơn thành công'
    ], 200);
}

// =============================================================================
// BACKWARD COMPATIBILITY: Legacy Leave Requests API
// =============================================================================

/**
 * Lấy danh sách đơn nghỉ phép (Legacy API - tương thích ngược)
 * Đọc từ bảng approval_requests với request_type = 'leave'
 */
function checkin_mkt192_get_leave_requests(WP_REST_Request $request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'checkin_mkt192_approval_requests';

    // Lấy tham số lọc
    $start_date       = $request->get_param('start_date');
    $end_date         = $request->get_param('end_date');
    $hairdresser_name = $request->get_param('hairdresser_name');

    // Xây dựng query - chỉ lấy request_type = 'leave'
    $query  = "SELECT
                id,
                request_id,
                staff_name AS hairdresser_name,
                leave_type,
                leave_start_date,
                leave_end_date,
                DATEDIFF(leave_end_date, leave_start_date) + 1 AS leave_total_date,
                status AS leave_status,
                reason,
                created_at,
                updated_at
               FROM $table_name
               WHERE request_type = 'leave' AND status != 'cancelled'";
    $params = [];

    if ($start_date) {
        $query .= ' AND leave_start_date >= %s';
        $params[] = $start_date;
    }
    if ($end_date) {
        $query .= ' AND leave_end_date <= %s';
        $params[] = $end_date;
    }
    if ($hairdresser_name) {
        $query .= ' AND staff_name = %s';
        $params[] = $hairdresser_name;
    }

    // Thêm sắp xếp mặc định (mới nhất)
    $query .= ' ORDER BY leave_start_date DESC';

    if (!empty($params)) {
        $results = $wpdb->get_results($wpdb->prepare($query, $params), ARRAY_A);
    } else {
        $results = $wpdb->get_results($query, ARRAY_A);
    }

    if (empty($results)) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Không tìm thấy dữ liệu ngày off.',
        ], 200);
    }

    // Map status để tương thích ngược
    foreach ($results as &$row) {
        $row['leave_status'] = ucfirst($row['leave_status']); // approved -> Approved
    }

    return new WP_REST_Response([
        'success' => true,
        'data'    => $results,
    ], 200);
}

?>
