<?php

add_action('rest_api_init', function () {
    // KPI Settings
    register_rest_route('vg/v1', '/kpi-settings', [
        'methods'             => 'GET',
        'callback'            => 'checkin_mkt192_get_kpi_settings_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'kpi.read']),
        'args'                => [
            'staff_name' => [
                'required'          => false,
                'type'              => 'string',
                'sanitize_callback' => 'sanitize_text_field'
            ],
            'current_user_role' => [
                'required'          => false,
                'type'              => 'string',
                'sanitize_callback' => 'sanitize_text_field'
            ],
            'kpi_type' => [
                'required'          => false,
                'type'              => 'string',
                'sanitize_callback' => 'sanitize_text_field',
                'validate_callback' => function($param) {
                    return in_array($param, ['service', 'product', 'postfb', 'feedback']);
                }
            ],
            'start_date' => [
                'required'          => false,
                'type'              => 'string',
                'validate_callback' => function($param) {
                    return preg_match('/^\d{4}-\d{2}-\d{2}$/', $param);
                },
                'sanitize_callback' => 'sanitize_text_field'
            ],
            'end_date' => [
                'required'          => false,
                'type'              => 'string',
                'validate_callback' => function($param) {
                    return preg_match('/^\d{4}-\d{2}-\d{2}$/', $param);
                },
                'sanitize_callback' => 'sanitize_text_field'
            ]
        ]
    ]);
    register_rest_route('vg/v1', '/kpi-settings', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_save_kpi_settings_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'kpi.config'])
    ]);
    register_rest_route('vg/v1', '/kpi-settings/(?P<id>\d+)', [
        'methods'             => 'GET',
        'callback'            => 'checkin_mkt192_get_kpi_setting_by_id_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'kpi.read'])
    ]);
    register_rest_route('vg/v1', '/kpi-settings/(?P<id>\d+)', [
        'methods'             => 'PUT',
        'callback'            => 'checkin_mkt192_update_kpi_settings_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'kpi.config'])
    ]);
    register_rest_route('vg/v1', '/kpi-settings/(?P<id>\d+)', [
        'methods'             => 'DELETE',
        'callback'            => 'checkin_mkt192_delete_kpi_settings_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'kpi.delete'])
    ]);

    // Endpoint để lấy số lượng bài đăng Facebook
    register_rest_route('vg/v1', '/kpi-social-posts-count', [
        'methods'             => 'GET',
        'callback'            => 'checkin_mkt192_get_social_posts_count',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'kpi.read']),
        'args'                => [
            'start_date' => [
                'required'          => true,
                'type'              => 'string',
                'validate_callback' => function($param) {
                    return preg_match('/^\d{4}-\d{2}-\d{2}$/', $param);
                },
            ],
            'end_date' => [
                'required'          => true,
                'type'              => 'string',
                'validate_callback' => function($param) {
                    return preg_match('/^\d{4}-\d{2}-\d{2}$/', $param);
                },
            ],
            'staff_name' => [
                'required'          => false,
                'type'              => 'string',
                'sanitize_callback' => 'sanitize_text_field'
            ]
        ],
    ]);
});

function checkin_mkt192_get_kpi_settings_api(WP_REST_Request $request) {
    global $wpdb;
    try {
        date_default_timezone_set('Asia/Ho_Chi_Minh');
        $staff_name        = $request->get_param('staff_name');
        $current_user_role = $request->get_param('current_user_role');
        $kpi_type          = $request->get_param('kpi_type');
        $start_date        = $request->get_param('start_date');
        $end_date          = $request->get_param('end_date');

        $query  = "SELECT * FROM {$wpdb->prefix}checkin_mkt192_kpi_settings WHERE status = '1'";
        $params = [];

        // Lọc theo loại KPI nếu được cung cấp
        if ($kpi_type) {
            switch ($kpi_type) {
                case 'service':
                    $query .= ' AND service_kpi > 0';
                    break;
                case 'product':
                    $query .= ' AND product_kpi_lv1 > 0';
                    break;
                case 'postfb':
                    $query .= ' AND post_fb_kpi > 0';
                    break;
                case 'feedback':
                    $query .= ' AND feedback_kpi > 0';
                    break;
            }
        }

        // Lọc theo khoảng thời gian nếu được cung cấp
        if ($start_date && $end_date) {
            $query .= ' AND start_date <= %s AND end_date >= %s';
            $params[] = $end_date;
            $params[] = $start_date;
        } elseif ($start_date) {
            $query .= ' AND end_date >= %s';
            $params[] = $start_date;
        } elseif ($end_date) {
            $query .= ' AND start_date <= %s';
            $params[] = $end_date;
        }

        // Xử lý lọc theo staff_name dựa trên vai trò người dùng
        if ($current_user_role === 'Thu Ngân' || $current_user_role === 'Quản Lý') {
            if (!empty($staff_name)) {
                $query .= ' AND JSON_CONTAINS(staff_name, %s)';
                $params[] = wp_json_encode($staff_name, JSON_UNESCAPED_UNICODE);
            }
        } else {
            // Vai trò Thợ yêu cầu staff_name
            if (empty($staff_name)) {
                return new WP_REST_Response([
                    'success' => false,
                    'message' => 'Thiếu tham số staff_name cho vai trò Thợ'
                ], 400);
            }
            $query .= ' AND JSON_CONTAINS(staff_name, %s)';
            $params[] = wp_json_encode($staff_name, JSON_UNESCAPED_UNICODE);
        }

        $query .= ' ORDER BY updated_at DESC';
        $settings = $wpdb->get_results($wpdb->prepare($query, $params), ARRAY_A);

        // Decode JSON staff_name cho từng dòng
        foreach ($settings as &$row) {
            if (!empty($row['staff_name'])) {
                $decoded = json_decode($row['staff_name'], true);
                if (json_last_error() === JSON_ERROR_NONE) {
                    $row['staff_name'] = $decoded;
                } else {
                    error_log('JSON decode error for staff_name: ' . json_last_error_msg());
                    $row['staff_name'] = [$row['staff_name']]; // Fallback
                }
            } else {
                $row['staff_name'] = [];
            }
        }

        return new WP_REST_Response([
            'success' => true,
            'data'    => $settings
        ], 200);
    } catch (Exception $e) {
        error_log('Get KPI settings error: ' . $e->getMessage());
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Lỗi hệ thống: ' . $e->getMessage()
        ], 500);
    }
}

function checkin_mkt192_get_kpi_setting_by_id_api(WP_REST_Request $request) {
    global $wpdb;
    try {
        date_default_timezone_set('Asia/Ho_Chi_Minh');
        $id      = $request->get_param('id');
        $setting = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}checkin_mkt192_kpi_settings WHERE id = %d AND status = '1'", $id), ARRAY_A);

        if (!$setting) {
            return new WP_REST_Response(['success' => false, 'message' => 'KPI không tồn tại'], 404);
        }

        // Decode JSON staff_name
        if (!empty($setting['staff_name'])) {
            $decoded = json_decode($setting['staff_name'], true);
            if (json_last_error() === JSON_ERROR_NONE) {
                $setting['staff_name'] = $decoded;
            } else {
                error_log('JSON decode error for staff_name: ' . json_last_error_msg());
                $setting['staff_name'] = [$setting['staff_name']]; // Fallback to array with single value
            }
        } else {
            $setting['staff_name'] = [];
        }

        return new WP_REST_Response([
            'success' => true,
            'data'    => $setting
        ], 200);
    } catch (Exception $e) {
        error_log('Get KPI setting by ID error: ' . $e->getMessage());
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Lỗi hệ thống: ' . $e->getMessage()
        ], 500);
    }
}

function checkin_mkt192_save_kpi_settings_api(WP_REST_Request $request) {
    global $wpdb;
    $data                = $request->get_json_params();
    $staff_name          = isset($data['staff_name']) && is_array($data['staff_name'])
    ? wp_json_encode(array_map('sanitize_text_field', $data['staff_name']), JSON_UNESCAPED_UNICODE)
    : wp_json_encode([sanitize_text_field($data['staff_name'] ?? '')], JSON_UNESCAPED_UNICODE);
    $service_kpi         = $data['service_kpi']         ?? null;
    $service_bonus       = $data['service_bonus']       ?? null;
    $service_penalty     = $data['service_penalty']     ?? null;
    $product_kpi_lv1     = $data['product_kpi_lv1']     ?? null;
    $product_bonus_lv1   = $data['product_bonus_lv1']   ?? null;
    $product_penalty_lv1 = $data['product_penalty_lv1'] ?? null;
    $product_kpi_type    = sanitize_text_field($data['product_kpi_type'] ?? 'doanh_thu'); // Thêm trường mới, mặc định 'doanh_thu'
    $post_fb_kpi         = $data['post_fb_kpi']         ?? null;
    $post_fb_mode        = ($data['post_fb_mode'] ?? 'count') === 'workdays' ? 'workdays' : 'count'; // count = số bài cố định · workdays = N bài/ngày công
    $post_fb_bonus       = $data['post_fb_bonus']       ?? null;
    $post_fb_penalty     = $data['post_fb_penalty']     ?? null;
    $feedback_kpi        = $data['feedback_kpi']        ?? null;
    $feedback_bonus      = $data['feedback_bonus']      ?? null;
    $feedback_penalty    = $data['feedback_penalty']    ?? null;
    $status              = $data['status']              ?? 1;
    $start_date          = sanitize_text_field($data['start_date'] ?? '');
    $end_date            = sanitize_text_field($data['end_date'] ?? '');
    $updated_at          = current_time('mysql');

    // Kiểm tra các trường bắt buộc
    if (empty($staff_name) || empty($start_date) || empty($end_date)) {
        return new WP_REST_Response(['success' => false, 'message' => 'Dữ liệu không được để trống'], 400);
    }

    // Xác định loại KPI đang cập nhật
    $kpi_type = '';
    if (($service_kpi !== null && $service_kpi > 0) || ($service_bonus !== null && $service_bonus > 0) || ($service_penalty !== null && $service_penalty > 0)) {
        $kpi_type = 'service';
    } elseif (($product_kpi_lv1 !== null && $product_kpi_lv1 > 0) || ($product_bonus_lv1 !== null && $product_bonus_lv1 > 0) || ($product_penalty_lv1 !== null && $product_penalty_lv1 > 0)) {
        $kpi_type = 'product';
    } elseif (($post_fb_kpi !== null && $post_fb_kpi > 0) || ($post_fb_bonus !== null && $post_fb_bonus > 0) || ($post_fb_penalty !== null && $post_fb_penalty > 0)) {
        $kpi_type = 'postfb';
    } elseif (($feedback_kpi !== null && $feedback_kpi > 0) || ($feedback_bonus !== null && $feedback_bonus > 0) || ($feedback_penalty !== null && $feedback_penalty > 0)) {
        $kpi_type = 'feedback';
    }

    if (!$kpi_type && $status === null) {
        return new WP_REST_Response(['success' => false, 'message' => 'Không có giá trị KPI nào được cung cấp'], 400);
    }

    // Kiểm tra product_kpi_type chỉ hợp lệ nếu kpi_type là 'product'
    if ($kpi_type === 'product' && !in_array($product_kpi_type, ['san_pham', 'doanh_thu'])) {
        return new WP_REST_Response(['success' => false, 'message' => 'Loại mục tiêu KPI sản phẩm không hợp lệ'], 400);
    }

    // Chèn dữ liệu vào database
    $result = $wpdb->insert(
        "{$wpdb->prefix}checkin_mkt192_kpi_settings",
        [
            'staff_name'          => $staff_name,
            'service_kpi'         => $kpi_type === 'service'  && $service_kpi         !== null ? floatval($service_kpi) : 0,
            'service_bonus'       => $kpi_type === 'service'  && $service_bonus       !== null ? floatval($service_bonus) : 0,
            'service_penalty'     => $kpi_type === 'service'  && $service_penalty     !== null ? floatval($service_penalty) : 0,
            'product_kpi_lv1'     => $kpi_type === 'product'  && $product_kpi_lv1     !== null ? floatval($product_kpi_lv1) : 0,
            'product_bonus_lv1'   => $kpi_type === 'product'  && $product_bonus_lv1   !== null ? floatval($product_bonus_lv1) : 0,
            'product_penalty_lv1' => $kpi_type === 'product'  && $product_penalty_lv1 !== null ? floatval($product_penalty_lv1) : 0,
            'product_kpi_type'    => $kpi_type === 'product' ? $product_kpi_type : 'doanh_thu', // Thêm trường mới
            'post_fb_kpi'         => $kpi_type === 'postfb'   && $post_fb_kpi         !== null ? floatval($post_fb_kpi) : 0,
            'post_fb_mode'        => $kpi_type === 'postfb' ? $post_fb_mode : 'count',
            'post_fb_bonus'       => $kpi_type === 'postfb'   && $post_fb_bonus       !== null ? floatval($post_fb_bonus) : 0,
            'post_fb_penalty'     => $kpi_type === 'postfb'   && $post_fb_penalty     !== null ? floatval($post_fb_penalty) : 0,
            'feedback_kpi'        => $kpi_type === 'feedback' && $feedback_kpi        !== null ? floatval($feedback_kpi) : 0,
            'feedback_bonus'      => $kpi_type === 'feedback' && $feedback_bonus      !== null ? floatval($feedback_bonus) : 0,
            'feedback_penalty'    => $kpi_type === 'feedback' && $feedback_penalty    !== null ? floatval($feedback_penalty) : 0,
            'status'              => $status                                          !== null ? intval($status) : 1,
            'start_date'          => $start_date,
            'end_date'            => $end_date,
            'updated_at'          => $updated_at,
            'created_at'          => $updated_at
        ],
        [
            '%s', // staff_name
            '%f', // service_kpi
            '%f', // service_bonus
            '%f', // service_penalty
            '%f', // product_kpi_lv1
            '%f', // product_bonus_lv1
            '%f', // product_penalty_lv1
            '%s', // product_kpi_type (thêm mới)
            '%f', // post_fb_kpi
            '%s', // post_fb_mode
            '%f', // post_fb_bonus
            '%f', // post_fb_penalty
            '%f', // feedback_kpi
            '%f', // feedback_bonus
            '%f', // feedback_penalty
            '%d', // status
            '%s', // start_date
            '%s', // end_date
            '%s', // updated_at
            '%s'  // created_at
        ]
    );

    if ($result === false) {
        file_put_contents(__DIR__ . '/logs/kpi_settings_errors.log', date('Y-m-d H:i:s') . ' - Insert KPI settings error: ' . $wpdb->last_error . "\n", FILE_APPEND);
        return new WP_REST_Response(['success' => false, 'message' => 'Lỗi khi lưu KPI vào cơ sở dữ liệu'], 500);
    }

    $last_id     = $wpdb->insert_id;
    $new_setting = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}checkin_mkt192_kpi_settings WHERE id = %d", $last_id), ARRAY_A);

    if ($new_setting) {
        try {
            $new_setting['staff_name'] = json_decode($new_setting['staff_name'], true) ?: [$new_setting['staff_name']];
        } catch (Exception $e) {
            $new_setting['staff_name'] = [$new_setting['staff_name']]; // Fallback nếu JSON parse thất bại
        }
        return new WP_REST_Response(['success' => true, 'data' => $new_setting], 200);
    } else {
        return new WP_REST_Response(['success' => false, 'message' => 'Không thể lấy dữ liệu KPI vừa lưu'], 500);
    }
}

function checkin_mkt192_update_kpi_settings_api(WP_REST_Request $request) {
    global $wpdb;
    $id                  = $request->get_param('id');
    $data                = $request->get_json_params();
    $staff_name          = isset($data['staff_name']) && is_array($data['staff_name'])
    ? wp_json_encode(array_map('sanitize_text_field', $data['staff_name']), JSON_UNESCAPED_UNICODE)
    : wp_json_encode([sanitize_text_field($data['staff_name'] ?? '')], JSON_UNESCAPED_UNICODE);
    $service_kpi         = $data['service_kpi']         ?? null;
    $service_bonus       = $data['service_bonus']       ?? null;
    $service_penalty     = $data['service_penalty']     ?? null;
    $product_kpi_lv1     = $data['product_kpi_lv1']     ?? null;
    $product_bonus_lv1   = $data['product_bonus_lv1']   ?? null;
    $product_penalty_lv1 = $data['product_penalty_lv1'] ?? null;
    $product_kpi_type    = sanitize_text_field($data['product_kpi_type'] ?? null); // Thêm trường mới
    $post_fb_kpi         = $data['post_fb_kpi']         ?? null;
    $post_fb_mode        = isset($data['post_fb_mode']) ? ($data['post_fb_mode'] === 'workdays' ? 'workdays' : 'count') : null;
    $post_fb_bonus       = $data['post_fb_bonus']       ?? null;
    $post_fb_penalty     = $data['post_fb_penalty']     ?? null;
    $feedback_kpi        = $data['feedback_kpi']        ?? null;
    $feedback_bonus      = $data['feedback_bonus']      ?? null;
    $feedback_penalty    = $data['feedback_penalty']    ?? null;
    $status              = $data['status']              ?? null;
    $start_date          = sanitize_text_field($data['start_date'] ?? '');
    $end_date            = sanitize_text_field($data['end_date'] ?? '');
    $updated_at          = current_time('mysql');

    // Lấy bản ghi hiện tại
    $currentRecord = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}checkin_mkt192_kpi_settings WHERE id = %d", $id), ARRAY_A);

    if (!$currentRecord) {
        return new WP_REST_Response(['success' => false, 'message' => 'Bản ghi không tồn tại'], 404);
    }

    // Xác định loại KPI đang cập nhật
    $kpi_type = '';
    if (($service_kpi !== null && $service_kpi > 0) || ($service_bonus !== null && $service_bonus > 0) || ($service_penalty !== null && $service_penalty > 0)) {
        $kpi_type = 'service';
    } elseif (($product_kpi_lv1 !== null && $product_kpi_lv1 > 0) || ($product_bonus_lv1 !== null && $product_bonus_lv1 > 0) || ($product_penalty_lv1 !== null && $product_penalty_lv1 > 0)) {
        $kpi_type = 'product';
    } elseif (($post_fb_kpi !== null && $post_fb_kpi > 0) || ($post_fb_bonus !== null && $post_fb_bonus > 0) || ($post_fb_penalty !== null && $post_fb_penalty > 0)) {
        $kpi_type = 'postfb';
    } elseif (($feedback_kpi !== null && $feedback_kpi > 0) || ($feedback_bonus !== null && $feedback_bonus > 0) || ($feedback_penalty !== null && $feedback_penalty > 0)) {
        $kpi_type = 'feedback';
    }

    if (!$kpi_type && $status === null) {
        return new WP_REST_Response(['success' => false, 'message' => 'Không có giá trị KPI nào được cung cấp'], 400);
    }

    // Kiểm tra product_kpi_type chỉ hợp lệ nếu kpi_type là 'product'
    if ($kpi_type === 'product' && $product_kpi_type !== null && !in_array($product_kpi_type, ['san_pham', 'doanh_thu'])) {
        return new WP_REST_Response(['success' => false, 'message' => 'Loại mục tiêu KPI sản phẩm không hợp lệ'], 400);
    }

    // Cập nhật các trường liên quan, giữ nguyên các giá trị khác
    $result = $wpdb->update(
        "{$wpdb->prefix}checkin_mkt192_kpi_settings",
        [
            'staff_name'          => $staff_name ?: $currentRecord['staff_name'],
            'service_kpi'         => $kpi_type === 'service'  && $service_kpi         !== null ? floatval($service_kpi) : $currentRecord['service_kpi'],
            'service_bonus'       => $kpi_type === 'service'  && $service_bonus       !== null ? floatval($service_bonus) : $currentRecord['service_bonus'],
            'service_penalty'     => $kpi_type === 'service'  && $service_penalty     !== null ? floatval($service_penalty) : $currentRecord['service_penalty'],
            'product_kpi_lv1'     => $kpi_type === 'product'  && $product_kpi_lv1     !== null ? floatval($product_kpi_lv1) : $currentRecord['product_kpi_lv1'],
            'product_bonus_lv1'   => $kpi_type === 'product'  && $product_bonus_lv1   !== null ? floatval($product_bonus_lv1) : $currentRecord['product_bonus_lv1'],
            'product_penalty_lv1' => $kpi_type === 'product'  && $product_penalty_lv1 !== null ? floatval($product_penalty_lv1) : $currentRecord['product_penalty_lv1'],
            'product_kpi_type'    => $product_kpi_type                                !== null ? $product_kpi_type : $currentRecord['product_kpi_type'], // Thêm trường mới
            'post_fb_kpi'         => $kpi_type === 'postfb'   && $post_fb_kpi         !== null ? floatval($post_fb_kpi) : $currentRecord['post_fb_kpi'],
            'post_fb_mode'        => $kpi_type === 'postfb'   && $post_fb_mode        !== null ? $post_fb_mode : ($currentRecord['post_fb_mode'] ?? 'count'),
            'post_fb_bonus'       => $kpi_type === 'postfb'   && $post_fb_bonus       !== null ? floatval($post_fb_bonus) : $currentRecord['post_fb_bonus'],
            'post_fb_penalty'     => $kpi_type === 'postfb'   && $post_fb_penalty     !== null ? floatval($post_fb_penalty) : $currentRecord['post_fb_penalty'],
            'feedback_kpi'        => $kpi_type === 'feedback' && $feedback_kpi        !== null ? floatval($feedback_kpi) : $currentRecord['feedback_kpi'],
            'feedback_bonus'      => $kpi_type === 'feedback' && $feedback_bonus      !== null ? floatval($feedback_bonus) : $currentRecord['feedback_bonus'],
            'feedback_penalty'    => $kpi_type === 'feedback' && $feedback_penalty    !== null ? floatval($feedback_penalty) : $currentRecord['feedback_penalty'],
            'status'              => $status                                          !== null ? intval($status) : $currentRecord['status'],
            'start_date'          => $start_date ?: $currentRecord['start_date'],
            'end_date'            => $end_date ?: $currentRecord['end_date'],
            'updated_at'          => $updated_at
        ],
        ['id' => $id],
        [
            '%s', // staff_name
            '%f', // service_kpi
            '%f', // service_bonus
            '%f', // service_penalty
            '%f', // product_kpi_lv1
            '%f', // product_bonus_lv1
            '%f', // product_penalty_lv1
            '%s', // product_kpi_type (thêm mới)
            '%f', // post_fb_kpi
            '%s', // post_fb_mode
            '%f', // post_fb_bonus
            '%f', // post_fb_penalty
            '%f', // feedback_kpi
            '%f', // feedback_bonus
            '%f', // feedback_penalty
            '%d', // status
            '%s', // start_date
            '%s', // end_date
            '%s'  // updated_at
        ],
        ['%d'] // id
    );

    if ($result === false) {
        file_put_contents(__DIR__ . '/logs/kpi_settings_errors.log', date('Y-m-d H:i:s') . ' - Update KPI settings error: ' . $wpdb->last_error . "\n", FILE_APPEND);
        return new WP_REST_Response(['success' => false, 'message' => 'Lỗi khi cập nhật KPI'], 500);
    }

    $updated_setting = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}checkin_mkt192_kpi_settings WHERE id = %d", $id), ARRAY_A);
    if ($updated_setting) {
        try {
            $updated_setting['staff_name'] = json_decode($updated_setting['staff_name'], true) ?: [$updated_setting['staff_name']];
        } catch (Exception $e) {
            $updated_setting['staff_name'] = [$updated_setting['staff_name']]; // Fallback nếu JSON parse thất bại
        }
        return new WP_REST_Response(['success' => true, 'data' => $updated_setting], 200);
    } else {
        return new WP_REST_Response(['success' => false, 'message' => 'Không thể lấy dữ liệu KPI vừa cập nhật'], 500);
    }
}

function checkin_mkt192_delete_kpi_settings_api(WP_REST_Request $request) {
    global $wpdb;
    $id = $request->get_param('id');
    try {
        $result = $wpdb->delete(
            "{$wpdb->prefix}checkin_mkt192_kpi_settings",
            ['id' => $id],
            ['%d']
        );
        if ($result === false) {
            file_put_contents(__DIR__ . '/logs/kpi_settings_errors.log', date('Y-m-d H:i:s') . ' - Delete KPI settings error: ' . $wpdb->last_error . "\n", FILE_APPEND);
            return new WP_REST_Response(['success' => false, 'message' => 'Lỗi khi xóa KPI'], 500);
        }
        return new WP_REST_Response(['success' => true, 'message' => 'Xóa KPI thành công'], 200);
    } catch (Exception $e) {
        file_put_contents(__DIR__ . '/logs/kpi_settings_errors.log', date('Y-m-d H:i:s') . ' - Delete KPI settings error: ' . $e->getMessage() . "\n", FILE_APPEND);
        return new WP_REST_Response(['success' => false, 'message' => 'Lỗi hệ thống: ' . $e->getMessage()], 500);
    }
}

function checkin_mkt192_get_social_posts_count(WP_REST_Request $request) {
    global $wpdb;
    $log_file    = __DIR__ . '/logs/social_feedback_api.log';
    $log_message = '=== Bắt đầu lấy số lượng bài đăng FB (' . date('Y-m-d H:i:s') . ") ===\n";
    file_put_contents($log_file, $log_message, FILE_APPEND);

    $start_date = sanitize_text_field($request->get_param('start_date')) . ' 00:00:00';
    $end_date   = sanitize_text_field($request->get_param('end_date')) . ' 23:59:59';
    $staff_name = sanitize_text_field($request->get_param('staff_name'));

    // Validate date format
    if (!preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $start_date) ||
        !preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $end_date)) {
        $log_message = "Lỗi: Định dạng ngày không hợp lệ - start_date: $start_date, end_date: $end_date\n";
        file_put_contents($log_file, $log_message, FILE_APPEND);
        return new WP_Error('invalid_date', 'Định dạng ngày không hợp lệ', ['status' => 400]);
    }

    // Build query
    $query = $wpdb->prepare("
        SELECT COUNT(*) as post_count
        FROM {$wpdb->prefix}checkin_mkt192_social_posts
        WHERE post_type = 'facebook'
        AND post_date BETWEEN %s AND %s
    ", $start_date, $end_date);

    if ($staff_name) {
        $query .= $wpdb->prepare(' AND staff_name = %s', $staff_name);
    }

    $post_count = $wpdb->get_var($query);
    $post_count = $post_count ? (int)$post_count : 0;

    $log_message = 'Số lượng bài đăng FB cho ' . ($staff_name ? $staff_name : 'tất cả thợ') .
                   " từ $start_date đến $end_date: $post_count\n";
    file_put_contents($log_file, $log_message, FILE_APPEND);

    $log_message = '=== Kết thúc lấy số lượng bài đăng FB (' . date('Y-m-d H:i:s') . ") ===\n\n";
    file_put_contents($log_file, $log_message, FILE_APPEND);

    return [
        'success'    => true,
        'post_count' => $post_count,
        'message'    => 'Lấy số lượng bài đăng Facebook thành công'
    ];
}
?>