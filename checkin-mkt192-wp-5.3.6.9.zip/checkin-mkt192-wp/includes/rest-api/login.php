<?php

/**
 * AJAX handler for refreshing nonce (không qua REST API để bypass nonce check)
 * Đây là cách an toàn vì:
 * - wp_ajax_ chỉ cho user đã login
 * - Không cần nonce để verify vì user đã auth qua session cookie
 */
add_action('wp_ajax_checkin_refresh_nonce', function () {
    if (!is_user_logged_in()) {
        wp_send_json_error(['message' => 'Not logged in'], 401);
    }

    wp_send_json_success([
        'nonce' => wp_create_nonce('wp_rest'),
    ]);
});

/**
 * FIX nonce sau login qua REST: wp_set_auth_cookie chỉ gửi cookie trong response,
 * $_COOKIE của request hiện tại vẫn là session cũ nên wp_create_nonce('wp_rest')
 * tạo nonce gắn với session token CŨ → mọi request sau đó bị
 * rest_cookie_invalid_nonce ("lỗi quyền") cho tới khi user reload trang.
 * Hook này đồng bộ cookie mới vào $_COOKIE ngay trong request login để nonce
 * trả về khớp session mới.
 */
add_action('set_logged_in_cookie', function ($logged_in_cookie) {
    $_COOKIE[LOGGED_IN_COOKIE] = $logged_in_cookie;
});

// Đăng ký REST API endpoints
add_action('rest_api_init', function () {
    // Endpoint cho đăng nhập Google
    register_rest_route('vg/v1', '/google-login', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt_handle_google_login',
        'permission_callback' => function () {
        return get_option('checkin_use_google_login', '0') === '1';
        },
    ]);

    // Đích redirect cho Google Sign-In ux_mode=redirect (PWA standalone không dùng được popup)
    // Google POST form-encoded: credential + g_csrf_token → verify, login, redirect về /user-profile
    register_rest_route('vg/v1', '/google-login-redirect', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt_handle_google_login_redirect',
        'permission_callback' => '__return_true', // CSRF tự kiểm bằng g_csrf_token (double-submit cookie của Google)
    ]);

    // Endpoint cho đăng nhập Facebook
    register_rest_route('vg/v1', '/facebook-login', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt_handle_facebook_login',
        'permission_callback' => function () {
        return get_option('checkin_use_facebook_login', '0') === '1';
        },
    ]);

    register_rest_route('vg/v1', '/fb-deletion-status', [
        'methods'             => ['GET', 'POST'],
        'callback'            => 'checkin_mkt_handle_fb_data_deletion_combined',
        'permission_callback' => '__return_true',
    ]);

    // Endpoint cho đăng xuất
    register_rest_route('vg/v1', '/logout', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_logout_staff',
        'permission_callback' => '__return_true',
    ]);

    // Endpoint cho đăng nhập thủ công
    register_rest_route('vg/v1', '/login', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_login_staff',
        'permission_callback' => '__return_true',
    ]);

    // Endpoint đổi mật khẩu
    register_rest_route('vg/v1', '/change-password', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt_change_password',
        'permission_callback' => function () { return is_user_logged_in(); }
    ]);
});

// Xử lý đăng nhập Google
function checkin_mkt_handle_google_login($request) {
    if (get_option('checkin_use_google_login', '0') !== '1') {
        return new WP_REST_Response(['success' => false, 'message' => 'Đăng nhập Google chưa được kích hoạt.'], 403);
    }

    $params       = $request->get_json_params();
    $id_token     = $params['id_token']     ?? '';
    $remember     = $params['remember']     ?? true;
    $force_create = $params['force_create'] ?? false; // Cho phép tạo tài khoản mới

    if (empty($id_token)) {
        return new WP_REST_Response(['success' => false, 'message' => 'Thiếu token Google.'], 400);
    }

    $user_data = checkin_verify_google_id_token($id_token);

    if (is_wp_error($user_data)) {
        return new WP_REST_Response(['success' => false, 'message' => $user_data->get_error_message()], 401);
    }

    return checkin_mkt_process_user_login($user_data, $remember, $force_create);
}

/**
 * Xử lý Google Sign-In dạng redirect (ux_mode=redirect) — dùng cho PWA standalone.
 * Google POST về đây với credential (id_token) + g_csrf_token, sau khi login xong
 * redirect browser về /user-profile kèm query param báo kết quả.
 */
function checkin_mkt_handle_google_login_redirect(WP_REST_Request $request) {
    $redirect_base = home_url('/user-profile');

    if (get_option('checkin_use_google_login', '0') !== '1') {
        return checkin_mkt_login_redirect_response($redirect_base, ['login_error' => rawurlencode('Đăng nhập Google chưa được kích hoạt.')]);
    }

    $credential  = $request->get_param('credential');
    $csrf_body   = $request->get_param('g_csrf_token');
    $csrf_cookie = $_COOKIE['g_csrf_token'] ?? '';

    if (empty($credential) || empty($csrf_body) || empty($csrf_cookie) || !hash_equals($csrf_cookie, $csrf_body)) {
        return checkin_mkt_login_redirect_response($redirect_base, ['login_error' => rawurlencode('Phiên đăng nhập Google không hợp lệ, vui lòng thử lại.')]);
    }

    $user_data = checkin_verify_google_id_token($credential);
    if (is_wp_error($user_data)) {
        return checkin_mkt_login_redirect_response($redirect_base, ['login_error' => rawurlencode($user_data->get_error_message())]);
    }

    $result = checkin_mkt_process_user_login($user_data, true, false);
    $data   = $result->get_data();

    if (!empty($data['success'])) {
        return checkin_mkt_login_redirect_response($redirect_base, ['login' => 'success']);
    }
    if (!empty($data['is_new_account'])) {
        return checkin_mkt_login_redirect_response($redirect_base, [
            'login_error' => 'new_account',
            'email'       => rawurlencode($data['email'] ?? ''),
        ]);
    }
    return checkin_mkt_login_redirect_response($redirect_base, ['login_error' => rawurlencode($data['message'] ?? 'Đăng nhập thất bại.')]);
}

// Trả về 302 redirect từ REST endpoint (browser đang điều hướng cả trang nên sẽ đi theo Location)
function checkin_mkt_login_redirect_response($base, $args) {
    $url      = add_query_arg($args, $base);
    $response = new WP_REST_Response(null, 302);
    $response->header('Location', $url);
    return $response;
}

// Xử lý đăng nhập Fb
function checkin_mkt_handle_facebook_login($request) {
    if (get_option('checkin_use_facebook_login', '0') !== '1') {
        return new WP_REST_Response(['success' => false, 'message' => 'Đăng nhập Facebook chưa được kích hoạt.'], 403);
    }

    $params       = $request->get_json_params();
    $access_token = $params['access_token'] ?? '';
    $remember     = $params['remember']     ?? true;
    $force_create = $params['force_create'] ?? false; // Cho phép tạo tài khoản mới

    if (empty($access_token)) {
        return new WP_REST_Response(['success' => false, 'message' => 'Thiếu access token Facebook.'], 400);
    }

    $user_data = checkin_verify_facebook_access_token($access_token);

    if (is_wp_error($user_data)) {
        return new WP_REST_Response(['success' => false, 'message' => $user_data->get_error_message()], 401);
    }

    return checkin_mkt_process_user_login($user_data, $remember, $force_create);
}

function checkin_mkt_process_user_login($user_data, $remember, $force_create = false) {
    $email = $user_data['email'];
    if (empty($email)) {
        return new WP_REST_Response(['success' => false, 'message' => 'Không thể lấy email từ token.'], 400);
    }

    // Bước 1: Tìm user theo email chính
    $user = get_user_by('email', $email);

    // Bước 2: Nếu không tìm thấy, kiểm tra secondary_emails (email đã liên kết)
    if (!$user) {
        $user = checkin_mkt_find_user_by_secondary_email($email);
    }

    // Bước 3: Nếu không tìm thấy, kiểm tra linked_social_accounts
    if (!$user) {
        $user = checkin_mkt_find_user_by_linked_account($email);
    }

    if ($user) {
        // Kiểm tra vai trò của người dùng
        $allowed_roles = ['customer', 'subscriber', 'staff', 'cashier', 'administrator'];
        $user_roles    = $user->roles; // Lấy danh sách vai trò của người dùng
        if (empty(array_intersect($allowed_roles, $user_roles))) {
            return new WP_REST_Response(['success' => false, 'message' => 'Tài khoản của bạn không có quyền đăng nhập.'], 403);
        }
    } else {
        // Không tìm thấy user với email này
        // Nếu force_create = false, trả về response để frontend hiển thị modal liên kết
        if (!$force_create) {
            return new WP_REST_Response([
                'success'        => false,
                'is_new_account' => true,
                'email'          => $email,
                'name'           => $user_data['name'] ?? '',
                'message'        => 'Email này chưa có tài khoản. Bạn có thể liên kết với tài khoản hiện có hoặc tạo tài khoản mới.',
            ], 200); // 200 để frontend xử lý, không phải error
        }

        // force_create = true: Tạo tài khoản mới
        $username        = sanitize_user(explode('@', $email)[0], true);

        // Đảm bảo username unique
        $base_username = $username;
        $counter       = 1;
        while (username_exists($username)) {
            $username = $base_username . $counter;
            $counter++;
        }

        $random_password = wp_generate_password(12, false);
        $user_id         = wp_create_user($username, $random_password, $email);
        if (is_wp_error($user_id)) {
            return new WP_REST_Response(['success' => false, 'message' => 'Không thể tạo tài khoản: ' . $user_id->get_error_message()], 500);
        }
        $user = get_user_by('id', $user_id);
        wp_update_user([
            'ID'           => $user_id,
            'display_name' => $user_data['name'] ?? $username,
        ]);
        // Gán vai trò mặc định là subscriber cho tài khoản mới
        $wp_user = new WP_User($user_id);
        $wp_user->set_role('subscriber');
    }

    wp_set_current_user($user->ID);
    wp_set_auth_cookie($user->ID, $remember);

    // Trigger wp_login action để đảm bảo WordPress commit session
    do_action('wp_login', $user->user_login, $user);

    // Set current user lại để đảm bảo session mới được sử dụng
    wp_set_current_user($user->ID);

    // Tạo nonce mới cho session mới - PHẢI sau khi session được commit
    $new_nonce = wp_create_nonce('wp_rest');

    // Lấy profile data để trả về luôn
    $profile_data = checkin_mkt_get_profile_data_for_user($user->ID);

    return new WP_REST_Response([
        'success' => true,
        'message' => 'Đăng nhập thành công.',
        'nonce'   => $new_nonce, // Trả về nonce mới
        'profile' => $profile_data, // Trả về profile luôn
        'wp_role' => !empty($user->roles) ? $user->roles[0] : 'subscriber', // Để JS cập nhật navbar không cần reload
    ], 200);
}

// Xử lý token Google
function checkin_verify_google_id_token($id_token) {
    $client_id = get_option('checkin_google_client_id', '');
    if (empty($client_id)) {
        return new WP_Error('missing_client_id', 'Google Client ID chưa được cấu hình.');
    }

    $response = wp_remote_get("https://www.googleapis.com/oauth2/v3/tokeninfo?id_token={$id_token}");
    if (is_wp_error($response)) {
        return new WP_Error('token_verification_failed', 'Lỗi khi xác minh token: ' . $response->get_error_message());
    }

    $body    = wp_remote_retrieve_body($response);
    $payload = json_decode($body, true);

    if (!$payload || isset($payload['error_description'])) {
        return new WP_Error('invalid_token', 'Token không hợp lệ: ' . ($payload['error_description'] ?? 'Lỗi không xác định'));
    }

    if ($payload['iss'] !== 'https://accounts.google.com' || $payload['aud'] !== $client_id) {
        return new WP_Error('invalid_token', 'Token không hợp lệ: Issuer hoặc Audience không khớp.');
    }

    if (isset($payload['exp']) && (int)$payload['exp'] < time()) {
        return new WP_Error('expired_token', 'Token đã hết hạn.');
    }

    return [
        'email' => $payload['email'] ?? '',
        'name'  => $payload['name']  ?? '',
        'sub'   => $payload['sub']   ?? '',
    ];
}

// Xử lý token Fb
function checkin_verify_facebook_access_token($access_token) {
    $app_id = get_option('checkin_facebook_app_id', '');
    if (empty($app_id)) {
        return new WP_Error('missing_app_id', 'Facebook App ID chưa được cấu hình.');
    }

    $response = wp_remote_get("https://graph.facebook.com/me?fields=id,email,name&access_token={$access_token}");
    if (is_wp_error($response)) {
        return new WP_Error('token_verification_failed', 'Lỗi khi xác minh access token: ' . $response->get_error_message());
    }

    $body    = wp_remote_retrieve_body($response);
    $payload = json_decode($body, true);

    if (!$payload || isset($payload['error'])) {
        return new WP_Error('invalid_token', 'Access token không hợp lệ: ' . ($payload['error']['message'] ?? 'Lỗi không xác định'));
    }

    return [
        'email' => $payload['email'] ?? '',
        'name'  => $payload['name']  ?? '',
        'sub'   => $payload['id']    ?? '',
    ];
}

function checkin_mkt_handle_fb_data_deletion_combined(WP_REST_Request $request) {
    if ($request->get_method() === 'GET') {
        // Facebook test compliance hoặc user mở link status
        $user_id = $request->get_param('id');
        return [
            'status'  => 'pending',
            'user_id' => $user_id,
            'message' => 'Your deletion request is being processed.'
        ];
    }

    // Nếu là POST → Facebook gửi signed_request khi gỡ ứng dụng
    $signed_request = $request->get_param('signed_request');
    if (empty($signed_request)) {
        return new WP_Error('no_signed_request', 'Missing signed_request parameter', ['status' => 400]);
    }

    // Lấy app secret từ cài đặt WP
    $app_secret = get_option('checkin_facebook_app_secret', '');
    if (empty($app_secret)) {
        return new WP_Error('no_app_secret', 'Facebook App Secret not configured', ['status' => 500]);
    }

    // Parse signed request
    $data = checkin_mkt_parse_signed_request($signed_request, $app_secret);
    if (!$data) {
        return new WP_Error('invalid_signature', 'Invalid signed request signature', ['status' => 400]);
    }

    $user_id           = isset($data['user_id']) ? $data['user_id'] : null;
    $status_url        = rest_url('vg/v1/deletion-status?id=' . $user_id);
    $confirmation_code = uniqid();

    // TODO: Thêm logic xóa dữ liệu user ở đây

    return [
        'url'               => $status_url,
        'confirmation_code' => $confirmation_code
    ];
}

/**
 * Parse signed request từ Facebook
 */
function checkin_mkt_parse_signed_request($signed_request, $app_secret) {
    list($encoded_sig, $payload) = explode('.', $signed_request, 2);

    $sig  = base64_url_decode($encoded_sig);
    $data = json_decode(base64_url_decode($payload), true);

    // Xác thực chữ ký
    $expected_sig = hash_hmac('sha256', $payload, $app_secret, true);
    if ($sig !== $expected_sig) {
        checkin_mkt192_log_error('login', 'Bad Signed JSON signature from Facebook', [
            'encoded_sig' => substr($encoded_sig, 0, 50) . '...',
            'payload'     => substr($payload, 0, 100) . '...'
        ]);
        return null;
    }

    return $data;
}

function base64_url_decode($input) {
    return base64_decode(strtr($input, '-_', '+/'));
}


// Xử lý đăng xuất
function checkin_mkt192_logout_staff(WP_REST_Request $request) {
    $log_file = __DIR__ . '/logs/staff-logout-log.log';
    file_put_contents($log_file, date('Y-m-d H:i:s') . " - Logout request received\n", FILE_APPEND);

    wp_logout();
    file_put_contents($log_file, date('Y-m-d H:i:s') . " - User logged out successfully\n", FILE_APPEND);

    return new WP_REST_Response([
        'success' => true,
        'message' => 'Đăng xuất thành công'
    ], 200);
}

// Xử lý đăng nhập thủ công
function checkin_mkt192_login_staff(WP_REST_Request $request) {
    $params   = $request->get_json_params();
    $username = sanitize_text_field($params['username'] ?? '');
    $password = $params['password'] ?? '';
    $remember = !empty($params['remember']);

    $user = wp_authenticate($username, $password);
    if (is_wp_error($user)) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Tên đăng nhập hoặc mật khẩu không đúng.',
        ], 200);
    }

    wp_set_current_user($user->ID);
    wp_set_auth_cookie($user->ID, $remember);

    // Trigger wp_login action để đảm bảo WordPress commit session
    do_action('wp_login', $user->user_login, $user);

    // Set current user lại để đảm bảo session mới được sử dụng
    wp_set_current_user($user->ID);

    // Tạo nonce mới cho session mới - PHẢI sau khi session được commit
    $new_nonce = wp_create_nonce('wp_rest');

    // Lấy profile data để trả về luôn, tránh phải gọi API thứ 2
    $profile_data = checkin_mkt_get_profile_data_for_user($user->ID);

    return new WP_REST_Response([
        'success' => true,
        'message' => 'Đăng nhập thành công.',
        'nonce'   => $new_nonce, // Trả về nonce mới
        'profile' => $profile_data, // Trả về profile luôn
        'wp_role' => !empty($user->roles) ? $user->roles[0] : 'subscriber', // Để JS cập nhật navbar không cần reload
    ], 200);
}

// Helper function để lấy profile data (dùng cho login response)
function checkin_mkt_get_profile_data_for_user($user_id) {
    global $wpdb;

    $user = get_userdata($user_id);
    if (!$user) return null;

    $user_login    = $user->user_login;
    $display_name  = $user->display_name;
    $user_email    = $user->user_email;
    $custom_avatar = get_user_meta($user_id, 'custom_avatar', true);
    $avatar_url    = $custom_avatar ?: get_avatar_url($user_id);

    // Lấy staff data
    $staff_data = $wpdb->get_row($wpdb->prepare(
        "SELECT employee_id, user_role, facebook_url, tiktok_url, birthday, gender, address, is_cccd
         FROM {$wpdb->prefix}checkin_mkt192_staff
         WHERE user_login = %s",
        $user_login
    ), ARRAY_A);

    $employee_id  = $staff_data ? $staff_data['employee_id'] : '';
    $user_role    = $staff_data ? $staff_data['user_role'] : 'Chưa xác định';
    $facebook_url = $staff_data ? $staff_data['facebook_url'] : get_user_meta($user_id, 'facebook_url', true);
    $tiktok_url   = $staff_data ? $staff_data['tiktok_url'] : get_user_meta($user_id, 'tiktok_url', true);
    $birthday     = $staff_data ? $staff_data['birthday'] : get_user_meta($user_id, 'birthday', true);
    $address      = $staff_data ? $staff_data['address'] : get_user_meta($user_id, 'address', true);
    $is_cccd      = $staff_data ? $staff_data['is_cccd'] : 0;
    $gender       = $staff_data ? $staff_data['gender'] : 'male';

    switch ($gender) {
        case 'male': $gender_display   = 'Nam'; break;
        case 'female': $gender_display = 'Nữ'; break;
        case 'other': $gender_display  = 'Khác'; break;
        default: $gender_display       = '';
    }

    // Lấy checkin logs
    $checkin_logs  = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}checkin_mkt192_checkinlogs
         WHERE display_name = %s
         ORDER BY checkin_time DESC LIMIT 30",
        $display_name
    ), OBJECT);

    $late_count    = 0;
    $total_penalty = 0.0;
    foreach ($checkin_logs as $log) {
        if ($log->status_late == 1) $late_count++;
        if ($log->penalty_amount > 0) $total_penalty += floatval($log->penalty_amount);
    }

    return [
        'display_name'  => $display_name,
        'user_role'     => $user_role,
        'gender'        => $gender_display,
        'avatar_url'    => $avatar_url,
        'employee_id'   => $employee_id,
        'email'         => $user_email,
        'facebook'      => $facebook_url ?: '',
        'tiktok'        => $tiktok_url ?: '',
        'birthday'      => $birthday ?: '',
        'address'       => $address ?: '',
        'is_cccd'       => (int) $is_cccd,
        'late_count'    => $late_count,
        'total_penalty' => $total_penalty,
        'checkin_logs'  => $checkin_logs
    ];
}

// Đổi mật khẩu
function checkin_mkt_change_password(WP_REST_Request $request) {
    $user = wp_get_current_user();
    if (!$user->ID) {
        return new WP_Error('not_logged_in', 'User not logged in', ['status' => 401]);
    }

    $current_password = $request->get_param('current_password');
    $new_password     = $request->get_param('new_password');

    if (!$current_password || !$new_password) {
        return new WP_Error('missing_params', 'Missing required parameters', ['status' => 400]);
    }

    if (!wp_check_password($current_password, $user->user_pass, $user->ID)) {
        return new WP_Error('invalid_password', 'Current password is incorrect', ['status' => 401]);
    }

    wp_set_password($new_password, $user->ID);
    wp_set_auth_cookie($user->ID, true); // Đăng nhập lại sau khi đổi mật khẩu

    return new WP_REST_Response([
        'success' => true,
        'message' => 'Đổi mật khẩu thành công'
    ], 200);
}

/**
 * Tìm user theo secondary email (email đã được liên kết)
 *
 * @param string $email Email cần tìm
 * @return WP_User|false User object hoặc false nếu không tìm thấy
 */
function checkin_mkt_find_user_by_secondary_email($email) {
    global $wpdb;

    // Tìm trong user meta 'secondary_emails'
    $meta_key = 'secondary_emails';

    // Query tất cả users có secondary_emails meta
    $users_with_secondary = $wpdb->get_results($wpdb->prepare(
        "SELECT user_id, meta_value FROM {$wpdb->usermeta} WHERE meta_key = %s",
        $meta_key
    ));

    foreach ($users_with_secondary as $row) {
        $secondary_emails = maybe_unserialize($row->meta_value);
        if (is_array($secondary_emails) && in_array($email, $secondary_emails, true)) {
            return get_user_by('id', $row->user_id);
        }
    }

    return false;
}

/**
 * Tìm user theo linked social account email
 *
 * @param string $email Email cần tìm
 * @return WP_User|false User object hoặc false nếu không tìm thấy
 */
function checkin_mkt_find_user_by_linked_account($email) {
    global $wpdb;

    // Tìm trong user meta 'linked_social_accounts'
    $meta_key = 'linked_social_accounts';

    // Query tất cả users có linked_social_accounts meta
    $users_with_linked = $wpdb->get_results($wpdb->prepare(
        "SELECT user_id, meta_value FROM {$wpdb->usermeta} WHERE meta_key = %s",
        $meta_key
    ));

    foreach ($users_with_linked as $row) {
        $linked_accounts = maybe_unserialize($row->meta_value);
        if (is_array($linked_accounts)) {
            foreach ($linked_accounts as $provider => $data) {
                if (isset($data['email']) && $data['email'] === $email) {
                    return get_user_by('id', $row->user_id);
                }
            }
        }
    }

    return false;
}
?>
