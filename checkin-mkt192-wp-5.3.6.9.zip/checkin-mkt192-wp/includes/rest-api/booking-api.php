<?php

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

require_once dirname(__FILE__, 2) . '/lark/class-checkin-mkt192-lark-booking-notification.php';
require_once dirname(__FILE__, 2) . '/zalo/class-checkin-mkt192-zalo-booking-message.php';
require_once dirname(__FILE__, 2) . '/zalo/class-checkin-mkt192-zalo-cancel-booking-message.php';

/**
 * Class xử lý các endpoint REST API cho quản lý lịch hẹn.
 */
class Checkin_MKT192_BookingAPI {
    /**
     * Ghi log vào file (tùy thuộc vào loại endpoint).
     *
     * @param string $type    Loại log (e.g., resend_booking, customer_booking, submit_booking).
     * @param string $message Thông điệp log.
     * @param array  $data    Dữ liệu bổ sung (tùy chọn).
     */
    private static function write_log($type, $message, $data = []) {
        $log_file = __DIR__ . "/logs/{$type}.log";
        if (!file_exists(dirname($log_file))) {
            mkdir(dirname($log_file), 0755, true);
        }
        $log_entry = date('Y-m-d H:i:s') . " - $message: " . json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
        file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);
    }

    /**
     * Lấy ngày/giờ theo timezone Việt Nam (Asia/Ho_Chi_Minh).
     * Tránh bug khi server chạy UTC: 1:00 AM VN = 18:00 UTC hôm trước.
     *
     * @param string $format    Định dạng date (e.g., 'Y-m-d', 'H:i:s').
     * @param string $modifier  Biểu thức tương đối (e.g., '+1 days', '-1 month'), null = hiện tại.
     * @return string
     */
    private static function vn_date($format = 'Y-m-d', $modifier = null) {
        $tz = new \DateTimeZone('Asia/Ho_Chi_Minh');
        $dt = new \DateTime('now', $tz);
        if ($modifier !== null) {
            $dt->modify($modifier);
        }
        return $dt->format($format);
    }

    /**
     * Đăng ký các endpoint REST API.
     */
    public static function register_routes() {
        // Lấy booking hoặc hủy booking theo ID
        register_rest_route('vg/v1', '/bookings/(?P<id_booking>[a-zA-Z0-9_-]+)', [
            [
                'methods'             => 'DELETE',
                'callback'            => [self::class, 'delete_booking'],
                'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'booking.delete'])
            ],
            [
                'methods'             => 'GET',
                'callback'            => [self::class, 'get_booking_by_id'],
                'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'booking.read'])
            ]
        ]);

        // Kiểm tra booking của thợ
        register_rest_route('vg/v1', '/hairdresser-availability', [
            'methods'             => 'POST',
            'callback'            => [self::class, 'check_hairdresser_availability'],
            'permission_callback' => '__return_true'
        ]);

        // Kiểm tra sự tồn tại của khách hàng
        register_rest_route('vg/v1', '/check-customer', [
            'methods'             => 'GET',
            'callback'            => [self::class, 'check_customer_existence'],
            'permission_callback' => '__return_true'
        ]);

        // Lấy danh sách thợ và thông tin nghỉ phép
        register_rest_route('vg/v1', '/hairdressers', [
            'methods'             => 'GET',
            'callback'            => [self::class, 'get_hairdressers'],
            'permission_callback' => '__return_true'
        ]);

        // Tạo mã booking
        register_rest_route('vg/v1', '/last-booking-number', [
            'methods'             => 'GET',
            'callback'            => [self::class, 'get_last_booking_number'],
            'permission_callback' => '__return_true',
        ]);

        // Trang app thợ lấy danh sách booking
        register_rest_route('vg/v1', '/staff-bookings', [
            'methods'             => 'GET',
            'callback'            => [self::class, 'get_staff_bookings'],
            'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'booking.read'])
        ]);

        // Trang thành viên lấy thông tin booking
        register_rest_route('vg/v1', '/customer-booking', [
            'methods'             => 'POST',
            'callback'            => [self::class, 'get_customer_booking'],
            'permission_callback' => '__return_true'
        ]);

        // Gửi lại thông báo booking
        register_rest_route('vg/v1', '/bookings/(?P<id_booking>[a-zA-Z0-9_-]+)/resend', [
            'methods'             => 'POST',
            'callback'            => [self::class, 'resend_booking_notification'],
            'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'booking.resend'])
        ]);

        // Gửi lại thông báo nhắc hẹn
        register_rest_route('vg/v1', '/bookings/(?P<id_booking>[a-zA-Z0-9_-]+)/resend-reminder', [
            'methods'             => 'POST',
            'callback'            => [self::class, 'resend_reminder_notification'],
            'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'booking.resend'])
        ]);

        // Gửi lại thông báo hủy lịch
        register_rest_route('vg/v1', '/bookings/(?P<id_booking>[a-zA-Z0-9_-]+)/resend-cancel', [
            'methods'             => 'POST',
            'callback'            => [self::class, 'resend_cancel_notification'],
            'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'booking.resend'])
        ]);

        // Cài đặt booking
        register_rest_route('vg/v1', '/booking-settings', [
            [
                'methods'             => 'GET',
                'callback'            => [self::class, 'get_booking_settings'],
                'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'booking.config'])
            ],
            [
                'methods'             => 'POST',
                'callback'            => [self::class, 'save_booking_settings'],
                'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'booking.config'])
            ]
        ]);

        // Xử lý đặt lịch
        register_rest_route('vg/v1', '/bookings', [
            'methods'             => 'POST',
            'callback'            => [self::class, 'submit_booking'],
            'permission_callback' => '__return_true'
        ]);

        // Lịch đi làm của Quản Lý
        register_rest_route('vg/v1', '/manager-schedules', [
            [
                'methods'             => 'GET',
                'callback'            => [self::class, 'get_manager_schedules'],
                'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'schedule.read'])
            ],
            [
                'methods'             => 'POST',
                'callback'            => [self::class, 'save_manager_schedules'],
                'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'schedule.manage'])
            ]
        ]);

        // Xóa lịch đi làm của Quản Lý
        register_rest_route('vg/v1', '/manager-schedules/delete', [
            'methods'             => 'POST',
            'callback'            => [self::class, 'delete_manager_schedule'],
            'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'schedule.manage'])
        ]);
    }

    /**
     * Lấy lịch đi làm của Quản Lý.
     *
     * @param WP_REST_Request $request Yêu cầu REST.
     * @return WP_REST_Response
     */
    public static function get_manager_schedules(WP_REST_Request $request) {
        global $wpdb;
        $table = $wpdb->prefix . 'checkin_mkt192_manager_schedules';

        $results = $wpdb->get_results("SELECT * FROM $table", ARRAY_A);

        return new WP_REST_Response(['success' => true, 'data' => $results], 200);
    }

    /**
     * Lưu lịch đi làm của Quản Lý.
     *
     * @param WP_REST_Request $request Yêu cầu REST.
     * @return WP_REST_Response
     */
    public static function save_manager_schedules(WP_REST_Request $request) {
        global $wpdb;
        $table = $wpdb->prefix . 'checkin_mkt192_manager_schedules';
        $data  = $request->get_json_params();

        if (!is_array($data)) {
            return new WP_REST_Response(['success' => false, 'message' => 'Dữ liệu không hợp lệ.'], 400);
        }

        $required_fields = ['staff_name', 'branch_id', 'start_date', 'end_date'];

        try {
            foreach ($data as $item) {
                foreach ($required_fields as $field) {
                    if (!isset($item[$field]) || $item[$field] === '') {
                        return new WP_REST_Response(['success' => false, 'message' => "Thiếu trường $field"], 400);
                    }
                }

                $fields = [
                    'staff_name' => sanitize_text_field($item['staff_name']),
                    'branch_id'  => intval($item['branch_id']),
                    'start_date' => sanitize_text_field($item['start_date']),
                    'end_date'   => sanitize_text_field($item['end_date']),
                ];

                // Kiểm tra xem lịch đã tồn tại chưa
                $existing = $wpdb->get_row($wpdb->prepare(
                    "SELECT * FROM $table WHERE staff_name = %s AND start_date = %s",
                    $fields['staff_name'], $fields['start_date']
                ), ARRAY_A);

                if ($existing) {
                    $wpdb->update($table, $fields, [
                        'staff_name' => $fields['staff_name'],
                        'start_date' => $fields['start_date']
                    ]);
                } else {
                    $wpdb->insert($table, $fields);
                }
            }

            return new WP_REST_Response(['success' => true, 'message' => 'Cập nhật lịch làm việc thành công.'], 200);
        } catch (Exception $e) {
            self::write_log('manager_schedules', 'Lỗi khi lưu lịch làm việc', ['error' => $e->getMessage()]);
            return new WP_REST_Response(['success' => false, 'message' => 'Lỗi hệ thống: ' . $e->getMessage()], 500);
        }
    }

    /**
     * Xóa lịch đi làm của Quản Lý.
     *
     * @param WP_REST_Request $request Yêu cầu REST.
     * @return WP_REST_Response
     */
    public static function delete_manager_schedule(WP_REST_Request $request) {
        global $wpdb;
        $table = $wpdb->prefix . 'checkin_mkt192_manager_schedules';
        $data  = $request->get_json_params();

        if (!isset($data['staff_name']) || !isset($data['start_date'])) {
            return new WP_REST_Response(['success' => false, 'message' => 'Thiếu thông tin staff_name hoặc start_date.'], 400);
        }

        try {
            $result = $wpdb->delete($table, [
                'staff_name' => sanitize_text_field($data['staff_name']),
                'start_date' => sanitize_text_field($data['start_date']),
            ]);

            if ($result === false) {
                throw new Exception('Lỗi khi xóa lịch làm việc: ' . $wpdb->last_error);
            }

            if ($result === 0) {
                return new WP_REST_Response(['success' => false, 'message' => 'Không tìm thấy lịch làm việc để xóa.'], 404);
            }

            return new WP_REST_Response(['success' => true, 'message' => 'Xóa lịch làm việc thành công.'], 200);
        } catch (Exception $e) {
            self::write_log('manager_schedules', 'Lỗi khi xóa lịch làm việc', ['error' => $e->getMessage()]);
            return new WP_REST_Response(['success' => false, 'message' => 'Lỗi hệ thống: ' . $e->getMessage()], 500);
        }
    }

    /**
     * Xử lý và lưu thông tin đặt lịch vào cơ sở dữ liệu, gửi thông báo qua Lark và Zalo.
     *
     * @param WP_REST_Request $request Yêu cầu REST.
     * @return WP_REST_Response
     */
    public static function submit_booking(WP_REST_Request $request) {
        // Rate limiting: 10 bookings per 5 minutes per IP
        $rate_limit = checkin_mkt192_apply_rate_limit('booking_submit', 10, 300);
        if (is_wp_error($rate_limit)) {
            return new WP_REST_Response([
                'success' => false,
                'message' => $rate_limit->get_error_message()
            ], 429);
        }

        global $wpdb;
        $data = $request->get_json_params();

        try {
            // Kiểm tra dữ liệu đầu vào
            if (empty($data)) {
                throw new Exception('Dữ liệu JSON không hợp lệ');
            }

            self::write_log('submit_booking', 'Dữ liệu nhận được', $data);

            // Lấy và làm sạch dữ liệu
            $idBooking     = isset($data['idBooking']) ? sanitize_text_field(trim($data['idBooking'])) : '';
            $services      = isset($data['services']) && is_array($data['services']) ? array_map('sanitize_text_field', $data['services']) : [];
            $phone         = isset($data['phone']) ? sanitize_text_field(trim($data['phone'])) : '';
            $customer      = isset($data['customerName']) ? sanitize_text_field(trim($data['customerName'])) : '';
            $hairdresser   = isset($data['hairdresser']) ? sanitize_text_field(trim($data['hairdresser'])) : '';
            $branch        = isset($data['branch']) ? sanitize_text_field(trim($data['branch'])) : '';
            $branch_id     = isset($data['branch_id']) ? intval($data['branch_id']) : 0;
            $time          = isset($data['time']) ? sanitize_text_field(trim($data['time'])) : '';
            $date          = isset($data['date']) ? sanitize_text_field(trim($data['date'])) : '';
            $note          = isset($data['note']) ? sanitize_textarea_field(trim($data['note'])) : '';
            $customerType  = isset($data['customerType']) ? sanitize_text_field(trim($data['customerType'])) : '';
            $silentService = isset($data['silentService']) ? sanitize_text_field(trim($data['silentService'])) : '';
            $customerCount = isset($data['customerCount']) ? absint($data['customerCount']) : 1;

            // Chuẩn hóa định dạng ngày tháng
            if (empty($date) || $date === 'Hôm nay') {
                // Fallback: nếu date rỗng (bug frontend) hoặc "Hôm nay" → dùng ngày VN hiện tại
                $date = self::vn_date('Y-m-d');
            } else {
                $dateParts = explode('/', $date);
                if (count($dateParts) === 3) {
                    $date = $dateParts[2] . '-' . $dateParts[1] . '-' . $dateParts[0];
                } else {
                    self::write_log('submit_booking', 'Lỗi định dạng ngày', ['date' => $date]);
                    return new WP_REST_Response(['success' => false, 'message' => 'Định dạng ngày không hợp lệ'], 400);
                }
            }

            // Chuẩn bị service_name và services JSON
            $serviceName  = !empty($services) ? implode(', ', $services) : '';
            $servicesData = [];
            if (!empty($services)) {
                foreach ($services as $service) {
                    $servicePrice = $wpdb->get_var($wpdb->prepare(
                        "SELECT service_price FROM {$wpdb->prefix}checkin_mkt192_service_data WHERE service_name = %s",
                        $service
                    ));
                    $servicesData[] = [
                        'service_name'  => $service,
                        'service_price' => $servicePrice ? (int) $servicePrice : 0
                    ];
                }
            }
            $servicesJson = json_encode($servicesData, JSON_UNESCAPED_UNICODE);

            // Chuẩn bị dữ liệu để lưu vào database
            $table_name     = $wpdb->prefix . 'bookingmkt192_booking_data';
            $data_to_insert = [
                'id_booking'       => $idBooking,
                'service_name'     => $serviceName,
                'services'         => $servicesJson,
                'customer_phone'   => $phone,
                'customer_name'    => $customer,
                'hairdresser_name' => $hairdresser,
                'booking_time'     => $time,
                'booking_date'     => $date,
                'customer_note'    => $note,
                'customer_count'   => $customerCount,
                'silent_service'   => $silentService,
                'customer_type'    => $customerType
            ];

            // Thêm branch nếu có
            if (!empty($branch)) {
                $data_to_insert['branch'] = $branch;
            }

            // Thêm branch_id nếu có
            if (!empty($branch_id)) {
                $data_to_insert['branch_id'] = $branch_id;
            }

            // Lưu dữ liệu vào database
            $format = ['%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s'];
            if (!empty($branch)) {
                $format[] = '%s';
            }
            if (!empty($branch_id)) {
                $format[] = '%d';
            }
            $result = $wpdb->insert($table_name, $data_to_insert, $format);

            if ($result === false) {
                throw new Exception('Lỗi khi lưu dữ liệu vào database: ' . $wpdb->last_error);
            }

            // Cập nhật id_zalo cho customer nếu có (từ Zalo widget consent)
            $id_zalo = isset($data['id_zalo']) ? sanitize_text_field(trim($data['id_zalo'])) : '';

            self::write_log('submit_booking', 'Kiểm tra id_zalo', [
                'id_zalo_received' => $id_zalo,
                'phone_received'   => $phone,
                'has_id_zalo'      => !empty($id_zalo),
                'has_phone'        => !empty($phone)
            ]);

            if (!empty($id_zalo) && !empty($phone)) {
                $customer_table = $wpdb->prefix . 'bookingmkt192_customer_data';

                // Chuẩn hóa phone để tìm kiếm (có thể là 962794917 hoặc 0962794917)
                $phone_without_zero = ltrim($phone, '0');
                $phone_with_zero    = '0' . $phone_without_zero;

                self::write_log('submit_booking', 'Tìm kiếm customer với phone', [
                    'phone_without_zero' => $phone_without_zero,
                    'phone_with_zero'    => $phone_with_zero
                ]);

                // Kiểm tra xem customer có tồn tại không
                $customer_id = $wpdb->get_var($wpdb->prepare(
                    "SELECT customer_id FROM $customer_table WHERE customer_phone = %s OR customer_phone = %s",
                    $phone_without_zero,
                    $phone_with_zero
                ));

                if ($customer_id) {
                    // Cập nhật id_zalo cho customer hiện có
                    $updated = $wpdb->update(
                        $customer_table,
                        ['id_zalo'     => $id_zalo],
                        ['customer_id' => $customer_id],
                        ['%s'],
                        ['%s']  // customer_id là VARCHAR
                    );

                    if ($updated !== false) {
                        self::write_log('submit_booking', 'Đã cập nhật id_zalo cho customer', [
                            'customer_id' => $customer_id,
                            'id_zalo'     => $id_zalo
                        ]);
                    } else {
                        self::write_log('submit_booking', 'Lỗi khi cập nhật id_zalo', [
                            'customer_id' => $customer_id,
                            'id_zalo'     => $id_zalo,
                            'error'       => $wpdb->last_error
                        ]);
                    }
                } else {
                    self::write_log('submit_booking', 'Không tìm thấy customer để cập nhật id_zalo', [
                        'phone'   => $phone,
                        'id_zalo' => $id_zalo
                    ]);
                }
            }

            // Gửi thông báo đến group Lark
            $link_bookingnew = "https://vangroupbarbershop.store/customer-member?booking_id=$idBooking";
            $booking_data    = [
                'id_booking'      => $idBooking,
                'booking_date'    => $date,
                'booking_time'    => $time,
                'customer_name'   => $customer,
                'service_name'    => $serviceName,
                'hairdresser'     => $hairdresser,
                'branch'          => $branch,
                'booking_note'    => $note,
                'customer_count'  => $customerCount,
                'silent_service'  => $silentService,
                'link_bookingnew' => $link_bookingnew,
                'power_by'        => 'Website'
            ];

            // Gửi thông báo Lark nếu được bật
            if (is_lark_enabled()) {
                $lark_result = Checkin_MKT192_LarkBookingNotification::send_booking_notification($booking_data);
                self::write_log('submit_booking', 'Kết quả gửi Lark', $lark_result);
            } else {
                self::write_log('submit_booking', 'Lark bị tắt, bỏ qua gửi thông báo');
            }

            // Lấy dữ liệu booking từ database để gửi Zalo
            $booking = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}bookingmkt192_booking_data WHERE id_booking = %s",
                $idBooking
            ));

            // Gửi tin nhắn Zalo
            $zalo_result = Checkin_MKT192_ZaloBookingMessage::send_booking_message($booking);
            self::write_log('submit_booking', 'Kết quả gửi Zalo', $zalo_result);

            // Send push notification to staff about new booking
            if (function_exists('checkin_mkt192_notify_booking_to_staff') && !empty($hairdresser)) {
                // Get staff WordPress user ID
                $staff_user_id = $wpdb->get_var($wpdb->prepare(
                    "SELECT user_id FROM {$wpdb->prefix}checkin_mkt192_staff WHERE display_name = %s",
                    $hairdresser
                ));

                if ($staff_user_id) {
                    checkin_mkt192_notify_booking_to_staff($staff_user_id, [
                        'id_booking'    => $idBooking,
                        'customer_name' => $customer,
                        'booking_time'  => $time . ' ' . $date,
                        'branch_id'     => $branch_id
                    ]);
                    self::write_log('submit_booking', 'Đã gửi push notification đến staff', ['staff_user_id' => $staff_user_id]);
                }
            }

            // Trả về phản hồi JSON
            return new WP_REST_Response(['success' => true, 'message' => 'Đặt lịch thành công!'], 200);
        } catch (Exception $e) {
            self::write_log('submit_booking', 'Lỗi khi xử lý đặt lịch', ['error' => $e->getMessage()]);
            return new WP_REST_Response(['success' => false, 'message' => 'Có lỗi xảy ra: ' . $e->getMessage()], 500);
        }
    }

    /**
     * Kiểm tra lịch làm việc và xung đột thời gian của thợ.
     *
     * @param WP_REST_Request $request Yêu cầu REST.
     * @return WP_REST_Response
     */
    public static function check_hairdresser_availability(WP_REST_Request $request) {
        // Rate limiting: 60 requests per minute per IP
        $rate_limit = checkin_mkt192_apply_rate_limit('hairdresser_availability', 60, 60);
        if (is_wp_error($rate_limit)) {
            return new WP_REST_Response([
                'success' => false,
                'message' => $rate_limit->get_error_message()
            ], 429);
        }

        global $wpdb;
        $data = $request->get_json_params();

        try {
            // Lấy và làm sạch dữ liệu
            $hairdresser = isset($data['hairdresser']) ? sanitize_text_field(trim($data['hairdresser'])) : '';
            $date        = isset($data['date']) ? sanitize_text_field(trim($data['date'])) : '';
            $timeSlots   = isset($data['timeSlots']) && is_array($data['timeSlots']) ? array_map('sanitize_text_field', $data['timeSlots']) : [];

            // Kiểm tra dữ liệu đầu vào
            if (empty($hairdresser) || empty($date)) {
                return new WP_REST_Response([
                    'success'      => false,
                    'message'      => 'Thiếu thông tin Thợ hoặc ngày.',
                    'resetToStep1' => true
                ], 400);
            }

            if (empty($timeSlots)) {
                return new WP_REST_Response([
                    'success'      => false,
                    'message'      => 'Đã hết giờ hoạt động hôm nay, vui lòng chọn ngày khác',
                    'resetToStep1' => false
                ], 400);
            }

            // Chuẩn hóa ngày
            if ($date === 'Hôm nay') {
                $date = self::vn_date('Y-m-d');
            }

            // Lấy trạng thái và vai trò của thợ
            $hairdresser_data = $wpdb->get_row($wpdb->prepare(
                "SELECT status, user_role FROM {$wpdb->prefix}checkin_mkt192_staff WHERE display_name = %s",
                $hairdresser
            ), ARRAY_A);

            if (!$hairdresser_data) {
                return new WP_REST_Response([
                    'success'      => false,
                    'message'      => 'Không tìm thấy thông tin Thợ.',
                    'resetToStep1' => true
                ], 404);
            }

            $hairdresser_status = $hairdresser_data['status'] ?: 'Unknown';
            $is_manager         = strpos($hairdresser_data['user_role'], 'Quản Lý') !== false ? 1 : 0;

            // Kiểm tra lịch làm việc của Quản Lý nếu là Quản Lý
            if ($is_manager) {
                $schedule = $wpdb->get_row($wpdb->prepare(
                    "SELECT start_date, end_date
                     FROM {$wpdb->prefix}checkin_mkt192_manager_schedules
                     WHERE staff_name = %s
                       AND start_date <= %s
                       AND end_date >= %s",
                    $hairdresser, $date, $date
                ), ARRAY_A);

                if (!$schedule) {
                    $today         = self::vn_date('Y-m-d');
                    $all_schedules = $wpdb->get_results($wpdb->prepare(
                        "SELECT start_date, end_date
                         FROM {$wpdb->prefix}checkin_mkt192_manager_schedules
                         WHERE staff_name = %s
                         ORDER BY start_date ASC",
                        $hairdresser
                    ), ARRAY_A);

                    // Kiểm tra nếu tất cả lịch đều là quá khứ
                    $has_future_schedule = false;
                    foreach ($all_schedules as $sched) {
                        if ($sched['end_date'] >= $today) {
                            $has_future_schedule = true;
                            break;
                        }
                    }

                    if (!$has_future_schedule) {
                        $hotline = get_option('checkin_phone', '');
                        return new WP_REST_Response([
                            'success'      => false,
                            'message'      => "Quản Lý $hairdresser không có lịch làm việc vào ngày $date. Vui lòng gọi số hotline $hotline để liên hệ trực tiếp Quản lý!",
                            'resetToStep1' => false
                        ], 400);
                    }

                    return new WP_REST_Response([
                        'success'      => false,
                        'message'      => "Quản Lý $hairdresser không có lịch làm việc vào ngày $date.",
                        'schedules'    => $all_schedules,
                        'resetToStep1' => false
                    ], 400);
                }
            }

            // Kiểm tra lịch nghỉ phép từ bảng approval_requests mới
            $leaves = $wpdb->get_results($wpdb->prepare(
                "SELECT leave_start_date, leave_end_date
                 FROM {$wpdb->prefix}checkin_mkt192_approval_requests
                 WHERE staff_name = %s
                   AND request_type = 'leave'
                   AND status = 'approved'
                   AND (
                     (leave_start_date <= %s AND leave_end_date >= %s)
                     OR (leave_start_date <= %s AND leave_end_date >= %s)
                   )",
                $hairdresser, $date, $date, $date, $date
            ), ARRAY_A);

            foreach ($leaves as $leave) {
                $leave_start_date = substr($leave['leave_start_date'], 0, 10);
                $leave_end_date   = substr($leave['leave_end_date'], 0, 10);

                if ($date >= $leave_start_date && $date <= $leave_end_date) {
                    return new WP_REST_Response([
                        'success'      => false,
                        'message'      => "Thợ $hairdresser có lịch nghỉ phép từ {$leave['leave_start_date']} đến {$leave['leave_end_date']}. Vui lòng chọn Thợ khác",
                        'resetToStep1' => true
                    ], 400);
                }
            }

            // Kiểm tra đơn xin đi trễ/về sớm từ bảng approval_requests
            $late_early_requests = $wpdb->get_results($wpdb->prepare(
                "SELECT late_early_type, late_early_minutes
                 FROM {$wpdb->prefix}checkin_mkt192_approval_requests
                 WHERE staff_name = %s
                   AND request_type = 'late_early'
                   AND status = 'approved'
                   AND late_early_date = %s",
                $hairdresser, $date
            ), ARRAY_A);

            // Biến lưu thời gian bị chặn do đi trễ/về sớm
            $late_blocked_until  = null; // Giờ bắt đầu nhận booking (nếu đi trễ)
            $early_blocked_from  = null; // Giờ kết thúc nhận booking (nếu về sớm)
            $late_early_message  = '';

            foreach ($late_early_requests as $request) {
                $minutes = intval($request['late_early_minutes']);

                if ($request['late_early_type'] === 'late') {
                    // Đi trễ: Tính giờ bắt đầu làm = 08:30 + số phút đi trễ
                    $default_start      = strtotime($date . ' 08:30:00');
                    $new_start          = $default_start + ($minutes * 60);
                    $late_blocked_until = date('H:i', $new_start);
                    $late_early_message .= "Thợ $hairdresser đi trễ $minutes phút, bắt đầu nhận khách từ $late_blocked_until. ";
                } elseif ($request['late_early_type'] === 'early') {
                    // Về sớm: Tính giờ kết thúc làm = 20:30 - số phút về sớm
                    $default_end        = strtotime($date . ' 20:30:00');
                    $new_end            = $default_end - ($minutes * 60);
                    $early_blocked_from = date('H:i', $new_end);
                    $late_early_message .= "Thợ $hairdresser về sớm $minutes phút, nhận khách đến $early_blocked_from. ";
                }
            }

            // Lấy danh sách các ngày đặc biệt
            $special_days = $wpdb->get_results($wpdb->prepare(
                "SELECT start_date, start_time, end_date, end_time, type, message
                 FROM {$wpdb->prefix}bookingmkt192_special_days
                 WHERE start_date <= %s AND (end_date >= %s OR end_date = '0000-00-00')",
                $date, $date
            ), ARRAY_A);

            // Tạo khung giờ mặc định (ngày bình thường)
            $start_hour_default   = 8;
            $start_minute_default = 30;
            $end_hour_default     = 20;
            $end_minute_default   = 30;

            // Tạo danh sách khung giờ
            $timeSlotsToCheck   = [];
            $is_overtime        = false;
            $is_event           = false;
            $event_message      = '';
            $event_start_time   = '';
            $overtime_start_str = '';
            $overtime_end_str   = '';

            foreach ($special_days as $day) {
                // Chỉ gán các biến khi ngày trùng khớp với ngày đang kiểm tra
                if ($date >= $day['start_date'] && ($date <= $day['end_date'] || $day['end_date'] === '0000-00-00')) {
                    if ($day['type'] === 'holiday') {
                        $holiday_message = $day['message'] ?: 'Ngày nghỉ, không nhận đặt lịch.';
                        return new WP_REST_Response([
                            'success'      => false,
                            'message'      => $holiday_message,
                            'resetToStep1' => false
                        ], 400);
                    } elseif ($day['type'] === 'event') {
                        $is_event         = true;
                        $event_start_time = $day['start_time'];
                        $event_message    = $day['message'];
                    } elseif ($day['type'] === 'overtime') {
                        $is_overtime          = true;
                        $overtime_start_str   = substr($day['start_time'], 0, 5);
                        $overtime_end_str     = substr($day['end_time'], 0, 5);
                        $start_hour_default   = (int)substr($day['start_time'], 0, 2);
                        $start_minute_default = (int)substr($day['start_time'], 3, 2);
                        $end_hour_default     = (int)substr($day['end_time'], 0, 2);
                        $end_minute_default   = (int)substr($day['end_time'], 3, 2);
                        $event_message        = $day['message'];
                    }
                }
            }

            // Tạo khung giờ khả dụng
            $start_hour   = $is_overtime ? $start_hour_default : 8;
            $start_minute = $is_overtime ? $start_minute_default : 30;
            $end_hour     = $is_overtime ? $end_hour_default : 20;
            $end_minute   = $is_overtime ? $end_minute_default : 30;

            $current_time = mktime($start_hour, $start_minute, 0, date('m', strtotime($date)), date('d', strtotime($date)), date('Y', strtotime($date)));
            $end_time     = mktime($end_hour, $end_minute, 0, date('m', strtotime($date)), date('d', strtotime($date)), date('Y', strtotime($date)));

            while ($current_time <= $end_time) {
                $hour                   = date('H', $current_time);
                $minute                 = date('i', $current_time);
                $time_slot              = sprintf('%02d:%02d', $hour, $minute);
                $timeSlotsToCheck[]     = $time_slot;
                $current_time           = strtotime('+30 minutes', $current_time);
            }

            // Kiểm tra xung đột lịch hẹn
            $conflicts           = [];
            $nearestTimeConflict = null;
            $bookings            = $wpdb->get_results($wpdb->prepare(
                "SELECT booking_date, booking_time, status
                 FROM {$wpdb->prefix}bookingmkt192_booking_data
                 WHERE hairdresser_name = %s
                   AND booking_date = %s
                   AND status IN ('pending', 'start')
                 ORDER BY booking_time ASC",
                $hairdresser, $date
            ), ARRAY_A);

            foreach ($timeSlotsToCheck as $time) {
                $booking_datetime = $date . ' ' . $time . ':00';
                $selected_time    = strtotime($booking_datetime);
                $is_conflict      = false;

                // Kiểm tra xung đột với lịch hẹn hiện có
                foreach ($bookings as $booking) {
                    $current_booking_time = strtotime($booking['booking_date'] . ' ' . $booking['booking_time']);
                    if ($selected_time >= $current_booking_time - 1800 && $selected_time < $current_booking_time + 3600) {
                        $is_conflict = true;
                        break;
                    }
                }

                // Nếu là ngày sự kiện, đánh dấu các khung giờ từ start_time trở đi là xung đột
                if ($is_event && $time >= substr($event_start_time, 0, 5)) {
                    $is_conflict = true;
                }

                // Kiểm tra đi trễ: các slot trước giờ bắt đầu làm sẽ bị khóa
                if ($late_blocked_until !== null && $time < $late_blocked_until) {
                    $is_conflict = true;
                }

                // Kiểm tra về sớm: các slot từ giờ kết thúc làm trở đi sẽ bị khóa
                if ($early_blocked_from !== null && $time >= $early_blocked_from) {
                    $is_conflict = true;
                }

                // Nếu là ngày hiện tại, làm mờ các khung giờ trước thời gian hiện tại + 1 giờ
                if ($hairdresser_status === 'BUSY' && $date === self::vn_date('Y-m-d')) {
                    $current_time      = new DateTime('now', new DateTimeZone('Asia/Ho_Chi_Minh'));
                    $current_time->modify('+1 hour');
                    $selected_datetime = DateTime::createFromFormat('Y-m-d H:i:s', $booking_datetime);
                    if ($selected_datetime && $selected_datetime <= $current_time) {
                        $is_conflict = true;
                        if ($nearestTimeConflict === null) {
                            $nearestTimeConflict = $time;
                        }
                    }
                }

                $conflicts[$time] = $is_conflict;
            }

            // Xây dựng message phản hồi
            $response_message = '';
            if ($is_overtime) {
                $response_message = $event_message ?: "Đây là khung giờ làm thêm theo lịch: {$overtime_start_str} - {$overtime_end_str}.";
            } elseif ($is_event) {
                $response_message = $event_message ?: 'Vì lý do Shop tổ chức sự kiện Tiệc Tất Niên vào tối nay nên xin phép không nhận lịch hẹn từ ' . substr($event_start_time, 0, 5) . ' trở đi. Mong quý khách thông cảm!';
            } elseif (!empty($late_early_message)) {
                $response_message = trim($late_early_message);
            }

            return new WP_REST_Response([
                'success'              => true,
                'hairdresser_status'   => $hairdresser_status,
                'is_manager'           => $is_manager,
                'conflicts'            => $conflicts,
                'available_time_slots' => $timeSlotsToCheck,
                'message'              => $response_message,
                'leaves'               => $leaves,
                'late_blocked_until'   => $late_blocked_until,
                'early_blocked_from'   => $early_blocked_from,
                'nearestTimeConflict'  => $nearestTimeConflict,
                'resetToStep1'         => false
            ], 200);

        } catch (Exception $e) {
            self::write_log('check_hairdresser_availability', 'Lỗi khi kiểm tra lịch làm việc', ['error' => $e->getMessage()]);
            return new WP_REST_Response([
                'success'      => false,
                'message'      => 'Có lỗi xảy ra: ' . $e->getMessage(),
                'resetToStep1' => false
            ], 500);
        }
    }

    /**
     * Kiểm tra sự tồn tại của khách hàng dựa trên số điện thoại.
     *
     * @param WP_REST_Request $request Yêu cầu REST.
     * @return WP_REST_Response
     */
    public static function check_customer_existence(WP_REST_Request $request) {
        // Rate limiting: 30 requests per minute per IP
        $rate_limit = checkin_mkt192_apply_rate_limit('check_customer', 30, 60);
        if (is_wp_error($rate_limit)) {
            return new WP_REST_Response([
                'success' => false,
                'message' => $rate_limit->get_error_message()
            ], 429);
        }

        global $wpdb;
        $phone = sanitize_text_field($request->get_param('phone'));

        try {
            if (empty($phone)) {
                return new WP_REST_Response(['success' => false, 'message' => 'Vui lòng cung cấp số điện thoại.'], 400);
            }

            // Kiểm tra xem số điện thoại có tồn tại trong database không
            $customer = $wpdb->get_row($wpdb->prepare(
                "SELECT customer_name, hairdresser_name FROM {$wpdb->prefix}bookingmkt192_customer_data WHERE customer_phone = %s",
                $phone
            ), ARRAY_A);

            if ($customer) {
                return new WP_REST_Response([
                    'success'         => true,
                    'exists'          => true,
                    'customerName'    => $customer['customer_name'],
                    'hairdresserName' => $customer['hairdresser_name']
                ], 200);
            } else {
                return new WP_REST_Response([
                    'success' => true,
                    'exists'  => false
                ], 200);
            }
        } catch (Exception $e) {
            self::write_log('check_customer_existence', 'Lỗi khi kiểm tra khách hàng', ['phone' => $phone, 'error' => $e->getMessage()]);
            return new WP_REST_Response(['success' => false, 'message' => 'Có lỗi xảy ra: ' . $e->getMessage()], 500);
        }
    }

    /**
     * Lấy danh sách thợ và thông tin nghỉ phép, cập nhật trạng thái thợ.
     *
     * @param WP_REST_Request $request Yêu cầu REST.
     * @return WP_REST_Response
     */
    public static function get_hairdressers(WP_REST_Request $request) {
        global $wpdb;

        try {
        date_default_timezone_set('Asia/Ho_Chi_Minh');

        // Lấy danh sách thợ và thông tin nghỉ phép, bao gồm chi nhánh
        $result = $wpdb->get_results("
            SELECT
                s.display_name AS hairdresser_name,
                s.status AS hairdresser_status,
                s.user_role AS user_role,
                s.branch AS branch,
                s.branch_id AS branch_id,
                s.phone AS phone,
                MAX(CASE
                    WHEN lr.status = 'approved'
                    AND CURDATE() BETWEEN lr.leave_start_date AND lr.leave_end_date
                    THEN 1 ELSE 0
                END) AS is_off_today,
                MIN(CASE
                    WHEN lr.status = 'approved'
                    AND lr.leave_start_date > CURDATE()
                    THEN lr.leave_start_date
                    ELSE NULL
                END) AS off_future_start,
                MAX(CASE
                    WHEN lr.status = 'approved'
                    AND lr.leave_start_date > CURDATE()
                    THEN lr.leave_end_date
                    ELSE NULL
                END) AS off_future_end
            FROM {$wpdb->prefix}checkin_mkt192_staff s
            LEFT JOIN {$wpdb->prefix}checkin_mkt192_approval_requests lr
                ON s.display_name COLLATE utf8mb4_unicode_520_ci = lr.staff_name COLLATE utf8mb4_unicode_520_ci
                AND lr.request_type = 'leave'
            WHERE s.user_role IN ('Thợ Chính', 'Thợ Phụ', 'Quản Lý')
                -- PAUSE (tạm dừng) vẫn hiện: thợ còn nhận đặt lịch, kèm SĐT để
                -- khách gọi trực tiếp. ARCHIVED (nghỉ việc) thì ẩn hẳn.
                AND s.status NOT IN ('DELETED', 'ARCHIVED')
            GROUP BY s.display_name, s.status, s.user_role, s.branch, s.phone
        ", ARRAY_A);

        // Lấy đường dẫn thư mục ảnh
        $upload_dir       = wp_upload_dir();
        $staff_image_dir  = $upload_dir['baseurl'] . '/checkin-mkt192-wp/home/staff/';
        $staff_image_path = $upload_dir['basedir'] . '/checkin-mkt192-wp/home/staff/';

        // Lấy danh sách file ảnh
        $image_files = glob($staff_image_path . '*.{jpg,jpeg,png,gif,webp}', GLOB_BRACE);
        $image_files = array_map('basename', $image_files);

        // Chuẩn hoá Unicode về NFC khi so sánh: file up từ macOS thường ở dạng NFD
        // (tách dấu rời), nhìn giống hệt display_name trong DB nhưng khác byte
        // → so sánh chính xác trượt và thợ bị rơi về ảnh mặc định
        $normalize = function ($s) {
            return class_exists('Normalizer') ? Normalizer::normalize($s, Normalizer::FORM_C) : $s;
        };
        $image_lookup = [];
        foreach ($image_files as $file) {
            $image_lookup[$normalize($file)] = $file; // key chuẩn hoá → tên file thật trên disk
        }

        foreach ($result as &$row) {
            // Kiểm tra vai trò Quản Lý
            $is_manager        = strpos($row['user_role'], 'Quản Lý') !== false;
            $row['is_manager'] = $is_manager ? 1 : 0;

            // Giữ nguyên tên thợ có dấu
            $base_name = $normalize($row['hairdresser_name']); // Không thay khoảng trắng
            $image_url = $upload_dir['baseurl'] . '/default-barber.jpg'; // Ảnh mặc định

            // Kiểm tra các định dạng file ảnh
            $possible_extensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
            foreach ($possible_extensions as $ext) {
                $image_name = $base_name . '.' . $ext;
                if (isset($image_lookup[$image_name])) {
                    // ?v=filemtime: URL đổi theo nội dung file — thay ảnh thợ là khách
                    // thấy ngay, không bị kẹt cache trình duyệt 7 ngày (max-age hosting)
                    $real_file = $image_lookup[$image_name];
                    $version   = @filemtime($staff_image_path . $real_file) ?: time();
                    $image_url = $staff_image_dir . rawurlencode($real_file) . '?v=' . $version;
                    break;
                }
            }

            $row['hairdresser_image'] = $image_url;

            $row['phone'] = (string) ($row['phone'] ?? '');

            if ($row['hairdresser_status'] === 'PAUSE') {
                // Tạm dừng: giữ nguyên trạng thái, bỏ qua đoạn tự ép OFF/ON bên dưới
                // (một đơn nghỉ phép cũ còn hiệu lực sẽ ghi đè mất trạng thái này).
                $row['is_paused'] = 1;
                continue;
            }

            $row['is_paused'] = 0;

            if ($row['is_off_today']) {
                // Cập nhật trạng thái thành OFF nếu thợ nghỉ hôm nay
                $wpdb->query($wpdb->prepare(
                    "UPDATE {$wpdb->prefix}checkin_mkt192_staff SET status = %s WHERE display_name = %s",
                    'OFF', $row['hairdresser_name']
                ));
                $row['hairdresser_status'] = 'OFF';
            } elseif ($row['hairdresser_status'] === 'OFF' && !$row['is_off_today'] && !$is_manager) {
                // Cập nhật trạng thái thành ON nếu không nghỉ và không phải Quản Lý
                $wpdb->query($wpdb->prepare(
                    "UPDATE {$wpdb->prefix}checkin_mkt192_staff SET status = %s WHERE display_name = %s",
                    'ON', $row['hairdresser_name']
                ));
                $row['hairdresser_status'] = 'ON';
            }
        }

        // Debug: Log số lượng thợ trả về
        error_log('Total hairdressers returned: ' . count($result));

        // Check if there's a database error
        if ($wpdb->last_error) {
            error_log('Database error in get_hairdressers: ' . $wpdb->last_error);
        }

        return new WP_REST_Response([
            'success' => true,
            'data'    => $result,
            'message' => 'Lấy danh sách thợ thành công'
        ], 200);

    } catch (Exception $e) {
        error_log('Exception in get_hairdressers: ' . $e->getMessage());
        self::write_log('get_hairdressers', 'Lỗi khi lấy danh sách thợ', ['error' => $e->getMessage()]);
        return new WP_REST_Response(['success' => false, 'message' => 'Lỗi hệ thống: ' . $e->getMessage()], 500);
    }
}

    /**
     * Tạo mã booking.
     *
     * @param WP_REST_Request $request Yêu cầu REST.
     * @return WP_REST_Response
     */
    public static function get_last_booking_number(WP_REST_Request $request) {
    global $wpdb;

    try {
        date_default_timezone_set('Asia/Ho_Chi_Minh');

        // Lấy checkin_date từ request
        $checkin_date = isset($request['checkin_date']) ? sanitize_text_field(trim($request['checkin_date'])) : '';

        // Nếu không có checkin_date hoặc sai định dạng, sử dụng ngày hiện tại
        if (empty($checkin_date) || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $checkin_date)) {
            $checkin_date = self::vn_date('Y-m-d');
        }

        // Định dạng ngày checkin_date thành ddmmyy
        $formatted_date = date('dmY', strtotime($checkin_date));

        // Bắt đầu giao dịch với khóa
        $wpdb->query('START TRANSACTION');

        // Lấy tất cả id_booking trong ngày checkin_date với khóa FOR UPDATE
        $bookings = $wpdb->get_results($wpdb->prepare(
            "SELECT id_booking
             FROM {$wpdb->prefix}bookingmkt192_booking_data
             WHERE DATE(booking_date) = %s
             FOR UPDATE",
            $checkin_date
        ), ARRAY_A);

        $max_id_number = 0;
        $prefix        = 'BK' . $formatted_date;

        // Kiểm tra các id_booking và tìm số thứ tự cao nhất
        foreach ($bookings as $booking) {
            if (preg_match('/^BK' . $formatted_date . '(\d{3})$/', $booking['id_booking'], $matches)) {
                $id_number = (int)$matches[1];
                if ($id_number > $max_id_number) {
                    $max_id_number = $id_number;
                }
            }
        }

        // Tạo mã mới và kiểm tra trùng lặp
        $attempts      = 0;
        $max_attempts  = 100; // Giới hạn số lần thử để tránh vòng lặp vô hạn
        $result_string = '';

        do {
            $new_id_number = str_pad($max_id_number + 1 + $attempts, 3, '0', STR_PAD_LEFT);
            $result_string = $prefix . $new_id_number;

            // Kiểm tra xem id_booking đã tồn tại chưa
            $exists = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}bookingmkt192_booking_data WHERE id_booking = %s",
                $result_string
            ));

            $attempts++;
        } while ($exists > 0 && $attempts < $max_attempts);

        // Nếu không tìm được mã mới sau max_attempts
        if ($exists > 0) {
            $wpdb->query('ROLLBACK');
            self::write_log('get_last_booking_number', 'Không thể tạo mã booking mới sau nhiều lần thử', [
                'checkin_date' => $checkin_date,
                'attempts'     => $attempts
            ]);
            return new WP_REST_Response(['success' => false, 'message' => 'Không thể tạo mã booking mới'], 500);
        }

        // Ghi log chi tiết
        $log_data = [
            'id_booking'        => $result_string,
            'checkin_date'      => $checkin_date,
            'existing_bookings' => array_column($bookings, 'id_booking'),
            'attempts'          => $attempts
        ];
        self::write_log('get_last_booking_number', 'New id_booking generated', $log_data);

        // Commit giao dịch
        $wpdb->query('COMMIT');

        // Trả về kết quả
        return new WP_REST_Response([
            'success'     => true,
            'id_booking'  => $result_string
        ], 200);
    } catch (Exception $e) {
        // Rollback giao dịch nếu có lỗi
        $wpdb->query('ROLLBACK');
        self::write_log('get_last_booking_number', 'Lỗi khi tạo id_booking', ['error' => $e->getMessage()]);
        return new WP_REST_Response(['success' => false, 'message' => 'Lỗi hệ thống: ' . $e->getMessage()], 500);
    }
}

    /**
     * Lấy thông tin booking theo ID.
     *
     * @param WP_REST_Request $request Yêu cầu REST.
     * @return WP_REST_Response
     */
    public static function get_booking_by_id(WP_REST_Request $request) {
        global $wpdb;
        $id_booking    = sanitize_text_field($request->get_param('id_booking'));
        $booking_table = $wpdb->prefix . 'bookingmkt192_booking_data';

        $booking = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM $booking_table WHERE id_booking = %s", $id_booking),
            ARRAY_A
        );

        if (!$booking) {
            return new WP_REST_Response(['success' => false, 'message' => 'Không tìm thấy booking.'], 404);
        }

        $services = [];
        if (!empty($booking['services'])) {
            $servicesData = json_decode($booking['services'], true);
            if (is_array($servicesData)) {
                foreach ($servicesData as $service) {
                    $services[] = [
                        'service_name'     => html_entity_decode($service['service_name']),
                        'service_price'    => (int) $service['service_price'],
                        'hairdresser_name' => !empty($booking['hairdresser_name']) ? html_entity_decode($booking['hairdresser_name']) : 'Chưa xác định'
                    ];
                }
            }
        }

        $response = [
            'id_booking'     => $booking['id_booking'],
            'customer_name'  => $booking['customer_name'],
            'customer_phone' => $booking['customer_phone'],
            'customer_type'  => $booking['customer_type'],
            'services'       => $services
        ];

        return new WP_REST_Response(['success' => true, 'data' => $response], 200);
    }

    /**
 * Xóa (hủy) booking bằng cách cập nhật trạng thái.
 *
 * @param WP_REST_Request $request Yêu cầu REST.
 * @return WP_REST_Response
 */
public static function delete_booking(WP_REST_Request $request) {
    global $wpdb;
    $table_name  = $wpdb->prefix . 'bookingmkt192_booking_data';
    $table_staff = $wpdb->prefix . 'checkin_mkt192_staff';
    $id_booking  = sanitize_text_field($request->get_param('id_booking'));

    // Lấy cancel_reason từ request body
    $json_params   = $request->get_json_params();
    $cancel_reason = isset($json_params['cancel_reason']) ? sanitize_text_field($json_params['cancel_reason']) : '';

    if (empty($id_booking)) {
        return new WP_REST_Response(['success' => false, 'message' => 'Thiếu id_booking'], 400);
    }

    // Lấy dữ liệu booking trước khi cập nhật trạng thái
    $booking_data = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $table_name WHERE id_booking = %s",
        $id_booking
    ), ARRAY_A);

    if (!$booking_data) {
        self::write_log('delete_booking', 'Không tìm thấy booking để gửi thông báo', ['id_booking' => $id_booking]);
        return new WP_REST_Response(['success' => false, 'message' => 'Không tìm thấy booking với id_booking này'], 404);
    }

    // Cập nhật trạng thái booking và lý do hủy
    $update_data   = ['status' => 'deleted'];
    $update_format = ['%s'];

    if (!empty($cancel_reason)) {
        $update_data['cancel_reason'] = $cancel_reason;
        $update_format[]              = '%s';
        // Thêm cancel_reason vào booking_data để gửi trong thông báo
        $booking_data['cancel_reason'] = $cancel_reason;
    }

    $result = $wpdb->update(
        $table_name,
        $update_data,
        ['id_booking' => $id_booking],
        $update_format,
        ['%s']
    );

    if ($result === false) {
        self::write_log('delete_booking', 'Lỗi khi cập nhật trạng thái booking', [
            'id_booking' => $id_booking,
            'error'      => $wpdb->last_error
        ]);
        return new WP_REST_Response(['success' => false, 'message' => 'Lỗi khi cập nhật trạng thái booking'], 500);
    }

    if ($result === 0) {
        self::write_log('delete_booking', 'Không tìm thấy booking để cập nhật', ['id_booking' => $id_booking]);
        return new WP_REST_Response(['success' => false, 'message' => 'Không tìm thấy booking với id_booking này'], 404);
    }

    // Gửi thông báo hủy lịch qua Zalo (ưu tiên gửi trước)
    try {
        $zalo_result = Checkin_MKT192_ZaloCancelBookingMessage::send_cancel_message((object)$booking_data);
        self::write_log('delete_booking', 'Kết quả gửi Zalo hủy lịch', $zalo_result);
    } catch (Exception $e) {
        self::write_log('delete_booking', 'Lỗi khi gửi thông báo hủy lịch qua Zalo', [
            'id_booking' => $id_booking,
            'error'      => $e->getMessage()
        ]);
    }

    // Gửi thông báo hủy lịch qua Lark nếu được bật (sau khi gửi Zalo/ZBS)
    if (is_lark_enabled()) {
        try {
            $notification_result = Checkin_MKT192_LarkBookingNotification::send_booking_cancellation_notification($booking_data);

            if (!$notification_result['success']) {
                self::write_log('delete_booking', 'Lỗi gửi thông báo hủy lịch qua Lark', [
                    'id_booking' => $id_booking,
                    'error'      => $notification_result['message']
                ]);
            } else {
                self::write_log('delete_booking', 'Gửi thông báo hủy lịch qua Lark thành công', [
                    'id_booking' => $id_booking,
                    'message_id' => $notification_result['message_id']
                ]);
            }
        } catch (Exception $e) {
            self::write_log('delete_booking', 'Lỗi khi gửi thông báo hủy lịch qua Lark', [
                'id_booking' => $id_booking,
                'error'      => $e->getMessage()
            ]);
        }
    } else {
        self::write_log('delete_booking', 'Lark bị tắt, bỏ qua gửi thông báo hủy lịch');
    }

    // Send push notification to staff about booking cancellation
    if (function_exists('checkin_mkt192_notify_booking_cancelled') && !empty($booking_data['hairdresser_name'])) {
        $staff_user_id = $wpdb->get_var($wpdb->prepare(
            "SELECT user_id FROM $table_staff WHERE display_name = %s",
            $booking_data['hairdresser_name']
        ));

        if ($staff_user_id) {
            checkin_mkt192_notify_booking_cancelled($staff_user_id, [
                'id_booking'    => $id_booking,
                'customer_name' => $booking_data['customer_name'],
                'booking_time'  => $booking_data['booking_time'] . ' ' . $booking_data['booking_date'],
                'branch_id'     => $booking_data['branch_id'] ?? null
            ]);
            self::write_log('delete_booking', 'Đã gửi push notification hủy lịch đến staff', ['staff_user_id' => $staff_user_id]);
        }
    }

    return new WP_REST_Response(['success' => true, 'message' => 'Hủy booking thành công'], 200);
}

    /**
     * Lấy danh sách booking của nhân viên.
     *
     * @param WP_REST_Request $request Yêu cầu REST.
     * @return WP_REST_Response
     */
    public static function get_staff_bookings(WP_REST_Request $request) {
        global $wpdb;
        $booking_table  = $wpdb->prefix . 'bookingmkt192_booking_data';
        $customer_table = $wpdb->prefix . 'bookingmkt192_customer_data';

        try {
            date_default_timezone_set('Asia/Ho_Chi_Minh');
            $staff_name   = sanitize_text_field($request->get_param('staff_name'));
            $current_role = function_exists('checkin_mkt192_get_current_staff_role') ? checkin_mkt192_get_current_staff_role() : null;
            // Kiểm tra quyền xem tất cả booking (booking.view_all)
            $can_view_all = $current_role && function_exists('checkin_mkt192_role_has_scope') ? checkin_mkt192_role_has_scope($current_role, 'booking.view_all') : false;

            // Support both branch (name) and branch_id (id) parameters
            $branch       = sanitize_text_field($request->get_param('branch'));
            $branch_id    = absint($request->get_param('branch_id'));

            // Check if multi-branch mode is enabled
            $multi_branch_enabled = get_option('checkin_branch_mode_enabled', '0') === '1';

            // Only filter by branch when multi-branch mode is enabled
            if ($multi_branch_enabled) {
                // If branch_id is provided, lookup branch name from locations table
                if ($branch_id > 0 && empty($branch)) {
                    $branch = $wpdb->get_var($wpdb->prepare(
                        "SELECT location_name FROM {$wpdb->prefix}checkin_mkt192_locations WHERE id = %d",
                        $branch_id
                    ));
                }
            } else {
                // Multi-branch mode disabled: ignore branch filter
                $branch    = '';
                $branch_id = 0;
            }

            // Chỉ yêu cầu staff_name nếu KHÔNG có quyền view_all
            if (!$can_view_all && !$staff_name) {
                return new WP_REST_Response(['success' => false, 'message' => 'Thiếu tham số staff_name'], 400);
            }

            $filter     = $request->get_param('filter') ?: 'today';
            $start_date = sanitize_text_field($request->get_param('start_date'));
            $end_date   = sanitize_text_field($request->get_param('end_date'));

            $date_condition = '';
            $params         = [];

            switch ($filter) {
                case 'upcoming':
                    // Lịch hẹn từ bây giờ đến hết ngày mai
                    $date_condition = '(booking_date > %s OR (booking_date = %s AND booking_time >= %s))';
                    $params[]       = self::vn_date('Y-m-d');
                    $params[]       = self::vn_date('Y-m-d');
                    $params[]       = self::vn_date('H:i:s');
                    break;
                case 'tomorrow':
                    $date_condition = 'DATE(booking_date) = %s';
                    $params[]       = self::vn_date('Y-m-d', '+1 day');
                    break;
                case 'today':
                    $date_condition = 'DATE(booking_date) = %s';
                    $params[]       = self::vn_date('Y-m-d');
                    break;
                case 'yesterday':
                    $date_condition = 'DATE(booking_date) = %s';
                    $params[]       = self::vn_date('Y-m-d', '-1 day');
                    break;
                case 'thisMonth':
                    $date_condition = 'YEAR(booking_date) = %d AND MONTH(booking_date) = %d';
                    $params[]       = self::vn_date('Y');
                    $params[]       = self::vn_date('m');
                    break;
                case 'lastMonth':
                    $date_condition = 'YEAR(booking_date) = %d AND MONTH(booking_date) = %d';
                    $params[]       = self::vn_date('Y', '-1 month');
                    $params[]       = self::vn_date('m', '-1 month');
                    break;
                case '7days':
                    // Lấy booking từ 7 ngày trước đến hôm nay
                    $date_condition = 'DATE(booking_date) >= %s AND DATE(booking_date) <= %s';
                    $params[]       = self::vn_date('Y-m-d', '-6 days');
                    $params[]       = self::vn_date('Y-m-d');
                    break;
                case 'custom':
                    if ($start_date && $end_date) {
                        $date_condition = 'booking_date BETWEEN %s AND %s';
                        $params[]       = $start_date . ' 00:00:00';
                        $params[]       = $end_date . ' 23:59:59';
                    } else {
                        $date_condition = 'DATE(booking_date) = %s';
                        $params[]       = self::vn_date('Y-m-d');
                    }
                    break;
                default:
                    $date_condition = 'DATE(booking_date) = %s';
                    $params[]       = self::vn_date('Y-m-d');
            }

            if ($can_view_all) {
                $branch_condition = $branch ? 'AND b.branch = %s' : '';
                $branch_params    = $branch ? [$branch] : [];

                $query = $wpdb->prepare(
                    "SELECT DISTINCT b.*
                    FROM $booking_table b
                    WHERE $date_condition $branch_condition
                    ORDER BY ABS(TIMESTAMPDIFF(SECOND, NOW(), CONCAT(booking_date, ' ', booking_time))) ASC",
                    array_merge($params, $branch_params)
                );
            } else {
                $branch_condition = $branch ? 'AND b.branch = %s' : '';
                $branch_params    = $branch ? [$branch] : [];

                $query = $wpdb->prepare(
                    "SELECT DISTINCT b.*
                    FROM $booking_table b
                    WHERE b.hairdresser_name = %s AND $date_condition $branch_condition
                    ORDER BY ABS(TIMESTAMPDIFF(SECOND, NOW(), CONCAT(booking_date, ' ', booking_time))) ASC",
                    array_merge([$staff_name], $params, $branch_params)
                );
            }

            if ($request->get_param('limit')) {
                $limit = absint($request->get_param('limit'));
                $query .= $wpdb->prepare(' LIMIT %d', $limit);
            }

            $bookings = $wpdb->get_results($query, ARRAY_A);

            if (empty($bookings)) {
                return new WP_REST_Response([
                    'success' => true,
                    'data'    => [],
                    'message' => 'Không tìm thấy lịch hẹn nào' . (!$can_view_all ? ' cho nhân viên: ' . $staff_name : '')
                ], 200);
            }

            // Lấy ảnh khách từ invoice mới nhất - batch query để tối ưu hiệu suất
            $phone_list          = array_unique(array_column($bookings, 'customer_phone'));
            $customer_images_map = [];

            if (!empty($phone_list)) {
                // Tạo variants của số điện thoại (có và không có số 0 đầu) để search
                $phone_variants = [];
                $phone_mapping  = []; // Map từ variant → original phone

                foreach ($phone_list as $phone) {
                    // Bỏ số 0 đầu nếu có
                    $without_zero = ltrim($phone, '0');
                    // Thêm số 0 nếu chưa có
                    $with_zero = (strlen($without_zero) === 9) ? '0' . $without_zero : $phone;

                    $phone_variants[] = $without_zero;
                    $phone_variants[] = $with_zero;

                    // Map cả 2 variant về số gốc
                    $phone_mapping[$without_zero] = $phone;
                    $phone_mapping[$with_zero]    = $phone;
                }

                $phone_variants = array_unique($phone_variants);
                $placeholders   = implode(',', array_fill(0, count($phone_variants), '%s'));

                $invoices = $wpdb->get_results($wpdb->prepare(
                    "SELECT i1.customer_phone, i1.images
                     FROM {$wpdb->prefix}checkin_mkt192_invoices_data i1
                     INNER JOIN (
                         SELECT customer_phone, MAX(created_at) as max_date
                         FROM {$wpdb->prefix}checkin_mkt192_invoices_data
                         WHERE customer_phone IN ($placeholders)
                         AND images IS NOT NULL AND images != '' AND images != '[]'
                         GROUP BY customer_phone
                     ) i2 ON i1.customer_phone = i2.customer_phone AND i1.created_at = i2.max_date",
                    ...$phone_variants
                ), ARRAY_A);

                foreach ($invoices as $invoice) {
                    $decoded = json_decode($invoice['images'], true);

                    if (is_array($decoded) && !empty($decoded)) {
                        // Map về số gốc trong booking
                        $original_phone                       = $phone_mapping[$invoice['customer_phone']] ?? $invoice['customer_phone'];
                        $customer_images_map[$original_phone] = $decoded;
                    }
                }
            }

            foreach ($bookings as &$booking) {
                if (!empty($booking['booking_images']) && is_string($booking['booking_images'])) {
                    $decoded_images            = json_decode($booking['booking_images'], true);
                    $booking['booking_images'] = $decoded_images !== null ? $decoded_images : [];
                } else {
                    $booking['booking_images'] = [];
                }

                // Lấy customer_images từ invoice mới nhất
                $customer_phone             = $booking['customer_phone'];
                $booking['customer_images'] = $customer_images_map[$customer_phone] ?? [];

                $booking['display_image'] = !empty($booking['booking_images'])
                    ? WP_CONTENT_URL . '/uploads/checkin-mkt192-wp/customer_image/' . $booking['id'] . '/' . trim($booking['booking_images'][0])
                    : (!empty($booking['customer_images']) ? $booking['customer_images'][0] : 'https://randomuser.me/api/portraits/lego/1.jpg');
            }

            return new WP_REST_Response([
                'success' => true,
                'data'    => $bookings,
                'message' => 'Lấy lịch hẹn thành công'
            ], 200);

        } catch (Exception $e) {
            self::write_log('staff_bookings', 'Lỗi khi lấy danh sách booking', ['error' => $e->getMessage()]);
            return new WP_REST_Response(['success' => false, 'message' => 'Lỗi hệ thống: ' . $e->getMessage()], 500);
        }
    }

    /**
     * Lấy thông tin booking của khách hàng theo số điện thoại hoặc mã booking.
     *
     * @param WP_REST_Request $request Yêu cầu REST.
     * @return WP_REST_Response
     */
    public static function get_customer_booking(WP_REST_Request $request) {
        // Rate limiting: 20 requests per minute per IP
        $rate_limit = checkin_mkt192_apply_rate_limit('customer_booking', 20, 60);
        if (is_wp_error($rate_limit)) {
            return new WP_REST_Response([
                'success' => false,
                'message' => $rate_limit->get_error_message()
            ], 429);
        }

        global $wpdb;
        $booking_table  = $wpdb->prefix . 'bookingmkt192_booking_data';
        $customer_table = $wpdb->prefix . 'bookingmkt192_customer_data';

        $params = $request->get_json_params();

        // Support both old format (bookingInput) and new format (customer_phone/booking_code)
        $input = $params['bookingInput'] ?? $params['customer_phone'] ?? $params['booking_code'] ?? '';

        if (empty($input)) {
            return new WP_REST_Response(['success' => false, 'message' => 'Vui lòng cung cấp số điện thoại hoặc mã booking.'], 400);
        }

        $input = sanitize_text_field($input);
        self::write_log('customer_booking', 'Dữ liệu nhận được', ['input' => $input]);

        // Normalize phone: remove leading 0 or 84
        $normalized_input = preg_replace('/^(0|84)/', '', $input);

        // Create phone variants for comprehensive search
        $phone_variants = [$normalized_input];
        if (strlen($normalized_input) === 9) {
            $phone_variants[] = '0' . $normalized_input; // Add version with 0
        }

        // Build query with multiple phone variants
        $placeholders = implode(',', array_fill(0, count($phone_variants), '%s'));
        $query_params = array_merge($phone_variants, [$input]); // phone variants + booking_id

        $query = $wpdb->prepare(
            "SELECT b.*
             FROM $booking_table b
             WHERE (b.customer_phone IN ($placeholders) OR b.id_booking = %s)
                AND b.status = 'start'
             ORDER BY b.created_at DESC
             LIMIT 1",
            $query_params
        );

        $booking = $wpdb->get_row($query, ARRAY_A);
        if (!$booking) {
            // No active booking found - but if searching by phone, still return history
            $is_phone_search = preg_match('/^\d{9,10}$/', $normalized_input);
            if ($is_phone_search) {
                // Try to get all bookings for this phone (any status)
                $hist_placeholders = implode(',', array_fill(0, count($phone_variants), '%s'));
                $history_rows = $wpdb->get_results($wpdb->prepare(
                    "SELECT id_booking, customer_name, booking_date, booking_time, hairdresser_name, services, status, created_at
                     FROM $booking_table
                     WHERE customer_phone IN ($hist_placeholders)
                     ORDER BY created_at DESC
                     LIMIT 10",
                    $phone_variants
                ), ARRAY_A);

                if (!empty($history_rows)) {
                    $statusMap_hist = [
                        'start'   => 'Chờ phục vụ',
                        'pending' => 'Đang phục vụ',
                        'deleted' => 'Đã hủy',
                        'success' => 'Hoàn thành',
                    ];

                    $all_bookings_hist = [];
                    foreach ($history_rows as $bk) {
                        $bk_services = [];
                        if (!empty($bk['services'])) {
                            $bk_services_data = json_decode($bk['services'], true);
                            if (is_array($bk_services_data)) {
                                foreach ($bk_services_data as $s) {
                                    $bk_services[] = html_entity_decode($s['service_name']);
                                }
                            }
                        }
                        $all_bookings_hist[] = [
                            'id_booking'   => $bk['id_booking'],
                            'booking_date' => $bk['booking_date'],
                            'booking_time' => $bk['booking_time'],
                            'staff_name'   => $bk['hairdresser_name'] ?: '--',
                            'service_name' => !empty($bk_services) ? implode(', ', $bk_services) : '--',
                            'status'       => $statusMap_hist[$bk['status']] ?? $bk['status'],
                            'status_raw'   => $bk['status'],
                        ];
                    }

                    // Return success with history but flag no active booking
                    return new WP_REST_Response([
                        'success'            => true,
                        'has_active_booking'  => false,
                        'customer_name'       => $history_rows[0]['customer_name'] ?? '',
                        'customer_phone'      => $input,
                        'all_bookings'        => $all_bookings_hist,
                        'message'             => 'Không có booking đang chờ, nhưng có lịch sử đặt lịch.',
                    ], 200);
                }
            }

            return new WP_REST_Response(['success' => false, 'message' => 'Không tìm thấy booking.'], 404);
        }

        $services = [];
        if (!empty($booking['services'])) {
            $servicesData = json_decode($booking['services'], true);
            if (is_array($servicesData)) {
                foreach ($servicesData as $service) {
                    $services[] = html_entity_decode($service['service_name']);
                }
            }
        }

        // Lấy ảnh khách từ invoice mới nhất của khách hàng
        $customer_images = [];
        $phone           = $booking['customer_phone'];

        // Tạo variants của số điện thoại (có và không có số 0 đầu)
        $without_zero = ltrim($phone, '0');
        $with_zero    = (strlen($without_zero) === 9) ? '0' . $without_zero : $phone;

        $latest_invoice = $wpdb->get_row($wpdb->prepare(
            "SELECT images FROM {$wpdb->prefix}checkin_mkt192_invoices_data
             WHERE customer_phone IN (%s, %s) AND images IS NOT NULL AND images != '' AND images != '[]'
             ORDER BY created_at DESC LIMIT 1",
            $without_zero,
            $with_zero
        ));

        if ($latest_invoice && !empty($latest_invoice->images)) {
            $decoded = json_decode($latest_invoice->images, true);
            if (is_array($decoded) && !empty($decoded)) {
                $customer_images = $decoded;
            }
        }

        // Avatar: Use customer images from invoice, or generate by name (NO LEGO!)
        if (!empty($customer_images)) {
            $display_image = $customer_images[0];
        } else {
            // Generate avatar by customer name
            $name_for_avatar = !empty($booking['customer_name']) ? $booking['customer_name'] : 'User';
            $display_image   = 'https://ui-avatars.com/api/?name=' . urlencode($name_for_avatar) . '&background=00d4aa&color=fff&size=200';
        }

        $statusMap = [
            'pending' => 'Đang phục vụ',
            'deleted' => 'Đã hủy lịch',
            'success' => 'Đã hoàn thành',
        ];

        $statusText = isset($statusMap[$booking['status']]) ? $statusMap[$booking['status']] : 'Chờ phục vụ';

        $response = [
            'success'          => true,
            // Provide both formats for compatibility
            'id_booking'       => $booking['id_booking'],
            'booking_code'     => $booking['id_booking'], // Frontend expects 'booking_code'
            'customer_name'    => $booking['customer_name'],
            'customer_phone'   => $booking['customer_phone'],
            'customer_type'    => $booking['customer_type'],
            'service_name'     => !empty($services) ? implode(', ', $services) : 'Không xác định',
            'hairdresser_name' => $booking['hairdresser_name'] ?: 'Chưa xác định',
            'staff_name'       => $booking['hairdresser_name'] ?: 'Chưa xác định', // Frontend expects 'staff_name'
            'booking_date'     => $booking['booking_date'] ?: 'Không áp dụng',
            'booking_time'     => $booking['booking_time'] ?: 'Không áp dụng',
            'customer_note'    => $booking['customer_note'] ?: 'Không có',
            'note'             => $booking['customer_note'] ?: 'Không có', // Frontend expects 'note'
            'status'           => $statusText,
            'booking_status'   => 'confirmed', // Frontend expects 'booking_status' for QR logic
            'avatar'           => $display_image, // Use 'avatar' key to match promo API
            'customer_images'  => $customer_images
        ];

        // Also return all bookings for this phone (for booking history list)
        $all_bookings = [];
        if (!empty($booking['customer_phone'])) {
            $bk_phone = $booking['customer_phone'];
            $bk_without_zero = ltrim($bk_phone, '0');
            $bk_with_zero = (strlen($bk_without_zero) === 9) ? '0' . $bk_without_zero : $bk_phone;

            $all_booking_rows = $wpdb->get_results($wpdb->prepare(
                "SELECT id_booking, customer_name, booking_date, booking_time, hairdresser_name, services, status, created_at
                 FROM $booking_table
                 WHERE customer_phone IN (%s, %s)
                 ORDER BY created_at DESC
                 LIMIT 10",
                $bk_without_zero,
                $bk_with_zero
            ), ARRAY_A);

            $statusMap_all = [
                'start'   => 'Chờ phục vụ',
                'pending' => 'Đang phục vụ',
                'deleted' => 'Đã hủy',
                'success' => 'Hoàn thành',
            ];

            foreach ($all_booking_rows as $bk) {
                $bk_services = [];
                if (!empty($bk['services'])) {
                    $bk_services_data = json_decode($bk['services'], true);
                    if (is_array($bk_services_data)) {
                        foreach ($bk_services_data as $s) {
                            $bk_services[] = html_entity_decode($s['service_name']);
                        }
                    }
                }
                $all_bookings[] = [
                    'id_booking'   => $bk['id_booking'],
                    'booking_date' => $bk['booking_date'],
                    'booking_time' => $bk['booking_time'],
                    'staff_name'   => $bk['hairdresser_name'] ?: '--',
                    'service_name' => !empty($bk_services) ? implode(', ', $bk_services) : '--',
                    'status'       => $statusMap_all[$bk['status']] ?? $bk['status'],
                    'status_raw'   => $bk['status'],
                ];
            }
        }
        $response['all_bookings'] = $all_bookings;

        return new WP_REST_Response($response, 200);
    }

    /**
     * Gửi lại thông báo booking qua Lark và Zalo.
     *
     * @param WP_REST_Request $request Yêu cầu REST.
     * @return WP_REST_Response
     */
    public static function resend_booking_notification(WP_REST_Request $request) {
        global $wpdb;
        $booking_table = $wpdb->prefix . 'bookingmkt192_booking_data';
        $id_booking    = sanitize_text_field($request->get_param('id_booking'));

        try {
            $booking = $wpdb->get_row(
                $wpdb->prepare("SELECT * FROM $booking_table WHERE id_booking = %s", $id_booking),
                ARRAY_A
            );

            if (!$booking) {
                self::write_log('resend_booking', 'Không tìm thấy lịch hẹn', ['id_booking' => $id_booking]);
                return new WP_REST_Response(['success' => false, 'message' => 'Không tìm thấy lịch hẹn.'], 404);
            }

            $link_bookingnew = "https://vangroupbarbershop.store/customer-member?booking_id=$id_booking";
            $booking_data    = [
                'id_booking'      => $booking['id_booking'],
                'booking_date'    => $booking['booking_date'],
                'booking_time'    => $booking['booking_time'],
                'customer_name'   => $booking['customer_name'],
                'service_name'    => $booking['service_name'],
                'hairdresser'     => $booking['hairdresser_name'],
                'booking_note'    => $booking['customer_note'],
                'customer_count'  => (int)$booking['customer_count'],
                'silent_service'  => $booking['silent_service'],
                'link_bookingnew' => $link_bookingnew,
                'power_by'        => 'Website'
            ];

            // Gửi lại thông báo Lark nếu được bật
            $lark_result = null;
            if (is_lark_enabled()) {
                $lark_result = Checkin_MKT192_LarkBookingNotification::send_booking_notification($booking_data);
                self::write_log('resend_booking', 'Kết quả gửi lại Lark', $lark_result);
            } else {
                self::write_log('resend_booking', 'Lark bị tắt, bỏ qua gửi lại thông báo');
            }

            $zalo_result = Checkin_MKT192_ZaloBookingMessage::send_booking_message((object)$booking);
            self::write_log('resend_booking', 'Kết quả gửi lại Zalo', $zalo_result);

            return new WP_REST_Response([
                'success' => true,
                'message' => 'Gửi lại thông báo thành công!',
                'data'    => [
                    'lark_result' => $lark_result,
                    'zalo_result' => $zalo_result
                ]
            ], 200);
        } catch (Exception $e) {
            self::write_log('resend_booking', 'Lỗi khi gửi lại thông báo', ['error' => $e->getMessage()]);
            return new WP_REST_Response(['success' => false, 'message' => 'Có lỗi xảy ra: ' . $e->getMessage()], 500);
        }
    }

    /**
     * Gửi lại thông báo nhắc hẹn qua Zalo.
     *
     * @param WP_REST_Request $request Yêu cầu REST.
     * @return WP_REST_Response
     */
    public static function resend_reminder_notification(WP_REST_Request $request) {
        global $wpdb;
        $booking_table = $wpdb->prefix . 'bookingmkt192_booking_data';
        $id_booking    = sanitize_text_field($request->get_param('id_booking'));

        try {
            $booking = $wpdb->get_row(
                $wpdb->prepare("SELECT * FROM $booking_table WHERE id_booking = %s", $id_booking),
                ARRAY_A
            );

            if (!$booking) {
                self::write_log('resend_reminder', 'Không tìm thấy lịch hẹn', ['id_booking' => $id_booking]);
                return new WP_REST_Response(['success' => false, 'message' => 'Không tìm thấy lịch hẹn.'], 404);
            }

            $zalo_result = Checkin_MKT192_ZaloBookingReminder::send_reminder_booking((object)$booking);
            self::write_log('resend_reminder', 'Kết quả gửi lại nhắc hẹn Zalo', $zalo_result);

            return new WP_REST_Response([
                'success' => true,
                'message' => 'Gửi lại thông báo nhắc hẹn thành công!',
                'data'    => [
                    'zalo_result' => $zalo_result
                ]
            ], 200);
        } catch (Exception $e) {
            self::write_log('resend_reminder', 'Lỗi khi gửi lại thông báo nhắc hẹn', ['error' => $e->getMessage()]);
            return new WP_REST_Response(['success' => false, 'message' => 'Có lỗi xảy ra: ' . $e->getMessage()], 500);
        }
    }

    /**
     * Gửi lại thông báo hủy lịch qua Zalo.
     *
     * @param WP_REST_Request $request Yêu cầu REST.
     * @return WP_REST_Response
     */
    public static function resend_cancel_notification(WP_REST_Request $request) {
        global $wpdb;
        $booking_table = $wpdb->prefix . 'bookingmkt192_booking_data';
        $id_booking    = sanitize_text_field($request->get_param('id_booking'));

        try {
            $booking = $wpdb->get_row(
                $wpdb->prepare("SELECT * FROM $booking_table WHERE id_booking = %s", $id_booking),
                ARRAY_A
            );

            if (!$booking) {
                self::write_log('resend_cancel', 'Không tìm thấy lịch hẹn', ['id_booking' => $id_booking]);
                return new WP_REST_Response(['success' => false, 'message' => 'Không tìm thấy lịch hẹn.'], 404);
            }

            $zalo_result = Checkin_MKT192_ZaloCancelBookingMessage::send_cancel_message((object)$booking);
            self::write_log('resend_cancel', 'Kết quả gửi lại thông báo hủy Zalo', $zalo_result);

            // Gửi lại thông báo hủy lịch qua Lark nếu được bật
            $lark_result = null;
            if (is_lark_enabled()) {
                try {
                    $lark_result = Checkin_MKT192_LarkBookingNotification::send_booking_cancellation_notification($booking);
                    self::write_log('resend_cancel', 'Kết quả gửi lại thông báo hủy Lark', $lark_result);
                } catch (Exception $e) {
                    self::write_log('resend_cancel', 'Lỗi khi gửi lại thông báo hủy Lark', ['error' => $e->getMessage()]);
                }
            }

            return new WP_REST_Response([
                'success' => true,
                'message' => 'Gửi lại thông báo hủy lịch thành công!',
                'data'    => [
                    'zalo_result' => $zalo_result,
                    'lark_result' => $lark_result
                ]
            ], 200);
        } catch (Exception $e) {
            self::write_log('resend_cancel', 'Lỗi khi gửi lại thông báo hủy lịch', ['error' => $e->getMessage()]);
            return new WP_REST_Response(['success' => false, 'message' => 'Có lỗi xảy ra: ' . $e->getMessage()], 500);
        }
    }

    /**
     * Lấy cài đặt booking (ngày đặc biệt).
     *
     * @param WP_REST_Request $request Yêu cầu REST.
     * @return WP_REST_Response
     */
    public static function get_booking_settings(WP_REST_Request $request) {
        global $wpdb;
        $table = $wpdb->prefix . 'bookingmkt192_special_days';

        $results = $wpdb->get_results("SELECT * FROM $table WHERE type IN ('overtime', 'holiday', 'event')", ARRAY_A);

        return new WP_REST_Response(['success' => true, 'data' => $results], 200);
    }

    /**
     * Lưu cài đặt booking (ngày đặc biệt).
     *
     * @param WP_REST_Request $request Yêu cầu REST.
     * @return WP_REST_Response
     */
    public static function save_booking_settings(WP_REST_Request $request) {
        global $wpdb;
        $table = $wpdb->prefix . 'bookingmkt192_special_days';
        $data  = $request->get_json_params();

        if (!is_array($data)) {
            return new WP_REST_Response(['success' => false, 'message' => 'Dữ liệu không hợp lệ.'], 400);
        }

        $allowed_types   = ['overtime', 'holiday', 'event'];
        $required_fields = [
            'overtime' => ['start_date', 'start_time', 'end_date', 'end_time'],
            'holiday'  => ['start_date', 'start_time', 'end_date', 'end_time', 'message'],
            'event'    => ['start_date', 'start_time'],
        ];

        try {
            foreach ($data as $item) {
                if (!isset($item['type']) || !in_array($item['type'], $allowed_types)) {
                    continue;
                }

                $fields = [];
                foreach ($required_fields[$item['type']] as $field) {
                    if (isset($item[$field]) && $item[$field] !== '') {
                        $fields[$field] = sanitize_text_field($item[$field]);
                    }
                }

                if (empty($fields['start_date'])) {
                    continue;
                }

                // Với event (Year-end Party), tự động set end_date = start_date để query hoạt động đúng
                if ($item['type'] === 'event') {
                    $fields['end_date'] = $fields['start_date'];
                    // Set end_time nếu có, nếu không thì để 23:59:59
                    $fields['end_time'] = isset($item['end_time']) && $item['end_time'] !== ''
                        ? sanitize_text_field($item['end_time'])
                        : '23:59:59';
                }

                $existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM $table WHERE type = %s", $item['type']), ARRAY_A);

                if ($existing) {
                    $wpdb->update($table, $fields, ['type' => $item['type']]);
                } else {
                    $fields['type'] = $item['type'];
                    $wpdb->insert($table, $fields);
                }
            }

            return new WP_REST_Response(['success' => true, 'message' => 'Cập nhật cài đặt booking thành công.'], 200);
        } catch (Exception $e) {
            self::write_log('booking_settings', 'Lỗi khi lưu cài đặt', ['error' => $e->getMessage()]);
            return new WP_REST_Response(['success' => false, 'message' => 'Lỗi hệ thống: ' . $e->getMessage()], 500);
        }
    }
}

// Đăng ký các route khi REST API khởi tạo
add_action('rest_api_init', [Checkin_MKT192_BookingAPI::class, 'register_routes']);
?>
