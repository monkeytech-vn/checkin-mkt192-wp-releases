<?php

// Đăng ký các endpoint REST API cho quản lý chi nhánh (Branch System)
add_action('rest_api_init', function () {
    // Endpoint để lấy danh sách tất cả chi nhánh - PUBLIC ACCESS cho booking form
    register_rest_route('vg/v1', '/branches', [
        'methods'             => 'GET',
        'callback'            => 'checkin_mkt192_get_all_branches_api',
        'permission_callback' => '__return_true' // Allow public access for booking
    ]);

    // Endpoint để lấy danh sách chi nhánh user được phép làm việc
    register_rest_route('vg/v1', '/user-branches', [
        'methods'             => 'GET',
        'callback'            => 'checkin_mkt192_get_user_branches_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'location.read'])
    ]);

    // Endpoint để auto-detect chi nhánh dựa trên vị trí GPS - PUBLIC ACCESS
    register_rest_route('vg/v1', '/branch-by-location', [
        'methods'             => 'GET',
        'callback'            => 'checkin_mkt192_detect_branch_by_location_api',
        'permission_callback' => '__return_true' // Allow public access for auto-detection
    ]);

    // Endpoint để lấy thông tin chi nhánh hiện tại của user
    register_rest_route('vg/v1', '/user-current-branch', [
        'methods'             => 'GET',
        'callback'            => 'checkin_mkt192_get_user_current_branch_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'location.read'])
    ]);

    // Endpoint để lưu chi nhánh hiện tại của user
    register_rest_route('vg/v1', '/user-current-branch', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_set_user_current_branch_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'location.read'])
    ]);
});

/**
 * Lấy danh sách tất cả chi nhánh (locations)
 */
function checkin_mkt192_get_all_branches_api(WP_REST_Request $request) {
    global $wpdb;

    try {
        $branches = $wpdb->get_results(
            "SELECT id, location_name as branch_name, latitude, longitude, radius,
                    address, google_map_link, is_main_branch
             FROM {$wpdb->prefix}checkin_mkt192_locations
             ORDER BY is_main_branch DESC, location_name ASC",
            ARRAY_A
        );

        if (empty($branches)) {
            return new WP_REST_Response(['success' => true, 'data' => []], 200);
        }

        return new WP_REST_Response(['success' => true, 'data' => $branches], 200);
    } catch (Exception $e) {
        error_log('Checkin MKT192: Error fetching branches - ' . $e->getMessage());
        return new WP_Error('fetch_failed', 'Lỗi khi lấy danh sách chi nhánh: ' . $e->getMessage(), ['status' => 500]);
    }
}

/**
 * Lấy danh sách chi nhánh mà user được phép làm việc
 *
 * Sử dụng helper function để lấy TẤT CẢ chi nhánh mà nhân viên tham gia
 * (lưu trong cột `branch` dạng JSON array)
 */
function checkin_mkt192_get_user_branches_api(WP_REST_Request $request) {
    global $wpdb;
    $user_id = get_current_user_id();

    if (!$user_id) {
        return new WP_Error('not_authenticated', 'Người dùng chưa đăng nhập', ['status' => 401]);
    }

    try {
        // Lấy thông tin staff từ DB
        $staff = $wpdb->get_row($wpdb->prepare(
            "SELECT branch_id FROM {$wpdb->prefix}checkin_mkt192_staff WHERE user_id = %d LIMIT 1",
            $user_id
        ));

        // Lấy TẤT CẢ các chi nhánh mà nhân viên có tham gia (từ cột `branch`)
        $branch_ids = checkin_mkt192_get_staff_all_branch_ids($user_id);

        // Nếu chế độ đa chi nhánh tắt hoặc không có branch, trả về tất cả chi nhánh
        if (!checkin_mkt192_is_multi_branch_enabled() || empty($branch_ids)) {
            return checkin_mkt192_get_all_branches_api($request);
        }

        // Lấy thông tin chi tiết của các chi nhánh
        $placeholders = implode(',', array_fill(0, count($branch_ids), '%d'));
        $branches     = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT id, location_name as branch_name, latitude, longitude, radius,
                        address, google_map_link, is_main_branch
                 FROM {$wpdb->prefix}checkin_mkt192_locations
                 WHERE id IN ($placeholders)
                 ORDER BY is_main_branch DESC, location_name ASC",
                ...$branch_ids
            ),
            ARRAY_A
        );

        // Lấy thêm thông tin điểm danh hôm nay để xác định chi nhánh ưu tiên
        // Bảng checkinlogs lưu location_name, cần lookup sang locations để lấy branch_id
        $today                = date('Y-m-d');
        $today_checkin_branch = null;

        $checkin_today = $wpdb->get_row($wpdb->prepare(
            "SELECT location_name FROM {$wpdb->prefix}checkin_mkt192_checkinlogs
             WHERE employee_id = %s AND DATE(checkin_time) = %s
             ORDER BY checkin_time DESC LIMIT 1",
            $user_id,
            $today
        ));

        // Nếu có checkin hôm nay, tìm branch_id từ location_name
        if ($checkin_today && !empty($checkin_today->location_name)) {
            $location = $wpdb->get_row($wpdb->prepare(
                "SELECT id FROM {$wpdb->prefix}checkin_mkt192_locations WHERE location_name = %s LIMIT 1",
                $checkin_today->location_name
            ));
            if ($location) {
                $today_checkin_branch = intval($location->id);
            }
        }

        return new WP_REST_Response([
            'success'              => true,
            'data'                 => $branches,
            'branch_ids'           => $branch_ids,
            'primary_branch_id'    => $staff ? intval($staff->branch_id) : 0,
            'today_checkin_branch' => $today_checkin_branch
        ], 200);
    } catch (Exception $e) {
        error_log('Checkin MKT192: Error fetching user branches - ' . $e->getMessage());
        return new WP_Error('fetch_failed', 'Lỗi khi lấy danh sách chi nhánh: ' . $e->getMessage(), ['status' => 500]);
    }
}

/**
 * Auto-detect chi nhánh dựa trên vị trí GPS của user
 * Tham số: latitude, longitude
 */
function checkin_mkt192_detect_branch_by_location_api(WP_REST_Request $request) {
    global $wpdb;

    $user_latitude  = isset($request['latitude']) ? floatval($request['latitude']) : null;
    $user_longitude = isset($request['longitude']) ? floatval($request['longitude']) : null;

    // Validate coordinates
    if ($user_latitude === null     || $user_longitude === null ||
        !is_numeric($user_latitude) || !is_numeric($user_longitude)) {
        return new WP_Error('invalid_coordinates', 'Tọa độ không hợp lệ. Vui lòng cung cấp latitude và longitude', ['status' => 400]);
    }

    // Validate latitude range: -90 to 90
    if ($user_latitude < -90 || $user_latitude > 90) {
        return new WP_Error('invalid_latitude', 'Latitude phải trong khoảng -90 đến 90', ['status' => 400]);
    }

    // Validate longitude range: -180 to 180
    if ($user_longitude < -180 || $user_longitude > 180) {
        return new WP_Error('invalid_longitude', 'Longitude phải trong khoảng -180 đến 180', ['status' => 400]);
    }

    try {
        // Lấy tất cả chi nhánh
        $branches = $wpdb->get_results(
            "SELECT id, location_name, latitude, longitude, radius
             FROM {$wpdb->prefix}checkin_mkt192_locations
             WHERE latitude != 0 AND longitude != 0
             ORDER BY location_name ASC",
            ARRAY_A
        );

        if (empty($branches)) {
            return new WP_REST_Response([
                'success'         => true,
                'detected_branch' => null,
                'message'         => 'Không có chi nhánh nào được cấu hình',
                'all_branches'    => []
            ], 200);
        }

        // Tính khoảng cách giữa vị trí user và mỗi chi nhánh sử dụng Haversine formula
        $detected_branch = null;
        $min_distance    = PHP_FLOAT_MAX;

        foreach ($branches as $branch) {
            $distance = checkin_mkt192_haversine_distance(
                $user_latitude,
                $user_longitude,
                $branch['latitude'],
                $branch['longitude']
            );

            // Kiểm tra nếu user nằm trong bán kính của chi nhánh
            if ($distance <= $branch['radius']) {
                // Nếu có nhiều chi nhánh trong bán kính, chọn chi nhánh gần nhất
                if ($distance < $min_distance) {
                    $min_distance    = $distance;
                    $detected_branch = [
                        'id'          => $branch['id'],
                        'branch_name' => $branch['location_name'],
                        'distance_m'  => round($distance, 2),
                        'radius_m'    => $branch['radius']
                    ];
                }
            }
        }

        // Nếu không tìm thấy chi nhánh trong bán kính nào, trả về chi nhánh gần nhất
        if ($detected_branch === null) {
            $min_distance = PHP_FLOAT_MAX;
            foreach ($branches as $branch) {
                $distance = checkin_mkt192_haversine_distance(
                    $user_latitude,
                    $user_longitude,
                    $branch['latitude'],
                    $branch['longitude']
                );

                if ($distance < $min_distance) {
                    $min_distance    = $distance;
                    $detected_branch = [
                        'id'           => $branch['id'],
                        'branch_name'  => $branch['location_name'],
                        'distance_m'   => round($distance, 2),
                        'radius_m'     => $branch['radius'],
                        'out_of_range' => true
                    ];
                }
            }
        }

        return new WP_REST_Response([
            'success'         => true,
            'detected_branch' => $detected_branch,
            'all_branches'    => array_map(function($b) {
                return [
                    'id'          => $b['id'],
                    'branch_name' => $b['location_name'],
                    'latitude'    => $b['latitude'],
                    'longitude'   => $b['longitude'],
                    'radius_m'    => $b['radius']
                ];
            }, $branches)
        ], 200);
    } catch (Exception $e) {
        error_log('Checkin MKT192: Error detecting branch - ' . $e->getMessage());
        return new WP_Error('detection_failed', 'Lỗi khi phát hiện chi nhánh: ' . $e->getMessage(), ['status' => 500]);
    }
}

/**
 * Lấy chi nhánh CHÍNH hiện tại của user
 *
 * Chi nhánh chính (branch_id) là chi nhánh mặc định được gán cho nhân viên,
 * được chọn từ checkbox "Chi nhánh chính" ở admin settings
 */
function checkin_mkt192_get_user_current_branch_api(WP_REST_Request $request) {
    global $wpdb;
    $user_id = get_current_user_id();

    if (!$user_id) {
        return new WP_Error('not_authenticated', 'Người dùng chưa đăng nhập', ['status' => 401]);
    }

    try {
        // Lấy chi nhánh CHÍNH của nhân viên (từ cột branch_id)
        $branch_id = checkin_mkt192_get_staff_primary_branch_id($user_id);

        $current_branch = null;

        // Nếu có branch_id, lấy branch_name tương ứng
        if ($branch_id) {
            $current_branch = checkin_mkt192_get_branch_name($branch_id);
        }

        return new WP_REST_Response([
            'success'           => true,
            'user_id'           => $user_id,
            'current_branch'    => $current_branch,
            'current_branch_id' => $branch_id
        ], 200);
    } catch (Exception $e) {
        error_log('Checkin MKT192: Error getting user current branch - ' . $e->getMessage());
        return new WP_Error('fetch_failed', 'Lỗi khi lấy chi nhánh hiện tại', ['status' => 500]);
    }
}

/**
 * Lưu chi nhánh hiện tại của user vào meta
 */
function checkin_mkt192_set_user_current_branch_api(WP_REST_Request $request) {
    global $wpdb;

    $user_id = get_current_user_id();

    if (!$user_id) {
        return new WP_Error('not_authenticated', 'Người dùng chưa đăng nhập', ['status' => 401]);
    }

    $body        = $request->get_json_params();
    $branch_name = isset($body['branch_name']) ? sanitize_text_field($body['branch_name']) : '';

    if (empty($branch_name)) {
        return new WP_Error('missing_branch', 'Chi nhánh không được để trống', ['status' => 400]);
    }

    try {
        // Validate branch exists
        $branch_exists = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}checkin_mkt192_locations WHERE location_name = %s",
            $branch_name
        ));

        if (!$branch_exists) {
            return new WP_Error('branch_not_found', 'Chi nhánh không tồn tại', ['status' => 404]);
        }

        // Update user meta
        update_user_meta($user_id, 'current_branch', $branch_name);

        return new WP_REST_Response([
            'success'        => true,
            'user_id'        => $user_id,
            'current_branch' => $branch_name,
            'message'        => 'Cập nhật chi nhánh thành công'
        ], 200);
    } catch (Exception $e) {
        error_log('Checkin MKT192: Error setting user current branch - ' . $e->getMessage());
        return new WP_Error('update_failed', 'Lỗi khi cập nhật chi nhánh: ' . $e->getMessage(), ['status' => 500]);
    }
}

/**
 * Tính khoảng cách giữa hai điểm dựa trên vĩ độ, kinh độ sử dụng Haversine formula
 * @return float Khoảng cách tính bằng mét
 */
function checkin_mkt192_haversine_distance($lat1, $lon1, $lat2, $lon2) {
    $earth_radius = 6371000; // Bán kính Trái Đất tính bằng mét

    $lat1_rad  = deg2rad($lat1);
    $lat2_rad  = deg2rad($lat2);
    $delta_lat = deg2rad($lat2 - $lat1);
    $delta_lon = deg2rad($lon2 - $lon1);

    $a = sin($delta_lat / 2) * sin($delta_lat / 2) +
         cos($lat1_rad)      * cos($lat2_rad) * sin($delta_lon / 2) * sin($delta_lon / 2);

    $c = 2 * asin(sqrt($a));

    return $earth_radius * $c; // Trả về khoảng cách tính bằng mét
}

/**
 * Helper function: Thêm điều kiện branch filter vào query
 * @param string $query SQL query hiện tại
 * @param string $table Tên bảng database
 * @param int $branch_id Branch ID cần lọc (updated to use branch_id instead of branch_name)
 * @return string Query đã cập nhật
 */
function checkin_mkt192_add_branch_filter($query, $table, $branch_id = 0) {
    if (empty($branch_id)) {
        return $query;
    }

    $branch_id = intval($branch_id);

    if (strpos($query, 'WHERE') !== false) {
        return str_replace('WHERE', "WHERE {$table}.branch_id = {$branch_id} AND", $query);
    } else {
        return $query . " WHERE {$table}.branch_id = {$branch_id}";
    }
}

/**
 * Helper function: Lấy chi nhánh CHÍNH từ request hoặc staff profile
 *
 * Ưu tiên: request param branch_id > staff's primary branch (branch_id column)
 * Chi nhánh chính được dùng để filter data theo chi nhánh mặc định của user
 *
 * @param WP_REST_Request $request
 * @return int|null Chi nhánh ID hoặc null nếu không có
 */
function checkin_mkt192_get_branch_from_request($request) {
    // Sử dụng helper function để lấy branch_id từ context
    return checkin_mkt192_get_branch_id_from_context($request, get_current_user_id());
}
?>
