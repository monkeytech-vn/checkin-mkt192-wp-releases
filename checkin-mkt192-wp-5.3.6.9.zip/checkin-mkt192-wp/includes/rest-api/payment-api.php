<?php

add_action('rest_api_init', function () {
    // PayOS Config - Staff/Admin tạo link thanh toán
    register_rest_route('vg/v1', '/payos-config', [
    'methods'             => 'POST',
    'callback'            => 'checkin_mkt192_handle_payos_config',
    'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'payment.process']),
    'args'                => [
        'orderCode' => [
            'required'          => true,
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
        ],
        'amount' => [
            'required'          => true,
            'type'              => 'number',
            'validate_callback' => function($param) {
                return is_numeric($param) && $param > 0;
            },
        ],
        'description' => [
            'required'          => false,
            'type'              => 'string',
            'sanitize_callback' => 'sanitize_text_field',
        ],
    ],
]);

    // PayOS Webhook - Public endpoint (from payment gateway)
    register_rest_route('vg/v1', '/payment-webhook', [
    'methods'             => 'POST',
    'callback'            => 'checkin_mkt192_handle_payos_webhook',
    'permission_callback' => '__return_true' // Public webhook
]);

    // PayOS Success Callback - Public endpoint (customer redirect)
    register_rest_route('vg/v1', '/payos-payment-success', [
        'methods'             => 'GET',
        'callback'            => 'handle_payos_payment_success',
        'permission_callback' => '__return_true', // Public callback
    ]);

    function checkin_mkt192_handle_payos_config(WP_REST_Request $request) {
    $orderCode   = $request->get_param('orderCode');
    $amount      = $request->get_param('amount');
    $description = $request->get_param('description') ?: 'Thanh toán hóa đơn';

    // Cấu hình API PayOS
    $apiUrl      = 'https://api-merchant.payos.vn/v2/payment-requests';
    $clientId    = '69a3c869-9851-488d-900f-39c878cc30c2'; // Thay bằng clientId thực tế
    $apiKey      = '3bbb8bcb-d59d-4f00-8f4f-bb3b6305f7cb';   // Thay bằng apiKey thực tế
    $checksumKey = '2f6e7ec9bc2d15468ab6efa0e725007703c437371e6582512ff4b7f3baab9537'; // Thay bằng checksumKey thực tế

    // Dữ liệu gửi đi
    $payload = [
        'orderCode'   => $orderCode,
        'amount'      => $amount * 100, // PayOS yêu cầu số tiền theo cent (nhân 100)
        'description' => $description,
        'cancelUrl'   => 'https://vangroupbarbershop.store/app-tho.html?payment_error=cancelled',
        'returnUrl'   => 'https://vangroupbarbershop.store/vg/v1/payos-payment-success',
    ];

    // Tạo chữ ký HMAC-SHA256
    $dataString = http_build_query($payload);
    $signature  = hash_hmac('sha256', $dataString, $checksumKey);

    // Thiết lập headers
    $headers = [
        'x-client-id'  => $clientId,
        'x-api-key'    => $apiKey,
        'signature'    => $signature,
        'Content-Type' => 'application/json',
    ];

    // Gửi yêu cầu tới PayOS
    $response = wp_remote_post($apiUrl, [
        'headers' => $headers,
        'body'    => json_encode($payload),
        'timeout' => 30,
    ]);

    if (is_wp_error($response)) {
        error_log('PayOS Config Error: ' . $response->get_error_message());
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Lỗi khi kết nối với PayOS: ' . $response->get_error_message(),
        ], 500);
    }

    $httpCode = wp_remote_retrieve_response_code($response);
    $body     = json_decode(wp_remote_retrieve_body($response), true);

    if ($httpCode !== 200 || !isset($body['code']) || $body['code'] !== '00') {
        error_log('PayOS Config Failed: ' . json_encode($body));
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Lỗi khi cấu hình PayOS: ' . ($body['message'] ?? 'Không xác định'),
        ], $httpCode);
    }

    // Trả về URL thanh toán từ PayOS
    $checkoutUrl = $body['data']['checkoutUrl'] ?? '';
    if (empty($checkoutUrl)) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Không nhận được URL thanh toán từ PayOS',
        ], 500);
    }

    return new WP_REST_Response([
        'success' => true,
        'message' => 'Cấu hình PayOS thành công',
        'data'    => [
            'checkoutUrl' => $checkoutUrl,
            'orderCode'   => $orderCode,
        ],
    ], 200);
}

function checkin_mkt192_handle_payos_webhook(WP_REST_Request $request) {
    global $wpdb;
    $table_name         = 'ZAw_defaultcheckin_mkt192_invoices_data';
    $webhook_secret_key = '2f6e7ec9bc2d15468ab6efa0e725007703c437371e6582512ff4b7f3baab9537';

    // Lấy dữ liệu thô từ body
    $raw_body = file_get_contents('php://input');
    error_log('PayOS Webhook Raw Body: ' . $raw_body);

    // Parse JSON
    $data = json_decode($raw_body, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        error_log('PayOS Webhook: JSON parse error - ' . json_last_error_msg());
        return new WP_REST_Response(['success' => false, 'message' => 'Dữ liệu JSON không hợp lệ'], 400);
    }

    // Kiểm tra các trường bắt buộc
    if (!isset($data['code']) || !isset($data['data']) || !isset($data['signature'])) {
        error_log('PayOS Webhook: Missing required fields');
        return new WP_REST_Response(['success' => false, 'message' => 'Thiếu các trường bắt buộc'], 400);
    }

    // Tạo và kiểm tra chữ ký
    $transaction_data = $data['data'];
    ksort($transaction_data);
    $transaction_str    = http_build_query($transaction_data);
    $computed_signature = hash_hmac('sha256', $transaction_str, $webhook_secret_key);

    if ($data['signature'] !== $computed_signature) {
        error_log('PayOS Webhook: Invalid signature - Computed: ' . $computed_signature . ', Received: ' . $data['signature']);
        return new WP_REST_Response(['success' => false, 'message' => 'Chữ ký không hợp lệ'], 403);
    }

    // Lấy thông tin giao dịch
    $order_code       = sanitize_text_field($data['data']['orderCode']);
    $transaction_code = sanitize_text_field($data['code']);
    $total            = floatval($data['data']['amount']);

    if (empty($order_code)) {
        error_log('PayOS Webhook: Missing orderCode');
        return new WP_REST_Response(['success' => false, 'message' => 'Thiếu orderCode'], 400);
    }

    // Xác định trạng thái
    $new_status         = '';
    $new_payment_status = '';
    switch ($transaction_code) {
        case '00':
            $new_status         = 'paid';
            $new_payment_status = 'paid';
            break;
        case '01':
            $new_status         = 'cancelled';
            $new_payment_status = 'cancelled';
            break;
        case '02':
            $new_status         = 'pending';
            $new_payment_status = 'pending';
            break;
        default:
            error_log('PayOS Webhook: Unknown transaction code ' . $transaction_code);
            return new WP_REST_Response(['success' => false, 'message' => 'Mã giao dịch không hợp lệ'], 400);
    }

    // Cập nhật trạng thái hóa đơn
    $updated = $wpdb->update(
        $table_name,
        [
            'status'         => $new_status,
            'payment_status' => $new_payment_status,
            'total'          => $total,
            'updated_at'     => current_time('mysql')
        ],
        ['payos_order_code' => $order_code],
        ['%s', '%s', '%f', '%s'],
        ['%s']
    );

    if ($updated === false) {
        error_log('PayOS Webhook: Database update failed for orderCode=' . $order_code . ' - Error: ' . $wpdb->last_error);
        return new WP_REST_Response(['success' => false, 'message' => 'Lỗi khi cập nhật cơ sở dữ liệu: ' . $wpdb->last_error], 500);
    }

    if ($updated === 0) {
        error_log('PayOS Webhook: No invoice found for orderCode=' . $order_code);
        return new WP_REST_Response(['success' => false, 'message' => 'Không tìm thấy hóa đơn'], 404);
    }

    return new WP_REST_Response([
        'success' => true,
        'message' => 'Xử lý webhook thành công',
        'data'    => [
            'orderCode'        => $order_code,
            'transaction_code' => $transaction_code
        ]
    ], 200);
}

function handle_payos_payment_success(WP_REST_Request $request) {
    global $wpdb;
    $table_name = 'ZAw_defaultcheckin_mkt192_invoices_data'; // Bảng hóa đơn

    // Lấy query parameters từ PayOS
    $order_code = sanitize_text_field($request->get_param('orderCode'));
    $status     = sanitize_text_field($request->get_param('status'));
    $code       = sanitize_text_field($request->get_param('code'));
    $cancel     = filter_var($request->get_param('cancel'), FILTER_VALIDATE_BOOLEAN);

    if (!$order_code) {
        error_log('PayOS Success: Missing orderCode');
        wp_redirect('https://vangroupbarbershop.store/app-tho.html?payment_error=invalid_order_code');
        exit;
    }

    // Kiểm tra trạng thái thanh toán với PayOS
    $payos_response = wp_remote_get("https://api-merchant.payos.vn/v2/payment-requests/$order_code", [
        'headers' => [
            'x-client-id' => '69a3c869-9851-488d-900f-39c878cc30c2',
            'x-api-key'   => '3bbb8bcb-d59d-4f00-8f4f-bb3b6305f7cb',
        ],
    ]);

    if (is_wp_error($payos_response)) {
        error_log('PayOS Success: API request failed - ' . $payos_response->get_error_message());
        wp_redirect('https://vangroupbarbershop.store/app-tho.html?payment_error=api_error');
        exit;
    }

    $payos_data = json_decode(wp_remote_retrieve_body($payos_response), true);
    if ($payos_data['code'] !== '00' || $payos_data['data']['status'] !== 'PAID') {
        error_log('PayOS Success: Payment not completed - ' . json_encode($payos_data));
        wp_redirect('https://vangroupbarbershop.store/app-tho.html?payment_error=payment_failed');
        exit;
    }

    // Lấy thông tin người dùng hiện tại (cashier)
    $current_user = wp_get_current_user();
    $cashier      = $current_user->display_name ? $current_user->display_name : 'Unknown';

    // Cập nhật trạng thái hóa đơn
    $updated = $wpdb->update(
        $table_name,
        [
            'payment_status' => 'paid',
            'payment_method' => 'payos',
            'status'         => 'paid',
            'cashier'        => $cashier,
            'updated_at'     => current_time('mysql'),
        ],
        ['payos_order_code' => $order_code],
        ['%s', '%s', '%s', '%s', '%s'],
        ['%s']
    );

    if ($updated === false) {
        error_log('PayOS Success: Database update failed for orderCode=' . $order_code . ' - ' . $wpdb->last_error);
        wp_redirect('https://vangroupbarbershop.store/app-tho.html?payment_error=db_error');
        exit;
    }

    if ($updated === 0) {
        error_log('PayOS Success: No invoice found for orderCode=' . $order_code);
        wp_redirect('https://vangroupbarbershop.store/app-tho.html?payment_error=invoice_not_found');
        exit;
    }

    // Chuyển hướng về trang gốc với thông báo thành công
    wp_redirect('https://vangroupbarbershop.store/app-tho');
    exit;
}
});