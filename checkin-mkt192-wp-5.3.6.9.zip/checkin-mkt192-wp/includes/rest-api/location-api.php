<?php

// Đăng ký các endpoint REST API cho quản lý địa điểm
add_action('rest_api_init', function () {
    // Endpoint để thêm địa điểm mới
    register_rest_route('vg/v1', '/locations', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_add_location_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'location.create'])
    ]);

    // Endpoint để lấy danh sách tất cả địa điểm (PUBLIC - cho khách đặt lịch)
    register_rest_route('vg/v1', '/locations', [
        'methods'             => 'GET',
        'callback'            => 'checkin_mkt192_get_all_locations_api',
        'permission_callback' => '__return_true' // Public access for booking customers
    ]);

    // Endpoint để lấy thông tin một địa điểm theo ID
    register_rest_route('vg/v1', '/locations/(?P<id>\d+)', [
        'methods'             => 'GET',
        'callback'            => 'checkin_mkt192_get_location_by_id',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'location.read'])
    ]);

    // Endpoint để cập nhật thông tin địa điểm
    register_rest_route('vg/v1', '/locations/(?P<id>\d+)', [
        'methods'             => 'PUT',
        'callback'            => 'checkin_mkt192_update_location_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'location.update'])
    ]);

    // Endpoint để xóa địa điểm theo ID
    register_rest_route('vg/v1', '/locations/(?P<id>\d+)', [
        'methods'             => 'DELETE',
        'callback'            => 'checkin_mkt192_delete_location_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'location.delete'])
    ]);
});

// Hàm thêm địa điểm mới
function checkin_mkt192_add_location_api(WP_REST_Request $request) {
    global $wpdb;

    $body          = $request->get_json_params();
    $location_name = isset($body['location_name']) ? sanitize_text_field($body['location_name']) : '';

    if (empty($location_name)) {
        return new WP_Error('missing_location_name', 'Tên chi nhánh không được để trống', ['status' => 400]);
    }

    try {
        $exists = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}checkin_mkt192_locations WHERE location_name = %s",
            $location_name
        ));

        if ($exists > 0) {
            return new WP_Error('duplicate_location', 'Tên chi nhánh đã tồn tại', ['status' => 400]);
        }

        $result = $wpdb->insert(
            "{$wpdb->prefix}checkin_mkt192_locations",
            [
                'location_name' => $location_name,
                'latitude'      => 0,
                'longitude'     => 0,
                'radius'        => 50
            ]
        );

        if ($result === false) {
            throw new Exception('Không thể thêm địa điểm');
        }

        return new WP_REST_Response(['success' => true, 'message' => 'Thêm chi nhánh thành công'], 200);
    } catch (Exception $e) {
        file_put_contents(
            CHECKIN_PLUGIN_DIR . '/logs/location_errors.log',
            date('Y-m-d H:i:s') . ' - Failed to add location: ' . $e->getMessage() . "\n",
            FILE_APPEND
        );
        return new WP_Error('add_failed', 'Lỗi khi thêm chi nhánh: ' . $e->getMessage(), ['status' => 500]);
    }
}

// Hàm lấy danh sách tất cả địa điểm
function checkin_mkt192_get_all_locations_api(WP_REST_Request $request) {
    global $wpdb;

    try {
        $locations = $wpdb->get_results(
            "SELECT id, location_name, latitude, longitude, radius, address, google_map_link, is_main_branch
             FROM {$wpdb->prefix}checkin_mkt192_locations
             ORDER BY is_main_branch DESC, location_name ASC",
            ARRAY_A
        );
        return new WP_REST_Response(['success' => true, 'data' => $locations], 200);
    } catch (Exception $e) {
        file_put_contents(
            CHECKIN_PLUGIN_DIR . '/logs/location_errors.log',
            date('Y-m-d H:i:s') . ' - Failed to fetch locations: ' . $e->getMessage() . "\n",
            FILE_APPEND
        );
        return new WP_Error('fetch_failed', 'Lỗi khi lấy danh sách: ' . $e->getMessage(), ['status' => 500]);
    }
}

// Hàm lấy thông tin một địa điểm theo ID
function checkin_mkt192_get_location_by_id(WP_REST_Request $request) {
    global $wpdb;

    $location_id = intval($request->get_param('id'));

    try {
        $location = $wpdb->get_row($wpdb->prepare(
            "SELECT id, location_name, latitude, longitude, radius, address, google_map_link, is_main_branch
             FROM {$wpdb->prefix}checkin_mkt192_locations
             WHERE id = %d LIMIT 1",
            $location_id
        ), ARRAY_A);

        if ($location) {
            return new WP_REST_Response(['success' => true, 'data' => $location], 200);
        } else {
            return new WP_Error('not_found', 'Không tìm thấy địa điểm', ['status' => 404]);
        }
    } catch (Exception $e) {
        file_put_contents(
            CHECKIN_PLUGIN_DIR . '/logs/location_errors.log',
            date('Y-m-d H:i:s') . ' - Failed to fetch location: ' . $e->getMessage() . "\n",
            FILE_APPEND
        );
        return new WP_Error('fetch_failed', 'Lỗi khi lấy dữ liệu: ' . $e->getMessage(), ['status' => 500]);
    }
}

// Hàm cập nhật địa điểm
function checkin_mkt192_update_location_api(WP_REST_Request $request) {
    global $wpdb;

    $location_id = intval($request->get_param('id'));
    $body        = $request->get_json_params();

    $location_name   = isset($body['location_name']) ? sanitize_text_field($body['location_name']) : '';
    $address         = isset($body['address']) ? sanitize_text_field($body['address']) : '';
    $google_map_link = isset($body['google_map_link']) ? esc_url_raw($body['google_map_link']) : '';
    $latitude        = isset($body['latitude']) ? floatval($body['latitude']) : 0;
    $longitude       = isset($body['longitude']) ? floatval($body['longitude']) : 0;
    $radius          = isset($body['radius']) ? intval($body['radius']) : 50;
    $is_main_branch  = isset($body['is_main_branch']) ? intval($body['is_main_branch']) : 0;

    if (empty($location_id)) {
        return new WP_Error('missing_location_id', 'Vui lòng cung cấp ID địa điểm', ['status' => 400]);
    }

    try {
        $exists = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}checkin_mkt192_locations WHERE id = %d",
            $location_id
        ));

        if ($exists == 0) {
            return new WP_Error('location_not_found', 'Không tìm thấy địa điểm với ID này', ['status' => 404]);
        }

        // Nếu đánh dấu là chi nhánh chính, bỏ đánh dấu các chi nhánh khác
        if ($is_main_branch == 1) {
            $wpdb->update(
                "{$wpdb->prefix}checkin_mkt192_locations",
                ['is_main_branch' => 0],
                ['id !='          => $location_id]
            );
        }

        $update_data = [
            'latitude'        => $latitude,
            'longitude'       => $longitude,
            'radius'          => $radius,
            'address'         => $address,
            'google_map_link' => $google_map_link,
            'is_main_branch'  => $is_main_branch
        ];

        // Chỉ cập nhật location_name nếu có giá trị
        if (!empty($location_name)) {
            $update_data['location_name'] = $location_name;
        }

        $result = $wpdb->update(
            "{$wpdb->prefix}checkin_mkt192_locations",
            $update_data,
            ['id' => $location_id]
        );

        if ($result === false) {
            throw new Exception('Không thể cập nhật địa điểm');
        }

        return new WP_REST_Response(['success' => true, 'message' => 'Lưu thành công'], 200);
    } catch (Exception $e) {
        file_put_contents(
            CHECKIN_PLUGIN_DIR . '/logs/location_errors.log',
            date('Y-m-d H:i:s') . ' - Failed to save location: ' . $e->getMessage() . "\n",
            FILE_APPEND
        );
        return new WP_Error('update_failed', 'Lỗi khi lưu: ' . $e->getMessage(), ['status' => 500]);
    }
}

// Hàm xóa địa điểm theo ID
function checkin_mkt192_delete_location_api(WP_REST_Request $request) {
    global $wpdb;

    $location_id = intval($request->get_param('id'));

    try {
        // Kiểm tra xem địa điểm có tồn tại không
        $exists = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}checkin_mkt192_locations WHERE id = %d",
            $location_id
        ));

        // Ghi log để gỡ lỗi
        file_put_contents(
            __DIR__ . '/logs/location_errors.log',
            date('Y-m-d H:i:s') . " - Checking existence of location ID {$location_id}: exists = {$exists}\n",
            FILE_APPEND
        );

        if ($exists == 0) {
            return new WP_Error('location_not_found', 'Không tìm thấy địa điểm để xóa', ['status' => 404]);
        }

        // Thực hiện xóa
        $result = $wpdb->delete(
            "{$wpdb->prefix}checkin_mkt192_locations",
            ['id' => $location_id],
            ['%d']
        );

        // Ghi log kết quả xóa
        file_put_contents(
            __DIR__ . '/logs/location_errors.log',
            date('Y-m-d H:i:s') . " - Delete location ID {$location_id}: result = {$result}\n",
            FILE_APPEND
        );

        if ($result === false || $result === 0) {
            throw new Exception('Không thể xóa địa điểm');
        }

        return new WP_REST_Response(['success' => true, 'message' => 'Xóa địa điểm thành công'], 200);
    } catch (Exception $e) {
        file_put_contents(
            __DIR__ . '/logs/location_errors.log',
            date('Y-m-d H:i:s') . " - Failed to delete location ID {$location_id}: " . $e->getMessage() . "\n",
            FILE_APPEND
        );
        return new WP_Error('delete_failed', 'Lỗi khi xóa: ' . $e->getMessage(), ['status' => 500]);
    }
}
?>
