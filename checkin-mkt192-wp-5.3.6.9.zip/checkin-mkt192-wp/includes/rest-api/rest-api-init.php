<?php

require_once __DIR__ . '/log-helper.php';
require_once __DIR__ . '/permission.php';
require_once __DIR__ . '/rate-limiter.php';

require_once __DIR__ . '/branch-api.php';
require_once __DIR__ . '/customer-api.php';
require_once __DIR__ . '/booking-api.php';
require_once __DIR__ . '/inventory-api.php';
require_once __DIR__ . '/service-groups-api.php';
require_once __DIR__ . '/services-api.php';
require_once __DIR__ . '/product-groups-api.php';
require_once __DIR__ . '/products-api.php';
require_once __DIR__ . '/checkin-api.php';
require_once __DIR__ . '/location-api.php';
require_once __DIR__ . '/shift-api.php';
require_once __DIR__ . '/cash-shift-api.php'; // Quản lý ca thu ngân (giao nhận ca)
// leave-requests-api.php đã được tích hợp vào approval-requests-api.php
require_once __DIR__ . '/approval-requests-api.php';
require_once __DIR__ . '/staff-profile-api.php';
require_once __DIR__ . '/staff-levels-api.php';
require_once __DIR__ . '/staff-role-api.php';
require_once __DIR__ . '/salary-levels-api.php';
require_once __DIR__ . '/salary-api.php';
require_once __DIR__ . '/invoice-api.php';
require_once __DIR__ . '/review-api.php';
require_once __DIR__ . '/kpi-api.php';
require_once __DIR__ . '/ctkm-api.php';
require_once __DIR__ . '/payment-api.php';
require_once __DIR__ . '/penalty-api.php';
require_once __DIR__ . '/login.php';
require_once __DIR__ . '/account-linking-api.php'; // Liên kết tài khoản mạng xã hội mới với tài khoản hiện có
require_once __DIR__ . '/admin-settings-api.php';
require_once __DIR__ . '/zalo-api.php';
require_once __DIR__ . '/zalo-social-api.php'; // Zalo Social Login cho khách hàng
require_once __DIR__ . '/google-api.php';
require_once __DIR__ . '/lark-api.php';
require_once __DIR__ . '/push-notifications-api.php';
require_once __DIR__ . '/notifications-api.php';
require_once __DIR__ . '/debug-permissions-api.php';
require_once __DIR__ . '/monkeypay-api.php';
