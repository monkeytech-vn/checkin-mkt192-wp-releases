<?php

add_action('rest_api_init', function () {
    // Salary Levels - GET (List/read salary level configuration)
    register_rest_route('vg/v1', '/salary-levels', [
        'methods'             => 'GET',
        'callback'            => 'checkin_mkt192_get_salary_levels_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'salary_level.read'])
    ]);
    // Salary Levels - POST (Create new salary level)
    register_rest_route('vg/v1', '/salary-levels', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_save_salary_level_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'salary_level.create'])
    ]);
    // Salary Levels - PUT (Update existing salary level)
    register_rest_route('vg/v1', '/salary-levels/(?P<id>\d+)', [
        'methods'             => 'PUT',
        'callback'            => 'checkin_mkt192_update_salary_level_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'salary_level.update'])
    ]);
    // Salary Levels - DELETE (Remove salary level)
    register_rest_route('vg/v1', '/salary-levels/(?P<id>\d+)', [
        'methods'             => 'DELETE',
        'callback'            => 'checkin_mkt192_delete_salary_level_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'salary_level.delete'])
    ]);
});

function checkin_mkt192_get_salary_levels_api(WP_REST_Request $request) {
    global $wpdb;

    try {
        $level_name = sanitize_text_field($request->get_param('level_name'));

        // Khởi tạo câu truy vấn cơ bản - bao gồm branch_id và branch_ids
        $query = "SELECT id, level_name, base_salary, service_salary, chemical_salary, hourly_salary, video_salary, role, branch_id, branch_ids
                  FROM {$wpdb->prefix}checkin_mkt192_salary_level_settings";
        $params     = [];
        $conditions = [];

        // Nếu có level_name, lấy cấu hình lương cho cấp bậc cụ thể
        if ($level_name) {
            $conditions[] = 'level_name = %s';
            $params[]     = $level_name;
            $query .= ' WHERE ' . implode(' AND ', $conditions);
        }

        $levels = $wpdb->get_results($wpdb->prepare($query, $params), OBJECT);

        if (empty($levels)) {
            return new WP_REST_Response([
                'success' => false,
                'message' => 'Không tìm thấy dữ liệu cấu hình lương'
            ], 404);
        }

        // Parse branch_ids từ JSON string sang array
        foreach ($levels as &$level) {
            if (!empty($level->branch_ids)) {
                $level->branch_ids = json_decode($level->branch_ids, true) ?: [];
            } else {
                // Fallback: nếu branch_ids rỗng nhưng có branch_id, dùng branch_id
                $level->branch_ids = $level->branch_id ? [(int) $level->branch_id] : [];
            }
        }

        return new WP_REST_Response([
            'success' => true,
            'data'    => $level_name ? $levels[0] : $levels
        ], 200);
    } catch (Exception $e) {
        file_put_contents(CHECKIN_PLUGIN_DIR . '/logs/salary_level_errors.log', date('Y-m-d H:i:s') . ' - Failed to fetch salary levels: ' . $e->getMessage() . "\n", FILE_APPEND);
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Lỗi hệ thống'
        ], 500);
    }
}

function checkin_mkt192_save_salary_level_api(WP_REST_Request $request) {
    global $wpdb;
    $logFile = __DIR__ . '/logs/salary_level_errors.log';

    try {
        $data            = $request->get_json_params();
        $level_name      = sanitize_text_field($data['level_name'] ?? '');
        $base_salary     = floatval($data['base_salary'] ?? 0);
        $service_salary  = floatval($data['service_salary'] ?? 0);
        $chemical_salary = floatval($data['chemical_salary'] ?? 0);
        $hourly_salary   = floatval($data['hourly_salary'] ?? 0);
        $video_salary    = floatval($data['video_salary'] ?? 0);
        $role            = sanitize_text_field($data['role'] ?? '');

        // Xử lý branch_ids (mảng) - nếu không có thì fallback về branch_id đơn
        $branch_ids = $data['branch_ids'] ?? [];
        if (!is_array($branch_ids)) {
            $branch_ids = [];
        }
        // Sanitize branch_ids
        $branch_ids = array_map('intval', $branch_ids);
        $branch_ids = array_filter($branch_ids, function ($id) {
            return $id > 0;
        });
        $branch_ids_json = json_encode(array_values($branch_ids));

        if (empty($level_name) || empty($role)) {
            file_put_contents($logFile, date('Y-m-d H:i:s') . " - Failed to save salary level: Tên cấp bậc hoặc vai trò không được để trống\n", FILE_APPEND);
            return new WP_REST_Response(['success' => false, 'message' => 'Tên cấp bậc và vai trò không được để trống'], 400);
        }

        // Kiểm tra vai trò tồn tại
        $role_exists = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}checkin_mkt192_staff_roles WHERE role_name = %s",
            $role
        ));

        if (!$role_exists) {
            file_put_contents($logFile, date('Y-m-d H:i:s') . " - Failed to save salary level: Vai trò $role không hợp lệ\n", FILE_APPEND);
            return new WP_REST_Response(['success' => false, 'message' => 'Vai trò không hợp lệ'], 400);
        }

        // Kiểm tra cấp lương đã tồn tại chưa
        $level_exists = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}checkin_mkt192_salary_level_settings WHERE level_name = %s AND role = %s",
            $level_name,
            $role
        ));

        if ($level_exists) {
            // Cập nhật cấp lương
            $result = $wpdb->update(
                "{$wpdb->prefix}checkin_mkt192_salary_level_settings",
                [
                    'level_name'      => $level_name,
                    'base_salary'     => $base_salary,
                    'service_salary'  => $service_salary,
                    'chemical_salary' => $chemical_salary,
                    'hourly_salary'   => $hourly_salary,
                    'video_salary'    => $video_salary,
                    'role'            => $role,
                    'branch_ids'      => $branch_ids_json
                ],
                ['id' => $level_exists]
            );

            if ($result === false) {
                file_put_contents($logFile, date('Y-m-d H:i:s') . " - Failed to update salary level ID $level_exists: " . $wpdb->last_error . "\n", FILE_APPEND);
                return new WP_REST_Response(['success' => false, 'message' => 'Lỗi hệ thống khi cập nhật cấp lương'], 500);
            }

            $id = $level_exists;
            file_put_contents($logFile, date('Y-m-d H:i:s') . " - Successfully updated salary level: $level_name for role $role with branch_ids: $branch_ids_json\n", FILE_APPEND);
        } else {
            // Thêm cấp lương mới
            $result = $wpdb->insert(
                "{$wpdb->prefix}checkin_mkt192_salary_level_settings",
                [
                    'level_name'      => $level_name,
                    'base_salary'     => $base_salary,
                    'service_salary'  => $service_salary,
                    'chemical_salary' => $chemical_salary,
                    'hourly_salary'   => $hourly_salary,
                    'video_salary'    => $video_salary,
                    'role'            => $role,
                    'branch_ids'      => $branch_ids_json
                ]
            );

            if ($result === false) {
                file_put_contents($logFile, date('Y-m-d H:i:s') . ' - Failed to insert salary level: ' . $wpdb->last_error . "\n", FILE_APPEND);
                return new WP_REST_Response(['success' => false, 'message' => 'Lỗi hệ thống khi thêm cấp lương'], 500);
            }

            $id = $wpdb->insert_id;
            file_put_contents($logFile, date('Y-m-d H:i:s') . " - Successfully inserted salary level: $level_name for role $role with ID $id and branch_ids: $branch_ids_json\n", FILE_APPEND);
        }

        return new WP_REST_Response(['success' => true, 'data' => ['id' => $id]], 200);
    } catch (Exception $e) {
        file_put_contents($logFile, date('Y-m-d H:i:s') . ' - Failed to save salary level: ' . $e->getMessage() . "\n", FILE_APPEND);
        return new WP_REST_Response(['success' => false, 'message' => 'Lỗi hệ thống'], 500);
    }
}

function checkin_mkt192_update_salary_level_api(WP_REST_Request $request) {
    global $wpdb;
    try {
        $id              = $request->get_param('id');
        $data            = $request->get_json_params();
        $level_name      = sanitize_text_field($data['level_name'] ?? '');
        $base_salary     = floatval($data['base_salary'] ?? 0);
        $service_salary  = floatval($data['service_salary'] ?? 0);
        $chemical_salary = floatval($data['chemical_salary'] ?? 0);
        $hourly_salary   = floatval($data['hourly_salary'] ?? 0);
        $video_salary    = floatval($data['video_salary'] ?? 0);
        $role            = sanitize_text_field($data['role'] ?? '');

        // Xử lý branch_ids (mảng)
        $branch_ids = $data['branch_ids'] ?? [];
        if (!is_array($branch_ids)) {
            $branch_ids = [];
        }
        $branch_ids = array_map('intval', $branch_ids);
        $branch_ids = array_filter($branch_ids, function ($id) {
            return $id > 0;
        });
        $branch_ids_json = json_encode(array_values($branch_ids));

        if (empty($level_name) || empty($role)) {
            return new WP_REST_Response(['success' => false, 'message' => 'Tên cấp bậc và vai trò không được để trống'], 400);
        }

        // Kiểm tra vai trò tồn tại
        $role_exists = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}checkin_mkt192_staff_roles WHERE role_name = %s",
            $role
        ));

        if (!$role_exists) {
            return new WP_REST_Response(['success' => false, 'message' => 'Vai trò không hợp lệ'], 400);
        }

        // Kiểm tra cấp lương tồn tại
        $level_exists = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}checkin_mkt192_salary_level_settings WHERE id = %d",
            $id
        ));

        if (!$level_exists) {
            return new WP_REST_Response(['success' => false, 'message' => 'Cấp lương không tồn tại'], 404);
        }

        // Cập nhật cấp lương
        $wpdb->update(
            "{$wpdb->prefix}checkin_mkt192_salary_level_settings",
            [
                'level_name'      => $level_name,
                'base_salary'     => $base_salary,
                'service_salary'  => $service_salary,
                'chemical_salary' => $chemical_salary,
                'hourly_salary'   => $hourly_salary,
                'video_salary'    => $video_salary,
                'role'            => $role,
                'branch_ids'      => $branch_ids_json
            ],
            ['id' => $id]
        );

        return new WP_REST_Response(['success' => true, 'data' => ['id' => $id]], 200);
    } catch (Exception $e) {
        file_put_contents(CHECKIN_PLUGIN_DIR . '/logs/salary_level_errors.log', date('Y-m-d H:i:s') . ' - Failed to update salary level: ' . $e->getMessage() . "\n", FILE_APPEND);
        return new WP_REST_Response(['success' => false, 'message' => 'Lỗi hệ thống'], 500);
    }
}

function checkin_mkt192_delete_salary_level_api(WP_REST_Request $request) {
    global $wpdb;
    try {
        $id = $request->get_param('id');
        $wpdb->delete(
            "{$wpdb->prefix}checkin_mkt192_salary_level_settings",
            ['id' => $id]
        );

        return new WP_REST_Response(['success' => true, 'message' => 'Xóa cấp lương thành công'], 200);
    } catch (Exception $e) {
        file_put_contents(CHECKIN_PLUGIN_DIR . '/logs/salary_level_errors.log', date('Y-m-d H:i:s') . ' - Failed to delete salary level: ' . $e->getMessage() . "\n", FILE_APPEND);
        return new WP_REST_Response(['success' => false, 'message' => 'Lỗi hệ thống'], 500);
    }
}
