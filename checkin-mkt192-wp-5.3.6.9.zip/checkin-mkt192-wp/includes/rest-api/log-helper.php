<?php

/**
 * Helper function for logging to separate files
 * Giúp tách log ra các file riêng thay vì ghi vào debug.log
 */

if (!function_exists('checkin_mkt192_log')) {
    /**
     * Ghi log vào file riêng trong thư mục logs/
     *
     * @param string $filename Tên file log (không cần đuôi .log)
     * @param string $message Nội dung log
     * @param string $level Log level: 'ERROR', 'WARNING', 'INFO', 'DEBUG'
     * @param array|null $context Dữ liệu context để log (sẽ được convert sang JSON)
     */
    function checkin_mkt192_log($filename, $message, $level = 'INFO', $context = null) {
        // Chỉ log ERROR nếu không phải debug mode
        if ($level !== 'ERROR' && (!defined('WP_DEBUG') || !WP_DEBUG)) {
            return;
        }

        $log_dir = __DIR__ . '/logs/';

        // Tạo thư mục logs nếu chưa có
        if (!file_exists($log_dir)) {
            wp_mkdir_p($log_dir);
        }

        $log_file = $log_dir . $filename . '.log';

        // Format: [2024-01-01 12:00:00] [ERROR] Message
        $timestamp = date('Y-m-d H:i:s');
        $log_entry = "[{$timestamp}] [{$level}] {$message}";

        // Thêm context nếu có
        if ($context !== null) {
            if (is_array($context) || is_object($context)) {
                $log_entry .= ' | Context: ' . json_encode($context, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
            } else {
                $log_entry .= ' | Context: ' . $context;
            }
        }

        $log_entry .= PHP_EOL;

        // Ghi vào file
        error_log($log_entry, 3, $log_file);
    }
}

if (!function_exists('checkin_mkt192_log_error')) {
    /**
     * Shorthand cho log ERROR
     */
    function checkin_mkt192_log_error($filename, $message, $context = null) {
        checkin_mkt192_log($filename, $message, 'ERROR', $context);
    }
}

if (!function_exists('checkin_mkt192_log_info')) {
    /**
     * Shorthand cho log INFO
     */
    function checkin_mkt192_log_info($filename, $message, $context = null) {
        checkin_mkt192_log($filename, $message, 'INFO', $context);
    }
}

if (!function_exists('checkin_mkt192_log_debug')) {
    /**
     * Shorthand cho log DEBUG
     */
    function checkin_mkt192_log_debug($filename, $message, $context = null) {
        checkin_mkt192_log($filename, $message, 'DEBUG', $context);
    }
}