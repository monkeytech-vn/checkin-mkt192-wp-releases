<?php

/**
 * Centralized REST API permission helpers for Checkin MKT192
 *
 * Cách dùng nhanh trong register_rest_route:
 * - Public:        'permission_callback' => checkin_mkt192_permission('public')
 * - Cần login:     'permission_callback' => checkin_mkt192_permission('login')
 * - Chỉ quản lý:   'permission_callback' => checkin_mkt192_permission('manager')
 * - Theo vai trò:  'permission_callback' => checkin_mkt192_permission(['roles' => ['Quản Lý','Thu Ngân']])
 * - Theo scope:    'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'invoices.read'])
 */

if (!function_exists('checkin_mkt192_permission')) {
    function checkin_mkt192_permission($rule = 'public') {
        return function ($request) use ($rule) {
            return checkin_mkt192_evaluate_permission_rule($rule);
        };
    }
}

if (!function_exists('checkin_mkt192_evaluate_permission_rule')) {
    function checkin_mkt192_evaluate_permission_rule($rule) {
        // Chuỗi đơn giản
        if (is_string($rule)) {
            switch ($rule) {
                case 'public':
                    return true;
                case 'login':
                    return is_user_logged_in() ? true : new WP_Error('rest_forbidden', __('Bạn cần đăng nhập để sử dụng API này.'), ['status' => 401]);
                case 'manager':
                    return checkin_mkt192_is_manager() ? true : new WP_Error('rest_forbidden', __('Bạn không có quyền truy cập (chỉ dành cho Quản Lý).'), ['status' => 403]);
                default:
                    return is_user_logged_in() ? true : new WP_Error('rest_forbidden', __('Bạn cần đăng nhập để sử dụng API này.'), ['status' => 401]);
            }
        }

        // Mảng chi tiết
        if (is_array($rule)) {
            $mode  = isset($rule['mode']) ? $rule['mode'] : (isset($rule['roles']) || isset($rule['scope']) ? 'login' : 'public');
            $roles = isset($rule['roles']) && is_array($rule['roles']) ? $rule['roles'] : [];
            $scope = isset($rule['scope']) ? $rule['scope'] : '';
            $logic = isset($rule['logic']) && strtoupper($rule['logic']) === 'OR' ? 'OR' : 'AND';

            // mode
            if ($mode === 'public') {
                // pass
            } elseif ($mode === 'login') {
                if (!is_user_logged_in()) return new WP_Error('rest_forbidden', __('Bạn cần đăng nhập để sử dụng API này.'), ['status' => 401]);
            } elseif ($mode === 'manager') {
                if (!checkin_mkt192_is_manager()) return new WP_Error('rest_forbidden', __('Bạn không có quyền truy cập (chỉ dành cho Quản Lý).'), ['status' => 403]);
            } else {
                if (!is_user_logged_in()) return new WP_Error('rest_forbidden', __('Bạn cần đăng nhập để sử dụng API này.'), ['status' => 401]);
            }

            // roles
            $current_role = null;
            if (!empty($roles)) {
                $current_role = checkin_mkt192_get_current_staff_role();
                if (!$current_role) return new WP_Error('rest_forbidden', __('Không xác định được vai trò người dùng.'), ['status' => 403]);
                if (!in_array($current_role, $roles, true)) return new WP_Error('rest_forbidden', __('Bạn không có quyền phù hợp để thực hiện hành động này.'), ['status' => 403]);
            }

            // scope - hỗ trợ mảng scope với logic OR/AND
            if (!empty($scope)) {
                // Administrator (WP) luôn full quyền — không phụ thuộc ma trận phân quyền staff role
                if (current_user_can('manage_options')) return true;

                if ($current_role === null) $current_role = checkin_mkt192_get_current_staff_role();

                // Nếu chưa login/chưa có role -> cho qua để không phá hiện trạng khi chưa cấu hình
                if (!$current_role) return true;

                // Chuyển scope thành mảng nếu là string
                $scopes = is_array($scope) ? $scope : [trim((string) $scope)];

                $has_permission = false;
                $checked_scopes = [];

                foreach ($scopes as $single_scope) {
                    $single_scope = trim((string) $single_scope);
                    if ($single_scope === '') continue;

                    $checked_scopes[] = $single_scope;

                    if (checkin_mkt192_role_has_scope($current_role, $single_scope)) {
                        $has_permission = true;
                        if ($logic === 'OR') {
                            // Với OR, chỉ cần 1 scope pass là đủ
                            break;
                        }
                    } elseif ($logic === 'AND') {
                        // Với AND, nếu 1 scope fail thì toàn bộ fail
                        $has_permission = false;
                        break;
                    }
                }

                if (!$has_permission) {
                    $scope_display = implode(', ', $checked_scopes);
                    checkin_mkt192_log_error('permission', "Permission denied for role '$current_role' on scope(s) '$scope_display' with logic '$logic'");

                    // Lấy message từ scope đầu tiên
                    $first_scope    = !empty($checked_scopes) ? $checked_scopes[0] : '';
                    $scope_messages = [
                        // Hóa đơn
                        'invoices.read'         => 'Bạn không có quyền xem hóa đơn.',
                        'invoices.create'       => 'Bạn không có quyền tạo hóa đơn.',
                        'invoices.update'       => 'Bạn không có quyền cập nhật hóa đơn.',
                        'invoices.delete'       => 'Bạn không có quyền xóa hóa đơn.',
                        'invoice.penalty'       => 'Bạn không có quyền truy thu.',
                        // Sản phẩm
                        'products.read'         => 'Bạn không có quyền xem sản phẩm.',
                        'products.create'       => 'Bạn không có quyền tạo sản phẩm.',
                        'products.update'       => 'Bạn không có quyền cập nhật sản phẩm.',
                        'products.delete'       => 'Bạn không có quyền xóa sản phẩm.',
                        // Dịch vụ
                        'services.read'         => 'Bạn không có quyền xem dịch vụ.',
                        'services.create'       => 'Bạn không có quyền tạo dịch vụ.',
                        'services.update'       => 'Bạn không có quyền cập nhật dịch vụ.',
                        'services.delete'       => 'Bạn không có quyền xóa dịch vụ.',
                        // Nhân viên
                        'staff.read'            => 'Bạn không có quyền xem nhân viên.',
                        'staff.create'          => 'Bạn không có quyền tạo nhân viên.',
                        'staff.update'          => 'Bạn không có quyền cập nhật nhân viên.',
                        'staff.delete'          => 'Bạn không có quyền xóa nhân viên.',
                        'staff.update_status'   => 'Bạn không có quyền cập nhật trạng thái nhân viên.',
                        // Vai trò [MỚI]
                        'role.read'             => 'Bạn không có quyền xem vai trò.',
                        'role.create'           => 'Bạn không có quyền tạo vai trò.',
                        'role.update'           => 'Bạn không có quyền cập nhật vai trò.',
                        'role.delete'           => 'Bạn không có quyền xóa vai trò.',
                        // KPI
                        'kpi.read'              => 'Bạn không có quyền xem KPI.',
                        'kpi.config'            => 'Bạn không có quyền cấu hình KPI.',
                        'kpi.evaluate'          => 'Bạn không có quyền đánh giá KPI.',
                        'kpi.delete'            => 'Bạn không có quyền xóa KPI.',
                        'kpi.reset'             => 'Bạn không có quyền reset KPI.',
                        // Lương
                        'salary.read'           => 'Bạn không có quyền xem lương.',
                        'salary.calculate'      => 'Bạn không có quyền tính lương.',
                        'salary.confirm'        => 'Bạn không có quyền xác nhận lương.',
                        'salary.payment'        => 'Bạn không có quyền thanh toán lương.',
                        'salary.notify'         => 'Bạn không có quyền gửi thông báo lương.',
                        // Booking
                        'booking.read'          => 'Bạn không có quyền xem đặt lịch.',
                        'booking.view_personal' => 'Bạn không có quyền xem đặt lịch cá nhân.',
                        'booking.view_all'      => 'Bạn không có quyền xem tất cả đặt lịch.',
                        'booking.create'        => 'Bạn không có quyền tạo đặt lịch.',
                        'booking.update'        => 'Bạn không có quyền cập nhật đặt lịch.',
                        'booking.delete'        => 'Bạn không có quyền xóa đặt lịch.',
                        'booking.resend'        => 'Bạn không có quyền gửi lại thông báo đặt lịch.',
                        'booking.config'        => 'Bạn không có quyền cấu hình đặt lịch.',
                        // Lịch làm việc (Schedule) [MỚI]
                        'schedule.read'         => 'Bạn không có quyền xem lịch làm việc.',
                        'schedule.manage'       => 'Bạn không có quyền quản lý lịch làm việc.',
                        // Chấm công [MỚI]
                        'checkin.record'        => 'Bạn không có quyền chấm công.',
                        'checkin.view'          => 'Bạn không có quyền xem lịch sử chấm công.',
                        'checkin.view_all'      => 'Bạn không có quyền xem tất cả lịch sử chấm công.',
                        // Nghỉ phép [MỚI]
                        'leave.read'            => 'Bạn không có quyền xem nghỉ phép.',
                        'leave.request'         => 'Bạn không có quyền đăng ký nghỉ phép.',
                        'leave.approve'         => 'Bạn không có quyền duyệt nghỉ phép.',
                        // Ca làm việc [MỚI]
                        'shift.read'            => 'Bạn không có quyền xem ca làm việc.',
                        'shift.create'          => 'Bạn không có quyền tạo ca làm việc.',
                        'shift.update'          => 'Bạn không có quyền cập nhật ca làm việc.',
                        'shift.delete'          => 'Bạn không có quyền xóa ca làm việc.',
                        // Chi nhánh [MỚI]
                        'location.read'         => 'Bạn không có quyền xem chi nhánh.',
                        'location.create'       => 'Bạn không có quyền tạo chi nhánh.',
                        'location.update'       => 'Bạn không có quyền cập nhật chi nhánh.',
                        'location.delete'       => 'Bạn không có quyền xóa chi nhánh.',
                        // Khách hàng [MỚI]
                        'customer.read'         => 'Bạn không có quyền xem khách hàng.',
                        'customer.create'       => 'Bạn không có quyền tạo khách hàng.',
                        'customer.update'       => 'Bạn không có quyền cập nhật khách hàng.',
                        'customer.delete'       => 'Bạn không có quyền xóa khách hàng.',
                        // Thanh toán [MỚI]
                        'payment.read'          => 'Bạn không có quyền xem thanh toán.',
                        'payment.process'       => 'Bạn không có quyền xử lý thanh toán.',
                        // Phạt/Truy thu [MỚI]
                        'penalty.read'          => 'Bạn không có quyền xem cài đặt phạt.',
                        'penalty.update'        => 'Bạn không có quyền cập nhật cài đặt phạt.',
                        // Đánh giá [MỚI]
                        'review.read'           => 'Bạn không có quyền xem đánh giá.',
                        'review.moderate'       => 'Bạn không có quyền quản lý đánh giá.',
                        // Phase 5 Session 2 Scopes [MỚI - 2024]
                        // Cài đặt hệ thống
                        'settings.read'         => 'Bạn không có quyền xem cài đặt hệ thống.',
                        'settings.update'       => 'Bạn không có quyền cập nhật cài đặt hệ thống.',
                        // Chương trình khuyến mãi
                        'promotion.read'        => 'Bạn không có quyền xem chương trình khuyến mãi.',
                        'promotion.create'      => 'Bạn không có quyền tạo chương trình khuyến mãi.',
                        'promotion.update'      => 'Bạn không có quyền cập nhật chương trình khuyến mãi.',
                        'promotion.delete'      => 'Bạn không có quyền xóa chương trình khuyến mãi.',
                        // Kho hàng
                        'inventory.read'        => 'Bạn không có quyền xem kho hàng.',
                        'inventory.check'       => 'Bạn không có quyền tạo phiếu kiểm kê.',
                        'inventory.transaction' => 'Bạn không có quyền tạo phiếu xuất/nhập kho.',
                        'inventory.approve'     => 'Bạn không có quyền duyệt phiếu xuất/nhập kho.',
                        'inventory.update'      => 'Bạn không có quyền cập nhật kho hàng.',
                        'inventory.delete'      => 'Bạn không có quyền xóa phiếu xuất/nhập kho.',
                        // Nhóm sản phẩm
                        'product_group.read'    => 'Bạn không có quyền xem nhóm sản phẩm.',
                        'product_group.create'  => 'Bạn không có quyền tạo nhóm sản phẩm.',
                        'product_group.update'  => 'Bạn không có quyền cập nhật nhóm sản phẩm.',
                        'product_group.delete'  => 'Bạn không có quyền xóa nhóm sản phẩm.',
                        // Nhóm dịch vụ
                        'service_group.read'    => 'Bạn không có quyền xem nhóm dịch vụ.',
                        'service_group.create'  => 'Bạn không có quyền tạo nhóm dịch vụ.',
                        'service_group.update'  => 'Bạn không có quyền cập nhật nhóm dịch vụ.',
                        'service_group.delete'  => 'Bạn không có quyền xóa nhóm dịch vụ.',
                        // Cấp bậc lương
                        'salary_level.read'     => 'Bạn không có quyền xem cấp bậc lương.',
                        'salary_level.create'   => 'Bạn không có quyền tạo cấp bậc lương.',
                        'salary_level.update'   => 'Bạn không có quyền cập nhật cấp bậc lương.',
                        'salary_level.delete'   => 'Bạn không có quyền xóa cấp bậc lương.',
                        // Cấp bậc nhân viên
                        'staff_level.read'      => 'Bạn không có quyền xem cấp bậc nhân viên.',
                        'staff_level.create'    => 'Bạn không có quyền tạo cấp bậc nhân viên.',
                        'staff_level.update'    => 'Bạn không có quyền cập nhật cấp bậc nhân viên.',
                        'staff_level.delete'    => 'Bạn không có quyền xóa cấp bậc nhân viên.',
                        // Cài đặt
                        'zalo.config'           => 'Bạn không có quyền cấu hình Zalo.',
                        'dashboard.view'        => 'Bạn không có quyền xem dashboard.',
                        'location.set'          => 'Bạn không có quyền thiết lập vị trí.',
                        'shift.set'             => 'Bạn không có quyền thiết lập ca.',
                        // Đơn xin phép [MỚI - 2025]
                        'approval.create'       => 'Bạn không có quyền tạo đơn xin phép.',
                        'approval.read'         => 'Bạn không có quyền xem đơn xin phép.',
                        'approval.approve'      => 'Bạn không có quyền duyệt đơn xin phép.',
                        'approval.reject'       => 'Bạn không có quyền từ chối đơn xin phép.',
                        'approval.delete'       => 'Bạn không có quyền xóa đơn xin phép.',
                    ];
                    $message = isset($scope_messages[$first_scope]) ? $scope_messages[$first_scope] : __('Bạn không có quyền truy cập tính năng này.');
                    return new WP_Error('rest_forbidden', $message, ['status' => 403]);
                }
            }

            return true;
        }

        // Mặc định yêu cầu login
        return is_user_logged_in() ? true : new WP_Error('rest_forbidden', __('Bạn cần đăng nhập để sử dụng API này.'), ['status' => 401]);
    }
}

if (!function_exists('checkin_mkt192_is_manager')) {
    function checkin_mkt192_is_manager() {
        if (current_user_can('manage_options')) return true;
        $role = checkin_mkt192_get_current_staff_role();
        return $role === 'Quản Lý';
    }
}

if (!function_exists('checkin_mkt192_get_current_staff_role')) {
    function checkin_mkt192_get_current_staff_role() {
        if (!is_user_logged_in()) return null;
        $user = wp_get_current_user();
        if (!$user || !$user->exists()) return null;

        static $cache = null;
        if ($cache !== null) return $cache;

        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT user_role FROM {$wpdb->prefix}checkin_mkt192_staff WHERE user_id = %d LIMIT 1",
            $user->ID
        ));

        if ($row && isset($row->user_role) && $row->user_role !== '') {
            $cache = $row->user_role;
            return $cache;
        }

        if (user_can($user, 'manage_options')) {
            $cache = 'Quản Lý';
        } elseif (in_array('cashier', (array) $user->roles, true)) {
            $cache = 'Thu Ngân';
        } elseif (in_array('staff', (array) $user->roles, true)) {
            $cache = 'Nhân viên';
        } else {
            $cache = null;
            checkin_mkt192_log_error('permission', "No role found for user: {$user->display_name} (ID: {$user->ID})");
        }
        return $cache;
    }
}

if (!function_exists('checkin_mkt192_is_assoc_array')) {
    function checkin_mkt192_is_assoc_array($arr) {
        if (!is_array($arr)) return false;
        return array_keys($arr) !== range(0, count($arr) - 1);
    }
}

if (!function_exists('checkin_mkt192_scope_to_permission_candidates')) {
    function checkin_mkt192_scope_to_permission_candidates($scope) {
        $scope = trim((string) $scope);
        if ($scope === '') return [];

        $alias = [
            // Hóa đơn
            'invoices.read'         => [['invoice','view'], ['invoice','view_all']],
            'invoices.create'       => [['invoice','add']],
            'invoices.update'       => [['invoice','edit'], ['invoice','penalty']],
            'invoices.delete'       => [['invoice','delete']],
            'invoice.penalty'       => [['invoice','penalty']],
            // Sản phẩm
            'products.read'         => [['product','view']],
            'products.create'       => [['product','add']],
            'products.update'       => [['product','edit']],
            'products.delete'       => [['product','delete']],
            // Dịch vụ
            'services.read'         => [['service','view']],
            'services.create'       => [['service','add']],
            'services.update'       => [['service','edit']],
            'services.delete'       => [['service','delete']],
            // Nhân viên
            'staff.read'            => [['staff','view']],
            'staff.create'          => [['staff','add']],
            'staff.update'          => [['staff','edit']],
            'staff.delete'          => [['staff','delete']],
            'staff.update_status'   => [['staff','update_status']],
            // Vai trò [MỚI]
            'role.read'             => [['role','view']],
            'role.create'           => [['role','add']],
            'role.update'           => [['role','edit']],
            'role.delete'           => [['role','delete']],
            // KPI
            'kpi.read'              => [['kpi','view']],
            'kpi.config'            => [['kpi','set'], ['kpi','add'], ['kpi','edit']],
            'kpi.evaluate'          => [['kpi','evaluate']],
            'kpi.delete'            => [['kpi','delete']],
            'kpi.reset'             => [['kpi','reset']],
            // Lương
            'salary.read'           => [['salary','view']],
            'salary.calculate'      => [['salary','calculate']],
            'salary.confirm'        => [['salary','confirm']],
            'salary.payment'        => [['salary','payment']],
            'salary.notify'         => [['salary','notify']],
            // Booking
            'booking.read'          => [['booking','view_personal'], ['booking','view_all']],
            'booking.view_personal' => [['booking','view_personal']],
            'booking.view_all'      => [['booking','view_all']],
            'booking.create'        => [['booking','add']],
            'booking.update'        => [['booking','edit']],
            'booking.delete'        => [['booking','delete']],
            'booking.resend'        => [['booking','resend']],
            'booking.config'        => [['booking','config']],
            // Lịch làm việc [MỚI]
            'schedule.read'         => [['schedule','view']],
            'schedule.manage'       => [['schedule','manage'], ['schedule','add'], ['schedule','edit'], ['schedule','delete']],
            // Chấm công [MỚI]
            'checkin.record'        => [['checkin','record']],
            'checkin.view'          => [['checkin','view']],
            'checkin.view_all'      => [['checkin','view_all']],
            // Nghỉ phép [MỚI]
            'leave.read'            => [['leave','view']],
            'leave.request'         => [['leave','request']],
            'leave.approve'         => [['leave','approve']],
            // Ca làm việc [MỚI]
            'shift.read'            => [['shift','view']],
            'shift.create'          => [['shift','add']],
            'shift.update'          => [['shift','edit']],
            'shift.delete'          => [['shift','delete']],
            // Chi nhánh [MỚI]
            'location.read'         => [['location','view']],
            'location.create'       => [['location','add']],
            'location.update'       => [['location','edit']],
            'location.delete'       => [['location','delete']],
            // Khách hàng [MỚI]
            'customer.read'         => [['customer','view']],
            'customer.create'       => [['customer','add']],
            'customer.update'       => [['customer','edit']],
            'customer.delete'       => [['customer','delete']],
            // Thanh toán [MỚI]
            'payment.read'          => [['payment','view']],
            'payment.process'       => [['payment','process']],
            // Phạt/Truy thu [MỚI]
            'penalty.read'          => [['penalty','view']],
            'penalty.update'        => [['penalty','edit']],
            // Đánh giá [MỚI]
            'review.read'           => [['review','view']],
            'review.moderate'       => [['review','moderate']],
            // Phase 5 Session 2 Scopes [MỚI - 2024]
            // Cài đặt hệ thống
            'settings.read'         => [['settings','view']],
            'settings.update'       => [['settings','edit']],
            // Chương trình khuyến mãi
            'promotion.read'        => [['promotion','view']],
            'promotion.create'      => [['promotion','add']],
            'promotion.update'      => [['promotion','edit']],
            'promotion.delete'      => [['promotion','delete']],
            // Kho hàng
            'inventory.read'        => [['inventory','view']],
            'inventory.check'       => [['inventory','check']],
            'inventory.transaction' => [['inventory','transaction']],
            'inventory.approve'     => [['inventory','approve']],
            'inventory.update'      => [['inventory','edit']],
            'inventory.delete'      => [['inventory','delete']],
            // Nhóm sản phẩm
            'product_group.read'    => [['product_group','view']],
            'product_group.create'  => [['product_group','add']],
            'product_group.update'  => [['product_group','edit']],
            'product_group.delete'  => [['product_group','delete']],
            // Nhóm dịch vụ
            'service_group.read'    => [['service_group','view']],
            'service_group.create'  => [['service_group','add']],
            'service_group.update'  => [['service_group','edit']],
            'service_group.delete'  => [['service_group','delete']],
            // Cấp bậc lương
            'salary_level.read'     => [['salary_level','view']],
            'salary_level.create'   => [['salary_level','add']],
            'salary_level.update'   => [['salary_level','edit']],
            'salary_level.delete'   => [['salary_level','delete']],
            // Cấp bậc nhân viên
            'staff_level.read'      => [['staff_level','view']],
            'staff_level.create'    => [['staff_level','add']],
            'staff_level.update'    => [['staff_level','edit']],
            'staff_level.delete'    => [['staff_level','delete']],
            // Cài đặt
            'zalo.config'           => [['zalo','config']],
            'dashboard.view'        => [['dashboard','view']],
            'location.set'          => [['location','set']],
            'shift.set'             => [['shift','set']],
            // Đơn xin phép [MỚI - 2025] - module trong DB là approval_request
            'approval.create'       => [['approval_request','add']],
            'approval.read'         => [['approval_request','view']],
            'approval.approve'      => [['approval_request','approve']],
            // Quyền "Duyệt đơn" bao hàm cả từ chối — các role cũ chỉ lưu action 'approve'
            'approval.reject'       => [['approval_request','reject'], ['approval_request','approve']],
            'approval.delete'       => [['approval_request','delete']],
        ];

        if (isset($alias[$scope])) return $alias[$scope];

        if (strpos($scope, '.') !== false) {
            [$m,$a] = explode('.', $scope, 2);
            $m      = strtolower(trim($m));
            $a      = strtolower(trim($a));
            return [[ $m, $a ]];
        }

        $map_action = [ 'read' => 'view', 'create' => 'add', 'update' => 'edit', 'delete' => 'delete' ];
        if (preg_match('/^([a-z_]+)\.(read|create|update|delete)$/i', $scope, $m)) {
            $module                                  = strtolower($m[1]);
            $action                                  = $map_action[strtolower($m[2])];
            if (substr($module, -1) === 's') $module = substr($module, 0, -1);
            return [[ $module, $action ]];
        }

        return [];
    }
}

if (!function_exists('checkin_mkt192_role_has_scope')) {
    function checkin_mkt192_role_has_scope($role_name, $scope) {
        global $wpdb;
        static $cache = [];

        if (!isset($cache[$role_name])) {
            $row = $wpdb->get_row($wpdb->prepare(
                "SELECT access_permissions, permissions FROM {$wpdb->prefix}checkin_mkt192_staff_roles WHERE role_name = %s LIMIT 1",
                $role_name
            ));
            $access = [];
            $perms  = [];
            $found  = false;
            if ($row) {
                $found = true;
                if (!empty($row->access_permissions)) {
                    $decoded                        = json_decode($row->access_permissions, true);
                    if (is_array($decoded)) $access = $decoded;
                }
                if (!empty($row->permissions)) {
                    $decoded_perm                       = json_decode($row->permissions, true);
                    if (is_array($decoded_perm)) $perms = $decoded_perm;
                }
            }
            $cache[$role_name] = [ 'access' => $access, 'perms' => $perms, 'found' => $found ];
        }

        $access = $cache[$role_name]['access'];
        $perms  = $cache[$role_name]['perms'];
        $found  = $cache[$role_name]['found'];

        // === 1. Kiểm tra access_permissions trước (cấp độ APP access) ===
        // Các module cần access 'app_tho' trong access_permissions
        $modules_need_app_tho = ['customer', 'booking', 'invoice'];

        if (!empty($access) && is_array($access)) {
            // Kiểm tra scope có liên quan đến module nào
            $scope_parts  = explode('.', $scope);
            $scope_module = strtolower($scope_parts[0]);

            // Nếu là module cần app_tho, phải có 'app_tho' trong access_permissions
            if (in_array($scope_module, $modules_need_app_tho, true)) {
                if (!in_array('app_tho', $access, true) && !in_array('all', $access, true) && !in_array('*', $access, true)) {
                    // Không có app_tho access -> từ chối
                    return false;
                }
            }
        }

        // === 2. Ưu tiên permissions (module→actions) ===
        if (!empty($perms)) {
            $candidates = checkin_mkt192_scope_to_permission_candidates($scope);
            foreach ($candidates as $pair) {
                [$module, $action] = $pair;
                if ($action === '*') {
                    if (isset($perms[$module]) && !empty($perms[$module])) {
                        return true;
                    }
                } else {
                    if (isset($perms[$module]) && is_array($perms[$module]) && in_array($action, $perms[$module], true)) {
                        return true;
                    }
                }
            }
        }

        // === 3. Hỗ trợ access_permissions (map/array) ===
        if (!empty($access)) {
            if (is_array($access) && checkin_mkt192_is_assoc_array($access)) {
                if (!empty($access['*']) || !empty($access['all'])) {
                    return true;
                }
                if (isset($access[$scope]) && $access[$scope]) {
                    return true;
                }
                $parts = explode('.', $scope);
                while (count($parts) > 1) {
                    array_pop($parts);
                    $prefix = implode('.', $parts) . '.*';
                    if (isset($access[$prefix]) && $access[$prefix]) {
                        return true;
                    }
                }
            } elseif (is_array($access)) {
                if (in_array('*', $access, true) || in_array('all', $access, true)) {
                    return true;
                }
                if (in_array($scope, $access, true)) {
                    return true;
                }
            }
        }

        // Mặc định: nếu có cấu hình role trong DB nhưng không match scope -> từ chối.
        // Nếu KHÔNG có bản ghi role trong DB (chưa cấu hình) -> cho qua để không phá vỡ hiện trạng.
        return $found ? false : true;
    }
}

/**
 * Kiểm tra user có access permission (page-level) hay không
 *
 * @param string $access_key 'admin', 'app_tho', 'diem_danh', 'profile'
 * @return bool
 */
if (!function_exists('checkin_mkt192_has_page_access')) {
    function checkin_mkt192_has_page_access($access_key) {
        global $wpdb;

        // Public pages - luôn cho phép
        $public_pages = ['customer_preview', 'customer_member', 'home'];
        if (in_array($access_key, $public_pages, true)) {
            return true;
        }

        // Chưa login -> deny
        if (!is_user_logged_in()) {
            return false;
        }

        // Lấy vai trò hiện tại
        $current_role = checkin_mkt192_get_current_staff_role();
        if (!$current_role) {
            return false;
        }

        // Lấy access_permissions từ DB
        $table = $wpdb->prefix . 'checkin_mkt192_staff_roles';
        $row   = $wpdb->get_row($wpdb->prepare(
            "SELECT access_permissions FROM $table WHERE role_name = %s LIMIT 1",
            $current_role
        ));

        if (!$row || empty($row->access_permissions)) {
            // Chưa cấu hình -> cho qua (backward compatible)
            return true;
        }

        $access_permissions = json_decode($row->access_permissions, true);
        if (!is_array($access_permissions)) {
            return true;
        }

        // Kiểm tra có access_key trong mảng không
        return in_array($access_key, $access_permissions, true);
    }
}

?>
