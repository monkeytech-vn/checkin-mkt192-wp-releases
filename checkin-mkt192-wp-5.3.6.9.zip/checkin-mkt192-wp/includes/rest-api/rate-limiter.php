<?php

/**
 * Rate Limiting Helper for REST API
 *
 * Prevents API abuse by limiting request frequency
 *
 * @package Checkin_MKT192_WP
 * @since 5.1.7.4.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Check rate limit for a specific action
 *
 * @param string $action Action identifier (e.g., 'booking', 'check-customer')
 * @param int $limit Max requests allowed
 * @param int $window Time window in seconds
 * @param string $identifier Optional custom identifier (defaults to IP)
 * @return bool|WP_Error True if allowed, WP_Error if rate limited
 */
function checkin_mkt192_check_rate_limit($action, $limit = 30, $window = 60, $identifier = null) {
    // Get identifier (IP address by default)
    if ($identifier === null) {
        $identifier = checkin_mkt192_get_client_ip();
    }

    // Create unique key for this action + identifier
    $transient_key = 'rate_limit_' . md5($action . '_' . $identifier);

    // Get current count
    $data = get_transient($transient_key);

    if ($data === false) {
        // First request, initialize counter
        set_transient($transient_key, [
            'count' => 1,
            'start' => time()
        ], $window);
        return true;
    }

    // Check if within limit
    if ($data['count'] >= $limit) {
        $remaining_time = $window - (time() - $data['start']);

        // Log rate limit hit
        error_log("[RATE_LIMIT] Action: $action, IP: $identifier, Limit: $limit/$window sec");

        return new WP_Error(
            'rate_limit_exceeded',
            sprintf('Quá nhiều yêu cầu. Vui lòng thử lại sau %d giây.', max(1, $remaining_time)),
            ['status' => 429, 'retry_after' => $remaining_time]
        );
    }

    // Increment counter
    $data['count']++;
    set_transient($transient_key, $data, $window - (time() - $data['start']));

    return true;
}

/**
 * Get client IP address
 *
 * @return string IP address
 */
function checkin_mkt192_get_client_ip() {
    $ip_keys = [
        'HTTP_CF_CONNECTING_IP',  // Cloudflare
        'HTTP_X_FORWARDED_FOR',   // Proxy
        'HTTP_X_REAL_IP',         // Nginx
        'REMOTE_ADDR'             // Direct
    ];

    foreach ($ip_keys as $key) {
        if (!empty($_SERVER[$key])) {
            $ip = $_SERVER[$key];
            // Handle comma-separated IPs (X-Forwarded-For)
            if (strpos($ip, ',') !== false) {
                $ip = trim(explode(',', $ip)[0]);
            }
            // Validate IP
            if (filter_var($ip, FILTER_VALIDATE_IP)) {
                return $ip;
            }
        }
    }

    return '0.0.0.0';
}

/**
 * Rate limit configurations for different endpoints
 */
function checkin_mkt192_get_rate_limits() {
    return apply_filters('checkin_mkt192_rate_limits', [
        // Public endpoints - more strict
        'booking_create'     => ['limit' => 10, 'window' => 60],   // 10 bookings/minute
        'booking_check'      => ['limit' => 30, 'window' => 60],   // 30 checks/minute
        'customer_check'     => ['limit' => 30, 'window' => 60],   // 30 checks/minute
        'login_attempt'      => ['limit' => 5,  'window' => 300],  // 5 attempts/5 min
        'password_reset'     => ['limit' => 3,  'window' => 3600], // 3 resets/hour

        // Authenticated endpoints - less strict
        'api_general'        => ['limit' => 100, 'window' => 60],  // 100 requests/minute
        'export_data'        => ['limit' => 5,   'window' => 60],  // 5 exports/minute
        'bulk_operation'     => ['limit' => 10,  'window' => 60],  // 10 bulk ops/minute
    ]);
}

/**
 * Apply rate limiting to a request
 *
 * @param string $action Action type from rate limit config
 * @return bool|WP_Error
 */
function checkin_mkt192_apply_rate_limit($action) {
    $limits = checkin_mkt192_get_rate_limits();

    if (!isset($limits[$action])) {
        // Default limit
        $limit  = 60;
        $window = 60;
    } else {
        $limit  = $limits[$action]['limit'];
        $window = $limits[$action]['window'];
    }

    return checkin_mkt192_check_rate_limit($action, $limit, $window);
}