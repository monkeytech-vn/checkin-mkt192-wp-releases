<?php

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class quản lý kích hoạt plugin và tạo bảng cơ sở dữ liệu.
 */
class Checkin_MKT192_Activation {
    /**
     * Instance của class (Singleton pattern).
     *
     * @var Checkin_MKT192_Activation
     */
    private static $instance = null;

    /**
     * Lấy instance của class.
     *
     * @return Checkin_MKT192_Activation
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor.
     */
    private function __construct() {
        // Không cần hook ở đây vì activation hook được đăng ký trong file chính
    }

    /**
     * Tạo tất cả các bảng cơ sở dữ liệu khi plugin được kích hoạt.
     */
    public static function create_tables() {
        self::create_booking_data_table();
        self::create_customer_data_table();
        // Bảng leave_requests cũ đã được thay thế bởi approval_requests
        self::create_product_tables();
        self::create_inventory_transaction_table();
        self::create_inventory_checks_table();
        self::create_special_days_table();
        // DEPRECATED: Bảng advance_salary cũ đã được thay thế bởi approval_requests
        self::create_cashier_salary_table();
        self::create_hairdresser_salary_table();
        self::create_checkinlogs_table();
        self::create_ctkm_settings_table();
        self::create_customer_reviews_off_table();
        self::create_customer_reviews_online_table();
        self::create_invoices_data_table();
        self::create_invoices_data_detail_table();
        self::create_kpi_settings_table();
        self::create_kpi_results_table();
        // DEPRECATED: Bảng late_requests cũ đã được thay thế bởi approval_requests
        self::create_locations_table();
        self::create_message_bot_settings_table();
        self::create_penalty_settings_table();
        self::create_pending_reviews_table();
        self::create_promo_settings_table();
        self::create_salary_level_settings_table();
        self::create_salary_period_rates_table();
        self::create_salary_adjustments_table();
        self::create_service_groups_table();
        self::create_service_data_table();
        self::create_shiftsettings_table();
        self::create_staff_table();
        self::create_staff_roles_table();
        self::create_staff_level_history_table();
        self::create_social_posts_table();
        self::create_image_feedback_table();
        self::create_zalo_config_table();
        self::create_manager_schedules_table();
        self::create_approval_requests_table();
        self::create_push_subscriptions_table();
        self::create_notifications_table();
        self::create_notification_views_table();
        self::create_cash_shift_tables();
        self::create_onesignal_service_worker();
        self::create_wordpress_roles();

        // Run migrations after tables are created
        self::run_migrations();
    }

    /**
     * Chạy các migrations để cập nhật cấu trúc bảng.
     * Được gọi sau khi tạo bảng để đảm bảo các cột mới được thêm.
     */
    public static function run_migrations() {
        global $wpdb;

        // =====================================================================
        // MIGRATION: Rename bảng cũ sang tên mới (backward compatibility)
        // =====================================================================
        self::migrate_legacy_notification_tables();

        // =====================================================================
        // MIGRATION: ZNS → ZBS (Zalo rebranding)
        // =====================================================================
        self::migrate_zns_to_zbs_options();
        self::migrate_zns_to_zbs_db_values();

        // Migration cho bảng notifications: thêm cột aspect_ratio
        $notifications_table = $wpdb->prefix . 'checkin_mkt192_notifications';
        if ($wpdb->get_var("SHOW TABLES LIKE '$notifications_table'") === $notifications_table) {
            $column_exists = $wpdb->get_results("SHOW COLUMNS FROM $notifications_table LIKE 'aspect_ratio'");
            if (empty($column_exists)) {
                $wpdb->query("ALTER TABLE $notifications_table ADD COLUMN aspect_ratio varchar(10) DEFAULT '16:9' AFTER media_type");
            }

            // Migration: thêm cột sort_order
            $column_exists = $wpdb->get_results("SHOW COLUMNS FROM $notifications_table LIKE 'sort_order'");
            if (empty($column_exists)) {
                $wpdb->query("ALTER TABLE $notifications_table ADD COLUMN sort_order int(11) DEFAULT 0 AFTER end_date");
                error_log("Checkin MKT192: Added sort_order column to $notifications_table");
            }

            // Migration: thêm cột slide_duration
            $column_exists = $wpdb->get_results("SHOW COLUMNS FROM $notifications_table LIKE 'slide_duration'");
            if (empty($column_exists)) {
                $wpdb->query("ALTER TABLE $notifications_table ADD COLUMN slide_duration int(11) DEFAULT 5 AFTER sort_order");
                error_log("Checkin MKT192: Added slide_duration column to $notifications_table");
            }
        }

        // Migration cho bảng hairdresser_salary: ảnh chụp thẻ hoa hồng đã áp (rates_json)
        $hairdresser_salary_table = $wpdb->prefix . 'checkin_mkt192_hairdresser_salary';
        if ($wpdb->get_var("SHOW TABLES LIKE '$hairdresser_salary_table'") === $hairdresser_salary_table) {
            $column_exists = $wpdb->get_results("SHOW COLUMNS FROM $hairdresser_salary_table LIKE 'rates_json'");
            if (empty($column_exists)) {
                $wpdb->query("ALTER TABLE $hairdresser_salary_table ADD COLUMN rates_json LONGTEXT DEFAULT NULL AFTER working_days");
                error_log("Checkin MKT192: Added rates_json column to $hairdresser_salary_table");
            }
        }

        // Migration 8.8.0: salary_adjustments.kind VARCHAR(10) → VARCHAR(20) để chứa 'base_penalty' (truy thu % trừ doanh số DV/HC)
        $adj_table = $wpdb->prefix . 'checkin_mkt192_salary_adjustments';
        if ($wpdb->get_var("SHOW TABLES LIKE '$adj_table'") === $adj_table) {
            $kind_col = $wpdb->get_row("SHOW COLUMNS FROM $adj_table LIKE 'kind'");
            if ($kind_col && stripos($kind_col->Type, 'varchar(10)') !== false) {
                $wpdb->query("ALTER TABLE $adj_table MODIFY kind VARCHAR(20) NOT NULL DEFAULT 'bonus'");
            }
        }

        // Migration: salary_period_rates.kpi_penalty_mode (trừ 1 lần / cộng dồn theo số KPI trượt)
        $rates_table = $wpdb->prefix . 'checkin_mkt192_salary_period_rates';
        if ($wpdb->get_var("SHOW TABLES LIKE '$rates_table'") === $rates_table) {
            $column_exists = $wpdb->get_results("SHOW COLUMNS FROM $rates_table LIKE 'kpi_penalty_mode'");
            if (empty($column_exists)) {
                $wpdb->query("ALTER TABLE $rates_table ADD COLUMN kpi_penalty_mode VARCHAR(10) NOT NULL DEFAULT 'once' AFTER kpi_penalty_scope");
            }
        }

        // Migration: kpi_results — số thực tế từng KPI + ghi đè tay của admin + cách tính đăng bài + số ngày công (8.7.0)
        $kpi_table = $wpdb->prefix . 'checkin_mkt192_kpi_results';
        if ($wpdb->get_var("SHOW TABLES LIKE '$kpi_table'") === $kpi_table) {
            foreach (['service_actual' => 'BIGINT(20) DEFAULT NULL', 'product_actual' => 'DECIMAL(15,2) DEFAULT NULL', 'post_fb_actual' => 'INT(11) DEFAULT NULL', 'post_fb_required' => 'INT(11) DEFAULT NULL', 'feedback_actual' => 'INT(11) DEFAULT NULL', 'manual_json' => 'LONGTEXT DEFAULT NULL', 'post_fb_mode' => 'VARCHAR(10) DEFAULT NULL', 'working_days' => 'INT(11) DEFAULT NULL'] as $col => $def) {
                if (empty($wpdb->get_results("SHOW COLUMNS FROM $kpi_table LIKE '$col'"))) {
                    $wpdb->query("ALTER TABLE $kpi_table ADD COLUMN $col $def");
                }
            }
        }

        // Migration 8.7.0: kpi_settings.post_fb_mode — cách tính KPI đăng bài FB: 'count' (số bài cố định) | 'workdays' (N bài mỗi ngày công).
        // Dữ liệu cũ chạy theo luật "KPI/tháng quy theo ngày công/30" (30 bài/tháng ≈ 1 bài/ngày công) → chuyển sang
        // 'workdays' với mục tiêu = round(kpi/30) bài/ngày công (tối thiểu 1) để kết quả đánh giá KHÔNG đổi. Cờ riêng, chạy một lần.
        $kpi_settings_table = $wpdb->prefix . 'checkin_mkt192_kpi_settings';
        if ($wpdb->get_var("SHOW TABLES LIKE '$kpi_settings_table'") === $kpi_settings_table) {
            if (empty($wpdb->get_results("SHOW COLUMNS FROM $kpi_settings_table LIKE 'post_fb_mode'"))) {
                $wpdb->query("ALTER TABLE $kpi_settings_table ADD COLUMN post_fb_mode VARCHAR(10) NOT NULL DEFAULT 'count' AFTER post_fb_kpi");
            }
            if (!get_option('checkin_mkt192_kpi_postfb_workdays_migrated')) {
                $moved = $wpdb->query("UPDATE $kpi_settings_table SET post_fb_mode = 'workdays', post_fb_kpi = GREATEST(1, ROUND(post_fb_kpi / 30)) WHERE post_fb_kpi > 0 AND post_fb_mode = 'count'");
                update_option('checkin_mkt192_kpi_postfb_workdays_migrated', ['at' => current_time('mysql'), 'rows' => (int)$moved], false);
                error_log("Checkin MKT192: KPI post FB → workdays mode, rows: " . (int)$moved);
            }
        }

        // Migration: staff_level_history.legacy_level_name (tên bậc cũ trước khi gom về 4 hạng Barber)
        $history_table = $wpdb->prefix . 'checkin_mkt192_staff_level_history';
        if ($wpdb->get_var("SHOW TABLES LIKE '$history_table'") === $history_table) {
            $column_exists = $wpdb->get_results("SHOW COLUMNS FROM $history_table LIKE 'legacy_level_name'");
            if (empty($column_exists)) {
                $wpdb->query("ALTER TABLE $history_table ADD COLUMN legacy_level_name VARCHAR(100) DEFAULT NULL AFTER level_name");
            }
        }

        // Migration: adjustments_json (ảnh chụp phiếu thưởng/trừ) cho 2 bảng lương
        foreach (['checkin_mkt192_hairdresser_salary', 'checkin_mkt192_cashier_salary'] as $salary_table) {
            $salary_table = $wpdb->prefix . $salary_table;
            if ($wpdb->get_var("SHOW TABLES LIKE '$salary_table'") === $salary_table) {
                $column_exists = $wpdb->get_results("SHOW COLUMNS FROM $salary_table LIKE 'adjustments_json'");
                if (empty($column_exists)) {
                    $wpdb->query("ALTER TABLE $salary_table ADD COLUMN adjustments_json LONGTEXT DEFAULT NULL");
                    error_log("Checkin MKT192: Added adjustments_json column to $salary_table");
                }
            }
        }

        // Migration cho bảng cash_shifts: thêm cột opening_transfer_balance
        $shifts_table = $wpdb->prefix . 'checkin_mkt192_cash_shifts';
        if ($wpdb->get_var("SHOW TABLES LIKE '$shifts_table'") === $shifts_table) {
            $column_exists = $wpdb->get_results("SHOW COLUMNS FROM $shifts_table LIKE 'opening_transfer_balance'");
            if (empty($column_exists)) {
                $wpdb->query("ALTER TABLE $shifts_table ADD COLUMN opening_transfer_balance DECIMAL(15,0) NOT NULL DEFAULT 0 AFTER opening_balance");
            }

            // Thêm cột sales_start_time
            $column_exists = $wpdb->get_results("SHOW COLUMNS FROM $shifts_table LIKE 'sales_start_time'");
            if (empty($column_exists)) {
                $wpdb->query("ALTER TABLE $shifts_table ADD COLUMN sales_start_time DATETIME DEFAULT NULL AFTER start_time");
            }
        }

        // Migration cho bảng cash_transactions: thêm cột branch_id
        $transactions_table = $wpdb->prefix . 'checkin_mkt192_cash_transactions';
        if ($wpdb->get_var("SHOW TABLES LIKE '$transactions_table'") === $transactions_table) {
            $column_exists = $wpdb->get_results("SHOW COLUMNS FROM $transactions_table LIKE 'branch_id'");
            if (empty($column_exists)) {
                $wpdb->query("ALTER TABLE $transactions_table ADD COLUMN branch_id BIGINT(20) UNSIGNED DEFAULT 0 AFTER shift_id");
                $wpdb->query("ALTER TABLE $transactions_table ADD KEY idx_branch_id (branch_id)");
            }
        }

        // Migration cho bảng customers: thêm cột zalo_social_id (Zalo Social Login)
        $customer_table = $wpdb->prefix . 'bookingmkt192_customer_data';
        if ($wpdb->get_var("SHOW TABLES LIKE '$customer_table'") === $customer_table) {
            $column_exists = $wpdb->get_results("SHOW COLUMNS FROM $customer_table LIKE 'zalo_social_id'");
            if (empty($column_exists)) {
                $wpdb->query("ALTER TABLE $customer_table ADD COLUMN zalo_social_id VARCHAR(100) DEFAULT NULL AFTER id_zalo");
                $wpdb->query("ALTER TABLE $customer_table ADD KEY idx_zalo_social_id (zalo_social_id)");
                error_log("Checkin MKT192: Added zalo_social_id column to $customer_table");
            }
        }

        // Migration cho bảng staff: cột SĐT thợ. Thợ ở trạng thái PAUSE (tạm dừng)
        // vẫn hiện ở trang chủ và nhận đặt lịch, kèm SĐT để khách gọi trực tiếp.
        $staff_table = $wpdb->prefix . 'checkin_mkt192_staff';
        if ($wpdb->get_var("SHOW TABLES LIKE '$staff_table'") === $staff_table) {
            $col = $wpdb->get_results("SHOW COLUMNS FROM $staff_table LIKE 'phone'");
            if (empty($col)) {
                $wpdb->query(
                    "ALTER TABLE $staff_table
                     ADD COLUMN phone VARCHAR(30) DEFAULT ''
                     COMMENT 'SĐT thợ — hiện ở trang chủ khi thợ đang tạm dừng' AFTER status"
                );
                error_log("Checkin MKT192: Added phone column to $staff_table");
            }
        }

        // Migration cho bảng invoices_data: thêm cột đối soát (reconcile)
        $invoice_table = $wpdb->prefix . 'checkin_mkt192_invoices_data';
        if ($wpdb->get_var("SHOW TABLES LIKE '$invoice_table'") === $invoice_table) {
            // reconcile_status: matched / unmatched / NULL (chưa kiểm)
            $col = $wpdb->get_results("SHOW COLUMNS FROM $invoice_table LIKE 'reconcile_status'");
            if (empty($col)) {
                $wpdb->query("ALTER TABLE $invoice_table ADD COLUMN reconcile_status VARCHAR(20) DEFAULT NULL COMMENT 'Trạng thái đối soát: matched/unmatched' AFTER status");
                error_log("Checkin MKT192: Added reconcile_status column to $invoice_table");
            }
            // reconcile_at: thời điểm đối soát
            $col = $wpdb->get_results("SHOW COLUMNS FROM $invoice_table LIKE 'reconcile_at'");
            if (empty($col)) {
                $wpdb->query("ALTER TABLE $invoice_table ADD COLUMN reconcile_at DATETIME DEFAULT NULL COMMENT 'Thời điểm đối soát gần nhất' AFTER reconcile_status");
                error_log("Checkin MKT192: Added reconcile_at column to $invoice_table");
            }
            // reconcile_tx_ref: mã giao dịch ngân hàng đã khớp
            $col = $wpdb->get_results("SHOW COLUMNS FROM $invoice_table LIKE 'reconcile_tx_ref'");
            if (empty($col)) {
                $wpdb->query("ALTER TABLE $invoice_table ADD COLUMN reconcile_tx_ref VARCHAR(100) DEFAULT NULL COMMENT 'Mã tham chiếu giao dịch ngân hàng' AFTER reconcile_at");
                error_log("Checkin MKT192: Added reconcile_tx_ref column to $invoice_table");
            }
        }
    }

    /**
     * Migrate bảng notifications từ tên cũ sang tên mới.
     * Xử lý các trường hợp:
     * 1. Bảng cũ tồn tại, bảng mới chưa có → RENAME
     * 2. Cả 2 đều tồn tại → Copy dữ liệu từ cũ sang mới, xóa bảng cũ
     * 3. Chỉ có bảng mới → Không làm gì
     */
    private static function migrate_legacy_notification_tables() {
        global $wpdb;

        // Định nghĩa mapping bảng cũ → mới
        $table_mappings = [
            'checkin_notifications'       => 'checkin_mkt192_notifications',
            'checkin_notification_views'  => 'checkin_mkt192_notification_views',
        ];

        foreach ($table_mappings as $old_suffix => $new_suffix) {
            $old_table = $wpdb->prefix . $old_suffix;
            $new_table = $wpdb->prefix . $new_suffix;

            $old_exists = $wpdb->get_var("SHOW TABLES LIKE '$old_table'") === $old_table;
            $new_exists = $wpdb->get_var("SHOW TABLES LIKE '$new_table'") === $new_table;

            if ($old_exists && !$new_exists) {
                // Trường hợp 1: Bảng cũ tồn tại, bảng mới chưa có → RENAME
                $wpdb->query("RENAME TABLE `$old_table` TO `$new_table`");
                error_log("Checkin MKT192: Renamed table $old_table to $new_table");

            } elseif ($old_exists && $new_exists) {
                // Trường hợp 2: Cả 2 đều tồn tại → Copy dữ liệu rồi xóa bảng cũ
                // Chỉ copy nếu bảng mới trống
                $new_count = (int) $wpdb->get_var("SELECT COUNT(*) FROM $new_table");
                $old_count = (int) $wpdb->get_var("SELECT COUNT(*) FROM $old_table");

                if ($new_count === 0 && $old_count > 0) {
                    // Copy dữ liệu từ bảng cũ sang bảng mới
                    $wpdb->query("INSERT INTO $new_table SELECT * FROM $old_table");
                    error_log("Checkin MKT192: Copied $old_count rows from $old_table to $new_table");
                }

                // Xóa bảng cũ sau khi migrate
                $wpdb->query("DROP TABLE IF EXISTS `$old_table`");
                error_log("Checkin MKT192: Dropped legacy table $old_table");
            }
            // Trường hợp 3: Chỉ có bảng mới → Không làm gì
        }
    }

    /**
     * Migrate WP option keys từ ZNS → ZBS.
     * Khi reactivate hoặc update: nếu option cũ tồn tại → copy sang key mới, xóa key cũ.
     */
    private static function migrate_zns_to_zbs_options() {
        $option_mappings = [
            'checkin_zns_template_booking'          => 'checkin_zbs_template_booking',
            'checkin_zns_template_cancel_booking'   => 'checkin_zbs_template_cancel_booking',
            'checkin_zns_template_booking_reminder' => 'checkin_zbs_template_booking_reminder',
            'checkin_zns_template_invoice'          => 'checkin_zbs_template_invoice',
        ];

        foreach ($option_mappings as $old_key => $new_key) {
            $old_value = get_option($old_key);
            if ($old_value !== false) {
                // Chỉ migrate nếu key mới chưa có giá trị
                $new_value = get_option($new_key);
                if ($new_value === false || $new_value === '') {
                    update_option($new_key, $old_value);
                    error_log("Checkin MKT192: Migrated option $old_key → $new_key (value: $old_value)");
                }
                // Xóa option cũ
                delete_option($old_key);
                error_log("Checkin MKT192: Deleted legacy option $old_key");
            }
        }
    }

    /**
     * Migrate DB values từ 'zns' → 'zbs' trong các cột message_type.
     * Cập nhật booking_data và invoices_data.
     */
    private static function migrate_zns_to_zbs_db_values() {
        global $wpdb;

        // Bảng booking_data
        $booking_table = $wpdb->prefix . 'bookingmkt192_booking_data';
        if ($wpdb->get_var("SHOW TABLES LIKE '$booking_table'") === $booking_table) {
            $updated = $wpdb->query("UPDATE $booking_table SET message_type = 'zbs' WHERE message_type = 'zns'");
            if ($updated > 0) error_log("Checkin MKT192: Updated $updated booking rows message_type zns → zbs");

            $updated = $wpdb->query("UPDATE $booking_table SET reminder_message_type = 'zbs' WHERE reminder_message_type = 'zns'");
            if ($updated > 0) error_log("Checkin MKT192: Updated $updated booking rows reminder_message_type zns → zbs");

            $updated = $wpdb->query("UPDATE $booking_table SET cancel_message_type = 'zbs' WHERE cancel_message_type = 'zns'");
            if ($updated > 0) error_log("Checkin MKT192: Updated $updated booking rows cancel_message_type zns → zbs");
        }

        // Bảng invoices_data
        $invoice_table = $wpdb->prefix . 'checkin_mkt192_invoices_data';
        if ($wpdb->get_var("SHOW TABLES LIKE '$invoice_table'") === $invoice_table) {
            $updated = $wpdb->query("UPDATE $invoice_table SET message_type = 'zbs' WHERE message_type = 'zns'");
            if ($updated > 0) error_log("Checkin MKT192: Updated $updated invoice rows message_type zns → zbs");
        }
    }

    /**
     * Chạy migrations khi plugin được cập nhật (không cần reactivate).
     * Sử dụng version check để tránh chạy lại mỗi lần page load.
     */
    public static function run_migrations_on_update() {
        $current_version  = '8.8.0'; // Bump version: salary_adjustments.kind VARCHAR(20) — thêm kind 'base_penalty' (truy thu trừ doanh số)
        $stored_version   = get_option('checkin_mkt192_db_version', '0');

        // Migration 4 hạng Barber chạy độc lập với version: lần đầu deploy 5.3.5.0 trên VG, OPcache còn giữ
        // salary-api.php cũ nên function_exists() = false → bị bỏ qua mà version vẫn bump. Kiểm tra cờ mỗi lần tải (option autoload).
        if (!get_option('checkin_mkt192_barber_tiers_migrated') && function_exists('checkin_mkt192_migrate_barber_tiers')) {
            checkin_mkt192_migrate_barber_tiers();
        }

        // Nếu version không thay đổi → skip
        if (version_compare($stored_version, $current_version, '>=')) {
            return;
        }

        // Chạy migrations
        self::migrate_legacy_notification_tables();

        // Đảm bảo bảng mới tồn tại (tạo nếu chưa có)
        global $wpdb;
        $notifications_table = $wpdb->prefix . 'checkin_mkt192_notifications';
        if ($wpdb->get_var("SHOW TABLES LIKE '$notifications_table'") !== $notifications_table) {
            self::create_notifications_table();
        }

        $views_table = $wpdb->prefix . 'checkin_mkt192_notification_views';
        if ($wpdb->get_var("SHOW TABLES LIKE '$views_table'") !== $views_table) {
            self::create_notification_views_table();
        }

        $shifts_table = $wpdb->prefix . 'checkin_mkt192_cash_shifts';
        if ($wpdb->get_var("SHOW TABLES LIKE '$shifts_table'") !== $shifts_table) {
            self::create_cash_shift_tables();
        }

        $rates_table = $wpdb->prefix . 'checkin_mkt192_salary_period_rates';
        if ($wpdb->get_var("SHOW TABLES LIKE '$rates_table'") !== $rates_table) {
            self::create_salary_period_rates_table();
        }

        $adjust_table = $wpdb->prefix . 'checkin_mkt192_salary_adjustments';
        if ($wpdb->get_var("SHOW TABLES LIKE '$adjust_table'") !== $adjust_table) {
            self::create_salary_adjustments_table();
        }

        // Chạy column migrations
        self::run_migrations();

        // 4 hạng Barber: đổi tên bậc thợ, giữ tên cũ, tạo thẻ hoa hồng giữ nguyên % (chạy một lần)
        if (function_exists('checkin_mkt192_migrate_barber_tiers')) {
            checkin_mkt192_migrate_barber_tiers();
        }

        // Lưu version mới
        update_option('checkin_mkt192_db_version', $current_version);
        error_log("Checkin MKT192: Database migrated to version $current_version");
    }

    /**
     * Tạo file OneSignalSDKWorker.js ở WordPress root cho Push Notifications.
     * Based on: https://documentation.onesignal.com/docs/en/web-sdk-reference
     */
    private static function create_onesignal_service_worker() {
        $worker_content = "/**\n * OneSignal Service Worker - Web SDK v16\n * https://documentation.onesignal.com/docs/en/web-sdk-reference\n */\nimportScripts('https://cdn.onesignal.com/sdks/web/v16/OneSignalSDK.sw.js');\n";

        // File cần ở WordPress root (ABSPATH)
        $worker_path = ABSPATH . 'OneSignalSDKWorker.js';

        // Chỉ tạo nếu file chưa tồn tại hoặc nội dung khác
        if (!file_exists($worker_path) || file_get_contents($worker_path) !== $worker_content) {
            $result = file_put_contents($worker_path, $worker_content);

            if ($result === false) {
                error_log('Checkin MKT192: Failed to create OneSignalSDKWorker.js at ' . $worker_path);
            } else {
                error_log('Checkin MKT192: Created OneSignalSDKWorker.js at ' . $worker_path);
            }
        }
    }

    /**
     * Tạo các role WordPress: staff và cashier nếu chưa tồn tại.
     */
    private static function create_wordpress_roles() {
        // Kiểm tra và tạo role 'staff'
        if (!get_role('staff')) {
            add_role('staff', 'Staff', [
                'read'          => true, // Có thể xem nội dung
                'edit_posts'    => false,
                'publish_posts' => false,
            ]);
        }

        // Kiểm tra và tạo role 'cashier'
        if (!get_role('cashier')) {
            add_role('cashier', 'Cashier', [
                'read'          => true,
                'edit_posts'    => false,
                'publish_posts' => false,
            ]);
        }
    }

    /**
     * Thiết lập cron job khi plugin được kích hoạt.
     */
    public static function schedule_cron() {
        $cron_events = [
            'daily_new_thread_lark'            => ['time' => 'today 23:00', 'recurrence' => 'daily'],// 6:00 sáng
            'send_booking_reminder'            => ['time' => 'today 01:00', 'recurrence' => 'every_5_minutes'],//01:00
            'stop_booking_reminder'            => ['time' => 'today 13:30', 'recurrence' => 'daily'],//13:30
            'daily_upload_image'               => ['time' => 'today 01:00', 'recurrence' => 'every_5_minutes'],//01:00
            'stop_upload_image'                => ['time' => 'today 13:30', 'recurrence' => 'daily'],//13:30
            'daily_update_promo_code'          => ['time' => 'today 02:00', 'recurrence' => 'daily'],//02:00
            'daily_missing_image_notification' => ['time' => 'today 14:30', 'recurrence' => 'daily'],//14:30
            'daily_reprocess_temp_files'       => ['time' => 'today 16:55', 'recurrence' => 'daily'],//16:55
            'daily_refresh_zalo_tokens'        => ['time' => 'today 16:55', 'recurrence' => 'daily']//16:55
        ];

        foreach ($cron_events as $hook => $config) {
            // Xóa TẤT CẢ lịch trình hiện có cho hook (tránh trùng lặp)
            $timestamps = _get_cron_array();
            if ($timestamps) {
                foreach ($timestamps as $timestamp => $cron) {
                    if (isset($cron[$hook])) {
                        foreach ($cron[$hook] as $key => $event) {
                            wp_unschedule_event($timestamp, $hook, $event['args']);
                        }
                    }
                }
            }

            // Lập lịch sự kiện mới
            $schedule_time = strtotime($config['time']);
            if ($schedule_time === false || $schedule_time < time()) {
                $schedule_time = strtotime('tomorrow ' . date('H:i', strtotime($config['time'])));
            }

            $result = wp_schedule_event($schedule_time, $config['recurrence'], $hook);

            // Log để debug
            if ($result === false) {
                error_log("Checkin MKT192: Failed to schedule $hook");
            } else {
                error_log("Checkin MKT192: Scheduled $hook at " . date('Y-m-d H:i:s', $schedule_time));
            }
        }
    }

    /**
     * Tạo bảng booking_data.
     */
    private static function create_booking_data_table() {
        global $wpdb;
        $table_name      = $wpdb->prefix . 'bookingmkt192_booking_data';
        $charset_collate = 'CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci';

        $sql = "CREATE TABLE $table_name (
            id INT(11) NOT NULL AUTO_INCREMENT,
            id_booking VARCHAR(50) NOT NULL,
            customer_phone VARCHAR(20) NOT NULL,
            customer_name VARCHAR(50) NOT NULL,
            service_name VARCHAR(100) NOT NULL,
            services LONGTEXT NOT NULL,
            hairdresser_name VARCHAR(100) NOT NULL,
            booking_date DATE NOT NULL,
            booking_time TIME NOT NULL,
            booking_images LONGTEXT DEFAULT NULL,
            status ENUM('success','pending','deleted','start') DEFAULT 'start',
            customer_note VARCHAR(100) NOT NULL,
            customer_type VARCHAR(50) NOT NULL,
            customer_count INT(11) NOT NULL DEFAULT 1,
            silent_service VARCHAR(10) NOT NULL DEFAULT 'Không',
            message_type VARCHAR(100) DEFAULT NULL,
            message_status VARCHAR(100) DEFAULT NULL,
            reminder_message_type VARCHAR(50) DEFAULT NULL,
            reminder_status VARCHAR(100) DEFAULT NULL,
            cancel_message_type VARCHAR(50) DEFAULT NULL,
            cancel_message_status VARCHAR(100) DEFAULT NULL,
            cancel_reason TEXT DEFAULT NULL COMMENT 'Lý do hủy lịch',
            branch VARCHAR(255) DEFAULT '' COMMENT 'Chi nhánh',
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY idx_branch (branch)
        ) ENGINE=InnoDB $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    /**
     * Tạo bảng customer_data.
     */
    private static function create_customer_data_table() {
        global $wpdb;
        $table_name      = $wpdb->prefix . 'bookingmkt192_customer_data';
        $charset_collate = 'CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci';

        $sql = "CREATE TABLE $table_name (
            customer_id VARCHAR(50) NOT NULL,
            customer_phone VARCHAR(20) DEFAULT NULL,
            customer_name VARCHAR(100) DEFAULT NULL,
            name_zalo VARCHAR(100) DEFAULT NULL,
            id_zalo VARCHAR(50) DEFAULT NULL,
            customer_birthday DATE DEFAULT NULL,
            customer_gender VARCHAR(20) DEFAULT NULL,
            customer_email VARCHAR(100) DEFAULT NULL,
            membership_level VARCHAR(50) DEFAULT NULL,
            follower_zalo VARCHAR(50) DEFAULT NULL,
            hairdresser_name VARCHAR(100) DEFAULT NULL,
            customer_address TEXT DEFAULT NULL,
            new_checkin DATE DEFAULT NULL,
            new_code VARCHAR(50) DEFAULT NULL,
            status_code VARCHAR(20) DEFAULT NULL,
            new_customer VARCHAR(50) DEFAULT NULL,
            branch VARCHAR(255) DEFAULT '' COMMENT 'Chi nhánh',
            created_at DATETIME DEFAULT NULL COMMENT 'Ngày giờ tạo record khách hàng',
            updated_at DATETIME DEFAULT NULL COMMENT 'Ngày giờ cập nhật gần nhất',
            date_new_member DATETIME DEFAULT NULL COMMENT 'Ngày giờ trở thành thành viên',
            PRIMARY KEY  (customer_id),
            KEY idx_customer_id (customer_id),
            KEY idx_branch (branch),
            KEY idx_created_at (created_at),
            KEY idx_date_new_member (date_new_member)
        ) ENGINE=InnoDB $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    /**
     * DEPRECATED: Bảng leave_requests cũ đã được thay thế bởi approval_requests
     * Giữ lại để tham khảo, không còn được gọi khi kích hoạt plugin
     * Bảng cũ: bookingmkt192_leave_requests
     * Bảng mới: checkin_mkt192_approval_requests (hỗ trợ tất cả loại đơn)
     */
    // private static function create_leave_requests_table() { ... }

private static function create_product_tables() {
    global $wpdb;
    $charset_collate = 'CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci';
    $table_groups    = $wpdb->prefix . 'checkin_mkt192_product_groups';
    $table_products  = $wpdb->prefix . 'checkin_mkt192_products';

    $sql_groups = "CREATE TABLE $table_groups (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        group_name VARCHAR(255) NOT NULL,
        group_code VARCHAR(50) NOT NULL,
        description TEXT,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY  (id),
        UNIQUE KEY group_code (group_code)
    ) ENGINE=InnoDB $charset_collate;";

    $sql_products = "CREATE TABLE $table_products (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        product_name VARCHAR(255) NOT NULL,
        product_group_id BIGINT(20) UNSIGNED NOT NULL,
        price DECIMAL(15,2) NOT NULL,
        branch VARCHAR(255) DEFAULT '',
        stock INT(11) NOT NULL DEFAULT 0,
        sku VARCHAR(50),
        description TEXT,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY  (id),
        UNIQUE KEY sku (sku),
        KEY idx_product_group_id (product_group_id),
        KEY idx_product_id (id),
        KEY idx_stock (stock),
        KEY idx_branch (branch)
    ) ENGINE=InnoDB $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql_groups);
    dbDelta($sql_products);

    // Thêm dữ liệu mặc định cho product_groups
    $default_groups = [
        ['Tạo kiểu (Wax)', 'WAX'],
        ['Gôm', 'GÔM'],
        ['Dầu dưỡng', 'TINH DẦU'],
        ['Sản phẩm khác', 'KHÁC'],
    ];

    foreach ($default_groups as $group) {
        $exists = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM $table_groups WHERE group_code = %s",
                $group[1]
            )
        );

        if ($exists == 0) {
            $wpdb->insert(
                $table_groups,
                [
                    'group_name' => $group[0],
                    'group_code' => $group[1],
                    'created_at' => current_time('mysql'),
                    'updated_at' => current_time('mysql'),
                ],
                ['%s', '%s', '%s', '%s']
            );
        }
    }

    // Đảm bảo FK tồn tại
    $fk_check = $wpdb->get_var("
        SELECT COUNT(*)
        FROM information_schema.TABLE_CONSTRAINTS
        WHERE CONSTRAINT_TYPE = 'FOREIGN KEY'
          AND TABLE_NAME = '$table_products'
          AND CONSTRAINT_NAME = 'fk_product_group'
          AND TABLE_SCHEMA = DATABASE()
    ");
    if ($fk_check == 0) {
        $wpdb->query("ALTER TABLE $table_products
            ADD CONSTRAINT fk_product_group
            FOREIGN KEY (product_group_id) REFERENCES $table_groups(id)
            ON DELETE RESTRICT");
    }
}

    /**
     * Tạo bảng inventory_transactions (Xuất/Nhập kho).
     */
    private static function create_inventory_transaction_table() {
        global $wpdb;
        $charset_collate    = 'CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci';
        $table_transactions = $wpdb->prefix . 'checkin_mkt192_inventory_transactions';
        $table_products     = $wpdb->prefix . 'checkin_mkt192_products';

        $sql_transactions = "CREATE TABLE $table_transactions (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            product_id BIGINT(20) UNSIGNED NOT NULL,
            product_name VARCHAR(255) NOT NULL,
            transaction_type ENUM('IN','OUT') NOT NULL,
            quantity INT(11) NOT NULL,
            transaction_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            note TEXT DEFAULT NULL,
            staff_name VARCHAR(100) NOT NULL,
            image_key LONGTEXT NOT NULL COMMENT 'Lark image key cho notification',
            image_url TEXT DEFAULT NULL COMMENT 'WordPress URL cho hiển thị',
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            transaction_id VARCHAR(50) DEFAULT NULL,
            status VARCHAR(20) DEFAULT 'CHỜ DUYỆT',
            branch_id INT(11) DEFAULT 0 COMMENT 'ID chi nhánh',
            PRIMARY KEY  (id),
            KEY idx_transaction_id (transaction_id),
            KEY idx_product_id (product_id),
            KEY idx_branch_id (branch_id)
        ) ENGINE=InnoDB $charset_collate COMMENT='Bảng lưu giao dịch xuất/nhập kho';";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql_transactions);

        // Migration: Drop UNIQUE constraint nếu tồn tại (cho các bảng cũ)
        self::fix_inventory_transaction_unique_constraint();

        $fk_check = $wpdb->get_var("SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS WHERE CONSTRAINT_TYPE = 'FOREIGN KEY' AND TABLE_NAME = '$table_transactions' AND CONSTRAINT_NAME = 'fk_product'");
        if ($fk_check == 0) {
            $wpdb->query("ALTER TABLE $table_transactions ADD CONSTRAINT fk_product FOREIGN KEY (product_id) REFERENCES $table_products(id) ON DELETE RESTRICT");
        }
    }

    /**
     * Fix UNIQUE constraint trên transaction_id trong bảng inventory_transactions.
     * Vấn đề: Mỗi phiếu xuất/nhập kho có thể chứa nhiều sản phẩm,
     * tất cả dùng chung 1 transaction_id. UNIQUE constraint gây lỗi duplicate key.
     */
    private static function fix_inventory_transaction_unique_constraint() {
        global $wpdb;
        $table_transactions = $wpdb->prefix . 'checkin_mkt192_inventory_transactions';

        // 1. Kiểm tra và xóa UNIQUE KEY 'transaction_id' (cũ - chỉ trên 1 cột)
        $unique_exists = $wpdb->get_var($wpdb->prepare("
            SELECT COUNT(*)
            FROM information_schema.STATISTICS
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME = %s
              AND INDEX_NAME = 'transaction_id'
              AND NON_UNIQUE = 0
        ", $table_transactions));

        if ($unique_exists > 0) {
            $wpdb->query("ALTER TABLE $table_transactions DROP INDEX transaction_id");
            error_log("Checkin MKT192: Dropped UNIQUE constraint 'transaction_id' from inventory_transactions");
        }

        // 2. Kiểm tra và xóa UNIQUE KEY 'idx_transaction_id' (composite - gây lỗi duplicate)
        $unique_idx_exists = $wpdb->get_var($wpdb->prepare("
            SELECT COUNT(*)
            FROM information_schema.STATISTICS
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME = %s
              AND INDEX_NAME = 'idx_transaction_id'
              AND NON_UNIQUE = 0
        ", $table_transactions));

        if ($unique_idx_exists > 0) {
            $wpdb->query("ALTER TABLE $table_transactions DROP INDEX idx_transaction_id");
            error_log("Checkin MKT192: Dropped UNIQUE constraint 'idx_transaction_id' from inventory_transactions");
        }

        // 3. Thêm INDEX thường (không UNIQUE) trên transaction_id nếu chưa có
        $index_exists = $wpdb->get_var($wpdb->prepare("
            SELECT COUNT(*)
            FROM information_schema.STATISTICS
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME = %s
              AND INDEX_NAME = 'idx_transaction_id'
        ", $table_transactions));

        if ($index_exists == 0) {
            $wpdb->query("ALTER TABLE $table_transactions ADD INDEX idx_transaction_id (transaction_id)");
            error_log("Checkin MKT192: Added INDEX 'idx_transaction_id' (non-unique) to inventory_transactions");
        }
    }

    /**
     * Public method để chạy migration fix UNIQUE constraint.
     * Được gọi từ wp_loaded hook để fix bảng hiện có mà không cần reactivate plugin.
     */
    public static function run_inventory_transaction_migration() {
        // Kiểm tra nếu đã chạy migration rồi thì skip (v3 để force run lại)
        $migration_key = 'checkin_mkt192_inventory_transaction_unique_fixed_v3';
        if (get_option($migration_key)) {
            return;
        }

        self::fix_inventory_transaction_unique_constraint();
        self::add_image_url_column();

        // Đánh dấu đã chạy migration
        update_option($migration_key, true);
        error_log('Checkin MKT192: Inventory transaction migration v3 completed');
    }

    /**
     * Thêm cột image_url vào bảng inventory_transactions
     */
    private static function add_image_url_column() {
        global $wpdb;
        $table_transactions = $wpdb->prefix . 'checkin_mkt192_inventory_transactions';

        // Kiểm tra cột image_url đã tồn tại chưa
        $column_exists = $wpdb->get_var($wpdb->prepare("
            SELECT COUNT(*)
            FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME = %s
              AND COLUMN_NAME = 'image_url'
        ", $table_transactions));

        if ($column_exists == 0) {
            $wpdb->query("ALTER TABLE $table_transactions ADD COLUMN image_url TEXT DEFAULT NULL COMMENT 'WordPress URL cho hiển thị' AFTER image_key");
            error_log("Checkin MKT192: Added column 'image_url' to inventory_transactions");
        }
    }

    /**
     * Tạo bảng inventory_checks (Phiếu kiểm kê).
     */
    private static function create_inventory_checks_table() {
        global $wpdb;
        $charset_collate = 'CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci';
        $table_checks    = $wpdb->prefix . 'checkin_mkt192_inventory_checks';

        $sql_checks = "CREATE TABLE $table_checks (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            check_code VARCHAR(50) NOT NULL COMMENT 'Mã phiếu kiểm kê (VD: CHECK-20250105-001)',
            staff_name VARCHAR(100) NOT NULL COMMENT 'Tên nhân viên kiểm kê',
            check_date DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Ngày kiểm kê',
            inventory_data LONGTEXT NOT NULL COMMENT 'JSON data chứa chi tiết sản phẩm kiểm kê',
            total_products INT(11) NOT NULL DEFAULT 0 COMMENT 'Tổng số sản phẩm kiểm kê',
            mismatched_count INT(11) NOT NULL DEFAULT 0 COMMENT 'Số sản phẩm không khớp',
            status ENUM('matched','mismatched','partial') DEFAULT 'matched' COMMENT 'Trạng thái tổng quan',
            note TEXT DEFAULT NULL COMMENT 'Ghi chú chung',
            branch_id INT(11) DEFAULT 0 COMMENT 'ID chi nhánh',
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY check_code (check_code),
            KEY idx_check_date (check_date),
            KEY idx_staff_name (staff_name),
            KEY idx_branch_id (branch_id)
        ) ENGINE=InnoDB $charset_collate COMMENT='Bảng lưu phiếu kiểm kê tồn kho';";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql_checks);
    }

    /**
     * Tạo bảng special_days.
     */
    private static function create_special_days_table() {
        global $wpdb;
        $table_name      = $wpdb->prefix . 'bookingmkt192_special_days';
        $charset_collate = 'CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci';

        $sql = "CREATE TABLE $table_name (
            id INT(11) NOT NULL AUTO_INCREMENT,
            type ENUM('overtime','holiday','event') NOT NULL,
            start_date DATE NOT NULL,
            end_date DATE NOT NULL,
            start_time TIME NOT NULL,
            end_time TIME NOT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            message TEXT NOT NULL,
            PRIMARY KEY  (id)
        ) ENGINE=InnoDB $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    /**
     * DEPRECATED: Bảng advance_salary cũ đã được thay thế bởi approval_requests
     * Giữ lại để tham khảo, không còn được gọi khi kích hoạt plugin
     * Bảng cũ: checkin_mkt192_advance_salary
     * Bảng mới: checkin_mkt192_approval_requests (request_type = 'salary_advance')
     */
    // private static function create_advance_salary_table() { ... }

    /**
     * Tạo bảng cashier_salary.
     */
    private static function create_cashier_salary_table() {
    global $wpdb;
    $table_name      = $wpdb->prefix . 'checkin_mkt192_cashier_salary';
    $charset_collate = 'CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci';

    $sql = "CREATE TABLE $table_name (
        id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        staff_name varchar(191) NOT NULL,
        level_name varchar(50) NOT NULL,
        standard_hours decimal(10,2) DEFAULT 0.00,
        overtime_hours decimal(10,2) DEFAULT 0.00,
        total_hours decimal(10,2) DEFAULT 0.00,
        hourly_salary decimal(15,2) DEFAULT 0.00,
        total_salary decimal(15,2) DEFAULT 0.00,
        advance_salary decimal(15,2) DEFAULT 0.00,
        uniform_fee decimal(15,2) DEFAULT 0.00,
        total_of_deductions decimal(10,2) NOT NULL DEFAULT 0.00,
        product_total int(11) DEFAULT 0,
        product_count_total int(11) DEFAULT 0,
        product_salary int(11) DEFAULT 0,
        actual_salary decimal(15,2) GENERATED ALWAYS AS (total_salary - advance_salary) STORED,
        level_start_date date DEFAULT NULL,
        period varchar(7) NOT NULL,
        xac_nhan_luong varchar(50) NOT NULL,
        payment varchar(255) NOT NULL,
        xac_nhan_thanh_toan varchar(50) NOT NULL,
        status varchar(50) NOT NULL,
        updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        current_level varchar(50) DEFAULT NULL,
        probation_hourly_salary decimal(10,2) DEFAULT 0.00,
        official_hourly_salary decimal(10,2) DEFAULT 0.00,
        probation_hours decimal(10,2) DEFAULT 0.00,
        official_hours decimal(10,2) DEFAULT 0.00,
        PRIMARY KEY  (id),
        KEY idx_staff_period (staff_name)
    ) ENGINE=InnoDB $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}

    /**
     * Tạo bảng hairdresser_salary.
     */
    private static function create_hairdresser_salary_table() {
        global $wpdb;
        $table_name      = $wpdb->prefix . 'checkin_mkt192_hairdresser_salary';
        $charset_collate = 'CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci';

        $sql = "CREATE TABLE $table_name (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            staff_id BIGINT(20) UNSIGNED NOT NULL,
            staff_name VARCHAR(100) NOT NULL,
            period VARCHAR(20) NOT NULL,
            level_name VARCHAR(100) NOT NULL,
            level_start_date DATE DEFAULT NULL,
            service_total INT(11) NOT NULL DEFAULT 0,
            penalty_service INT(11) NOT NULL DEFAULT 0,
            chemical_total INT(11) NOT NULL DEFAULT 0,
            penalty_chemical INT(11) NOT NULL DEFAULT 0,
            product_total INT(11) NOT NULL DEFAULT 0,
            product_count_total INT(11) NOT NULL DEFAULT 0,
            overtime_total INT(11) NOT NULL DEFAULT 0,
            service_salary INT(11) NOT NULL DEFAULT 0,
            chemical_salary INT(11) NOT NULL DEFAULT 0,
            product_salary INT(11) NOT NULL DEFAULT 0,
            overtime_salary INT(11) NOT NULL DEFAULT 0,
            total_salary INT(11) NOT NULL DEFAULT 0,
            penalty_note VARCHAR(255) DEFAULT NULL,
            penalty_percent DECIMAL(5,2) NOT NULL DEFAULT 0.00,
            advance_salary INT(11) NOT NULL DEFAULT 0,
            uniform_fee DECIMAL(15,2) DEFAULT 0.00,
            total_of_deductions INT(11) NOT NULL DEFAULT 0,
            actual_salary INT(11) NOT NULL DEFAULT 0,
            xac_nhan_luong TEXT,
            payment LONGTEXT,
            xac_nhan_thanh_toan TEXT,
            status TEXT,
            working_days DECIMAL(5,2) NOT NULL DEFAULT 0.00,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) ENGINE=InnoDB $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    /**
     * Tạo bảng checkinlogs.
     */
    private static function create_checkinlogs_table() {
        global $wpdb;
        $table_name      = $wpdb->prefix . 'checkin_mkt192_checkinlogs';
        $charset_collate = 'CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci';

        $sql = "CREATE TABLE $table_name (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            employee_id VARCHAR(50) NOT NULL,
            display_name VARCHAR(191) NOT NULL,
            checkin_time DATETIME NOT NULL,
            checkout_time DATETIME DEFAULT NULL,
            shift VARCHAR(100) NOT NULL,
            status VARCHAR(50) NOT NULL DEFAULT 'pending',
            approval_ot VARCHAR(50) DEFAULT NULL,
            approval_late VARCHAR(50) DEFAULT NULL,
            late_minutes INT(11) DEFAULT 0,
            penalty_amount DECIMAL(10,2) DEFAULT 0.00,
            type VARCHAR(20) NOT NULL,
            location_name VARCHAR(191) NOT NULL,
            status_late TINYINT(1) DEFAULT 0,
            penalty_type TEXT DEFAULT NULL,
            status_early TINYINT(1) DEFAULT 0,
            longitude DOUBLE NOT NULL,
            latitude DOUBLE NOT NULL,
            post_fb VARCHAR(50) NOT NULL,
            employee_role VARCHAR(50) NOT NULL,
            PRIMARY KEY  (id),
            KEY idx_employee (checkin_time),
            KEY idx_employee_checkin (employee_id, checkin_time)
        ) ENGINE=InnoDB $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    /**
     * Tạo bảng ctkm_settings.
     */
    private static function create_ctkm_settings_table() {
        global $wpdb;
        $table_name      = $wpdb->prefix . 'checkin_mkt192_ctkm_settings';
        $charset_collate = 'CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci';

        $sql = "CREATE TABLE $table_name (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            promo_type VARCHAR(50) NOT NULL DEFAULT 'ctkm',
            ctkm_name VARCHAR(100) NOT NULL,
            value INT(11) NOT NULL,
            description TEXT DEFAULT NULL,
            membership_label TEXT NOT NULL,
            applicable_services TEXT DEFAULT NULL,
            start_date DATE NOT NULL,
            end_date DATE NOT NULL,
            status VARCHAR(20) DEFAULT 'active',
            created_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY ctkm_name (ctkm_name)
        ) ENGINE=InnoDB $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    /**
     * Tạo bảng customer_reviews_off.
     */
    private static function create_customer_reviews_off_table() {
        global $wpdb;
        $table_name      = $wpdb->prefix . 'checkin_mkt192_customer_reviews_off';
        $charset_collate = 'CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci';

        $sql = "CREATE TABLE $table_name (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            invoice_id VARCHAR(50) NOT NULL,
            customer_id VARCHAR(50) NOT NULL,
            customer_name VARCHAR(255) NOT NULL,
            service_rating TINYINT(1) NOT NULL,
            service_name VARCHAR(255) DEFAULT NULL,
            staff_rating TINYINT(1) NOT NULL,
            staff_name VARCHAR(255) DEFAULT NULL,
            feedback TEXT DEFAULT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME DEFAULT NULL,
            PRIMARY KEY  (id),
            KEY idx_invoice_id (invoice_id),
            KEY idx_invoice_customer (invoice_id, customer_id)
        ) ENGINE=InnoDB $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    /**
     * Tạo bảng customer_reviews_online.
     */
    private static function create_customer_reviews_online_table() {
        global $wpdb;
        $table_name      = $wpdb->prefix . 'checkin_mkt192_customer_reviews_online';
        $charset_collate = 'CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci';

        $sql = "CREATE TABLE $table_name (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            invoice_id VARCHAR(50) NOT NULL,
            customer_id VARCHAR(50) NOT NULL,
            customer_name VARCHAR(255) NOT NULL,
            service_rating TINYINT(1) NOT NULL,
            service_name LONGTEXT NOT NULL,
            staff_rating TINYINT(1) NOT NULL,
            staff_name VARCHAR(255) NOT NULL,
            feedback TEXT DEFAULT NULL,
            created_at DATETIME NOT NULL,
            updated_at DATETIME DEFAULT NULL,
            PRIMARY KEY  (id),
            KEY idx_invoice_id (invoice_id),
            KEY idx_invoice_customer (invoice_id, customer_id)
        ) ENGINE=InnoDB $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    /**
     * Tạo bảng invoices_data.
     */
    private static function create_invoices_data_table() {
        global $wpdb;
        $table_name      = $wpdb->prefix . 'checkin_mkt192_invoices_data';
        $charset_collate = 'CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci';

        $sql = "CREATE TABLE $table_name (
            invoice_id VARCHAR(20) NOT NULL,
            booking_id VARCHAR(50) NOT NULL,
            created_at DATETIME NOT NULL,
            created_user VARCHAR(50) DEFAULT NULL,
            customer_id VARCHAR(50) NOT NULL,
            customer_name VARCHAR(100) NOT NULL,
            customer_phone VARCHAR(20) NOT NULL,
            new_customer VARCHAR(50) DEFAULT NULL,
            images LONGTEXT DEFAULT NULL,
            image_feedback LONGTEXT DEFAULT NULL,
            not_image LONGTEXT NOT NULL,
            promo_code VARCHAR(50) DEFAULT NULL,
            promo_status VARCHAR(255) NOT NULL,
            membership_label VARCHAR(20) NOT NULL,
            services TEXT NOT NULL COMMENT 'JSON array of services with staff',
            cashier VARCHAR(100) DEFAULT NULL,
            payment_method VARCHAR(20) DEFAULT NULL,
            combined_payment_details TEXT DEFAULT NULL COMMENT 'JSON chi tiết thanh toán kết hợp: {cash: xxx, bank: xxx}',
            promo_name VARCHAR(100) DEFAULT NULL COMMENT 'Chương trình khuyến mãi',
            subtotal INT(11) NOT NULL,
            discount INT(11) NOT NULL DEFAULT 0,
            tips INT(11) NOT NULL DEFAULT 0,
            total INT(11) NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'pending',
            message_type VARCHAR(20) DEFAULT NULL,
            message_status VARCHAR(100) DEFAULT NULL,
            branch VARCHAR(255) DEFAULT '' COMMENT 'Chi nhánh',
            updated_at DATETIME DEFAULT NULL,
            PRIMARY KEY  (invoice_id),
            KEY idx_customer_id (customer_id),
            KEY idx_created_at_status (created_at, status),
            KEY idx_created_at (created_at),
            KEY idx_invoice_id (invoice_id),
            KEY idx_branch (branch)
        ) ENGINE=InnoDB $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);

        // Migration: Thêm cột combined_payment_details nếu chưa tồn tại
        $column_exists = $wpdb->get_results("SHOW COLUMNS FROM $table_name LIKE 'combined_payment_details'");
        if (empty($column_exists)) {
            $wpdb->query("ALTER TABLE $table_name ADD COLUMN combined_payment_details TEXT DEFAULT NULL COMMENT 'JSON chi tiết thanh toán kết hợp: {cash: xxx, bank: xxx}' AFTER payment_method");
        }
    }

    /**
     * Tạo bảng invoices_data_detail.
     */
    private static function create_invoices_data_detail_table() {
        global $wpdb;
        $table_name      = $wpdb->prefix . 'checkin_mkt192_invoices_data_detail';
        $charset_collate = 'CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci';

        $sql = "CREATE TABLE $table_name (
            id INT(11) NOT NULL AUTO_INCREMENT,
            invoice_id VARCHAR(50) NOT NULL,
            staff_id VARCHAR(50) DEFAULT NULL,
            staff_name VARCHAR(255) DEFAULT NULL,
            service_id VARCHAR(50) DEFAULT NULL,
            service_name VARCHAR(255) DEFAULT NULL,
            price INT(11) NOT NULL,
            quantity INT(11) NOT NULL,
            subtotal INT(11) NOT NULL,
            discount INT(11) NOT NULL DEFAULT 0,
            total INT(11) NOT NULL,
            tips INT(11) NOT NULL DEFAULT 0,
            total_invoice INT(11) NOT NULL,
            status VARCHAR(50) DEFAULT 'pending',
            type VARCHAR(50) NOT NULL,
            service_type VARCHAR(50) NOT NULL,
            is_penalty TINYINT(1) DEFAULT 0,
            is_overtime TINYINT(1) DEFAULT 0,
            overtime_value INT(11) DEFAULT 0,
            branch VARCHAR(255) DEFAULT '' COMMENT 'Chi nhánh',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            INDEX invoice_id (invoice_id),
            KEY idx_invoice_id (invoice_id),
            KEY idx_staff_name (staff_name(250)),
            KEY idx_branch (branch)
        ) ENGINE=InnoDB $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

private static function create_kpi_settings_table() {
    global $wpdb;
    $table_name      = $wpdb->prefix . 'checkin_mkt192_kpi_settings';
    $charset_collate = 'CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci';

    $sql = "CREATE TABLE $table_name (
        id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        staff_name varchar(191) NOT NULL,
        service_kpi int(11) DEFAULT NULL,
        service_bonus int(11) DEFAULT NULL,
        service_penalty int(11) DEFAULT NULL,
        product_kpi_lv1 decimal(15,2) DEFAULT NULL,
        product_bonus_lv1 decimal(15,2) DEFAULT NULL,
        product_penalty_lv1 decimal(15,2) DEFAULT NULL,
        product_kpi_type enum('san_pham','doanh_thu') DEFAULT 'doanh_thu',
        post_fb_kpi int(11) DEFAULT NULL,
        post_fb_mode varchar(10) NOT NULL DEFAULT 'count',
        post_fb_bonus int(11) DEFAULT NULL,
        post_fb_penalty int(11) DEFAULT NULL,
        feedback_kpi int(11) DEFAULT NULL,
        feedback_bonus int(11) DEFAULT NULL,
        feedback_penalty int(11) DEFAULT NULL,
        status int(11) NOT NULL,
        start_date date DEFAULT NULL,
        end_date date DEFAULT NULL,
        created_at datetime DEFAULT NULL,
        updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY  (id),
        KEY idx_staff_month (staff_name(100))
    ) ENGINE=InnoDB $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}

    /**
     * Tạo bảng kpi_results.
     */
    private static function create_kpi_results_table() {
    global $wpdb;
    $table_name      = $wpdb->prefix . 'checkin_mkt192_kpi_results';
    $charset_collate = 'CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci';

    $sql = "CREATE TABLE $table_name (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        staff_name varchar(255) NOT NULL,
        period varchar(7) NOT NULL,
        service_kpi bigint(20) DEFAULT 0,
        service_achieved tinyint(1) DEFAULT 0,
        service_bonus bigint(20) DEFAULT 0,
        service_penalty bigint(20) DEFAULT 0,
        product_kpi bigint(20) DEFAULT 0,
        product_achieved tinyint(1) DEFAULT 0,
        product_bonus bigint(20) DEFAULT 0,
        product_kpi_type enum('san_pham','doanh_thu') DEFAULT 'doanh_thu',
        post_fb_kpi int(11) DEFAULT 0,
        post_fb_mode varchar(10) DEFAULT NULL,
        post_fb_achieved tinyint(1) DEFAULT 0,
        post_fb_bonus bigint(20) DEFAULT 0,
        feedback_kpi int(11) DEFAULT 0,
        feedback_achieved tinyint(1) DEFAULT 0,
        feedback_bonus bigint(20) DEFAULT 0,
        updated_at datetime NOT NULL,
        is_evaluated tinyint(1) DEFAULT 0,
        PRIMARY KEY  (id),
        UNIQUE KEY staff_period (staff_name, period)
    ) ENGINE=InnoDB $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}

    /**
     * DEPRECATED: Bảng late_requests cũ đã được thay thế bởi approval_requests
     * Giữ lại để tham khảo, không còn được gọi khi kích hoạt plugin
     * Bảng cũ: checkin_mkt192_late_requests
     * Bảng mới: checkin_mkt192_approval_requests (request_type = 'late_early')
     */
    // private static function create_late_requests_table() { ... }

    /**
     * Tạo bảng locations.
     */
    private static function create_locations_table() {
        global $wpdb;
        $table_name      = $wpdb->prefix . 'checkin_mkt192_locations';
        $charset_collate = 'CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci';

        $sql = "CREATE TABLE $table_name (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            latitude DOUBLE NOT NULL,
            longitude DOUBLE NOT NULL,
            radius INT(11) NOT NULL,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            location_name VARCHAR(191) NOT NULL DEFAULT '',
            address TEXT DEFAULT NULL COMMENT 'Địa chỉ chi nhánh',
            google_map_link TEXT DEFAULT NULL COMMENT 'Link Google Maps',
            is_main_branch TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'Chi nhánh chính',
            PRIMARY KEY  (id),
            UNIQUE KEY location_name (location_name)
        ) ENGINE=InnoDB $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    /**
     * Tạo bảng message_bot_settings.
     */
    private static function create_message_bot_settings_table() {
        global $wpdb;
        $table_name      = $wpdb->prefix . 'checkin_mkt192_message_bot_settings';
        $charset_collate = 'CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci';

        $sql = "CREATE TABLE $table_name (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            bot_name VARCHAR(100) NOT NULL,
            bot_type VARCHAR(20) NOT NULL DEFAULT 'interactive',
            notification_types TEXT NULL,
            chat_id VARCHAR(100) NULL,
            app_id VARCHAR(100) NULL,
            app_secret VARCHAR(255) NULL,
            webhook_url TEXT NULL,
            is_active TINYINT(1) NOT NULL DEFAULT 1,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY idx_bot_type (bot_type),
            KEY idx_is_active (is_active)
        ) ENGINE=InnoDB $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    /**
     * Tạo bảng penalty_settings.
     */
    private static function create_penalty_settings_table() {
        global $wpdb;
        $table_name      = $wpdb->prefix . 'checkin_mkt192_penalty_settings';
        $charset_collate = 'CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci';

        $sql = "CREATE TABLE $table_name (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            penalty_enabled TINYINT(1) NOT NULL DEFAULT 0,
            fine_amount DECIMAL(15,2) NOT NULL DEFAULT 50000.00,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            fine_by_time TINYINT(1) NOT NULL DEFAULT 0,
            late_count_for_report INT(11) NOT NULL DEFAULT 5,
            report_penalty_type VARCHAR(50) NOT NULL DEFAULT 'fixed',
            report_penalty_value DECIMAL(15,2) NOT NULL DEFAULT 0.00,
            fine_levels TEXT DEFAULT NULL,
            report_enabled TINYINT(1) NOT NULL DEFAULT 0,
            PRIMARY KEY  (id)
        ) ENGINE=InnoDB $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    /**
     * Tạo bảng pending_reviews.
     */
    private static function create_pending_reviews_table() {
        global $wpdb;
        $table_name      = $wpdb->prefix . 'checkin_mkt192_pending_reviews';
        $charset_collate = 'CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci';

        $sql = "CREATE TABLE $table_name (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            invoice_id VARCHAR(255) NOT NULL,
            created_at DATETIME NOT NULL,
            is_processed TINYINT(4) DEFAULT 0,
            processed_at DATETIME DEFAULT NULL,
            status VARCHAR(50) NOT NULL,
            cashier VARCHAR(100) NOT NULL,
            PRIMARY KEY  (id),
            KEY idx_invoice_id (invoice_id)
        ) ENGINE=InnoDB $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    /**
     * Tạo bảng promo_settings.
     */
    private static function create_promo_settings_table() {
        global $wpdb;
        $table_name      = $wpdb->prefix . 'checkin_mkt192_promo_settings';
        $charset_collate = 'CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci';

        $sql = "CREATE TABLE $table_name (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            promo_code VARCHAR(50) NOT NULL,
            discount_value FLOAT NOT NULL,
            start_date DATE NOT NULL,
            end_date DATE NOT NULL,
            status VARCHAR(20) DEFAULT 'active',
            created_at DATETIME NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY promo_code (promo_code)
        ) ENGINE=InnoDB $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    /**
     * Tạo bảng salary_level_settings.
     */
    private static function create_salary_level_settings_table() {
        global $wpdb;
        $table_name      = $wpdb->prefix . 'checkin_mkt192_salary_level_settings';
        $charset_collate = 'CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci';

        $sql = "CREATE TABLE $table_name (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            level_name VARCHAR(100) NOT NULL,
            base_salary DECIMAL(15,2) NOT NULL DEFAULT 0.00,
            service_salary DECIMAL(5,2) NOT NULL DEFAULT 0.00,
            chemical_salary DECIMAL(5,2) NOT NULL DEFAULT 0.00,
            hourly_salary INT(11) NOT NULL DEFAULT 0,
            video_salary INT(11) NOT NULL DEFAULT 0,
            role VARCHAR(100) NOT NULL,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) ENGINE=InnoDB $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);

        self::insert_default_salary_levels();
    }

    /**
     * Tạo bảng salary_period_rates — "thẻ hoa hồng" của một thợ trong một kỳ lương.
     * Thay cho việc đoán % từ cấp bậc: mỗi kỳ có thể chỉnh lẻ %, kỳ sau kế thừa kỳ trước.
     */
    private static function create_salary_period_rates_table() {
        global $wpdb;
        $table_name      = $wpdb->prefix . 'checkin_mkt192_salary_period_rates';
        $charset_collate = 'CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci';

        $sql = "CREATE TABLE $table_name (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            staff_name VARCHAR(191) NOT NULL,
            period CHAR(7) NOT NULL,
            service_percent DECIMAL(5,2) NOT NULL DEFAULT 0.00,
            chemical_percent DECIMAL(5,2) NOT NULL DEFAULT 0.00,
            product_percent DECIMAL(5,2) NOT NULL DEFAULT 10.00,
            product_min_qty INT(11) NOT NULL DEFAULT 1,
            overtime_percent DECIMAL(5,2) NOT NULL DEFAULT 10.00,
            kpi_penalty_percent DECIMAL(5,2) NOT NULL DEFAULT 0.00,
            kpi_penalty_scope VARCHAR(10) NOT NULL DEFAULT 'service',
            kpi_penalty_mode VARCHAR(10) NOT NULL DEFAULT 'once',
            kpi_required VARCHAR(100) NOT NULL DEFAULT '',
            note VARCHAR(255) DEFAULT NULL,
            source VARCHAR(10) NOT NULL DEFAULT 'manual',
            updated_by BIGINT(20) UNSIGNED DEFAULT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY staff_period (staff_name(100), period)
        ) ENGINE=InnoDB $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    /**
     * Tạo bảng salary_adjustments — phiếu thưởng / phiếu trừ theo kỳ lương
     * (thưởng nóng, thưởng lễ, đồng phục, phạt, truy thu đánh giá thấp…).
     */
    private static function create_salary_adjustments_table() {
        global $wpdb;
        $table_name      = $wpdb->prefix . 'checkin_mkt192_salary_adjustments';
        $charset_collate = 'CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci';

        $sql = "CREATE TABLE $table_name (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            staff_name VARCHAR(191) NOT NULL,
            role VARCHAR(50) NOT NULL DEFAULT 'Thợ',
            period CHAR(7) NOT NULL,
            kind VARCHAR(20) NOT NULL DEFAULT 'bonus',
            category VARCHAR(30) NOT NULL DEFAULT 'other',
            title VARCHAR(191) NOT NULL,
            unit_price DECIMAL(15,2) NOT NULL DEFAULT 0.00,
            quantity DECIMAL(10,2) NOT NULL DEFAULT 1.00,
            amount DECIMAL(15,2) NOT NULL DEFAULT 0.00,
            note VARCHAR(255) DEFAULT NULL,
            source VARCHAR(20) NOT NULL DEFAULT 'manual',
            ref_id VARCHAR(50) DEFAULT NULL,
            created_by BIGINT(20) UNSIGNED DEFAULT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY staff_period (staff_name(100), period),
            KEY source_ref (source, ref_id)
        ) ENGINE=InnoDB $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    /**
     * Chèn dữ liệu mặc định cho bảng salary_level_settings.
     */
    private static function insert_default_salary_levels() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'checkin_mkt192_salary_level_settings';

        $levels = [
            ['Thử việc (C0_0)', 0, 0],
            ['Sơ cấp 1 (C10_0)', 10, 0],
            ['Sơ cấp 2 (C20_0)', 20, 0],
            ['Sơ cấp 3 (C30_0)', 30, 0],
            ['Trung cấp 1 (C30_10)', 30, 10],
            ['Trung cấp 2 (C30_15)', 30, 15],
            ['Trung cấp 3 (C35_10)', 35, 10],
            ['Trung cấp 4 (C35_15)', 35, 15],
            ['Trung cấp 5 (C35_20)', 35, 20],
            ['Cao cấp 1 (C40_15)', 40, 15],
            ['Cao cấp 2 (C40_20)', 40, 20],
            ['Cao cấp 3 (C45_20)', 45, 20],
            ['Cao cấp 4 (C45_25)', 45, 25],
            ['Cao cấp 5 (C45_30)', 45, 30],
            ['Chuyên gia 1 (C50_15)', 50, 15],
            ['Chuyên gia 2 (C50_20)', 50, 20],
            ['Chuyên gia 3 (C50_30)', 50, 30],
            ['Chuyên gia 4 (C50_40)', 50, 40],
            ['Master (C50_50)', 50, 50],
        ];

        foreach ($levels as $level) {
            $existing = $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM $table_name WHERE level_name = %s",
                    $level[0]
                )
            );

            if (!$existing) {
                $wpdb->insert(
                    $table_name,
                    [
                        'level_name'      => $level[0],
                        'service_salary'  => $level[1],
                        'chemical_salary' => $level[2],
                        'role'            => 'Thợ Chính',
                        'updated_at'      => current_time('mysql', 1)
                    ],
                    ['%s', '%f', '%f', '%s', '%s']
                );
            }
        }
    }

private static function create_service_groups_table() {
    global $wpdb;
    $table_name      = $wpdb->prefix . 'checkin_mkt192_service_groups';
    $charset_collate = 'CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci';

    $sql = "CREATE TABLE $table_name (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        name VARCHAR(255) NOT NULL,
        description TEXT NULL,
        PRIMARY KEY  (id)
    ) ENGINE=InnoDB $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}

    /**
     * Tạo bảng service_data.
     */
    private static function create_service_data_table() {
        global $wpdb;
        $table_name      = $wpdb->prefix . 'checkin_mkt192_service_data';
        $group_table     = $wpdb->prefix . 'checkin_mkt192_service_groups';
        $charset_collate = 'CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci';

        $sql = "CREATE TABLE $table_name (
            service_id VARCHAR(50) NOT NULL,
            service_name VARCHAR(255) NOT NULL,
            service_group VARCHAR(255) DEFAULT NULL,
            service_group_id BIGINT UNSIGNED DEFAULT NULL,
            service_price INT(11) NOT NULL,
            branch VARCHAR(255) DEFAULT '',
            sort_order INT(11) DEFAULT NULL,
            discounted_price DECIMAL(15,2) DEFAULT NULL,
            service_type ENUM('service', 'chemical') DEFAULT 'service',
            service_description LONGTEXT DEFAULT NULL,
            PRIMARY KEY  (service_id),
            KEY idx_service_group_id (service_group_id),
            KEY idx_branch (branch)
        ) ENGINE=InnoDB $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);

        $constraint_exists = $wpdb->get_var("
            SELECT CONSTRAINT_NAME
            FROM information_schema.KEY_COLUMN_USAGE
            WHERE TABLE_SCHEMA = DATABASE()
                AND TABLE_NAME = '{$table_name}'
                AND CONSTRAINT_NAME = 'fk_service_group_id'
        ");
        if (!$constraint_exists) {
        $wpdb->query("
            ALTER TABLE $table_name
            ADD CONSTRAINT fk_service_group_id
            FOREIGN KEY (service_group_id) REFERENCES $group_table (id)
            ON DELETE SET NULL ON UPDATE CASCADE
        ");
        }
    }

    /**
     * Tạo bảng shiftsettings.
     */
    private static function create_shiftsettings_table() {
        global $wpdb;
        $table_name      = $wpdb->prefix . 'checkin_mkt192_shiftsettings';
        $charset_collate = 'CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci';

        $sql = "CREATE TABLE $table_name (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            shift_group VARCHAR(50) NOT NULL,
            shift_name VARCHAR(100) NOT NULL,
            start_time TIME NOT NULL,
            end_time TIME NOT NULL,
            branch VARCHAR(255) DEFAULT '',
            early_checkin INT(11) NOT NULL DEFAULT 0,
            late_allowed INT(11) NOT NULL DEFAULT 0,
            late_checkin INT(11) NOT NULL DEFAULT 0,
            early_checkout INT(11) NOT NULL DEFAULT 0,
            late_checkout INT(11) NOT NULL DEFAULT 0,
            PRIMARY KEY  (id),
            KEY idx_branch (branch)
        ) ENGINE=InnoDB $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    /**
     * Tạo bảng staff.
     */
    private static function create_staff_table() {
    global $wpdb;
    $table_name      = $wpdb->prefix . 'checkin_mkt192_staff';
    $charset_collate = 'CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci';

    $sql = "CREATE TABLE $table_name (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id INT(11) DEFAULT NULL,
        employee_id VARCHAR(50) NOT NULL,
        ou_id VARCHAR(50) NOT NULL,
        user_login VARCHAR(100) NOT NULL,
        display_name VARCHAR(191) NOT NULL,
        user_email VARCHAR(191) NOT NULL,
        user_role VARCHAR(50) NOT NULL,
        branch VARCHAR(255) DEFAULT '',
        branch_id INT(11) DEFAULT 0 COMMENT 'ID chi nhánh chính',
        facebook_url VARCHAR(255) DEFAULT '',
        tiktok_url VARCHAR(255) DEFAULT '',
        birthday DATE DEFAULT NULL,
        gender VARCHAR(50) DEFAULT 'male',
        address TEXT DEFAULT NULL,
        is_cccd TINYINT(1) DEFAULT 0,
        cccd_front VARCHAR(255) DEFAULT '',
        cccd_back VARCHAR(255) DEFAULT '',
        avatar LONGTEXT DEFAULT NULL,
        status ENUM('ON','OFF','BUSY','PAUSE','ARCHIVED','DELETED') DEFAULT 'ON',
        phone VARCHAR(30) DEFAULT '' COMMENT 'SĐT thợ — hiện ở trang chủ khi thợ đang tạm dừng',
        PRIMARY KEY  (id),
        UNIQUE KEY employee_id (employee_id),
        INDEX user_login (user_login),
        KEY idx_user_login (user_login),
        KEY idx_display_name (display_name),
        KEY idx_staff_name (display_name),
        KEY idx_branch (branch),
        KEY idx_branch_id (branch_id)
    ) ENGINE=InnoDB $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}

    /**
     * Tạo bảng staff_roles.
     */
    private static function create_staff_roles_table() {
    global $wpdb;
    $table_name      = $wpdb->prefix . 'checkin_mkt192_staff_roles';
    $charset_collate = $wpdb->get_charset_collate();

    // === 1. TẠO BẢNG CHUẨN dbDelta (chỉ 1 lần duy nhất) ===
    $sql = "CREATE TABLE `$table_name` (
        id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        role_name VARCHAR(50) NOT NULL,
        description TEXT DEFAULT NULL,
        is_active TINYINT(1) DEFAULT 1,
        paid_leave_days INT(11) DEFAULT 0,
        access_permissions LONGTEXT DEFAULT NULL,
        permissions LONGTEXT DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY  (id),
        UNIQUE KEY role_name_unique (role_name)
    ) ENGINE=InnoDB $charset_collate;";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta( $sql );

    // === 2. THÊM CỘT paid_leave_days CHỈ KHI CHƯA TỒN TẠI (an toàn tuyệt đối) ===
    $column_exists = $wpdb->get_col( $wpdb->prepare(
        "SHOW COLUMNS FROM `$table_name` LIKE %s", 'paid_leave_days'
    ) );

    if ( empty( $column_exists ) ) {
        $wpdb->query( "ALTER TABLE `$table_name`
            ADD COLUMN paid_leave_days INT(11) DEFAULT 0 AFTER is_active" );
    }

    // === 3. ĐỔI TÊN UNIQUE KEY ĐỂ TRÁNH TRÙNG (nếu có key cũ bị lỗi) ===
    // Một số hosting tạo ra role_name, role_name_2, role_name_3...
    $indexes         = $wpdb->get_results( "SHOW INDEX FROM `$table_name` WHERE Column_name = 'role_name'" );
    $good_key_exists = false;
    foreach ( $indexes as $index ) {
        if ( $index->Key_name === 'role_name_unique' ) {
            $good_key_exists = true;
            break;
        }
    }

    // Nếu chưa có key chuẩn → xóa hết key cũ rồi tạo lại key chuẩn
    if ( ! $good_key_exists ) {
        // Xóa tất cả key liên quan đến role_name
        foreach ( $indexes as $index ) {
            if ( strpos( $index->Key_name, 'role_name' ) !== false && $index->Key_name !== 'PRIMARY' ) {
                $wpdb->query( "ALTER TABLE `$table_name` DROP INDEX `{$index->Key_name}`" );
            }
        }
        // Tạo lại key chuẩn
        $wpdb->query( "ALTER TABLE `$table_name` ADD UNIQUE KEY role_name_unique (role_name)" );
    }

    // === 4. INSERT DEFAULT ROLES (idempotent - chạy 1000 lần vẫn ok) ===
    $default_roles       = ['Thợ Chính', 'Thợ Phụ'];
    $default_permissions = wp_json_encode( [
        'invoice'      => ['add','edit','view_personal','send_message'],
        'booking'      => ['view','add','edit','delete','send_message','resend'],
        'service'      => ['view'],
        'product'      => ['view'],
        'staff'        => ['view','update_status'],
        'salary'       => ['view','confirm'],
        'kpi'          => ['view'],
        'penalty'      => ['view'],
        'location'     => ['view'],
        'shift'        => ['view'],
        'leave'        => ['view'],
        'checkin'      => ['view','record'],
        'customer'     => ['view','add','edit'],
        'review'       => ['view'],
        'zalo'         => ['view'],
        'dashboard'    => ['view'],
        'promotion'    => ['view'],
        'salary_level' => ['view'],
        'staff_level'  => ['view']
    ], JSON_UNESCAPED_UNICODE );

    $cashier_permissions = wp_json_encode( [
        'invoice'      => ['add','edit','view_all','penalty','send_message'],
        'booking'      => ['view','add','edit','delete','send_message','resend'],
        'service'      => ['view','add'],
        'product'      => ['view','add'],
        'staff'        => ['view','update_status'],
        'salary'       => ['view','confirm'],
        'kpi'          => ['view'],
        'penalty'      => ['view'],
        'location'     => ['view'],
        'shift'        => ['view'],
        'leave'        => ['view'],
        'checkin'      => ['view','record'],
        'customer'     => ['view','add','edit'],
        'review'       => ['view','moderate'],
        'zalo'         => ['view'],
        'dashboard'    => ['view'],
        'promotion'    => ['view'],
        'inventory'    => ['view','edit','check','transaction'],
        'salary_level' => ['view'],
        'staff_level'  => ['view']
    ], JSON_UNESCAPED_UNICODE );

    $admin_permissions = wp_json_encode( [
        'invoice'       => ['view_personal','view_all','add','edit','penalty','delete','send_message'],
        'booking'       => ['view_personal','view_all','add','edit','delete','send_message','resend','config'],
        'service'       => ['view','add','edit','delete'],
        'product'       => ['view','add','edit','delete'],
        'staff'         => ['view','add','edit','delete','update_status'],
        'salary'        => ['view','calculate','confirm','payment','notify'],
        'kpi'           => ['view','set','add','edit','delete','evaluate','reset'],
        'penalty'       => ['view','set','edit'],
        'location'      => ['view','add','edit','delete','set'],
        'shift'         => ['view','add','edit','delete','delete_history'],
        'leave'         => ['view','request','approve'],
        'checkin'       => ['record','view','view_all'],
        'customer'      => ['view','add','edit','delete'],
        'payment'       => ['view','process'],
        'review'        => ['view','moderate'],
        'zalo'          => ['view','config'],
        'dashboard'     => ['view'],
        'role'          => ['view','add','edit','delete'],
        'schedule'      => ['view','manage','add','edit','delete'],
        'settings'      => ['view','edit'],
        'promotion'     => ['view','add','edit','delete'],
        'inventory'     => ['view','check','transaction','edit','approve','delete'],
        'product_group' => ['view','add','edit','delete'],
        'service_group' => ['view','add','edit','delete'],
        'salary_level'  => ['view','add','edit','delete'],
        'staff_level'   => ['view','add','edit','delete']
    ], JSON_UNESCAPED_UNICODE );

    // === CHỈ INSERT DEFAULT ROLES KHI BẢNG CHƯA CÓ DỮ LIỆU ===
    $total_roles = $wpdb->get_var( "SELECT COUNT(*) FROM `$table_name`" );

    if ( intval( $total_roles ) === 0 ) {
        // Insert Quản Lý role
        $wpdb->insert( $table_name, [
            'role_name'          => 'Quản Lý',
            'access_permissions' => wp_json_encode(['admin','app_tho','diem_danh','profile']),
            'permissions'        => $admin_permissions,
            'is_active'          => 1
        ], ['%s', '%s', '%s', '%d'] );

        // Insert Thu Ngân role (cashier)
        $wpdb->insert( $table_name, [
            'role_name'          => 'Thu Ngân',
            'access_permissions' => wp_json_encode(['app_tho','diem_danh','profile']),
            'permissions'        => $cashier_permissions,
            'is_active'          => 1
        ], ['%s', '%s', '%s', '%d'] );

        // Insert default staff roles (Thợ Chính, Thợ Phụ)
        foreach ( $default_roles as $role ) {
            $wpdb->insert( $table_name, [
                'role_name'          => $role,
                'access_permissions' => wp_json_encode(['app_tho','diem_danh','profile']),
                'permissions'        => $default_permissions,
                'is_active'          => 1
            ], ['%s', '%s', '%s', '%d'] );
        }
    }

    // === 5. CẬP NHẬT PERMISSIONS VÀ ACCESS_PERMISSIONS CHO CÁC ROLE CŨ ===
    $wpdb->query( $wpdb->prepare(
        "UPDATE `$table_name`
         SET permissions = %s
         WHERE permissions IS NULL
            OR permissions = ''
            OR permissions = 'null'
            OR permissions = '[]'",
        $default_permissions
    ) );

    // Update access_permissions cho các role cũ nếu rỗng hoặc chưa được set
    $wpdb->query( $wpdb->prepare(
        "UPDATE `$table_name`
         SET access_permissions = %s
         WHERE (access_permissions IS NULL
            OR access_permissions = ''
            OR access_permissions = 'null'
            OR access_permissions = '[]'
            OR TRIM(access_permissions) = 'null')
            AND role_name IN ('Thợ Chính', 'Thợ Phụ')",
        wp_json_encode(['app_tho','diem_danh','profile'])
    ) );

    $wpdb->query( $wpdb->prepare(
        "UPDATE `$table_name`
         SET access_permissions = %s
         WHERE (access_permissions IS NULL
            OR access_permissions = ''
            OR access_permissions = 'null'
            OR access_permissions = '[]'
            OR TRIM(access_permissions) = 'null')
            AND role_name = 'Thu Ngân'",
        wp_json_encode(['app_tho','diem_danh','profile'])
    ) );

    $wpdb->query( $wpdb->prepare(
        "UPDATE `$table_name`
         SET access_permissions = %s
         WHERE (access_permissions IS NULL
            OR access_permissions = ''
            OR access_permissions = 'null'
            OR access_permissions = '[]'
            OR TRIM(access_permissions) = 'null')
            AND role_name = 'Quản Lý'",
        wp_json_encode(['admin','app_tho','diem_danh','profile'])
    ) );

    // === 6. CẬP NHẬT PERMISSIONS CHO QUẢN LÝ VÀ THU NGÂN (CHỈ KHI CHƯA CÓ) ===
    // Chỉ update permissions cho Quản Lý nếu permissions đang rỗng/null
    $wpdb->query( $wpdb->prepare(
        "UPDATE `$table_name`
         SET permissions = %s
         WHERE role_name = 'Quản Lý'
           AND (permissions IS NULL
            OR permissions = ''
            OR permissions = 'null'
            OR permissions = '[]'
            OR TRIM(permissions) = 'null')",
        $admin_permissions
    ) );

    // Chỉ update access_permissions cho Quản Lý nếu đang rỗng/null
    $wpdb->query( $wpdb->prepare(
        "UPDATE `$table_name`
         SET access_permissions = %s
         WHERE role_name = 'Quản Lý'
           AND (access_permissions IS NULL
            OR access_permissions = ''
            OR access_permissions = 'null'
            OR access_permissions = '[]'
            OR TRIM(access_permissions) = 'null')",
        wp_json_encode(['admin','app_tho','diem_danh','profile'])
    ) );

    // Chỉ update permissions cho Thu Ngân nếu permissions đang rỗng/null
    $wpdb->query( $wpdb->prepare(
        "UPDATE `$table_name`
         SET permissions = %s
         WHERE role_name = 'Thu Ngân'
           AND (permissions IS NULL
            OR permissions = ''
            OR permissions = 'null'
            OR permissions = '[]'
            OR TRIM(permissions) = 'null')",
        $cashier_permissions
    ) );

    // Chỉ update access_permissions cho Thu Ngân nếu đang rỗng/null
    $wpdb->query( $wpdb->prepare(
        "UPDATE `$table_name`
         SET access_permissions = %s
         WHERE role_name = 'Thu Ngân'
           AND (access_permissions IS NULL
            OR access_permissions = ''
            OR access_permissions = 'null'
            OR access_permissions = '[]'
            OR TRIM(access_permissions) = 'null')",
        wp_json_encode(['app_tho','diem_danh','profile'])
    ) );

    // === 7. ĐÁNH DẤU PHIÊN BẢN ĐỂ SAU NÀY UPDATE TỰ ĐỘNG ===
    update_option( 'checkin_mkt192_db_version', '1.2.1' );
}

    /**
     * Tạo bảng staff_level_history.
     */
    private static function create_staff_level_history_table() {
        global $wpdb;
        $table_name      = $wpdb->prefix . 'checkin_mkt192_staff_level_history';
        $charset_collate = 'CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci';

        $sql = "CREATE TABLE $table_name (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            staff_id VARCHAR(50) NOT NULL,
            staff_name VARCHAR(191) NOT NULL,
            role VARCHAR(100) NOT NULL DEFAULT '',
            status VARCHAR(50) NOT NULL DEFAULT '',
            level_name VARCHAR(100) NOT NULL,
            start_time DATE NOT NULL DEFAULT '0000-00-00',
            end_time DATE NOT NULL DEFAULT '0000-00-00',
            `condition` TEXT DEFAULT NULL,
            is_active TINYINT(1) NOT NULL DEFAULT 1,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY idx_staff_level (staff_name(100), level_name)
        ) ENGINE=InnoDB $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    /**
     * Tạo bảng social_posts.
     */
    private static function create_social_posts_table() {
        global $wpdb;
        $table_name      = $wpdb->prefix . 'checkin_mkt192_social_posts';
        $charset_collate = 'CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci';

        $sql = "CREATE TABLE $table_name (
            id INT AUTO_INCREMENT,
            staff_name VARCHAR(100),
            post_type VARCHAR(50) DEFAULT 'facebook',
            post_id VARCHAR(255),
            post_date DATE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) ENGINE=InnoDB $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    /**
     * Tạo bảng image_feedback.
     */
    private static function create_image_feedback_table() {
        global $wpdb;
        $table_name      = $wpdb->prefix . 'checkin_mkt192_image_feedback';
        $charset_collate = 'CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci';

        $sql = "CREATE TABLE $table_name (
            id INT NOT NULL AUTO_INCREMENT,
            staff_name VARCHAR(100),
            image TEXT,
            feedback_date DATETIME,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) ENGINE=InnoDB $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    /**
     * Tạo bảng zalo_config.
     */
    private static function create_zalo_config_table() {
        global $wpdb;
        $table_name      = $wpdb->prefix . 'checkin_mkt192_zalo_config';
        $charset_collate = 'CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci';

        $sql = "CREATE TABLE $table_name (
            id INT(11) NOT NULL AUTO_INCREMENT,
            app_id VARCHAR(255) NOT NULL,
            app_secret VARCHAR(255) NOT NULL,
            access_token TEXT NOT NULL,
            refresh_token TEXT NOT NULL,
            oa_id VARCHAR(100) DEFAULT NULL,
            oa_name VARCHAR(255) DEFAULT NULL,
            is_verified TINYINT(1) DEFAULT 0,
            num_follower INT(11) DEFAULT 0,
            package_name VARCHAR(100) DEFAULT NULL,
            package_valid_through_date DATE DEFAULT NULL,
            updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) ENGINE=InnoDB $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    /**
     * Tạo bảng manager_schedules.
     */
    private static function create_manager_schedules_table() {
        global $wpdb;
        $table_name      = $wpdb->prefix . 'checkin_mkt192_manager_schedules';
        $charset_collate = 'CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci';

        $sql = "CREATE TABLE $table_name (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            staff_name VARCHAR(255) NOT NULL,
            branch VARCHAR(255) NOT NULL,
            start_date DATE DEFAULT NULL,
            end_date DATE DEFAULT NULL,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY unique_schedule (staff_name, start_date)
        ) ENGINE=InnoDB $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    /**
     * DEPRECATED: Thêm branch column vào các bảng hiện có (Migration).
     * Đã không còn sử dụng - tất cả các site đều có branch_id rồi.
     */
    /*
    public static function add_branch_column_to_tables() {
        global $wpdb;

        // Danh sách 15 bảng cần thêm branch column (manager_schedules đã có)
        $tables = [
            $wpdb->prefix . 'checkin_mkt192_staff',
            $wpdb->prefix . 'checkin_mkt192_service_data',
            $wpdb->prefix . 'checkin_mkt192_products',
            $wpdb->prefix . 'checkin_mkt192_service_groups',
            $wpdb->prefix . 'checkin_mkt192_ctkm_settings',
            $wpdb->prefix . 'checkin_mkt192_salary_level_settings',
            $wpdb->prefix . 'checkin_mkt192_staff_roles',
            $wpdb->prefix . 'checkin_mkt192_shiftsettings',
            $wpdb->prefix . 'checkin_mkt192_penalty_settings',
            $wpdb->prefix . 'checkin_mkt192_advance_salary',
            $wpdb->prefix . 'checkin_mkt192_cashier_salary',
            $wpdb->prefix . 'checkin_mkt192_hairdresser_salary',
            $wpdb->prefix . 'checkin_mkt192_kpi_settings',
            $wpdb->prefix . 'checkin_mkt192_kpi_results',
            $wpdb->prefix . 'bookingmkt192_booking_data',
        ];

        foreach ($tables as $table_name) {
            // Kiểm tra xem column 'branch' đã tồn tại chưa
            $column_exists = $wpdb->get_results(
                "SELECT * FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_SCHEMA = DATABASE()
                AND TABLE_NAME = '$table_name'
                AND COLUMN_NAME = 'branch'"
            );

            if (empty($column_exists)) {
                // Thêm column branch (không thể dùng CHARACTER SET với ALTER TABLE ADD COLUMN)
                $wpdb->query("ALTER TABLE $table_name ADD COLUMN branch VARCHAR(255) DEFAULT ''");

                // Thêm KEY idx_branch
                $wpdb->query("ALTER TABLE $table_name ADD KEY idx_branch (branch)");

                error_log("Checkin MKT192: Added branch column to $table_name");
            }
        }
    }
    */

    /**
     * DEPRECATED: Thêm index cho cột branch trong tất cả các bảng.
     * Đã không còn sử dụng - tất cả các site đều có branch_id rồi.
     */
    /*
    public static function add_branch_indexes() {
        global $wpdb;

        // Danh sách tất cả 16 bảng (bao gồm manager_schedules và booking_data)
        $tables = [
            $wpdb->prefix . 'checkin_mkt192_staff',
            $wpdb->prefix . 'checkin_mkt192_service_data',
            $wpdb->prefix . 'checkin_mkt192_products',
            $wpdb->prefix . 'checkin_mkt192_service_groups',
            $wpdb->prefix . 'checkin_mkt192_ctkm_settings',
            $wpdb->prefix . 'checkin_mkt192_salary_level_settings',
            $wpdb->prefix . 'checkin_mkt192_staff_roles',
            $wpdb->prefix . 'checkin_mkt192_shiftsettings',
            $wpdb->prefix . 'checkin_mkt192_penalty_settings',
            $wpdb->prefix . 'checkin_mkt192_advance_salary',
            $wpdb->prefix . 'checkin_mkt192_cashier_salary',
            $wpdb->prefix . 'checkin_mkt192_hairdresser_salary',
            $wpdb->prefix . 'checkin_mkt192_kpi_settings',
            $wpdb->prefix . 'checkin_mkt192_kpi_results',
            $wpdb->prefix . 'checkin_mkt192_manager_schedules',
            $wpdb->prefix . 'bookingmkt192_booking_data',
        ];

        foreach ($tables as $table_name) {
            // Kiểm tra xem cột branch có tồn tại không
            $column_exists = $wpdb->get_results(
                "SELECT * FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_SCHEMA = DATABASE()
                AND TABLE_NAME = '$table_name'
                AND COLUMN_NAME = 'branch'"
            );

            // Nếu cột không tồn tại, bỏ qua
            if (empty($column_exists)) {
                continue;
            }

            // Kiểm tra xem index đã tồn tại chưa
            $index_exists = $wpdb->get_results(
                "SELECT * FROM INFORMATION_SCHEMA.STATISTICS
                WHERE TABLE_SCHEMA = DATABASE()
                AND TABLE_NAME = '$table_name'
                AND COLUMN_NAME = 'branch'
                AND INDEX_NAME = 'idx_branch'"
            );

            if (empty($index_exists)) {
                $wpdb->query("ALTER TABLE $table_name ADD KEY idx_branch (branch)");
                error_log("Checkin MKT192: Added idx_branch index to $table_name");
            }
        }
    }
    */

    /**
     * Thêm branch_id column vào các bảng hiện có nếu chưa tồn tại.
     * Đảm bảo tất cả các site đều có branch_id column trong các bảng cần thiết.
     * Safe to run multiple times - chỉ thêm column nếu chưa có.
     * Sử dụng option để track đã chạy migration chưa để tránh query mỗi request.
     */
    public static function add_branch_id_column_to_tables() {
        // Kiểm tra xem đã chạy migration này chưa
        $migration_version = get_option('checkin_mkt192_branch_id_migration', '0');
        if (version_compare($migration_version, '2.0', '>=')) {
            return; // Đã chạy migration rồi
        }

        global $wpdb;

        // Danh sách tất cả bảng cần thêm branch_id column
        $tables = [
            $wpdb->prefix . 'checkin_mkt192_staff',
            $wpdb->prefix . 'checkin_mkt192_service_data',
            $wpdb->prefix . 'checkin_mkt192_products',
            $wpdb->prefix . 'checkin_mkt192_service_groups',
            $wpdb->prefix . 'checkin_mkt192_ctkm_settings',
            $wpdb->prefix . 'checkin_mkt192_salary_level_settings',
            $wpdb->prefix . 'checkin_mkt192_staff_roles',
            $wpdb->prefix . 'checkin_mkt192_shiftsettings',
            $wpdb->prefix . 'checkin_mkt192_penalty_settings',
            $wpdb->prefix . 'checkin_mkt192_advance_salary',
            $wpdb->prefix . 'checkin_mkt192_cashier_salary',
            $wpdb->prefix . 'checkin_mkt192_hairdresser_salary',
            $wpdb->prefix . 'checkin_mkt192_kpi_settings',
            $wpdb->prefix . 'checkin_mkt192_kpi_results',
            $wpdb->prefix . 'checkin_mkt192_manager_schedules',
            $wpdb->prefix . 'bookingmkt192_booking_data',
            $wpdb->prefix . 'checkin_mkt192_invoices_data',
            $wpdb->prefix . 'checkin_mkt192_invoices_data_detail',
            $wpdb->prefix . 'bookingmkt192_customer_data',
            $wpdb->prefix . 'checkin_mkt192_inventory_transactions',
            $wpdb->prefix . 'checkin_mkt192_inventory_checks',
        ];

        $added_count = 0;
        foreach ($tables as $table_name) {
            // Kiểm tra xem bảng có tồn tại không
            $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table_name'");
            if (!$table_exists) {
                continue;
            }

            // Kiểm tra xem column 'branch_id' đã tồn tại chưa
            $column_exists = $wpdb->get_results(
                "SELECT * FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_SCHEMA = DATABASE()
                AND TABLE_NAME = '$table_name'
                AND COLUMN_NAME = 'branch_id'"
            );

            if (empty($column_exists)) {
                // Thêm column branch_id
                $wpdb->query("ALTER TABLE $table_name ADD COLUMN branch_id INT(11) DEFAULT 0 COMMENT 'ID chi nhánh'");

                // Thêm KEY idx_branch_id (bỏ qua lỗi nếu đã tồn tại)
                $wpdb->query("ALTER TABLE $table_name ADD KEY idx_branch_id (branch_id)");

                error_log("Checkin MKT192: Added branch_id column to $table_name");
                $added_count++;
            }
        }

        // Đánh dấu đã chạy migration
        update_option('checkin_mkt192_branch_id_migration', '2.0');

        if ($added_count > 0) {
            error_log("Checkin MKT192: branch_id migration completed - added to $added_count tables");
        }

        // Populate branch_id cho staff table từ column branch (JSON)
        self::populate_staff_branch_id();

        // Thêm column branch_ids cho salary_level_settings (multi-branch support)
        self::add_branch_ids_column_to_salary_levels();
    }

    /**
     * Thêm column branch_ids (TEXT/JSON) cho bảng salary_level_settings.
     * Cho phép một cấp bậc áp dụng cho nhiều chi nhánh.
     */
    public static function add_branch_ids_column_to_salary_levels() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'checkin_mkt192_salary_level_settings';

        // Kiểm tra bảng tồn tại
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table_name'");
        if (!$table_exists) {
            return;
        }

        // Kiểm tra column branch_ids đã tồn tại chưa
        $column_exists = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_SCHEMA = %s
                AND TABLE_NAME = %s
                AND COLUMN_NAME = 'branch_ids'",
                DB_NAME,
                $table_name
            )
        );

        if (!$column_exists) {
            // Thêm column branch_ids
            $wpdb->query("ALTER TABLE $table_name ADD COLUMN branch_ids TEXT DEFAULT NULL COMMENT 'JSON array of branch IDs'");
            error_log("Checkin MKT192: Added branch_ids column to $table_name");

            // Migrate data từ branch_id sang branch_ids
            $wpdb->query("UPDATE $table_name SET branch_ids = CONCAT('[', branch_id, ']') WHERE branch_id > 0 AND (branch_ids IS NULL OR branch_ids = '')");
            error_log("Checkin MKT192: Migrated branch_id to branch_ids for existing records in $table_name");
        }
    }

    /**
     * Populate branch_id cho staff từ column branch (JSON).
     * Chạy một lần để đảm bảo tất cả staff có branch_id được set đúng.
     */
    public static function populate_staff_branch_id() {
        global $wpdb;
        $table_staff = $wpdb->prefix . 'checkin_mkt192_staff';

        // Kiểm tra bảng tồn tại
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table_staff'");
        if (!$table_exists) {
            return;
        }

        // Lấy tất cả staff có branch_id = 0 nhưng có branch không rỗng
        $staff_to_update = $wpdb->get_results(
            "SELECT id, branch FROM $table_staff WHERE branch_id = 0 AND branch IS NOT NULL AND branch != ''"
        );

        if (empty($staff_to_update)) {
            return;
        }

        $updated_count = 0;
        foreach ($staff_to_update as $staff) {
            $branch_json = $staff->branch;

            // Parse branch JSON để lấy primary branch_id
            $branch_ids = json_decode($branch_json, true);
            if (!is_array($branch_ids) || empty($branch_ids)) {
                // Nếu không phải JSON hợp lệ, thử parse như số đơn lẻ
                $branch_id = intval($branch_json);
            } else {
                // Lấy phần tử đầu tiên làm primary branch
                $branch_id = intval($branch_ids[0]);
            }

            if ($branch_id > 0) {
                $wpdb->update(
                    $table_staff,
                    ['branch_id' => $branch_id],
                    ['id'        => $staff->id],
                    ['%d'],
                    ['%d']
                );
                $updated_count++;
            }
        }

        if ($updated_count > 0) {
            error_log("Checkin MKT192: Populated branch_id for $updated_count staff records");
        }
    }

    /**
     * DEPRECATED: Populate dữ liệu branch từ bảng locations vào tất cả các bảng có branch column.
     * Gọi khi plugin được kích hoạt để migrate dữ liệu từ phiên bản cũ.
     * Đã không còn sử dụng - tất cả các site đều có branch_id rồi.
     */
    /*
    public static function populate_branch_data() {
        global $wpdb;

        // Lấy danh sách tất cả chi nhánh từ bảng locations
        $table_locations = $wpdb->prefix . 'checkin_mkt192_locations';
        $locations       = $wpdb->get_results("SELECT id, location_name FROM $table_locations ORDER BY id ASC", ARRAY_A);

        if (empty($locations)) {
            error_log('Checkin MKT192: No locations found in locations table');
            return;
        }

        // Lấy ID chi nhánh đầu tiên (mặc định) - CHI NHÁNH CHÍNH
        $default_branch_id   = isset($locations[0]['id']) ? intval($locations[0]['id']) : 0;
        $default_branch_name = isset($locations[0]['location_name']) ? $locations[0]['location_name'] : '';

        if ($default_branch_id <= 0) {
            error_log('Checkin MKT192: Default branch ID is invalid');
            return;
        }

        // Danh sách tất cả bảng có cột branch_id
        $tables_to_update = [
            $wpdb->prefix . 'checkin_mkt192_staff',
            $wpdb->prefix . 'checkin_mkt192_service_data',
            $wpdb->prefix . 'checkin_mkt192_products',
            $wpdb->prefix . 'checkin_mkt192_service_groups',
            $wpdb->prefix . 'checkin_mkt192_ctkm_settings',
            $wpdb->prefix . 'checkin_mkt192_salary_level_settings',
            $wpdb->prefix . 'checkin_mkt192_staff_roles',
            $wpdb->prefix . 'checkin_mkt192_shiftsettings',
            $wpdb->prefix . 'checkin_mkt192_penalty_settings',
            $wpdb->prefix . 'checkin_mkt192_advance_salary',
            $wpdb->prefix . 'checkin_mkt192_cashier_salary',
            $wpdb->prefix . 'checkin_mkt192_hairdresser_salary',
            $wpdb->prefix . 'checkin_mkt192_kpi_settings',
            $wpdb->prefix . 'checkin_mkt192_kpi_results',
            $wpdb->prefix . 'checkin_mkt192_manager_schedules',
            $wpdb->prefix . 'bookingmkt192_booking_data',
            $wpdb->prefix . 'checkin_mkt192_invoices_data',
            $wpdb->prefix . 'checkin_mkt192_invoices_data_detail',
            $wpdb->prefix . 'bookingmkt192_customer_data',
            $wpdb->prefix . 'checkin_mkt192_inventory_transactions',
            $wpdb->prefix . 'checkin_mkt192_inventory_checks',
        ];

        // Cập nhật branch_id cho tất cả các bảng
        foreach ($tables_to_update as $table_name) {
            // Kiểm tra xem bảng có tồn tại không
            $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table_name'");
            if (!$table_exists) {
                continue;
            }

            // Kiểm tra xem cột branch_id có tồn tại không
            $column_exists = $wpdb->get_results(
                "SELECT * FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_SCHEMA = DATABASE()
                AND TABLE_NAME = '$table_name'
                AND COLUMN_NAME = 'branch_id'"
            );

            if (empty($column_exists)) {
                error_log("Checkin MKT192: Table $table_name does not have branch_id column");
                continue;
            }

            // Đếm số record có branch_id = 0 hoặc NULL
            $empty_branch_count = $wpdb->get_var("SELECT COUNT(*) FROM $table_name WHERE branch_id = 0 OR branch_id IS NULL");

            if ($empty_branch_count > 0) {
                // Cập nhật tất cả records có branch_id rỗng với ID chi nhánh đầu tiên
                $updated = $wpdb->query($wpdb->prepare(
                    "UPDATE $table_name SET branch_id = %d WHERE branch_id = 0 OR branch_id IS NULL",
                    $default_branch_id
                ));

                error_log("Checkin MKT192: Updated $updated records in $table_name with branch_id = $default_branch_id (Branch: '$default_branch_name')");
            } else {
                error_log("Checkin MKT192: No empty branch_id records found in $table_name");
            }
        }

        error_log("Checkin MKT192: Branch data population completed using default branch_id: $default_branch_id (Branch: '$default_branch_name')");
    }
    */

    /**
     * DEPRECATED: Add new fields to locations table for branch management.
     * This migration adds: address, google_map_link, and is_main_branch columns.
     * Đã không còn sử dụng - tất cả các site đều có branch_id rồi.
     */
    /*
    public static function add_branch_management_fields() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'checkin_mkt192_locations';

        // Check if columns exist before adding them
        $columns          = $wpdb->get_results("SHOW COLUMNS FROM $table_name");
        $existing_columns = array_column($columns, 'Field');

        // Add address column
        if (!in_array('address', $existing_columns)) {
            $wpdb->query("ALTER TABLE `$table_name` ADD COLUMN `address` TEXT DEFAULT NULL COMMENT 'Địa chỉ chi nhánh' AFTER `location_name`");
            error_log("Checkin MKT192: Added 'address' column to locations table");
        }

        // Add google_map_link column
        if (!in_array('google_map_link', $existing_columns)) {
            $wpdb->query("ALTER TABLE `$table_name` ADD COLUMN `google_map_link` TEXT DEFAULT NULL COMMENT 'Link Google Maps' AFTER `address`");
            error_log("Checkin MKT192: Added 'google_map_link' column to locations table");
        }

        // Add is_main_branch column
        if (!in_array('is_main_branch', $existing_columns)) {
            $wpdb->query("ALTER TABLE `$table_name` ADD COLUMN `is_main_branch` TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'Chi nhánh chính' AFTER `google_map_link`");
            error_log("Checkin MKT192: Added 'is_main_branch' column to locations table");
        }

        error_log('Checkin MKT192: Branch management fields migration completed');
    }
    */

    /**
     * Add uniform_fee column to cashier_salary and hairdresser_salary tables.
     * This migration adds the uniform_fee column for tracking uniform fees in salary calculations.
     */
    public static function add_uniform_fee_column() {
        global $wpdb;

        // Add uniform_fee to cashier_salary table
        $cashier_table    = $wpdb->prefix . 'checkin_mkt192_cashier_salary';
        $cashier_columns  = $wpdb->get_results("SHOW COLUMNS FROM $cashier_table");
        $cashier_existing = array_column($cashier_columns, 'Field');

        if (!in_array('uniform_fee', $cashier_existing)) {
            $wpdb->query("ALTER TABLE `$cashier_table` ADD COLUMN `uniform_fee` DECIMAL(15,2) DEFAULT 0.00 AFTER `advance_salary`");
            error_log("Checkin MKT192: Added 'uniform_fee' column to cashier_salary table");
        }

        // Add uniform_fee to hairdresser_salary table
        $hairdresser_table    = $wpdb->prefix . 'checkin_mkt192_hairdresser_salary';
        $hairdresser_columns  = $wpdb->get_results("SHOW COLUMNS FROM $hairdresser_table");
        $hairdresser_existing = array_column($hairdresser_columns, 'Field');

        if (!in_array('uniform_fee', $hairdresser_existing)) {
            $wpdb->query("ALTER TABLE `$hairdresser_table` ADD COLUMN `uniform_fee` DECIMAL(15,2) DEFAULT 0.00 AFTER `advance_salary`");
            error_log("Checkin MKT192: Added 'uniform_fee' column to hairdresser_salary table");
        }

        // Add product_count_total to hairdresser_salary table if not exists
        if (!in_array('product_count_total', $hairdresser_existing)) {
            $wpdb->query("ALTER TABLE `$hairdresser_table` ADD COLUMN `product_count_total` INT(11) NOT NULL DEFAULT 0 AFTER `product_total`");
            error_log("Checkin MKT192: Added 'product_count_total' column to hairdresser_salary table");
        }

        error_log('Checkin MKT192: Uniform fee column migration completed');
    }

    /**
     * Tạo bảng approval_requests cho các loại đơn xin phép.
     */
    private static function create_approval_requests_table() {
        global $wpdb;
        $table_name      = $wpdb->prefix . 'checkin_mkt192_approval_requests';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $table_name (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            request_id varchar(50) NOT NULL,
            request_type varchar(50) NOT NULL,
            staff_name varchar(191) NOT NULL,
            staff_id bigint(20) unsigned NOT NULL,
            request_date date NOT NULL,
            reason text NOT NULL,
            status varchar(20) DEFAULT 'pending',
            approved_by varchar(191) DEFAULT NULL,
            approved_at datetime DEFAULT NULL,
            reject_reason text,
            late_early_type varchar(20) DEFAULT NULL,
            late_early_date date DEFAULT NULL,
            late_early_minutes int(11) DEFAULT NULL,
            leave_start_date date DEFAULT NULL,
            leave_end_date date DEFAULT NULL,
            leave_total_days int(11) DEFAULT NULL,
            leave_type varchar(20) DEFAULT NULL,
            overtime_date date DEFAULT NULL,
            overtime_start_time time DEFAULT NULL,
            overtime_end_time time DEFAULT NULL,
            overtime_hours decimal(5,2) DEFAULT NULL,
            advance_amount decimal(15,2) DEFAULT NULL,
            lark_message_id varchar(255) DEFAULT NULL,
            branch varchar(255) DEFAULT '',
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY request_id (request_id),
            KEY idx_staff_name (staff_name),
            KEY idx_staff_id (staff_id),
            KEY idx_request_type (request_type),
            KEY idx_status (status),
            KEY idx_created_at (created_at),
            KEY idx_branch (branch)
        ) $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    /**
     * Tạo bảng push_subscriptions để lưu thông tin đăng ký push notifications.
     */
    private static function create_push_subscriptions_table() {
        global $wpdb;
        $table_name      = $wpdb->prefix . 'checkin_mkt192_push_subscriptions';
        $charset_collate = 'CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci';

        $sql = "CREATE TABLE $table_name (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT(20) UNSIGNED DEFAULT NULL COMMENT 'WordPress user ID',
            player_id VARCHAR(255) NOT NULL COMMENT 'OneSignal Player ID',
            platform VARCHAR(50) NOT NULL DEFAULT 'web' COMMENT 'Platform: web, android_web, ios_web, etc.',
            device_info TEXT DEFAULT NULL COMMENT 'Browser/Device info JSON',
            is_active TINYINT(1) NOT NULL DEFAULT 1 COMMENT 'Subscription active status',
            notification_types TEXT DEFAULT NULL COMMENT 'JSON array of enabled notification types',
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY player_id (player_id),
            KEY idx_user_id (user_id),
            KEY idx_platform (platform),
            KEY idx_is_active (is_active)
        ) ENGINE=InnoDB $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    /**
     * Tạo bảng checkin_mkt192_notifications để lưu thông báo trang chủ và nhân viên.
     */
    private static function create_notifications_table() {
        global $wpdb;
        $table_name      = $wpdb->prefix . 'checkin_mkt192_notifications';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            type varchar(50) NOT NULL DEFAULT 'homepage',
            title varchar(255) NOT NULL,
            content text NOT NULL,
            media_url varchar(500) DEFAULT NULL,
            media_type varchar(20) DEFAULT NULL,
            aspect_ratio varchar(10) DEFAULT '16:9',
            link varchar(500) DEFAULT NULL,
            status varchar(50) NOT NULL DEFAULT 'draft',
            start_date datetime DEFAULT NULL,
            end_date datetime DEFAULT NULL,
            sort_order int(11) DEFAULT 0,
            slide_duration int(11) DEFAULT 5,
            branches longtext DEFAULT NULL,
            send_push tinyint(1) DEFAULT 1,
            show_in_app tinyint(1) DEFAULT 1,
            views int(11) DEFAULT 0,
            created_by bigint(20) unsigned NOT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY type_status_idx (type, status),
            KEY status_dates_idx (status, start_date, end_date)
        ) $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    /**
     * Tạo bảng checkin_mkt192_notification_views để theo dõi người dùng đã xem thông báo.
     */
    private static function create_notification_views_table() {
        global $wpdb;
        $table_name      = $wpdb->prefix . 'checkin_mkt192_notification_views';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            notification_id bigint(20) unsigned NOT NULL,
            user_id bigint(20) unsigned NOT NULL,
            viewed_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY notification_user_idx (notification_id, user_id),
            KEY notification_id_idx (notification_id),
            KEY user_id_idx (user_id)
        ) $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
    }

    /**
     * Tạo bảng cash_shifts và cash_transactions cho quản lý ca thu ngân.
     */
    private static function create_cash_shift_tables() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();

        // Bảng ca thu ngân
        $table_shifts = $wpdb->prefix . 'checkin_mkt192_cash_shifts';
        $sql_shifts   = "CREATE TABLE IF NOT EXISTS $table_shifts (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            staff_id BIGINT(20) UNSIGNED NOT NULL,
            staff_name VARCHAR(255) NOT NULL,
            branch_id BIGINT(20) UNSIGNED DEFAULT 0,
            opening_balance DECIMAL(15,0) NOT NULL DEFAULT 0,
            opening_transfer_balance DECIMAL(15,0) NOT NULL DEFAULT 0,
            sales_revenue DECIMAL(15,0) NOT NULL DEFAULT 0,
            total_receipts DECIMAL(15,0) NOT NULL DEFAULT 0,
            total_payments DECIMAL(15,0) NOT NULL DEFAULT 0,
            closing_balance DECIMAL(15,0) DEFAULT NULL,
            actual_balance DECIMAL(15,0) DEFAULT NULL,
            difference_reason TEXT DEFAULT NULL,
            status ENUM('open', 'closed', 'handover_pending', 'handover_completed') NOT NULL DEFAULT 'open',
            handover_to BIGINT(20) UNSIGNED DEFAULT NULL,
            handover_to_name VARCHAR(255) DEFAULT NULL,
            handover_method ENUM('cash', 'transfer') DEFAULT NULL,
            note TEXT DEFAULT NULL,
            start_time DATETIME NOT NULL,
            sales_start_time DATETIME DEFAULT NULL,
            end_time DATETIME DEFAULT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_staff_id (staff_id),
            KEY idx_branch_id (branch_id),
            KEY idx_status (status),
            KEY idx_start_time (start_time)
        ) $charset_collate;";

        // Bảng phiếu thu/chi
        $table_transactions = $wpdb->prefix . 'checkin_mkt192_cash_transactions';
        $sql_transactions   = "CREATE TABLE IF NOT EXISTS $table_transactions (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            shift_id BIGINT(20) UNSIGNED NOT NULL,
            branch_id BIGINT(20) UNSIGNED DEFAULT 0,
            type ENUM('receipt', 'payment') NOT NULL,
            amount DECIMAL(15,0) NOT NULL,
            reason VARCHAR(255) NOT NULL,
            note TEXT DEFAULT NULL,
            created_by BIGINT(20) UNSIGNED NOT NULL,
            created_by_name VARCHAR(255) NOT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_shift_id (shift_id),
            KEY idx_branch_id (branch_id),
            KEY idx_type (type)
        ) $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql_shifts);
        dbDelta($sql_transactions);
    }
}
