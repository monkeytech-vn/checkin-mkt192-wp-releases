<?php
function checkin_pro_is_activated() {
    $license_key = get_option('checkin_plugin_license_key');
    if (!$license_key) return false;

    $response = wp_remote_post('https://vangroupbarbershop.store/wp-content/plugins/check-license.php', [
        'body' => [
            'license_key' => $license_key,
            'site_url' => home_url(),
        ],
    ]);

    if (is_wp_error($response)) return false;

    $body = json_decode(wp_remote_retrieve_body($response), true);
    return isset($body['status']) && $body['status'] === 'valid';
}

if (checkin_pro_is_activated()) {
    define('CHECKIN_PRO_VERSION', true);
    require_once plugin_dir_path(__FILE__) . '../pro/pro-features.php';
}
?>