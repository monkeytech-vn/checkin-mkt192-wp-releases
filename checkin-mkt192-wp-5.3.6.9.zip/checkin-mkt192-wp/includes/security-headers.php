<?php

/**
 * Security Headers for Checkin MKT192 WP Plugin
 *
 * Adds security-related HTTP headers to protect against common attacks
 *
 * @package Checkin_MKT192_WP
 * @since 5.1.7.4.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Add security headers to REST API responses
 */
add_filter('rest_post_dispatch', function($response, $server, $request) {
    // Only add headers for our plugin's endpoints
    $route = $request->get_route();
    if (strpos($route, '/vg/v1/') !== 0 && strpos($route, '/checkin-mkt192/') !== 0) {
        return $response;
    }

    // Content-Type Options - Prevent MIME type sniffing
    $response->header('X-Content-Type-Options', 'nosniff');

    // Frame Options - Prevent clickjacking
    $response->header('X-Frame-Options', 'SAMEORIGIN');

    // XSS Protection - Legacy but still useful for older browsers
    $response->header('X-XSS-Protection', '1; mode=block');

    // Referrer Policy - Control referrer information
    $response->header('Referrer-Policy', 'strict-origin-when-cross-origin');

    // Remove server info
    $response->header('X-Powered-By', '');

    return $response;
}, 10, 3);

/**
 * Add security headers to frontend pages
 */
add_action('send_headers', function() {
    // Only on plugin pages
    if (!is_page() || !has_shortcode(get_post()->post_content ?? '', 'checkin_')) {
        return;
    }

    // Content Security Policy
    $csp = implode('; ', [
        "default-src 'self'",
        "script-src 'self' 'unsafe-inline' 'unsafe-eval' https://apis.google.com https://connect.facebook.net https://www.google.com https://www.gstatic.com",
        "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
        "img-src 'self' data: blob: https: http:",
        "font-src 'self' https://fonts.gstatic.com",
        "connect-src 'self' https://apis.google.com https://graph.facebook.com https://*.lark.com https://*.feishu.cn",
        "frame-src 'self' https://accounts.google.com https://www.facebook.com",
        "object-src 'none'",
        "base-uri 'self'"
    ]);

    header("Content-Security-Policy: $csp");
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('X-XSS-Protection: 1; mode=block');
    header('Referrer-Policy: strict-origin-when-cross-origin');

    // Remove PHP version
    header_remove('X-Powered-By');
});

/**
 * Sanitize error messages for production
 * Removes sensitive database/system info from error responses
 */
function checkin_mkt192_sanitize_error_message($message, $log_original = true) {
    // Check if in debug mode
    if (defined('WP_DEBUG') && WP_DEBUG) {
        return $message;
    }

    // Patterns that indicate sensitive info
    $sensitive_patterns = [
        '/\bwpdb\b/i',
        '/\bMySQL\b/i',
        '/\bSQL\b/i',
        '/\btable\s+[\w_]+/i',
        '/\bcolumn\s+[\w_]+/i',
        '/\/var\/www\//i',
        '/\/home\/\w+\//i',
        '/[A-Za-z]:\\\\/',
        '/\bstack trace\b/i',
        '/\bFatal error\b/i',
        '/\bWarning\b/i',
        '/\bin\s+[\w\/\\\\]+\.php\s+on\s+line\s+\d+/i',
    ];

    foreach ($sensitive_patterns as $pattern) {
        if (preg_match($pattern, $message)) {
            // Log original error for debugging
            if ($log_original) {
                error_log('[CHECKIN_MKT192] Sanitized error: ' . $message);
            }

            // Return generic message
            return 'Đã xảy ra lỗi. Vui lòng thử lại hoặc liên hệ hỗ trợ.';
        }
    }

    return $message;
}

/**
 * Filter REST API error responses
 */
add_filter('rest_request_after_callbacks', function($response, $handler, $request) {
    if (is_wp_error($response)) {
        $error_message = $response->get_error_message();
        $sanitized     = checkin_mkt192_sanitize_error_message($error_message);

        if ($sanitized !== $error_message) {
            $response = new WP_Error(
                $response->get_error_code(),
                $sanitized,
                $response->get_error_data()
            );
        }
    }

    return $response;
}, 10, 3);