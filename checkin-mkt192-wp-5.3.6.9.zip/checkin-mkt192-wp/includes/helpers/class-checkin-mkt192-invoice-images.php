<?php

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class Checkin_MKT192_Invoice_Images
 *
 * Nguồn duy nhất (single source of truth) cho mọi thao tác ghi ảnh vào hoá đơn.
 *
 * Bối cảnh: trường invoices.images từng bị ghi đè mất dữ liệu do nhiều nơi
 * (upload API, cron convert WebP, cron reprocess, PUT /invoices) cùng
 * đọc-sửa-ghi mà không khoá row. Mọi thao tác thêm/xoá URL ảnh phải đi qua
 * class này để đảm bảo atomic (SELECT ... FOR UPDATE trong transaction).
 *
 * Quy ước:
 * - PUT /invoices KHÔNG được phép ghi trường images/image_feedback.
 * - Muốn thêm ảnh: dùng add_urls(). Muốn xoá ảnh (tính năng tương lai):
 *   thêm method remove_urls() tại đây, không thao tác trực tiếp $wpdb.
 */
class Checkin_MKT192_Invoice_Images {

    const FIELD_IMAGES   = 'images';
    const FIELD_FEEDBACK = 'image_feedback';

    /**
     * Parse giá trị lưu trong DB (JSON array hoặc CSV legacy) thành mảng URL.
     *
     * @param string|null $raw
     * @return array
     */
    public static function parse($raw) {
        if (empty($raw)) {
            return [];
        }
        if (str_starts_with($raw, '[')) {
            $list = json_decode($raw, true);
            return is_array($list) ? array_values(array_filter($list)) : [];
        }
        return array_values(array_filter(explode(',', $raw)));
    }

    /**
     * URL có trỏ vào thư mục temp (file sẽ bị cron xoá sau khi convert) không?
     *
     * @param string $url
     * @return bool
     */
    public static function is_temp_url($url) {
        return strpos($url, '/temp/') !== false || strpos($url, '/temp-feedback-image/') !== false;
    }

    /**
     * Thêm URL ảnh vào hoá đơn một cách atomic (row lock, chống lost-update).
     *
     * @param string $invoice_id
     * @param array  $urls       Danh sách URL cần thêm.
     * @param string $field      self::FIELD_IMAGES | self::FIELD_FEEDBACK.
     * @param bool   $strip_temp true = loại bỏ các URL temp hiện có trong DB
     *                           (dùng khi cron đã convert xong sang WebP).
     * @return array|false Danh sách URL cuối cùng trong DB, hoặc false nếu lỗi.
     */
    public static function add_urls($invoice_id, array $urls, $field = self::FIELD_IMAGES, $strip_temp = false) {
        global $wpdb;

        if (!in_array($field, [self::FIELD_IMAGES, self::FIELD_FEEDBACK], true) || empty($invoice_id)) {
            return false;
        }

        $table = $wpdb->prefix . 'checkin_mkt192_invoices_data';

        $wpdb->query('START TRANSACTION');

        // Khoá row đến khi COMMIT để upload API / cron không giẫm lên nhau
        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT invoice_id, {$field} AS field_value FROM {$table} WHERE invoice_id = %s FOR UPDATE",
            $invoice_id
        ));

        if (!$row) {
            $wpdb->query('ROLLBACK');
            return false;
        }

        $list = self::parse($row->field_value);

        if ($strip_temp) {
            $list = array_values(array_filter($list, function($url) {
                return !self::is_temp_url($url);
            }));
        }

        foreach ($urls as $url) {
            if (!in_array($url, $list, true)) {
                $list[] = $url;
            }
        }
        $list = array_values($list);

        $result = $wpdb->update(
            $table,
            [$field       => wp_json_encode($list, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)],
            ['invoice_id' => $invoice_id],
            ['%s'],
            ['%s']
        );

        if ($result === false) {
            $wpdb->query('ROLLBACK');
            return false;
        }

        $wpdb->query('COMMIT');
        return $list;
    }

    /**
     * Đồng bộ danh sách ảnh feedback sang bảng wp_checkin_mkt192_image_feedback
     * (bảng này lưu theo staff_name + feedback_date của hoá đơn).
     *
     * @param string $invoice_id
     * @param array  $final_list Danh sách URL cuối cùng (kết quả add_urls).
     * @return bool
     */
    public static function sync_feedback_table($invoice_id, array $final_list) {
        global $wpdb;

        $invoice_table = $wpdb->prefix . 'checkin_mkt192_invoices_data';
        $created_data  = $wpdb->get_row($wpdb->prepare(
            "SELECT created_user, created_at FROM {$invoice_table} WHERE invoice_id = %s",
            $invoice_id
        ), ARRAY_A);

        if (!$created_data) {
            return false;
        }

        $feedback_table = $wpdb->prefix . 'checkin_mkt192_image_feedback';
        $result = $wpdb->update(
            $feedback_table,
            ['image' => wp_json_encode($final_list, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)],
            [
                'staff_name'    => $created_data['created_user'],
                'feedback_date' => $created_data['created_at']
            ],
            ['%s'],
            ['%s', '%s']
        );

        return $result !== false;
    }
}
