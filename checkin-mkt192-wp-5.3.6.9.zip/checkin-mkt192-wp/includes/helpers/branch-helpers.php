<?php

/**
 * Branch Helper Functions
 *
 * Tập trung các helper functions liên quan đến xử lý chi nhánh (branch).
 *
 * === GIẢI THÍCH CẤU TRÚC DỮ LIỆU ===
 *
 * 1. Khi site BẬT chế độ đa chi nhánh (checkin_branch_mode_enabled = '1'):
 *    - `branch` (VARCHAR/JSON): Danh sách TẤT CẢ các chi nhánh mà nhân viên có tham gia
 *      Lưu dưới dạng JSON array, ví dụ: "[1,2,3]"
 *      → Dùng khi cần biết nhân viên có thể làm việc ở NHỮNG CHI NHÁNH NÀO
 *
 *    - `branch_id` (INT): Chi nhánh CHÍNH của nhân viên
 *      Được chọn từ checkbox "Chi nhánh chính" ở trang admin settings
 *      → Dùng khi cần xác định CHI NHÁNH MẶC ĐỊNH của nhân viên (gửi thông báo, tạo dữ liệu...)
 *
 * 2. Khi site KHÔNG bật chế độ đa chi nhánh (checkin_branch_mode_enabled = '0'):
 *    - Hoàn toàn KHÔNG quan tâm đến branch/branch_id
 *    - Tất cả nhân viên đều thuộc cùng một chi nhánh (không phân biệt)
 *    - Các query không cần filter theo branch_id
 *
 * === NGUYÊN TẮC SỬ DỤNG ===
 *
 * - Dùng `checkin_mkt192_is_multi_branch_enabled()` để kiểm tra chế độ đa chi nhánh
 * - Dùng `checkin_mkt192_get_staff_primary_branch_id()` để lấy chi nhánh CHÍNH
 * - Dùng `checkin_mkt192_get_staff_all_branch_ids()` để lấy TẤT CẢ chi nhánh
 * - Dùng `checkin_mkt192_staff_belongs_to_branch()` để kiểm tra nhân viên có thuộc chi nhánh không
 *
 * @package Checkin_MKT192
 * @since 2.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Kiểm tra xem site có bật chế độ đa chi nhánh hay không
 *
 * @return bool True nếu đa chi nhánh được bật
 */
function checkin_mkt192_is_multi_branch_enabled() {
    return get_option('checkin_branch_mode_enabled', '0') === '1';
}

/**
 * Lấy chi nhánh CHÍNH (primary) của nhân viên từ bảng staff
 *
 * Chi nhánh chính được lưu trong cột `branch_id` - đây là chi nhánh mặc định
 * mà nhân viên được gán khi tạo dữ liệu mới (invoice, booking, etc.)
 *
 * @param int|null $user_id WordPress user ID. Nếu null, lấy user hiện tại
 * @return int Branch ID (0 nếu không có hoặc chế độ đa chi nhánh tắt)
 */
function checkin_mkt192_get_staff_primary_branch_id($user_id = null) {
    // Nếu chế độ đa chi nhánh tắt, không cần quan tâm branch
    if (!checkin_mkt192_is_multi_branch_enabled()) {
        return 0;
    }

    if ($user_id === null) {
        $user_id = get_current_user_id();
    }

    if (!$user_id) {
        return 0;
    }

    global $wpdb;
    $staff = $wpdb->get_row($wpdb->prepare(
        "SELECT branch, branch_id FROM {$wpdb->prefix}checkin_mkt192_staff WHERE user_id = %d LIMIT 1",
        $user_id
    ));

    if (!$staff) {
        return 0;
    }

    // Ưu tiên branch_id (chi nhánh chính)
    if (isset($staff->branch_id) && intval($staff->branch_id) > 0) {
        return intval($staff->branch_id);
    }

    // Fallback: Lấy phần tử đầu tiên từ branch JSON làm chi nhánh chính
    if (!empty($staff->branch)) {
        $branch_ids = json_decode($staff->branch, true);
        if (is_array($branch_ids) && !empty($branch_ids)) {
            return intval($branch_ids[0]);
        }
        // Nếu branch là số đơn lẻ (legacy)
        if (is_numeric($staff->branch)) {
            return intval($staff->branch);
        }
    }

    return 0;
}

/**
 * Lấy DANH SÁCH TẤT CẢ các chi nhánh mà nhân viên có tham gia
 *
 * Danh sách này được lưu trong cột `branch` dưới dạng JSON array
 * Dùng khi cần biết nhân viên có thể làm việc ở những chi nhánh nào
 *
 * @param int|null $user_id WordPress user ID. Nếu null, lấy user hiện tại
 * @return array Mảng các branch ID (rỗng nếu không có hoặc chế độ đa chi nhánh tắt)
 */
function checkin_mkt192_get_staff_all_branch_ids($user_id = null) {
    // Nếu chế độ đa chi nhánh tắt, không cần quan tâm branch
    if (!checkin_mkt192_is_multi_branch_enabled()) {
        return [];
    }

    if ($user_id === null) {
        $user_id = get_current_user_id();
    }

    if (!$user_id) {
        return [];
    }

    global $wpdb;
    $staff = $wpdb->get_row($wpdb->prepare(
        "SELECT branch, branch_id FROM {$wpdb->prefix}checkin_mkt192_staff WHERE user_id = %d LIMIT 1",
        $user_id
    ));

    if (!$staff) {
        return [];
    }

    $branch_ids = [];

    // Parse branch JSON
    if (!empty($staff->branch)) {
        $decoded = json_decode($staff->branch, true);
        if (is_array($decoded)) {
            $branch_ids = array_map('intval', $decoded);
        } elseif (is_numeric($staff->branch)) {
            $branch_ids = [intval($staff->branch)];
        }
    }

    // Fallback: nếu branch trống nhưng có branch_id
    if (empty($branch_ids) && isset($staff->branch_id) && intval($staff->branch_id) > 0) {
        $branch_ids = [intval($staff->branch_id)];
    }

    return array_unique(array_filter($branch_ids));
}

/**
 * Kiểm tra xem nhân viên có thuộc một chi nhánh cụ thể không
 *
 * @param int $branch_id Branch ID cần kiểm tra
 * @param int|null $user_id WordPress user ID. Nếu null, lấy user hiện tại
 * @return bool True nếu nhân viên thuộc chi nhánh đó
 */
function checkin_mkt192_staff_belongs_to_branch($branch_id, $user_id = null) {
    // Nếu chế độ đa chi nhánh tắt, tất cả đều thuộc cùng chi nhánh
    if (!checkin_mkt192_is_multi_branch_enabled()) {
        return true;
    }

    if (!$branch_id) {
        return true; // Không có branch_id = không filter
    }

    $all_branches = checkin_mkt192_get_staff_all_branch_ids($user_id);

    // Nếu nhân viên không có branch nào, cho phép tất cả (fallback)
    if (empty($all_branches)) {
        return true;
    }

    return in_array(intval($branch_id), $all_branches, true);
}

/**
 * Lấy tên chi nhánh từ branch_id
 *
 * @param int $branch_id Branch ID
 * @return string|null Tên chi nhánh hoặc null nếu không tìm thấy
 */
function checkin_mkt192_get_branch_name($branch_id) {
    if (empty($branch_id) || !checkin_mkt192_is_multi_branch_enabled()) {
        return null;
    }

    global $wpdb;
    return $wpdb->get_var($wpdb->prepare(
        "SELECT location_name FROM {$wpdb->prefix}checkin_mkt192_locations WHERE id = %d",
        $branch_id
    ));
}

/**
 * Lấy branch_id từ request (parameter hoặc staff profile)
 *
 * Ưu tiên: request param > staff's primary branch
 *
 * @param WP_REST_Request|array $request Request object hoặc array chứa branch_id
 * @param int|null $user_id WordPress user ID. Nếu null, lấy user hiện tại
 * @return int Branch ID (0 nếu không có hoặc chế độ đa chi nhánh tắt)
 */
function checkin_mkt192_get_branch_id_from_context($request, $user_id = null) {
    // Nếu chế độ đa chi nhánh tắt, không cần branch_id
    if (!checkin_mkt192_is_multi_branch_enabled()) {
        return 0;
    }

    // Lấy từ request parameter
    $branch_id = 0;
    if ($request instanceof WP_REST_Request) {
        $branch_id = intval($request->get_param('branch_id') ?: 0);
    } elseif (is_array($request) && isset($request['branch_id'])) {
        $branch_id = intval($request['branch_id']);
    }

    // Nếu có branch_id từ request, dùng nó
    if ($branch_id > 0) {
        return $branch_id;
    }

    // Fallback: lấy chi nhánh chính của user
    return checkin_mkt192_get_staff_primary_branch_id($user_id);
}

/**
 * Build WHERE clause cho query SQL dựa trên branch_id
 *
 * @param string $table_alias Alias của bảng (ví dụ: 'i' cho invoices)
 * @param int $branch_id Branch ID để filter
 * @param bool $include_where Có thêm 'WHERE' hay 'AND'
 * @return string SQL clause (empty string nếu không cần filter)
 */
function checkin_mkt192_build_branch_where_clause($table_alias, $branch_id, $include_where = false) {
    // Nếu chế độ đa chi nhánh tắt hoặc không có branch_id, không filter
    if (!checkin_mkt192_is_multi_branch_enabled() || empty($branch_id)) {
        return '';
    }

    $branch_id = intval($branch_id);
    $prefix    = $include_where ? 'WHERE' : 'AND';

    return " {$prefix} {$table_alias}.branch_id = {$branch_id}";
}

/**
 * Lấy thông tin staff đầy đủ (bao gồm branch data)
 *
 * @param int|null $user_id WordPress user ID. Nếu null, lấy user hiện tại
 * @return object|null Staff object hoặc null
 */
function checkin_mkt192_get_staff_data($user_id = null) {
    if ($user_id === null) {
        $user_id = get_current_user_id();
    }

    if (!$user_id) {
        return null;
    }

    global $wpdb;
    return $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}checkin_mkt192_staff WHERE user_id = %d LIMIT 1",
        $user_id
    ));
}
