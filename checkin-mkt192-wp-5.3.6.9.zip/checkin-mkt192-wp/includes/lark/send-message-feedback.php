<?php

require_once(dirname(__FILE__, 6) . '/wp-load.php');
require_once __DIR__ . '/class-checkin-mkt192-message-bot-manager.php';

function send_lark_notification($data, $type = 'good') {
    $log_file = __DIR__ . '/logs/send_message_' . ($type === 'bad' ? 'bad' : 'good') . '_feedback.log';

    // Ghi log dữ liệu đầu vào
    $log_entry = '[' . date('Y-m-d H:i:s') . '] Nhận yêu cầu gửi thông báo ' . ($type === 'bad' ? 'đánh giá tệ' : 'đánh giá tốt') . "\n";
    $log_entry .= 'Data: ' . json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
    $log_entry .= "----------------------------------------\n";
    file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);

    // Check if Lark is enabled
    if (!is_lark_enabled()) {
        $error_message = 'Lark chưa được kích hoạt';
        $log_entry     = '[' . date('Y-m-d H:i:s') . "] $error_message\n";
        $log_entry .= "----------------------------------------\n";
        file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);
        return ['success' => false, 'message' => $error_message];
    }

    // Load Bot Manager
    $bot_manager = Checkin_MKT192_Message_Bot_Manager::get_instance();

    // Kiểm tra bot có tồn tại không
    $bot = $bot_manager->get_bot_by_notification_type('feedback');
    if (!$bot) {
        $error_message = 'Không tìm thấy bot được cấu hình cho loại thông báo: feedback';
        $log_entry     = '[' . date('Y-m-d H:i:s') . "] $error_message\n";
        $log_entry .= "----------------------------------------\n";
        file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);
        return ['success' => false, 'message' => $error_message];
    }

    // Ghi log bot được sử dụng
    $log_entry = '[' . date('Y-m-d H:i:s') . "] Bot được sử dụng\n";
    $log_entry .= 'Data: ' . json_encode([
        'bot_id'   => $bot->id,
        'bot_name' => $bot->bot_name,
        'bot_type' => $bot->bot_type
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
    $log_entry .= "----------------------------------------\n";
    file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);

    // Load card builder
    require_once __DIR__ . '/card-builder.php';

    // Get bot type
    $bot_type = $bot ? $bot->bot_type : 'interactive';

    // Build card using card builder
    $card = build_feedback_card($data, $type, $bot_type);

    // Chuẩn bị dữ liệu cho card message
    $payload = [
        'msg_type' => 'interactive',
        'card'     => $card
    ];

    // Ghi log payload
    $log_entry = '[' . date('Y-m-d H:i:s') . "] Payload gửi tới Lark\n";
    $log_entry .= 'Data: ' . json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
    $log_entry .= "----------------------------------------\n";
    file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);

    // Gửi thông báo qua Bot Manager
    $start_time    = microtime(true);
    $result        = $bot_manager->send_message('feedback', null, $payload);
    $response_time = microtime(true) - $start_time;

    // Ghi log kết quả
    $log_entry = '[' . date('Y-m-d H:i:s') . "] Kết quả gửi từ Bot Manager\n";
    $log_entry .= 'Data: ' . json_encode([
        'is_error'      => is_wp_error($result),
        'result'        => $result,
        'response_time' => $response_time
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
    $log_entry .= "----------------------------------------\n";
    file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);

    if (is_wp_error($result)) {
        $error_message = 'Error sending feedback notification: ' . $result->get_error_message();
        return ['success' => false, 'message' => $error_message];
    }

    // Kiểm tra response code từ Lark
    if (isset($result['code']) && $result['code'] == 0) {
        $log_entry = '[' . date('Y-m-d H:i:s') . "] ✅ Gửi thông báo đánh giá thành công\n";
        $log_entry .= "----------------------------------------\n";
        file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);
        return ['success' => true, 'message' => 'Tin nhắn đã được gửi tới Lark'];
    } else {
        $error_msg = isset($result['msg']) ? $result['msg'] : 'Unknown error';
        $log_entry = '[' . date('Y-m-d H:i:s') . "] ❌ Lark API trả về lỗi: $error_msg\n";
        $log_entry .= "----------------------------------------\n";
        file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);
        return ['success' => false, 'message' => 'Lark API error: ' . $error_msg];
    }
}

// Xử lý yêu cầu POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    if (!empty($input)) {
        // Xác định type dựa trên feedback_type được truyền từ review-api
        // Fallback về 'good' nếu không có feedback_type
        $type   = !empty($input['feedback_type']) ? $input['feedback_type'] : 'good';
        $result = send_lark_notification($input, $type);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($result, JSON_UNESCAPED_UNICODE);
    } else {
        $error_message = 'Dữ liệu đầu vào không hợp lệ';
        $log_file      = __DIR__ . '/logs/send_message_good_feedback.log'; // Mặc định log vào file good nếu không xác định được type
        $log_entry     = '[' . date('Y-m-d H:i:s') . "] $error_message\n";
        $log_entry .= "----------------------------------------\n";
        file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);
        header('Content-Type: application/json; charset=utf-8', true, 400);
        echo json_encode(['success' => false, 'message' => $error_message], JSON_UNESCAPED_UNICODE);
    }
} else {
    $error_message = 'Phương thức không được hỗ trợ';
    $log_file      = __DIR__ . '/logs/send_message_good_feedback.log'; // Mặc định log vào file good nếu không xác định được type
    $log_entry     = '[' . date('Y-m-d H:i:s') . "] $error_message\n";
    $log_entry .= "----------------------------------------\n";
    file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);
    header('Content-Type: application/json; charset=utf-8', true, 405);
    echo json_encode(['success' => false, 'message' => $error_message], JSON_UNESCAPED_UNICODE);
}
?>
