<?php

require_once(dirname(__FILE__, 6) . '/wp-load.php');
require_once(__DIR__ . '/lark-utils.php');
require_once(__DIR__ . '/card-builder.php');
require_once(__DIR__ . '/cache-utils.php');

/**
 * Generate unique transaction ID for penalty
 */
function generate_penalty_transaction_id() {
    $timestamp = time();
    $random    = mt_rand(1000, 999999);
    return "penalty_{$timestamp}_{$random}";
}

/**
 * Send penalty notification to group
 */
function send_penalty_group_notification($transaction_id, $penalty_data) {
    // Load Bot Manager
    require_once __DIR__ . '/class-checkin-mkt192-message-bot-manager.php';
    $bot_manager = Checkin_MKT192_Message_Bot_Manager::get_instance();

    $card = build_penalty_notification_card($penalty_data);

    CacheManager::write_log('Sending penalty notification via Bot Manager', [
        'card'           => $card,
        'transaction_id' => $transaction_id
    ], 'penalty_notification.log');

    $start_time    = microtime(true);
    $result        = $bot_manager->send_message('feedback', null, $card);
    $response_time = microtime(true) - $start_time;

    if (is_wp_error($result)) {
        $error_message = 'Error sending penalty notification: ' . $result->get_error_message();
        CacheManager::write_log($error_message, [
            'transaction_id' => $transaction_id
        ], 'penalty_notification.log');
        return false;
    }

    CacheManager::write_log('Group penalty notification response', [
        'result'         => $result,
        'response_time'  => $response_time,
        'transaction_id' => $transaction_id
    ], 'penalty_notification.log');

    return true;
}

/**
 * Send penalty notification to individual staff
 */
function send_penalty_staff_notification($penalty_data) {
    global $wpdb;
    $table_staff = $wpdb->prefix . 'checkin_mkt192_staff';

    // Load Bot Manager
    require_once __DIR__ . '/class-checkin-mkt192-message-bot-manager.php';
    $bot_manager = Checkin_MKT192_Message_Bot_Manager::get_instance();

    $staff_notifications = [];
    $unique_staff        = array_unique(array_column($penalty_data['services'], 'staff_name'));

    foreach ($unique_staff as $staff_name) {
        $ou_id = $wpdb->get_var($wpdb->prepare(
            "SELECT ou_id FROM $table_staff WHERE display_name = %s",
            $staff_name
        ));

        if (!$ou_id) {
            CacheManager::write_log("No ou_id found for staff '$staff_name'", [], 'penalty_notification.log');
            continue;
        }

        $transaction_id = generate_penalty_transaction_id();

        CacheManager::write_log('Sending penalty notification to staff', [
            'staff_name'     => $staff_name,
            'ou_id'          => $ou_id,
            'transaction_id' => $transaction_id
        ], 'penalty_notification.log');

        $card = build_penalty_notification_card($penalty_data);

        $start_time    = microtime(true);
        $result        = $bot_manager->send_message('feedback', null, $card);
        $response_time = microtime(true) - $start_time;

        CacheManager::write_log('Lark response for staff', [
            'staff_name'    => $staff_name,
            'result'        => $result,
            'response_time' => $response_time
        ], 'penalty_notification.log');

        if (is_wp_error($result)) {
            $error_message         = 'Error sending penalty to staff: ' . $result->get_error_message();
            $staff_notifications[] = ['staff_name' => $staff_name, 'success' => false, 'message' => $error_message];
        } else {
            $staff_notifications[] = [
                'staff_name'     => $staff_name,
                'success'        => true,
                'message'        => "Penalty notification sent to staff '$staff_name'",
                'message_id'     => $result['data']['message_id'] ?? '',
                'transaction_id' => $transaction_id
            ];
        }
    }

    return $staff_notifications;
}

/**
 * Send penalty notifications
 */
function send_penalty_notifications($penalty_data) {
    $transaction_id = generate_penalty_transaction_id();

    // Send to group
    $group_result = send_penalty_group_notification($transaction_id, $penalty_data);

    // Send to staff
    $staff_results = send_penalty_staff_notification($penalty_data);

    $overall_success = $group_result;
    foreach ($staff_results as $result) {
        if ($result['success']) {
            $overall_success = true;
            break;
        }
    }

    return [
        'success'       => $overall_success,
        'group_sent'    => $group_result,
        'staff_results' => $staff_results,
        'message'       => $overall_success ? 'Penalty notifications sent successfully' : 'Failed to send penalty notifications'
    ];
}

ob_start();
register_shutdown_function(function () {
    $output = ob_get_clean();
    if ($output && !headers_sent()) {
        header('Content-Type: application/json; charset=utf-8', true, 500);
        echo json_encode(['success' => false, 'message' => 'Unexpected output: ' . $output]);
        exit;
    }
});
?>