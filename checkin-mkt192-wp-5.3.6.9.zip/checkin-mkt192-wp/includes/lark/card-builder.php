<?php

/**
 * Helper function để kiểm tra chế độ đa chi nhánh có được bật không
 *
 * @return bool True nếu chế độ đa chi nhánh được bật
 */
function is_multi_branch_enabled() {
    return get_option('checkin_branch_mode_enabled', '0') === '1';
}

/**
 * Build salary report card - LOẠI 1
 * Thông báo phiếu lương gửi Group nhân viên (webhook)
 * Hiển thị khi có phiếu lương mới, nhân viên vào website xem
 */
function build_salary_report_notification_card($staff_name, $period) {
    return [
        'header' => [
            'template' => 'blue',
            'title'    => [
                'content' => '📢 THÔNG BÁO PHIẾU LƯƠNG MỚI 📢',
                'tag'     => 'plain_text'
            ]
        ],
        'elements' => [
            [
                'tag'  => 'div',
                'text' => [
                    'content' => "**Nhân viên**: __{$staff_name}__ 🎉\n" .
                                 "**Kỳ lương**: 🗓️ {$period}\n\n" .
                                 "Vui lòng vào **trang cá nhân** để xem và xác nhận lương của bạn.\n\n" .
                                 '🔗 Link: ' . home_url('/user-profile/'),
                    'tag' => 'lark_md'
                ]
            ],
            ['tag' => 'hr'],
            [
                'tag'  => 'div',
                'text' => [
                    'content' => '📌 *Ghi chú*: Vui lòng xác nhận trong vòng 3 ngày!',
                    'tag'     => 'lark_md'
                ]
            ]
        ]
    ];
}/**
 * Build salary payment card - LOẠI 3
 * Thanh toán lương gửi cá nhân nhân viên (interactive)
 * Quản lý gửi card có 2 nút cho nhân viên xác nhận đã nhận lương
 * Được gọi từ send_salary_notification.php -> send_salary_payment_notification()
 *
 * @param string $transaction_id Transaction ID
 * @param array $salary_data Salary data
 * @param string $ou_id OU ID
 * @param string $bot_type Bot type: 'interactive' or 'webhook'
 */
function build_salary_payment_card($transaction_id, $salary_data, $ou_id, $bot_type = 'interactive') {
    // Kiểm tra chế độ đa chi nhánh
    $multi_branch_enabled = is_multi_branch_enabled();
    $branch               = !empty($salary_data['branch']) ? $salary_data['branch'] : '';

    $elements = [
        [
            'tag'        => 'markdown',
            'content'    => "**<font color='red'>Van Group Barber Shop</font>**",
            'text_align' => 'center'
        ],
        [
            'tag'    => 'div',
            'fields' => [
                [
                    'is_short' => true,
                    'text'     => [
                        'tag'     => 'lark_md',
                        'content' => "**🧑‍💼 Nhân viên:**\n<at id=$ou_id></at>"
                    ]
                ],
                [
                    'is_short' => true,
                    'text'     => [
                        'tag'     => 'lark_md',
                        'content' => "**💰 Thực nhận:**\n" . number_format(floatval($salary_data['actual_salary']), 0, '.', ',')
                    ]
                ]
            ]
        ]
    ];

    // Chỉ thêm trường chi nhánh nếu chế độ đa chi nhánh được bật
    if ($multi_branch_enabled) {
        $elements[] = [
            'tag'    => 'div',
            'fields' => [
                [
                    'is_short' => true,
                    'text'     => [
                        'tag'     => 'lark_md',
                        'content' => "**🏢 Chi nhánh:**\n" . ($branch ?: '_Chưa xác định_')
                    ]
                ],
                [
                    'is_short' => true,
                    'text'     => [
                        'tag'     => 'lark_md',
                        'content' => '' // Empty cell
                    ]
                ]
            ]
        ];
    }

    $elements[] =
    [
        'tag'    => 'div',
        'fields' => [
            [
                'is_short' => false,
                'text'     => [
                    'tag'     => 'lark_md',
                    'content' => '**📝 Ghi chú:** Vui lòng bấm nút và xác nhận đã nhận lương.'
                ]
            ]
        ]
    ];
    $elements[] = ['tag' => 'hr'];

    $card = [
        'config' => [
            'wide_screen_mode' => true,
            'update_multi'     => true
        ],
        'elements' => $elements,
        'header'   => [
            'template' => 'green',
            'title'    => [
                'content' => "THANH TOÁN LƯƠNG | {$salary_data['period']}",
                'tag'     => 'plain_text'
            ]
        ]
    ];

    // Chỉ thêm buttons nếu là interactive bot
    if ($bot_type === 'interactive') {
        $card['elements'][] = [
            'tag'     => 'action',
            'actions' => [
                [
                    'tag'   => 'button',
                    'text'  => ['tag' => 'plain_text', 'content' => 'Đã nhận đủ'],
                    'type'  => 'primary',
                    'value' => [
                        'id'         => $transaction_id,
                        'type'       => 'salary_payment',
                        'staff_name' => $salary_data['staff_name'],
                        'period'     => $salary_data['period'],
                        'trang_thai' => 'ĐÃ DUYỆT'
                    ]
                ],
                [
                    'tag'   => 'button',
                    'text'  => ['tag' => 'plain_text', 'content' => 'Xin xét lại'],
                    'type'  => 'danger',
                    'value' => [
                        'id'         => $transaction_id,
                        'type'       => 'salary_payment',
                        'staff_name' => $salary_data['staff_name'],
                        'period'     => $salary_data['period'],
                        'trang_thai' => 'KHÔNG DUYỆT'
                    ]
                ]
            ]
        ];
    } else {
        // Webhook bot: Hiển thị thông báo không có nút
        $card['elements'][] = [
            'tag'  => 'div',
            'text' => [
                'tag'     => 'lark_md',
                'content' => '**📝 Lưu ý:** Vui lòng liên hệ quản lý để xác nhận thanh toán lương.'
            ]
        ];
    }

    return $card;
}

/**
 * Build stock card
 *
 * @param string $bot_type Bot type: 'interactive' or 'webhook'
 */
function build_stock_card($transaction_id, $transaction_data, $type, $employee_ou_id, $employee_name, $items_content, $image_key = '', $bot_type = 'interactive') {
    $manager_open_id = 'ou_75709e45ff7e09fd60de587295a16087';

    // Kiểm tra chế độ đa chi nhánh
    $multi_branch_enabled = is_multi_branch_enabled();
    $branch               = !empty($transaction_data['branch']) ? $transaction_data['branch'] : '';

    // Chỉ hiển thị chi nhánh nếu chế độ đa chi nhánh được bật
    $branch_text = ($multi_branch_enabled && $branch) ? "\n**🏢 Chi nhánh: " . $branch . '**' : '';

    $card = [
        'config' => [
            'update_multi'     => true,
            'wide_screen_mode' => true,
            'enable_forward'   => true
        ],
        'header' => [
            'template' => 'red',
            'title'    => [
                'content' => $type === 'in' ? 'PHIẾU NHẬP HÀNG' : 'PHIẾU XUẤT HÀNG',
                'tag'     => 'plain_text'
            ]
        ],
        'elements' => [
            [
                'tag'        => 'markdown',
                'content'    => "**<font color='red'>🆔 $transaction_id</font>**" . $branch_text,
                'text_align' => 'center'
            ],
            [
                'tag'              => 'column_set',
                'flex_mode'        => 'none',
                'background_style' => 'grey',
                'columns'          => array_map(function ($item) {
                    return [
                        'tag'            => 'column',
                        'width'          => 'weighted',
                        'weight'         => 1,
                        'vertical_align' => 'top',
                        'elements'       => [
                            [
                                'tag'        => 'markdown',
                                'content'    => "**💈 {$item['product_name']}**\n🔢 **{$item['quantity']}**",
                                'text_align' => 'center'
                            ]
                        ]
                    ];
                }, $items_content)
            ],
            [
                'tag'              => 'column_set',
                'flex_mode'        => 'none',
                'background_style' => 'grey',
                'columns'          => [
                    [
                        'tag'            => 'column',
                        'width'          => 'weighted',
                        'weight'         => 1,
                        'vertical_align' => 'top',
                        'elements'       => [
                            [
                                'tag'        => 'markdown',
                                'content'    => "**🔵 Nhân Viên:\n<at id=$employee_ou_id>$employee_name</at>**",
                                'text_align' => 'center'
                            ]
                        ]
                    ],
                    [
                        'tag'            => 'column',
                        'width'          => 'weighted',
                        'weight'         => 1,
                        'vertical_align' => 'top',
                        'elements'       => [
                            [
                                'tag'        => 'markdown',
                                'content'    => "**🔴 Sếp:\n<at id=$manager_open_id></at>**",
                                'text_align' => 'center'
                            ]
                        ]
                    ]
                ]
            ],
            [
                'tag'  => 'div',
                'text' => [
                    'tag'     => 'lark_md',
                    'content' => "**<font color='red'>📍 Lý do: " . ($transaction_data['reason'] ?? '') . '</font>**'
                ]
            ]
        ]
    ];

    if ($image_key) {
        $card['elements'][] = [
            'tag'     => 'img',
            'img_key' => $image_key,
            'alt'     => [
                'tag'     => 'plain_text',
                'content' => $type === 'in' ? 'Hình ảnh hàng nhập' : 'Hình ảnh hàng xuất'
            ],
            'mode'          => 'fit_horizontal',
            'compact_width' => false
        ];
    }

    $card['elements'][] = ['tag' => 'hr'];

    // Chỉ thêm buttons nếu là interactive bot
    if ($bot_type === 'interactive') {
        $card['elements'][] = [
            'tag'     => 'action',
            'actions' => [
                [
                    'tag'  => 'button',
                    'text' => [
                        'tag'     => 'plain_text',
                        'content' => 'Duyệt'
                    ],
                    'type'  => 'primary',
                    'value' => [
                        'trang_thai' => 'ĐÃ DUYỆT',
                        'id'         => $transaction_id,
                        'type'       => 'inventory_transaction'
                    ],
                    'confirm' => [
                        'title' => [
                            'tag'     => 'plain_text',
                            'content' => 'ĐỒNG Ý DUYỆT?'
                        ],
                        'text' => [
                            'tag'     => 'plain_text',
                            'content' => 'Xác nhận lưu Phiếu ' . ($type === 'in' ? 'Nhập' : 'Xuất') . '?'
                        ]
                    ]
                ],
                [
                    'tag'  => 'button',
                    'text' => [
                        'tag'     => 'plain_text',
                        'content' => 'Không Duyệt'
                    ],
                    'type'  => 'danger',
                    'value' => [
                        'trang_thai' => 'KHÔNG DUYỆT',
                        'id'         => $transaction_id,
                        'type'       => 'inventory_transaction'
                    ],
                    'confirm' => [
                        'title' => [
                            'tag'     => 'plain_text',
                            'content' => 'KHÔNG DUYỆT?'
                        ],
                        'text' => [
                            'tag'     => 'plain_text',
                            'content' => 'Xác nhận hủy Phiếu ' . ($type === 'in' ? 'Nhập' : 'Xuất') . '?'
                        ]
                    ]
                ]
            ]
        ];
    } else {
        // Webhook bot: Hiển thị thông báo không có nút
        $card['elements'][] = [
            'tag'  => 'div',
            'text' => [
                'tag'     => 'lark_md',
                'content' => '**📝 Lưu ý:** Vui lòng liên hệ quản lý để duyệt phiếu xuất/nhập kho.'
            ]
        ];
    }

    $card['elements'][] = [
        'tag'     => 'markdown',
        'content' => "**<font color='green'>📆 Ngày: " . current_time('Y-m-d H:i:s') . '</font>**'
    ];

    return $card;
}

/**
 * Build salary report confirmation card - LOẠI 2
 * Xác nhận phiếu lương gửi Group quản lý (webhook)
 * Hiển thị khi nhân viên bấm "Đồng ý" hoặc "Xin xét lại" trên website
 * Được gọi từ salary-api.php -> checkin_mkt192_confirm_salary()
 */
function build_salary_report_confirmation_card($staff_name, $role, $period, $total_salary, $deductions, $actual_salary, $action, $xac_nhan_luong) {
    $total_salary_formatted  = number_format($total_salary, 0, ',', '.') . ' đ';
    $deductions_formatted    = number_format($deductions, 0, ',', '.') . ' đ';
    $actual_salary_formatted = number_format($actual_salary, 0, ',', '.') . ' đ';
    $status_color            = ($action === 'approve' ? 'green' : 'red');

    return [
        'header' => [
            'template' => $status_color,
            'title'    => [
                'content' => '📢 Xác Nhận Lương 📢',
                'tag'     => 'plain_text'
            ]
        ],
        'elements' => [
            [
                'tag'  => 'div',
                'text' => [
                    'content' => "**Nhân viên**: __{$staff_name}__ 🎉\n" .
                                 "**Vai trò**: {$role}\n" .
                                 "**Kỳ lương**: 🗓️ {$period}\n" .
                                 "**Tổng lương**: 💰 {$total_salary_formatted}\n" .
                                 "**Tổng trừ**: ➖ {$deductions_formatted}\n" .
                                 "**💵 Thực nhận**: <font color='blue'>**{$actual_salary_formatted}**</font>\n" .
                                 '**Trạng thái**: ' . ($action === 'approve' ? "<font color='green'>✅ **{$xac_nhan_luong}**</font>" : "<font color='red'>⚠️ **{$xac_nhan_luong}**</font>"),
                    'tag' => 'lark_md'
                ]
            ],
            ['tag' => 'hr'],
            [
                'tag'  => 'div',
                'text' => [
                    'content' => '📌 *Ghi chú*: Vui lòng kiểm tra và phản hồi nếu có sai sót!',
                    'tag'     => 'lark_md'
                ]
            ]
        ]
    ];
}

/**
 * Build salary payment completion card - LOẠI 4
 * Hoàn thành thanh toán gửi Group quản lý (webhook)
 * Hiển thị khi nhân viên bấm nút "Đã nhận đủ" hoặc "Xin xét lại" trên card Lark
 * Được gọi từ send_salary_notification.php -> send_group_notification()
 */
function build_salary_payment_completion_card($staff_name, $period, $status, $actual_salary) {
    $status_text  = ($status === 'ĐÃ DUYỆT') ? 'Đã nhận đủ' : 'Chưa nhận được';
    $status_color = ($status === 'ĐÃ DUYỆT') ? 'green' : 'red';

    return [
        'header' => [
            'template' => $status_color,
            'title'    => [
                'content' => '📢 Xác Nhận Thanh Toán 📢',
                'tag'     => 'plain_text'
            ]
        ],
        'elements' => [
            [
                'tag'  => 'div',
                'text' => [
                    'content' => "**Nhân viên**: __{$staff_name}__ 🎉\n" .
                                 "**Kỳ lương**: 🗓️ {$period}\n" .
                                 '**Số tiền**: 💰 ' . number_format($actual_salary, 0, '.', ',') . "\n" .
                                 "**Trạng thái**: <font color='$status_color'>✅ **{$status_text}**</font>",
                    'tag' => 'lark_md'
                ]
            ],
            ['tag' => 'hr'],
            [
                'tag'  => 'div',
                'text' => [
                    'content' => '📌 *Ghi chú*: Vui lòng kiểm tra và phản hồi nếu có sai sót!',
                    'tag'     => 'lark_md'
                ]
            ]
        ]
    ];
}

/**
 * Build callback card
 */
function build_callback_card($transaction_id, $status_value, $status_color, $log_function, $action_type) {
    $is_salary_action  = in_array($action_type, ['salary_confirmation', 'salary_payment'], true);
    $cache_prefix      = $is_salary_action ? CACHE_PREFIX_SALARY : CACHE_PREFIX_INVENTORY;
    $fallback_callback = $is_salary_action ? 'get_salary_data_from_db' : 'get_inventory_data_from_db';

    CacheManager::write_log('Attempting to retrieve cache', [
        'transaction_id' => $transaction_id,
        'cache_prefix'   => $cache_prefix,
        'action_type'    => $action_type
    ], 'lark_callback_log.log');

    $cached_data = CacheManager::get($transaction_id, $cache_prefix, $fallback_callback);

    if (!$cached_data) {
        call_user_func($log_function, "No cache data found for $action_type", [
            'transaction_id' => $transaction_id,
            'cache_prefix'   => $cache_prefix
        ], 'lark_callback_log.log');
        return false;
    }

    CacheManager::write_log('Cache data retrieved', [
        'transaction_id' => $transaction_id,
        'cache_prefix'   => $cache_prefix,
        'cached_data'    => $cached_data
    ], 'lark_callback_log.log');

    $transaction_type = $cached_data['transaction_type'];
    $card_data        = [
        'config' => [
            'update_multi'     => true,
            'wide_screen_mode' => true,
            'enable_forward'   => true
        ],
        'header' => [
            'template' => $status_color,
            'title'    => [
                'content' => '',
                'tag'     => 'plain_text'
            ]
        ],
        'elements' => []
    ];

    switch ($transaction_type) {
        case 'IN':
        case 'OUT':
            $employee_name   = $cached_data['employee_name']  ?? '';
            $employee_ou_id  = $cached_data['employee_ou_id'] ?? '';
            $transactions    = $cached_data['transactions']   ?? [];
            $note            = $cached_data['note']           ?? '';
            $manager_open_id = 'ou_75709e45ff7e09fd60de587295a16087';

            if (!$employee_name || !$employee_ou_id || empty($transactions)) {
                call_user_func($log_function, 'Missing required data for inventory transaction', [
                    'transaction_id' => $transaction_id,
                    'cached_data'    => $cached_data
                ], 'lark_callback_log.log');
                return false;
            }

            $card_data['header']['title']['content'] = $transaction_type === 'IN' ? 'PHIẾU NHẬP HÀNG' : 'PHIẾU XUẤT HÀNG';
            $card_data['elements']                   = [
                [
                    'tag'        => 'markdown',
                    'content'    => "**<font color='$status_color'>🆔 $transaction_id</font>**",
                    'text_align' => 'center'
                ],
                [
                    'tag'              => 'column_set',
                    'flex_mode'        => 'none',
                    'background_style' => 'grey',
                    'columns'          => array_map(function ($transaction) {
                        return [
                            'tag'            => 'column',
                            'width'          => 'weighted',
                            'weight'         => 1,
                            'vertical_align' => 'top',
                            'elements'       => [
                                [
                                    'tag'        => 'markdown',
                                    'content'    => "**💈 {$transaction['product_name']}**\n🔢 **{$transaction['quantity']}**",
                                    'text_align' => 'center'
                                ]
                            ]
                        ];
                    }, $transactions)
                ],
                [
                    'tag'              => 'column_set',
                    'flex_mode'        => 'none',
                    'background_style' => 'grey',
                    'columns'          => [
                        [
                            'tag'            => 'column',
                            'width'          => 'weighted',
                            'weight'         => 1,
                            'vertical_align' => 'top',
                            'elements'       => [
                                [
                                    'tag'        => 'markdown',
                                    'content'    => "**🔵 Nhân Viên:\n<at id=$employee_ou_id>$employee_name</at>**",
                                    'text_align' => 'center'
                                ]
                            ]
                        ],
                        [
                            'tag'            => 'column',
                            'width'          => 'weighted',
                            'weight'         => 1,
                            'vertical_align' => 'top',
                            'elements'       => [
                                [
                                    'tag'        => 'markdown',
                                    'content'    => "**🔴 Sếp:\n<at id=$manager_open_id></at>**",
                                    'text_align' => 'center'
                                ]
                            ]
                        ]
                    ]
                ],
                [
                    'tag'  => 'div',
                    'text' => [
                        'tag'     => 'lark_md',
                        'content' => "**<font color='$status_color'>📍 Lý do: $note</font>**"
                    ]
                ],
                [
                    'tag'        => 'markdown',
                    'content'    => "**<font color='$status_color'>📍 Trạng thái: $status_value</font>**\n**📆 Thời gian: " . current_time('Y-m-d H:i:s') . '**',
                    'text_align' => 'center'
                ],
                ['tag' => 'hr'],
                [
                    'tag'      => 'note',
                    'elements' => [
                        [
                            'tag'     => 'lark_md',
                            'content' => '📌 *Ghi chú*: Thông tin đã được xử lý.'
                        ]
                    ]
                ]
            ];
            break;

        case 'PAYROLL':
        case 'PAYROLL_CONFIRM':
            $staff_name    = $cached_data['staff_name'] ?? '';
            $actual_salary = isset($cached_data['actual_salary']) ? number_format(floatval($cached_data['actual_salary']), 0, '.', ',') : '0';
            if (!$staff_name) {
                call_user_func($log_function, 'Missing staff_name for ' . $transaction_type, [
                    'transaction_id' => $transaction_id,
                    'cached_data'    => $cached_data
                ], 'lark_callback_log.log');
                return false;
            }
            $card_data['header']['title']['content'] = $transaction_type === 'PAYROLL' ? 'THANH TOÁN LƯƠNG' : 'XÁC NHẬN THANH TOÁN LƯƠNG';
            $card_data['elements']                   = [
                [
                    'tag'        => 'markdown',
                    'content'    => "**<font color='red'>Van Group Barber Shop</font>**",
                    'text_align' => 'center'
                ],
                [
                    'tag'    => 'div',
                    'fields' => [
                        [
                            'is_short' => true,
                            'text'     => [
                                'tag'     => 'lark_md',
                                'content' => "**🧑‍💼 Nhân viên:**\n$staff_name"
                            ]
                        ],
                        [
                            'is_short' => true,
                            'text'     => [
                                'tag'     => 'lark_md',
                                'content' => "**💰 Thực nhận:**\n$actual_salary"
                            ]
                        ]
                    ]
                ],
                [
                    'tag' => 'hr'
                ],
                [
                    'tag'        => 'markdown',
                    'content'    => "**<font color='$status_color'>📍 Trạng thái: $status_value</font>**\n**📆 Thời gian: " . current_time('Y-m-d H:i:s') . '**',
                    'text_align' => 'center'
                ],
                [
                    'tag'      => 'note',
                    'elements' => [
                        [
                            'tag'     => 'lark_md',
                            'content' => '📌 *Ghi chú*: ' . ($transaction_type === 'PAYROLL' ? 'Thông tin đã được xử lý.' : 'Xác nhận lương đã được xử lý.')
                        ]
                    ]
                ]
            ];
            break;

        default:
            call_user_func($log_function, 'Unsupported transaction type', [
                'transaction_type' => $transaction_type,
                'action_type'      => $action_type
            ], 'lark_callback_log.log');
            return false;
    }

    return [
        'type' => 'raw',
        'data' => $card_data
    ];
}

/**
 * Build booking notification card
 */
function build_booking_notification_card($booking_data, $id_hairdresser) {
    // Kiểm tra chế độ đa chi nhánh
    $multi_branch_enabled = is_multi_branch_enabled();
    $branch               = !empty($booking_data['branch']) ? $booking_data['branch'] : (!empty($booking_data['branch_name']) ? $booking_data['branch_name'] : '');

    // Xây dựng elements
    $elements = [
        [
            'tag'        => 'markdown',
            'content'    => "**<font color='red'>{$booking_data['id_booking']}</font>**",
            'text_align' => 'center'
        ],
        [
            'tag'    => 'div',
            'fields' => [
                [
                    'is_short' => true,
                    'text'     => [
                        'tag'     => 'lark_md',
                        'content' => "**📅 Thời gian:**\n {$booking_data['booking_date']} {$booking_data['booking_time']}"
                    ]
                ],
                [
                    'is_short' => true,
                    'text'     => [
                        'tag'     => 'lark_md',
                        'content' => "**🧑‍💼 Khách hàng:** \n{$booking_data['customer_name']}"
                    ]
                ]
            ]
        ]
    ];

    // Chỉ thêm trường chi nhánh nếu chế độ đa chi nhánh được bật
    if ($multi_branch_enabled) {
        $elements[] = [
            'tag'    => 'div',
            'fields' => [
                [
                    'is_short' => true,
                    'text'     => [
                        'tag'     => 'lark_md',
                        'content' => "**🏢 Chi nhánh:**\n" . ($branch ?: '_Chưa xác định_')
                    ]
                ],
                [
                    'is_short' => true,
                    'text'     => [
                        'tag'     => 'lark_md',
                        'content' => '' // Empty cell để cân bằng layout
                    ]
                ]
            ]
        ];
    }

    $elements[] = [
        'tag'    => 'div',
        'fields' => [
            [
                'is_short' => true,
                'text'     => [
                    'tag'     => 'lark_md',
                    'content' => "**✂️ Dịch vụ:** \n{$booking_data['service_name']}"
                ]
            ],
            [
                'is_short' => true,
                'text'     => [
                    'tag'     => 'lark_md',
                    'content' => "**💈 Thợ:** \n<at id=$id_hairdresser></at>"
                ]
            ]
        ]
    ];

    $elements[] = [
        'tag'    => 'div',
        'fields' => [
            [
                'is_short' => true,
                'text'     => [
                    'tag'     => 'lark_md',
                    'content' => "**👥 Số lượng khách:** \n{$booking_data['customer_count']}"
                ]
            ],
            [
                'is_short' => true,
                'text'     => [
                    'tag'     => 'lark_md',
                    'content' => "**🤫 Yêu cầu im lặng:** \n{$booking_data['silent_service']}"
                ]
            ]
        ]
    ];

    // Thêm ghi chú nếu có
    if (!empty($booking_data['booking_note']) || !empty($booking_data['note'])) {
        $elements[] = [
            'tag'              => 'column_set',
            'flex_mode'        => 'none',
            'background_style' => 'grey',
            'columns'          => [
                [
                    'tag'            => 'column',
                    'width'          => 'weighted',
                    'weight'         => 1,
                    'vertical_align' => 'top',
                    'elements'       => [
                        [
                            'tag'     => 'markdown',
                            'content' => "**📝 Ghi chú: <font color='red'>" . (!empty($booking_data['booking_note']) ? $booking_data['booking_note'] : $booking_data['note']) . '</font>**'
                        ]
                    ]
                ]
            ]
        ];
    }

    $elements[] = [
        'tag'     => 'action',
        'actions' => [
            [
                'tag'  => 'button',
                'text' => [
                    'tag'     => 'plain_text',
                    'content' => 'Xem chi tiết'
                ],
                'type'      => 'primary',
                'multi_url' => [
                    'url'         => $booking_data['link_bookingnew'],
                    'pc_url'      => '',
                    'android_url' => '',
                    'ios_url'     => ''
                ]
            ]
        ]
    ];

    $elements[] = ['tag' => 'hr'];

    $elements[] = [
        'tag'  => 'div',
        'text' => [
            'content' => "**Nguồn: <font color='green'>{$booking_data['power_by']}</font>**",
            'tag'     => 'lark_md'
        ]
    ];

    return [
        'config' => [
            'wide_screen_mode' => true
        ],
        'elements' => $elements,
        'header'   => [
            'template' => 'green',
            'title'    => [
                'content' => 'THÔNG BÁO LỊCH HẸN MỚI',
                'tag'     => 'plain_text'
            ]
        ]
    ];
}

/**
 * Get cancel reason Vietnamese text
 */
function get_cancel_reason_text_lark($reason_code) {
    $reasons = [
        'test'                => 'Test',
        'khach_bom_lich'      => 'Khách bom lịch',
        'khach_yeu_cau_huy'   => 'Khách yêu cầu hủy',
        'tho_off_dot_xuat'    => 'Thợ off đột xuất'
    ];
    return isset($reasons[$reason_code]) ? $reasons[$reason_code] : '';
}

/**
 * Build booking cancellation card
 */
function build_booking_cancellation_card($booking_data, $id_hairdresser) {
    // Lấy lý do hủy nếu có
    $cancel_reason = '';
    if (!empty($booking_data['cancel_reason'])) {
        $cancel_reason_text = get_cancel_reason_text_lark($booking_data['cancel_reason']);
        if ($cancel_reason_text) {
            $cancel_reason = "**🔖 Lý do hủy: <font color='orange'>{$cancel_reason_text}</font>**\n";
        }
    }

    // Lấy chi nhánh
    $branch = !empty($booking_data['branch']) ? $booking_data['branch'] : (!empty($booking_data['branch_name']) ? $booking_data['branch_name'] : '');

    // Build elements array
    $elements = [];

    // Booking ID
    $elements[] = [
        'tag'        => 'markdown',
        'content'    => "**<font color='red'>{$booking_data['id_booking']}</font>**",
        'text_align' => 'center'
    ];

    // Thời gian + Khách hàng
    $elements[] = [
        'tag'    => 'div',
        'fields' => [
            [
                'is_short' => true,
                'text'     => [
                    'tag'     => 'lark_md',
                    'content' => "**📅 Thời gian:**\n {$booking_data['booking_date']} {$booking_data['booking_time']}"
                ]
            ],
            [
                'is_short' => true,
                'text'     => [
                    'tag'     => 'lark_md',
                    'content' => "**🧑‍💼 Khách hàng:** \n{$booking_data['customer_name']}"
                ]
            ]
        ]
    ];

    // Chi nhánh - chỉ hiển thị khi bật chế độ đa chi nhánh
    if (is_multi_branch_enabled()) {
        $elements[] = [
            'tag'    => 'div',
            'fields' => [
                [
                    'is_short' => true,
                    'text'     => [
                        'tag'     => 'lark_md',
                        'content' => "**🏢 Chi nhánh:**\n" . ($branch ?: '_Chưa xác định_')
                    ]
                ],
                [
                    'is_short' => true,
                    'text'     => [
                        'tag'     => 'lark_md',
                        'content' => '' // Empty cell
                    ]
                ]
            ]
        ];
    }

    // Dịch vụ + Thợ
    $elements[] = [
        'tag'    => 'div',
        'fields' => [
            [
                'is_short' => true,
                'text'     => [
                    'tag'     => 'lark_md',
                    'content' => "**✂️ Dịch vụ:** \n{$booking_data['service_name']}"
                ]
            ],
            [
                'is_short' => true,
                'text'     => [
                    'tag'     => 'lark_md',
                    'content' => "**💈 Thợ:** \n<at id=$id_hairdresser></at>"
                ]
            ]
        ]
    ];

    // Ghi chú (nếu có)
    if (!empty($booking_data['booking_note']) || !empty($booking_data['note'])) {
        $elements[] = [
            'tag'              => 'column_set',
            'flex_mode'        => 'none',
            'background_style' => 'grey',
            'columns'          => [
                [
                    'tag'            => 'column',
                    'width'          => 'weighted',
                    'weight'         => 1,
                    'vertical_align' => 'top',
                    'elements'       => [
                        [
                            'tag'     => 'markdown',
                            'content' => "**📝 Ghi chú: <font color='red'>" . (!empty($booking_data['booking_note']) ? $booking_data['booking_note'] : $booking_data['note']) . '</font>**'
                        ]
                    ]
                ]
            ]
        ];
    }

    // Trạng thái hủy + thời gian
    $elements[] = [
        'tag'        => 'markdown',
        'content'    => "**<font color='red'>📍 Trạng thái: Đã hủy</font>**\n" . $cancel_reason . '**📆 Thời gian hủy: ' . current_time('Y-m-d H:i:s') . '**',
        'text_align' => 'center'
    ];

    // HR
    $elements[] = [
        'tag' => 'hr'
    ];

    // Nguồn
    $elements[] = [
        'tag'  => 'div',
        'text' => [
            'content' => "**Nguồn: <font color='green'>{$booking_data['power_by']}</font>**",
            'tag'     => 'lark_md'
        ]
    ];

    return [
        'config' => [
            'wide_screen_mode' => true
        ],
        'elements' => $elements,
        'header'   => [
            'template' => 'red',
            'title'    => [
                'content' => 'THÔNG BÁO HỦY LỊCH HẸN',
                'tag'     => 'plain_text'
            ]
        ]
    ];
}

/**
 * Build penalty notification card
 */
function build_penalty_notification_card($penalty_data) {
    $invoice_id = $penalty_data['invoice_id'];
    $reasons    = $penalty_data['reasons'];
    $services   = $penalty_data['services'];
    $note       = $penalty_data['note'] ?? null; // Nhận note nếu có
    $timestamp  = current_time('Y-m-d H:i:s');

    $reason_text = implode(', ', array_map(function($reason) {
        return ucfirst(str_replace('_', ' ', $reason));
    }, $reasons));

    $services_text = '';
    foreach ($services as $service) {
        $services_text .= "- {$service['service_name']} (Thợ: {$service['staff_name']})\n";
    }

    // Tạo nội dung ghi chú: ưu tiên note từ penalty_data, nếu không thì dùng default
    $note_content = $note
        ? "📌 *Ghi chú*: {$note}"
        : '📌 *Ghi chú*: Vui lòng kiểm tra và xử lý truy thu này!';

    return [
        'config' => [
            'wide_screen_mode' => true,
            'update_multi'     => true
        ],
        'header' => [
            'template' => 'red',
            'title'    => [
                'content' => '📢 THÔNG BÁO TRUY THU 📢',
                'tag'     => 'plain_text'
            ]
        ],
        'elements' => [
            [
                'tag'  => 'div',
                'text' => [
                    'content' => "**🧾 Hóa đơn**: __{$invoice_id}__\n" .
                                 "**📋 Lý do truy thu**: {$reason_text}\n" .
                                 "**💇 Dịch vụ bị truy thu**:\n{$services_text}" .
                                 "**📅 Thời gian**: {$timestamp}",
                    'tag' => 'lark_md'
                ]
            ],
            ['tag' => 'hr'],
            [
                'tag'  => 'div',
                'text' => [
                    'content' => $note_content,
                    'tag'     => 'lark_md'
                ]
            ]
        ]
    ];
}

/**
 * Build missing image reminder card
 * Gửi thông báo nhắc nhở upload hình cho các hóa đơn thiếu hình
 *
 * @param array $data Data bao gồm: today (date), no_image_no_reason (array), no_image_with_reason (array), upload_url (string)
 * @param string $bot_type Bot type: 'interactive' or 'webhook'
 */
function build_missing_image_reminder_card($data, $bot_type = 'interactive') {
    $today                = $data['today'];
    $no_image_no_reason   = $data['no_image_no_reason'];
    $no_image_with_reason = $data['no_image_with_reason'];
    $upload_url           = $data['upload_url'];

    // Chuẩn bị card elements
    $elements = [
        [
            'tag'  => 'div',
            'text' => [
                'content' => "**Ngày kiểm tra**: __{$today}__ 📅",
                'tag'     => 'lark_md'
            ]
        ],
        ['tag' => 'hr']
    ];

    if (!empty($no_image_no_reason)) {
        $content = "**🔴 Thợ quên tải hình ảnh (không có lý do):**\n";
        foreach ($no_image_no_reason as $staff) {
            $name = $staff['ou_id'] ? "<at id={$staff['ou_id']}>{$staff['display_name']}</at>" : $staff['display_name'];
            $content .= "- **{$name}** (Hóa đơn: __{$staff['invoice_id']}__)\n";
        }
        $elements[] = [
            'tag'  => 'div',
            'text' => [
                'content' => $content,
                'tag'     => 'lark_md'
            ]
        ];
        $elements[] = ['tag' => 'hr'];
    }

    if (!empty($no_image_with_reason)) {
        $content = "**🟡 Thợ không tải hình ảnh (có lý do):**\n";
        foreach ($no_image_with_reason as $staff) {
            $name = $staff['ou_id'] ? "<at id={$staff['ou_id']}>{$staff['display_name']}</at>" : $staff['display_name'];
            $content .= "- **{$name}** (Hóa đơn: __{$staff['invoice_id']}__, Lý do: _{$staff['reason']}_)\n";
        }
        $elements[] = [
            'tag'  => 'div',
            'text' => [
                'content' => $content,
                'tag'     => 'lark_md'
            ]
        ];
        $elements[] = ['tag' => 'hr'];
    }

    $elements[] = [
        'tag'      => 'note',
        'elements' => [
            [
                'tag'     => 'plain_text',
                'content' => '📌 Vui lòng kiểm tra và bổ sung hình ảnh hoặc lý do nếu cần!'
            ]
        ]
    ];

    $elements[] = [
        'tag'     => 'action',
        'actions' => [
            [
                'tag'  => 'button',
                'text' => [
                    'tag'     => 'plain_text',
                    'content' => '📷 Bổ sung hình ảnh'
                ],
                'type' => 'primary',
                'url'  => $upload_url
            ]
        ]
    ];

    return [
        'config' => [
            'wide_screen_mode' => true
        ],
        'header' => [
            'template' => !empty($no_image_no_reason) ? 'red' : 'yellow',
            'title'    => [
                'content' => '📢 Nhắc Nhở Hóa Đơn Thiếu Hình Ảnh',
                'tag'     => 'plain_text'
            ]
        ],
        'elements' => $elements
    ];
}

/**
 * Build inventory check card
 * Thông báo kiểm kê tồn kho (webhook only, no buttons)
 *
 * @param array $data Data bao gồm: check_code, current_date, employee_ou_id, employee_name, total_products, mismatched_count, mismatched_items (array)
 * @param string $bot_type Bot type: 'interactive' or 'webhook'
 */
function build_inventory_check_card($data, $bot_type = 'interactive') {
    $all_match = empty($data['mismatched_items']);

    $content = "**Mã phiếu**: __{$data['check_code']}__ 📋\n" .
               "**Ngày kiểm kê**: __{$data['current_date']}__ 📅\n" .
               "**Nhân viên**: __<at id={$data['employee_ou_id']}>{$data['employee_name']}</at>__\n" .
               "**Tổng sản phẩm**: __{$data['total_products']}__ | **Không khớp**: __{$data['mismatched_count']}__\n\n";

    if ($all_match) {
        $content .= '✅ Tất cả sản phẩm khớp với tồn kho hiện tại.';
    } else {
        $content .= "⚠️ **Sản phẩm không khớp**:\n" . implode("\n", $data['mismatched_items']);
    }

    return [
        'header' => [
            'template' => $all_match ? 'green' : 'yellow',
            'title'    => [
                'content' => $all_match ? '✅ Kiểm kê tồn kho thành công' : '⚠️ Kiểm kê tồn kho có sai lệch',
                'tag'     => 'plain_text'
            ]
        ],
        'elements' => [
            [
                'tag'  => 'div',
                'text' => [
                    'content' => $content,
                    'tag'     => 'lark_md'
                ]
            ],
            ['tag' => 'hr'],
            [
                'tag'  => 'div',
                'text' => [
                    'content' => '📌 *Ghi chú*: Vui lòng kiểm tra và xử lý nếu có sai lệch!',
                    'tag'     => 'lark_md'
                ]
            ]
        ]
    ];
}

/**
 * Build feedback card
 * Gửi thông báo đánh giá tốt/tệ (webhook only, no buttons)
 *
 * @param array $data Feedback data bao gồm: invoice_id, customer_name, service_name, staff_name, created_at, service_rating, staff_rating, feedback, is_offline
 * @param string $type 'good' or 'bad'
 * @param string $bot_type Bot type: 'interactive' or 'webhook'
 */
function build_feedback_card($data, $type = 'good', $bot_type = 'interactive') {
    return [
        'header' => [
            'template' => ($type === 'bad') ? 'red' : 'green',
            'title'    => [
                'content' => ($type === 'bad') ? '📢 Đánh Giá Tệ 📢' : '🎉 Đánh Giá Tốt 🎉',
                'tag'     => 'plain_text'
            ]
        ],
        'elements' => [
            [
                'tag'  => 'div',
                'text' => [
                    'content' => "**Hóa đơn**: __{$data['invoice_id']}__ 🧾\n" .
                                 "**Khách hàng**: __{$data['customer_name']}__ 👤\n" .
                                 "**Dịch vụ**: {$data['service_name']} 💇\n" .
                                 "**Thợ phục vụ**: {$data['staff_name']} 👷\n" .
                                 "**Ngày**: {$data['created_at']} 📅\n" .
                                 "**Đánh giá dịch vụ**: <font color='" . ($type === 'bad' ? 'red' : 'green') . "'>{$data['service_rating']}</font>\n" .
                                 "**Đánh giá thợ**: <font color='" . ($type === 'bad' ? 'red' : 'green') . "'>{$data['staff_rating']}</font>\n" .
                                 "**Phản hồi**: {$data['feedback']}\n" .
                                 '**Loại đánh giá**: ' . ($type === 'bad' && !empty($data['is_offline']) && $data['is_offline'] ? 'Trực tiếp tại Shop' : 'Đánh giá từ hóa đơn'),
                    'tag' => 'lark_md'
                ]
            ],
            ['tag' => 'hr'],
            [
                'tag'  => 'div',
                'text' => [
                    'content' => ($type === 'bad') ? '📌 *Ghi chú*: Thay vì buồn phiền và sợ hãi hãy thay đổi để tốt hơn!' : '📌 *Ghi chú*: Chúc mừng bro!',
                    'tag'     => 'lark_md'
                ]
            ]
        ]
    ];
}

/**
 * Build daily appointment thread card
 * Tạo thread tổng hợp lịch hẹn hàng ngày (webhook only, no buttons)
 *
 * @param string $booking_date Ngày đặt lịch
 * @param string $image_key Lark image key
 * @param string $bot_type Bot type: 'interactive' or 'webhook'
 */
function build_daily_appointment_thread_card($booking_date, $image_key = '', $bot_type = 'interactive') {
    return [
        'config' => [
            'wide_screen_mode' => true
        ],
        'header' => [
            'template' => 'grey',
            'title'    => [
                'content' => "📅 TỔNG HỢP LỊCH HẸN NGÀY: $booking_date",
                'tag'     => 'plain_text'
            ]
        ],
        'elements' => [
            [
                'tag'     => 'img',
                'img_key' => $image_key ?: 'img_v3_02dl_fbb7f4ba-3746-4127-9c61-70f758dfd0hu',
                'alt'     => [
                    'tag'     => 'plain_text',
                    'content' => ''
                ],
                'mode'    => 'fit_horizontal',
                'preview' => true
            ]
        ]
    ];
}

/**
 * Build API test notification card
 * Card đơn giản để test kết nối Lark bot
 *
 * @param string $bot_name Bot name being tested
 * @param string $test_time Test timestamp
 * @return array Card data
 */
function build_api_test_card($bot_name, $test_time) {
    return [
        'header'   => [
            'template' => 'green',
            'title'    => [
                'content' => '✅ KIỂM TRA KẾT NỐI API',
                'tag'     => 'plain_text'
            ]
        ],
        'elements' => [
            [
                'tag'  => 'div',
                'text' => [
                    'content' => "**Bot:** {$bot_name}\n" .
                                 "**Thời gian:** {$test_time}\n" .
                                 "**Trạng thái:** Kết nối thành công ✓\n\n" .
                                 '_Đây là tin nhắn test tự động từ hệ thống._',
                    'tag'     => 'lark_md'
                ]
            ]
        ]
    ];
}

/**
 * Build approval request notification card
 * Card thông báo đơn xin phép với 2 nút Duyệt/Từ chối
 *
 * @param array $request_data Request data from database
 * @return array Card data for Lark
 */
function build_approval_request_card($request_data) {
    $request_id   = $request_data['id'];
    $request_no   = $request_data['request_no'];
    $request_type = $request_data['request_type'];
    $staff_name   = $request_data['staff_name'];
    $status       = $request_data['status'];

    // Map request type to display name
    $type_names = [
        'late_early'     => '📅 Đơn xin đi trễ/về sớm',
        'leave'          => '🏖️ Đơn xin nghỉ phép',
        'overtime'       => '⏰ Đơn xin tăng ca',
        'salary_advance' => '💵 Đơn xin ứng lương'
    ];
    $type_display = $type_names[$request_type] ?? $request_type;

    // Build content based on type
    $content_lines = [
        "**Mã đơn:** {$request_no}",
        "**Loại đơn:** {$type_display}",
        "**Nhân viên:** {$staff_name}",
    ];

    // Add type-specific fields
    switch ($request_type) {
        case 'late_early':
            $date            = !empty($request_data['start_date']) ? date('d/m/Y', strtotime($request_data['start_date'])) : 'N/A';
            $content_lines[] = "**Ngày:** {$date}";
            if (!empty($request_data['start_time'])) {
                $content_lines[] = "**Giờ vào:** {$request_data['start_time']}";
            }
            if (!empty($request_data['end_time'])) {
                $content_lines[] = "**Giờ về:** {$request_data['end_time']}";
            }
            break;

        case 'leave':
            $start_date      = !empty($request_data['start_date']) ? date('d/m/Y', strtotime($request_data['start_date'])) : 'N/A';
            $end_date        = !empty($request_data['end_date']) ? date('d/m/Y', strtotime($request_data['end_date'])) : 'N/A';
            $content_lines[] = "**Từ ngày:** {$start_date}";
            $content_lines[] = "**Đến ngày:** {$end_date}";
            break;

        case 'overtime':
            $date            = !empty($request_data['start_date']) ? date('d/m/Y', strtotime($request_data['start_date'])) : 'N/A';
            $content_lines[] = "**Ngày tăng ca:** {$date}";
            if (!empty($request_data['overtime_hours'])) {
                $content_lines[] = "**Số giờ:** {$request_data['overtime_hours']} giờ";
            }
            break;

        case 'salary_advance':
            if (!empty($request_data['amount'])) {
                $content_lines[] = '**Số tiền:** ' . number_format($request_data['amount'], 0, '.', ',') . ' VNĐ';
            }
            break;
    }

    // Add note if exists
    if (!empty($request_data['note'])) {
        $content_lines[] = "**Lý do:** {$request_data['note']}";
    }

    // Add created time
    $created_at      = !empty($request_data['created_at']) ? date('H:i d/m/Y', strtotime($request_data['created_at'])) : '';
    $content_lines[] = "**Thời gian gửi:** {$created_at}";

    $content = implode("\n", $content_lines);

    return [
        'header'   => [
            'template' => 'orange',
            'title'    => [
                'content' => "📋 ĐƠN XIN PHÉP - {$request_no}",
                'tag'     => 'plain_text'
            ]
        ],
        'elements' => [
            [
                'tag'  => 'div',
                'text' => [
                    'content' => $content,
                    'tag'     => 'lark_md'
                ]
            ],
            ['tag' => 'hr'],
            [
                'tag'     => 'action',
                'actions' => [
                    [
                        'tag'  => 'button',
                        'text' => [
                            'tag'     => 'plain_text',
                            'content' => '✅ Duyệt đơn'
                        ],
                        'type'  => 'primary',
                        'value' => [
                            'type'          => 'approval_request',
                            'id'            => (string) $request_id,
                            'trang_thai'    => 'ĐÃ DUYỆT',
                            'approver_name' => 'Admin'
                        ]
                    ],
                    [
                        'tag'  => 'button',
                        'text' => [
                            'tag'     => 'plain_text',
                            'content' => '❌ Từ chối'
                        ],
                        'type'  => 'danger',
                        'value' => [
                            'type'          => 'approval_request',
                            'id'            => (string) $request_id,
                            'trang_thai'    => 'KHÔNG DUYỆT',
                            'approver_name' => 'Admin'
                        ]
                    ]
                ]
            ]
        ]
    ];
}

/**
 * Build approval request status card (after approval/rejection)
 * Card hiển thị trạng thái sau khi đã duyệt/từ chối
 *
 * @param array $request_data Request data from database
 * @param string $status_text Status text (e.g., '✅ Đã Duyệt')
 * @param string $status_color Status color ('green' or 'red')
 * @return array Card data for Lark
 */
function build_approval_status_card($request_data, $status_text, $status_color) {
    $request_no   = $request_data['request_no']   ?? '';
    $request_type = $request_data['request_type'] ?? '';
    $staff_name   = $request_data['staff_name']   ?? '';
    $approver     = $request_data['approved_by']  ?? 'Admin';
    $approved_at  = !empty($request_data['approved_at']) ? date('H:i d/m/Y', strtotime($request_data['approved_at'])) : date('H:i d/m/Y');

    // Map request type to display name
    $type_names = [
        'late_early'     => '📅 Đơn xin đi trễ/về sớm',
        'leave'          => '🏖️ Đơn xin nghỉ phép',
        'overtime'       => '⏰ Đơn xin tăng ca',
        'salary_advance' => '💵 Đơn xin ứng lương'
    ];
    $type_display = $type_names[$request_type] ?? $request_type;

    $template = $status_color === 'green' ? 'green' : 'red';

    $content_lines = [
        "**Mã đơn:** {$request_no}",
        "**Loại đơn:** {$type_display}",
        "**Nhân viên:** {$staff_name}",
        "**Trạng thái:** <font color='{$status_color}'>{$status_text}</font>",
        "**Người duyệt:** {$approver}",
        "**Thời gian duyệt:** {$approved_at}"
    ];

    $content = implode("\n", $content_lines);

    return [
        'header'   => [
            'template' => $template,
            'title'    => [
                'content' => "📋 ĐƠN XIN PHÉP - {$request_no}",
                'tag'     => 'plain_text'
            ]
        ],
        'elements' => [
            [
                'tag'  => 'div',
                'text' => [
                    'content' => $content,
                    'tag'     => 'lark_md'
                ]
            ],
            ['tag' => 'hr'],
            [
                'tag'      => 'note',
                'elements' => [
                    [
                        'tag'     => 'plain_text',
                        'content' => '🔔 Đơn này đã được xử lý.'
                    ]
                ]
            ]
        ]
    ];
}

/**
 * Chuyển đổi HTML sang Lark Markdown format
 * Lark MD hỗ trợ: **bold**, *italic*, ~~strikethrough~~, [link](url)
 *
 * @param string $html HTML content
 * @return string Lark markdown content
 */
function convert_html_to_lark_md($html) {
    if (empty($html)) return '';

    // Chuyển các thẻ HTML sang Lark markdown
    $content = $html;

    // Bold: <strong>, <b> -> **text**
    $content = preg_replace('/<(strong|b)>(.*?)<\/(strong|b)>/is', '**$2**', $content);

    // Italic: <em>, <i> -> *text*
    $content = preg_replace('/<(em|i)>(.*?)<\/(em|i)>/is', '*$2*', $content);

    // Underline: <u> -> (Lark không hỗ trợ underline, giữ nguyên text)
    $content = preg_replace('/<u>(.*?)<\/u>/is', '$1', $content);

    // Strikethrough: <s>, <strike>, <del> -> ~~text~~
    $content = preg_replace('/<(s|strike|del)>(.*?)<\/(s|strike|del)>/is', '~~$2~~', $content);

    // Links: <a href="url">text</a> -> [text](url)
    $content = preg_replace('/<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)<\/a>/is', '[$2]($1)', $content);

    // List items: <li> -> - text
    $content = preg_replace('/<li[^>]*>(.*?)<\/li>/is', "- $1\n", $content);

    // Remove list wrappers
    $content = preg_replace('/<\/?[ou]l[^>]*>/i', '', $content);

    // Xuống dòng: <br>, <br/>, </p>, </div>
    $content = preg_replace('/<br\s*\/?>/i', "\n", $content);
    $content = preg_replace('/<\/p>/i', "\n", $content);
    $content = preg_replace('/<\/div>/i', "\n", $content);

    // Xóa các HTML tags còn lại
    $content = wp_strip_all_tags($content);

    // Dọn dẹp multiple newlines
    $content = preg_replace("/\n{3,}/", "\n\n", $content);

    // Trim whitespace
    $content = trim($content);

    return $content;
}

/**
 * Build general staff notification card
 * Thông báo chung cho nhân viên gửi qua Group (webhook)
 *
 * @param string $title Notification title
 * @param string $content Notification content
 * @param int $notification_id Notification ID
 * @return array Card structure
 */
function build_staff_notification_card($title, $content, $notification_id) {
    // Chuyển HTML formatting sang Lark markdown
    $lark_content = convert_html_to_lark_md($content);

    // Cắt ngắn nội dung nhưng giữ formatting
    $short_content = mb_substr($lark_content, 0, 500);
    if (mb_strlen($lark_content) > 500) {
        $short_content .= '...';
    }

    return [
        'header' => [
            'template' => 'green',
            'title' => [
                'content' => '📢 THÔNG BÁO MỚI',
                'tag' => 'plain_text'
            ]
        ],
        'elements' => [
            [
                'tag' => 'markdown',
                'content' => '**' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '**',
                'text_align' => 'center'
            ],
            [
                'tag' => 'div',
                'text' => [
                    'content' => $short_content,
                    'tag' => 'lark_md'
                ]
            ],
            ['tag' => 'hr'],
            [
                'tag' => 'div',
                'text' => [
                    'content' => '🔗 [Xem chi tiết](' . home_url('/app?notification=' . $notification_id) . ')',
                    'tag' => 'lark_md'
                ]
            ],
            [
                'tag' => 'note',
                'elements' => [
                    [
                        'tag' => 'plain_text',
                        'content' => '⏰ ' . date('d/m/Y H:i')
                    ]
                ]
            ]
        ]
    ];
}
?>
