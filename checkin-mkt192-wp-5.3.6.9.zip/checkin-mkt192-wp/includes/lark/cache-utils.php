<?php
// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class CacheManager
 * Centralized cache management for salary and inventory transactions
 */
class CacheManager {
    private static $allowed_prefixes = [
        CACHE_PREFIX_SALARY => 'salary_notification.log',
        CACHE_PREFIX_INVENTORY => 'stock_transaction_notification.log',
        'transaction' => 'transaction.log'
    ];

    /**
     * Store data in cache
     */
    public static function store($transaction_id, $data, $prefix = 'transaction', $expire = 3600) {
        if (!isset(self::$allowed_prefixes[$prefix])) {
            throw new Exception("Invalid cache prefix: $prefix");
        }
        $cache_key = "{$prefix}_{$transaction_id}";
        $result = set_transient($cache_key, $data, $expire);
        self::write_log("Stored cache", [
            'transaction_id' => $transaction_id,
            'cache_key' => $cache_key,
            'prefix' => $prefix
        ], self::$allowed_prefixes[$prefix]);
        return $result;
    }

    /**
     * Retrieve data from cache with optional fallback
     */
    public static function get($transaction_id, $prefix = 'transaction', $fallback_callback = null) {
        if (!isset(self::$allowed_prefixes[$prefix])) {
            throw new Exception("Invalid cache prefix: $prefix");
        }
        $cache_key = "{$prefix}_{$transaction_id}";
        $data = get_transient($cache_key);
        if ($data === false && $fallback_callback !== null) {
            $data = call_user_func($fallback_callback, $transaction_id);
            if ($data) {
                self::store($transaction_id, $data, $prefix);
            }
        }
        if ($data) {
            self::write_log("Retrieved cache", [
                'transaction_id' => $transaction_id,
                'cache_key' => $cache_key,
                'prefix' => $prefix
            ], self::$allowed_prefixes[$prefix]);
        }
        return $data;
    }

    /**
     * Delete data from cache
     */
    public static function delete($transaction_id, $prefix = 'transaction') {
        if (!isset(self::$allowed_prefixes[$prefix])) {
            throw new Exception("Invalid cache prefix: $prefix");
        }
        $cache_key = "{$prefix}_{$transaction_id}";
        $result = delete_transient($cache_key);
        self::write_log("Deleted cache", [
            'transaction_id' => $transaction_id,
            'cache_key' => $cache_key,
            'prefix' => $prefix
        ], self::$allowed_prefixes[$prefix]);
        return $result;
    }

    /**
     * Write log to file
     */
    public static function write_log($message, $data = [], $log_file = 'transaction.log') {
        $log_file_path = CHECKIN_PLUGIN_DIR . '/includes/lark/logs/' . $log_file;
        if (!file_exists(dirname($log_file_path))) {
            mkdir(dirname($log_file_path), 0755, true);
        }
        $timestamp = date('Y-m-d H:i:s');
        $log_entry = "[$timestamp] $message\n";
        if ($data) {
            $log_entry .= "Data: " . json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
        }
        $log_entry .= "----------------------------------------\n";
        file_put_contents($log_file_path, $log_entry, FILE_APPEND | LOCK_EX);
    }
}
?>