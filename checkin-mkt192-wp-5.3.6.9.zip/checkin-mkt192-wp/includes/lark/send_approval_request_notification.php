<?php

/**
 * Gửi thông báo đơn xin phép qua Lark Bot
 */

if (!defined('ABSPATH')) {
    exit;
}

// Include required files
require_once plugin_dir_path(__FILE__) . 'card-builder.php';

// Check if function exists before including
if (!function_exists('send_lark_message')) {
    $lark_message_file = plugin_dir_path(__FILE__) . 'send-lark-message.php';
    if (file_exists($lark_message_file)) {
        require_once $lark_message_file;
    }
}

/**
 * Lấy chat_id của người nhận
 */
function get_approval_receiver_chat_id($receiver_email) {
    global $wpdb;

    // Tìm user theo email
    $table_name = $wpdb->prefix . 'checkin_mkt192_employees';
    $employee   = $wpdb->get_row($wpdb->prepare(
        "SELECT lark_chat_id FROM $table_name WHERE email = %s AND status = 'active'",
        $receiver_email
    ));

    return $employee ? $employee->lark_chat_id : null;
}

/**
 * Lấy màu theo loại đơn
 */
function get_request_type_color($type) {
    $colors = [
        'late_early'     => 'orange',
        'leave'          => 'blue',
        'overtime'       => 'green',
        'salary_advance' => 'red'
    ];
    return $colors[$type] ?? 'blue';
}

/**
 * Gửi thông báo đơn xin phép mới
 *
 * @param int $request_id ID của đơn
 * @param array $request_data Dữ liệu đơn
 * @return array Result với status và message
 */
function send_approval_request_notification($request_id, $request_data) {
    global $wpdb;

    // Lấy thông tin người gửi (hỗ trợ cả staff_name và sender_name để tương thích)
    $sender_name  = $request_data['staff_name']   ?? $request_data['sender_name'] ?? 'Nhân viên';
    $sender_email = $request_data['sender_email'] ?? '';

    // Lấy thông tin người nhận (manager/approver)
    $receiver_email = $request_data['receiver_email'] ?? '';

    if (empty($receiver_email)) {
        return [
            'success' => false,
            'message' => 'Không tìm thấy email người nhận'
        ];
    }

    // Lấy chat_id của người nhận
    $receiver_chat_id = get_approval_receiver_chat_id($receiver_email);

    if (empty($receiver_chat_id)) {
        return [
            'success' => false,
            'message' => 'Không tìm thấy chat_id của người nhận'
        ];
    }

    // Build card message
    $card = build_approval_request_card($request_id, $request_data);

    // Gửi message qua Lark
    if (function_exists('send_lark_message')) {
        $result = send_lark_message($receiver_chat_id, $card, 'interactive');

        if ($result['success']) {
            // Lưu message_id để track
            $wpdb->update(
                $wpdb->prefix . 'checkin_mkt192_approval_requests',
                ['lark_message_id' => $result['message_id'] ?? ''],
                ['id'              => $request_id],
                ['%s'],
                ['%d']
            );

            return [
                'success'    => true,
                'message'    => 'Đã gửi thông báo qua Lark',
                'message_id' => $result['message_id'] ?? ''
            ];
        }

        return [
            'success' => false,
            'message' => 'Lỗi gửi Lark: ' . ($result['error'] ?? 'Unknown error')
        ];
    }

    return [
        'success' => false,
        'message' => 'Chức năng gửi Lark không khả dụng'
    ];
}

/**
 * Gửi thông báo cập nhật trạng thái đơn
 *
 * @param int $request_id ID của đơn
 * @param string $new_status Trạng thái mới (approved/rejected)
 * @param string $approver_name Tên người duyệt
 * @param string $approver_note Ghi chú từ người duyệt
 * @return array Result với status và message
 */
function send_approval_status_notification($request_id, $new_status, $approver_name = '', $approver_note = '') {
    global $wpdb;

    // Lấy thông tin đơn
    $table_name = $wpdb->prefix . 'checkin_mkt192_approval_requests';
    $request    = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $table_name WHERE id = %d",
        $request_id
    ), ARRAY_A);

    if (!$request) {
        return [
            'success' => false,
            'message' => 'Không tìm thấy đơn'
        ];
    }

    // Lấy chat_id của người gửi đơn gốc
    $sender_chat_id = get_approval_receiver_chat_id($request['user_email']);

    if (empty($sender_chat_id)) {
        return [
            'success' => false,
            'message' => 'Không tìm thấy chat_id của người gửi đơn'
        ];
    }

    // Merge request data với status info
    $request_data = array_merge($request, [
        'status'        => $new_status,
        'approver_name' => $approver_name,
        'approver_note' => $approver_note
    ]);

    // Build card message
    $card = build_approval_status_card($request_id, $request_data);

    // Gửi message qua Lark
    if (function_exists('send_lark_message')) {
        $result = send_lark_message($sender_chat_id, $card, 'interactive');

        return [
            'success' => $result['success'],
            'message' => $result['success'] ? 'Đã gửi thông báo trạng thái' : ('Lỗi: ' . ($result['error'] ?? 'Unknown'))
        ];
    }

    return [
        'success' => false,
        'message' => 'Chức năng gửi Lark không khả dụng'
    ];
}

/**
 * Xử lý callback từ Lark khi người dùng click Approve/Reject
 *
 * @param array $callback_data Dữ liệu callback từ Lark
 * @return array Result
 */
function handle_approval_request_callback($callback_data) {
    $action       = $callback_data['action']   ?? [];
    $action_value = $action['value']           ?? '';
    $operator     = $callback_data['operator'] ?? [];
    $operator_id  = $operator['user_id']       ?? '';

    // Parse action value: format "action_type:request_id"
    // Example: "approve:123" or "reject:123"
    $parts = explode(':', $action_value);

    if (count($parts) < 2) {
        return [
            'success' => false,
            'message' => 'Invalid action format'
        ];
    }

    $action_type = $parts[0]; // approve hoặc reject
    $request_id  = intval($parts[1]);

    if (!in_array($action_type, ['approve', 'reject'])) {
        return [
            'success' => false,
            'message' => 'Invalid action type'
        ];
    }

    // Lấy thông tin người duyệt từ Lark user_id
    global $wpdb;
    $employees_table = $wpdb->prefix . 'checkin_mkt192_employees';
    $approver        = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $employees_table WHERE lark_user_id = %s AND status = 'active'",
        $operator_id
    ));

    $approver_name = $approver ? $approver->display_name : 'Người duyệt';

    // Cập nhật trạng thái đơn
    $new_status = ($action_type === 'approve') ? 'approved' : 'rejected';
    $result     = update_approval_request_status($request_id, $new_status, $approver_name);

    if ($result['success']) {
        // Gửi thông báo cho người gửi đơn
        send_approval_status_notification($request_id, $new_status, $approver_name);
    }

    return $result;
}

/**
 * Cập nhật trạng thái đơn xin phép
 *
 * @param int $request_id ID của đơn
 * @param string $new_status Trạng thái mới
 * @param string $approver_name Tên người duyệt
 * @param string $approver_note Ghi chú
 * @return array Result
 */
function update_approval_request_status($request_id, $new_status, $approver_name = '', $approver_note = '') {
    global $wpdb;
    $table_name = $wpdb->prefix . 'checkin_mkt192_approval_requests';

    // Kiểm tra đơn tồn tại và đang pending
    $request = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM $table_name WHERE id = %d",
        $request_id
    ));

    if (!$request) {
        return [
            'success' => false,
            'message' => 'Không tìm thấy đơn'
        ];
    }

    if ($request->status !== 'pending') {
        return [
            'success' => false,
            'message' => 'Đơn đã được xử lý trước đó'
        ];
    }

    // Cập nhật trạng thái
    $update_data = [
        'status'      => $new_status,
        'approved_by' => $approver_name,
        'approved_at' => current_time('mysql')
    ];

    if (!empty($approver_note)) {
        $update_data['approver_note'] = $approver_note;
    }

    $updated = $wpdb->update(
        $table_name,
        $update_data,
        ['id' => $request_id],
        ['%s', '%s', '%s', '%s'],
        ['%d']
    );

    if ($updated !== false) {
        return [
            'success'    => true,
            'message'    => 'Đã cập nhật trạng thái đơn',
            'new_status' => $new_status
        ];
    }

    return [
        'success' => false,
        'message' => 'Lỗi cập nhật database'
    ];
}
