<?php

/**
 * Lark Helper Class
 *
 * Helper class để gửi tin nhắn qua Lark/Larksuite
 * Sử dụng App ID và App Secret được cấu hình trong Brand Settings
 */

if (!defined('ABSPATH')) {
    exit;
}

class Checkin_MKT192_Lark_Helper {

    /**
     * Kiểm tra xem Lark có được kích hoạt không
     *
     * @return bool
     */
    public static function is_enabled() {
        return get_option('checkin_use_lark', '0') === '1';
    }

    /**
     * Lấy App ID từ settings
     *
     * @return string
     */
    public static function get_app_id() {
        return get_option('checkin_lark_app_id', '');
    }

    /**
     * Lấy App Secret từ settings
     *
     * @return string
     */
    public static function get_app_secret() {
        return get_option('checkin_lark_app_secret', '');
    }

    /**
     * Kiểm tra xem Lark đã được cấu hình đầy đủ chưa
     *
     * @return bool
     */
    public static function is_configured() {
        return self::is_enabled()
            && !empty(self::get_app_id())
            && !empty(self::get_app_secret());
    }

    /**
     * Lấy mode hiện tại: 'bot' hoặc 'admin'
     *
     * @return string
     */
    public static function get_mode() {
        return get_option('checkin_lark_mode', 'bot'); // Default: bot
    }

    /**
     * Lấy Default Chat ID
     *
     * @return string
     */
    public static function get_default_chat_id() {
        return get_option('checkin_lark_default_chat_id', '');
    }

    /**
     * Lấy access token (Bot Identity only)
     *
     * @return string|WP_Error
     */
    public static function get_access_token() {
        if (!self::is_configured()) {
            return new WP_Error('not_configured', 'Lark chưa được cấu hình đầy đủ');
        }

        // Sử dụng Tenant Access Token (Bot Identity)
        return get_lark_tenant_access_token(
            self::get_app_id(),
            self::get_app_secret()
        );
    }

    /**
     * Gửi tin nhắn text đơn giản đến chat
     *
     * @param string $receive_id Chat ID (có thể là user_id, chat_id, hoặc open_id)
     * @param string $message Nội dung tin nhắn
     * @param string $receive_id_type Loại ID: 'open_id', 'user_id', 'union_id', 'email', 'chat_id'
     * @return array|WP_Error
     */
    public static function send_text_message($receive_id, $message, $receive_id_type = 'chat_id') {
        $token = self::get_access_token();
        if (is_wp_error($token)) {
            return $token;
        }

        $url = 'https://open.larksuite.com/open-apis/im/v1/messages';
        $url = add_query_arg('receive_id_type', $receive_id_type, $url);

        $payload = [
            'receive_id' => $receive_id,
            'msg_type'   => 'text',
            'content'    => json_encode([
                'text' => $message
            ])
        ];

        $response = wp_remote_post($url, [
            'headers' => [
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'application/json; charset=utf-8'
            ],
            'body'    => json_encode($payload),
            'timeout' => 30
        ]);

        if (is_wp_error($response)) {
            log_lark_untils('Lỗi khi gửi tin nhắn text', [
                'error'      => $response->get_error_message(),
                'receive_id' => $receive_id
            ]);
            return $response;
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);
        log_lark_untils('Phản hồi gửi tin nhắn text', [
            'response'   => $body,
            'receive_id' => $receive_id
        ]);

        return $body;
    }

    /**
     * Gửi message card (interactive message) đến chat
     *
     * @param string $receive_id Chat ID
     * @param array $card_content Nội dung card (theo format Lark Card)
     * @param string $receive_id_type Loại ID: 'open_id', 'user_id', 'union_id', 'email', 'chat_id'
     * @return array|WP_Error
     */
    public static function send_interactive_message($receive_id, $card_content, $receive_id_type = 'chat_id') {
        $token = self::get_access_token();
        if (is_wp_error($token)) {
            return $token;
        }

        $url = 'https://open.larksuite.com/open-apis/im/v1/messages';
        $url = add_query_arg('receive_id_type', $receive_id_type, $url);

        $payload = [
            'receive_id' => $receive_id,
            'msg_type'   => 'interactive',
            'content'    => json_encode($card_content)
        ];

        $response = wp_remote_post($url, [
            'headers' => [
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'application/json; charset=utf-8'
            ],
            'body'    => json_encode($payload),
            'timeout' => 30
        ]);

        if (is_wp_error($response)) {
            log_lark_untils('Lỗi khi gửi message card', [
                'error'      => $response->get_error_message(),
                'receive_id' => $receive_id
            ]);
            return $response;
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);
        log_lark_untils('Phản hồi gửi message card', [
            'response'   => $body,
            'receive_id' => $receive_id
        ]);

        return $body;
    }

    /**
     * Gửi tin nhắn với nhiều loại nội dung (post message)
     *
     * @param string $receive_id Chat ID
     * @param array $content Nội dung rich text
     * @param string $receive_id_type Loại ID
     * @return array|WP_Error
     */
    public static function send_post_message($receive_id, $content, $receive_id_type = 'chat_id') {
        $token = self::get_access_token();
        if (is_wp_error($token)) {
            return $token;
        }

        $url = 'https://open.larksuite.com/open-apis/im/v1/messages';
        $url = add_query_arg('receive_id_type', $receive_id_type, $url);

        $payload = [
            'receive_id' => $receive_id,
            'msg_type'   => 'post',
            'content'    => json_encode($content)
        ];

        $response = wp_remote_post($url, [
            'headers' => [
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'application/json; charset=utf-8'
            ],
            'body'    => json_encode($payload),
            'timeout' => 30
        ]);

        if (is_wp_error($response)) {
            log_lark_untils('Lỗi khi gửi post message', [
                'error'      => $response->get_error_message(),
                'receive_id' => $receive_id
            ]);
            return $response;
        }

        $body = json_decode(wp_remote_retrieve_body($response), true);
        log_lark_untils('Phản hồi gửi post message', [
            'response'   => $body,
            'receive_id' => $receive_id
        ]);

        return $body;
    }

    /**
     * Gửi tin nhắn thông báo đơn giản (wrapper function)
     * Tự động chọn định dạng phù hợp
     *
     * @param string $receive_id Chat/User ID
     * @param string $title Tiêu đề
     * @param string $content Nội dung
     * @param string $receive_id_type Loại ID
     * @return array|WP_Error
     */
    public static function send_notification($receive_id, $title, $content, $receive_id_type = 'chat_id') {
        // Tạo message card đơn giản
        $card = [
            'config' => [
                'wide_screen_mode' => true
            ],
            'header' => [
                'title' => [
                    'tag'     => 'plain_text',
                    'content' => $title
                ],
                'template' => 'blue'
            ],
            'elements' => [
                [
                    'tag'  => 'div',
                    'text' => [
                        'tag'     => 'plain_text',
                        'content' => $content
                    ]
                ]
            ]
        ];

        return self::send_interactive_message($receive_id, $card, $receive_id_type);
    }
}