<?php

/**
 * Script update bot settings để thêm 4 notification types lương mới
 *
 * Chạy: docker exec wordpress-wordpress-1 php /var/www/html/wp-content/plugins/checkin-mkt192-wp/includes/lark/update-bot-salary-types.php
 */

require_once(dirname(__FILE__, 6) . '/wp-load.php');

global $wpdb;
$table_name = $wpdb->prefix . 'checkin_mkt192_message_bot_settings';

echo "=== UPDATE BOT SALARY NOTIFICATION TYPES ===\n\n";

// Lấy tất cả bots
$bots = $wpdb->get_results("SELECT id, bot_name, bot_type, notification_types FROM $table_name ORDER BY id");

if (empty($bots)) {
    echo "❌ Không tìm thấy bot nào trong database!\n";
    exit(1);
}

echo 'Tìm thấy ' . count($bots) . " bots:\n\n";

foreach ($bots as $bot) {
    echo "Bot #{$bot->id}: {$bot->bot_name} ({$bot->bot_type})\n";
    echo "  Notification types hiện tại: {$bot->notification_types}\n";

    $types = $bot->notification_types ? explode(',', $bot->notification_types) : [];
    $types = array_map('trim', $types);

    // Xóa các type cũ liên quan đến salary
    $types = array_filter($types, function($type) {
        return !in_array($type, ['salary', 'salary_confirmation']);
    });

    $updated   = false;
    $new_types = [];

    // Logic thêm types mới dựa vào bot hiện tại
    if ($bot->bot_name === 'MKT192-Push-Noti') {
        // Bot này handle cả 4 loại (có thể tách sau)
        $salary_types = [
            'salary_report',
            'salary_report_confirmation',
            'salary_payment',
            'salary_payment_completion'
        ];

        foreach ($salary_types as $new_type) {
            if (!in_array($new_type, $types)) {
                $types[]     = $new_type;
                $new_types[] = $new_type;
                $updated     = true;
            }
        }
    }

    if ($updated) {
        $new_notification_types = implode(', ', $types);

        $result = $wpdb->update(
            $table_name,
            ['notification_types' => $new_notification_types],
            ['id'                 => $bot->id],
            ['%s'],
            ['%d']
        );

        if ($result !== false) {
            echo "  ✅ Đã update thành công!\n";
            echo "  Notification types mới: {$new_notification_types}\n";
            echo '  Đã thêm: ' . implode(', ', $new_types) . "\n";
        } else {
            echo '  ❌ Lỗi update: ' . $wpdb->last_error . "\n";
        }
    } else {
        echo "  ℹ️  Không cần update\n";
    }

    echo "\n";
}

echo "=== KẾT QUẢ SAU KHI UPDATE ===\n\n";

$bots_after = $wpdb->get_results("SELECT id, bot_name, bot_type, notification_types FROM $table_name ORDER BY id");

foreach ($bots_after as $bot) {
    echo "Bot #{$bot->id}: {$bot->bot_name}\n";
    echo "  Type: {$bot->bot_type}\n";
    echo "  Notifications: {$bot->notification_types}\n\n";
}

echo "✅ Hoàn thành!\n\n";

echo "📌 LƯU Ý:\n";
echo "  - salary_report: Webhook gửi Group nhân viên\n";
echo "  - salary_report_confirmation: Webhook gửi Group quản lý (từ website)\n";
echo "  - salary_payment: Interactive gửi cá nhân nhân viên\n";
echo "  - salary_payment_completion: Webhook gửi Group quản lý (từ Lark callback)\n\n";

echo "🔧 KHUYẾN NGHỊ:\n";
echo "  - Nên tạo riêng bot cho mỗi loại thông báo lương để dễ quản lý\n";
echo "  - Bot salary_report & salary_report_confirmation: Webhook type\n";
echo "  - Bot salary_payment: Interactive type\n";
echo "  - Bot salary_payment_completion: Webhook type\n\n";
?>
