<?php

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

require_once __DIR__ . '/lark-utils.php';

/**
 * Class xử lý gửi thông báo lịch hẹn hàng ngày qua Lark.
 */
class Checkin_MKT192_NewThreadDaily {
    /**
     * Ghi log vào file new_thread_daily.log.
     *
     * @param string $message Thông điệp log.
     * @param array  $data    Dữ liệu bổ sung (tùy chọn).
     */
    private static function write_thread_log($message, $data = []) {
        $log_file = __DIR__ . '/logs/new_thread_daily.log';
        if (!file_exists(dirname($log_file))) {
            mkdir(dirname($log_file), 0755, true);
        }
        $timestamp = date('Y-m-d H:i:s');
        $log_entry = "[$timestamp] $message\n";
        if ($data) {
            $log_entry .= 'Data: ' . json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
        }
        $log_entry .= "----------------------------------------\n";
        file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);
    }

    /**
     * Lưu thread_id vào WordPress options (ghi đè thread_id cũ).
     *
     * @param string $thread_id   ID của thread.
     * @param string $booking_date Ngày đặt lịch.
     * @return bool Kết quả lưu.
     */
    private static function save_thread_id($thread_id, $booking_date) {
        $option_name = 'lark_appointment_thread_id';

        // Lấy dữ liệu hiện tại
        $current_data = get_option($option_name, []);

        // Log dữ liệu trước khi xử lý
        self::write_thread_log('Dữ liệu trước khi lưu', [
            'current_data'     => $current_data,
            'new_thread_id'    => $thread_id,
            'new_booking_date' => $booking_date
        ]);

        // Kiểm tra xem dữ liệu cũ có phải cấu trúc flat (legacy) hay không
        // Cấu trúc flat: ['booking_date' => '...', 'thread_id' => '...', 'updated_at' => '...']
        // Cấu trúc mới: ['2025-12-04' => ['thread_id' => '...', 'booking_date' => '...', 'updated_at' => '...']]
        $is_legacy_format = isset($current_data['thread_id']) && isset($current_data['booking_date']) && !isset($current_data[$booking_date]);

        if ($is_legacy_format) {
            // Migrate dữ liệu cũ sang cấu trúc mới
            $old_booking_date = $current_data['booking_date'];
            $thread_data      = [
                $old_booking_date => [
                    'thread_id'    => $current_data['thread_id'],
                    'booking_date' => $old_booking_date,
                    'updated_at'   => $current_data['updated_at'] ?? current_time('Y-m-d H:i:s')
                ]
            ];
            self::write_thread_log('Migrate dữ liệu legacy sang cấu trúc mới', [
                'old_format' => $current_data,
                'new_format' => $thread_data
            ]);
        } else {
            $thread_data = is_array($current_data) ? $current_data : [];
        }

        // Lưu thread_id với key là booking_date, bao gồm timestamp
        // Chỉ giữ lại thread_id của ngày hiện tại (ghi đè hoàn toàn)
        $thread_data = [
            $booking_date => [
                'thread_id'    => $thread_id,
                'booking_date' => $booking_date,
                'updated_at'   => current_time('Y-m-d H:i:s')
            ]
        ];

        // Force update bằng cách xóa option cũ và thêm mới
        delete_option($option_name);
        $updated = add_option($option_name, $thread_data, '', 'no');

        // Kiểm tra xem có thực sự lưu được không bằng cách đọc lại
        $saved_data = get_option($option_name, []);
        $is_saved   = isset($saved_data[$booking_date])            &&
                    isset($saved_data[$booking_date]['thread_id']) &&
                    $saved_data[$booking_date]['thread_id'] === $thread_id;

        if ($is_saved) {
            self::write_thread_log('Lưu thread_id vào WordPress options thành công', [
                'thread_id'     => $thread_id,
                'booking_date'  => $booking_date,
                'option_name'   => $option_name,
                'all_threads'   => $saved_data,
                'update_result' => $updated,
                'verification'  => 'passed'
            ]);
            return true;
        } else {
            self::write_thread_log('Lỗi khi lưu thread_id vào WordPress options', [
                'thread_id'     => $thread_id,
                'booking_date'  => $booking_date,
                'option_name'   => $option_name,
                'intended_data' => $thread_data,
                'saved_data'    => $saved_data,
                'update_result' => $updated,
                'verification'  => 'failed'
            ]);
            return false;
        }
    }

    /**
     * Gửi card thông báo lịch hẹn hàng ngày qua Lark.
     *
     * @param string|null $booking_date Ngày đặt lịch (mặc định là hôm nay).
     * @param string      $image_key    Khóa hình ảnh (mặc định là giá trị cố định).
     * @return array Kết quả gửi.
     */
    public static function send_daily_new_thread($booking_date = null, $image_key = '') {
        // Sử dụng current_time() để lấy đúng múi giờ WordPress (UTC+7 cho VN)
        $booking_date = $booking_date ?: current_time('Y-m-d');

        // Ghi log ngữ cảnh
        $context = (defined('DOING_CRON') && DOING_CRON) ? 'Cron' : 'HTTP Request';
        self::write_thread_log("Bắt đầu gửi tin nhắn card lịch hẹn cho ngày: $booking_date", [
            'context'        => $context,
            'booking_date'   => $booking_date,
            'request_method' => $_SERVER['REQUEST_METHOD'] ?? 'N/A',
            'request_uri'    => $_SERVER['REQUEST_URI']    ?? 'N/A'
        ]);

        // Check if Lark is enabled
        if (!is_lark_enabled()) {
            $error_message = 'Lark chưa được kích hoạt';
            self::write_thread_log($error_message);
            return ['success' => false, 'message' => $error_message];
        }

        // Load Bot Manager
        require_once __DIR__ . '/class-checkin-mkt192-message-bot-manager.php';
        $bot_manager = Checkin_MKT192_Message_Bot_Manager::get_instance();

        // Kiểm tra bot cho appointment
        $bot = $bot_manager->get_bot_by_notification_type('appointment');
        if (!$bot) {
            $error_message = 'Không tìm thấy bot được cấu hình cho loại thông báo: appointment';
            self::write_thread_log($error_message);
            return ['success' => false, 'message' => $error_message];
        }

        self::write_thread_log('Thông tin bot', [
            'bot_id'   => $bot->id,
            'bot_name' => $bot->bot_name,
            'bot_type' => $bot->bot_type
        ]);

        // Load card builder
        require_once __DIR__ . '/card-builder.php';

        // Get bot type
        $bot_type = $bot->bot_type;

        // Build card using card builder
        $card = build_daily_appointment_thread_card($booking_date, $image_key, $bot_type);

        // Chuẩn bị card payload
        $card_payload = [
            'msg_type' => 'interactive',
            'card'     => $card
        ];

        self::write_thread_log('Payload gửi tới Lark', $card_payload);

        // Gửi qua Bot Manager
        $start_time    = microtime(true);
        $result        = $bot_manager->send_message('appointment', null, $card_payload);
        $response_time = microtime(true) - $start_time;

        self::write_thread_log('Phản hồi từ Bot Manager', [
            'is_error'      => is_wp_error($result),
            'result'        => $result,
            'response_time' => $response_time
        ]);

        if (is_wp_error($result)) {
            $error_message = 'Lỗi gửi yêu cầu tới Lark: ' . $result->get_error_message();
            self::write_thread_log($error_message);
            return ['success' => false, 'message' => $error_message];
        }

        if (!isset($result['code']) || $result['code'] !== 0) {
            $error_message = 'Lỗi gửi tin nhắn tới Lark: ' . ($result['msg'] ?? 'Unknown error');
            self::write_thread_log($error_message);
            return ['success' => false, 'message' => $error_message];
        }

        // Lưu thread_id (message_id)
        $thread_id = $result['data']['message_id'] ?? '';
        if ($thread_id) {
            $saved = self::save_thread_id($thread_id, $booking_date);
            if (!$saved) {
                return [
                    'success' => false,
                    'message' => 'Gửi card thành công nhưng lỗi khi lưu thread_id'
                ];
            }
        } else {
            self::write_thread_log('Không tìm thấy thread_id trong phản hồi', ['response' => $result]);
            return [
                'success' => false,
                'message' => 'Gửi card thành công nhưng không lấy được thread_id'
            ];
        }

        return [
            'success'   => true,
            'message'   => "Tin nhắn lịch hẹn đã gửi với thread_id: $thread_id",
            'thread_id' => $thread_id
        ];
    }
}
?>