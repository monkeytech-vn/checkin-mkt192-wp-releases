<?php

/**
 * Class quản lý Message Bot Settings
 *
 * Quản lý các bot để gửi thông báo qua Lark
 */

if (!defined('ABSPATH')) {
    exit;
}

class Checkin_MKT192_Message_Bot_Manager {

    private static $instance = null;

    /**
     * Các loại thông báo hỗ trợ
     */
    const NOTIFICATION_TYPES = [
        'appointment'                => 'Thông báo lịch hẹn (Channel)', //interactive
        'inventory'                  => 'Phiếu xuất/ nhập kho (Channel)', //interactive
        'inventory_check'            => 'Kiểm kê kho (Group nhân viên)', //webhook
        'general'                    => 'Thông báo chung (Group nhân viên)', //webhook
        'salary_report'              => 'Thông báo phiếu lương (Group nhân viên)', //webhook
        'salary_report_confirmation' => 'Xác nhận phiếu lương (Group quản lý)', //webhook
        'salary_payment'             => 'Thanh toán lương (Cá nhân nhân viên)', //interactive
        'salary_payment_completion'  => 'Hoàn thành thanh toán (Group quản lý)', //webhook
        'feedback'                   => 'Feedback & Truy thu (Group nhân viên)', //webhook
        'image_processing'           => 'Thông báo xử lý hình ảnh (Group Cron Job)', //webhook
        'promo_code_update'          => 'Thông báo update mã KM (Group Cron Job)', //webhook
        'missing_image_reminder'     => 'Thông báo nhắc nhở upload hình (Group nhân viên)', //webhook
        'api_test'                   => 'Thông báo Test API (Group Cron Job)', //webhook
        // payment_success removed — now handled by MonkeyPay Connections
    ];

    /**
     * Phân loại notification types theo bot type
     */
    const NOTIFICATION_TYPES_BY_BOT = [
        'interactive' => ['appointment', 'inventory', 'salary_payment'],
        'webhook'     => [
            'inventory_check', 'general', 'salary_report', 'salary_report_confirmation',
            'salary_payment_completion', 'feedback', 'image_processing',
            'promo_code_update', 'missing_image_reminder', 'api_test'
        ]
    ];

    /**
     * Mô tả chi tiết cho từng loại thông báo
     */
    const NOTIFICATION_DESCRIPTIONS = [
        'appointment'                => 'Gửi thông báo lịch hẹn/ nhắc hoặc hủy lịch hẹn qua channel Lark nhân viên.',
        'inventory'                  => 'Thông báo phiếu xuất/nhập kho qua channel Lark nhân viên. Quản lý xác nhận Đồng ý duyệt hoặc không duyệt.',
        'inventory_check'            => 'Thông báo kiểm kê kho định kỳ tới group nhân viên. Gửi đến group Lark nhân viên.',
        'general'                    => 'Thông báo chung cho toàn bộ nhân viên về các sự kiện, thay đổi quan trọng trong hệ thống.',
        'salary_report'              => 'Gửi phiếu lương hàng tháng tới group nhân viên. Bao gồm thông tin chi tiết và tổng kết.',
        'salary_report_confirmation' => 'Thông báo xác nhận phiếu lương tới Group Quản lý. Theo dõi trạng thái đồng ý phiếu lương của nhân viên.',
        'salary_payment'             => 'Thông báo thanh toán lương kèm hình ảnh chuyển khoản tới cá nhân nhân viên. Nhân viên bấm tương tác xác nhận.',
        'salary_payment_completion'  => 'Thông báo hoàn tất thanh toán lương tới Group Quản lý. Theo dõi tiến độ thanh toán.',
        'feedback'                   => 'Gửi thông báo feedback khách hàng hoặc thông báo truy thu tới group nhân viên',
        'image_processing'           => 'Thông báo kết quả xử lý hình ảnh tự động (resize, optimize) tới group Cron Job.',
        'promo_code_update'          => 'Cập nhật thông tin mã khuyến mãi mới hoặc thay đổi tới group Cron Job.',
        'missing_image_reminder'     => 'Thông báo nhắc nhở tới group nhân viên với cá nhân quên up hình ảnh sản phẩm/dịch vụ.',
        'api_test'                   => 'Thông báo kết quả test API tự động, kiểm tra tính khả dụng của hệ thống group Cron Job.',
        // payment_success removed — now handled by MonkeyPay Connections
    ];

    /**
     * Các loại bot
     */
    const BOT_TYPES = [
        'interactive' => 'Bot Tương tác (Lark)',
        'webhook'     => 'Bot Webhook'
    ];

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Lấy danh sách notification types theo loại bot
     *
     * @param string $bot_type 'interactive' hoặc 'webhook'
     * @return array Danh sách notification types với label và description
     */
    public static function get_notifications_by_bot_type($bot_type) {
        $notification_keys = self::NOTIFICATION_TYPES_BY_BOT[$bot_type] ?? [];
        $result            = [];

        foreach ($notification_keys as $key) {
            if (isset(self::NOTIFICATION_TYPES[$key])) {
                $result[$key] = [
                    'label'       => self::NOTIFICATION_TYPES[$key],
                    'description' => self::NOTIFICATION_DESCRIPTIONS[$key] ?? ''
                ];
            }
        }

        return $result;
    }

    private function __construct() {
        // Constructor
    }

    /**
     * Lấy tên bảng
     */
    private function get_table_name() {
        global $wpdb;
        return $wpdb->prefix . 'checkin_mkt192_message_bot_settings';
    }

    /**
     * Tạo bot mới
     *
     * @param array $data {
     *     @type string $bot_name Bot name
     *     @type string $bot_type Bot type: 'interactive' hoặc 'webhook'
     *     @type array  $notification_types Mảng các loại thông báo
     *     @type string $chat_id Chat ID (cho interactive bot)
     *     @type string $app_id App ID (cho interactive bot)
     *     @type string $app_secret App Secret (cho interactive bot)
     *     @type string $webhook_url Webhook URL (cho webhook bot)
     *     @type bool   $is_active Trạng thái active
     * }
     * @return int|WP_Error Bot ID hoặc error
     */
    public function create_bot($data) {
        global $wpdb;

        // Validate required fields
        if (empty($data['bot_name'])) {
            return new WP_Error('missing_name', 'Tên bot không được để trống');
        }

        if (empty($data['bot_type']) || !in_array($data['bot_type'], ['interactive', 'webhook'])) {
            return new WP_Error('invalid_type', 'Loại bot không hợp lệ');
        }

        if (empty($data['notification_types']) || !is_array($data['notification_types'])) {
            return new WP_Error('missing_notification_types', 'Phải chọn ít nhất 1 loại thông báo');
        }

        // Validate theo bot type
        if ($data['bot_type'] === 'interactive') {
            if (empty($data['chat_id']) || empty($data['app_id']) || empty($data['app_secret'])) {
                return new WP_Error('missing_interactive_fields', 'Bot tương tác cần có Chat ID, App ID và App Secret');
            }
        } elseif ($data['bot_type'] === 'webhook') {
            if (empty($data['webhook_url'])) {
                return new WP_Error('missing_webhook_url', 'Bot webhook cần có URL webhook');
            }
        }

        // Prepare data
        $insert_data = [
            'bot_name'           => sanitize_text_field($data['bot_name']),
            'bot_type'           => sanitize_text_field($data['bot_type']),
            'notification_types' => json_encode($data['notification_types']),
            'is_active'          => isset($data['is_active']) ? (int) $data['is_active'] : 1,
            'created_at'         => current_time('mysql'),
            'updated_at'         => current_time('mysql')
        ];

        // Add type-specific fields
        if ($data['bot_type'] === 'interactive') {
            $insert_data['chat_id']    = sanitize_text_field($data['chat_id']);
            $insert_data['app_id']     = sanitize_text_field($data['app_id']);
            $insert_data['app_secret'] = sanitize_text_field($data['app_secret']);
        } else {
            $insert_data['webhook_url'] = esc_url_raw($data['webhook_url']);
        }

        $table  = $this->get_table_name();
        $result = $wpdb->insert($table, $insert_data);

        if ($result === false) {
            return new WP_Error('db_error', 'Lỗi khi lưu vào database: ' . $wpdb->last_error);
        }

        return $wpdb->insert_id;
    }

    /**
     * Cập nhật bot
     */
    public function update_bot($bot_id, $data) {
        global $wpdb;

        $bot_id = absint($bot_id);
        if ($bot_id <= 0) {
            return new WP_Error('invalid_id', 'ID bot không hợp lệ');
        }

        // Check bot exists
        $existing = $this->get_bot($bot_id);
        if (!$existing) {
            return new WP_Error('not_found', 'Không tìm thấy bot');
        }

        $update_data = ['updated_at' => current_time('mysql')];

        // Update fields if provided
        if (isset($data['bot_name'])) {
            $update_data['bot_name'] = sanitize_text_field($data['bot_name']);
        }

        // Allow changing bot_type
        if (isset($data['bot_type']) && in_array($data['bot_type'], ['interactive', 'webhook'])) {
            $update_data['bot_type'] = sanitize_text_field($data['bot_type']);
            $new_bot_type            = $data['bot_type'];
        } else {
            $new_bot_type = $existing->bot_type;
        }

        if (isset($data['notification_types']) && is_array($data['notification_types'])) {
            $update_data['notification_types'] = json_encode($data['notification_types']);
        }

        if (isset($data['is_active'])) {
            $update_data['is_active'] = (int) $data['is_active'];
        }

        // Type-specific updates (use new bot_type if changed)
        if ($new_bot_type === 'interactive') {
            if (isset($data['chat_id'])) {
                $update_data['chat_id'] = sanitize_text_field($data['chat_id']);
            }
            if (isset($data['app_id'])) {
                $update_data['app_id'] = sanitize_text_field($data['app_id']);
            }
            if (isset($data['app_secret'])) {
                $update_data['app_secret'] = sanitize_text_field($data['app_secret']);
            }
            // Clear webhook fields if switching from webhook to interactive
            if ($existing->bot_type === 'webhook') {
                $update_data['webhook_url'] = null;
            }
        } else {
            if (isset($data['webhook_url'])) {
                $update_data['webhook_url'] = esc_url_raw($data['webhook_url']);
            }
            // Clear interactive fields if switching from interactive to webhook
            if ($existing->bot_type === 'interactive') {
                $update_data['chat_id']    = null;
                $update_data['app_id']     = null;
                $update_data['app_secret'] = null;
            }
        }

        $table  = $this->get_table_name();
        $result = $wpdb->update($table, $update_data, ['id' => $bot_id]);

        if ($result === false) {
            return new WP_Error('db_error', 'Lỗi khi cập nhật: ' . $wpdb->last_error);
        }

        return true;
    }

    /**
     * Lấy thông tin bot
     */
    public function get_bot($bot_id) {
        global $wpdb;
        $table = $this->get_table_name();

        $bot = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table WHERE id = %d",
            $bot_id
        ));

        if ($bot) {
            if (!empty($bot->notification_types)) {
                $bot->notification_types = json_decode($bot->notification_types, true);
            } else {
                // Đảm bảo luôn là array
                $bot->notification_types = [];
            }
        }

        return $bot;
    }

    /**
     * Lấy tất cả bots
     */
    public function get_all_bots($active_only = false) {
        global $wpdb;
        $table = $this->get_table_name();

        $where = $active_only ? 'WHERE is_active = 1' : '';
        $bots  = $wpdb->get_results("SELECT * FROM $table $where ORDER BY created_at DESC");

        foreach ($bots as $bot) {
            if (!empty($bot->notification_types)) {
                $bot->notification_types = json_decode($bot->notification_types, true);
            } else {
                // Đảm bảo luôn là array, không để null
                $bot->notification_types = [];
            }
        }

        return $bots;
    }

    /**
     * Lấy bot theo loại thông báo
     *
     * @param string $notification_type Loại thông báo (appointment, inventory, etc.)
     * @return object|null Bot object hoặc null
     */
    public function get_bot_by_notification_type($notification_type) {
        $bots = $this->get_all_bots(true); // Chỉ lấy active bots

        foreach ($bots as $bot) {
            // Đảm bảo notification_types là array trước khi dùng in_array
            if (is_array($bot->notification_types) && in_array($notification_type, $bot->notification_types)) {
                return $bot;
            }
        }

        return null;
    }

    /**
     * Xóa bot
     */
    public function delete_bot($bot_id) {
        global $wpdb;
        $table = $this->get_table_name();

        $result = $wpdb->delete($table, ['id' => absint($bot_id)]);

        if ($result === false) {
            return new WP_Error('db_error', 'Lỗi khi xóa: ' . $wpdb->last_error);
        }

        return true;
    }

    /**
     * Toggle active status
     */
    public function toggle_active($bot_id) {
        global $wpdb;
        $table = $this->get_table_name();

        $bot = $this->get_bot($bot_id);
        if (!$bot) {
            return new WP_Error('not_found', 'Không tìm thấy bot');
        }

        $new_status = $bot->is_active ? 0 : 1;
        $wpdb->update($table, ['is_active' => $new_status], ['id' => $bot_id]);

        return $new_status;
    }

    /**
     * Gửi tin nhắn qua bot
     *
     * @param string $notification_type Loại thông báo
     * @param string $message Nội dung tin nhắn
     * @param array $card_data Dữ liệu card (optional, cho interactive message)
     * @param string $ou_id Open ID của nhân viên (optional, nếu có sẽ gửi đến cá nhân thay vì group)
     * @return array|WP_Error Kết quả gửi tin nhắn
     */
    public function send_message($notification_type, $message, $card_data = null, $ou_id = null) {
        // Tìm bot phù hợp
        $bot = $this->get_bot_by_notification_type($notification_type);

        if (!$bot) {
            return new WP_Error('no_bot', 'Không tìm thấy bot cho loại thông báo: ' . $notification_type);
        }

        if ($bot->bot_type === 'interactive') {
            return $this->send_lark_message($bot, $message, $card_data, $ou_id);
        } else {
            return $this->send_webhook_message($bot, $message, $card_data);
        }
    }

    /**
     * Gửi tin nhắn qua Lark Interactive Bot với retry logic
     *
     * @param object $bot Bot object
     * @param string $message Nội dung tin nhắn
     * @param array $card_data Dữ liệu card
     * @param string $ou_id Open ID của nhân viên (optional, nếu có sẽ gửi đến cá nhân)
     */
    private function send_lark_message($bot, $message, $card_data = null, $ou_id = null) {
        // Lấy tenant access token
        require_once(plugin_dir_path(__FILE__) . 'lark-utils.php');
        $token = get_lark_tenant_access_token($bot->app_id, $bot->app_secret);

        if (is_wp_error($token)) {
            log_lark_untils('Token error', [
                'bot_id' => $bot->id,
                'error'  => $token->get_error_message()
            ]);
            return $token;
        }

        // Nếu có ou_id thì gửi đến cá nhân, không thì gửi vào group
        if ($ou_id) {
            $url        = 'https://open.larksuite.com/open-apis/im/v1/messages?receive_id_type=open_id';
            $receive_id = $ou_id;
            $log_target = 'personal (ou_id: ' . $ou_id . ')';
        } else {
            $url        = 'https://open.larksuite.com/open-apis/im/v1/messages?receive_id_type=chat_id';
            $receive_id = $bot->chat_id;
            $log_target = 'group (chat_id: ' . $bot->chat_id . ')';
        }

        // Nếu có card data thì gửi interactive message, không thì text
        if ($card_data) {
            // Nếu card_data đã có msg_type, extract ra card
            if (isset($card_data['msg_type']) && isset($card_data['card'])) {
                $content = $card_data['card'];
            } else {
                $content = $card_data;
            }

            $payload = [
                'receive_id' => $receive_id,
                'msg_type'   => 'interactive',
                'content'    => json_encode($content)
            ];
        } else {
            $payload = [
                'receive_id' => $receive_id,
                'msg_type'   => 'text',
                'content'    => json_encode(['text' => $message])
            ];
        }

        log_lark_untils('Sending message to ' . $log_target, [
            'bot_id'  => $bot->id,
            'payload' => $payload
        ]);

        // Retry logic - thử tối đa 2 lần
        $max_retries = 2;
        $retry_delay = 500000; // 500ms
        $last_error  = null;
        $body        = null;

        for ($attempt = 1; $attempt <= $max_retries; $attempt++) {
            // Delay giữa các request để tránh rate limiting
            if ($attempt > 1) {
                usleep($retry_delay);
            }

            $response = wp_remote_post($url, [
                'headers' => [
                    'Authorization' => 'Bearer ' . $token,
                    'Content-Type'  => 'application/json; charset=utf-8'
                ],
                'body'    => json_encode($payload),
                'timeout' => 30
            ]);

            if (is_wp_error($response)) {
                $last_error = $response->get_error_message();
                log_lark_untils('❌ Send failed attempt ' . $attempt, [
                    'bot_id' => $bot->id,
                    'target' => $log_target,
                    'error'  => $last_error
                ]);
                continue;
            }

            $body        = json_decode(wp_remote_retrieve_body($response), true);
            $status_code = wp_remote_retrieve_response_code($response);

            // Nếu thành công thì return
            if ($status_code === 200 && isset($body['code']) && $body['code'] === 0) {
                log_lark_untils('✅ Message sent successfully to ' . $log_target, [
                    'bot_id'     => $bot->id,
                    'message_id' => $body['data']['message_id'] ?? ''
                ]);
                return $body;
            }

            // Nếu lỗi rate limiting (code 99991400), thử lại
            if (isset($body['code']) && $body['code'] === 99991400) {
                log_lark_untils('⚠️ Rate limited, retry ' . $attempt, ['bot_id' => $bot->id]);
                continue;
            }

            // Lỗi khác thì log và return
            log_lark_untils('❌ API error', [
                'bot_id'  => $bot->id,
                'target'  => $log_target,
                'status'  => $status_code,
                'code'    => $body['code'] ?? -1,
                'msg'     => $body['msg']  ?? 'Unknown',
                'attempt' => $attempt
            ]);
            return $body;
        }

        // Hết retry mà vẫn lỗi
        return $body ?: new WP_Error('send_failed', 'Failed after ' . $max_retries . ' attempts: ' . $last_error);
    }

    /**
     * Gửi tin nhắn qua Webhook
     */
    private function send_webhook_message($bot, $message, $card_data = null) {
        // Nếu có card_data thì ưu tiên gửi interactive card
        if ($card_data) {
            // Nếu card_data đã có đầy đủ msg_type và card/content
            if (isset($card_data['msg_type'])) {
                $payload = $card_data;
            } else {
                // Nếu chỉ có card data thuần, wrap nó
                $payload = [
                    'msg_type' => 'interactive',
                    'card'     => $card_data
                ];
            }
        } else {
            // Gửi text message đơn giản
            $payload = [
                'msg_type' => 'text',
                'content'  => [
                    'text' => $message
                ]
            ];
        }

        $response = wp_remote_post($bot->webhook_url, [
            'headers' => ['Content-Type' => 'application/json; charset=utf-8'],
            'body'    => json_encode($payload),
            'timeout' => 30
        ]);

        if (is_wp_error($response)) {
            log_lark_untils('❌ Webhook failed', [
                'bot_id' => $bot->id,
                'error'  => $response->get_error_message()
            ]);
            return $response;
        }

        $body        = json_decode(wp_remote_retrieve_body($response), true);
        $status_code = wp_remote_retrieve_response_code($response);

        // Chỉ log nếu có lỗi
        if ($status_code !== 200 || ($body['code'] ?? -1) !== 0) {
            log_lark_untils('❌ Webhook error', [
                'bot_id' => $bot->id,
                'status' => $status_code,
                'code'   => $body['code'] ?? -1,
                'msg'    => $body['msg']  ?? 'Unknown'
            ]);
        }

        return $body;
    }
}
