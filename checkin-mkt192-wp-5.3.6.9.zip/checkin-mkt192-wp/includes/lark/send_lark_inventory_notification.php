<?php

/**
 * Gửi thông báo Lark cho phiếu xuất/nhập kho
 * CHỈ GỬI NOTIFICATION, KHÔNG INSERT DB
 *
 * @package Checkin_MKT192
 * @since 5.1.8
 */

require_once __DIR__ . '/lark-utils.php';
require_once __DIR__ . '/card-builder.php';
require_once __DIR__ . '/cache-utils.php';
require_once __DIR__ . '/class-checkin-mkt192-message-bot-manager.php';

/**
 * Ghi log cho inventory notification (ngắn gọn)
 */
function log_lark_inventory($message, $data = []) {
    $log_dir = __DIR__ . '/logs';
    if (!file_exists($log_dir)) {
        mkdir($log_dir, 0755, true);
    }

    $log_file  = $log_dir . '/lark_inventory_notification.log';
    $timestamp = date('Y-m-d H:i:s');
    $log_entry = "[$timestamp] $message";
    if (!empty($data)) {
        $log_entry .= ' ' . json_encode($data, JSON_UNESCAPED_UNICODE);
    }
    $log_entry .= "\n";
    file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);
}

/**
 * Gửi thông báo Lark cho phiếu xuất/nhập kho
 *
 * @param string $transaction_id Mã phiếu (OUT-xxx hoặc IN-xxx)
 * @param array $transaction_data Dữ liệu phiếu (products, reason, ...)
 * @param string $type Loại phiếu (in/out)
 * @param string $image_key Lark image key (nếu có)
 * @param string $staff_name Tên nhân viên
 * @return array
 */
function send_lark_inventory_notification($transaction_id, $transaction_data, $type, $image_key = '', $staff_name = '') {
    global $wpdb;
    $table_products = $wpdb->prefix . 'checkin_mkt192_products';
    $table_staff    = $wpdb->prefix . 'checkin_mkt192_staff';

    $bot_manager = Checkin_MKT192_Message_Bot_Manager::get_instance();

    $employee_id   = get_current_user_id();
    $employee_name = !empty($staff_name) ? $staff_name : get_userdata($employee_id)->display_name;
    $items_content = [];

    // Lấy employee ou_id để tag trong Lark
    $employee_ou_id = $wpdb->get_var($wpdb->prepare(
        "SELECT ou_id FROM $table_staff WHERE display_name = %s",
        $employee_name
    ));

    // Chuẩn bị items_content cho card
    $product_names = [];
    foreach ($transaction_data['products'] as $product) {
        $product_id = intval($product['id'] ?? $product['product_id'] ?? 0);
        $quantity   = intval($product['quantity'] ?? 0);

        $product_name = $wpdb->get_var($wpdb->prepare(
            "SELECT product_name FROM $table_products WHERE id = %d",
            $product_id
        ));

        if ($product_name) {
            $items_content[] = [
                'product_name' => $product_name,
                'quantity'     => $quantity
            ];
            $product_names[] = "{$product_name} x{$quantity}";
        }
    }

    // Log thông tin phiếu xuất
    log_lark_inventory('📤 ' . strtoupper($type), [
        'id'       => $transaction_id,
        'staff'    => $employee_name,
        'products' => implode(', ', $product_names)
    ]);

    // Lấy bot để biết loại bot
    $bot = $bot_manager->get_bot_by_notification_type('inventory');
    if (!$bot) {
        log_lark_inventory('❌ FAILED', ['id' => $transaction_id, 'error' => 'No bot']);
        return ['success' => false, 'message' => 'No bot found for inventory'];
    }

    // Build card theo loại bot
    $card = build_stock_card($transaction_id, $transaction_data, $type, $employee_ou_id ?: '', $employee_name, $items_content, $image_key, $bot->bot_type);

    // Gửi thông báo qua Bot Manager
    $result = $bot_manager->send_message('inventory', null, $card);

    // Kiểm tra kết quả
    if (is_wp_error($result)) {
        log_lark_inventory('❌ FAILED', [
            'id'    => $transaction_id,
            'error' => $result->get_error_message()
        ]);
        return ['success' => false, 'message' => $result->get_error_message()];
    }

    // Kiểm tra response có hợp lệ không
    $message_id = $result['data']['message_id'] ?? '';
    $lark_code  = $result['code']               ?? -1;

    if (empty($message_id) || $lark_code !== 0) {
        log_lark_inventory('❌ FAILED', [
            'id'    => $transaction_id,
            'code'  => $lark_code,
            'msg'   => $result['msg']  ?? 'No response',
            'data'  => $result['data'] ?? null
        ]);
        return ['success' => false, 'message' => $result['msg'] ?? 'Lark API error'];
    }

    // Thành công
    log_lark_inventory('✅ OK', [
        'id'  => $transaction_id,
        'mid' => $message_id
    ]);

    return [
        'success'         => true,
        'message'         => 'Lark notification sent',
        'open_message_id' => $message_id
    ];
}
