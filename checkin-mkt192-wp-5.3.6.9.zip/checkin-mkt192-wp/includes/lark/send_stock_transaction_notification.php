<?php

require_once(dirname(__FILE__, 6) . '/wp-load.php');
require_once(__DIR__ . '/lark-utils.php');
require_once(__DIR__ . '/card-builder.php');
require_once(__DIR__ . '/cache-utils.php');

/**
 * Generate unique transaction ID
 */
function generate_unique_transaction_id($wpdb, $table_transactions, $prefix = 'STX_') {
    $max_attempts = 3;
    $attempt      = 0;

    while ($attempt < $max_attempts) {
        $random_bytes   = bin2hex(random_bytes(4));
        $transaction_id = $prefix . uniqid();
        $exists         = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table_transactions WHERE transaction_id = %s",
            $transaction_id
        ));

        if ($exists == 0) {
            return $transaction_id;
        }

        CacheManager::write_log('Duplicate transaction_id, retrying', [
            'transaction_id' => $transaction_id,
            'attempt'        => $attempt + 1
        ], 'stock_transaction_notification.log');
        $attempt++;
    }

    throw new Exception("Failed to generate unique transaction_id after $max_attempts attempts");
}

/**
 * Update transaction status and stock quantity
 */
function update_transaction_status($transaction_id, $status) {
    global $wpdb;
    $table_transactions = $wpdb->prefix . 'checkin_mkt192_inventory_transactions';
    $table_products     = $wpdb->prefix . 'checkin_mkt192_products';

    $cached_data = CacheManager::get($transaction_id, CACHE_PREFIX_INVENTORY);
    if (!$cached_data || !isset($cached_data['transactions'])) {
        CacheManager::write_log('No cache data found', ['transaction_id' => $transaction_id], 'stock_transaction_notification.log');
        return false;
    }

    $wpdb->query('START TRANSACTION');

    try {
        $updated = $wpdb->query($wpdb->prepare(
            "UPDATE $table_transactions SET status = %s, updated_at = %s WHERE transaction_id = %s",
            [$status, current_time('mysql'), $transaction_id]
        ));

        if ($updated === false) {
            throw new Exception($wpdb->last_error);
        }

        if ($status === 'ĐÃ DUYỆT') {
            foreach ($cached_data['transactions'] as $transaction) {
                $product_id       = intval($transaction['product_id']);
                $quantity         = intval($transaction['quantity']);
                $transaction_type = $cached_data['transaction_type'];

                $current_stock = $wpdb->get_var($wpdb->prepare(
                    "SELECT stock FROM $table_products WHERE id = %d",
                    $product_id
                ));

                if ($current_stock === null) {
                    throw new Exception("Product ID $product_id does not exist");
                }

                $current_stock = intval($current_stock);
                $new_stock     = $transaction_type === 'IN' ? $current_stock + $quantity : $current_stock - $quantity;

                if ($transaction_type === 'OUT' && $new_stock < 0) {
                    throw new Exception("Insufficient stock for product ID $product_id (current: $current_stock, requested: $quantity)");
                }

                $stock_updated = $wpdb->update(
                    $table_products,
                    ['stock' => $new_stock],
                    ['id'    => $product_id],
                    ['%d'],
                    ['%d']
                );

                if ($stock_updated === false) {
                    throw new Exception($wpdb->last_error);
                }
            }
        }

        $wpdb->query('COMMIT');

        CacheManager::write_log('Database update successful', [
            'transaction_id' => $transaction_id,
            'status'         => $status,
            'updated'        => $updated
        ], 'stock_transaction_notification.log');

        return true;
    } catch (Exception $e) {
        $wpdb->query('ROLLBACK');

        CacheManager::write_log('Error updating database', [
            'transaction_id' => $transaction_id,
            'status'         => $status,
            'error'          => $e->getMessage()
        ], 'stock_transaction_notification.log');

        return false;
    }
}

/**
 * Send stock transaction notification
 */
function send_stock_transaction_notification($transaction_data, $type, $image_key = '') {
    global $wpdb;
    $table_products     = $wpdb->prefix . 'checkin_mkt192_products';
    $table_transactions = $wpdb->prefix . 'checkin_mkt192_inventory_transactions';
    $table_staff        = $wpdb->prefix . 'checkin_mkt192_staff';

    CacheManager::write_log('Received transaction data', $transaction_data, 'stock_transaction_notification.log');

    // Load Bot Manager
    require_once __DIR__ . '/class-checkin-mkt192-message-bot-manager.php';
    $bot_manager = Checkin_MKT192_Message_Bot_Manager::get_instance();

    $current_date  = current_time('mysql');
    $employee_id   = get_current_user_id();
    $employee_name = get_userdata($employee_id)->display_name;
    $transactions  = [];
    $items_content = [];

    $employee_ou_id = $wpdb->get_var($wpdb->prepare(
        "SELECT ou_id FROM $table_staff WHERE display_name = %s",
        $employee_name
    ));

    if (!$employee_ou_id) {
        $error_message = "No ou_id found for '$employee_name'";
        CacheManager::write_log($error_message, [], 'stock_transaction_notification.log');
        return ['success' => false, 'message' => $error_message];
    }

    CacheManager::write_log('Employee ou_id', ['employee_ou_id' => $employee_ou_id], 'stock_transaction_notification.log');

    $transaction_id = generate_unique_transaction_id($wpdb, $table_transactions);

    $wpdb->query('START TRANSACTION');

    try {
        foreach ($transaction_data['products'] as $product) {
            $product_id = intval($product['product_id']);
            $quantity   = intval($product['quantity']);

            $product_name = $wpdb->get_var($wpdb->prepare(
                "SELECT product_name FROM $table_products WHERE id = %d",
                $product_id
            ));

            if (!$product_name) {
                throw new Exception("Product ID $product_id does not exist");
            }

            $note = sanitize_text_field($transaction_data['reason'] ?? '');

            $inserted = $wpdb->insert(
                $table_transactions,
                [
                    'product_id'       => $product_id,
                    'product_name'     => $product_name,
                    'transaction_type' => strtoupper($type),
                    'quantity'         => $quantity,
                    'note'             => $note,
                    'image_key'        => $image_key,
                    'transaction_id'   => $transaction_id,
                    'status'           => 'CHỜ DUYỆT',
                    'staff_name'       => $employee_name,
                    'created_at'       => $current_date,
                    'updated_at'       => $current_date
                ],
                ['%d', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s']
            );

            if ($inserted === false) {
                throw new Exception($wpdb->last_error);
            }

            $items_content[] = [
                'product_name' => $product_name,
                'quantity'     => $quantity
            ];

            $transactions[] = [
                'transaction_id' => $transaction_id,
                'product_id'     => $product_id,
                'product_name'   => $product_name,
                'quantity'       => $quantity
            ];
        }

        $wpdb->query('COMMIT');

        $cache_data = [
            'employee_name'    => $employee_name,
            'employee_ou_id'   => $employee_ou_id,
            'transaction_type' => strtoupper($type),
            'transaction_id'   => $transaction_id,
            'transactions'     => $transactions,
            'note'             => $note
        ];
        CacheManager::store($transaction_id, $cache_data, CACHE_PREFIX_INVENTORY);
    } catch (Exception $e) {
        $wpdb->query('ROLLBACK');

        $error_message = 'Error saving transaction: ' . $e->getMessage();
        CacheManager::write_log($error_message, ['products' => $transaction_data['products']], 'stock_transaction_notification.log');
        return ['success' => false, 'message' => $error_message];
    }

    // Lấy bot để biết loại bot
    $bot = $bot_manager->get_bot_by_notification_type('inventory');
    if (!$bot) {
        $error_message = "No bot found for notification type 'inventory'";
        CacheManager::write_log($error_message, [], 'stock_transaction_notification.log');
        return ['success' => false, 'message' => $error_message];
    }

    CacheManager::write_log('Building card with image_key', [
        'image_key'       => $image_key,
        'image_key_empty' => empty($image_key),
        'transaction_id'  => $transaction_id,
        'type'            => $type,
        'bot_type'        => $bot->bot_type
    ], 'stock_transaction_notification.log');

    // Build card theo loại bot
    $card = build_stock_card($transaction_id, $transaction_data, $type, $employee_ou_id, $employee_name, $items_content, $image_key, $bot->bot_type);

    CacheManager::write_log('Card sent to Bot Manager', $card, 'stock_transaction_notification.log');

    // Gửi thông báo qua Bot Manager
    $result = $bot_manager->send_message('inventory', null, $card);

    if (is_wp_error($result)) {
        $error_message = 'Error sending stock transaction notification: ' . $result->get_error_message();
        CacheManager::write_log($error_message, [], 'stock_transaction_notification.log');
        return ['success' => false, 'message' => $error_message];
    }

    CacheManager::write_log('Lark response', $result, 'stock_transaction_notification.log');

    // Lưu open_message_id vào cache để sử dụng trong callback nếu cần
    $cache_data['open_message_id'] = $result['data']['message_id'] ?? '';
    CacheManager::store($transaction_id, $cache_data, CACHE_PREFIX_INVENTORY);
    CacheManager::write_log('Stored open_message_id in cache', [
        'transaction_id'  => $transaction_id,
        'open_message_id' => $cache_data['open_message_id']
    ], 'stock_transaction_notification.log');

    return [
        'success'         => true,
        'message'         => 'Stock transaction message sent successfully',
        'transaction_id'  => $transaction_id,
        'open_message_id' => $result['data']['message_id'] ?? ''
    ];
}

ob_start();
register_shutdown_function(function () {
    $output = ob_get_clean();
    if ($output && !headers_sent()) {
        header('Content-Type: application/json; charset=utf-8', true, 500);
        echo json_encode(['success' => false, 'message' => 'Unexpected output: ' . $output]);
        exit;
    }
});
?>
