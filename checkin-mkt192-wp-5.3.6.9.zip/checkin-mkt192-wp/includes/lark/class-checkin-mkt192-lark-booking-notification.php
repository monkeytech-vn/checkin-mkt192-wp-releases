<?php

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

require_once __DIR__ . '/lark-utils.php';
require_once __DIR__ . '/card-builder.php';

/**
 * Class xử lý gửi thông báo lịch hẹn mới và hủy lịch qua Lark.
 */
class Checkin_MKT192_LarkBookingNotification {
    /**
     * Ghi log vào file booking_notification.log.
     *
     * @param string $message Thông điệp log.
     * @param array  $data    Dữ liệu bổ sung (tùy chọn).
     */
    private static function write_booking_log($message, $data = []) {
        $log_file = __DIR__ . '/logs/booking_notification.log';
        if (!file_exists(dirname($log_file))) {
            mkdir(dirname($log_file), 0755, true);
        }
        $timestamp = date('Y-m-d H:i:s');
        $log_entry = "[$timestamp] $message\n";
        if ($data) {
            $log_entry .= 'Data: ' . json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
        }
        $log_entry .= "----------------------------------------\n";
        file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);
    }

    /**
     * Lấy thread_id cho ngày chỉ định từ WordPress options.
     * Hỗ trợ cả cấu trúc legacy (flat) và mới (nested by date).
     *
     * @param string $date Ngày cần lấy thread_id (Y-m-d format).
     * @return string|null Thread ID hoặc null nếu không tìm thấy.
     */
    private static function get_thread_id_for_date($date) {
        $thread_data = get_option('lark_appointment_thread_id', []);

        // New nested format: ['2025-12-04' => ['thread_id' => '...', 'booking_date' => '...', 'updated_at' => '...']]
        if (isset($thread_data[$date])) {
            return is_array($thread_data[$date])
                ? ($thread_data[$date]['thread_id'] ?? null)
                : $thread_data[$date];
        }

        // Legacy flat format: ['booking_date' => '...', 'thread_id' => '...', 'updated_at' => '...']
        if (isset($thread_data['thread_id']) && isset($thread_data['booking_date'])) {
            if ($thread_data['booking_date'] === $date) {
                return $thread_data['thread_id'];
            }
        }

        return null;
    }

    /**
     * Gửi thông báo lịch hẹn mới vào thread Booking qua Lark.
     *
     * @param array $booking_data Dữ liệu lịch hẹn.
     * @return array Kết quả gửi.
     */
    public static function send_booking_notification($booking_data) {
        // Kiểm tra Lark có được bật không
        if (!is_lark_enabled()) {
            self::write_booking_log('Lark is disabled, skipping booking notification');
            return ['success' => false, 'message' => 'Lark is disabled'];
        }

        global $wpdb;
        $table_staff = $wpdb->prefix . 'checkin_mkt192_staff';

        // Lấy thread_id từ WordPress options
        $today     = date('Y-m-d');
        $thread_id = self::get_thread_id_for_date($today);

        if (!$thread_id) {
            $thread_data   = get_option('lark_appointment_thread_id', []);
            $error_message = "Không tìm thấy thread_id cho ngày $today. Vui lòng chạy cronjob tạo thread trước.";
            self::write_booking_log($error_message, ['thread_data' => $thread_data]);
            return ['success' => false, 'message' => $error_message];
        }

        // Lấy tên thợ từ booking_data (field là hairdresser_name)
        $hairdresser_name = $booking_data['hairdresser_name'] ?? $booking_data['hairdresser'] ?? '';

        if (empty($hairdresser_name)) {
            $error_message = 'Không tìm thấy tên thợ trong booking_data';
            self::write_booking_log($error_message, $booking_data);
            return ['success' => false, 'message' => $error_message];
        }

        // Lấy ou_id từ bảng staff
        $id_hairdresser = $wpdb->get_var($wpdb->prepare(
            "SELECT ou_id FROM $table_staff WHERE display_name = %s",
            $hairdresser_name
        ));

        if (!$id_hairdresser) {
            $error_message = "Không tìm thấy ou_id cho hairdresser '$hairdresser_name'";
            self::write_booking_log($error_message, ['hairdresser_name' => $hairdresser_name]);
            return ['success' => false, 'message' => $error_message];
        }

        self::write_booking_log('Thông tin thread', [
            'thread_id'      => $thread_id,
            'booking_date'   => $today,
            'id_hairdresser' => $id_hairdresser
        ]);

        // Chuẩn bị card từ card-builder.php
        $card = build_booking_notification_card($booking_data, $id_hairdresser);

        // Tạo payload để reply vào thread
        $payload = [
            'msg_type' => 'interactive',
            'content'  => json_encode($card, JSON_UNESCAPED_UNICODE),
            'uuid'     => wp_generate_uuid4()
        ];

        self::write_booking_log('Payload gửi tới Lark', $payload);

        // Lấy Bot Manager
        require_once __DIR__ . '/class-checkin-mkt192-message-bot-manager.php';
        $bot_manager = Checkin_MKT192_Message_Bot_Manager::get_instance();

        // Lấy bot 'appointment'
        $bot = $bot_manager->get_bot_by_notification_type('appointment');
        if (!$bot) {
            $error_message = 'Không tìm thấy bot được cấu hình cho loại thông báo: appointment';
            self::write_booking_log($error_message);
            return ['success' => false, 'message' => $error_message];
        }

        // Lấy token
        $token = get_lark_tenant_access_token($bot->app_id, $bot->app_secret);
        if (is_wp_error($token)) {
            $error_message = 'Lỗi lấy token: ' . $token->get_error_message();
            self::write_booking_log($error_message);
            return ['success' => false, 'message' => $error_message];
        }

        // Gửi reply vào thread
        $url        = "https://open.larksuite.com/open-apis/im/v1/messages/$thread_id/reply";
        $start_time = microtime(true);
        $response   = wp_remote_post($url, [
            'method'  => 'POST',
            'headers' => [
                'Authorization' => "Bearer $token",
                'Content-Type'  => 'application/json; charset=utf-8'
            ],
            'body'    => json_encode($payload, JSON_UNESCAPED_UNICODE),
            'timeout' => 15
        ]);

        $response_time = microtime(true) - $start_time;
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = json_decode(wp_remote_retrieve_body($response), true);

        self::write_booking_log('Phản hồi từ Lark', [
            'http_code'     => $response_code,
            'body'          => $response_body,
            'response_time' => $response_time
        ]);

        if (is_wp_error($response)) {
            $error_message = 'Lỗi gửi yêu cầu tới Lark: ' . $response->get_error_message();
            self::write_booking_log($error_message);
            return ['success' => false, 'message' => $error_message];
        }

        if ($response_code !== 200 || !isset($response_body['code']) || $response_body['code'] !== 0) {
            $error_message = "Lỗi gửi tin nhắn tới Lark: HTTP $response_code - " . ($response_body['msg'] ?? 'Unknown error');
            self::write_booking_log($error_message);
            return ['success' => false, 'message' => $error_message];
        }

        return [
            'success'    => true,
            'message'    => "Tin nhắn thông báo lịch hẹn đã gửi vào thread ngày $today",
            'message_id' => $response_body['data']['message_id'] ?? ''
        ];
    }

    /**
     * Gửi thông báo hủy lịch hẹn vào thread Booking qua Lark.
     *
     * @param array $booking_data Dữ liệu lịch hẹn.
     * @return array Kết quả gửi.
     */
    public static function send_booking_cancellation_notification($booking_data) {
        // Kiểm tra Lark có được bật không
        if (!is_lark_enabled()) {
            self::write_booking_log('Lark is disabled, skipping cancellation notification');
            return ['success' => false, 'message' => 'Lark is disabled'];
        }

        global $wpdb;
        $table_staff = $wpdb->prefix . 'checkin_mkt192_staff';

        // Lấy thread_id từ WordPress options
        $today     = date('Y-m-d');
        $thread_id = self::get_thread_id_for_date($today);

        if (!$thread_id) {
            $thread_data   = get_option('lark_appointment_thread_id', []);
            $error_message = "Không tìm thấy thread_id cho ngày $today. Vui lòng chạy cronjob tạo thread trước.";
            self::write_booking_log($error_message, ['thread_data' => $thread_data]);
            return ['success' => false, 'message' => $error_message];
        }

        // Lấy tên thợ từ booking_data (field là hairdresser_name)
        $hairdresser_name = $booking_data['hairdresser_name'] ?? $booking_data['hairdresser'] ?? '';

        if (empty($hairdresser_name)) {
            $error_message = 'Không tìm thấy tên thợ trong booking_data';
            self::write_booking_log($error_message, $booking_data);
            return ['success' => false, 'message' => $error_message];
        }

        // Lấy ou_id từ bảng staff
        $id_hairdresser = $wpdb->get_var($wpdb->prepare(
            "SELECT ou_id FROM $table_staff WHERE display_name = %s",
            $hairdresser_name
        ));

        if (!$id_hairdresser) {
            $error_message = "Không tìm thấy ou_id cho hairdresser '$hairdresser_name'";
            self::write_booking_log($error_message, ['hairdresser_name' => $hairdresser_name]);
            return ['success' => false, 'message' => $error_message];
        }

        self::write_booking_log('Thông tin thread cho hủy lịch', [
            'thread_id'      => $thread_id,
            'booking_date'   => $today,
            'id_hairdresser' => $id_hairdresser
        ]);

        // Chuẩn bị card từ card-builder.php
        $card = build_booking_cancellation_card($booking_data, $id_hairdresser);

        // Tạo payload để reply vào thread
        $payload = [
            'msg_type' => 'interactive',
            'content'  => json_encode($card, JSON_UNESCAPED_UNICODE),
            'uuid'     => wp_generate_uuid4()
        ];

        self::write_booking_log('Payload gửi tới Lark cho hủy lịch', $payload);

        // Lấy Bot Manager
        require_once __DIR__ . '/class-checkin-mkt192-message-bot-manager.php';
        $bot_manager = Checkin_MKT192_Message_Bot_Manager::get_instance();

        // Lấy bot 'appointment'
        $bot = $bot_manager->get_bot_by_notification_type('appointment');
        if (!$bot) {
            $error_message = 'Không tìm thấy bot được cấu hình cho loại thông báo: appointment';
            self::write_booking_log($error_message);
            return ['success' => false, 'message' => $error_message];
        }

        // Lấy token
        $token = get_lark_tenant_access_token($bot->app_id, $bot->app_secret);
        if (is_wp_error($token)) {
            $error_message = 'Lỗi lấy token: ' . $token->get_error_message();
            self::write_booking_log($error_message);
            return ['success' => false, 'message' => $error_message];
        }

        // Gửi reply vào thread
        $url        = "https://open.larksuite.com/open-apis/im/v1/messages/$thread_id/reply";
        $start_time = microtime(true);
        $response   = wp_remote_post($url, [
            'method'  => 'POST',
            'headers' => [
                'Authorization' => "Bearer $token",
                'Content-Type'  => 'application/json; charset=utf-8'
            ],
            'body'    => json_encode($payload, JSON_UNESCAPED_UNICODE),
            'timeout' => 15
        ]);

        $response_time = microtime(true) - $start_time;
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = json_decode(wp_remote_retrieve_body($response), true);

        self::write_booking_log('Phản hồi từ Lark cho hủy lịch', [
            'http_code'     => $response_code,
            'body'          => $response_body,
            'response_time' => $response_time
        ]);

        if (is_wp_error($response)) {
            $error_message = 'Lỗi gửi yêu cầu tới Lark: ' . $response->get_error_message();
            self::write_booking_log($error_message);
            return ['success' => false, 'message' => $error_message];
        }

        if ($response_code !== 200 || !isset($response_body['code']) || $response_body['code'] !== 0) {
            $error_message = "Lỗi gửi tin nhắn tới Lark: HTTP $response_code - " . ($response_body['msg'] ?? 'Unknown error');
            self::write_booking_log($error_message);
            return ['success' => false, 'message' => $error_message];
        }

        return [
            'success'    => true,
            'message'    => "Tin nhắn thông báo hủy lịch hẹn đã gửi vào thread ngày $today",
            'message_id' => $response_body['data']['message_id'] ?? ''
        ];
    }
}
?>