<?php

require_once(dirname(__FILE__, 6) . '/wp-load.php');

// Hàm ghi log vào file
function write_inventory_log($message, $data = []) {
    $log_file = __DIR__ . '/logs/inventory_check_notification.log';
    if (!file_exists(dirname($log_file))) {
        mkdir(dirname($log_file), 0755, true);
    }
    $timestamp = date('Y-m-d H:i:s');
    $log_entry = "[$timestamp] $message\n";
    if (!empty($data)) {
        $log_entry .= 'Data: ' . json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
    }
    $log_entry .= "----------------------------------------\n";
    file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);
}

function send_inventory_check_notification($inventory_data, $general_reason) {
    global $wpdb;
    $table_products     = $wpdb->prefix . 'checkin_mkt192_products';
    $table_checks       = $wpdb->prefix . 'checkin_mkt192_inventory_checks';
    $table_staff        = $wpdb->prefix . 'checkin_mkt192_staff';

    // Ghi log dữ liệu đầu vào
    write_inventory_log('Nhận dữ liệu kiểm kê để gửi thông báo', $inventory_data);

    // Load lark utils and check if enabled
    require_once __DIR__ . '/lark-utils.php';
    if (!is_lark_enabled()) {
        write_inventory_log('Lark chưa được kích hoạt');
        return ['success' => false, 'message' => 'Lark chưa được kích hoạt'];
    }

    // Load Bot Manager
    require_once __DIR__ . '/class-checkin-mkt192-message-bot-manager.php';
    $bot_manager = Checkin_MKT192_Message_Bot_Manager::get_instance();

    // Chuẩn bị dữ liệu
    $current_date     = current_time('mysql');
    $employee_id      = get_current_user_id();
    $employee_name    = get_userdata($employee_id)->display_name;
    $mismatched_items = [];

    // Tạo mã phiếu kiểm kê: CHECK-YYYYMMDD-XXX
    $date_prefix = date('Ymd');
    $last_check  = $wpdb->get_var($wpdb->prepare(
        "SELECT check_code FROM $table_checks WHERE check_code LIKE %s ORDER BY id DESC LIMIT 1",
        "CHECK-{$date_prefix}-%"
    ));

    if ($last_check && preg_match('/CHECK-\d{8}-(\d{3})/', $last_check, $matches)) {
        $sequence = intval($matches[1]) + 1;
    } else {
        $sequence = 1;
    }
    $check_code = sprintf('CHECK-%s-%03d', $date_prefix, $sequence);

    // Lấy ou_id của nhân viên
    $employee_ou_id = $wpdb->get_var($wpdb->prepare(
        "SELECT ou_id FROM $table_staff WHERE display_name = %s",
        $employee_name
    ));

    if (!$employee_ou_id) {
        $error_message = "Không tìm thấy ou_id cho '$employee_name'";
        write_inventory_log($error_message);
        return ['success' => false, 'message' => $error_message];
    }

    // Bắt đầu giao dịch database
    $wpdb->query('START TRANSACTION');

    try {
        // Chuẩn bị dữ liệu inventory cho JSON
        $inventory_details = [];
        $total_products    = count($inventory_data);
        $mismatched_count  = 0;

        // Xử lý từng sản phẩm trong kiểm kê
        foreach ($inventory_data as $item) {
            $product_id      = intval($item['product_id']);
            $actual_quantity = intval($item['actual_quantity']);
            $stock           = intval($item['stock']);
            $is_mismatched   = $item['is_mismatched'];
            $reason          = !empty($item['reason']) ? sanitize_text_field($item['reason']) : '';

            // Lấy tên sản phẩm
            $product_name = $wpdb->get_var($wpdb->prepare(
                "SELECT product_name FROM $table_products WHERE id = %d",
                $product_id
            ));

            if (!$product_name) {
                throw new Exception("Sản phẩm ID $product_id không tồn tại");
            }

            // Thêm vào mảng chi tiết
            $inventory_details[] = [
                'product_id'      => $product_id,
                'product_name'    => $product_name,
                'stock'           => $stock,
                'actual_quantity' => $actual_quantity,
                'difference'      => $actual_quantity - $stock,
                'is_mismatched'   => $is_mismatched,
                'reason'          => $reason
            ];

            // Đếm số sản phẩm không khớp
            if ($is_mismatched) {
                $mismatched_count++;
                $difference         = $actual_quantity - $stock;
                $mismatched_items[] = "**Sản phẩm**: __{$product_name}__ - Tồn kho: __{$stock}__, Kiểm kê: __{$actual_quantity}__ (Chênh lệch: __{$difference}__), Lý do: __{$reason}__";
            }
        }

        // Xác định trạng thái tổng quan
        if ($mismatched_count === 0) {
            $status = 'matched';
        } elseif ($mismatched_count === $total_products) {
            $status = 'mismatched';
        } else {
            $status = 'partial';
        }

        // Lấy branch_id CHÍNH (primary) của staff từ bảng staff
        // Sử dụng helper để đảm bảo logic nhất quán khi bật/tắt multi-branch mode
        $branch_id = 0;
        if (function_exists('checkin_mkt192_is_multi_branch_enabled') && checkin_mkt192_is_multi_branch_enabled()) {
            if (function_exists('checkin_mkt192_get_staff_primary_branch_id')) {
                $branch_id = checkin_mkt192_get_staff_primary_branch_id();
            }
        }

        // Lưu phiếu kiểm kê vào bảng mới (1 dòng duy nhất)
        $inserted = $wpdb->insert(
            $table_checks,
            [
                'check_code'       => $check_code,
                'staff_name'       => $employee_name,
                'check_date'       => $current_date,
                'inventory_data'   => json_encode($inventory_details, JSON_UNESCAPED_UNICODE),
                'total_products'   => $total_products,
                'mismatched_count' => $mismatched_count,
                'status'           => $status,
                'note'             => sanitize_text_field($general_reason),
                'branch_id'        => $branch_id,
                'created_at'       => $current_date,
                'updated_at'       => $current_date
            ],
            ['%s', '%s', '%s', '%s', '%d', '%d', '%s', '%s', '%d', '%s', '%s']
        );

        if ($inserted === false) {
            throw new Exception('Lỗi khi lưu phiếu kiểm kê: ' . $wpdb->last_error);
        }

        // Commit giao dịch
        $wpdb->query('COMMIT');

        // Load card builder
        require_once __DIR__ . '/card-builder.php';

        // Get bot by notification type
        $bot = $bot_manager->get_bot_by_notification_type('inventory_check');
        if (!$bot) {
            write_inventory_log('Không tìm thấy bot được cấu hình cho loại thông báo: inventory_check');
            throw new Exception('Không tìm thấy bot được cấu hình cho loại thông báo: inventory_check');
        }
        $bot_type = $bot->bot_type;

        // Build card using card builder
        $card_data = [
            'check_code'       => $check_code,
            'current_date'     => $current_date,
            'employee_ou_id'   => $employee_ou_id,
            'employee_name'    => $employee_name,
            'total_products'   => $total_products,
            'mismatched_count' => $mismatched_count,
            'mismatched_items' => $mismatched_items
        ];

        $card = build_inventory_check_card($card_data, $bot_type);

        // Chuẩn bị payload cho card message
        $payload = [
            'msg_type' => 'interactive',
            'card'     => $card
        ];

        // Ghi log payload
        write_inventory_log('Payload gửi tới Lark', $payload);

        // Gửi thông báo qua Bot Manager
        $result = $bot_manager->send_message('inventory_check', null, $payload);

        if (is_wp_error($result)) {
            throw new Exception('Lỗi khi gửi thông báo kiểm kê: ' . $result->get_error_message());
        }

        // Ghi log phản hồi
        write_inventory_log('Phản hồi từ Lark', $result);

        write_inventory_log('Gửi tin nhắn kiểm kê tới Lark thành công');
        return ['success' => true, 'message' => 'Tin nhắn kiểm kê đã được gửi tới Lark', 'data' => $result];
    } catch (Exception $e) {
        // Rollback giao dịch nếu có lỗi
        $wpdb->query('ROLLBACK');
        write_inventory_log('Lỗi trong quá trình xử lý kiểm kê', ['error' => $e->getMessage()]);
        return ['success' => false, 'message' => 'Lỗi khi xử lý kiểm kê: ' . $e->getMessage()];
    }
}
?>
