<?php

add_action('rest_api_init', function () {
    register_rest_route('vg/v1', '/lark-callback', [
        'methods'             => 'POST',
        'callback'            => 'handle_lark_callback',
        'permission_callback' => '__return_true',
    ]);
});

require_once(dirname(__FILE__, 6) . '/wp-load.php');
require_once(__DIR__ . '/lark-utils.php');
require_once(__DIR__ . '/card-builder.php');
require_once(__DIR__ . '/cache-utils.php');
require_once(__DIR__ . '/send_salary_notification.php');
require_once(__DIR__ . '/send_stock_transaction_notification.php');
require_once(__DIR__ . '/send_approval_request_notification.php');

/**
 * Get salary data from database when cache is unavailable
 */
function get_salary_data_from_db($transaction_id) {
    global $wpdb;
    $table_cashier_salary     = $wpdb->prefix . 'checkin_mkt192_cashier_salary';
    $table_hairdresser_salary = $wpdb->prefix . 'checkin_mkt192_hairdresser_salary';
    $table_staff              = $wpdb->prefix . 'checkin_mkt192_staff';

    $salary_data = $wpdb->get_row($wpdb->prepare(
        "SELECT staff_name, actual_salary, period FROM $table_cashier_salary WHERE transaction_id = %s AND xac_nhan_thanh_toan IS NOT NULL
         UNION
         SELECT staff_name, actual_salary, period FROM $table_hairdresser_salary WHERE transaction_id = %s AND xac_nhan_thanh_toan IS NOT NULL",
        $transaction_id, $transaction_id
    ));

    if (!$salary_data) {
        CacheManager::write_log("No salary data found for transaction_id '$transaction_id'", [], 'lark_callback_log.log');
        return false;
    }

    return [
        'staff_name'       => $salary_data->staff_name,
        'actual_salary'    => $salary_data->actual_salary,
        'period'           => $salary_data->period,
        'transaction_type' => 'PAYROLL'
    ];
}

/**
 * Get inventory data from database when cache is unavailable
 */
function get_inventory_data_from_db($transaction_id) {
    global $wpdb;
    $table_transactions = $wpdb->prefix . 'checkin_mkt192_inventory_transactions';
    $table_staff        = $wpdb->prefix . 'checkin_mkt192_staff';

    $transaction_data = $wpdb->get_results($wpdb->prepare(
        "SELECT product_id, product_name, quantity, note, transaction_type, staff_name
         FROM $table_transactions
         WHERE transaction_id = %s",
        $transaction_id
    ));

    if (!$transaction_data) {
        CacheManager::write_log("No inventory data found for transaction_id '$transaction_id'", [], 'lark_callback_log.log');
        return false;
    }

    $employee_name  = $transaction_data[0]->staff_name;
    $employee_ou_id = $wpdb->get_var($wpdb->prepare(
        "SELECT ou_id FROM $table_staff WHERE display_name = %s",
        $employee_name
    ));

    if (!$employee_ou_id) {
        CacheManager::write_log("No ou_id found for employee '$employee_name'", [], 'lark_callback_log.log');
        return false;
    }

    $transactions = array_map(function ($row) {
        return [
            'product_id'   => $row->product_id,
            'product_name' => $row->product_name,
            'quantity'     => $row->quantity
        ];
    }, $transaction_data);

    return [
        'employee_name'    => $employee_name,
        'employee_ou_id'   => $employee_ou_id,
        'transaction_type' => $transaction_data[0]->transaction_type,
        'transaction_id'   => $transaction_id,
        'transactions'     => $transactions,
        'note'             => $transaction_data[0]->note
    ];
}

/**
 * Handle Lark callback
 */
function handle_lark_callback() {
    global $wpdb;

    $table_bot_settings = $wpdb->prefix . 'checkin_mkt192_message_bot_settings';
    $group_name         = 'all_staff_channel';
    $bot_name           = 'MKT192-Approval';
    $bot_settings       = $wpdb->get_row($wpdb->prepare(
        "SELECT chat_id, app_id, app_secret FROM $table_bot_settings WHERE group_name = %s AND bot_name = %s",
        $group_name, $bot_name
    ));

    if (!$bot_settings) {
        $error_message = "No bot or group info found for '$group_name' and '$bot_name'";
        CacheManager::write_log($error_message, [], 'lark_callback_log.log');
        echo json_encode(['success' => false, 'message' => $error_message]);
        http_response_code(500);
        exit;
    }

    $chat_id            = $bot_settings->chat_id;
    $app_id             = $bot_settings->app_id;
    $app_secret         = $bot_settings->app_secret;
    $verification_token = 'nYjX7Y3ZH7AEhp3N6gwtjgZR53mO8N17';

    header('Content-Type: application/json; charset=utf-8');
    $body       = file_get_contents('php://input');
    $data       = json_decode($body, true);
    $start_time = microtime(true);

    CacheManager::write_log('Received Lark request', [
        'raw_body'        => $body,
        'parsed_data'     => $data,
        'processing_time' => 0
    ], 'lark_callback_log.log');

    if (!isset($data['header']['event_type']) && !isset($data['type'])) {
        CacheManager::write_log('Invalid request structure', $data, 'lark_callback_log.log');
        echo json_encode(['success' => false, 'message' => 'Invalid request structure']);
        http_response_code(400);
        exit;
    }

    if (isset($data['type']) && $data['type'] === 'url_verification') {
        if (!isset($data['token'], $data['challenge']) || $data['token'] !== $verification_token) {
            CacheManager::write_log('Invalid token or challenge', $data, 'lark_callback_log.log');
            echo json_encode(['success' => false, 'message' => 'Invalid token or challenge']);
            http_response_code(400);
            exit;
        }
        echo json_encode(['challenge' => $data['challenge']]);
        http_response_code(200);
        exit;
    }

    if (isset($data['header']['event_type']) && $data['header']['event_type'] === 'card.action.trigger') {
        $token = $data['header']['token'] ?? '';
        if ($token !== $verification_token) {
            CacheManager::write_log('Invalid header token', ['token' => $token], 'lark_callback_log.log');
            echo json_encode(['success' => false, 'message' => 'Invalid header token']);
            http_response_code(400);
            exit;
        }

        $action_value    = $data['event']['action']['value']            ?? [];
        $open_message_id = $data['event']['context']['open_message_id'] ?? '';
        $card_token      = $data['event']['token']                      ?? '';
        $transaction_id  = sanitize_text_field($action_value['id'] ?? '');
        $status          = sanitize_text_field($action_value['trang_thai'] ?? '');
        $action_type     = sanitize_text_field($action_value['type'] ?? 'inventory_transaction');

        if (!$transaction_id || !$status || !$open_message_id || !$card_token || !in_array($status, ['ĐÃ DUYỆT', 'KHÔNG DUYỆT'])) {
            CacheManager::write_log('Invalid callback data', [
                'action_value'    => $action_value,
                'open_message_id' => $open_message_id,
                'card_token'      => $card_token,
                'status'          => $status,
                'action_type'     => $action_type
            ], 'lark_callback_log.log');
            echo json_encode(['success' => false, 'message' => 'Invalid data']);
            http_response_code(400);
            exit;
        }

        $is_salary_action           = in_array($action_type, ['salary_confirmation', 'salary_payment'], true);
        $is_approval_request_action = $action_type === 'approval_request';

        // Xử lý Approval Request (Đơn xin phép)
        if ($is_approval_request_action) {
            $request_id     = intval($action_value['id'] ?? 0);
            $new_status     = $status === 'ĐÃ DUYỆT' ? 'approved' : 'rejected';
            $approver_name  = sanitize_text_field($action_value['approver_name'] ?? 'Admin');

            // Cập nhật trạng thái đơn trong database
            $update_result = update_approval_request_status($request_id, $new_status, $approver_name);

            if (!$update_result) {
                CacheManager::write_log('Error updating approval request status', [
                    'request_id'    => $request_id,
                    'status'        => $new_status,
                    'approver_name' => $approver_name
                ], 'lark_callback_log.log');
                echo json_encode(['success' => false, 'message' => 'Error updating approval request status']);
                http_response_code(500);
                exit;
            }

            // Lấy thông tin đơn đã cập nhật
            $table_approval = $wpdb->prefix . 'checkin_mkt192_approval_requests';
            $request_data   = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM $table_approval WHERE id = %d",
                $request_id
            ), ARRAY_A);

            // Build card đã cập nhật
            $status_text  = $new_status === 'approved' ? '✅ Đã Duyệt' : '❌ Không Duyệt';
            $status_color = $new_status === 'approved' ? 'green' : 'red';
            $card         = build_approval_status_card($request_data, $status_text, $status_color);

            $toast_message = $new_status === 'approved' ? 'Đã duyệt đơn thành công' : 'Đã từ chối đơn';
            $toast_type    = $new_status === 'approved' ? 'success' : 'error';

            $response = [
                'toast' => [
                    'type'    => $toast_type,
                    'content' => $toast_message,
                    'i18n'    => [
                        'zh_cn' => $new_status === 'approved' ? '审批成功' : '已拒绝',
                        'en_us' => $new_status === 'approved' ? 'Approved successfully' : 'Rejected'
                    ]
                ],
                'card' => $card
            ];

            CacheManager::write_log('Approval request processed', [
                'request_id' => $request_id,
                'status'     => $new_status,
                'approver'   => $approver_name
            ], 'lark_callback_log.log');

            echo json_encode($response, JSON_UNESCAPED_UNICODE);
            http_response_code(200);
            exit;
        }

        $cache_prefix      = $is_salary_action ? CACHE_PREFIX_SALARY : CACHE_PREFIX_INVENTORY;
        $fallback_callback = $is_salary_action ? 'get_salary_data_from_db' : 'get_inventory_data_from_db';

        $cached_data = CacheManager::get($transaction_id, $cache_prefix, $fallback_callback);

        if (!$cached_data) {
            CacheManager::write_log('Failed to retrieve data from cache or database', [
                'transaction_id' => $transaction_id,
                'action_type'    => $action_type,
                'cache_prefix'   => $cache_prefix
            ], 'lark_callback_log.log');
            echo json_encode(['success' => false, 'message' => 'Failed to retrieve data']);
            http_response_code(500);
            exit;
        }

        // Lưu cache nếu dữ liệu được lấy từ database
        if (!get_transient("{$cache_prefix}_{$transaction_id}")) {
            CacheManager::store($transaction_id, $cached_data, $cache_prefix);
        }

        // Xác định status_value và status_color dựa theo loại action
        if ($is_salary_action) {
            $status_value  = $status === 'ĐÃ DUYỆT' ? '✅ Đã nhận đủ' : '❌ Chưa nhận được';
            $toast_message = $status === 'ĐÃ DUYỆT' ? 'Xác nhận thành công' : 'Đã gửi yêu cầu xét lại';
        } else {
            $status_value  = $status === 'ĐÃ DUYỆT' ? '✅ Đã Duyệt' : '❌ Không Duyệt';
            $toast_message = $status === 'ĐÃ DUYỆT' ? 'Đã duyệt thành công' : 'Đã từ chối';
        }
        $status_color = $status === 'ĐÃ DUYỆT' ? 'green' : 'red';
        $card         = build_callback_card($transaction_id, $status_value, $status_color, [CacheManager::class, 'write_log'], $action_type);

        if ($card === false) {
            CacheManager::write_log('Error building card', [
                'transaction_id' => $transaction_id,
                'status'         => $status,
                'action_type'    => $action_type,
                'cached_data'    => $cached_data
            ], 'lark_callback_log.log');
            echo json_encode(['success' => false, 'message' => 'Error building card']);
            http_response_code(500);
            exit;
        }

        $db_updated = false;
        if ($is_salary_action) {
            $staff_name = sanitize_text_field($action_value['staff_name'] ?? '');
            $period     = sanitize_text_field($action_value['period'] ?? '');
            $db_updated = update_salary_payment_confirmation($transaction_id, $staff_name, $period, $status);
            if (!$db_updated) {
                CacheManager::write_log('Error updating salary status', [
                    'transaction_id' => $transaction_id,
                    'staff_name'     => $staff_name,
                    'status'         => $status
                ], 'lark_callback_log.log');
                echo json_encode(['success' => false, 'message' => 'Error updating salary status']);
                http_response_code(500);
                exit;
            }
        } else {
            $db_updated = update_transaction_status($transaction_id, $status);
            if (!$db_updated) {
                CacheManager::write_log('Error updating inventory transaction status', [
                    'transaction_id' => $transaction_id,
                    'status'         => $status
                ], 'lark_callback_log.log');
                echo json_encode(['success' => false, 'message' => 'Error updating inventory transaction status']);
                http_response_code(500);
                exit;
            }
        }

        $toast_type    = $status === 'ĐÃ DUYỆT' ? 'success' : 'error';
        $response      = [
            'toast' => [
                'type'    => $toast_type,
                'content' => $toast_message,
                'i18n'    => [
                    'zh_cn' => $status === 'ĐÃ DUYỆT' ? '卡片交互成功' : '卡片交互失败',
                    'en_us' => $status === 'ĐÃ DUYỆT' ? 'Card action success' : 'Card action failed'
                ]
            ],
            'card' => $card
        ];

        CacheManager::delete($transaction_id, $cache_prefix);

        $end_time        = microtime(true);
        $processing_time = $end_time - $start_time;
        if ($processing_time > 3) {
            CacheManager::write_log('Callback processing time exceeded 3 seconds', [
                'transaction_id'  => $transaction_id,
                'processing_time' => $processing_time
            ], 'lark_callback_log.log');
        }

        CacheManager::write_log('Returning Update Now response with toast and card', [
            'card_token'      => $card_token,
            'response'        => $response,
            'processing_time' => $processing_time
        ], 'lark_callback_log.log');
        echo json_encode($response, JSON_UNESCAPED_UNICODE);
        http_response_code(200);
        exit;
    }

    CacheManager::write_log('Unsupported request', $data, 'lark_callback_log.log');
    echo json_encode(['success' => false, 'message' => 'Unsupported request']);
    http_response_code(400);
    exit;
}
?>
