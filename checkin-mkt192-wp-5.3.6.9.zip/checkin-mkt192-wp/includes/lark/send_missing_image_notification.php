<?php

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

require_once __DIR__ . '/lark-utils.php';

/**
 * Class xử lý gửi thông báo nhắc nhở hóa đơn thiếu hình ảnh qua Lark.
 */
class Checkin_MKT192_MissingImageNotification {
    /**
     * Ghi log vào file send_missing_image_notification.log.
     *
     * @param string $message Thông điệp log.
     * @param array  $data    Dữ liệu bổ sung (tùy chọn).
     */
    private static function write_log($message, $data = []) {
        $log_file  = __DIR__ . '/logs/send_missing_image_notification.log';
        $timestamp = date('Y-m-d H:i:s');
        $log_entry = "[$timestamp] $message\n";
        if (!empty($data)) {
            $log_entry .= 'Data: ' . json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
        }
        $log_entry .= "----------------------------------------\n";
        file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);
    }

    /**
     * Gửi thông báo nhắc nhở về hóa đơn thiếu hình ảnh qua Lark.
     *
     * @return array Kết quả gửi.
     */
    public static function send_missing_image_notification() {
        global $wpdb;
        $table_invoices = $wpdb->prefix . 'checkin_mkt192_invoices_data';
        $table_staff    = $wpdb->prefix . 'checkin_mkt192_staff';

        // Ghi log bắt đầu
        self::write_log('Bắt đầu gửi thông báo nhắc nhở');

        // Kiểm tra Lark có được kích hoạt không
        if (!is_lark_enabled()) {
            $message = 'Lark chưa được kích hoạt';
            self::write_log($message);
            return ['success' => false, 'message' => $message];
        }

        // Load Bot Manager
        require_once __DIR__ . '/class-checkin-mkt192-message-bot-manager.php';
        $bot_manager = Checkin_MKT192_Message_Bot_Manager::get_instance();

        // Lấy danh sách hóa đơn hôm nay
        $today = date('Y-m-d');
        $query = $wpdb->prepare(
            "SELECT invoice_id, created_user, images, not_image
             FROM $table_invoices
             WHERE DATE(created_at) = %s
             AND (images IS NULL OR TRIM(images) = '' OR images = '[]')
             AND customer_name != %s",
            $today, 'KHÁCH VÃNG LAI'
        );

        $invoices = $wpdb->get_results($query);

        self::write_log('Kết quả truy vấn hóa đơn thiếu hình ảnh', [
            'query'    => $query,
            'num_rows' => count($invoices),
            'invoices' => $invoices
        ]);

        if (empty($invoices)) {
            $message = 'Không có hóa đơn nào hôm nay thiếu hình ảnh (loại trừ KHÁCH VÃNG LAI)';
            self::write_log($message);
            return ['success' => true, 'message' => $message];
        }

        // Phân loại danh sách thợ
        $no_image_no_reason   = [];
        $no_image_with_reason = [];

        foreach ($invoices as $invoice) {
            $ou_id = $wpdb->get_var($wpdb->prepare(
                "SELECT ou_id FROM $table_staff WHERE display_name = %s",
                $invoice->created_user
            ));

            self::write_log('Xử lý hóa đơn', [
                'invoice_id'   => $invoice->invoice_id,
                'created_user' => $invoice->created_user,
                'images'       => $invoice->images,
                'not_image'    => $invoice->not_image,
                'ou_id'        => $ou_id
            ]);

            $staff_info = [
                'display_name' => $invoice->created_user,
                'invoice_id'   => $invoice->invoice_id,
                'ou_id'        => $ou_id ?: null
            ];

            if (empty($invoice->not_image)) {
                $no_image_no_reason[] = $staff_info;
            } else {
                $staff_info['reason']   = $invoice->not_image;
                $no_image_with_reason[] = $staff_info;
            }
        }

        self::write_log('Trạng thái danh sách thợ', [
            'no_image_no_reason'   => $no_image_no_reason,
            'no_image_with_reason' => $no_image_with_reason
        ]);

        // Load card builder
        require_once __DIR__ . '/card-builder.php';

        // Get bot by notification type
        $bot = $bot_manager->get_bot_by_notification_type('missing_image_reminder');
        if (!$bot) {
            $message = 'Không tìm thấy bot được cấu hình cho loại thông báo: missing_image_reminder';
            self::write_log($message);
            return ['success' => false, 'message' => $message];
        }
        $bot_type = $bot->bot_type;

        // Build card using card builder
        $card_data = [
            'today'                => $today,
            'no_image_no_reason'   => $no_image_no_reason,
            'no_image_with_reason' => $no_image_with_reason,
            'upload_url'           => 'https://vangroupbarbershop.store/upload-image'
        ];

        $card = build_missing_image_reminder_card($card_data, $bot_type);

        // Chuẩn bị payload
        $payload = [
            'msg_type' => 'interactive',
            'card'     => $card
        ];

        self::write_log('Payload gửi tới Lark', $payload);

        // Kiểm tra bot được sử dụng
        $bot = $bot_manager->get_bot_by_notification_type('general');
        self::write_log('Bot được sử dụng', [
            'bot_exists' => !empty($bot),
            'bot_info'   => $bot ? [
                'id'        => $bot->id,
                'name'      => $bot->bot_name,
                'type'      => $bot->bot_type,
                'is_active' => $bot->is_active
            ] : null
        ]);

        // Gửi thông báo qua Bot Manager
        $result = $bot_manager->send_message('missing_image_reminder', null, $payload);

        self::write_log('Kết quả gửi từ Bot Manager', [
            'is_error' => is_wp_error($result),
            'result'   => $result
        ]);

        if (is_wp_error($result)) {
            $error_message = 'Error sending missing image notification: ' . $result->get_error_message();
            self::write_log($error_message);
            return ['success' => false, 'message' => $error_message];
        }

        self::write_log('Phản hồi từ Lark', $result);

        // Kiểm tra response code
        if (isset($result['code']) && $result['code'] == 0) {
            self::write_log('✅ Gửi tin nhắn nhắc nhở tới Lark thành công');
            return ['success' => true, 'message' => 'Tin nhắn nhắc nhở đã được gửi tới Lark'];
        } else {
            $error_msg = isset($result['msg']) ? $result['msg'] : 'Unknown error';
            self::write_log('❌ Lark API trả về lỗi: ' . $error_msg);
            return ['success' => false, 'message' => 'Lark API error: ' . $error_msg];
        }
    }
}
?>