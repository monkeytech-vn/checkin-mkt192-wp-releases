<?php
/**
 * Admin page để quản lý Message Bots
 */

if (!defined('ABSPATH')) {
    exit;
}

class Checkin_MKT192_Message_Bot_Admin {

    private static $instance = null;
    private $bot_manager;

    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        require_once plugin_dir_path(__FILE__) . 'class-checkin-mkt192-message-bot-manager.php';
        $this->bot_manager = Checkin_MKT192_Message_Bot_Manager::get_instance();

        // No longer add admin menu - bot management is now handled in Connections page
        // add_action('admin_menu', [$this, 'add_menu_page']);

        add_action('admin_post_checkin_save_message_bot', [$this, 'handle_save_bot']);
        add_action('admin_post_checkin_delete_message_bot', [$this, 'handle_delete_bot']);
        add_action('admin_post_checkin_toggle_bot', [$this, 'handle_toggle_bot']);
    }

    // Removed - bot management is now integrated in Connections page
    // public function add_menu_page() {
    //     add_submenu_page(
    //         'checkin-mkt192-dashboard',
    //         __('Quản lý Bot Thông báo', 'checkin-mkt192'),
    //         __('Bot Thông báo', 'checkin-mkt192'),
    //         'manage_options',
    //         'checkin-message-bots',
    //         [$this, 'render_page']
    //     );
    // }

    public function render_page() {
        $action = isset($_GET['action']) ? $_GET['action'] : 'list';
        $bot_id = isset($_GET['bot_id']) ? absint($_GET['bot_id']) : 0;

        ?>
<div class="wrap">
    <h1>
        <?php _e('Quản lý Bot Thông báo', 'checkin-mkt192'); ?>
        <?php if ($action === 'list'): ?>
        <a href="<?php echo admin_url('admin.php?page=checkin-message-bots&action=add'); ?>" class="page-title-action">
            <?php _e('Thêm Bot', 'checkin-mkt192'); ?>
        </a>
        <?php endif; ?>
    </h1>

    <?php
            // Hiển thị thông báo
            if (isset($_GET['message'])):
                $message = sanitize_text_field($_GET['message']);
                $class   = 'notice-success';

                switch ($message) {
                    case 'bot_created':
                        $text = 'Bot đã được tạo thành công!';
                        break;
                    case 'bot_updated':
                        $text = 'Bot đã được cập nhật thành công!';
                        break;
                    case 'bot_deleted':
                        $text = 'Bot đã được xóa!';
                        break;
                    case 'bot_toggled':
                        $text = 'Trạng thái bot đã được thay đổi!';
                        break;
                    default:
                        $text = '';
                }

                if ($text):
            ?>
    <div class="notice <?php echo $class; ?> is-dismissible">
        <p><?php echo esc_html($text); ?></p>
    </div>
    <?php
                endif;
            endif;
            ?>

    <?php
            switch ($action) {
                case 'add':
                    $this->render_add_form();
                    break;
                case 'edit':
                    $this->render_edit_form($bot_id);
                    break;
                default:
                    $this->render_list();
                    break;
            }
            ?>
</div>
<?php
    }

    private function render_list() {
        $bots = $this->bot_manager->get_all_bots();
        ?>
<table class="wp-list-table widefat fixed striped">
    <thead>
        <tr>
            <th width="5%">ID</th>
            <th width="15%">
                <?php _e('Tên Bot', 'checkin-mkt192'); ?>
            </th>
            <th width="10%">
                <?php _e('Loại Bot', 'checkin-mkt192'); ?>
            </th>
            <th width="30%">
                <?php _e('Loại Thông báo', 'checkin-mkt192'); ?>
            </th>
            <th width="15%">
                <?php _e('Cấu hình', 'checkin-mkt192'); ?>
            </th>
            <th width="10%">
                <?php _e('Trạng thái', 'checkin-mkt192'); ?>
            </th>
            <th width="15%">
                <?php _e('Hành động', 'checkin-mkt192'); ?>
            </th>
        </tr>
    </thead>
    <tbody>
        <?php if (empty($bots)): ?>
        <tr>
            <td colspan="7" style="text-align:center; padding:20px;">
                <?php _e('Chưa có bot nào. Click "Thêm Bot" để tạo bot mới.', 'checkin-mkt192'); ?>
            </td>
        </tr>
        <?php else: ?>
        <?php foreach ($bots as $bot): ?>
        <tr>
            <td><?php echo $bot->id; ?></td>
            <td><strong><?php echo esc_html($bot->bot_name); ?></strong>
            </td>
            <td>
                <?php
                            $type_label = Checkin_MKT192_Message_Bot_Manager::BOT_TYPES[$bot->bot_type] ?? $bot->bot_type;
                            echo esc_html($type_label);
                            ?>
            </td>
            <td>
                <?php
                            $types       = $bot->notification_types ?? [];
                            $type_labels = [];
                            foreach ($types as $type) {
                                $type_labels[] = Checkin_MKT192_Message_Bot_Manager::NOTIFICATION_TYPES[$type] ?? $type;
                            }
                            echo implode(', ', $type_labels);
                            ?>
            </td>
            <td>
                <?php if ($bot->bot_type === 'interactive'): ?>
                <small>
                    Chat:
                    <?php echo esc_html(substr($bot->chat_id, 0, 20)); ?>...<br>
                    App:
                    <?php echo esc_html(substr($bot->app_id, 0, 15)); ?>...
                </small>
                <?php else: ?>
                <small>
                    <?php echo esc_url(substr($bot->webhook_url, 0, 40)); ?>...
                </small>
                <?php endif; ?>
            </td>
            <td>
                <?php if ($bot->is_active): ?>
                <span class="dashicons dashicons-yes-alt" style="color:green;"></span> Active
                <?php else: ?>
                <span class="dashicons dashicons-dismiss" style="color:red;"></span> Inactive
                <?php endif; ?>
            </td>
            <td>
                <a href="<?php echo admin_url('admin.php?page=checkin-message-bots&action=edit&bot_id=' . $bot->id); ?>"
                    class="button button-small">
                    <?php _e('Sửa', 'checkin-mkt192'); ?>
                </a>
                <a href="<?php echo wp_nonce_url(admin_url('admin-post.php?action=checkin_toggle_bot&bot_id=' . $bot->id), 'toggle_bot_' . $bot->id); ?>"
                    class="button button-small">
                    <?php echo $bot->is_active ? __('Tắt', 'checkin-mkt192') : __('Bật', 'checkin-mkt192'); ?>
                </a>
                <a href="<?php echo wp_nonce_url(admin_url('admin-post.php?action=checkin_delete_message_bot&bot_id=' . $bot->id), 'delete_bot_' . $bot->id); ?>"
                    class="button button-small button-link-delete"
                    onclick="return confirm('Bạn có chắc muốn xóa bot này?');">
                    <?php _e('Xóa', 'checkin-mkt192'); ?>
                </a>
            </td>
        </tr>
        <?php endforeach; ?>
        <?php endif; ?>
    </tbody>
</table>
<?php
    }

    private function render_add_form() {
        $this->render_form();
    }

    private function render_edit_form($bot_id) {
        $bot = $this->bot_manager->get_bot($bot_id);
        if (!$bot) {
            echo '<div class="notice notice-error"><p>Không tìm thấy bot!</p></div>';
            return;
        }
        $this->render_form($bot);
    }

    private function render_form($bot = null) {
        $is_edit            = !empty($bot);
        $bot_id             = $is_edit ? $bot->id : 0;
        $bot_name           = $is_edit ? $bot->bot_name : '';
        $bot_type           = $is_edit ? $bot->bot_type : 'interactive';
        $notification_types = $is_edit ? ($bot->notification_types ?? []) : [];
        $chat_id            = $is_edit ? ($bot->chat_id ?? '') : '';
        $app_id             = $is_edit ? ($bot->app_id ?? '') : '';
        $app_secret         = $is_edit ? ($bot->app_secret ?? '') : '';
        $webhook_url        = $is_edit ? ($bot->webhook_url ?? '') : '';
        $is_active          = $is_edit ? $bot->is_active : 1;

        ?>
<form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
    <input type="hidden" name="action" value="checkin_save_message_bot">
    <?php if ($is_edit): ?>
    <input type="hidden" name="bot_id" value="<?php echo $bot_id; ?>">
    <?php endif; ?>
    <?php wp_nonce_field('save_message_bot', 'message_bot_nonce'); ?>

    <table class="form-table">
        <tr>
            <th scope="row">
                <label for="bot_name"><?php _e('Tên Bot', 'checkin-mkt192'); ?>
                    *</label>
            </th>
            <td>
                <input type="text" name="bot_name" id="bot_name" value="<?php echo esc_attr($bot_name); ?>"
                    class="regular-text" required>
                <p class="description">
                    <?php _e('Tên để nhận diện bot', 'checkin-mkt192'); ?>
                </p>
            </td>
        </tr>

        <tr>
            <th scope="row">
                <label for="bot_type"><?php _e('Loại Bot', 'checkin-mkt192'); ?>
                    *</label>
            </th>
            <td>
                <select name="bot_type" id="bot_type" required>
                    <?php foreach (Checkin_MKT192_Message_Bot_Manager::BOT_TYPES as $key => $label): ?>
                    <option value="<?php echo esc_attr($key); ?>" <?php selected($bot_type, $key); ?>>
                        <?php echo esc_html($label); ?>
                    </option>
                    <?php endforeach; ?>
                </select>
                <p class="description">
                    <?php _e('Bot tương tác dùng Lark API, Bot webhook gửi qua URL webhook', 'checkin-mkt192'); ?>
                </p>
            </td>
        </tr>

        <tr>
            <th scope="row">
                <label><?php _e('Loại Thông báo', 'checkin-mkt192'); ?>
                    *</label>
            </th>
            <td>
                <?php foreach (Checkin_MKT192_Message_Bot_Manager::NOTIFICATION_TYPES as $key => $label): ?>
                <label style="display:block; margin-bottom:5px;">
                    <input type="checkbox" name="notification_types[]" value="<?php echo esc_attr($key); ?>"
                        <?php checked(in_array($key, $notification_types)); ?>>
                    <?php echo esc_html($label); ?>
                </label>
                <?php endforeach; ?>
                <p class="description">
                    <?php _e('Chọn các loại thông báo mà bot này sẽ xử lý', 'checkin-mkt192'); ?>
                </p>
            </td>
        </tr>

        <!-- Interactive Bot Fields -->
        <tbody id="interactive_fields" style="<?php echo $bot_type === 'webhook' ? 'display:none;' : ''; ?>">
            <tr>
                <th scope="row">
                    <label for="chat_id"><?php _e('Chat ID', 'checkin-mkt192'); ?></label>
                </th>
                <td>
                    <input type="text" name="chat_id" id="chat_id" value="<?php echo esc_attr($chat_id); ?>"
                        class="regular-text">
                    <p class="description">
                        <?php _e('Chat ID hoặc Group ID của Lark', 'checkin-mkt192'); ?>
                    </p>
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="app_id"><?php _e('App ID', 'checkin-mkt192'); ?></label>
                </th>
                <td>
                    <input type="text" name="app_id" id="app_id" value="<?php echo esc_attr($app_id); ?>"
                        class="regular-text">
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="app_secret"><?php _e('App Secret', 'checkin-mkt192'); ?></label>
                </th>
                <td>
                    <input type="password" name="app_secret" id="app_secret"
                        value="<?php echo esc_attr($app_secret); ?>" class="regular-text">
                </td>
            </tr>
        </tbody>

        <!-- Webhook Bot Fields -->
        <tbody id="webhook_fields" style="<?php echo $bot_type === 'interactive' ? 'display:none;' : ''; ?>">
            <tr>
                <th scope="row">
                    <label for="webhook_url"><?php _e('Webhook URL', 'checkin-mkt192'); ?></label>
                </th>
                <td>
                    <input type="url" name="webhook_url" id="webhook_url" value="<?php echo esc_url($webhook_url); ?>"
                        class="regular-text">
                    <p class="description">
                        <?php _e('URL webhook để gửi tin nhắn', 'checkin-mkt192'); ?>
                    </p>
                </td>
            </tr>
        </tbody>

        <tr>
            <th scope="row">
                <label for="is_active"><?php _e('Trạng thái', 'checkin-mkt192'); ?></label>
            </th>
            <td>
                <label>
                    <input type="checkbox" name="is_active" id="is_active" value="1" <?php checked($is_active, 1); ?>>
                    <?php _e('Active', 'checkin-mkt192'); ?>
                </label>
            </td>
        </tr>

        <?php if ($bot_type === 'interactive'): ?>
        <tr class="interactive-fields">
            <th scope="row">
                <label><?php _e('Callback URL', 'checkin-mkt192'); ?></label>
            </th>
            <td>
                <?php
                require_once dirname(__FILE__) . '/lark-utils.php';
                $callback_url = get_lark_callback_url();
                ?>
                <input type="text" value="<?php echo esc_attr($callback_url); ?>" class="regular-text" readonly>
                <button type="button" class="button"
                    onclick="navigator.clipboard.writeText('<?php echo esc_js($callback_url); ?>'); alert('Đã copy callback URL!');">
                    📋 Copy
                </button>
                <p class="description">
                    URL này cần được đăng ký trong <strong>Lark Open Platform</strong> →
                    Event Subscriptions → Request URL<br>
                    <a href="https://open.feishu.cn/app" target="_blank">Mở Lark Open Platform →</a>
                </p>
            </td>
        </tr>
        <?php endif; ?>
    </table>

    <p class="submit">
        <button type="submit" class="button button-primary">
            <?php echo $is_edit ? __('Cập nhật Bot', 'checkin-mkt192') : __('Tạo Bot', 'checkin-mkt192'); ?>
        </button>
        <a href="<?php echo admin_url('admin.php?page=checkin-message-bots'); ?>" class="button">
            <?php _e('Hủy', 'checkin-mkt192'); ?>
        </a>
    </p>
</form>

<script>
jQuery(document).ready(function($) {
    function toggleBotFields() {
        var type = $('#bot_type').val();
        if (type === 'interactive') {
            $('#interactive_fields').show();
            $('#webhook_fields').hide();
        } else {
            $('#interactive_fields').hide();
            $('#webhook_fields').show();
        }
    }

    // Toggle fields on change
    $('#bot_type').on('change', toggleBotFields);

    // Trigger on page load to ensure correct display
    toggleBotFields();
});
</script>
<?php
    }

    public function handle_save_bot() {
        check_admin_referer('save_message_bot', 'message_bot_nonce');

        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }

        $bot_id  = isset($_POST['bot_id']) ? absint($_POST['bot_id']) : 0;
        $is_edit = $bot_id > 0;

        $data = [
            'bot_name'           => sanitize_text_field($_POST['bot_name']),
            'bot_type'           => sanitize_text_field($_POST['bot_type']),
            'notification_types' => isset($_POST['notification_types']) ? $_POST['notification_types'] : [],
            'is_active'          => isset($_POST['is_active']) ? 1 : 0
        ];

        if ($data['bot_type'] === 'interactive') {
            $data['chat_id']    = sanitize_text_field($_POST['chat_id']);
            $data['app_id']     = sanitize_text_field($_POST['app_id']);
            $data['app_secret'] = sanitize_text_field($_POST['app_secret']);
        } else {
            $data['webhook_url'] = esc_url_raw($_POST['webhook_url']);
        }

        if ($is_edit) {
            $result  = $this->bot_manager->update_bot($bot_id, $data);
            $message = 'bot_updated';
        } else {
            $result  = $this->bot_manager->create_bot($data);
            $message = 'bot_created';
        }

        if (is_wp_error($result)) {
            wp_die($result->get_error_message());
        }

        wp_redirect(admin_url('admin.php?page=checkin-message-bots&message=' . $message));
        exit;
    }

    public function handle_delete_bot() {
        $bot_id = isset($_GET['bot_id']) ? absint($_GET['bot_id']) : 0;
        check_admin_referer('delete_bot_' . $bot_id);

        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }

        $this->bot_manager->delete_bot($bot_id);

        wp_redirect(admin_url('admin.php?page=checkin-message-bots&message=bot_deleted'));
        exit;
    }

    public function handle_toggle_bot() {
        $bot_id = isset($_GET['bot_id']) ? absint($_GET['bot_id']) : 0;
        check_admin_referer('toggle_bot_' . $bot_id);

        if (!current_user_can('manage_options')) {
            wp_die('Unauthorized');
        }

        $this->bot_manager->toggle_active($bot_id);

        wp_redirect(admin_url('admin.php?page=checkin-message-bots&message=bot_toggled'));
        exit;
    }
}

// Initialize
Checkin_MKT192_Message_Bot_Admin::get_instance();
?>