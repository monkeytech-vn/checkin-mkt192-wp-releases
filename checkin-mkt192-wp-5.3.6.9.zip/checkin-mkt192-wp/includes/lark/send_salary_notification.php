<?php

require_once(dirname(__FILE__, 6) . '/wp-load.php');
require_once(__DIR__ . '/lark-utils.php');
require_once(__DIR__ . '/card-builder.php');
require_once(__DIR__ . '/cache-utils.php');

/**
 * Generate unique transaction ID
 */
function generate_salary_transaction_id() {
    $timestamp = time();
    $random    = mt_rand(1000, 999999);
    return "salary_{$timestamp}_{$random}";
}

/**
 * Send notification to group webhook - LOẠI 4
 * Gửi thông báo vào Group quản lý khi nhân viên bấm nút xác nhận trên card Lark
 */
function send_group_notification($transaction_id, $staff_name, $period, $status, $actual_salary) {
    // Load Bot Manager
    require_once __DIR__ . '/class-checkin-mkt192-message-bot-manager.php';
    $bot_manager = Checkin_MKT192_Message_Bot_Manager::get_instance();

    $card = build_salary_payment_completion_card($staff_name, $period, $status, $actual_salary);

    CacheManager::write_log('Sending salary confirmation via Bot Manager', [
        'card'           => $card,
        'transaction_id' => $transaction_id
    ], 'salary_notification.log');

    $start_time    = microtime(true);
    $result        = $bot_manager->send_message('salary', null, $card);
    $response_time = microtime(true) - $start_time;

    if (is_wp_error($result)) {
        $error_message = 'Error sending salary confirmation: ' . $result->get_error_message();
        CacheManager::write_log($error_message, [
            'transaction_id' => $transaction_id
        ], 'salary_notification.log');
        return false;
    }

    CacheManager::write_log('Group notification response', [
        'result'         => $result,
        'response_time'  => $response_time,
        'transaction_id' => $transaction_id
    ], 'salary_notification.log');

    return true;
}

/**
 * Update salary confirmation status
 */
function update_salary_payment_confirmation($transaction_id, $staff_name, $period, $status) {
    global $wpdb;
    $table_staff              = $wpdb->prefix . 'checkin_mkt192_staff';
    $table_cashier_salary     = $wpdb->prefix . 'checkin_mkt192_cashier_salary';
    $table_hairdresser_salary = $wpdb->prefix . 'checkin_mkt192_hairdresser_salary';

    $user_role = $wpdb->get_var($wpdb->prepare(
        "SELECT user_role FROM $table_staff WHERE display_name = %s",
        $staff_name
    ));

    if (!$user_role) {
        CacheManager::write_log("No user_role found for employee '$staff_name'", [
            'transaction_id' => $transaction_id
        ], 'salary_notification.log');
        return false;
    }

    $table = ($user_role === 'Thu Ngân') ? $table_cashier_salary : $table_hairdresser_salary;

    // Fetch actual_salary for the notification card
    $actual_salary = $wpdb->get_var($wpdb->prepare(
        "SELECT actual_salary FROM $table WHERE staff_name = %s AND period = %s",
        $staff_name,
        $period
    ));

    // Xác định giá trị text và status dựa trên trạng thái
    $status_text  = ($status === 'ĐÃ DUYỆT') ? 'Đã nhận đủ' : 'Chưa nhận được';
    $status_value = ($status === 'ĐÃ DUYỆT') ? 'received' : 'disputed';

    // Cập nhật cả xac_nhan_thanh_toan và status
    $updated = $wpdb->update(
        $table,
        [
            'xac_nhan_thanh_toan' => $status_text,
            'status'              => $status_value
        ],
        ['staff_name' => $staff_name, 'period' => $period],
        ['%s', '%s'],
        ['%s', '%s']
    );

    if ($updated === false) {
        CacheManager::write_log("Error updating salary payment confirmation in $table", [
            'transaction_id' => $transaction_id,
            'staff_name'     => $staff_name,
            'period'         => $period,
            'status'         => $status,
            'status_text'    => $status_text,
            'status_value'   => $status_value
        ], 'salary_notification.log');
        return false;
    }

    if ($updated === 0) {
        CacheManager::write_log("No matching record found in $table", [
            'transaction_id' => $transaction_id,
            'staff_name'     => $staff_name,
            'period'         => $period,
            'status'         => $status
        ], 'salary_notification.log');
        return false;
    }

    CacheManager::write_log('Successfully updated xac_nhan_thanh_toan and status', [
        'table'          => $table,
        'transaction_id' => $transaction_id,
        'staff_name'     => $staff_name,
        'period'         => $period,
        'status'         => $status,
        'status_text'    => $status_text,
        'status_value'   => $status_value,
        'rows_affected'  => $updated
    ], 'salary_notification.log');

    // Push notification: Thông báo cho admin khi nhân viên xác nhận thanh toán qua Lark
    if (function_exists('checkin_push_notify_salary_payment_confirmed')) {
        // Lấy branch_id của nhân viên
        $staff_user = get_user_by('login', $staff_name);
        $branch_id  = null;
        if ($staff_user) {
            $branch_id = get_user_meta($staff_user->ID, 'branch_id', true);
        }
        checkin_push_notify_salary_payment_confirmed($staff_name, $period, $status_value, $branch_id);
    }

    return true;
}

/**
 * Cache salary data
 */
function cache_salary_data($transaction_id, $salary_data) {
    $cache_data = [
        'staff_name'       => $salary_data['staff_name'],
        'actual_salary'    => $salary_data['actual_salary'],
        'period'           => $salary_data['period'],
        'transaction_type' => 'PAYROLL'
    ];
    return CacheManager::store($transaction_id, $cache_data, CACHE_PREFIX_SALARY);
}

/**
 * Send salary notification
 */
function send_salary_payment_notification($salary_data) {
    global $wpdb;
    $table_staff = $wpdb->prefix . 'checkin_mkt192_staff';

    // Load Bot Manager
    require_once __DIR__ . '/class-checkin-mkt192-message-bot-manager.php';
    $bot_manager = Checkin_MKT192_Message_Bot_Manager::get_instance();

    $ou_id = $wpdb->get_var($wpdb->prepare(
        "SELECT ou_id FROM $table_staff WHERE display_name = %s",
        $salary_data['staff_name']
    ));

    if (!$ou_id) {
        $error_message = "No ou_id found for employee '$salary_data[staff_name]'";
        CacheManager::write_log($error_message, [], 'salary_notification.log');
        return ['success' => false, 'message' => $error_message];
    }

    $transaction_id = generate_salary_transaction_id();
    $cache_result   = cache_salary_data($transaction_id, $salary_data);

    if (!$cache_result) {
        $error_message = 'Error caching salary data';
        CacheManager::write_log($error_message, ['transaction_id' => $transaction_id], 'salary_notification.log');
        return ['success' => false, 'message' => $error_message];
    }

    // Lấy bot để biết loại bot
    $bot = $bot_manager->get_bot_by_notification_type('salary_payment');
    if (!$bot) {
        $error_message = "No bot found for notification type 'salary_payment'";
        CacheManager::write_log($error_message, [], 'salary_notification.log');
        return ['success' => false, 'message' => $error_message];
    }

    CacheManager::write_log('Salary notification info', [
        'ou_id'          => $ou_id,
        'transaction_id' => $transaction_id,
        'bot_type'       => $bot->bot_type
    ], 'salary_notification.log');

    // Build card theo loại bot
    $card = build_salary_payment_card($transaction_id, $salary_data, $ou_id, $bot->bot_type);

    CacheManager::write_log('Card sent to Bot Manager', [
        'ou_id'          => $ou_id,
        'transaction_id' => $transaction_id,
        'card'           => $card
    ], 'salary_notification.log');

    $start_time    = microtime(true);
    // Gửi đến cá nhân nhân viên bằng cách truyền ou_id
    $result        = $bot_manager->send_message('salary_payment', null, $card, $ou_id);
    $response_time = microtime(true) - $start_time;

    if (is_wp_error($result)) {
        $error_message = 'Error sending salary notification: ' . $result->get_error_message();
        CacheManager::write_log($error_message, [], 'salary_notification.log');
        return ['success' => false, 'message' => $error_message];
    }

    CacheManager::write_log('Lark response', [
        'result'        => $result,
        'response_time' => $response_time
    ], 'salary_notification.log');

    return [
        'success'        => true,
        'message'        => "Salary notification sent to employee '$salary_data[staff_name]'",
        'message_id'     => $result['data']['message_id'] ?? '',
        'transaction_id' => $transaction_id
    ];
}


