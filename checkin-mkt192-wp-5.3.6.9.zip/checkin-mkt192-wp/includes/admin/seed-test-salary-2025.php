<?php
/**
 * Seed Test Salary Data for 2025 (All 12 Months)
 * 
 * Tạo dữ liệu test lương cho cả hairdresser và cashier
 * trong 12 tháng năm 2025 để test tính năng lương trung bình.
 * 
 * Sử dụng: Admin menu → Gọi qua AJAX hoặc WP-CLI
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Seed salary data cho 12 tháng 2025
 */
function checkin_mkt192_seed_test_salary_2025() {
    global $wpdb;

    $year = 2025;
    $months = ['01','02','03','04','05','06','07','08','09','10','11','12'];

    // Lấy danh sách thợ
    $hairdressers = $wpdb->get_results(
        "SELECT display_name, branch_id FROM {$wpdb->prefix}checkin_mkt192_staff 
         WHERE user_role LIKE '%Thợ%' AND status != 'DELETED'",
        ARRAY_A
    );

    // Lấy danh sách thu ngân
    $cashiers = $wpdb->get_results(
        "SELECT display_name, branch_id FROM {$wpdb->prefix}checkin_mkt192_staff 
         WHERE user_role LIKE '%Thu Ngân%' AND status != 'DELETED'",
        ARRAY_A
    );

    $inserted_hairdresser = 0;
    $inserted_cashier     = 0;
    $skipped              = 0;

    // === Seed data cho Hairdresser ===
    foreach ($hairdressers as $staff) {
        // Lấy level hiện tại
        $level = $wpdb->get_row($wpdb->prepare(
            "SELECT level_name, start_time FROM {$wpdb->prefix}checkin_mkt192_staff_level_history 
             WHERE staff_name = %s ORDER BY start_time DESC LIMIT 1",
            $staff['display_name']
        ));

        $level_name       = $level ? $level->level_name : 'C40_30';
        $level_start_date = $level ? date('Y-m-d', strtotime($level->start_time)) : '2024-06-01';

        foreach ($months as $month) {
            $period = "{$year}-{$month}";

            // Kiểm tra đã tồn tại chưa
            $exists = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}checkin_mkt192_hairdresser_salary 
                 WHERE staff_name = %s AND period = %s",
                $staff['display_name'], $period
            ));

            if ($exists > 0) {
                $skipped++;
                continue;
            }

            // Sinh giá trị ngẫu nhiên hợp lý
            $service_total    = rand(8000000, 25000000);
            $penalty_service  = rand(0, intval($service_total * 0.05));
            $chemical_total   = rand(3000000, 12000000);
            $penalty_chemical = rand(0, intval($chemical_total * 0.05));
            $product_total    = rand(500000, 5000000);
            $product_count    = rand(1, 15);
            $overtime_total   = rand(0, 3000000);
            $working_days     = rand(20, 28) + (rand(0, 1) * 0.5);

            // Tính lương dựa trên commission rates (mặc định C40_30)
            $service_salary  = intval(($service_total - $penalty_service) * 0.40);
            $chemical_salary = intval(($chemical_total - $penalty_chemical) * 0.30);
            $product_salary  = intval($product_total * 0.10);
            $overtime_salary = intval($overtime_total * 0.10);
            $total_salary    = $service_salary + $chemical_salary + $product_salary + $overtime_salary;

            $advance_salary      = rand(0, 2) * 500000; // 0, 500k, hoặc 1M
            $uniform_fee         = (rand(0, 3) == 0) ? 200000 : 0;
            $penalty_percent     = (rand(0, 5) == 0) ? rand(1, 5) : 0;
            $total_of_deductions = $advance_salary + $uniform_fee + intval($total_salary * ($penalty_percent / 100));
            $actual_salary       = max(0, $total_salary - $total_of_deductions);

            $wpdb->insert(
                "{$wpdb->prefix}checkin_mkt192_hairdresser_salary",
                [
                    'staff_name'          => $staff['display_name'],
                    'period'              => $period,
                    'level_name'          => $level_name,
                    'level_start_date'    => $level_start_date,
                    'service_total'       => $service_total,
                    'penalty_service'     => $penalty_service,
                    'chemical_total'      => $chemical_total,
                    'penalty_chemical'    => $penalty_chemical,
                    'product_total'       => $product_total,
                    'product_count_total' => $product_count,
                    'overtime_total'      => $overtime_total,
                    'service_salary'      => $service_salary,
                    'chemical_salary'     => $chemical_salary,
                    'product_salary'      => $product_salary,
                    'overtime_salary'     => $overtime_salary,
                    'total_salary'        => $total_salary,
                    'advance_salary'      => $advance_salary,
                    'uniform_fee'         => $uniform_fee,
                    'penalty_note'        => $penalty_percent > 0 ? 'Vi phạm nội quy' : null,
                    'penalty_percent'     => $penalty_percent,
                    'total_of_deductions' => $total_of_deductions,
                    'actual_salary'       => $actual_salary,
                    'working_days'        => $working_days,
                    'branch_id'           => intval($staff['branch_id'] ?? 0),
                    'created_at'          => "{$year}-{$month}-28 10:00:00",
                    'updated_at'          => "{$year}-{$month}-28 10:00:00",
                ]
            );

            $inserted_hairdresser++;
        }
    }

    // === Seed data cho Cashier ===
    foreach ($cashiers as $staff) {
        // Lấy level hiện tại
        $level = $wpdb->get_row($wpdb->prepare(
            "SELECT slh.level_name, slh.start_time, sls.hourly_salary
             FROM {$wpdb->prefix}checkin_mkt192_staff_level_history slh
             LEFT JOIN {$wpdb->prefix}checkin_mkt192_salary_level_settings sls 
                 ON slh.level_name = sls.level_name
             WHERE slh.staff_name = %s 
             ORDER BY slh.start_time DESC LIMIT 1",
            $staff['display_name']
        ));

        $level_name       = $level ? $level->level_name : 'TN-Bậc 1';
        $level_start_date = $level ? date('Y-m-d', strtotime($level->start_time)) : '2024-06-01';
        $hourly_salary    = $level ? floatval($level->hourly_salary) : 25000;

        foreach ($months as $month) {
            $period = "{$year}-{$month}";

            // Kiểm tra đã tồn tại chưa
            $exists = $wpdb->get_var($wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->prefix}checkin_mkt192_cashier_salary 
                 WHERE staff_name = %s AND period = %s",
                $staff['display_name'], $period
            ));

            if ($exists > 0) {
                $skipped++;
                continue;
            }

            $total_hours    = rand(160, 220) + rand(0, 99) / 100;
            $standard_hours = $total_hours - rand(0, 10);
            $probation_hours = 0;
            $official_hours  = $total_hours;

            $total_salary    = intval($total_hours * $hourly_salary);
            $product_total   = rand(200000, 3000000);
            $product_count   = rand(0, 10);
            $product_salary  = $product_count >= 1 ? intval($product_total * 0.10) : 0;
            $total_salary   += $product_salary;

            $advance_salary      = rand(0, 2) * 500000;
            $uniform_fee         = (rand(0, 3) == 0) ? 200000 : 0;
            $total_of_deductions = $advance_salary + $uniform_fee;
            $actual_salary       = max(0, $total_salary - $total_of_deductions);

            $wpdb->insert(
                "{$wpdb->prefix}checkin_mkt192_cashier_salary",
                [
                    'staff_name'              => $staff['display_name'],
                    'period'                  => $period,
                    'level_name'              => $level_name,
                    'level_start_date'        => $level_start_date,
                    'hourly_salary'           => $hourly_salary,
                    'total_hours'             => $total_hours,
                    'standard_hours'          => $standard_hours,
                    'probation_hours'         => $probation_hours,
                    'official_hours'          => $official_hours,
                    'probation_hourly_salary' => 0,
                    'official_hourly_salary'  => $hourly_salary,
                    'total_salary'            => $total_salary,
                    'advance_salary'          => $advance_salary,
                    'uniform_fee'             => $uniform_fee,
                    'total_of_deductions'     => $total_of_deductions,
                    'actual_salary'           => $actual_salary,
                    'product_total'           => $product_total,
                    'product_count_total'     => $product_count,
                    'product_salary'          => $product_salary,
                    'branch_id'              => intval($staff['branch_id'] ?? 0),
                    'created_at'              => "{$year}-{$month}-28 10:00:00",
                    'updated_at'              => "{$year}-{$month}-28 10:00:00",
                ]
            );

            $inserted_cashier++;
        }
    }

    return [
        'success'              => true,
        'inserted_hairdresser' => $inserted_hairdresser,
        'inserted_cashier'     => $inserted_cashier,
        'skipped'              => $skipped,
        'message'              => "Đã tạo {$inserted_hairdresser} record thợ, {$inserted_cashier} record thu ngân (bỏ qua {$skipped} record đã tồn tại)"
    ];
}

// Đăng ký admin AJAX action
add_action('wp_ajax_checkin_mkt192_seed_test_salary', function() {
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Unauthorized');
    }

    $result = checkin_mkt192_seed_test_salary_2025();
    wp_send_json($result);
});
