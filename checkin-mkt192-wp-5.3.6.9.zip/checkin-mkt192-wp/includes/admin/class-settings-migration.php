<?php

/**
 * Settings Migration Script
 *
 * Chuyển đổi cài đặt cũ sang cấu trúc mới
 *
 * @package    Checkin_MKT192_WP
 * @subpackage Includes/Admin
 * @since      5.1.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Checkin_MKT192_WP_Settings_Migration
 *
 * Xử lý việc migrate settings từ version cũ sang version mới
 */
class Checkin_MKT192_WP_Settings_Migration {

    /**
     * Migration version
     */
    const MIGRATION_VERSION = '5.1.0';

    /**
     * Singleton instance
     */
    private static $instance = null;

    /**
     * Get singleton instance
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct() {
        // Run migration on admin_init if needed
        add_action( 'admin_init', [ $this, 'maybe_run_migration' ] );
    }

    /**
     * Check if migration is needed and run it
     */
    public function maybe_run_migration() {
        $migration_completed = get_option( 'checkin_mkt192_migration_version', '0' );

        // Check if migration is needed
        if ( version_compare( $migration_completed, self::MIGRATION_VERSION, '<' ) ) {
            $this->run_migration();
        }
    }

    /**
     * Run the full migration process
     */
    public function run_migration() {
        // Prevent multiple simultaneous migrations
        if ( get_transient( 'checkin_mkt192_migration_running' ) ) {
            return;
        }

        set_transient( 'checkin_mkt192_migration_running', true, 300 ); // 5 minutes lock

        try {
            // Migrate brand settings
            $this->migrate_brand_settings();

            // Migrate connection settings
            $this->migrate_connection_settings();

            // Migrate payment settings
            $this->migrate_payment_settings();

            // Mark migration as completed
            update_option( 'checkin_mkt192_migration_version', self::MIGRATION_VERSION );
            update_option( 'checkin_mkt192_migration_date', current_time( 'mysql' ) );

            // Log success
            $this->log_migration( 'success', 'Migration completed successfully' );

        } catch ( Exception $e ) {
            // Log error
            $this->log_migration( 'error', $e->getMessage() );
        }

        delete_transient( 'checkin_mkt192_migration_running' );
    }

    /**
     * Migrate brand settings
     */
    private function migrate_brand_settings() {
        // Get existing brand settings (adjust option names as needed)
        $old_settings = get_option( 'checkin_mkt192_settings', [] );

        $new_settings = [];

        // Migrate logo
        if ( isset( $old_settings['brand_logo'] ) ) {
            $new_settings['brand_logo'] = $old_settings['brand_logo'];
        }

        // Migrate primary color
        if ( isset( $old_settings['primary_color'] ) ) {
            $new_settings['primary_color'] = $old_settings['primary_color'];
        }

        // Migrate secondary color
        if ( isset( $old_settings['secondary_color'] ) ) {
            $new_settings['secondary_color'] = $old_settings['secondary_color'];
        }

        // Migrate company info
        if ( isset( $old_settings['company_name'] ) ) {
            $new_settings['company_name'] = $old_settings['company_name'];
        }

        if ( isset( $old_settings['company_email'] ) ) {
            $new_settings['company_email'] = $old_settings['company_email'];
        }

        if ( isset( $old_settings['company_phone'] ) ) {
            $new_settings['company_phone'] = $old_settings['company_phone'];
        }

        if ( isset( $old_settings['company_address'] ) ) {
            $new_settings['company_address'] = $old_settings['company_address'];
        }

        if ( isset( $old_settings['company_website'] ) ) {
            $new_settings['company_website'] = $old_settings['company_website'];
        }

        // Migrate social links
        if ( isset( $old_settings['facebook_url'] ) ) {
            $new_settings['facebook_url'] = $old_settings['facebook_url'];
        }

        if ( isset( $old_settings['zalo_url'] ) ) {
            $new_settings['zalo_url'] = $old_settings['zalo_url'];
        }

        if ( isset( $old_settings['youtube_url'] ) ) {
            $new_settings['youtube_url'] = $old_settings['youtube_url'];
        }

        if ( isset( $old_settings['instagram_url'] ) ) {
            $new_settings['instagram_url'] = $old_settings['instagram_url'];
        }

        // Save new settings
        if ( ! empty( $new_settings ) ) {
            update_option( 'checkin_mkt192_brand_settings', $new_settings );
            $this->log_migration( 'info', 'Brand settings migrated: ' . count( $new_settings ) . ' items' );
        }
    }

    /**
     * Migrate connection settings
     */
    private function migrate_connection_settings() {
        $old_settings = get_option( 'checkin_mkt192_settings', [] );

        $new_settings = [];

        // Migrate Zalo settings
        if ( isset( $old_settings['zalo_enabled'] ) ) {
            $new_settings['zalo_enabled'] = $old_settings['zalo_enabled'];
        }

        if ( isset( $old_settings['zalo_app_id'] ) ) {
            $new_settings['zalo_app_id'] = $old_settings['zalo_app_id'];
        }

        if ( isset( $old_settings['zalo_app_secret'] ) ) {
            $new_settings['zalo_app_secret'] = $old_settings['zalo_app_secret'];
        }

        // Migrate Lark settings
        if ( isset( $old_settings['lark_enabled'] ) ) {
            $new_settings['lark_enabled'] = $old_settings['lark_enabled'];
        }

        if ( isset( $old_settings['lark_app_id'] ) ) {
            $new_settings['lark_app_id'] = $old_settings['lark_app_id'];
        }

        if ( isset( $old_settings['lark_app_secret'] ) ) {
            $new_settings['lark_app_secret'] = $old_settings['lark_app_secret'];
        }

        // Migrate Google settings
        if ( isset( $old_settings['google_enabled'] ) ) {
            $new_settings['google_enabled'] = $old_settings['google_enabled'];
        }

        if ( isset( $old_settings['google_client_id'] ) ) {
            $new_settings['google_client_id'] = $old_settings['google_client_id'];
        }

        if ( isset( $old_settings['google_client_secret'] ) ) {
            $new_settings['google_client_secret'] = $old_settings['google_client_secret'];
        }

        // Migrate Facebook settings
        if ( isset( $old_settings['facebook_enabled'] ) ) {
            $new_settings['facebook_enabled'] = $old_settings['facebook_enabled'];
        }

        if ( isset( $old_settings['facebook_app_id'] ) ) {
            $new_settings['facebook_app_id'] = $old_settings['facebook_app_id'];
        }

        if ( isset( $old_settings['facebook_app_secret'] ) ) {
            $new_settings['facebook_app_secret'] = $old_settings['facebook_app_secret'];
        }

        // Save new settings
        if ( ! empty( $new_settings ) ) {
            update_option( 'checkin_mkt192_connections_settings', $new_settings );
            $this->log_migration( 'info', 'Connection settings migrated: ' . count( $new_settings ) . ' items' );
        }
    }

    /**
     * Migrate payment settings
     */
    private function migrate_payment_settings() {
        $old_settings = get_option( 'checkin_mkt192_settings', [] );

        $new_settings = [];

        // Migrate bank transfer settings
        if ( isset( $old_settings['bank_enabled'] ) ) {
            $new_settings['bank_enabled'] = $old_settings['bank_enabled'];
        }

        if ( isset( $old_settings['bank_name'] ) ) {
            $new_settings['bank_name'] = $old_settings['bank_name'];
        }

        if ( isset( $old_settings['bank_account_number'] ) ) {
            $new_settings['bank_account_number'] = $old_settings['bank_account_number'];
        }

        if ( isset( $old_settings['bank_account_name'] ) ) {
            $new_settings['bank_account_name'] = $old_settings['bank_account_name'];
        }

        // Migrate Momo settings
        if ( isset( $old_settings['momo_enabled'] ) ) {
            $new_settings['momo_enabled'] = $old_settings['momo_enabled'];
        }

        if ( isset( $old_settings['momo_partner_code'] ) ) {
            $new_settings['momo_partner_code'] = $old_settings['momo_partner_code'];
        }

        if ( isset( $old_settings['momo_access_key'] ) ) {
            $new_settings['momo_access_key'] = $old_settings['momo_access_key'];
        }

        if ( isset( $old_settings['momo_secret_key'] ) ) {
            $new_settings['momo_secret_key'] = $old_settings['momo_secret_key'];
        }

        // Migrate ZaloPay settings
        if ( isset( $old_settings['zalopay_enabled'] ) ) {
            $new_settings['zalopay_enabled'] = $old_settings['zalopay_enabled'];
        }

        if ( isset( $old_settings['zalopay_app_id'] ) ) {
            $new_settings['zalopay_app_id'] = $old_settings['zalopay_app_id'];
        }

        if ( isset( $old_settings['zalopay_key1'] ) ) {
            $new_settings['zalopay_key1'] = $old_settings['zalopay_key1'];
        }

        if ( isset( $old_settings['zalopay_key2'] ) ) {
            $new_settings['zalopay_key2'] = $old_settings['zalopay_key2'];
        }

        // Save new settings
        if ( ! empty( $new_settings ) ) {
            update_option( 'checkin_mkt192_payments_settings', $new_settings );
            $this->log_migration( 'info', 'Payment settings migrated: ' . count( $new_settings ) . ' items' );
        }
    }

    /**
     * Log migration activity
     */
    private function log_migration( $level, $message ) {
        $log_entry = [
            'timestamp' => current_time( 'mysql' ),
            'level'     => $level,
            'message'   => $message,
        ];

        $migration_log   = get_option( 'checkin_mkt192_migration_log', [] );
        $migration_log[] = $log_entry;

        // Keep only last 100 entries
        if ( count( $migration_log ) > 100 ) {
            $migration_log = array_slice( $migration_log, -100 );
        }

        update_option( 'checkin_mkt192_migration_log', $migration_log );

        // Also log to error_log for debugging
        if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
            error_log( sprintf( '[Checkin MKT192 Migration] [%s] %s', strtoupper( $level ), $message ) );
        }
    }

    /**
     * Get migration log
     */
    public static function get_migration_log() {
        return get_option( 'checkin_mkt192_migration_log', [] );
    }

    /**
     * Clear migration log
     */
    public static function clear_migration_log() {
        delete_option( 'checkin_mkt192_migration_log' );
    }

    /**
     * Force re-run migration (for debugging)
     */
    public static function force_migration() {
        delete_option( 'checkin_mkt192_migration_version' );
        delete_transient( 'checkin_mkt192_migration_running' );

        $instance = self::get_instance();
        $instance->run_migration();
    }

    /**
     * Rollback migration (restore old settings)
     */
    public static function rollback_migration() {
        // Delete new settings
        delete_option( 'checkin_mkt192_brand_settings' );
        delete_option( 'checkin_mkt192_connections_settings' );
        delete_option( 'checkin_mkt192_payments_settings' );
        delete_option( 'checkin_mkt192_platforms_settings' );

        // Reset migration version
        delete_option( 'checkin_mkt192_migration_version' );
        delete_option( 'checkin_mkt192_migration_date' );

        // Clear log
        self::clear_migration_log();
    }
}

// Migration system will be initialized by main plugin file when needed