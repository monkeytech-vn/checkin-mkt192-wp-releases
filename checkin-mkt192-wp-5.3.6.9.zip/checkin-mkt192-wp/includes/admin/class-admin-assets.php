<?php

/**
 * Admin Assets Loader
 *
 * Quản lý việc load CSS và JavaScript cho admin pages
 *
 * @package    Checkin_MKT192_WP
 * @subpackage Includes/Admin
 * @since      5.1.0
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Checkin_MKT192_WP_Admin_Assets
 *
 * Xử lý enqueue scripts và styles cho admin
 */
class Checkin_MKT192_WP_Admin_Assets {

    /**
     * Singleton instance
     */
    private static $instance = null;

    /**
     * Plugin version for cache busting
     */
    private $version;

    /**
     * Assets URL
     */
    private $assets_url;

    /**
     * Get singleton instance
     */
    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor
     */
    private function __construct() {
        $this->version    = defined( 'CHECKIN_MKT192_WP_VERSION' ) ? CHECKIN_MKT192_WP_VERSION : '5.1.0';
        $this->assets_url = plugin_dir_url( dirname( dirname( __FILE__ ) ) ) . 'admin/assets/';
        $this->assets_dir = plugin_dir_path( dirname( dirname( __FILE__ ) ) ) . 'admin' . DIRECTORY_SEPARATOR . 'assets' . DIRECTORY_SEPARATOR;

        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_styles' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_scripts' ] );
    }

    /**
     * Enqueue admin styles
     */
    public function enqueue_styles( $hook ) {
        // Only load on our plugin pages
        if ( ! $this->is_plugin_page( $hook ) ) {
            return;
        }

        // Admin Framework CSS
        wp_enqueue_style(
            'checkin-admin-framework',
            $this->assets_url . 'css/admin-framework.css',
            [],
            $this->asset_ver( 'css/admin-framework.css' )
        );

        // Components CSS
        wp_enqueue_style(
            'checkin-admin-components',
            $this->assets_url . 'css/components.css',
            [ 'checkin-admin-framework' ],
            $this->asset_ver( 'css/components.css' )
        );

        // Global Header CSS (for all admin pages)
        wp_enqueue_style(
            'checkin-admin-global-header',
            $this->assets_url . 'css/global-header.css',
            [ 'checkin-admin-framework' ],
            $this->asset_ver( 'css/global-header.css' )
        );

        // Page-specific CSS
        wp_enqueue_style(
            'checkin-admin-pages',
            $this->assets_url . 'css/pages/pages.css',
            [ 'checkin-admin-framework', 'checkin-admin-components' ],
            $this->asset_ver( 'css/pages/pages.css' )
        );

        // Connections page specific CSS
        if ( isset( $_GET['page'] ) && $_GET['page'] === 'checkin-mkt192-connections' ) {
            wp_enqueue_style(
                'checkin-admin-connections',
                $this->assets_url . 'css/pages/connections.css',
                [ 'checkin-admin-framework', 'checkin-admin-components' ],
                $this->asset_ver( 'css/pages/connections.css' )
            );
        }

        // Brand Settings page specific CSS
        if ( isset( $_GET['page'] ) && $_GET['page'] === 'checkin-mkt192-brand-settings' ) {
            wp_enqueue_style(
                'checkin-admin-brand-settings',
                $this->assets_url . 'css/pages/brand-settings.css',
                [ 'checkin-admin-framework', 'checkin-admin-components' ],
                $this->asset_ver( 'css/pages/brand-settings.css' )
            );
        }

        // Payments page specific CSS
        if ( isset( $_GET['page'] ) && $_GET['page'] === 'checkin-mkt192-payments' ) {
            wp_enqueue_style(
                'checkin-admin-payments',
                $this->assets_url . 'css/pages/payments.css',
                [ 'checkin-admin-framework', 'checkin-admin-components' ],
                $this->asset_ver( 'css/pages/payments.css' )
            );
        }

        // Shortcodes page specific CSS
        if ( isset( $_GET['page'] ) && $_GET['page'] === 'checkin-mkt192-shortcodes' ) {
            wp_enqueue_style(
                'checkin-admin-shortcodes',
                $this->assets_url . 'css/pages/shortcodes.css',
                [ 'checkin-admin-framework', 'checkin-admin-components' ],
                $this->asset_ver( 'css/pages/shortcodes.css' )
            );
        }

        // Platforms page specific CSS
        if ( isset( $_GET['page'] ) && $_GET['page'] === 'checkin-mkt192-platforms' ) {
            wp_enqueue_style(
                'checkin-admin-platforms',
                $this->assets_url . 'css/pages/platforms.css',
                [ 'checkin-admin-framework', 'checkin-admin-components' ],
                $this->asset_ver( 'css/pages/platforms.css' )
            );
        }

        // Tools page specific CSS
        if ( isset( $_GET['page'] ) && $_GET['page'] === 'checkin-mkt192-tools' ) {
            wp_enqueue_style(
                'checkin-admin-tools',
                $this->assets_url . 'css/pages/tools.css',
                [ 'checkin-admin-framework', 'checkin-admin-components' ],
                $this->asset_ver( 'css/pages/tools.css' )
            );
        }

        // Push Notifications page specific CSS
        if ( isset( $_GET['page'] ) && $_GET['page'] === 'checkin-mkt192-push-notifications' ) {
            wp_enqueue_style(
                'checkin-admin-push-notifications',
                $this->assets_url . 'css/pages/push-notifications.css',
                [ 'checkin-admin-framework', 'checkin-admin-components' ],
                $this->asset_ver( 'css/pages/push-notifications.css' )
            );
        }

        // WordPress Color Picker
        wp_enqueue_style( 'wp-color-picker' );
    }

    /**
     * Enqueue admin scripts
     */
    public function enqueue_scripts( $hook ) {
        // Only load on our plugin pages
        if ( ! $this->is_plugin_page( $hook ) ) {
            return;
        }

        // WordPress Media Library
        wp_enqueue_media();

        // WordPress Color Picker
        wp_enqueue_script( 'wp-color-picker' );

        // jQuery (already included in WordPress)
        wp_enqueue_script( 'jquery' );

        // Common JS (shared utilities for all admin pages)
        wp_enqueue_script(
            'checkin-admin-common',
            $this->assets_url . 'js/common.js',
            [ 'jquery' ],
            $this->asset_ver( 'js/common.js' ),
            true
        );

        // Admin Framework JS
        wp_enqueue_script(
            'checkin-admin-framework',
            $this->assets_url . 'js/admin-framework.js',
            [ 'jquery', 'wp-color-picker', 'checkin-admin-common' ],
            $this->asset_ver( 'js/admin-framework.js' ),
            true
        );

        // Connections page specific JS
        if ( isset( $_GET['page'] ) && $_GET['page'] === 'checkin-mkt192-connections' ) {
            wp_enqueue_script(
                'checkin-admin-connections',
                $this->assets_url . 'js/connections.js',
                [ 'jquery', 'checkin-admin-common', 'checkin-admin-framework' ],
                $this->asset_ver( 'js/connections.js' ),
                true
            );
        }

        // Brand Settings page specific JS
        if ( isset( $_GET['page'] ) && $_GET['page'] === 'checkin-mkt192-brand-settings' ) {
            wp_enqueue_script(
                'checkin-admin-brand-settings',
                $this->assets_url . 'js/brand-settings.js',
                [ 'jquery', 'checkin-admin-common', 'checkin-admin-framework' ],
                $this->asset_ver( 'js/brand-settings.js' ),
                true
            );
        }

        // Payments page specific JS
        if ( isset( $_GET['page'] ) && $_GET['page'] === 'checkin-mkt192-payments' ) {
            wp_enqueue_script(
                'checkin-admin-payments',
                $this->assets_url . 'js/payments.js',
                [ 'jquery', 'checkin-admin-common', 'checkin-admin-framework' ],
                $this->asset_ver( 'js/payments.js' ),
                true
            );
        }

        // Shortcodes page specific JS
        if ( isset( $_GET['page'] ) && $_GET['page'] === 'checkin-mkt192-shortcodes' ) {
            wp_enqueue_script(
                'checkin-admin-shortcodes',
                $this->assets_url . 'js/shortcodes.js',
                [ 'jquery', 'checkin-admin-common' ],
                $this->asset_ver( 'js/shortcodes.js' ),
                true
            );
        }

        // Platforms page specific JS
        if ( isset( $_GET['page'] ) && $_GET['page'] === 'checkin-mkt192-platforms' ) {
            wp_enqueue_script(
                'checkin-admin-platforms',
                $this->assets_url . 'js/platforms.js',
                [ 'jquery', 'checkin-admin-common', 'checkin-admin-framework' ],
                $this->asset_ver( 'js/platforms.js' ),
                true
            );

            // Localize script for platforms page
            wp_localize_script(
                'checkin-admin-platforms',
                'checkinPlatformsAdmin',
                [
                    'ajaxurl' => admin_url( 'admin-ajax.php' ),
                    'nonce'   => wp_create_nonce( 'checkin-admin-nonce' ),
                ]
            );
        }

        // Tools page specific JS
        if ( isset( $_GET['page'] ) && $_GET['page'] === 'checkin-mkt192-tools' ) {
            wp_enqueue_script(
                'checkin-admin-tools',
                $this->assets_url . 'js/tools.js',
                [ 'jquery', 'checkin-admin-common', 'checkin-admin-framework' ],
                $this->asset_ver( 'js/tools.js' ),
                true
            );
        }

        // Push Notifications page specific JS
        if ( isset( $_GET['page'] ) && $_GET['page'] === 'checkin-mkt192-push-notifications' ) {
            wp_enqueue_script(
                'checkin-admin-push-notifications',
                $this->assets_url . 'js/pages/push-notifications.js',
                [ 'jquery', 'checkin-admin-common', 'checkin-admin-framework' ],
                $this->asset_ver( 'js/pages/push-notifications.js' ),
                true
            );
        }

        // Localize script with admin data
        wp_localize_script(
            'checkin-admin-framework',
            'checkinAdmin',
            [
                'ajaxurl'      => admin_url( 'admin-ajax.php' ),
                'adminUrl'     => admin_url(),
                'nonce'        => wp_create_nonce( 'checkin-admin-nonce' ),
                'restUrl'      => rest_url(),
                'restNonce'    => wp_create_nonce( 'wp_rest' ),
                'pluginUrl'    => plugin_dir_url( dirname( dirname( __FILE__ ) ) ),
                'currentPage'  => isset( $_GET['page'] ) ? sanitize_text_field( $_GET['page'] ) : '',
                'i18n'         => [
                    'saved'              => __( 'Đã lưu thành công!', 'checkin-mkt192-wp' ),
                    'error'              => __( 'Có lỗi xảy ra. Vui lòng thử lại.', 'checkin-mkt192-wp' ),
                    'loading'            => __( 'Đang tải...', 'checkin-mkt192-wp' ),
                    'confirm'            => __( 'Bạn có chắc chắn?', 'checkin-mkt192-wp' ),
                    'copied'             => __( 'Đã copy!', 'checkin-mkt192-wp' ),
                    'selectImage'        => __( 'Chọn hình ảnh', 'checkin-mkt192-wp' ),
                    'useImage'           => __( 'Sử dụng hình ảnh này', 'checkin-mkt192-wp' ),
                    'removeImage'        => __( 'Xoá hình ảnh', 'checkin-mkt192-wp' ),
                    'uploadImage'        => __( 'Tải lên hình ảnh', 'checkin-mkt192-wp' ),
                    'validationError'    => __( 'Vui lòng điền đầy đủ thông tin bắt buộc.', 'checkin-mkt192-wp' ),
                    'connectionSuccess'  => __( 'Kết nối thành công!', 'checkin-mkt192-wp' ),
                    'connectionFailed'   => __( 'Kết nối thất bại!', 'checkin-mkt192-wp' ),
                ],
            ]
        );

        // Page-specific scripts
        $this->enqueue_page_scripts( $hook );
    }

    /**
     * Enqueue page-specific scripts
     */
    private function enqueue_page_scripts( $hook ) {
        // Get current page
        $page = isset( $_GET['page'] ) ? sanitize_text_field( $_GET['page'] ) : '';

        // Dashboard page scripts
        if ( $page === 'checkin-mkt192-dashboard' ) {
            // Could load Chart.js or other dashboard-specific libraries here
            // wp_enqueue_script( 'chart-js', 'https://cdn.jsdelivr.net/npm/chart.js', array(), '3.9.1', true );
        }

        // Tools page scripts
        if ( $page === 'checkin-mkt192-tools' ) {
            wp_add_inline_script(
                'checkin-admin-framework',
                $this->get_tools_page_script()
            );
        }

        // License page scripts
        if ( $page === 'checkin-mkt192-license' ) {
            wp_add_inline_script(
                'checkin-admin-framework',
                $this->get_license_page_script()
            );
        }
    }

    /**
     * Get tools page inline script
     */
    private function get_tools_page_script() {
        // Tools page now uses tools.js - no inline script needed
        return '';
    }

    /**
     * Get license page inline script
     */
    private function get_license_page_script() {
        return "
        jQuery(document).ready(function($) {
            // License form validation
            $('#checkin-license-form').on('submit', function(e) {
                var licenseKey = $('#license_key').val().trim();

                if (licenseKey.length < 10) {
                    e.preventDefault();
                    CheckinAdmin.notifications.show('Vui lòng nhập license key hợp lệ.', 'error');
                    return false;
                }
            });
        });
        ";
    }

    /**
     * Check if current page is our plugin page
     */
    private function is_plugin_page( $hook ) {
        // Check if we're on a Checkin MKT192 admin page
        if ( isset( $_GET['page'] ) ) {
            $page = sanitize_text_field( $_GET['page'] );
            return strpos( $page, 'checkin-mkt192' ) === 0;
        }

        return false;
    }

    /**
     * Get asset URL
     */
    public function get_asset_url( $path = '' ) {
        return $this->assets_url . ltrim( $path, '/' );
    }

    /**
     * Get current plugin version
     */
    public function get_version() {
        return $this->version;
    }

    /**
     * Generate cache-busting version string for an admin asset.
     *
     * @param  string $relative_path Relative path from assets_dir (e.g. 'css/admin-framework.css').
     * @return string Version e.g. "5.1.0.1711187602".
     */
    private function asset_ver( $relative_path ) {
        $file = $this->assets_dir . str_replace( '/', DIRECTORY_SEPARATOR, $relative_path );
        $mtime = file_exists( $file ) ? filemtime( $file ) : 0;
        return $this->version . '.' . $mtime;
    }
}
