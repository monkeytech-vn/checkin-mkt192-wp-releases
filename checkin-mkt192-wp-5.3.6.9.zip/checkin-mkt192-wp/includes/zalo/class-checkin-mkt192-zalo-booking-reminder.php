<?php

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class xử lý gửi tin nhắn nhắc nhở lịch hẹn qua Zalo OA, ZBS hoặc webhook.
 */
class Checkin_MKT192_ZaloBookingReminder {
    /**
     * Ghi log vào file reminder_booking_log.log hoặc error_log.log.
     *
     * @param string $message Thông điệp log.
     * @param array  $data    Dữ liệu bổ sung (tùy chọn).
     * @param string $logFile Tên file log (mặc định: reminder_booking_log.log).
     */
    private static function write_log($message, $data = [], $logFile = 'reminder_booking_log.log') {
        $log_file = __DIR__ . '/logs/' . $logFile;
        if (!file_exists(dirname($log_file))) {
            if (!mkdir(dirname($log_file), 0755, true)) {
                $error_log_file = __DIR__ . '/logs/error_log.log';
                file_put_contents($error_log_file, date('Y-m-d H:i:s') . ' - Không thể tạo thư mục log: ' . dirname($log_file) . "\n", FILE_APPEND | LOCK_EX);
            }
        }
        $log_entry = date('Y-m-d H:i:s') . " - $message: " . json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
        if (!file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX)) {
            $error_log_file = __DIR__ . '/logs/error_log.log';
            file_put_contents($error_log_file, date('Y-m-d H:i:s') . " - Không thể ghi vào file log: $log_file\n", FILE_APPEND | LOCK_EX);
        }
    }

    /**
     * Kiểm tra và gửi tin nhắn nhắc nhở lịch hẹn.
     *
     * @return void
     */
    public static function check_and_send_booking_reminder() {
        global $wpdb;
        $booking_table = $wpdb->prefix . 'bookingmkt192_booking_data';

        self::write_log('Bắt đầu chạy check_and_send_booking_reminder');

        // Lấy thời gian hiện tại
        $currentTime      = current_time('mysql');
        $currentTimestamp = strtotime($currentTime);
        $startTime        = date('Y-m-d H:i', $currentTimestamp + 30 * 60);
        $endTime          = date('Y-m-d H:i', $currentTimestamp + 35 * 60);

        self::write_log("Kiểm tra lịch hẹn từ $startTime đến $endTime");

        // Lấy các lịch hẹn trong khoảng thời gian
        try {
            $bookings = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM $booking_table
                 WHERE DATE_FORMAT(CONCAT(booking_date, ' ', booking_time), %s) BETWEEN %s AND %s
                 AND (reminder_status IS NULL OR reminder_status != 'success')
                 AND status != 'deleted'",
                '%Y-%m-%d %H:%i',
                $startTime,
                $endTime
            ));

            self::write_log('Truy vấn SQL', ['query' => $wpdb->last_query]);
            if ($wpdb->last_error) {
                self::write_log('Lỗi database', ['error' => $wpdb->last_error]);
            }

            if (empty($bookings)) {
                self::write_log("Không có lịch hẹn nào cần gửi nhắc hẹn từ $startTime đến $endTime");
                return;
            }

            self::write_log('Tìm thấy ' . count($bookings) . ' lịch hẹn cần gửi nhắc hẹn', ['bookings' => array_map(function($b) { return $b->id_booking; }, $bookings)]);

            foreach ($bookings as $booking) {
                if (!isset($booking->id_booking) || !isset($booking->customer_name) || !isset($booking->customer_phone)) {
                    self::write_log('Lỗi: Dữ liệu booking không hợp lệ', ['booking' => (array)$booking]);
                    continue;
                }

                self::write_log("Gửi nhắc hẹn cho booking ID: {$booking->id_booking}");
                try {
                    $result = self::send_reminder_booking($booking);
                    self::write_log("Kết quả gửi nhắc hẹn cho booking ID: {$booking->id_booking}", [
                        'source'   => $result['source'],
                        'success'  => $result['success'],
                        'response' => $result['response']
                    ]);
                } catch (Exception $e) {
                    self::write_log("Lỗi khi gửi nhắc hẹn cho booking ID: {$booking->id_booking}", ['error' => $e->getMessage()]);
                }
            }
        } catch (Exception $e) {
            self::write_log('Lỗi khi lấy danh sách lịch hẹn', ['error' => $e->getMessage()]);
        }
    }

    /**
     * Gửi tin nhắn nhắc nhở lịch hẹn qua Zalo OA, ZBS hoặc webhook.
     *
     * @param object $booking Đối tượng chứa thông tin đặt lịch.
     * @return array Kết quả gửi tin nhắn.
     */
    public static function send_reminder_booking($booking) {
        global $wpdb;
        $booking_table   = $wpdb->prefix . 'bookingmkt192_booking_data';
        $customer_table  = $wpdb->prefix . 'bookingmkt192_customer_data';
        $config_table    = $wpdb->prefix . 'checkin_mkt192_zalo_config';
        $locations_table = $wpdb->prefix . 'checkin_mkt192_locations';
        $bookingId       = $booking->id_booking;

        // Lấy domain từ cài đặt
        $domain           = get_option('checkin_domain', '');
        $zalo_user_domain = get_option('checkin_zalo_user_domain', '');

        // Lấy branch_name từ branch_id hoặc branch (fallback)
        $branchName = '';
        if (!empty($booking->branch_id)) {
            $branchName = $wpdb->get_var($wpdb->prepare(
                "SELECT location_name FROM $locations_table WHERE id = %d",
                intval($booking->branch_id)
            ));
        }
        // Fallback: nếu không có branch_id, dùng cột branch (chứa tên cũ)
        if (empty($branchName) && !empty($booking->branch)) {
            $branchName = $booking->branch;
        }

        // Kiểm tra trạng thái tin nhắn
        if (isset($booking->reminder_status) && $booking->reminder_status === 'success') {
            self::write_log("$bookingId | Bỏ qua vì tin nhắn nhắc lịch đã gửi thành công trước đó", ['source' => $booking->reminder_message_type ?? 'unknown']);
            return [
                'success'        => true,
                'source'         => $booking->reminder_message_type ?? 'unknown',
                'message_type'   => $booking->reminder_message_type ?? 'unknown',
                'message_status' => 'success',
                'message'        => 'Tin nhắn nhắc lịch đã được gửi thành công trước đó.'
            ];
        }

        // Chuẩn hóa số điện thoại
        $cleanPhone = preg_replace('/\D/', '', $booking->customer_phone);
        if (preg_match('/^(84|0)/', $cleanPhone)) {
            $cleanPhone = preg_replace('/^(84|0)/', '', $cleanPhone);
        }
        $numberPhone = preg_replace('/\D/', '', $booking->customer_phone);
        $numberPhone = substr($numberPhone, 0, 1) === '0' ? '+84' . substr($numberPhone, 1) : (substr($numberPhone, 0, 3) !== '+84' ? '+84' . $numberPhone : $numberPhone);

        // Kiểm tra xem có sử dụng Zalo OA hay không
        $useZaloOA = get_option('checkin_use_zalo_oa', '0');

        // Kiểm tra chế độ đa chi nhánh
        $branchModeEnabled = get_option('checkin_branch_mode_enabled', '0') === '1';

        if ($useZaloOA === '1') {
            // Lấy access token
            $accessToken = $wpdb->get_var("SELECT access_token FROM $config_table ORDER BY updated_at DESC LIMIT 1");
            if (empty($accessToken)) {
                self::write_log("$bookingId | Lỗi: Access token không hợp lệ", ['table' => $config_table]);
                return [
                    'success'        => false,
                    'source'         => 'config',
                    'message_type'   => 'unknown',
                    'message_status' => 'failed',
                    'message'        => 'Access token không hợp lệ'
                ];
            }

            // Lấy user_id từ bảng khách hàng
            try {
                $customer = $wpdb->get_row($wpdb->prepare(
                    "SELECT id_zalo FROM $customer_table WHERE customer_phone = %s",
                    $cleanPhone
                ));
                if ($wpdb->last_error) {
                    self::write_log("$bookingId | Lỗi database khi truy vấn id_zalo", ['error' => $wpdb->last_error]);
                }
                $userIdZalo = $customer ? $customer->id_zalo : null;
            } catch (Exception $e) {
                self::write_log("$bookingId | Lỗi khi truy vấn id_zalo", ['error' => $e->getMessage()]);
                return [
                    'success'        => false,
                    'source'         => 'database',
                    'message_type'   => 'unknown',
                    'message_status' => 'failed',
                    'message'        => 'Lỗi khi truy vấn id_zalo: ' . $e->getMessage()
                ];
            }

            // Chuẩn bị template data chung cho ZBS (dùng cho cả UID và SĐT)
            $bookingTimeZBS = date('H:i d/m/Y', strtotime($booking->booking_date . ' ' . $booking->booking_time));
            $templateId     = get_option('checkin_zbs_template_booking_reminder', '375966');
            $templateData   = [
                'customer_name'    => substr($booking->customer_name, 0, 30),
                'phone_number'     => $numberPhone,
                'phone'            => $numberPhone,
                'booking_code'     => $booking->id_booking,
                'booking_time'     => $bookingTimeZBS,
                'service_name'     => substr($booking->service_name ?? '', 0, 200),
                'hairdresser_name' => substr($booking->hairdresser_name ?? '', 0, 200)
            ];

            // === BƯỚC 1: Thử gửi ZBS Template qua UID (nếu có id_zalo) ===
            if ($userIdZalo) {
                $zbsUidUrl     = 'https://openapi.zalo.me/v3.0/oa/message/template';
                $zbsUidPayload = [
                    'user_id'       => $userIdZalo,
                    'template_id'   => $templateId,
                    'template_data' => $templateData
                ];

                try {
                    $ch = curl_init($zbsUidUrl);
                    curl_setopt($ch, CURLOPT_HTTPHEADER, [
                        'Content-Type: application/json',
                        'access_token: ' . $accessToken
                    ]);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($zbsUidPayload, JSON_UNESCAPED_UNICODE));
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
                    $response  = curl_exec($ch);
                    $httpCode  = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                    $curlError = curl_error($ch);
                    curl_close($ch);

                    $responseData  = json_decode($response, true);
                    $isUidSuccess  = ($httpCode == 200 && (!isset($responseData['error']) || $responseData['error'] == 0));
                    $messageStatus = $isUidSuccess ? 'success' : (isset($responseData['message']) ? $responseData['message'] : ($curlError ?: 'Unknown error'));

                    $wpdb->update($booking_table, [
                        'reminder_message_type' => 'zbs_uid',
                        'reminder_status'       => $messageStatus
                    ], ['id_booking' => $bookingId]);
                    if ($wpdb->last_error) {
                        self::write_log("$bookingId | Lỗi database khi cập nhật trạng thái zbs_uid", ['error' => $wpdb->last_error]);
                    }

                    self::write_log("$bookingId | zbs_uid | HTTP $httpCode", [
                        'payload'    => $zbsUidPayload,
                        'response'   => $responseData,
                        'curl_error' => $curlError
                    ]);

                    if ($isUidSuccess) {
                        return [
                            'success'        => true,
                            'source'         => 'zbs_uid',
                            'message_type'   => 'zbs_uid',
                            'message_status' => 'success',
                            'response'       => $response
                        ];
                    }

                    // ZBS UID thất bại, tiếp tục fallback sang ZBS qua SĐT
                    self::write_log("$bookingId | ZBS UID thất bại, thử fallback gửi ZBS qua SĐT", [
                        'http_code'  => $httpCode,
                        'response'   => $responseData,
                        'curl_error' => $curlError
                    ]);
                } catch (Exception $e) {
                    self::write_log("$bookingId | zbs_uid | Lỗi khi gửi", ['error' => $e->getMessage()]);
                }
            } else {
                self::write_log("$bookingId | Không tìm thấy id_zalo, gửi ZBS qua SĐT", ['phone' => $cleanPhone]);
            }

            // === BƯỚC 2: Fallback gửi ZBS Template qua SĐT ===
            $zbsPhoneUrl     = 'https://business.openapi.zalo.me/message/template';
            $zbsPhonePayload = [
                'phone'         => $numberPhone,
                'template_id'   => $templateId,
                'template_data' => $templateData
            ];

            try {
                $chZns = curl_init($zbsPhoneUrl);
                curl_setopt($chZns, CURLOPT_HTTPHEADER, [
                    'Content-Type: application/json',
                    'access_token: ' . $accessToken
                ]);
                curl_setopt($chZns, CURLOPT_POSTFIELDS, json_encode($zbsPhonePayload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
                curl_setopt($chZns, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($chZns, CURLOPT_TIMEOUT, 10);
                $responseZns  = curl_exec($chZns);
                $httpCodeZns  = curl_getinfo($chZns, CURLINFO_HTTP_CODE);
                $curlErrorZns = curl_error($chZns);
                curl_close($chZns);

                $responseZnsData = json_decode($responseZns, true);
                $isZBSSuccess    = ($httpCodeZns == 200 && (!isset($responseZnsData['error']) || $responseZnsData['error'] == 0));
                $messageStatus   = $isZBSSuccess ? 'success' : (isset($responseZnsData['message']) ? $responseZnsData['message'] : ($curlErrorZns ?: 'Unknown error'));

                $wpdb->update($booking_table, [
                    'reminder_message_type' => 'zbs_phone',
                    'reminder_status'       => $messageStatus
                ], ['id_booking' => $bookingId]);
                if ($wpdb->last_error) {
                    self::write_log("$bookingId | Lỗi database khi cập nhật trạng thái zbs_phone", ['error' => $wpdb->last_error]);
                }

                self::write_log("$bookingId | zbs_phone | HTTP $httpCodeZns", [
                    'payload'    => $zbsPhonePayload,
                    'response'   => $responseZnsData,
                    'curl_error' => $curlErrorZns
                ]);

                return [
                    'success'        => $isZBSSuccess,
                    'source'         => 'zbs_phone',
                    'message_type'   => 'zbs_phone',
                    'message_status' => $messageStatus,
                    'response'       => $responseZns
                ];
            } catch (Exception $e) {
                self::write_log("$bookingId | zbs_phone | Lỗi khi gửi", ['error' => $e->getMessage()]);

                // Cập nhật status = failed vào DB
                $wpdb->update($booking_table, [
                    'reminder_message_type' => 'zbs_phone',
                    'reminder_status'       => 'failed'
                ], ['id_booking' => $bookingId]);

                return [
                    'success'        => false,
                    'source'         => 'zbs_phone',
                    'message_type'   => 'zbs_phone',
                    'message_status' => 'failed',
                    'message'        => 'Lỗi khi gửi ZBS: ' . $e->getMessage()
                ];
            }
        } else {
            // Gửi qua webhook nếu Zalo OA không được kích hoạt
            // Đọc toggle gửi khách / gửi group
            $sendCustomer = get_option('checkin_zalo_user_send_customer', '1') === '1';
            $sendGroup    = get_option('checkin_zalo_user_send_group', '1') === '1';

            // Kiểm tra zalo_user_domain có hợp lệ không
            if (empty($zalo_user_domain)) {
                self::write_log("$bookingId | webhook | Lỗi: zalo_user_domain không được cấu hình", [
                    'zalo_user_domain' => $zalo_user_domain,
                    'domain'           => $domain
                ]);
                return [
                    'success'        => false,
                    'source'         => 'webhook',
                    'message_type'   => 'webhook',
                    'message_status' => 'failed',
                    'message'        => 'Zalo User Domain chưa được cấu hình. Vui lòng cấu hình tại Settings > Zalo.'
                ];
            }

            $webhookBase    = rtrim($zalo_user_domain, '/') . '/webhook/';
            $webhookPayload = [
                'table_name'       => $booking_table,
                'booking_id'       => $booking->id_booking,
            'customer_phone'       => $numberPhone,
            'customer_name'        => substr($booking->customer_name, 0, 30),
            'booking_time'         => date('H:i d/m/Y', strtotime($booking->booking_date . ' ' . $booking->booking_time)),
            'branch_name'          => ($branchModeEnabled && !empty($branchName)) ? substr($branchName, 0, 100) : '',
            'service_name'         => substr($booking->service_name ?? '', 0, 200),
                'hairdresser_name' => substr($booking->hairdresser_name ?? '', 0, 200),
                'note'             => !empty($booking->note) ? substr($booking->note, 0, 200) : '',
                'checkin_url'      => "https://{$domain}/customer-member?booking_id=$cleanPhone",
                'reschedule_url'   => "https://{$domain}/customer-member?booking_id=$cleanPhone",
                'chat_admin_url'   => 'https://zalo.me/app/link/qd0z8uq1me',
                'voucher_url'      => "https://{$domain}/customer-member?customer_phone=$cleanPhone"
            ];

            $results = ['group' => null, 'customer' => null];

            // Helper: gửi webhook
            $sendWebhook = function($url, $payload) use ($bookingId) {
                $ch = curl_init($url);
                curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
                curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_TIMEOUT, 60);
                curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
                $response  = curl_exec($ch);
                $httpCode  = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                $curlError = curl_error($ch);
                curl_close($ch);

                $data    = json_decode($response, true);
                $success = false;
                $status  = 'failed';

                if ($httpCode == 200 && $data) {
                    if (isset($data['success'])) {
                        $success = $data['success'];
                        $status  = $success ? 'success' : ($data['message'] ?? 'Unknown error');
                    } else {
                        $success = (!isset($data['error']) || $data['error'] == 0);
                        $status  = $success ? 'success' : ($data['message'] ?? 'Unknown error');
                    }
                } else {
                    $status = $curlError ?: "HTTP $httpCode";
                }

                return ['success' => $success, 'status' => $status, 'http_code' => $httpCode, 'response' => $response, 'url' => $url];
            };

            // 1) Gửi Group webhook (nếu toggle bật)
            if ($sendGroup) {
                try {
                    $groupUrl = $webhookBase . 'n8n-send-reminder-group';
                    $results['group'] = $sendWebhook($groupUrl, $webhookPayload);
                    self::write_log("$bookingId | webhook-group | " . ($results['group']['success'] ? 'Thành công' : 'Thất bại'), $results['group']);
                } catch (Exception $e) {
                    self::write_log("$bookingId | webhook-group | Lỗi: " . $e->getMessage());
                    $results['group'] = ['success' => false, 'status' => $e->getMessage()];
                }
            }

            // 2) Gửi Customer webhook (nếu toggle bật — OA không bật nên luôn cho phép ở đây)
            if ($sendCustomer) {
                try {
                    $customerUrl = $webhookBase . 'n8n-send-reminder-customer';
                    $results['customer'] = $sendWebhook($customerUrl, $webhookPayload);
                    self::write_log("$bookingId | webhook-customer | " . ($results['customer']['success'] ? 'Thành công' : 'Thất bại'), $results['customer']);
                } catch (Exception $e) {
                    self::write_log("$bookingId | webhook-customer | Lỗi: " . $e->getMessage());
                    $results['customer'] = ['success' => false, 'status' => $e->getMessage()];
                }
            }

            // Determine overall status
            $anySuccess    = ($results['group'] && $results['group']['success']) || ($results['customer'] && $results['customer']['success']);
            $messageStatus = $anySuccess ? 'success' : 'failed';

            // Cập nhật reminder_message_type và reminder_status vào database
            $wpdb->update($booking_table, [
                'reminder_message_type' => 'webhook',
                'reminder_status'       => $messageStatus
            ], ['id_booking' => $bookingId]);
            if ($wpdb->last_error) {
                self::write_log("$bookingId | Lỗi database khi cập nhật trạng thái webhook", ['error' => $wpdb->last_error]);
            }

            return [
                'success'        => $anySuccess,
                'source'         => 'webhook',
                'message_type'   => 'webhook',
                'message_status' => $messageStatus,
                'details'        => $results
            ];
        }
    }
}
?>
