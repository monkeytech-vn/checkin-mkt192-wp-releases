<?php

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class xử lý gửi tin nhắn hóa đơn qua Zalo OA, ZBS hoặc webhook.
 */
class Checkin_MKT192_ZaloInvoiceMessage {
    /**
     * Ghi log vào file zalo_message_log.log.
     *
     * @param string $message Thông điệp log.
     * @param array  $data    Dữ liệu bổ sung (tùy chọn).
     */
    private static function write_log($message, $data = []) {
        $log_file = __DIR__ . '/logs/zalo_message_log.log';
        if (!file_exists(dirname($log_file))) {
            mkdir(dirname($log_file), 0755, true);
        }
        $log_entry = date('Y-m-d H:i:s') . " - $message: " . json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
        file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);
    }

    /**
     * Định dạng số tiền với dấu phân cách hàng nghìn.
     *
     * @param int $number Số tiền cần định dạng.
     * @return string Số tiền đã định dạng.
     */
    private static function format_number($number) {
        return number_format((int)$number, 0, '.', ',');
    }

    /**
     * Cắt chuỗi thông minh theo giới hạn ký tự, đảm bảo không cắt giữa chừng item.
     * Nếu chuỗi vượt quá giới hạn, cắt tại dấu phẩy gần nhất và thêm "...".
     *
     * @param string $text      Chuỗi cần cắt (các item phân cách bằng dấu phẩy).
     * @param int    $maxLength Số ký tự tối đa cho phép.
     * @return string Chuỗi đã được cắt.
     */
    private static function truncate_smart($text, $maxLength) {
        if (mb_strlen($text, 'UTF-8') <= $maxLength) {
            return $text;
        }

        // Trừ 3 ký tự cho "..."
        $availableLength = $maxLength - 3;

        // Cắt chuỗi tại vị trí giới hạn
        $truncated = mb_substr($text, 0, $availableLength, 'UTF-8');

        // Tìm vị trí dấu phẩy cuối cùng để không cắt giữa chừng tên dịch vụ
        $lastComma = mb_strrpos($truncated, ',', 0, 'UTF-8');

        if ($lastComma !== false && $lastComma > 0) {
            // Cắt tại dấu phẩy cuối cùng
            $truncated = mb_substr($truncated, 0, $lastComma, 'UTF-8');
        }

        return trim($truncated) . '...';
    }

    /**
     * Gửi tin nhắn hóa đơn qua Zalo OA, ZBS hoặc webhook.
     *
     * @param object $invoice Đối tượng chứa thông tin hóa đơn.
     * @return array Kết quả gửi tin nhắn.
     */
    public static function send_invoice_message($invoice) {
        global $wpdb;
        $invoiceId       = $invoice->invoice_id;
        $customer_table  = $wpdb->prefix . 'bookingmkt192_customer_data';
        $invoice_table   = $wpdb->prefix . 'checkin_mkt192_invoices_data';
        $config_table    = $wpdb->prefix . 'checkin_mkt192_zalo_config';
        $locations_table = $wpdb->prefix . 'checkin_mkt192_locations';

        // Lấy domain từ cài đặt
        $domain           = get_option('checkin_domain', '');
        $zalo_user_domain = get_option('checkin_zalo_user_domain', '');

        // Kiểm tra trạng thái tin nhắn
        if ($invoice->message_status === 'success') {
            self::write_log("$invoiceId | Bỏ qua vì tin nhắn đã gửi thành công trước đó", ['source' => $invoice->message_type]);
            return [
                'success'        => true,
                'source'         => $invoice->message_type,
                'message_type'   => $invoice->message_type,
                'message_status' => 'success',
                'message'        => 'Tin nhắn đã được gửi thành công trước đó.'
            ];
        }

        // Chuẩn hóa số điện thoại
        $cleanPhone = preg_replace('/\D/', '', $invoice->customer_phone);
        if (preg_match('/^(84|0)/', $cleanPhone)) {
            $cleanPhone = preg_replace('/^(84|0)/', '', $cleanPhone);
        }
        $numberPhone = preg_replace('/\D/', '', $invoice->customer_phone);
        $numberPhone = substr($numberPhone, 0, 1) === '0' ? '+84' . substr($numberPhone, 1) : (substr($numberPhone, 0, 3) !== '+84' ? '+84' . $numberPhone : $numberPhone);

        // Lấy user_id từ bảng khách hàng
        try {
            $customer = $wpdb->get_row($wpdb->prepare(
                "SELECT id_zalo FROM $customer_table WHERE customer_phone = %s",
                $cleanPhone
            ));
            $userIdZalo = $customer ? $customer->id_zalo : null;
        } catch (Exception $e) {
            self::write_log("$invoiceId | Lỗi khi lấy dữ liệu khách hàng", ['error' => $e->getMessage()]);
            return [
                'success'        => false,
                'source'         => 'database',
                'message_type'   => 'unknown',
                'message_status' => 'failed',
                'message'        => 'Lỗi khi lấy dữ liệu khách hàng: ' . $e->getMessage()
            ];
        }

        // Xử lý danh sách dịch vụ và nhân viên
        $servicesArray = json_decode($invoice->services, true);
        $serviceNames  = [];
        $staffNames    = [];
        if (!empty($servicesArray)) {
            foreach ($servicesArray as $service) {
                $serviceNames[] = html_entity_decode($service['service_name'], ENT_QUOTES, 'UTF-8');
                $staffNames[]   = html_entity_decode($service['staff_name'], ENT_QUOTES, 'UTF-8');
            }
        }
        $serviceNamesText = implode(', ', $serviceNames);
        $staffNamesText   = implode(', ', array_unique($staffNames));

        // Kiểm tra xem có sử dụng Zalo OA hay không
        $useZaloOA = get_option('checkin_use_zalo_oa', '0');

        // Kiểm tra chế độ đa chi nhánh và lấy tên chi nhánh
        $branchModeEnabled = get_option('checkin_branch_mode_enabled', '0') === '1';
        $branchName        = '';

        if ($branchModeEnabled && !empty($invoice->branch_id)) {
            // Lấy location_name từ bảng locations dựa trên branch_id
            $branchName = $wpdb->get_var($wpdb->prepare(
                "SELECT location_name FROM $locations_table WHERE id = %d",
                $invoice->branch_id
            ));
        }

        if ($useZaloOA === '1') {
            // Lấy access token
            $accessToken = $wpdb->get_var("SELECT access_token FROM $config_table ORDER BY updated_at DESC LIMIT 1");
            if (empty($accessToken)) {
                self::write_log("$invoiceId | Lỗi: Access token không hợp lệ", ['table' => $config_table]);
                return [
                    'success'        => false,
                    'source'         => 'config',
                    'message_type'   => 'unknown',
                    'message_status' => 'failed',
                    'message'        => 'Access token không hợp lệ'
                ];
            }

            // Chuẩn bị template data chung cho ZBS (dùng cho cả UID và SĐT)
            $orderDate    = date('H:i:s d/m/Y', strtotime($invoice->created_at));
            $templateId   = get_option('checkin_zbs_template_invoice', '518927');
            $templateData = [
                'customer_name'    => substr($invoice->customer_name, 0, 30),
                'customer_id'      => substr($cleanPhone, 0, 20),
                'order_date'       => $orderDate,
                'order_code'       => substr($invoice->invoice_id, 0, 30),
                'invoice_id'       => substr($invoice->invoice_id, 0, 30),
                'service_name'     => self::truncate_smart($serviceNamesText, 200),
                'hairdresser_name' => self::truncate_smart($staffNamesText, 30),
            ];

            // === BƯỚC 1: Thử gửi ZBS Template qua UID (nếu có id_zalo) ===
            if ($userIdZalo) {
                $zbsUidUrl     = 'https://openapi.zalo.me/v3.0/oa/message/template';
                $zbsUidPayload = [
                    'user_id'       => $userIdZalo,
                    'template_id'   => $templateId,
                    'template_data' => $templateData
                ];

                try {
                    $ch = curl_init($zbsUidUrl);
                    curl_setopt($ch, CURLOPT_HTTPHEADER, [
                        'Content-Type: application/json',
                        'access_token: ' . $accessToken
                    ]);
                    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($zbsUidPayload, JSON_UNESCAPED_UNICODE));
                    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
                    $response  = curl_exec($ch);
                    $httpCode  = curl_getinfo($ch, CURLINFO_HTTP_CODE);
                    $curlError = curl_error($ch);
                    curl_close($ch);

                    $responseData  = json_decode($response, true);
                    $isUidSuccess  = ($httpCode == 200 && (!isset($responseData['error']) || $responseData['error'] == 0));
                    $messageStatus = $isUidSuccess ? 'success' : (isset($responseData['message']) ? $responseData['message'] : ($curlError ?: 'Unknown error'));

                    $wpdb->update($invoice_table, [
                        'message_type'   => 'zbs_uid',
                        'message_status' => $messageStatus
                    ], ['invoice_id' => $invoiceId]);

                    self::write_log("$invoiceId | zbs_uid | HTTP $httpCode", [
                        'payload'    => $zbsUidPayload,
                        'response'   => $responseData,
                        'curl_error' => $curlError
                    ]);

                    if ($isUidSuccess) {
                        return [
                            'success'        => true,
                            'source'         => 'zbs_uid',
                            'message_type'   => 'zbs_uid',
                            'message_status' => 'success',
                            'response'       => $response
                        ];
                    }

                    // ZBS UID thất bại, tiếp tục fallback sang ZBS qua SĐT
                    self::write_log("$invoiceId | ZBS UID thất bại, thử fallback gửi ZBS qua SĐT", [
                        'http_code'  => $httpCode,
                        'response'   => $responseData,
                        'curl_error' => $curlError
                    ]);
                } catch (Exception $e) {
                    self::write_log("$invoiceId | zbs_uid | Lỗi khi gửi", ['error' => $e->getMessage()]);
                }
            }

            // === BƯỚC 2: Fallback gửi ZBS Template qua SĐT ===
            $zbsPhoneUrl     = 'https://business.openapi.zalo.me/message/template';
            $zbsPhonePayload = [
                'template_id'   => $templateId,
                'phone'         => $numberPhone,
                'template_data' => $templateData,
                'tracking_id'   => (string)$invoice->invoice_id
            ];

            try {
                $chZns = curl_init($zbsPhoneUrl);
                curl_setopt($chZns, CURLOPT_HTTPHEADER, [
                    'Content-Type: application/json',
                    'access_token: ' . $accessToken
                ]);
                curl_setopt($chZns, CURLOPT_POSTFIELDS, json_encode($zbsPhonePayload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
                curl_setopt($chZns, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($chZns, CURLOPT_TIMEOUT, 10);
                $responseZns  = curl_exec($chZns);
                $httpCodeZns  = curl_getinfo($chZns, CURLINFO_HTTP_CODE);
                $curlErrorZns = curl_error($chZns);
                curl_close($chZns);

                $responseZnsData = json_decode($responseZns, true);
                $isZBSSuccess    = ($httpCodeZns == 200 && (!isset($responseZnsData['error']) || $responseZnsData['error'] == 0));
                $messageStatus   = $isZBSSuccess ? 'success' : (isset($responseZnsData['message']) ? $responseZnsData['message'] : ($curlErrorZns ?: 'Unknown error'));

                $wpdb->update($invoice_table, [
                    'message_type'   => 'zbs_phone',
                    'message_status' => $messageStatus
                ], ['invoice_id' => $invoiceId]);

                self::write_log("$invoiceId | zbs_phone | HTTP $httpCodeZns", [
                    'payload'    => $zbsPhonePayload,
                    'response'   => $responseZnsData,
                    'curl_error' => $curlErrorZns
                ]);

                return [
                    'success'        => $isZBSSuccess,
                    'source'         => 'zbs_phone',
                    'message_type'   => 'zbs_phone',
                    'message_status' => $messageStatus,
                    'response'       => $responseZns
                ];
            } catch (Exception $e) {
                self::write_log("$invoiceId | zbs_phone | Lỗi khi gửi", ['error' => $e->getMessage()]);

                // Cập nhật status = failed vào DB
                $wpdb->update($invoice_table, [
                    'message_type'   => 'zbs_phone',
                    'message_status' => 'failed'
                ], ['invoice_id' => $invoiceId]);

                return [
                    'success'        => false,
                    'source'         => 'zbs_phone',
                    'message_type'   => 'zbs_phone',
                    'message_status' => 'failed',
                    'message'        => 'Lỗi khi gửi ZBS: ' . $e->getMessage()
                ];
            }
        } else {
            // Gửi qua webhook nếu không sử dụng Zalo OA

            // Kiểm tra zalo_user_domain có hợp lệ không
            if (empty($zalo_user_domain)) {
                self::write_log("$invoiceId | webhook | Lỗi: zalo_user_domain không được cấu hình", [
                    'zalo_user_domain' => $zalo_user_domain,
                    'domain'           => $domain
                ]);
                return [
                    'success'        => false,
                    'source'         => 'webhook',
                    'message_type'   => 'webhook',
                    'message_status' => 'failed',
                    'message'        => 'Zalo User Domain chưa được cấu hình. Vui lòng cấu hình tại Settings > Zalo.'
                ];
            }

            $webhookUrl     = rtrim($zalo_user_domain, '/') . '/webhook/n8n-send-message-invoice';
            $webhookPayload = [
                'table_name'       => $invoice_table,
                'invoice_id'       => $invoice->invoice_id,
                'customer_phone'   => $numberPhone,
                'customer_name'    => substr($invoice->customer_name, 0, 30),
                'order_date'       => date('H:i:s d/m/Y', strtotime($invoice->created_at)),
                'services'         => $serviceNamesText,
                'staff_names'      => $staffNamesText,
                'review_url'       => "https://{$domain}/customer-review-online/?invoice_id=" . urlencode($invoice->invoice_id),
                'booking_url'      => "https://{$domain}",
                'voucher_url'      => "https://{$domain}/customer-member?customer_phone=$cleanPhone"
            ];

            try {
                $chWebhook = curl_init($webhookUrl);
                curl_setopt($chWebhook, CURLOPT_HTTPHEADER, [
                    'Content-Type: application/json'
                ]);
                curl_setopt($chWebhook, CURLOPT_POSTFIELDS, json_encode($webhookPayload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
                curl_setopt($chWebhook, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($chWebhook, CURLOPT_TIMEOUT, 60); // 🔄 Tăng timeout lên 60s để đợi n8n gửi Zalo xong
                curl_setopt($chWebhook, CURLOPT_CONNECTTIMEOUT, 10); // Connection timeout riêng
                $responseWebhook  = curl_exec($chWebhook);
                $httpCodeWebhook  = curl_getinfo($chWebhook, CURLINFO_HTTP_CODE);
                $curlErrorWebhook = curl_error($chWebhook);
                curl_close($chWebhook);

                $responseWebhookData = json_decode($responseWebhook, true);

                // 🔄 Parse response từ n8n để xác định success
                // n8n nên trả về: {"success": true/false, "message": "...", "zalo_response": {...}}
                $isWebhookSuccess = false;
                $messageStatus    = 'failed';

                if ($httpCodeWebhook == 200 && $responseWebhookData) {
                    if (isset($responseWebhookData['success'])) {
                        $isWebhookSuccess = $responseWebhookData['success'];
                        $messageStatus    = $isWebhookSuccess ? 'success' : ($responseWebhookData['message'] ?? 'Unknown error');
                    } else {
                        // Fallback: Kiểm tra error code (legacy)
                        $isWebhookSuccess = (!isset($responseWebhookData['error']) || $responseWebhookData['error'] == 0);
                        $messageStatus    = $isWebhookSuccess ? 'success' : ($responseWebhookData['message'] ?? 'Unknown error');
                    }
                } else {
                    $messageStatus = $curlErrorWebhook ?: "HTTP $httpCodeWebhook";
                }

                // Log chi tiết kết quả gửi webhook
                $logData = [
                    'webhook_url'      => $webhookUrl,
                    'http_code'        => $httpCodeWebhook,
                    'curl_error'       => $curlErrorWebhook,
                    'response_body'    => $responseWebhook,
                    'response_data'    => $responseWebhookData,
                    'success'          => $isWebhookSuccess,
                    'message_status'   => $messageStatus
                ];

                if ($isWebhookSuccess) {
                    self::write_log("$invoiceId | webhook | Gửi thành công | HTTP $httpCodeWebhook", $logData);
                } else {
                    self::write_log("$invoiceId | webhook | Gửi thất bại | HTTP $httpCodeWebhook", $logData);
                }

                // 🔄 Cập nhật message_type và message_status vào database (Backend tự quản lý)

                $wpdb->update($invoice_table, [
                    'message_type'   => 'webhook',
                    'message_status' => $messageStatus
                ], ['invoice_id' => $invoiceId]);

                return [
                    'success'        => $isWebhookSuccess,
                    'source'         => 'webhook',
                    'message_type'   => 'webhook',
                    'message_status' => $messageStatus,
                    'response'       => $responseWebhook
                ];
            } catch (Exception $e) {
                self::write_log("$invoiceId | webhook | Lỗi khi gửi", [
                    'webhook_url' => $webhookUrl,
                    'error'       => $e->getMessage()
                ]);

                // Cập nhật status = failed vào DB
                $wpdb->update($invoice_table, [
                    'message_type'   => 'webhook',
                    'message_status' => 'failed'
                ], ['invoice_id' => $invoiceId]);

                return [
                    'success'        => false,
                    'source'         => 'webhook',
                    'message_type'   => 'webhook',
                    'message_status' => 'failed',
                    'message'        => 'Lỗi khi gửi webhook: ' . $e->getMessage()
                ];
            }
        }
    }
}
?>