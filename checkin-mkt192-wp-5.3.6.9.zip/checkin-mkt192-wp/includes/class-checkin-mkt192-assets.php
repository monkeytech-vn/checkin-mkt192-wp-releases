<?php

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class xử lý tải tài nguyên (CSS, JS) và cấu hình localize cho frontend.
 */
class Checkin_MKT192_Assets {
    /**
     * Lấy dữ liệu người dùng hiện tại.
     *
     * @return array Dữ liệu người dùng.
     */
    private static function get_current_user_data() {
        $current_user = wp_get_current_user();
        $branch_id    = get_user_meta($current_user->ID, 'branch_id', true);
        return [
            'id'           => $current_user->ID,
            'display_name' => $current_user->display_name ? $current_user->display_name : 'Unknown',
            'user_role'    => !empty($current_user->roles) ? $current_user->roles[0] : 'guest',
            'is_logged_in' => is_user_logged_in(),
            'user_login'   => $current_user->user_login,
            'branch_id'    => $branch_id ? intval($branch_id) : 0
        ];
    }

    /**
     * Lấy permissions của user hiện tại dựa trên role.
     *
     * @return array Mảng permissions.
     */
    private static function get_current_user_permissions() {
        if (!is_user_logged_in()) {
            return [];
        }

        $current_user = wp_get_current_user();
        $role         = checkin_mkt192_get_current_staff_role();

        if (!$role) {
            return [];
        }

        global $wpdb;
        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT permissions FROM {$wpdb->prefix}checkin_mkt192_staff_roles WHERE role_name = %s LIMIT 1",
            $role
        ));

        if ($row && !empty($row->permissions)) {
            $permissions = json_decode($row->permissions, true);
            if (is_array($permissions)) {
                // Flatten permissions to simple array for JS
                // Format: module.action (e.g., 'shift.delete_history')
                $flat_permissions = [];
                foreach ($permissions as $module => $actions) {
                    if (is_array($actions)) {
                        foreach ($actions as $action) {
                            $flat_permissions[] = $module . '.' . $action;
                        }
                    }
                }
                return $flat_permissions;
            }
        }

        return [];
    }

    /**
     * Lấy dữ liệu chung cho localize.
     *
     * @return array Dữ liệu localize.
     */
    private static function get_common_localize_data() {
        return apply_filters('checkin_mkt192_localize_data', [
            'nonce'                  => wp_create_nonce('wp_rest'),
            'restUrl'                => rest_url('vg/v1/'),
            'ajaxUrl'                => admin_url('admin-ajax.php'),
            'pluginUrl'              => CHECKIN_PLUGIN_URL,
            'logoUrl'                => get_option('checkin_logo_url', ''),
            'brandName'              => get_option('checkin_brand_name', 'Barber Shop'),
            'domain'                 => get_option('checkin_domain', get_site_url()),
            'primaryColor'           => get_option('checkin_primary_color', '#000000'),
            'secondaryColor'         => get_option('checkin_secondary_color', '#ffffff'),
            'useGoogleLogin'         => get_option('checkin_use_google_login', '0') === '1',
            'googleClientId'         => get_option('checkin_google_client_id'),
            'useFacebookLogin'       => get_option('checkin_use_facebook_login', '0') === '1',
            'facebookAppId'          => get_option('checkin_facebook_app_id'),
            'isMultiBranchEnabled'   => checkin_mkt192_is_multi_branch_enabled()
        ]);
    }

    /**
     * Lấy dữ liệu QR thanh toán dựa trên trạng thái bật/tắt.
     * Hỗ trợ multi-branch: Trả về QR theo chi nhánh nếu được cấu hình.
     *
     * @param int|null $branch_id Branch ID để lấy QR tương ứng (null = lấy tất cả)
     * @return array Dữ liệu QR thanh toán.
     */
    private static function get_payment_qr_data($branch_id = null) {
        // Kiểm tra chế độ đa chi nhánh
        $is_multi_branch = function_exists('checkin_mkt192_is_multi_branch_enabled')
            && checkin_mkt192_is_multi_branch_enabled();

        // Lấy QR branches data
        $bank_qr_per_branch    = get_option('checkin_bank_qr_per_branch', '0');
        $bank_qr_branches      = get_option('checkin_bank_qr_branches', []);
        $momo_qr_per_branch    = get_option('checkin_momo_qr_per_branch', '0');
        $momo_qr_branches      = get_option('checkin_momo_qr_branches', []);
        $zalopay_qr_per_branch = get_option('checkin_zalopay_qr_per_branch', '0');
        $zalopay_qr_branches   = get_option('checkin_zalopay_qr_branches', []);

        // Xác định QR URL cho từng loại thanh toán
        $bank_qr_url    = get_option('checkin_bank_qr_url', '');
        $momo_qr_url    = get_option('checkin_momo_qr_url', '');
        $zalopay_qr_url = get_option('checkin_zalopay_qr_url', '');

        // Nếu multi-branch được bật và có branch_id, lấy QR theo branch
        if ($is_multi_branch && $branch_id) {
            if ($bank_qr_per_branch === '1' && isset($bank_qr_branches[$branch_id]) && !empty($bank_qr_branches[$branch_id])) {
                $bank_qr_url = $bank_qr_branches[$branch_id];
            }
            if ($momo_qr_per_branch === '1' && isset($momo_qr_branches[$branch_id]) && !empty($momo_qr_branches[$branch_id])) {
                $momo_qr_url = $momo_qr_branches[$branch_id];
            }
            if ($zalopay_qr_per_branch === '1' && isset($zalopay_qr_branches[$branch_id]) && !empty($zalopay_qr_branches[$branch_id])) {
                $zalopay_qr_url = $zalopay_qr_branches[$branch_id];
            }
        }

        $qr_data = [
            'bank' => [
                'enabled'        => get_option('checkin_use_bank_transfer', '0') === '1',
                'account'        => get_option('checkin_bank_account', ''),
                'qr_url'         => $bank_qr_url,
                'account_number' => get_option('checkin_bank_account_number', ''),
                'account_name'   => get_option('checkin_bank_account_name', ''),
                'bank_bin'       => get_option('checkin_bank_bin', '970422'), // VietQR bank BIN code
                'note_prefix'    => get_option('checkin_monkeypay_note_prefix', get_option('checkin_mbbank_note_prefix', 'MKT')),
                'note_syntax'    => get_option('checkin_monkeypay_note_syntax', get_option('checkin_mbbank_note_syntax', '{invoice_id}')),
                'auto_mode'      => get_option('checkin_bank_auto_mode', '0') == '1',
                'auto_amount'    => get_option('checkin_bank_auto_amount', '1') == '1',
                'polling_interval' => intval(get_option('checkin_monkeypay_polling_interval', get_option('checkin_mbbank_polling_interval', '5'))),
                'is_monkeypay'   => function_exists('checkin_mkt192_is_monkeypay_mode') && checkin_mkt192_is_monkeypay_mode(),
                'qr_per_branch'  => $is_multi_branch && $bank_qr_per_branch === '1',
                'qr_branches'    => $is_multi_branch && $bank_qr_per_branch === '1' ? $bank_qr_branches : [],
            ],
            'momo' => [
                'enabled'        => get_option('checkin_use_momo', '0') === '1',
                'account'        => get_option('checkin_momo_account', ''),
                'qr_url'         => $momo_qr_url,
                'qr_per_branch'  => $is_multi_branch && $momo_qr_per_branch === '1',
                'qr_branches'    => $is_multi_branch && $momo_qr_per_branch === '1' ? $momo_qr_branches : [],
            ],
            'zalopay' => [
                'enabled'        => get_option('checkin_use_zalopay', '0') === '1',
                'account'        => get_option('checkin_zalopay_account', ''),
                'qr_url'         => $zalopay_qr_url,
                'qr_per_branch'  => $is_multi_branch && $zalopay_qr_per_branch === '1',
                'qr_branches'    => $is_multi_branch && $zalopay_qr_per_branch === '1' ? $zalopay_qr_branches : [],
            ],
        ];

        // Chỉ giữ các phương thức có enabled = true
        return array_filter($qr_data, function ($method) {
            return $method['enabled'];
        });
    }

    /**
     * Lấy danh sách tất cả chi nhánh để localize
     *
     * @return array Danh sách chi nhánh với id và name
     */
    private static function get_all_branches_for_localize() {
        if (get_option('checkin_branch_mode_enabled', '0') !== '1') {
            return [];
        }

        global $wpdb;
        $branches = $wpdb->get_results(
            "SELECT id, location_name as name FROM {$wpdb->prefix}checkin_mkt192_locations ORDER BY is_main_branch DESC, location_name ASC",
            ARRAY_A
        );

        return is_array($branches) ? $branches : [];
    }

    /**
     * Lấy cấu hình Push Notifications (OneSignal).
     *
     * @return array|null Cấu hình push hoặc null nếu chưa được cài đặt.
     */
    private static function get_push_notification_config() {
        $app_id        = get_option('checkin_onesignal_app_id', '');
        $safari_web_id = get_option('checkin_onesignal_safari_web_id', '');
        $enabled       = get_option('checkin_push_enabled', '0') === '1';

        if (!$enabled || empty($app_id)) {
            return null;
        }

        return [
            'enabled'       => true,
            'appId'         => $app_id,
            'safari_web_id' => $safari_web_id,
            'debug'         => defined('WP_DEBUG') && WP_DEBUG,
            'userId'        => get_current_user_id(),
            'apiBase'       => rest_url('vg/v1'),
            'nonce'         => wp_create_nonce('wp_rest'),
        ];
    }

    /**
     * Thêm HTML cho modal và toast vào footer.
     */
    public static function add_modal_toast_html() {
        global $post;
        if (!is_singular() || !isset($post->post_content)) {
            return;
        }

        $shortcodes = [
            'checkin_mkt192_home',
            'checkin_admin_frontend',
            'checkin_display',
            'checkin_app_tho',
            'checkin_user_profile',
            'checkin_dashboard',
            'checkin_customer_review_offline',
            'checkin_customer_review_online',
            'checkin_customer_member',
            'checkin_customer_registration',
            'checkin_policy',
            'checkin_terms_and_service',
        ];

        foreach ($shortcodes as $shortcode) {
            if (has_shortcode($post->post_content, $shortcode)) {
                echo '
                <!-- Modal thông báo -->
                <div id="notificationModal" class="notification-modal">
                    <div class="notification-modal-container">
                        <div class="notification-modal-header">
                            <i id="notificationModalIcon" class="notification-modal-icon"></i>
                            <h3 id="notificationModalTitle" class="notification-modal-title"></h3>
                        </div>
                        <p id="notificationModalMessage" class="notification-modal-message"></p>
                        <div id="notificationModalButtons" class="notification-modal-buttons"></div>
                    </div>
                </div>

                <!-- Thanh trạng thái -->
                <div id="checkinToastContainer" class="checkin-toast-container"></div>';
                break; // Thoát vòng lặp sau khi thêm HTML
            }
        }
    }

    /**
     * Generate cache-busting version string for an asset file.
     *
     * Appends the file modification timestamp to the plugin version,
     * so browsers automatically fetch the latest CSS/JS when files change.
     *
     * @param  string $ver  Original version string.
     * @param  string $src  Asset URL.
     * @return string Version string e.g. "5.1.0.1711187602".
     */
    private static function asset_ver( $ver, $src ) {
        // Skip external URLs (CDN) — keep original version
        if ( $ver === null || strpos( $src, CHECKIN_PLUGIN_URL ) === false ) {
            return $ver;
        }

        // Convert URL to file path
        $file_path = str_replace( CHECKIN_PLUGIN_URL, CHECKIN_PLUGIN_DIR, $src );
        $mtime     = file_exists( $file_path ) ? filemtime( $file_path ) : 0;
        return CHECKIN_MKT192_VERSION . '.' . $mtime;
    }

    /**
     * Tải tài nguyên frontend (CSS, JS) dựa trên shortcode.
     */
    public static function enqueue_frontend_assets() {
        global $post;
        if (!is_singular() || !isset($post->post_content)) {
            return;
        }
        $post_content = $post->post_content;

        // Tải Font Awesome nếu chưa được nạp
        if (!wp_style_is('font-awesome', 'enqueued')) {
            wp_enqueue_style('font-awesome', 'https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.5.1/css/all.min.css', [], '6.5.1');
        }

        // Tải Google Fonts: Montserrat
        wp_enqueue_style(
            'google-fonts-montserrat',
            'https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700;800&display=swap',
            [],
            null
        );

        // Tải tài nguyên modals chung cho tất cả shortcode (đã gộp từ modal-toast)
        if (!wp_style_is('modals-style', 'enqueued')) {
            wp_enqueue_style('modals-style', CHECKIN_PLUGIN_URL . 'frontend/assets/css/components/modals.css', [], self::asset_ver(CHECKIN_MKT192_VERSION, CHECKIN_PLUGIN_URL . 'frontend/assets/css/components/modals.css'));
        }
        if (!wp_script_is('modals-script', 'enqueued')) {
            wp_enqueue_script('modals-script', CHECKIN_PLUGIN_URL . 'frontend/assets/js/components/modals.js', [], self::asset_ver(CHECKIN_MKT192_VERSION, CHECKIN_PLUGIN_URL . 'frontend/assets/js/components/modals.js'), false); // Nạp trong <head>
        }

        // Tải Branch Helper script chung (dependency cho pages sử dụng branch)
        if (!wp_script_is('branch-helper-script', 'enqueued')) {
            wp_enqueue_script('branch-helper-script', CHECKIN_PLUGIN_URL . 'frontend/assets/js/components/branchHelper.js', [], CHECKIN_MKT192_VERSION, false);
        }

        // Cấu hình shortcode và tài nguyên
        $shortcodes = [
            'checkin_display' => [
                'styles' => [
                    ['handle' => 'checkin-style', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/css/pages/checkin.css', 'deps' => [], 'ver' => CHECKIN_MKT192_VERSION],
                    ['handle' => 'page-loader-style', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/css/components/page-loader.css', 'deps' => [], 'ver' => CHECKIN_MKT192_VERSION],
                ],
                'scripts' => [
                    ['handle' => 'page-loader-script', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/js/components/page-loader.js', 'deps' => [], 'ver' => CHECKIN_MKT192_VERSION, 'in_footer' => true],
                    ['handle' => 'checkin-script', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/js/pages/checkin.js', 'deps' => ['modals-script', 'page-loader-script'], 'ver' => CHECKIN_MKT192_VERSION, 'in_footer' => true],
                ],
                'localize' => [
                    'handle'      => 'checkin-script',
                    'object_name' => 'checkinData',
                    'data'        => function() {
                        $data = self::get_common_localize_data();
                        if (is_user_logged_in()) {
                            $user_data           = self::get_current_user_data();
                            $data['displayName'] = $user_data['display_name'];
                            $data['userLogin']   = $user_data['user_login'];
                            $data['userRole']    = $user_data['user_role'];
                        }
                        return $data;
                    },
                ],
            ],
            'checkin_admin_frontend' => [
                'styles' => [
                    ['handle' => 'admin-frontend-style', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/css/pages/admin-setting-frontend.css', 'deps' => [], 'ver' => CHECKIN_MKT192_VERSION],
                    ['handle' => 'salary-staff-style', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/css/components/salary-staff.css', 'deps' => [], 'ver' => CHECKIN_MKT192_VERSION],
                    ['handle' => 'branch-selector-style', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/css/components/branch-selector.css', 'deps' => [], 'ver' => CHECKIN_MKT192_VERSION],
                ],
                'scripts' => [
                    ['handle' => 'admin-frontend-script', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/js/pages/admin-setting/admin-setting-frontend.js', 'deps' => ['modals-script', 'branch-helper-script'], 'ver' => CHECKIN_MKT192_VERSION, 'in_footer' => true],
                    ['handle' => 'approval-management-script', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/js/pages/admin-setting/approval-management.js', 'deps' => ['admin-frontend-script'], 'ver' => CHECKIN_MKT192_VERSION, 'in_footer' => true],
                    ['handle' => 'notifications-management-script', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/js/pages/admin-setting/notifications-management.js', 'deps' => ['admin-frontend-script'], 'ver' => CHECKIN_MKT192_VERSION, 'in_footer' => true],
                    ['handle' => 'salary-staff-script', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/js/components/salary-staff.js', 'deps' => ['modals-script'], 'ver' => CHECKIN_MKT192_VERSION, 'in_footer' => true],
                ],
                'localize' => [
                    'handle'      => 'admin-frontend-script',
                    'object_name' => 'checkinData',
                    'data'        => function() {
                        return array_merge(
                            self::get_common_localize_data(),
                            [
                                'currentUser'       => self::get_current_user_data(),
                                'version'           => CHECKIN_MKT192_VERSION,
                                'branchModeEnabled' => get_option('checkin_branch_mode_enabled', '0'),
                                'branches'          => self::get_all_branches_for_localize()
                            ]
                        );
                    },
                ],
            ],
            'checkin_dashboard' => [
                'styles' => [
                    ['handle' => 'checkin-dashboard-style', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/css/pages/checkin-dashboard.css', 'deps' => [], 'ver' => CHECKIN_MKT192_VERSION],
                ],
                'scripts' => [
                    ['handle' => 'jquery', 'src' => '', 'deps' => [], 'ver' => null, 'in_footer' => true],
                    ['handle' => 'chart-js', 'src' => 'https://cdn.jsdelivr.net/npm/chart.js', 'deps' => ['modals-script'], 'ver' => null, 'in_footer' => true],
                    ['handle' => 'checkin-dashboard-script', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/js/pages/checkin-dashboard.js', 'deps' => ['jquery','chart-js', 'modals-script'], 'ver' => CHECKIN_MKT192_VERSION, 'in_footer' => true],
                ],
                'localize' => [
                    'handle'      => 'checkin-dashboard-script',
                    'object_name' => 'checkinData',
                    'data'        => function() {
                        return array_merge(
                            self::get_common_localize_data(),
                            ['current_user_id' => get_current_user_id()]
                        );
                    },
                ],
            ],
            'checkin_app_tho' => [
                'styles' => [
                    ['handle' => 'app-tho-style', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/css/pages/app-tho/app-tho.css', 'deps' => [], 'ver' => CHECKIN_MKT192_VERSION],
                    ['handle' => 'app-tho-sidebar-style', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/css/pages/app-tho/sidebar.css', 'deps' => ['app-tho-style'], 'ver' => CHECKIN_MKT192_VERSION],
                    ['handle' => 'app-tho-dashboard-style', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/css/pages/app-tho/dashboard.css', 'deps' => ['app-tho-style'], 'ver' => CHECKIN_MKT192_VERSION],
                    ['handle' => 'app-tho-invoice-services-style', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/css/pages/app-tho/invoice-services.css', 'deps' => ['app-tho-style'], 'ver' => CHECKIN_MKT192_VERSION],
                    ['handle' => 'modals-style', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/css/components/modals.css', 'deps' => ['app-tho-style'], 'ver' => CHECKIN_MKT192_VERSION],
                    ['handle' => 'app-tho-inventory-style', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/css/pages/app-tho/inventory.css', 'deps' => ['app-tho-style'], 'ver' => CHECKIN_MKT192_VERSION],
                    ['handle' => 'app-tho-shift-management-style', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/css/pages/app-tho/shift-management.css', 'deps' => ['app-tho-style'], 'ver' => CHECKIN_MKT192_VERSION],
                    ['handle' => 'app-tho-dark-mode-style', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/css/pages/app-tho/dark-mode.css', 'deps' => ['app-tho-style'], 'ver' => CHECKIN_MKT192_VERSION],
                    ['handle' => 'branch-selector-style', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/css/components/branch-selector.css', 'deps' => [], 'ver' => CHECKIN_MKT192_VERSION],
                    ['handle' => 'page-loader-style', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/css/components/page-loader.css', 'deps' => [], 'ver' => CHECKIN_MKT192_VERSION],
                    ['handle' => 'dashboard-style', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/css/pages/app-tho/dashboard.css', 'deps' => ['app-tho-style'], 'ver' => CHECKIN_MKT192_VERSION],
                    ['handle' => 'staff-notifications-style', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/css/components/staff-notifications.css', 'deps' => ['app-tho-style'], 'ver' => CHECKIN_MKT192_VERSION],
                ],
                'scripts' => [
                    ['handle' => 'html5-qrcode', 'src' => 'https://unpkg.com/html5-qrcode', 'deps' => ['modals-script'], 'ver' => null, 'in_footer' => true],
                    ['handle' => 'chart-js', 'src' => 'https://cdn.jsdelivr.net/npm/chart.js', 'deps' => ['modals-script'], 'ver' => null, 'in_footer' => true],
                    ['handle' => 'page-loader-script', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/js/components/page-loader.js', 'deps' => [], 'ver' => CHECKIN_MKT192_VERSION, 'in_footer' => true],
                    ['handle' => 'button-loader-script', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/js/components/button-loader.js', 'deps' => [], 'ver' => CHECKIN_MKT192_VERSION, 'in_footer' => true],
                    ['handle' => 'app-tho-dashboard-script', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/js/pages/app-tho/dashboard.js', 'deps' => ['chart-js'], 'ver' => CHECKIN_MKT192_VERSION, 'in_footer' => true],
                    ['handle' => 'app-tho-shift-management-script', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/js/pages/app-tho/shift-management.js', 'deps' => [], 'ver' => CHECKIN_MKT192_VERSION, 'in_footer' => true],
                    ['handle' => 'app-tho-script', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/js/pages/app-tho/app-tho.js', 'deps' => ['html5-qrcode', 'chart-js', 'modals-script', 'branch-helper-script', 'page-loader-script', 'button-loader-script', 'app-tho-dashboard-script', 'app-tho-shift-management-script'], 'ver' => CHECKIN_MKT192_VERSION, 'in_footer' => true],
                    ['handle' => 'staff-notifications-script', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/js/components/staff-notifications.js', 'deps' => ['app-tho-script'], 'ver' => CHECKIN_MKT192_VERSION, 'in_footer' => true],
                ],
                'localize' => [
                    'handle'      => 'app-tho-script',
                    'object_name' => 'checkinData',
                    'data'        => function() {
                        $data = array_merge(
                            self::get_common_localize_data(),
                            [
                            'currentUser'       => self::get_current_user_data(),
                                'version'           => CHECKIN_MKT192_VERSION,
                                'paymentQRs'        => self::get_payment_qr_data(),
                                'userPermissions'   => self::get_current_user_permissions(),
                                'branchModeEnabled' => get_option('checkin_branch_mode_enabled', '0') === '1',
                                'isMonkeyPayMode'   => function_exists('is_monkeypay_mode') && is_monkeypay_mode()
                            ]
                        );
                        return $data;
                    },
                ],
            ],
            'checkin_customer_review_offline' => [
                'styles' => [
                    ['handle' => 'customer-review-offline-style', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/css/pages/customer-review-offline.css', 'deps' => [], 'ver' => CHECKIN_MKT192_VERSION],
                    ['handle' => 'modals-style', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/css/components/modals.css', 'deps' => ['customer-review-offline-style'], 'ver' => CHECKIN_MKT192_VERSION],
                ],
                'scripts' => [
                    ['handle' => 'button-loader-script', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/js/components/button-loader.js', 'deps' => [], 'ver' => CHECKIN_MKT192_VERSION, 'in_footer' => true],
                    ['handle' => 'customer-review-offline-script', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/js/pages/customer-review-offline.js', 'deps' => ['modals-script', 'button-loader-script'], 'ver' => CHECKIN_MKT192_VERSION, 'in_footer' => true],
                ],
                'localize' => [
                    'handle'      => 'customer-review-offline-script',
                    'object_name' => 'checkinData',
                    'data'        => function() {
                        return array_merge(
                            self::get_common_localize_data(),
                            [
                                'currentUser' => self::get_current_user_data(),
                                'paymentQRs'  => self::get_payment_qr_data()
                            ]
                        );
                    },
                ],
            ],
            'checkin_customer_review_online' => [
                'styles' => [
                    ['handle' => 'customer-review-online-style', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/css/pages/customer-review-online.css', 'deps' => [], 'ver' => CHECKIN_MKT192_VERSION],
                ],
                'scripts' => [
                    ['handle' => 'customer-review-online-script', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/js/pages/customer-review-online.js', 'deps' => ['modals-script'], 'ver' => CHECKIN_MKT192_VERSION, 'in_footer' => true],
                ],
                'localize' => [
                    'handle'      => 'customer-review-online-script',
                    'object_name' => 'checkinData',
                    'data'        => function() {
                        return array_merge(
                            self::get_common_localize_data(),
                            ['currentUser' => self::get_current_user_data()]
                        );
                    },
                ],
            ],
            'checkin_user_profile' => [
                'styles' => [
                    ['handle' => 'dashicons', 'src' => '', 'deps' => [], 'ver' => null],
                    ['handle' => 'checkin-mkt-user-profile-style', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/css/pages/user-profile/user-profile.css', 'deps' => [], 'ver' => CHECKIN_MKT192_VERSION],
                    ['handle' => 'modern-edit-modal-style', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/css/pages/user-profile/modern-edit-modal.css', 'deps' => [], 'ver' => CHECKIN_MKT192_VERSION],
                    ['handle' => 'salary-staff-style', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/css/components/salary-staff.css', 'deps' => [], 'ver' => CHECKIN_MKT192_VERSION],
                    ['handle' => 'request-approval-style', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/css/pages/user-profile/request-approval.css', 'deps' => [], 'ver' => CHECKIN_MKT192_VERSION],
                    ['handle' => 'staff-notifications-style', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/css/components/staff-notifications.css', 'deps' => [], 'ver' => CHECKIN_MKT192_VERSION],
                    ['handle' => 'account-linking-style', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/css/components/account-linking.css', 'deps' => [], 'ver' => CHECKIN_MKT192_VERSION],
                ],
                'scripts' => [
                    ['handle' => 'checkin-mkt-user-profile-script', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/js/pages/user-profile/user-profile.js', 'deps' => ['modals-script'], 'ver' => CHECKIN_MKT192_VERSION, 'in_footer' => true],
                    ['handle' => 'modern-edit-modal-script', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/js/pages/user-profile/modern-edit-modal.js', 'deps' => ['checkin-mkt-user-profile-script'], 'ver' => CHECKIN_MKT192_VERSION, 'in_footer' => true],
                    ['handle' => 'account-linking-script', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/js/components/account-linking.js', 'deps' => ['checkin-mkt-user-profile-script'], 'ver' => CHECKIN_MKT192_VERSION, 'in_footer' => true],
                    ['handle' => 'push-notification-manager', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/js/components/push-notification-manager.js', 'deps' => [], 'ver' => CHECKIN_MKT192_VERSION, 'in_footer' => true],
                    ['handle' => 'salary-staff-script', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/js/components/salary-staff.js', 'deps' => ['modals-script'], 'ver' => CHECKIN_MKT192_VERSION, 'in_footer' => true],
                    ['handle' => 'request-approval-script', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/js/pages/user-profile/request-approval.js', 'deps' => ['checkin-mkt-user-profile-script'], 'ver' => CHECKIN_MKT192_VERSION, 'in_footer' => true],
                    ['handle' => 'staff-notifications-script', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/js/components/staff-notifications.js', 'deps' => ['checkin-mkt-user-profile-script'], 'ver' => CHECKIN_MKT192_VERSION, 'in_footer' => true],
                ],
                'localize' => [
                    'handle'      => 'checkin-mkt-user-profile-script',
                    'object_name' => 'checkinData',
                    'data'        => function() {
                        $default_avatar = get_avatar_url(get_current_user_id());
                        $push_config    = self::get_push_notification_config();
                        return array_merge(
                            self::get_common_localize_data(),
                            [
                                'defaultAvatar' => esc_url($default_avatar),
                                'currentUser'   => self::get_current_user_data(),
                                'push'          => $push_config
                            ]
                        );
                    },
                ],
            ],
            'checkin_customer_member' => [
                'styles' => [
                    ['handle' => 'modals-style', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/css/components/modals.css', 'deps' => [], 'ver' => CHECKIN_MKT192_VERSION],
                    ['handle' => 'customer-member-style', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/css/pages/customer-member.css', 'deps' => ['modals-style'], 'ver' => CHECKIN_MKT192_VERSION],
                ],
                'scripts' => [
                    ['handle' => 'qrcode-js', 'src' => 'https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js', 'deps' => [], 'ver' => '1.0.0', 'in_footer' => true],
                    ['handle' => 'customer-member-script', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/js/pages/customer-member.js', 'deps' => ['qrcode-js'], 'ver' => CHECKIN_MKT192_VERSION, 'in_footer' => true],
                ],
                'localize' => [
                    'handle'      => 'customer-member-script',
                    'object_name' => 'checkinData',
                    'data'        => function() {
                        global $wpdb;
                        $zalo_config = $wpdb->get_row(
                            "SELECT oa_id FROM {$wpdb->prefix}checkin_mkt192_zalo_config LIMIT 1"
                        );
                        return array_merge(
                            self::get_common_localize_data(),
                            [
                                'checkinBrandColors' => [
                                    'primary'   => get_option('checkin_primary_color', '#00d4aa'),
                                    'secondary' => get_option('checkin_secondary_color', '#6c5ce7')
                                ],
                                'useZaloOA' => get_option('checkin_use_zalo_oa', '0'),
                                'zaloOaId'  => $zalo_config ? $zalo_config->oa_id : ''
                            ]
                        );
                    },
                ],
            ],
            'checkin_customer_registration' => [
                'styles' => [
                    ['handle' => 'customer-registration-style', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/css/pages/customer-registration.css', 'deps' => [], 'ver' => CHECKIN_MKT192_VERSION],
                ],
                'scripts' => [
                    ['handle' => 'customer-registration-script', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/js/pages/customer-registration.js', 'deps' => [], 'ver' => CHECKIN_MKT192_VERSION, 'in_footer' => true],
                ],
                'localize' => [
                    'handle'      => 'customer-registration-script',
                    'object_name' => 'checkinData',
                    'data'        => function() {
                        return array_merge(
                            self::get_common_localize_data(),
                            [
                                'bannerUrl'      => get_option('checkin_banner_url', ''),
                                'useZaloOA'      => get_option('checkin_use_zalo_oa', 'no'),
                                'primaryColor'   => get_option('checkin_primary_color', '#00d4aa'),
                                'secondaryColor' => get_option('checkin_secondary_color', '#ff6b6b')
                            ]
                        );
                    },
                ],
            ],
            'checkin_mkt192_home' => [
                'styles' => [
                    ['handle' => 'home-style', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/css/pages/home.css', 'deps' => [], 'ver' => CHECKIN_MKT192_VERSION],
                    ['handle' => 'home-booking-modern-style', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/css/pages/home-booking-modern.css', 'deps' => ['home-style'], 'ver' => CHECKIN_MKT192_VERSION],
                    ['handle' => 'flatpickr', 'src' => 'https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css', 'deps' => [], 'ver' => null],
                ],
                'scripts' => [
                    ['handle' => 'image-loader-script', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/js/components/image-loader.js', 'deps' => [], 'ver' => CHECKIN_MKT192_VERSION, 'in_footer' => true],
                    ['handle' => 'home-script', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/js/pages/home.js', 'deps' => ['modals-script', 'image-loader-script'], 'ver' => CHECKIN_MKT192_VERSION, 'in_footer' => true],
                    ['handle' => 'home-booking-branch-script', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/js/pages/home-booking-branch.js', 'deps' => ['home-script', 'modals-script'], 'ver' => CHECKIN_MKT192_VERSION, 'in_footer' => true],
                    ['handle' => 'notification-popup-script', 'src' => CHECKIN_PLUGIN_URL . 'frontend/assets/js/components/notification-popup.js', 'deps' => ['home-script'], 'ver' => CHECKIN_MKT192_VERSION, 'in_footer' => true],
                    ['handle' => 'flatpickr-js', 'src' => 'https://cdn.jsdelivr.net/npm/flatpickr', 'deps' => ['home-script', 'modals-script'], 'ver' => null, 'in_footer' => true],
                    ['handle' => 'flatpickr-locale-vn', 'src' => 'https://npmcdn.com/flatpickr/dist/l10n/vn.js', 'deps' => ['home-script', 'modals-script'], 'ver' => null, 'in_footer' => true],
                ],
                'localize' => [
                    'handle'      => 'home-script',
                    'object_name' => 'checkinData',
                    'data'        => function() {
                        return array_merge(
                            self::get_common_localize_data(),
                            [
                                'branchModeEnabled' => get_option('checkin_branch_mode_enabled', '0') === '1'
                            ]
                        );
                    },
                ],
            ],
        ];

        foreach ($shortcodes as $shortcode => $config) {
            if (has_shortcode($post_content, $shortcode)) {
                foreach ($config['styles'] as $style) {
                    if (!wp_style_is($style['handle'], 'enqueued')) {
                        wp_enqueue_style($style['handle'], $style['src'], $style['deps'], self::asset_ver($style['ver'], $style['src']));
                    }
                }
                foreach ($config['scripts'] as $script) {
                    if (!wp_script_is($script['handle'], 'enqueued')) {
                        wp_enqueue_script($script['handle'], $script['src'], $script['deps'], self::asset_ver($script['ver'], $script['src']), $script['in_footer']);
                    }
                }
                if (isset($config['localize'])) {
                    wp_localize_script(
                        $config['localize']['handle'],
                        $config['localize']['object_name'],
                        call_user_func($config['localize']['data'])
                    );
                }
            }
        }
    }

    /**
     * Thêm các biến CSS toàn cục vào <head>.
     */
    public static function add_custom_css_vars() {
        $primary_color   = get_option('checkin_primary_color', '#000000');
        $secondary_color = get_option('checkin_secondary_color', '#ffd700');

        echo '<style type="text/css">';
        echo ':root {';
        echo '--primary-color: ' . esc_attr($primary_color) . ' !important;';
        echo '--secondary-color: ' . esc_attr($secondary_color) . ' !important;';
        echo '}';
        echo '</style>';
    }

    /**
     * Thêm PWA meta tags và manifest link vào <head>.
     * Required for iOS Safari to recognize the app as a PWA.
     */
    public static function add_pwa_meta_tags() {
        $brand_name    = get_option('checkin_brand_name', 'Checkin App');
        $primary_color = get_option('checkin_primary_color', '#000000');
        $logo_url      = get_option('checkin_logo_url', '');

        // Manifest link - serve dynamically via REST API
        echo '<link rel="manifest" href="' . esc_url(rest_url('vg/v1/manifest.json')) . '">' . "\n";

        // iOS specific meta tags for PWA
        echo '<meta name="apple-mobile-web-app-capable" content="yes">' . "\n";
        echo '<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">' . "\n";
        echo '<meta name="apple-mobile-web-app-title" content="' . esc_attr($brand_name) . '">' . "\n";

        // Theme color for Android Chrome
        echo '<meta name="theme-color" content="' . esc_attr($primary_color) . '">' . "\n";

        // Apple touch icons (use logo if available)
        if (!empty($logo_url)) {
            echo '<link rel="apple-touch-icon" href="' . esc_url($logo_url) . '">' . "\n";
            echo '<link rel="apple-touch-icon" sizes="152x152" href="' . esc_url($logo_url) . '">' . "\n";
            echo '<link rel="apple-touch-icon" sizes="180x180" href="' . esc_url($logo_url) . '">' . "\n";
            echo '<link rel="apple-touch-icon" sizes="167x167" href="' . esc_url($logo_url) . '">' . "\n";
        }

        // Mobile web app capable (legacy)
        echo '<meta name="mobile-web-app-capable" content="yes">' . "\n";
    }

    /**
     * Generate Web App Manifest JSON.
     * Called via REST API endpoint.
     *
     * @return array Manifest data.
     */
    public static function get_manifest_data() {
        $brand_name      = get_option('checkin_brand_name', 'Checkin App');
        $primary_color   = get_option('checkin_primary_color', '#000000');
        $secondary_color = get_option('checkin_secondary_color', '#ffd700');
        $logo_url        = get_option('checkin_logo_url', '');
        $start_url       = home_url('/user-profile');

        $manifest = [
            'name'             => $brand_name,
            'short_name'       => mb_substr($brand_name, 0, 12),
            'description'      => 'Ứng dụng điểm danh nhân viên - ' . $brand_name,
            'start_url'        => $start_url,
            'scope'            => home_url('/'),
            'display'          => 'standalone',
            'orientation'      => 'portrait',
            'theme_color'      => $primary_color,
            'background_color' => '#ffffff',
            'lang'             => 'vi',
            'categories'       => ['business', 'productivity'],
        ];

        // Add icons if logo exists
        if (!empty($logo_url)) {
            $manifest['icons'] = [
                [
                    'src'     => $logo_url,
                    'sizes'   => '192x192',
                    'type'    => 'image/png',
                    'purpose' => 'any maskable',
                ],
                [
                    'src'     => $logo_url,
                    'sizes'   => '512x512',
                    'type'    => 'image/png',
                    'purpose' => 'any maskable',
                ],
            ];
        }

        return $manifest;
    }

    /**
     * REST API endpoint để serve manifest.json.
     */
    public static function register_manifest_endpoint() {
        register_rest_route('vg/v1', '/manifest.json', [
            'methods'             => 'GET',
            'callback'            => function () {
                $manifest = self::get_manifest_data();
                return new WP_REST_Response($manifest, 200, [
                    'Content-Type' => 'application/manifest+json',
                ]);
            },
            'permission_callback' => '__return_true',
        ]);
    }
}

// Đăng ký các action
add_action('wp_enqueue_scripts', [Checkin_MKT192_Assets::class, 'enqueue_frontend_assets']);
add_action('wp_head', [Checkin_MKT192_Assets::class, 'add_custom_css_vars']);
add_action('wp_head', [Checkin_MKT192_Assets::class, 'add_pwa_meta_tags'], 5);
add_action('wp_footer', [Checkin_MKT192_Assets::class, 'add_modal_toast_html']);
add_action('rest_api_init', [Checkin_MKT192_Assets::class, 'register_manifest_endpoint']);
?>
