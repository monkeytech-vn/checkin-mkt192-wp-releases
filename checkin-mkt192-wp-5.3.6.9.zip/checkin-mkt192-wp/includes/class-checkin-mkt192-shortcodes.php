<?php

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Shortcodes management class for Checkin MKT192 WP.
 */
class Checkin_MKT192_Shortcodes {
    /**
     * Instance of the class (Singleton pattern).
     *
     * @var Checkin_MKT192_Shortcodes
     */
    private static $instance = null;

    /**
     * Get instance of the class.
     *
     * @return Checkin_MKT192_Shortcodes
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor.
     */
    private function __construct() {
        $this->init_hooks();
    }

    /**
     * Initialize WordPress hooks.
     */
    private function init_hooks() {
        $shortcodes = [
            'checkin_mkt192_home'              => [$this, 'home_shortcode'],
            'checkin_admin_frontend'           => [$this, 'admin_frontend_shortcode'],
            'checkin_display'                  => [$this, 'display_shortcode'],
            'checkin_app_tho'                  => [$this, 'app_tho_shortcode'],
            'checkin_user_profile'             => [$this, 'user_profile_shortcode'],
            'checkin_dashboard'                => [$this, 'checkin_dashboard_shortcode'],
            'checkin_customer_review_offline'  => [$this, 'customer_review_offline_shortcode'],
            'checkin_customer_review_online'   => [$this, 'customer_review_online_shortcode'],
            'checkin_customer_member'          => [$this, 'customer_member_shortcode'],
            'checkin_customer_registration'    => [$this, 'customer_registration_shortcode'],
            'checkin_policy'                   => [$this, 'policy_shortcode'],
            'checkin_terms_and_service'        => [$this, 'terms_and_service_shortcode'],
        ];

        foreach ($shortcodes as $shortcode => $callback) {
            add_shortcode($shortcode, $callback);
        }
    }

    /**
     * Check if user is logged in and return redirect message with modal if not.
     *
     * @param string $redirect_url URL to redirect to.
     * @param string $message Alert message.
     * @return string|bool JavaScript to show modal and redirect or false if logged in.
     */
    private function require_login($redirect_url = '/user-profile', $message = '🆘 Bạn chưa đăng nhập. Vui lòng đăng nhập!.') {
        if (!is_user_logged_in()) {
            ob_start();
            echo "<script>
                document.addEventListener('DOMContentLoaded', function() {
                    if (typeof showError === 'function') {
                        showError('$message', 'Lỗi đăng nhập').then(() => { window.location.href = '$redirect_url'; });
                    } else {
                        console.error('showError is not defined, falling back to alert');
                        alert('$message');
                        window.location.href = '$redirect_url';
                    }
                });
            </script>";
            return ob_get_clean();
        }
        return false;
    }

    /**
     * Check if user has admin privileges and return redirect message with modal if not.
     *
     * @param string $redirect_url URL to redirect to.
     * @param string $message Alert message.
     * @return string|bool JavaScript to show modal and redirect or false if user is admin.
     */
    private function require_admin($redirect_url = '/user-profile', $message = '🆘 Trang này chỉ dành cho Admin. Nếu là Admin, vui lòng đăng nhập trước!') {
        if (!current_user_can('manage_options')) {
            ob_start();
            echo "<script>
                document.addEventListener('DOMContentLoaded', function() {
                    if (typeof showError === 'function') {
                        showError('$message', 'Lỗi truy cập').then(() => { window.location.href = '$redirect_url'; });
                    } else {
                        console.error('showError is not defined, falling back to alert');
                        alert('$message');
                        window.location.href = '$redirect_url';
                    }
                });
            </script>";
            return ob_get_clean();
        }
        return false;
    }

    /**
     * Check if user has page access permission.
     *
     * @param string $access_key Access key: 'admin', 'app_tho', 'diem_danh', 'profile'
     * @param string $redirect_url URL to redirect to.
     * @param string $message Alert message.
     * @return string|bool JavaScript to show modal and redirect or false if user has access.
     */
    private function require_page_access($access_key, $redirect_url = '/', $message = '🆘 Bạn không có quyền truy cập trang này!') {
        // Load permission helper
        require_once CHECKIN_PLUGIN_DIR . 'includes/rest-api/permission.php';

        if (!checkin_mkt192_has_page_access($access_key)) {
            ob_start();
            echo "<script>
                document.addEventListener('DOMContentLoaded', function() {
                    if (typeof showError === 'function') {
                        showError('$message', 'Lỗi truy cập').then(() => { window.location.href = '$redirect_url'; });
                    } else {
                        console.error('showError is not defined, falling back to alert');
                        alert('$message');
                        window.location.href = '$redirect_url';
                    }
                });
            </script>";
            return ob_get_clean();
        }
        return false;
    }

    /**
     * Load a template safely.
     *
     * @param string $template_path Path to the template file.
     * @return string Template content or error message.
     */
    private function load_template($template_path) {
        ob_start();
        if (file_exists($template_path)) {
            include $template_path;
        } else {
            echo '<p>' . esc_html__('Template not found!', 'checkin-mkt192') . '</p>';
        }
        return ob_get_clean();
    }

    /**
     * Shortcode for displaying the home page.
     *
     * @return string Template content.
     */
    public function home_shortcode() {
        return $this->load_template(CHECKIN_PLUGIN_DIR . 'frontend/pages/home.php');
    }

    /**
     * Shortcode for admin frontend page.
     *
     * @return string Template content or redirect message.
     */
    public function admin_frontend_shortcode() {
        // Cho phép WordPress admin HOẶC role có access 'admin' trong plugin
        if ($redirect = $this->require_login()) {
            return $redirect;
        }
        if ($redirect = $this->require_page_access('admin', '/', '🆘 Bạn không có quyền truy cập trang Quản Lý!')) {
            return $redirect;
        }
        return $this->load_template(CHECKIN_PLUGIN_DIR . 'frontend/pages/admin-setting-frontend.html');
    }

    /**
     * Shortcode for check-in display page.
     *
     * @return string Template content or redirect message.
     */
    public function display_shortcode() {
        if ($redirect = $this->require_login()) {
            return $redirect;
        }
        if ($redirect = $this->require_page_access('diem_danh', '/', '🆘 Bạn không có quyền truy cập trang Điểm Danh!')) {
            return $redirect;
        }
        return $this->load_template(CHECKIN_PLUGIN_DIR . 'frontend/pages/checkin.html');
    }

    /**
     * Shortcode for worker app page.
     *
     * @return string Template content or redirect message.
     */
    public function app_tho_shortcode() {
        if ($redirect = $this->require_login()) {
            return $redirect;
        }
        if ($redirect = $this->require_page_access('app_tho', '/', '🆘 Bạn không có quyền truy cập trang App Thợ!')) {
            return $redirect;
        }
        return $this->load_template(CHECKIN_PLUGIN_DIR . 'frontend/pages/app-tho.html');
    }

    /**
     * Shortcode for user profile page.
     * Has its own login modal, so no permission check needed here.
     *
     * @return string Template content.
     */
    public function user_profile_shortcode() {
        return $this->load_template(CHECKIN_PLUGIN_DIR . 'frontend/pages/user-profile.html');
    }

    /**
     * Shortcode for admin frontend dashboard.
     *
     * @return string Template content or redirect message.
     */
    public function checkin_dashboard_shortcode() {
        if ($redirect = $this->require_login()) {
            return $redirect;
        }
        if ($redirect = $this->require_page_access('diem_danh', '/', '🆘 Bạn không có quyền truy cập trang Dashboard!')) {
            return $redirect;
        }
        return $this->load_template(CHECKIN_PLUGIN_DIR . 'frontend/pages/checkin-dashboard.html');
    }

    /**
     * Shortcode for offline customer review page.
     *
     * @return string Template content.
     */
    public function customer_review_offline_shortcode() {
        return $this->load_template(CHECKIN_PLUGIN_DIR . 'frontend/pages/customer-review-offline.html');
    }

    /**
     * Shortcode for online customer review page.
     *
     * @return string Template content.
     */
    public function customer_review_online_shortcode() {
        return $this->load_template(CHECKIN_PLUGIN_DIR . 'frontend/pages/customer-review-online.html');
    }

    /**
     * Shortcode for customer member page.
     *
     * @return string Template content.
     */
    public function customer_member_shortcode() {
        return $this->load_template(CHECKIN_PLUGIN_DIR . 'frontend/pages/customer-member.html');
    }

    /**
     * Shortcode for customer registration page (Public - từ Zalo OA).
     *
     * @return string Template content.
     */
    public function customer_registration_shortcode() {
        return $this->load_template(CHECKIN_PLUGIN_DIR . 'frontend/pages/customer-registration.php');
    }

    /**
     * Shortcode for policy page.
     *
     * @return string Template content.
     */
    public function policy_shortcode() {
        return $this->load_template(CHECKIN_PLUGIN_DIR . 'frontend/pages/policy.html');
    }

    /**
     * Shortcode for terms-and-services page.
     *
     * @return string Template content.
     */
    public function terms_and_service_shortcode() {
        return $this->load_template(CHECKIN_PLUGIN_DIR . 'frontend/pages/terms-and-service.html');
    }
}

// Initialize the class
Checkin_MKT192_Shortcodes::get_instance();
?>
