<?php
/**
 * Encryption Helper Class
 *
 * Provides AES-256-CBC encryption/decryption for sensitive data
 * using WordPress AUTH_KEY as the encryption key (unique per site).
 *
 * @package CheckinMKT192
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Checkin_Encryption {

	/**
	 * Cipher method
	 */
	private const CIPHER = 'aes-256-cbc';

	/**
	 * Get the encryption key derived from WordPress salt
	 *
	 * @return string
	 */
	private static function get_key() {
		return hash( 'sha256', wp_salt( 'auth' ), true );
	}

	/**
	 * Encrypt a plaintext value
	 *
	 * @param string $plaintext The value to encrypt.
	 * @return string|false Base64-encoded encrypted string, or false on failure.
	 */
	public static function encrypt( $plaintext ) {
		if ( empty( $plaintext ) ) {
			return '';
		}

		$key = self::get_key();
		$iv  = openssl_random_pseudo_bytes( openssl_cipher_iv_length( self::CIPHER ) );

		$encrypted = openssl_encrypt( $plaintext, self::CIPHER, $key, 0, $iv );

		if ( false === $encrypted ) {
			return false;
		}

		// Prepend IV to encrypted data (IV is needed for decryption)
		return base64_encode( $iv . '::' . $encrypted );
	}

	/**
	 * Decrypt an encrypted value
	 *
	 * @param string $encrypted The base64-encoded encrypted string.
	 * @return string|false The decrypted plaintext, or false on failure.
	 */
	public static function decrypt( $encrypted ) {
		if ( empty( $encrypted ) ) {
			return '';
		}

		$data = base64_decode( $encrypted, true );

		if ( false === $data ) {
			return false;
		}

		$parts = explode( '::', $data, 2 );

		if ( count( $parts ) !== 2 ) {
			// Not encrypted data — return as-is (backward compatibility)
			return $encrypted;
		}

		list( $iv, $ciphertext ) = $parts;
		$key = self::get_key();

		$decrypted = openssl_decrypt( $ciphertext, self::CIPHER, $key, 0, $iv );

		return $decrypted;
	}
}
