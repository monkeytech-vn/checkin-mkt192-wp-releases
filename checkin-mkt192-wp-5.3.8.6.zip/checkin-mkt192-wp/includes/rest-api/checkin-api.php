<?php

add_action('rest_api_init', function () {
    // Check-in
    register_rest_route('vg/v1', '/checkin', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_wp_handle_checkin',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'checkin.record'])
    ]);

    // Check-in Status
    register_rest_route('vg/v1', '/checkin-status', [
        'methods'             => 'GET',
        'callback'            => 'checkin_mkt192_wp_checkin_status',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'checkin.view'])
    ]);

    // Check-in Logs (Self-service - xem log của chính mình)
    register_rest_route('vg/v1', '/checkin-logs', [
        'methods'             => 'GET',
        'callback'            => 'checkin_mkt192_get_checkin_logs_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'checkin.view'])
    ]);

    // All Check-in Logs (Admin/Manager - xem tất cả)
    register_rest_route('vg/v1', '/all-checkin-logs', [
        'methods'             => 'GET',
        'callback'            => 'checkin_mkt192_get_all_checkin_logs_api',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'checkin.view_all'])
    ]);

    // Employee Check-in Logs (Xem log của nhân viên cụ thể)
    register_rest_route('vg/v1', '/employee-checkin-logs/(?P<employee_id>[^/]+)', [
       'methods'             => 'GET',
       'callback'            => 'checkin_mkt192_get_employee_checkin_logs_api',
       'permission_callback' => checkin_mkt192_permission([
           'mode'  => 'login',
           'scope' => ['checkin.view', 'checkin.view_all'],
           'logic' => 'OR'
       ])
    ]);
});

function checkin_mkt192_wp_handle_checkin(WP_REST_Request $request) {
    global $wpdb;

    // Đảm bảo thư mục logs tồn tại
    $log_dir = __DIR__ . '/logs/';
    if (!file_exists($log_dir)) {
        mkdir($log_dir, 0755, true);
    }

    if (!isset($wpdb)) {
        file_put_contents($log_dir . 'checkin_errors.log', date('Y-m-d H:i:s') . " - Không thể kết nối cơ sở dữ liệu.\n", FILE_APPEND);
        return new WP_REST_Response(['success' => false, 'message' => 'Không thể kết nối cơ sở dữ liệu.'], 500);
    }

    $data              = $request->get_json_params();
    $employee_id       = sanitize_text_field($data['employee_id'] ?? '');
    $display_name      = sanitize_text_field($data['display_name'] ?? '');
    $latitude          = floatval($data['latitude'] ?? 0);
    $longitude         = floatval($data['longitude'] ?? 0);
    $type              = sanitize_text_field($data['type'] ?? '');
    $selected_location = sanitize_text_field($data['selected_location'] ?? '');
    $selected_shift    = sanitize_text_field($data['selected_shift'] ?? '');
    $employee_role     = sanitize_text_field($data['employee_role'] ?? '');

    if (empty($employee_id) || empty($type) || empty($selected_shift)) {
        return new WP_REST_Response(['success' => false, 'message' => 'Thiếu thông tin bắt buộc (employee_id, type, hoặc selected_shift).'], 400);
    }

    try {
        $now          = new DateTime('now', new DateTimeZone('Asia/Ho_Chi_Minh'));
        $current_time = $now->format('H') * 60 + $now->format('i');

        $shifts_response = checkin_mkt192_get_shifts_api($request);
        if (!$shifts_response->data['success']) {
            return new WP_REST_Response(['success' => false, 'message' => 'Không thể lấy danh sách ca làm việc.'], 500);
        }
        $shifts = $shifts_response->data['data'];

        $locations_response = checkin_mkt192_get_all_locations_api($request);
        if (!$locations_response->data['success']) {
            return new WP_REST_Response(['success' => false, 'message' => 'Không thể lấy danh sách chi nhánh.'], 500);
        }
        $locations = $locations_response->data['data'];

        // Ghi log chi tiết về yêu cầu check-in
        $log_entry = sprintf(
            '[%s] - Thao tác: %s | Nhân viên: %s (ID: %s) | Vai trò: %s | Ca: %s | Vị trí: %s | Lat: %.6f, Long: %.6f',
            $now->format('Y-m-d H:i:s'),
            $type,
            $display_name,
            $employee_id,
            $employee_role,
            $selected_shift,
            $selected_location ?: ($nearest_location['location_name'] ?? 'Chưa xác định'),
            $latitude,
            $longitude
        );
        file_put_contents($log_dir . 'checkin_debug.log', $log_entry . "\n", FILE_APPEND);

        $nearest_location = null;
        $min_distance     = INF;
        foreach ($locations as $location) {
            if (!isset($location['latitude'], $location['longitude'], $location['radius']) ||
                $location['latitude'] === null                                             || $location['longitude'] === null) {
                continue;
            }
            $distance = calculate_distance($latitude, $longitude, $location['latitude'], $location['longitude']);
            if ($distance <= $location['radius'] && $distance < $min_distance) {
                $min_distance     = $distance;
                $nearest_location = $location;
            }
        }

        if ($selected_location) {
            $chosen_location = null;
            foreach ($locations as $location) {
                if ($location['location_name'] === $selected_location) {
                    $chosen_location = $location;
                    break;
                }
            }
            if ($chosen_location) {
                if (!isset($chosen_location['latitude'], $chosen_location['longitude'], $chosen_location['radius']) ||
                    $chosen_location['latitude'] === null                                                           || $chosen_location['longitude'] === null) {
                    return new WP_REST_Response(['success' => false, 'message' => "Dữ liệu chi nhánh '$selected_location' không hợp lệ."], 400);
                }
                $distance = calculate_distance($latitude, $longitude, $chosen_location['latitude'], $chosen_location['longitude']);
                if ($distance <= $chosen_location['radius']) {
                    $nearest_location = $chosen_location;
                } else {
                    return new WP_REST_Response(['success' => false, 'message' => "Chi nhánh '$selected_location' không nằm trong phạm vi cho phép."], 400);
                }
            }
        }

        if (!$nearest_location) {
            return new WP_REST_Response(['success' => false, 'message' => 'Bạn không nằm trong phạm vi chi nhánh nào.'], 400);
        }

        $user_role     = $wpdb->get_var($wpdb->prepare("SELECT user_role FROM {$wpdb->prefix}checkin_mkt192_staff WHERE employee_id = %s", $employee_id)) ?: 'Thu Ngân';
        $employee_role = $employee_role ?: $user_role;

        // Sử dụng ngày hiện tại từ PHP timezone thay vì CURDATE()
        $today = $now->format('Y-m-d');

        $existing_log = $wpdb->get_row($wpdb->prepare(
            "SELECT id, status, shift, checkin_time, checkout_time FROM {$wpdb->prefix}checkin_mkt192_checkinlogs
             WHERE employee_id = %s AND DATE(checkin_time) = %s AND shift = %s
             ORDER BY checkin_time DESC LIMIT 1",
            $employee_id, $today, $selected_shift
        ), ARRAY_A);

        $active_shift = null;
        foreach ($shifts as $shift) {
            if ($shift['shift_name'] === $selected_shift && $shift['shift_group'] === $user_role) {
                list($start_hours, $start_minutes) = explode(':', $shift['start_time']);
                $start_time                        = $start_hours * 60 + $start_minutes;
                list($end_hours, $end_minutes)     = explode(':', $shift['end_time']);
                $end_time                          = $end_hours * 60 + $end_minutes;

                $early_checkin  = (int) $shift['early_checkin'];
                $late_checkin   = (int) $shift['late_checkin'];
                $early_checkout = (int) $shift['early_checkout'];
                $late_checkout  = (int) $shift['late_checkout'];

                if ($type === 'Clock In') {
                    if (!$existing_log || !$existing_log['checkin_time'] || !$existing_log['checkout_time']) {
                        if ($current_time >= ($start_time - $early_checkin) && $current_time <= ($start_time + $late_checkin)) {
                            $active_shift = $shift;
                            break;
                        }
                    }
                } elseif ($type === 'Clock Out') {
                    if ($existing_log && $existing_log['checkin_time'] && !$existing_log['checkout_time']) {
                        if ($current_time >= ($end_time - $early_checkout) && $current_time <= ($end_time + $late_checkout)) {
                            $active_shift = $shift;
                            break;
                        }
                    }
                }
            }
        }

        if (!$active_shift) {
            if ($type === 'Clock In') {
                if ($existing_log && $existing_log['checkin_time'] && !$existing_log['checkout_time']) {
                    $checkin_time = (new DateTime($existing_log['checkin_time'], new DateTimeZone('Asia/Ho_Chi_Minh')))->format('H:i');
                    $message      = "Bạn đã Clock In ca {$existing_log['shift']} lúc $checkin_time. Vui lòng Clock Out trước khi Clock In ca khác.";
                    file_put_contents($log_dir . 'checkin_debug.log', "[$now->format('Y-m-d H:i:s')] - Message: $message\n", FILE_APPEND);
                    return new WP_REST_Response(['success' => false, 'message' => $message], 400);
                } else {
                    $shift = array_reduce($shifts, function ($carry, $shift) use ($selected_shift, $user_role) {
                        return $shift['shift_name'] === $selected_shift && $shift['shift_group'] === $user_role ? $shift : $carry;
                    }, null);
                    if ($shift) {
                        $start_time_str     = $shift['start_time'];
                        $early_checkin_time = gmdate('H:i', strtotime("1970-01-01 $start_time_str UTC") - ($shift['early_checkin'] * 60));
                        $late_checkin_time  = gmdate('H:i', strtotime("1970-01-01 $start_time_str UTC") + ($shift['late_checkin'] * 60));
                        $minutes_diff       = $current_time > ($start_hours * 60 + $start_minutes) ? ($current_time - ($start_hours * 60 + $start_minutes)) : (($start_hours * 60 + $start_minutes) - $current_time);
                        $message            = "Không thể Clock In: Thời gian hiện tại không nằm trong khoảng cho phép của {$shift['shift_name']}:\n- Giờ bắt đầu ca: $start_time_str\n- Giờ Clock In sớm nhất: $early_checkin_time\n- Giờ Clock In tối đa: $late_checkin_time\n- Thời gian hiện tại " . ($current_time < ($start_hours * 60 + $start_minutes) ? "sớm hơn $minutes_diff'" : "muộn hơn $minutes_diff'") . ' so với giờ bắt đầu.';
                        file_put_contents($log_dir . 'checkin_debug.log', "[$now->format('Y-m-d H:i:s')] - Message: $message\n", FILE_APPEND);
                        return new WP_REST_Response(['success' => false, 'message' => $message], 400);
                    }
                    $message = 'Không thể Clock In: Ca làm việc không hợp lệ.';
                    file_put_contents($log_dir . 'checkin_debug.log', "[$now->format('Y-m-d H:i:s')] - Message: $message\n", FILE_APPEND);
                    return new WP_REST_Response(['success' => false, 'message' => $message], 400);
                }
            } elseif ($type === 'Clock Out') {
                if (!$existing_log || !$existing_log['checkin_time']) {
                    $message = "Không thể Clock Out: Bạn chưa Clock In ca $selected_shift hôm nay.";
                    file_put_contents($log_dir . 'checkin_debug.log', "[$now->format('Y-m-d H:i:s')] - Message: $message\n", FILE_APPEND);
                    return new WP_REST_Response(['success' => false, 'message' => $message], 400);
                } elseif ($existing_log['checkout_time']) {
                    $checkout_time = (new DateTime($existing_log['checkout_time'], new DateTimeZone('Asia/Ho_Chi_Minh')))->format('H:i');
                    $message       = "Bạn đã Clock Out ca {$existing_log['shift']} lúc $checkout_time. Không thể Clock Out lại.";
                    file_put_contents($log_dir . 'checkin_debug.log', "[$now->format('Y-m-d H:i:s')] - Message: $message\n", FILE_APPEND);
                    return new WP_REST_Response(['success' => false, 'message' => $message], 400);
                } else {
                    $shift = array_reduce($shifts, function ($carry, $shift) use ($selected_shift, $user_role) {
                        return $shift['shift_name'] === $selected_shift && $shift['shift_group'] === $user_role ? $shift : $carry;
                    }, null);
                    if ($shift) {
                        $end_time_str        = $shift['end_time'];
                        $early_checkout_time = gmdate('H:i', strtotime("1970-01-01 $end_time_str UTC") - ($shift['early_checkout'] * 60));
                        $late_checkout_time  = gmdate('H:i', strtotime("1970-01-01 $end_time_str UTC") + ($shift['late_checkout'] * 60));
                        $minutes_diff        = $current_time > ($end_hours * 60 + $end_minutes) ? ($current_time - ($end_hours * 60 + $end_minutes)) : (($end_hours * 60 + $end_minutes) - $current_time);
                        $message             = "Không thể Clock Out: Thời gian hiện tại không nằm trong khoảng cho phép của {$shift['shift_name']}:\n- Giờ kết thúc ca: $end_time_str\n- Giờ Clock Out sớm nhất: $early_checkout_time\n- Giờ Clock Out tối đa: $late_checkout_time\n- Thời gian hiện tại " . ($current_time < ($end_hours * 60 + $end_minutes) ? "sớm hơn $minutes_diff'" : "muộn hơn $minutes_diff'") . ' so với giờ kết thúc.';
                        file_put_contents($log_dir . 'checkin_debug.log', "[$now->format('Y-m-d H:i:s')] - Message: $message\n", FILE_APPEND);
                        return new WP_REST_Response(['success' => false, 'message' => $message], 400);
                    }
                    $message = 'Không thể Clock Out: Ca làm việc không hợp lệ.';
                    file_put_contents($log_dir . 'checkin_debug.log', "[$now->format('Y-m-d H:i:s')] - Message: $message\n", FILE_APPEND);
                    return new WP_REST_Response(['success' => false, 'message' => $message], 400);
                }
            }
        }

        $checkin_time   = $now->format('Y-m-d H:i:s');
        $checkout_time  = null;
        $status         = 'pending';
        $status_late    = 0;
        $late_minutes   = 0;
        $penalty_type   = '';
        $penalty_amount = 0;
        $message        = '';

        if ($type === 'Clock In') {
            list($start_hours, $start_minutes) = explode(':', $active_shift['start_time']);
            $start_time                        = $start_hours * 60 + $start_minutes;
            $late_allowed                      = (int) $active_shift['late_allowed'];
            $late_minutes                      = max(0, $current_time - $start_time);

            if ($late_minutes > $late_allowed) {
                $message = "Đi trễ quá giới hạn $late_allowed phút. Không thể Check In.";
                file_put_contents($log_dir . 'checkin_debug.log', "[$now->format('Y-m-d H:i:s')] - Message: $message\n", FILE_APPEND);
                return new WP_REST_Response(['success' => false, 'message' => $message], 400);
            }

            if ($late_minutes > 0) {
                $status_late      = 1;
                $penalty_settings = $wpdb->get_row("SELECT * FROM {$wpdb->prefix}checkin_mkt192_penalty_settings WHERE id = 1", ARRAY_A) ?: [
                    'penalty_enabled' => 0,
                    'fine_amount'     => 0,
                    'fine_by_time'    => 0,
                    'fine_levels'     => '[]'
                ];

                // Vai trò không nằm trong "Áp dụng cho vai trò" thì vẫn ghi nhận trễ nhưng không phạt tiền
                if (function_exists('checkin_mkt192_penalty_applies_to') && !checkin_mkt192_penalty_applies_to($employee_role)) {
                    $penalty_settings['penalty_enabled'] = 0;
                }

                if ($penalty_settings['penalty_enabled']) {
                    $penalty_type = 'fine';
                    if ($penalty_settings['fine_by_time']) {
                        $fine_levels      = json_decode($penalty_settings['fine_levels'] ?: '[]', true);
                        $applicable_level = array_reduce($fine_levels, function ($carry, $level) use ($late_minutes) {
                            return $late_minutes <= $level['range'] ? $level : $carry;
                        }, end($fine_levels));
                        $penalty_amount = $applicable_level ? $applicable_level['amount'] : 0;
                    } else {
                        $penalty_amount = (float) $penalty_settings['fine_amount'];
                    }
                }
                $message = "Đi trễ $late_minutes phút, mức phạt: $penalty_amount VNĐ.";
            }

            $wpdb->insert(
                "{$wpdb->prefix}checkin_mkt192_checkinlogs",
                [
                    'employee_id'    => $employee_id,
                    'display_name'   => $display_name,
                    'checkin_time'   => $checkin_time,
                    'shift'          => $selected_shift,
                    'location_name'  => $nearest_location['location_name'],
                    'latitude'       => $latitude,
                    'longitude'      => $longitude,
                    'status'         => $status,
                    'status_late'    => $status_late,
                    'late_minutes'   => $late_minutes,
                    'penalty_type'   => $penalty_type,
                    'penalty_amount' => $penalty_amount,
                    'employee_role'  => $employee_role
                ],
                ['%s', '%s', '%s', '%s', '%s', '%f', '%f', '%s', '%d', '%d', '%s', '%f', '%s']
            );

            if ($wpdb->last_error) {
                file_put_contents($log_dir . 'checkin_errors.log', date('Y-m-d H:i:s') . ' - Lỗi khi chèn log: ' . $wpdb->last_error . "\n", FILE_APPEND);
                return new WP_REST_Response(['success' => false, 'message' => 'Lỗi khi lưu thông tin điểm danh.'], 500);
            }

            $log_entry = sprintf(
                '[%s] - Thao tác thành công: %s | Nhân viên: %s (ID: %s) | Vai trò: %s | Ca: %s | Thời gian: %s | Vị trí: %s | Trễ: %d phút | Phạt: %s VNĐ',
                $now->format('Y-m-d H:i:s'),
                $type,
                $display_name,
                $employee_id,
                $employee_role,
                $selected_shift,
                $checkin_time,
                $nearest_location['location_name'],
                $late_minutes,
                $penalty_amount
            );
            file_put_contents($log_dir . 'checkin_debug.log', $log_entry . "\n", FILE_APPEND);

            $message = $message ?: "Clock In thành công tại {$nearest_location['location_name']}!";
        } elseif ($type === 'Clock Out') {
            if ($existing_log && $existing_log['checkin_time'] && !$existing_log['checkout_time']) {
                $checkout_time = $now->format('Y-m-d H:i:s');
                $wpdb->update(
                    "{$wpdb->prefix}checkin_mkt192_checkinlogs",
                    ['checkout_time' => $checkout_time, 'status' => 'success'],
                    ['id'            => $existing_log['id']],
                    ['%s', '%s'],
                    ['%d']
                );

                if ($wpdb->last_error) {
                    file_put_contents($log_dir . 'checkin_errors.log', date('Y-m-d H:i:s') . ' - Lỗi khi cập nhật log: ' . $wpdb->last_error . "\n", FILE_APPEND);
                    return new WP_REST_Response(['success' => false, 'message' => 'Lỗi khi cập nhật thông tin điểm danh.'], 500);
                }

                $log_entry = sprintf(
                    '[%s] - Thao tác thành công: %s | Nhân viên: %s (ID: %s) | Vai trò: %s | Ca: %s | Thời gian: %s | Vị trí: %s',
                    $now->format('Y-m-d H:i:s'),
                    $type,
                    $display_name,
                    $employee_id,
                    $employee_role,
                    $selected_shift,
                    $checkout_time,
                    $nearest_location['location_name']
                );
                file_put_contents($log_dir . 'checkin_debug.log', $log_entry . "\n", FILE_APPEND);

                $message = "Clock Out thành công tại {$nearest_location['location_name']}!";
            }
        }

        $status_data = $wpdb->get_results($wpdb->prepare(
            "SELECT shift, checkin_time, checkout_time, status_late, late_minutes, penalty_amount
             FROM {$wpdb->prefix}checkin_mkt192_checkinlogs
             WHERE employee_id = %s AND DATE(checkin_time) = %s",
            $employee_id, $today
        ), ARRAY_A);

        foreach ($status_data as &$data) {
            $data['checkin_time']  = (new DateTime($data['checkin_time'], new DateTimeZone('Asia/Ho_Chi_Minh')))->format('c'); // ISO 8601
            $data['checkout_time'] = $data['checkout_time'] ? (new DateTime($data['checkout_time'], new DateTimeZone('Asia/Ho_Chi_Minh')))->format('c') : null;
        }

        $now_formatted = $now->format('Y-m-d H:i:s');
        file_put_contents($log_dir . 'checkin_debug.log', "[$now_formatted] - Message: $message\n", FILE_APPEND);
        return new WP_REST_Response([
            'success'        => true,
            'data'           => $status_data,
            'status_late'    => $status_late,
            'late_minutes'   => $late_minutes,
            'penalty_amount' => $penalty_amount,
            'message'        => $message,
            'location_name'  => $nearest_location['location_name'],
            'shift_name'     => $selected_shift
        ], 200);
    } catch (Exception $e) {
        file_put_contents($log_dir . 'checkin_errors.log', date('Y-m-d H:i:s') . ' - Lỗi: ' . $e->getMessage() . "\n", FILE_APPEND);
        return new WP_REST_Response(['success' => false, 'message' => 'Lỗi hệ thống: ' . $e->getMessage()], 500);
    }
}

function checkin_mkt192_wp_checkin_status(WP_REST_Request $request) {
    global $wpdb;

    $log_dir = __DIR__ . '/logs/';
    if (!file_exists($log_dir)) {
        mkdir($log_dir, 0755, true);
    }

    if (!isset($wpdb)) {
        file_put_contents($log_dir . 'checkin_errors.log', date('Y-m-d H:i:s') . " - Không thể kết nối cơ sở dữ liệu.\n", FILE_APPEND);
        return new WP_REST_Response(['success' => false, 'message' => 'Không thể kết nối cơ sở dữ liệu.'], 500);
    }

    try {
        $employee_id       = sanitize_text_field($request->get_param('employee_id') ?? '');
        $latitude          = floatval($request->get_param('latitude') ?? 0);
        $longitude         = floatval($request->get_param('longitude') ?? 0);
        $selected_location = sanitize_text_field($request->get_param('selected_location') ?? '');
        $selected_shift    = sanitize_text_field($request->get_param('selected_shift') ?? '');

        if (empty($employee_id)) {
            return new WP_REST_Response(['success' => false, 'message' => 'Thiếu employee_id'], 400);
        }

        $now          = new DateTime('now', new DateTimeZone('Asia/Ho_Chi_Minh'));
        $current_time = $now->format('H') * 60 + $now->format('i');

        $user_role = $wpdb->get_var($wpdb->prepare(
            "SELECT user_role FROM {$wpdb->prefix}checkin_mkt192_staff WHERE employee_id = %s",
            $employee_id
        )) ?: 'Thu Ngân';

        $shifts_response = checkin_mkt192_get_shifts_api($request);
        if (!$shifts_response->data['success']) {
            return new WP_REST_Response(['success' => false, 'message' => 'Không thể lấy danh sách ca làm việc.'], 500);
        }
        $shifts = $shifts_response->data['data'];

        $locations_response = checkin_mkt192_get_all_locations_api($request);
        if (!$locations_response->data['success']) {
            return new WP_REST_Response(['success' => false, 'message' => 'Không thể lấy danh sách chi nhánh.'], 500);
        }
        $locations = $locations_response->data['data'];

        $nearest_location = null;
        $min_distance     = INF;
        foreach ($locations as $location) {
            if (!isset($location['latitude'], $location['longitude'], $location['radius']) ||
                $location['latitude'] === null                                             || $location['longitude'] === null) {
                continue;
            }
            $distance = calculate_distance($latitude, $longitude, $location['latitude'], $location['longitude']);
            if ($distance <= $location['radius'] && $distance < $min_distance) {
                $min_distance     = $distance;
                $nearest_location = $location;
            }
        }

        if ($selected_location) {
            $chosen_location = null;
            foreach ($locations as $location) {
                if ($location['location_name'] === $selected_location) {
                    $chosen_location = $location;
                    break;
                }
            }
            if ($chosen_location) {
                if (!isset($chosen_location['latitude'], $chosen_location['longitude'], $chosen_location['radius']) ||
                    $chosen_location['latitude'] === null                                                           || $chosen_location['longitude'] === null) {
                    return new WP_REST_Response(['success' => false, 'message' => "Dữ liệu chi nhánh '$selected_location' không hợp lệ."], 400);
                }
                $distance = calculate_distance($latitude, $longitude, $chosen_location['latitude'], $chosen_location['longitude']);
                if ($distance <= $chosen_location['radius']) {
                    $nearest_location = $chosen_location;
                } else {
                    return new WP_REST_Response(['success' => false, 'message' => "Chi nhánh '$selected_location' không nằm trong phạm vi cho phép.", 'nearest_location' => $nearest_location ? $nearest_location['location_name'] : ''], 400);
                }
            }
        }

        // Sử dụng ngày hiện tại từ PHP timezone (Asia/Ho_Chi_Minh) thay vì CURDATE() (UTC)
        $today = $now->format('Y-m-d');

        $logs = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}checkin_mkt192_checkinlogs
             WHERE employee_id = %s AND DATE(checkin_time) = %s
             ORDER BY checkin_time DESC",
            $employee_id,
            $today
        ), ARRAY_A);

        // Debug logging
        $log_dir = __DIR__ . '/logs/';
        if (!file_exists($log_dir)) {
            mkdir($log_dir, 0755, true);
        }
        $debug_msg = sprintf(
            "[%s] checkin-status API: employee_id=%s, logs_count=%d, query=%s\n",
            (new DateTime('now', new DateTimeZone('Asia/Ho_Chi_Minh')))->format('Y-m-d H:i:s'),
            $employee_id,
            count($logs),
            $wpdb->last_query
        );
        file_put_contents($log_dir . 'checkin_status_debug.log', $debug_msg, FILE_APPEND);

        if (count($logs) > 0) {
            file_put_contents($log_dir . 'checkin_status_debug.log', 'First log: ' . print_r($logs[0], true) . "\n", FILE_APPEND);
        }

        foreach ($logs as &$log) {
            $log['status_late']    = (bool) $log['status_late'];
            $log['late_minutes']   = (int) $log['late_minutes'];
            $log['penalty_amount'] = (float) $log['penalty_amount'];
            $log['checkin_time']   = (new DateTime($log['checkin_time'], new DateTimeZone('Asia/Ho_Chi_Minh')))->format('c');
            $log['checkout_time']  = $log['checkout_time'] ? (new DateTime($log['checkout_time'], new DateTimeZone('Asia/Ho_Chi_Minh')))->format('c') : null;
        }

        $active_shift = null;
        $message      = '';
        if ($logs && $logs[0]['status'] === 'pending') {
            $active_shift = array_reduce($shifts, function ($carry, $shift) use ($logs, $user_role) {
                return $shift['shift_name'] === $logs[0]['shift'] && $shift['shift_group'] === $user_role ? $shift : $carry;
            }, null);
            if ($active_shift) {
                $message = 'Bạn đã Clock In ca ' . $active_shift['shift_name'] . '.';
            }
        } else {
            $nearest_shift = null;
            $min_time_diff = INF;

            foreach ($shifts as $shift) {
                if (!isset($shift['shift_group']) || $shift['shift_group'] !== $user_role) continue;
                list($start_hours, $start_minutes) = explode(':', $shift['start_time']);
                $start_time                        = $start_hours * 60 + $start_minutes;
                $early_checkin                     = (int) $shift['early_checkin'];
                $late_checkin                      = (int) $shift['late_checkin'];

                // Kiểm tra ca trong khoảng thời gian hợp lệ
                if ($current_time >= ($start_time - $early_checkin) && $current_time <= ($start_time + $late_checkin)) {
                    $time_diff = abs($current_time - $start_time);
                    if ($time_diff < $min_time_diff) {
                        $min_time_diff = $time_diff;
                        $nearest_shift = $shift;
                    }
                }
            }

            // Nếu không có ca hợp lệ, chọn ca có start_time gần nhất trong tương lai
            if (!$nearest_shift) {
                foreach ($shifts as $shift) {
                    if (!isset($shift['shift_group']) || $shift['shift_group'] !== $user_role) continue;
                    list($start_hours, $start_minutes) = explode(':', $shift['start_time']);
                    $start_time                        = $start_hours * 60 + $start_minutes;
                    if ($start_time >= $current_time) {
                        $time_diff = $start_time - $current_time;
                        if ($time_diff < $min_time_diff) {
                            $min_time_diff = $time_diff;
                            $nearest_shift = $shift;
                        }
                    }
                }
            }

            $active_shift = $nearest_shift;
            if ($active_shift) {
                list($start_hours, $start_minutes) = explode(':', $active_shift['start_time']);
                $start_time                        = $start_hours * 60 + $start_minutes;
                $late_minutes                      = max(0, $current_time - $start_time);
                $late_allowed                      = (int) $active_shift['late_allowed'];

                if ($late_minutes > 0 && $late_minutes <= $late_allowed) {
                    $message = "Bạn đang đi trễ $late_minutes phút.";
                } elseif ($late_minutes > $late_allowed) {
                    $message = "Đi trễ quá giới hạn $late_allowed phút.";
                } else {
                    $message = 'Hãy bắt đầu ca làm việc của bạn.';
                }
            } else {
                $message = 'Không tìm thấy ca làm việc phù hợp.';
            }
        }

        return new WP_REST_Response([
            'success'       => true,
            'message'       => $message,
            'data'          => $logs,
            'shift_name'    => $active_shift ? $active_shift['shift_name'] : '',
            'location_name' => $nearest_location ? $nearest_location['location_name'] : '',
            'current_date'  => $now->format('Y-m-d')
        ], 200);
    } catch (Exception $e) {
        file_put_contents($log_dir . 'checkin_errors.log', (new DateTime('now', new DateTimeZone('Asia/Ho_Chi_Minh')))->format('Y-m-d H:i:s') . ' - Lỗi: ' . $e->getMessage() . "\n", FILE_APPEND);
        return new WP_REST_Response(['success' => false, 'message' => 'Lỗi hệ thống khi kiểm tra trạng thái.'], 500);
    }
}

function calculate_distance($lat1, $lon1, $lat2, $lon2) {
    if ($lat2 === null || $lon2 === null) {
        return INF;
    }
    $R    = 6371000;
    $dLat = deg2rad($lat2 - $lat1);
    $dLon = deg2rad($lon2 - $lon1);
    $a    = sin($dLat / 2)   * sin($dLat / 2) +
         cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * sin($dLon / 2) * sin($dLon / 2);
    $c = 2                   * atan2(sqrt($a), sqrt(1 - $a));
    return $R                * $c;
}

function checkin_mkt192_get_checkin_logs_api($request) {
    global $wpdb;
    $employee_id = $request->get_param('employee_id');
    $scope       = $request->get_param('scope') ?: 'self';
    $limit       = $request->get_param('limit') ?: 10;
    $offset      = $request->get_param('offset') ?: 0;
    $search      = $request->get_param('search');
    $filter      = $request->get_param('filter') ?: 'today';

    // Sử dụng timezone Asia/Ho_Chi_Minh để tính toán ngày chính xác
    $tz    = new DateTimeZone('Asia/Ho_Chi_Minh');
    $now   = new DateTime('now', $tz);
    $today = $now->format('Y-m-d');

    $yesterday_dt = clone $now;
    $yesterday_dt->modify('-1 day');
    $yesterday = $yesterday_dt->format('Y-m-d');

    $query  = "SELECT * FROM {$wpdb->prefix}checkin_mkt192_checkinlogs WHERE 1=1";
    $params = [];

    if ($scope === 'self' && is_user_logged_in()) {
        $user        = wp_get_current_user();
        $employee_id = $wpdb->get_var($wpdb->prepare("SELECT employee_id FROM {$wpdb->prefix}checkin_mkt192_staff WHERE user_login = %s", $user->user_login));
    }

    if ($employee_id) {
        $query .= ' AND employee_id = %s';
        $params[] = $employee_id;
    }

    if ($search) {
        $query .= ' AND (display_name LIKE %s OR location_name LIKE %s)';
        $params[] = "%$search%";
        $params[] = "%$search%";
    }

    if ($filter === 'today') {
        $query .= ' AND DATE(checkin_time) = %s';
        $params[] = $today;
    } elseif ($filter === 'yesterday') {
        $query .= ' AND DATE(checkin_time) = %s';
        $params[] = $yesterday;
    } elseif ($filter === 'week') {
        $week_ago = clone $now;
        $week_ago->modify('-1 week');
        $query .= ' AND DATE(checkin_time) >= %s';
        $params[] = $week_ago->format('Y-m-d');
    } elseif ($filter === 'this_month') {
        $query .= ' AND MONTH(checkin_time) = %d AND YEAR(checkin_time) = %d';
        $params[] = (int)$now->format('m');
        $params[] = (int)$now->format('Y');
    } elseif ($filter === 'last_month') {
        $last_month = clone $now;
        $last_month->modify('first day of last month');
        $query .= ' AND MONTH(checkin_time) = %d AND YEAR(checkin_time) = %d';
        $params[] = (int)$last_month->format('m');
        $params[] = (int)$last_month->format('Y');
    } elseif ($filter === 'month') {
        $month_ago = clone $now;
        $month_ago->modify('-1 month');
        $query .= ' AND DATE(checkin_time) >= %s';
        $params[] = $month_ago->format('Y-m-d');
    }

    $query .= ' ORDER BY checkin_time DESC LIMIT %d OFFSET %d';
    $params[] = (int)$limit;
    $params[] = (int)$offset;

    try {
        $logs = $wpdb->get_results($wpdb->prepare($query, $params), OBJECT);

        $count_query = str_replace('SELECT *', 'SELECT COUNT(*)', $query);
        $count_query = preg_replace('/LIMIT %d OFFSET %d/', '', $count_query);
        $total       = $wpdb->get_var($wpdb->prepare($count_query, array_slice($params, 0, -2)));

        return new WP_REST_Response([
            'success' => true,
            'data'    => $logs,
            'total'   => $total,
            'limit'   => $limit,
            'offset'  => $offset
        ], 200);
    } catch (Exception $e) {
        file_put_contents(__DIR__ . '/logs/checkin_errors.log', date('Y-m-d H:i:s') . ' - Failed to fetch checkin logs: ' . $e->getMessage() . "\n", FILE_APPEND);
        return new WP_REST_Response(['success' => false, 'message' => 'Lỗi hệ thống'], 500);
    }
}

function checkin_mkt192_get_all_checkin_logs_api(WP_REST_Request $request) {
    global $wpdb;

    $limit  = intval($request->get_param('limit') ?? 50);
    $offset = intval($request->get_param('offset') ?? 0);
    $search = sanitize_text_field($request->get_param('search') ?? '');
    $filter = sanitize_text_field($request->get_param('filter') ?? '');

    try {
        $query  = "SELECT * FROM {$wpdb->prefix}checkin_mkt192_checkinlogs";
        $params = [];
        $where  = [];

        if (!empty($search)) {
            $where[]  = '(employee_id LIKE %s OR display_name LIKE %s)';
            $params[] = "%$search%";
            $params[] = "%$search%";
        }

        switch ($filter) {
            case 'today':
                $where[] = 'DATE(checkin_time) = CURDATE()';
                break;
            case 'yesterday':
                $where[] = 'DATE(checkin_time) = CURDATE() - INTERVAL 1 DAY';
                break;
            case 'this_week':
                $where[] = 'WEEK(checkin_time) = WEEK(CURDATE()) AND YEAR(checkin_time) = YEAR(CURDATE())';
                break;
            case 'this_month':
                $where[] = 'MONTH(checkin_time) = MONTH(CURDATE()) AND YEAR(checkin_time) = YEAR(CURDATE())';
                break;
            case 'last_month':
                $where[] = 'MONTH(checkin_time) = MONTH(CURDATE() - INTERVAL 1 MONTH) AND YEAR(checkin_time) = YEAR(CURDATE() - INTERVAL 1 MONTH)';
                break;
        }

        if (!empty($where)) {
            $query .= ' WHERE ' . implode(' AND ', $where);
        }

        $query .= ' ORDER BY checkin_time DESC LIMIT %d OFFSET %d';
        $params[] = $limit;
        $params[] = $offset;

        $logs = $wpdb->get_results($wpdb->prepare($query, $params), ARRAY_A);

        $count_query = "SELECT COUNT(*) FROM {$wpdb->prefix}checkin_mkt192_checkinlogs";
        if (!empty($where)) {
            $count_query .= ' WHERE ' . implode(' AND ', $where);
        }
        $total = $wpdb->get_var($wpdb->prepare($count_query, array_slice($params, 0, -2)));

        return new WP_REST_Response([
            'success' => true,
            'data'    => $logs,
            'total'   => $total,
            'limit'   => $limit,
            'offset'  => $offset
        ], 200);
    } catch (Exception $e) {
        file_put_contents(__DIR__ . '/logs/checkin_errors.log', date('Y-m-d H:i:s') . ' - Get all checkin logs error: ' . $e->getMessage() . "\n", FILE_APPEND);
        return new WP_REST_Response(['success' => false, 'message' => 'Lỗi hệ thống: ' . $e->getMessage()], 500);
    }
}

function checkin_mkt192_get_employee_checkin_logs_api(WP_REST_Request $request) {
    global $wpdb;

    $employee_id       = sanitize_text_field($request->get_param('employee_id'));
    $display_name      = sanitize_text_field($request->get_param('display_name'));
    $current_user_role = sanitize_text_field($request->get_param('current_user_role'));
    $start_date        = sanitize_text_field($request->get_param('start_date') ?? '');
    $end_date          = sanitize_text_field($request->get_param('end_date') ?? '');

    try {
        if ($current_user_role === 'Thu Ngân') {
            if (!empty($display_name) && $display_name !== 'all') {
                $result = $wpdb->get_row($wpdb->prepare("SELECT employee_id FROM {$wpdb->prefix}checkin_mkt192_staff WHERE display_name = %s", $display_name), ARRAY_A);
                if ($result && !empty($result['employee_id'])) {
                    $employee_id = $result['employee_id'];
                } else {
                    return new WP_REST_Response([
                        'success' => false,
                        'message' => 'Không tìm thấy employee_id tương ứng với display_name.'
                    ], 404);
                }
            } else {
                $query  = "SELECT * FROM {$wpdb->prefix}checkin_mkt192_checkinlogs";
                $params = [];

                if (!empty($start_date) && !empty($end_date)) {
                    $query .= ' WHERE checkin_time BETWEEN %s AND %s';
                    $params[] = $start_date . ' 00:00:00';
                    $params[] = $end_date . ' 23:59:59';
                }

                $query .= ' ORDER BY checkin_time DESC';

                // Chỉ dùng prepare nếu có params
                if (!empty($params)) {
                    $logs = $wpdb->get_results($wpdb->prepare($query, $params), ARRAY_A);
                } else {
                    $logs = $wpdb->get_results($query, ARRAY_A);
                }

                foreach ($logs as &$log) {
                    if ($log['employee_role'] === 'Thu Ngân') {
                        $checkin_time  = strtotime($log['checkin_time']);
                        $checkout_time = $log['checkout_time'] ? strtotime($log['checkout_time']) : null;

                        if (!$checkout_time) {
                            $log['standard_hours']   = 0;
                            $log['total_hours']      = 0;
                            $log['overtime_minutes'] = 0;
                            continue;
                        }

                        // Kiểm tra shift_name trước khi query
                        $shift = null;
                        if (!empty($log['shift'])) {
                            $shift = $wpdb->get_row($wpdb->prepare("
                                SELECT start_time, end_time
                                FROM {$wpdb->prefix}checkin_mkt192_shiftsettings
                                WHERE shift_name = %s
                            ", $log['shift']), ARRAY_A);
                        }

                        $shift_start = $shift ? strtotime(date('Y-m-d', $checkin_time) . ' ' . $shift['start_time']) : $checkin_time;
                        $shift_end   = $shift ? strtotime(date('Y-m-d', $checkin_time) . ' ' . $shift['end_time']) : $checkout_time;

                        if ($shift_end < $shift_start) {
                            $shift_end += 86400;
                        }

                        $start_time = $checkin_time;
                        $end_time   = $checkout_time;

                        if (strtolower($log['approval_ot'] ?? '') === 'approved') {
                            $end_time = $checkout_time;
                        } else {
                            if ($checkin_time > $shift_start) {
                                $start_time = $checkin_time;
                            } else {
                                $start_time = $shift_start;
                            }
                            $end_time = $checkout_time < $shift_end ? $checkout_time : $shift_end;
                        }

                        $total_hours = 0;
                        if ($end_time && $start_time && $end_time > $start_time) {
                            $hours = ($end_time - $start_time) / 3600;
                            if ($hours > 0 && $hours <= 24) {
                                $total_hours = round($hours, 2);
                            }
                        }

                        $standard_start_time = $checkin_time > $shift_start ? $checkin_time : $shift_start;
                        $standard_end_time   = $checkout_time && $checkout_time < $shift_end ? $checkout_time : $shift_end;
                        $standard_hours      = 0;
                        if ($standard_end_time && $standard_start_time && $standard_end_time > $standard_start_time) {
                            $hours = ($standard_end_time - $standard_start_time) / 3600;
                            if ($hours > 0 && $hours <= 24) {
                                $standard_hours = round($hours, 2);
                            }
                        }

                        $overtime_minutes = 0;
                        if (strtolower($log['approval_ot'] ?? '') === 'approved' && $checkout_time && $shift['end_time']) {
                            $shift_end = strtotime(date('Y-m-d', $checkin_time) . ' ' . $shift['end_time']);
                            if ($shift_end < $shift_start) {
                                $shift_end += 86400;
                            }
                            if ($checkout_time > $shift_end) {
                                $overtime_minutes = round(($checkout_time - $shift_end) / 60);
                            }
                        }

                        $log['standard_hours']   = $standard_hours;
                        $log['total_hours']      = $total_hours;
                        $log['overtime_minutes'] = $overtime_minutes;
                    } else {
                        $log['standard_hours']   = 0;
                        $log['total_hours']      = 0;
                        $log['overtime_minutes'] = 0;
                    }
                }

                return new WP_REST_Response([
                    'success' => true,
                    'data'    => $logs
                ], 200);
            }
        } else {
            if (empty($display_name)) {
                return new WP_REST_Response([
                    'success' => false,
                    'message' => 'Thiếu display_name cho vai trò Thợ.'
                ], 400);
            }

            $result = $wpdb->get_row($wpdb->prepare("SELECT employee_id FROM {$wpdb->prefix}checkin_mkt192_staff WHERE display_name = %s", $display_name), ARRAY_A);
            if ($result && !empty($result['employee_id'])) {
                $employee_id = $result['employee_id'];
            } else {
                return new WP_REST_Response([
                    'success' => false,
                    'message' => 'Không tìm thấy employee_id tương ứng với display_name.'
                ], 404);
            }
        }

        $query  = "SELECT * FROM {$wpdb->prefix}checkin_mkt192_checkinlogs WHERE employee_id = %s";
        $params = [$employee_id];

        if (!empty($start_date) && !empty($end_date)) {
            $query .= ' AND checkin_time BETWEEN %s AND %s';
            $params[] = $start_date . ' 00:00:00';
            $params[] = $end_date . ' 23:59:59';
        }

        $query .= ' ORDER BY checkin_time DESC';

        $logs = $wpdb->get_results($wpdb->prepare($query, $params), ARRAY_A);

        foreach ($logs as &$log) {
            if ($log['employee_role'] === 'Thu Ngân') {
                $checkin_time  = strtotime($log['checkin_time']);
                $checkout_time = $log['checkout_time'] ? strtotime($log['checkout_time']) : null;

                if (!$checkout_time) {
                    $log['standard_hours']   = 0;
                    $log['total_hours']      = 0;
                    $log['overtime_minutes'] = 0;
                    continue;
                }

                // Kiểm tra shift_name trước khi query
                $shift = null;
                if (!empty($log['shift'])) {
                    $shift = $wpdb->get_row($wpdb->prepare("
                        SELECT start_time, end_time
                        FROM {$wpdb->prefix}checkin_mkt192_shiftsettings
                        WHERE shift_name = %s
                    ", $log['shift']), ARRAY_A);
                }

                $shift_start = $shift ? strtotime(date('Y-m-d', $checkin_time) . ' ' . $shift['start_time']) : $checkin_time;
                $shift_end   = $shift ? strtotime(date('Y-m-d', $checkin_time) . ' ' . $shift['end_time']) : $checkout_time;

                if ($shift_end < $shift_start) {
                    $shift_end += 86400;
                }

                $start_time = $checkin_time;
                $end_time   = $checkout_time;

                if (strtolower($log['approval_ot'] ?? '') === 'approved') {
                    $end_time = $checkout_time;
                } else {
                    if ($checkin_time > $shift_start) {
                        $start_time = $checkin_time;
                    } else {
                        $start_time = $shift_start;
                    }
                    $end_time = $checkout_time < $shift_end ? $checkout_time : $shift_end;
                }

                $total_hours = 0;
                if ($end_time && $start_time && $end_time > $start_time) {
                    $hours = ($end_time - $start_time) / 3600;
                    if ($hours > 0 && $hours <= 24) {
                        $total_hours = round($hours, 2);
                    }
                }

                $standard_start_time = $checkin_time > $shift_start ? $checkin_time : $shift_start;
                $standard_end_time   = $checkout_time && $checkout_time < $shift_end ? $checkout_time : $shift_end;
                $standard_hours      = 0;
                if ($standard_end_time && $standard_start_time && $standard_end_time > $standard_start_time) {
                    $hours = ($standard_end_time - $standard_start_time) / 3600;
                    if ($hours > 0 && $hours <= 24) {
                        $standard_hours = round($hours, 2);
                    }
                }

                $overtime_minutes = 0;
                if (strtolower($log['approval_ot'] ?? '') === 'approved' && $checkout_time && $shift['end_time']) {
                    $shift_end = strtotime(date('Y-m-d', $checkin_time) . ' ' . $shift['end_time']);
                    if ($shift_end < $shift_start) {
                        $shift_end += 86400;
                    }
                    if ($checkout_time > $shift_end) {
                        $overtime_minutes = round(($checkout_time - $shift_end) / 60);
                    }
                }

                $log['standard_hours']   = $standard_hours;
                $log['total_hours']      = $total_hours;
                $log['overtime_minutes'] = $overtime_minutes;
            } else {
                $log['standard_hours']   = 0;
                $log['total_hours']      = 0;
                $log['overtime_minutes'] = 0;
            }
        }

        return new WP_REST_Response([
            'success' => true,
            'data'    => $logs
        ], 200);
    } catch (Exception $e) {
        file_put_contents(__DIR__ . '/logs/checkin_errors.log', date('Y-m-d H:i:s') . ' - Get employee checkin logs error: ' . $e->getMessage() . "\n", FILE_APPEND);
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Lỗi hệ thống: ' . $e->getMessage()
        ], 500);
    }
}
?>