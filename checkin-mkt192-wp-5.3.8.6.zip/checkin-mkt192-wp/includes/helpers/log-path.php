<?php

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Thư mục ghi nhật ký BỀN, nằm ngoài thư mục plugin.
 *
 * Nhật ký cũ đặt trong `includes/<nhóm>/logs/` nên **bị xoá sạch mỗi lần cập nhật plugin**
 * (WordPress xoá cả thư mục plugin rồi giải nén bản mới). Hai lần điều tra sự cố trên VG
 * (mất link ảnh 18/09/2026, đối soát báo cáo 21/09) đều bế tắc vì lý do này.
 * Nay ghi vào uploads, nơi cập nhật plugin không đụng tới.
 *
 * @param string $context Thường truyền __DIR__ để tự đặt tên nhóm (automation, lark, ...).
 * @return string Đường dẫn thư mục, đã tạo sẵn, không có dấu / ở cuối.
 */
function checkin_mkt192_log_dir($context = '') {
    static $cache = [];

    $group = $context ? basename(rtrim($context, '/\\')) : 'general';
    if (isset($cache[$group])) {
        return $cache[$group];
    }

    $uploads = wp_upload_dir();
    $base    = (!empty($uploads['basedir']) ? $uploads['basedir'] : WP_CONTENT_DIR . '/uploads')
        . '/checkin-mkt192-wp/logs/' . $group;

    if (!is_dir($base)) {
        wp_mkdir_p($base);
        // Chặn truy cập trực tiếp qua trình duyệt
        @file_put_contents(dirname($base) . '/index.php', "<?php\n// Silence is golden.\n");
        @file_put_contents(dirname($base) . '/.htaccess', "Deny from all\n");
    }

    // Không ghi được (phân quyền lạ) thì quay về chỗ cũ để không mất nhật ký
    if (!is_writable($base)) {
        $base = rtrim($context, '/\\') . '/logs';
    }

    $cache[$group] = $base;
    return $base;
}
