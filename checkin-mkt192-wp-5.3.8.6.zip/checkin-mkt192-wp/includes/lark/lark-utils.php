<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Kiểm tra xem Lark có được bật hay không
 *
 * @return bool True nếu Lark được bật, false nếu không
 */
function is_lark_enabled() {
    return get_option('checkin_use_lark', '0') === '1';
}

// Hàm ghi log
function log_lark_untils($message, $data = []) {
    $log_file = checkin_mkt192_log_dir(__DIR__) . '/lark_untils_log.log';
    if (!file_exists(dirname($log_file))) {
        mkdir(dirname($log_file), 0755, true);
    }
    $timestamp = date('Y-m-d H:i:s');
    $log_entry = "[$timestamp] $message\n";
    if (!empty($data)) {
        $log_entry .= 'Data: ' . json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
    }
    $log_entry .= "----------------------------------------\n";
    file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);
}

// Hàm lấy tenant_access_token với cache
function get_lark_tenant_access_token($app_id, $app_secret) {
    // Tạo cache key dựa trên app_id để tránh xung đột giữa các ứng dụng
    $cache_key = 'lark_tenant_access_token_' . md5($app_id);

    // Kiểm tra cache
    $cached_token = get_transient($cache_key);
    if ($cached_token) {
        return $cached_token;
    }

    $url      = 'https://open.larksuite.com/open-apis/auth/v3/tenant_access_token/internal';
    $payload  = ['app_id' => $app_id, 'app_secret' => $app_secret];
    $response = wp_remote_post($url, [
        'headers' => ['Content-Type' => 'application/json; charset=utf-8'],
        'body'    => json_encode($payload),
        'timeout' => 30
    ]);

    if (is_wp_error($response)) {
        log_lark_untils('Lỗi khi lấy tenant_access_token', [
            'error'  => $response->get_error_message(),
            'app_id' => $app_id
        ]);
        return new WP_Error('token_error', 'Lỗi khi lấy tenant_access_token');
    }

    $body = json_decode(wp_remote_retrieve_body($response), true);

    if (isset($body['code']) && $body['code'] === 0) {
        $token  = $body['tenant_access_token'];
        $expire = max(300, $body['expire'] - 300); // Lưu trước khi hết hạn 5 phút
        set_transient($cache_key, $token, $expire);
        return $token;
    }

    log_lark_untils('❌ Token failed', [
        'code'   => $body['code'] ?? -1,
        'msg'    => $body['msg']  ?? 'Unknown',
        'app_id' => $app_id
    ]);
    return new WP_Error('token_error', 'Lỗi khi lấy tenant_access_token: ' . ($body['msg'] ?? 'Unknown error'));
}

/**
 * Get the correct base URL for Lark callbacks
 * Supports ngrok override for local testing
 *
 * @return string Base URL (with no trailing slash)
 */
function get_lark_base_url() {
    // Check if ngrok URL override is defined in wp-config.php
    if (defined('MKT192_NGROK_URL') && MKT192_NGROK_URL) {
        return rtrim(MKT192_NGROK_URL, '/');
    }

    // Use WordPress site URL
    return rtrim(home_url(), '/');
}

/**
 * Get the full callback URL for Lark
 *
 * @return string Full callback URL
 */
function get_lark_callback_url() {
    return get_lark_base_url() . '/wp-json/vg/v1/lark-callback';
}
?>
