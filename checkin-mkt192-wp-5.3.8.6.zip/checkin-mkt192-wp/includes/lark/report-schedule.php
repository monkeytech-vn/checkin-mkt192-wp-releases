<?php

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Giờ chạy của các báo cáo định kỳ: chủ site đặt trong Checkin → Push Notifications (ô "Giờ gửi"),
 * lưu cùng template theo khoá 'schedule' dạng HH:MM giờ Việt Nam (múi giờ WordPress).
 */

/**
 * Giờ đã đặt cho một loại thông báo, rơi về mặc định khi chưa đặt hoặc sai định dạng.
 *
 * @param string $type    Khoá loại thông báo.
 * @param string $default Giờ mặc định 'HH:MM'.
 * @return string 'HH:MM'
 */
function checkin_mkt192_report_schedule_time($type, $default = '23:00') {
    $settings = function_exists('checkin_push_get_notification_settings')
        ? (array)checkin_push_get_notification_settings($type)
        : [];
    $time = trim((string)($settings['schedule'] ?? ''));

    return preg_match('/^([01][0-9]|2[0-3]):[0-5][0-9]$/', $time) ? $time : $default;
}

/**
 * Ngày mà báo cáo định kỳ phải nói về, tính theo giờ chạy đã đặt.
 *
 * WordPress chạy cron nhờ lượt truy cập, mà 23:00 tiệm đã đóng nên hook có thể nổ trễ sang hôm sau.
 * Lúc đó current_time('Y-m-d') là ngày mới (rỗng) chứ không phải ngày vừa qua, nên phải lùi lại một ngày.
 *
 * @param string $type    Khoá loại thông báo.
 * @param string $default Giờ mặc định 'HH:MM'.
 * @return string Y-m-d
 */
function checkin_mkt192_report_target_date($type, $default = '23:00') {
    $time   = checkin_mkt192_report_schedule_time($type, $default);
    $tz     = wp_timezone();
    $now    = new DateTime('now', $tz);
    $target = new DateTime('now', $tz);

    // Giờ gửi rơi vào buổi sáng: báo cáo luôn nói về ngày hôm trước.
    // Giờ gửi buổi chiều tối mà lúc chạy đã qua nửa đêm (giờ hiện tại còn nhỏ hơn giờ gửi) = chạy trễ.
    if ($time < '12:00' || $now->format('H:i') < $time) {
        $target->modify('-1 day');
    }

    return $target->format('Y-m-d');
}

/**
 * Đặt (hoặc đặt lại) lịch chạy hằng ngày cho một hook theo giờ trong template.
 * Gọi được mỗi lần tải trang: chỉ đụng tới cron khi chưa có lịch hoặc chủ site vừa đổi giờ.
 *
 * @param string $hook    Tên hook cron.
 * @param string $type    Khoá loại thông báo.
 * @param string $default Giờ mặc định 'HH:MM'.
 */
function checkin_mkt192_report_ensure_schedule($hook, $type, $default = '23:00') {
    $time   = checkin_mkt192_report_schedule_time($type, $default);
    $option = $hook . '_at';

    if (wp_next_scheduled($hook) && get_option($option) === $time) {
        return;
    }

    while ($timestamp = wp_next_scheduled($hook)) {
        wp_unschedule_event($timestamp, $hook);
    }

    $tz  = wp_timezone();
    $now = new DateTime('now', $tz);
    $at  = DateTime::createFromFormat('Y-m-d H:i:s', $now->format('Y-m-d') . ' ' . $time . ':00', $tz);
    if (!$at) {
        $at = new DateTime('today ' . $default, $tz);
    }
    if ($at <= $now) {
        $at->modify('+1 day');
    }

    wp_schedule_event($at->getTimestamp(), 'daily', $hook);
    update_option($option, $time, false);
}
