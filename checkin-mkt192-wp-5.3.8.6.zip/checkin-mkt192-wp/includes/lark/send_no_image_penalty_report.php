<?php

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

require_once __DIR__ . '/lark-utils.php';
require_once __DIR__ . '/report-schedule.php';

/**
 * Báo cáo cuối ngày (23:00 giờ WP) qua Lark: hoá đơn trong ngày KHÔNG có ảnh khách và KHÔNG có lý do,
 * bỏ khách vãng lai, gom theo THỢ LÀM DỊCH VỤ trên hoá đơn (invoices_data_detail), kèm số tiền dự kiến
 * truy thu theo Cài đặt lương. Dùng đúng bộ luật truy thu không ảnh của module lương
 * (checkin_mkt192_invoice_has_images / _not_image_reasons, skip_guest, valid_reasons, ghi chú "Hệ thống bù")
 * để danh sách báo ở đây trùng với danh sách sẽ bị trừ khi tính lương.
 *
 * Chủ VG yêu cầu 18/09/2026.
 */
class Checkin_MKT192_NoImagePenaltyReport {
    const HOOK               = 'daily_no_image_penalty_report';
    const NOTIFICATION_TYPE  = 'no_image_penalty_report';
    // 00:15 - PHẢI chạy sau cron `daily_reprocess_temp_files` 23:55, vì trong ngày ảnh khách còn nằm ở thư mục
    // temp và cột invoices_data.images chưa có URL chính thức; chạy sớm hơn sẽ báo nhầm gần hết hoá đơn là
    // "không ảnh" (đã xảy ra 18/09/2026). Chủ site đổi được trong Push Notifications.
    const DEFAULT_TIME       = '00:15';
    // Chưa gán bot cho loại mới thì dùng bot "Feedback & Truy thu", rồi bot "Nhắc nhở upload hình"
    const FALLBACK_TYPES     = ['feedback', 'missing_image_reminder'];

    private static function write_log($message, $data = []) {
        $log_file  = checkin_mkt192_log_dir(__DIR__) . '/send_no_image_penalty_report.log';
        $log_entry = '[' . current_time('Y-m-d H:i:s') . "] $message\n";
        if (!empty($data)) {
            $log_entry .= 'Data: ' . json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
        }
        $log_entry .= "----------------------------------------\n";
        @file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);
    }

    /** Đặt lịch theo giờ chủ site chọn trong Push Notifications (mặc định 23:05 giờ Việt Nam). */
    public static function ensure_scheduled() {
        checkin_mkt192_report_ensure_schedule(self::HOOK, self::NOTIFICATION_TYPE, self::DEFAULT_TIME);
    }

    /**
     * Gom vi phạm của một ngày.
     *
     * @param string $date Y-m-d theo giờ WP.
     * @return array {date, total_invoices, violations (số hoá đơn), staff: [name => {ou_id, invoices: [...], penalty_total}], penalty (cấu hình)}
     */
    public static function collect($date) {
        global $wpdb;
        $p = $wpdb->prefix;

        if (!function_exists('checkin_mkt192_salary_settings')) {
            require_once dirname(__DIR__) . '/rest-api/salary-api.php';
        }
        $cfg        = checkin_mkt192_salary_settings(true)['no_image_penalty'] ?? [];
        $skip_guest = !isset($cfg['skip_guest']) || !empty($cfg['skip_guest']);
        $valid      = array_map('mb_strtolower', (array)($cfg['valid_reasons'] ?? []));

        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT invoice_id, customer_name, created_at, total, images, not_image
             FROM {$p}checkin_mkt192_invoices_data
             WHERE DATE(created_at) = %s AND (status IS NULL OR status <> 'cancelled')",
            $date
        )) ?: [];

        $violations = [];
        foreach ($rows as $r) {
            if (checkin_mkt192_invoice_has_images($r->images)) {
                continue;
            }
            $reasons = checkin_mkt192_invoice_not_image_reasons($r->not_image);
            // Ghi chú hệ thống thêm ("Hệ thống bù: thợ đã tích nhưng bug v5.3.4.3 không lưu") = thợ ĐÃ chọn lý do
            if (array_filter($reasons, function ($x) { return mb_stripos($x, 'hệ thống bù') === 0; })) {
                continue;
            }
            $lower_reasons = array_map('mb_strtolower', $reasons);
            // VG lưu tên khách chữ in ("KHÁCH VÃNG LAI") → so không phân biệt hoa thường
            $is_guest = mb_strtolower(trim((string)$r->customer_name)) === 'khách vãng lai'
                || in_array('khách vãng lai', $lower_reasons, true);
            if ($skip_guest && $is_guest) {
                continue;
            }
            if (count(array_intersect($lower_reasons, $valid)) > 0) {
                continue;
            }
            $violations[(string)$r->invoice_id] = $r;
        }

        $out = [
            'date'           => $date,
            'total_invoices' => count($rows),
            'violations'     => count($violations),
            'staff'          => [],
            'penalty'        => $cfg,
        ];
        if (!$violations) {
            return $out;
        }

        // Thợ trên từng hoá đơn: 2 bước, KHÔNG JOIN (VG lệch collation giữa invoices_data và detail)
        $ids   = array_keys($violations);
        $ph    = implode(',', array_fill(0, count($ids), '%s'));
        $lines = $wpdb->get_results($wpdb->prepare(
            "SELECT invoice_id, staff_name, SUM(total) AS total
             FROM {$p}checkin_mkt192_invoices_data_detail
             WHERE invoice_id IN ($ph) AND service_type IN ('service', 'chemical')
             GROUP BY invoice_id, staff_name",
            $ids
        )) ?: [];

        $mode  = $cfg['mode'] ?? 'percent';
        $value = (float)($cfg['value'] ?? 0);
        $staff = [];
        foreach ($lines as $ln) {
            $name = trim((string)$ln->staff_name);
            $inv  = (string)$ln->invoice_id;
            if ($name === '' || !isset($violations[$inv])) {
                continue;
            }
            $base    = (float)$ln->total;
            $penalty = $mode === 'percent' ? round($base * $value / 100) : round($value);
            $r       = $violations[$inv];
            $staff[$name]['invoices'][] = [
                'invoice_id'    => $inv,
                'customer_name' => (string)$r->customer_name,
                'time'          => date('H:i', strtotime((string)$r->created_at)),
                'base'          => $base,
                'penalty'       => $penalty,
            ];
            $staff[$name]['penalty_total'] = ($staff[$name]['penalty_total'] ?? 0) + $penalty;
        }

        // ou_id để @mention trong Lark
        if ($staff) {
            $names = array_keys($staff);
            $ph2   = implode(',', array_fill(0, count($names), '%s'));
            $ous   = $wpdb->get_results($wpdb->prepare(
                "SELECT display_name, ou_id FROM {$p}checkin_mkt192_staff WHERE display_name IN ($ph2)",
                $names
            )) ?: [];
            foreach ($ous as $o) {
                if (isset($staff[$o->display_name])) {
                    $staff[$o->display_name]['ou_id'] = $o->ou_id ?: null;
                }
            }
            ksort($staff, SORT_LOCALE_STRING);
        }

        // Hoá đơn vi phạm nhưng không có dòng dịch vụ/hoá chất (chỉ bán sản phẩm) → không ai bị truy thu, vẫn liệt kê để chủ biết
        $covered = [];
        foreach ($staff as $s) {
            foreach ($s['invoices'] as $i) {
                $covered[$i['invoice_id']] = true;
            }
        }
        $out['unassigned'] = array_values(array_map(function ($r) {
            return ['invoice_id' => (string)$r->invoice_id, 'customer_name' => (string)$r->customer_name];
        }, array_filter($violations, function ($r) use ($covered) {
            return !isset($covered[(string)$r->invoice_id]);
        })));
        $out['staff'] = $staff;
        return $out;
    }

    /**
     * Template (Checkin → Push Notifications → Hoá đơn → "Báo cáo truy thu không ảnh 23:00"): enabled/title/body/roles.
     * Không có API push thì dùng mặc định.
     */
    public static function template() {
        $default = [
            'enabled' => true,
            'title'   => '🧾 Truy thu hoá đơn không ảnh · {date}',
            'body'    => '{violations} hoá đơn / {staff_count} thợ · dự kiến truy thu {total_penalty}đ',
            'roles'    => ['administrator'],
            'schedule' => self::DEFAULT_TIME,
            'stats'   => [
                ['label' => '🧾 Hoá đơn vi phạm', 'value' => '{violations}'],
                ['label' => '✂️ Thợ vi phạm', 'value' => '{staff_count}'],
                ['label' => '📏 Mức truy thu', 'value' => '{penalty_rule}'],
                ['label' => '💸 Dự kiến truy thu', 'value' => '{total_penalty}đ'],
            ],
        ];
        if (!function_exists('checkin_push_get_notification_settings')) {
            return $default;
        }
        $tpl = (array)checkin_push_get_notification_settings(self::NOTIFICATION_TYPE);
        // API bản cũ chưa biết loại này trả tiêu đề chung "Thông báo" → dùng mặc định; body rỗng thì card không có dòng tóm tắt
        if (empty($tpl['title']) || $tpl['title'] === 'Thông báo') {
            $tpl['title'] = $default['title'];
        }
        foreach (['roles', 'stats', 'schedule'] as $key) {
            if (empty($tpl[$key])) {
                $tpl[$key] = $default[$key];
            }
        }
        return $tpl;
    }

    /** Biến cho template từ kết quả collect(). */
    public static function template_vars($data) {
        $total = 0;
        $list  = [];
        foreach ($data['staff'] as $name => $s) {
            $total += (float)($s['penalty_total'] ?? 0);
            $list[] = $name . ' (' . count($s['invoices']) . ')';
        }
        $cfg  = $data['penalty'] ?? [];
        $rule = empty($cfg['enabled'])
            ? 'đang tắt'
            : ((($cfg['mode'] ?? 'percent') === 'percent')
                ? (int)($cfg['value'] ?? 0) . '% giá trị DV/HC'
                : number_format((float)($cfg['value'] ?? 0), 0, ',', '.') . ' đ/HĐ');

        return [
            'date'           => date('d/m/Y', strtotime($data['date'])),
            'total_invoices' => (string)$data['total_invoices'],
            'violations'     => (string)$data['violations'],
            'staff_count'    => (string)count($data['staff']),
            'total_penalty'  => number_format($total, 0, ',', '.'),
            'penalty_rule'   => $rule,
            'staff_list'     => $list ? implode(', ', $list) : 'không có',
        ];
    }

    /** Bảng chỉ số của template sau khi thay biến (bỏ ô thiếu nhãn hoặc giá trị). */
    public static function stats_for_card($tpl, $vars) {
        $out = [];
        foreach ((array)($tpl['stats'] ?? []) as $stat) {
            $label = self::fill((string)($stat['label'] ?? ''), $vars);
            $value = self::fill((string)($stat['value'] ?? ''), $vars);
            if (trim($label) === '' || trim($value) === '') {
                continue;
            }
            $out[] = ['label' => $label, 'value' => $value];
        }
        return $out;
    }

    public static function fill($tpl, $vars) {
        foreach ($vars as $k => $v) {
            $tpl = str_replace('{' . $k . '}', $v, $tpl);
        }
        return $tpl;
    }

    /**
     * Gửi báo cáo ngày $date (mặc định hôm nay theo giờ WP). Luôn gửi, kể cả ngày sạch (card xanh), để chủ biết cron còn sống.
     * Card chi tiết → Lark; tóm tắt (title/body của template) → push cho vai trò đã chọn (nếu push đang bật).
     *
     * @return array {success, message}
     */
    public static function send_report($date = null) {
        // Không truyền ngày = cron chạy: lấy ngày theo giờ đã đặt, phòng khi hook nổ trễ sang hôm sau
        $date = is_string($date) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)
            ? $date
            : checkin_mkt192_report_target_date(self::NOTIFICATION_TYPE, self::DEFAULT_TIME);
        self::write_log("Bắt đầu báo cáo truy thu không ảnh ngày $date");

        $tpl = self::template();
        if (empty($tpl['enabled'])) {
            self::write_log('Template đang tắt trong Push Notifications, bỏ qua');
            return ['success' => false, 'message' => 'Báo cáo đang tắt (Push Notifications)'];
        }

        if (!is_lark_enabled()) {
            self::write_log('Lark chưa được kích hoạt');
            return ['success' => false, 'message' => 'Lark chưa được kích hoạt'];
        }

        require_once __DIR__ . '/class-checkin-mkt192-message-bot-manager.php';
        require_once __DIR__ . '/card-builder.php';
        $bot_manager = Checkin_MKT192_Message_Bot_Manager::get_instance();

        $type = null;
        $bot  = null;
        foreach (array_merge([self::NOTIFICATION_TYPE], self::FALLBACK_TYPES) as $candidate) {
            $bot = $bot_manager->get_bot_by_notification_type($candidate);
            if ($bot) {
                $type = $candidate;
                break;
            }
        }
        if (!$bot) {
            $msg = 'Không có bot Lark nào gán cho ' . self::NOTIFICATION_TYPE . ' (hay feedback / missing_image_reminder)';
            self::write_log($msg);
            return ['success' => false, 'message' => $msg];
        }

        $data = self::collect($date);
        self::write_log('Dữ liệu báo cáo', [
            'bot_type_used'  => $type,
            'bot'            => $bot->bot_name,
            'total_invoices' => $data['total_invoices'],
            'violations'     => $data['violations'],
            'staff'          => array_keys($data['staff']),
        ]);

        $vars  = self::template_vars($data);
        $title = self::fill((string)$tpl['title'], $vars);
        $body  = self::fill((string)$tpl['body'], $vars);

        $card    = build_no_image_penalty_report_card($data, $bot->bot_type, [
            'title'   => $title,
            'summary' => $body,
            'stats'   => self::stats_for_card($tpl, $vars),
        ]);
        $payload = ['msg_type' => 'interactive', 'card' => $card];
        $result  = $bot_manager->send_message($type, null, $payload);

        // Push tóm tắt lên điện thoại cho vai trò đã chọn (không chặn Lark nếu push lỗi)
        if (!empty($tpl['roles']) && function_exists('checkin_push_is_enabled') && checkin_push_is_enabled()
            && function_exists('checkin_push_get_users_by_roles') && function_exists('checkin_push_send_to_users')) {
            $user_ids = checkin_push_get_users_by_roles((array)$tpl['roles']);
            if ($user_ids) {
                $push = checkin_push_send_to_users($user_ids, [
                    'title' => $title,
                    'body'  => $body,
                    'url'   => home_url('/'),
                    'data'  => ['type' => self::NOTIFICATION_TYPE, 'date' => $date],
                ]);
                self::write_log('Push tóm tắt', ['users' => count($user_ids), 'ok' => (bool)$push]);
            }
        }

        if (is_wp_error($result)) {
            self::write_log('Lỗi gửi: ' . $result->get_error_message());
            return ['success' => false, 'message' => $result->get_error_message()];
        }
        if (isset($result['code']) && (int)$result['code'] !== 0) {
            self::write_log('Lark trả lỗi', $result);
            return ['success' => false, 'message' => 'Lark API error: ' . ($result['msg'] ?? 'unknown')];
        }
        self::write_log('Đã gửi báo cáo', ['violations' => $data['violations']]);
        return ['success' => true, 'message' => 'Đã gửi báo cáo truy thu không ảnh ngày ' . $date];
    }
}
