<?php

/**
 * Script fix: Xóa các URL temp trong images/feedback_images
 *
 * Chạy 1 lần để fix các dòng đã bị lỗi khi cronjob cập nhật sai.
 *
 * Cách chạy:
 * - Truy cập: /wp-json/checkin-mkt192/v1/fix-temp-urls
 * - Hoặc: wp eval-file fix-temp-urls.php
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    // Allow running via WP-CLI or REST API
    if (php_sapi_name() !== 'cli') {
        exit('Direct access not allowed');
    }
}

/**
 * Fix temp URLs in invoices table
 */
function fix_temp_urls_in_invoices() {
    global $wpdb;

    $log_file      = checkin_mkt192_log_dir(__DIR__) . '/fix_temp_urls.log';
    $invoice_table = $wpdb->prefix . 'checkin_mkt192_invoices_data';

    // Patterns to remove
    $temp_patterns = ['/temp/', '/temp-feedback-image/'];

    $start_time    = microtime(true);
    $fixed_count   = 0;
    $skipped_count = 0;
    $error_count   = 0;

    file_put_contents($log_file, "\n🚀 Fix temp URLs started at " . date('Y-m-d H:i:s') . "\n", FILE_APPEND);

    // Tìm tất cả invoices có chứa URL temp trong images hoặc image_feedback
    $invoices = $wpdb->get_results("
        SELECT invoice_id, images, image_feedback
        FROM {$invoice_table}
        WHERE images LIKE '%/temp/%'
           OR images LIKE '%/temp-feedback-image/%'
           OR image_feedback LIKE '%/temp/%'
           OR image_feedback LIKE '%/temp-feedback-image/%'
    ");

    if (empty($invoices)) {
        $message = "✅ No invoices with temp URLs found. Nothing to fix.\n";
        file_put_contents($log_file, $message, FILE_APPEND);
        return [
            'success' => true,
            'message' => 'No invoices with temp URLs found',
            'fixed'   => 0,
            'skipped' => 0,
            'errors'  => 0
        ];
    }

    file_put_contents($log_file, '📋 Found ' . count($invoices) . " invoices to process\n", FILE_APPEND);

    foreach ($invoices as $invoice) {
        $invoice_id = $invoice->invoice_id;
        $updates    = [];

        // Process images field
        if (!empty($invoice->images)) {
            $images = json_decode($invoice->images, true);
            if (is_array($images)) {
                $original_count = count($images);

                // Lọc bỏ URL temp
                $cleaned_images = array_filter($images, function($url) use ($temp_patterns) {
                    foreach ($temp_patterns as $pattern) {
                        if (strpos($url, $pattern) !== false) {
                            return false;
                        }
                    }
                    return true;
                });
                $cleaned_images = array_values($cleaned_images);

                if (count($cleaned_images) < $original_count) {
                    $updates['images'] = json_encode($cleaned_images, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                    $removed           = $original_count - count($cleaned_images);
                    file_put_contents($log_file, "  📷 Invoice $invoice_id: Removed $removed temp URLs from images\n", FILE_APPEND);
                }
            }
        }

        // Process image_feedback field
        if (!empty($invoice->image_feedback)) {
            $feedback_images = json_decode($invoice->image_feedback, true);
            if (is_array($feedback_images)) {
                $original_count = count($feedback_images);

                // Lọc bỏ URL temp
                $cleaned_feedback = array_filter($feedback_images, function($url) use ($temp_patterns) {
                    foreach ($temp_patterns as $pattern) {
                        if (strpos($url, $pattern) !== false) {
                            return false;
                        }
                    }
                    return true;
                });
                $cleaned_feedback = array_values($cleaned_feedback);

                if (count($cleaned_feedback) < $original_count) {
                    $updates['image_feedback'] = json_encode($cleaned_feedback, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
                    $removed                   = $original_count - count($cleaned_feedback);
                    file_put_contents($log_file, "  💬 Invoice $invoice_id: Removed $removed temp URLs from image_feedback\n", FILE_APPEND);
                }
            }
        }

        // Update DB if needed
        if (!empty($updates)) {
            $result = $wpdb->update(
                $invoice_table,
                $updates,
                ['invoice_id' => $invoice_id],
                array_fill(0, count($updates), '%s'),
                ['%s']
            );

            if ($result !== false) {
                $fixed_count++;
                file_put_contents($log_file, "  ✅ Invoice $invoice_id: Fixed successfully\n", FILE_APPEND);
            } else {
                $error_count++;
                file_put_contents($log_file, "  ❌ Invoice $invoice_id: Update failed - " . $wpdb->last_error . "\n", FILE_APPEND);
            }
        } else {
            $skipped_count++;
        }
    }

    $execution_time = round(microtime(true) - $start_time, 2);

    $summary = "\n📊 Summary:\n";
    $summary .= "  - Fixed: $fixed_count invoices\n";
    $summary .= "  - Skipped: $skipped_count invoices\n";
    $summary .= "  - Errors: $error_count invoices\n";
    $summary .= "  - Time: {$execution_time}s\n";
    $summary .= '✅ Fix temp URLs completed at ' . date('Y-m-d H:i:s') . "\n";

    file_put_contents($log_file, $summary, FILE_APPEND);

    return [
        'success'        => true,
        'message'        => "Fixed $fixed_count invoices",
        'fixed'          => $fixed_count,
        'skipped'        => $skipped_count,
        'errors'         => $error_count,
        'execution_time' => $execution_time
    ];
}

// Register REST API endpoint
add_action('rest_api_init', function() {
    register_rest_route('checkin-mkt192/v1', '/fix-temp-urls', [
        'methods'  => 'GET',
        'callback' => function() {
            $result = fix_temp_urls_in_invoices();
            return new WP_REST_Response($result, 200);
        },
        'permission_callback' => function() {
            return current_user_can('manage_options');
        }
    ]);
});

// If running via WP-CLI
if (defined('WP_CLI') && WP_CLI) {
    $result = fix_temp_urls_in_invoices();
    WP_CLI::success(print_r($result, true));
}
