<?php
/**
 * Manual Reprocess Images - Optimized Version
 *
 * Chạy thủ công trên trình duyệt để xử lý ảnh với:
 * - Pagination: xử lý từng batch nhỏ tránh timeout
 * - Logging: ghi log vào file để debug
 * - Progress output: hiển thị realtime
 *
 * URL: /wp-content/plugins/checkin-mkt192-wp/includes/automation/manual-reprocess-images.php
 * Params:
 *   - limit: số file xử lý mỗi lần (mặc định 10)
 *   - debug: hiển thị thông tin debug chi tiết
 */

// Start output buffering và flush ngay
ob_implicit_flush(true);
if (ob_get_level()) ob_end_clean();

// Load WordPress
require_once dirname(__FILE__) . '/../../../../../wp-load.php';

// Security check
if (!current_user_can('administrator')) {
    wp_die('Bạn không có quyền truy cập trang này.');
}

// Increase limits
ini_set('memory_limit', '512M');
ini_set('max_execution_time', 300);
set_time_limit(300);

// Logging function
$log_dir = checkin_mkt192_log_dir(__DIR__) . '/';
if (!is_dir($log_dir)) wp_mkdir_p($log_dir);
$log_file = $log_dir . 'manual_reprocess_' . date('Y-m-d') . '.log';

function write_log($msg) {
    global $log_file;
    $entry = '[' . date('H:i:s') . '] ' . $msg . PHP_EOL;
    file_put_contents($log_file, $entry, FILE_APPEND | LOCK_EX);
}

// Params
$limit = isset($_GET['limit']) ? intval($_GET['limit']) : 10;
$limit = max(1, min(50, $limit));
$debug = isset($_GET['debug']);

// Directories
$temp_upload_dir   = WP_CONTENT_DIR . '/uploads/checkin-mkt192-wp/temp/';
$temp_feedback_dir = WP_CONTENT_DIR . '/uploads/checkin-mkt192-wp/temp-feedback-image/';
$processed_dir     = $temp_upload_dir . 'processed/';
$base_upload_dir   = WP_CONTENT_DIR . '/uploads/checkin-mkt192-wp/customer_image/';
$base_upload_url   = WP_CONTENT_URL . '/uploads/checkin-mkt192-wp/customer_image/';

global $wpdb;
$invoice_table = $wpdb->prefix . 'checkin_mkt192_invoices_data';

write_log("=== START: limit=$limit ===");

// Count files
$count_feedback  = is_dir($temp_feedback_dir) ? count(array_diff(scandir($temp_feedback_dir), ['.', '..'])) : 0;
$count_temp      = is_dir($temp_upload_dir) ? count(array_diff(scandir($temp_upload_dir), ['.', '..', 'processed'])) : 0;
$count_processed = is_dir($processed_dir) ? count(array_diff(scandir($processed_dir), ['.', '..'])) : 0;

write_log("Files: feedback=$count_feedback, temp=$count_temp, processed=$count_processed");

// Stats
$stats = [
    'json_ok'   => 0, 'json_fail' => 0,
    'orphan_ok' => 0, 'orphan_fail' => 0, 'orphan_skip' => 0
];
$results = [];

// ============================================================================
// Helper: Convert image to WebP
// ============================================================================
function convert_to_webp($source_path, $dest_path) {
    $ext   = strtolower(pathinfo($source_path, PATHINFO_EXTENSION));
    $image = @imagecreatefromstring(file_get_contents($source_path));

    if (!$image) return false;

    // Fix EXIF orientation
    if (function_exists('exif_read_data') && in_array($ext, ['jpg', 'jpeg'])) {
        $exif = @exif_read_data($source_path);
        if ($exif && isset($exif['Orientation'])) {
            switch ($exif['Orientation']) {
                case 3: $image = imagerotate($image, 180, 0); break;
                case 6: $image = imagerotate($image, -90, 0); break;
                case 8: $image = imagerotate($image, 90, 0); break;
            }
        }
    }

    $result = @imagewebp($image, $dest_path, 80);
    imagedestroy($image);
    return $result;
}

// ============================================================================
// PHẦN 1: Xử lý JSON files (limit/2)
// ============================================================================
$json_limit = ceil($limit / 2);
$json_files = array_merge(
    glob($temp_feedback_dir . 'temp_*.json') ?: [],
    glob($temp_upload_dir . 'temp_*.json') ?: [],
    glob($processed_dir . 'temp_*.json') ?: []
);
$json_files = array_slice($json_files, 0, $json_limit);

write_log('Processing ' . count($json_files) . ' JSON files');

foreach ($json_files as $json_file) {
    $filename = basename($json_file);
    $report   = ["📄 <b>$filename</b>"];

    write_log("JSON: $filename");

    $data = @json_decode(file_get_contents($json_file), true);
    if (!$data || empty($data['customer_id'])) {
        $report[] = '❌ Invalid';
        $stats['json_fail']++;
        $results[] = implode(' | ', $report);
        write_log('  FAIL: Invalid JSON or missing customer_id');
        continue;
    }

    $customer_id = $data['customer_id'];
    $invoice_id  = $data['invoice_id'] ?? null;
    $filenames   = array_unique($data['filenames'] ?? []);
    $is_feedback = $data['is_feedback'] ?? (strpos($filename, 'feedback') !== false);
    $field_name  = $is_feedback ? 'image_feedback' : 'images';

    $customer_dir = $base_upload_dir . $customer_id . '/';
    $customer_url = $base_upload_url . $customer_id . '/';

    if (!is_dir($customer_dir)) wp_mkdir_p($customer_dir);

    $converted_urls = [];
    $all_processed  = true;

    foreach ($filenames as $orig) {
        $ext  = strtolower(pathinfo($orig, PATHINFO_EXTENSION));
        $webp = str_replace(".$ext", '.webp', $orig);
        $dest = $customer_dir . $webp;

        // Tìm source
        $source = null;
        foreach ([$processed_dir, $temp_feedback_dir, $temp_upload_dir] as $dir) {
            if (file_exists($dir . $orig)) {
                $source = $dir . $orig;
                break;
            }
        }

        // Đã có?
        if (file_exists($dest)) {
            $converted_urls[] = $customer_url . $webp;
            if ($source) @unlink($source);
            write_log("  $orig: exists");
            continue;
        }

        if (!$source) {
            $all_processed = false;
            write_log("  $orig: not found");
            continue;
        }

        // Convert
        if (convert_to_webp($source, $dest)) {
            $converted_urls[] = $customer_url . $webp;
            @unlink($source);
            write_log("  $orig: converted");
        } else {
            $all_processed = false;
            write_log("  $orig: convert failed");
        }
    }

    // Update DB
    if (!empty($converted_urls) && $invoice_id) {
        $current = $wpdb->get_var($wpdb->prepare(
            "SELECT $field_name FROM $invoice_table WHERE invoice_id = %s",
            $invoice_id
        ));
        $arr                      = $current ? json_decode($current, true) : [];
        if (!is_array($arr)) $arr = [];

        // Filter temp URLs
        $arr = array_filter($arr, function($u) {
            return strpos($u, '/temp/') === false && strpos($u, '/temp-feedback-image/') === false;
        });

        $arr = array_merge($arr, $converted_urls);
        $arr = array_unique($arr);

        $wpdb->update(
            $invoice_table,
            [$field_name  => json_encode(array_values($arr), JSON_UNESCAPED_SLASHES)],
            ['invoice_id' => $invoice_id]
        );
        write_log('  DB updated: ' . count($converted_urls) . ' urls');
    }

    // Delete JSON if all processed
    if ($all_processed && count($converted_urls) == count($filenames)) {
        @unlink($json_file);
        $report[] = "✅ $customer_id (" . count($converted_urls) . ' imgs)';
        $stats['json_ok']++;
        write_log('  SUCCESS');
    } else {
        $report[] = '⚠️ Partial: ' . count($converted_urls) . '/' . count($filenames);
        $stats['json_fail']++;
        write_log('  PARTIAL');
    }

    $results[] = implode(' | ', $report);
}

// ============================================================================
// PHẦN 2: Xử lý Orphan images (limit/2)
// ============================================================================
$orphan_limit = $limit - count($json_files);
$image_exts   = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'JPG', 'JPEG', 'PNG'];
$orphan_files = [];

foreach ($image_exts as $ext) {
    $orphan_files = array_merge(
        $orphan_files,
        glob($temp_feedback_dir . "*.$ext") ?: [],
        glob($temp_upload_dir . "*.$ext") ?: [],
        glob($processed_dir . "*.$ext") ?: []
    );
}

// Filter những file đã trong JSON
$json_img_list = [];
foreach ($json_files as $jf) {
    if (file_exists($jf)) {
        $d = @json_decode(file_get_contents($jf), true);
        if ($d && isset($d['filenames'])) {
            $json_img_list = array_merge($json_img_list, $d['filenames']);
        }
    }
}
$orphan_files = array_filter($orphan_files, function($p) use ($json_img_list) {
    return !in_array(basename($p), $json_img_list);
});
$orphan_files = array_slice(array_values($orphan_files), 0, $orphan_limit);

write_log('Processing ' . count($orphan_files) . ' orphan images');

foreach ($orphan_files as $orphan_path) {
    $orphan_name = basename($orphan_path);
    $report      = ["🖼️ <b>$orphan_name</b>"];

    write_log("Orphan: $orphan_name");

    // Parse filename
    $clean     = preg_replace('/^(temp_feedback_|feedback_|temp_)/i', '', $orphan_name);
    $name_only = pathinfo($clean, PATHINFO_FILENAME);
    $parts     = explode('_', $name_only);

    $customer_id = null;
    $invoice_id  = null;

    // Tìm customer_id
    if (!empty($parts[0])) {
        if (preg_match('/^(KH|VG)\d+$/i', $parts[0])) {
            $customer_id = strtoupper($parts[0]);
        } elseif (preg_match('/^\d{10}$/', $parts[0])) {
            $customer_id = $parts[0];
        }
    }

    // Tìm invoice_id hoặc date
    if ($customer_id && count($parts) > 1) {
        foreach (array_slice($parts, 1, 2) as $p) {
            // Date YYYYMMDD
            if (preg_match('/^(\d{8})$/', $p)) {
                $df  = substr($p, 0, 4) . '-' . substr($p, 4, 2) . '-' . substr($p, 6, 2);
                $inv = $wpdb->get_var($wpdb->prepare(
                    "SELECT invoice_id FROM $invoice_table WHERE customer_id = %s AND DATE(created_at) = %s ORDER BY created_at DESC LIMIT 1",
                    $customer_id, $df
                ));
                if ($inv) { $invoice_id = $inv; break; }
            }
            // Timestamp (seconds or milliseconds)
            elseif (preg_match('/^(\d{10}|\d{13})$/', $p)) {
                $ts = floatval($p);
                if ($ts > 1000000000000) {
                    $ts = intval($ts / 1000);
                } else {
                    $ts = intval($ts);
                }
                if ($ts >= 1500000000 && $ts <= 2000000000) {
                    $df = date('Y-m-d', $ts);
                    $inv = $wpdb->get_var($wpdb->prepare(
                        "SELECT invoice_id FROM $invoice_table WHERE customer_id = %s AND DATE(created_at) = %s ORDER BY created_at DESC LIMIT 1",
                        $customer_id, $df
                    ));
                    if ($inv) { $invoice_id = $inv; break; }

                    // Fallback to range search
                    $start_range = date('Y-m-d H:i:s', $ts - 86400 * 2);
                    $end_range = date('Y-m-d H:i:s', $ts + 86400 * 2);
                    $inv = $wpdb->get_var($wpdb->prepare(
                        "SELECT invoice_id FROM $invoice_table WHERE customer_id = %s AND created_at BETWEEN %s AND %s ORDER BY created_at DESC LIMIT 1",
                        $customer_id, $start_range, $end_range
                    ));
                    if ($inv) { $invoice_id = $inv; break; }
                }

                // If not matching timestamp query, fallback to direct invoice_id check
                $exists = $wpdb->get_var($wpdb->prepare(
                    "SELECT invoice_id FROM $invoice_table WHERE invoice_id = %s LIMIT 1",
                    $p
                ));
                if ($exists) { $invoice_id = $p; break; }
            }
            // Invoice ID (any other 11 or 12 digit format)
            elseif (preg_match('/^(\d{10,13})$/', $p)) {
                $exists = $wpdb->get_var($wpdb->prepare(
                    "SELECT invoice_id FROM $invoice_table WHERE invoice_id = %s LIMIT 1",
                    $p
                ));
                if ($exists) { $invoice_id = $p; break; }
            }
        }
    }

    // Fallback: tìm từ invoice_id
    if (!$customer_id) {
        foreach ($parts as $p) {
            if (preg_match('/^(\d{10,13})$/', $p)) {
                $cust = $wpdb->get_var($wpdb->prepare(
                    "SELECT customer_id FROM $invoice_table WHERE invoice_id = %s LIMIT 1",
                    $p
                ));
                if ($cust) {
                    $customer_id = $cust;
                    $invoice_id  = $p;
                    break;
                }
            }
        }
    }

    if (!$customer_id) {
        $report[] = '⚠️ Skip (no customer)';
        $stats['orphan_skip']++;
        $results[] = implode(' | ', $report);
        write_log('  SKIP: no customer_id');
        continue;
    }

    write_log("  Found: customer=$customer_id, invoice=" . ($invoice_id ?: 'N/A'));

    // Convert
    $ext          = strtolower(pathinfo($orphan_name, PATHINFO_EXTENSION));
    $webp_name    = str_replace(".$ext", '.webp', $orphan_name);
    $customer_dir = $base_upload_dir . $customer_id . '/';
    $customer_url = $base_upload_url . $customer_id . '/';
    $dest         = $customer_dir . $webp_name;

    $is_feedback = strpos($orphan_path, 'temp-feedback') !== false;
    $field_name  = $is_feedback ? 'image_feedback' : 'images';

    if (!is_dir($customer_dir)) wp_mkdir_p($customer_dir);

    // Already exists?
    if (file_exists($dest)) {
        @unlink($orphan_path);
        $report[] = "✅ Exists → $customer_id";
        $stats['orphan_ok']++;
        $results[] = implode(' | ', $report);
        write_log('  EXISTS');
        continue;
    }

    // Convert
    if (convert_to_webp($orphan_path, $dest)) {
        @unlink($orphan_path);

        // Update DB
        if ($invoice_id) {
            $current = $wpdb->get_var($wpdb->prepare(
                "SELECT $field_name FROM $invoice_table WHERE invoice_id = %s",
                $invoice_id
            ));
            $arr                      = $current ? json_decode($current, true) : [];
            if (!is_array($arr)) $arr = [];

            $new_url = $customer_url . $webp_name;
            if (!in_array($new_url, $arr)) {
                $arr[] = $new_url;
                $wpdb->update(
                    $invoice_table,
                    [$field_name  => json_encode($arr, JSON_UNESCAPED_SLASHES)],
                    ['invoice_id' => $invoice_id]
                );
            }
        }

        $report[] = "✅ → $customer_id";
        $stats['orphan_ok']++;
        write_log('  SUCCESS');
    } else {
        $report[] = '❌ Convert fail';
        $stats['orphan_fail']++;
        write_log('  FAIL: convert error');
    }

    $results[] = implode(' | ', $report);
}

$total_remaining = max(0, $count_feedback + $count_temp + $count_processed
    - $stats['json_ok'] - $stats['orphan_ok'] - $stats['orphan_skip']);

write_log("=== END: json_ok={$stats['json_ok']}, orphan_ok={$stats['orphan_ok']}, remaining~$total_remaining ===");

// ============================================================================
// OUTPUT
// ============================================================================
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Reprocess Images</title>
    <style>
    body {
        font-family: Arial, sans-serif;
        padding: 20px;
        background: #f5f5f5;
        font-size: 14px
    }

    .container {
        max-width: 900px;
        margin: 0 auto
    }

    h1 {
        color: #333;
        border-bottom: 2px solid #0073aa;
        padding-bottom: 10px;
        font-size: 24px
    }

    .stats {
        display: flex;
        gap: 10px;
        margin: 15px 0;
        flex-wrap: wrap
    }

    .stat {
        background: #fff;
        padding: 10px 15px;
        border-radius: 6px;
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        text-align: center
    }

    .stat .num {
        font-size: 28px;
        font-weight: bold
    }

    .stat.ok .num {
        color: #46b450
    }

    .stat.err .num {
        color: #dc3232
    }

    .stat.warn .num {
        color: #ffb900
    }

    .stat.info .num {
        color: #0073aa
    }

    .stat .lbl {
        font-size: 11px;
        color: #666
    }

    .form {
        background: #fff;
        padding: 15px;
        border-radius: 6px;
        margin: 15px 0
    }

    .btn {
        display: inline-block;
        padding: 8px 16px;
        background: #0073aa;
        color: #fff;
        text-decoration: none;
        border-radius: 4px;
        border: none;
        cursor: pointer;
        margin-right: 5px
    }

    .btn:hover {
        background: #005a87
    }

    .btn.sec {
        background: #666
    }

    .results {
        margin-top: 15px
    }

    .item {
        background: #fff;
        padding: 10px;
        margin: 5px 0;
        border-radius: 4px;
        border-left: 3px solid #0073aa
    }

    .item.debug {
        border-left-color: #9b59b6;
        background: #f9f4fc
    }

    .empty {
        text-align: center;
        padding: 30px;
        color: #666;
        background: #fff;
        border-radius: 6px
    }
    </style>
</head>

<body>
    <div class="container">
        <h1>🖼️ Reprocess Images</h1>

        <div class="form">
            <form method="get" style="display:inline">
                <label>Limit:</label>
                <select name="limit">
                    <?php foreach([5,10,20,30,50] as $l): ?>
                    <option value="<?php echo $l; ?>" <?php echo $limit == $l?'selected':''; ?>><?php echo $l; ?>
                    </option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="btn">▶ Chạy</button>
            </form>
            <a href="?limit=<?php echo $limit; ?>&debug=1" class="btn sec">🔍 Debug</a>
            <a href="<?php echo admin_url(); ?>" class="btn sec">←
                Admin</a>
        </div>

        <div class="stats">
            <div class="stat ok">
                <div class="num">
                    <?php echo $stats['json_ok']; ?>
                </div>
                <div class="lbl">JSON OK</div>
            </div>
            <div class="stat err">
                <div class="num">
                    <?php echo $stats['json_fail']; ?>
                </div>
                <div class="lbl">JSON Fail</div>
            </div>
            <div class="stat ok">
                <div class="num">
                    <?php echo $stats['orphan_ok']; ?>
                </div>
                <div class="lbl">Orphan OK</div>
            </div>
            <div class="stat err">
                <div class="num">
                    <?php echo $stats['orphan_fail']; ?>
                </div>
                <div class="lbl">Orphan Fail</div>
            </div>
            <div class="stat warn">
                <div class="num">
                    <?php echo $stats['orphan_skip']; ?>
                </div>
                <div class="lbl">Skip</div>
            </div>
            <div class="stat info">
                <div class="num"><?php echo $total_remaining; ?>
                </div>
                <div class="lbl">Còn lại ~</div>
            </div>
        </div>

        <?php if ($debug): ?>
        <div class="item debug">
            <b>📊 Thư mục:</b><br>
            temp-feedback: <?php echo $count_feedback; ?> files
            (<?php echo is_dir($temp_feedback_dir)?'✅':'❌'; ?>)<br>
            temp: <?php echo $count_temp; ?> files<br>
            processed: <?php echo $count_processed; ?> files<br>
            <b>📝 Log:</b> <?php echo $log_file; ?>
        </div>
        <?php endif; ?>

        <div class="results">
            <?php if (empty($results)): ?>
            <div class="empty">✅ Không có file cần xử lý!</div>
            <?php else: ?>
            <?php foreach ($results as $r): ?>
            <div class="item"><?php echo $r; ?></div>
            <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <?php if ($total_remaining > 0): ?>
        <p style="margin-top:20px">
            <a href="?limit=<?php echo $limit; ?>" class="btn">🔄
                Chạy tiếp (còn ~<?php echo $total_remaining; ?>)</a>
        </p>
        <?php endif; ?>

    </div>
</body>

</html>