<?php

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

require_once dirname(__FILE__, 2) . '/helpers/class-checkin-mkt192-invoice-images.php';

/**
 * Class xử lý tải và chuyển đổi hình ảnh khách hàng.
 *
 * Chiến lược lưu trữ:
 * - PRIMARY: Chỉ cập nhật invoice.images (JSON array URLs)
 * - REMOVED: Không còn cập nhật customer_data.customer_images
 * - REMOVED: Không còn insert vào bảng wp_checkin_mkt192_customer_image
 *
 * Lý do: Đơn giản hóa logic, ảnh gắn liền với invoice, không duplicate data.
 */
class Checkin_MKT192_ImageUpload {
    /**
     * 🚀 MODERN Cronjob - Process images from metadata JSON files
     *
     * Process:
     * 1. Read metadata JSON files (meta_*.json)
     * 2. Find corresponding image file
     * 3. Convert to WebP format
     * 4. Move to customer folder
     * 5. Update invoice.images in DB
     * 6. Clean up temp files
     */
    public static function upload_customer_image() {
        $cron_id  = uniqid();
        $log_file = checkin_mkt192_log_dir(__DIR__) . '/upload_customer_image.log';
        ini_set('log_errors', 1);
        ini_set('error_log', $log_file);
        ini_set('memory_limit', '512M');
        set_time_limit(0);

        $start_time        = microtime(true);
        $temp_upload_dir   = WP_CONTENT_DIR . '/uploads/checkin-mkt192-wp/temp/';
        $temp_feedback_dir = WP_CONTENT_DIR . '/uploads/checkin-mkt192-wp/temp-feedback-image/';
        $processed_dir     = WP_CONTENT_DIR . '/uploads/checkin-mkt192-wp/temp/processed/';
        $base_upload_dir   = WP_CONTENT_DIR . '/uploads/checkin-mkt192-wp/customer_image/';
        $base_upload_url   = WP_CONTENT_URL . '/uploads/checkin-mkt192-wp/customer_image/';

        // Tạo thư mục processed
        if (!is_dir($processed_dir)) {
            wp_mkdir_p($processed_dir);
        }

        // Lấy danh sách JSON files từ cả 2 thư mục
        // API tạo file temp_*.json, không phải meta_*.json
        $customer_temp_files = glob($temp_upload_dir . 'temp_*.json');
        $feedback_temp_files = glob($temp_feedback_dir . 'temp_*.json');
        $temp_files          = array_merge($customer_temp_files ?: [], $feedback_temp_files ?: []);

        if (empty($temp_files)) {
            file_put_contents($log_file, "✅ [$cron_id] No temp files. Exiting.\n", FILE_APPEND);
            return;
        }

        // Xử lý tối đa 10 file mỗi lần (vì giờ upload song song)
        $temp_files = array_slice($temp_files, 0, 10);
        file_put_contents($log_file, "🚀 Cronjob [$cron_id] started at " . date('Y-m-d H:i:s') . ', processing ' . count($temp_files) . " files\n", FILE_APPEND);

        $success_count = 0;
        $failure_count = 0;

        global $wpdb;
        $invoice_table = $wpdb->prefix . 'checkin_mkt192_invoices_data';

        foreach ($temp_files as $temp_file) {
            $file_start = microtime(true);

            // Đọc metadata từ temp_*.json
            $metadata = json_decode(file_get_contents($temp_file), true);
            if (!$metadata) {
                file_put_contents($log_file, "❌ Invalid JSON: $temp_file\n", FILE_APPEND);
                $failure_count++;
                continue;
            }

            $customer_id = $metadata['customer_id'];
            $invoice_id  = $metadata['invoice_id']  ?? null;
            $filenames   = $metadata['filenames']   ?? []; // Mảng tên file
            $is_feedback = $metadata['is_feedback'] ?? false;

            // Xác định thư mục nguồn
            $source_dir = $is_feedback ? $temp_feedback_dir : $temp_upload_dir;

            // Tạo thư mục customer
            $customer_upload_dir = $base_upload_dir . $customer_id . '/';
            $customer_upload_url = $base_upload_url . $customer_id . '/';

            if (!is_dir($customer_upload_dir)) {
                if (!wp_mkdir_p($customer_upload_dir)) {
                    file_put_contents($log_file, "❌ Failed to create dir: $customer_upload_dir\n", FILE_APPEND);
                    $failure_count++;
                    continue;
                }
            }

            file_put_contents($log_file, '🔄 Processing ' . count($filenames) . " files for customer $customer_id (feedback: " . ($is_feedback ? 'yes' : 'no') . ")\n", FILE_APPEND);

            $converted_urls    = [];
            $processed_files   = [];
            $all_files_success = true;

            // Xử lý từng file trong mảng filenames
            foreach ($filenames as $filename) {
                $source_file = $source_dir . $filename;

                // Kiểm tra file ảnh tồn tại
                if (!file_exists($source_file)) {
                    file_put_contents($log_file, "  ❌ Image not found: $filename\n", FILE_APPEND);
                    continue; // Bỏ qua file này, tiếp tục xử lý file khác
                }

                // Convert sang WebP
                $original_extension = pathinfo($filename, PATHINFO_EXTENSION);
                $webp_filename      = str_replace('.' . $original_extension, '.webp', $filename);
                $final_path         = $customer_upload_dir . $webp_filename;

                // Bỏ qua nếu file WebP đã tồn tại
                if (file_exists($final_path)) {
                    file_put_contents($log_file, "  ✔ Skipped (exists): $webp_filename\n", FILE_APPEND);
                    $converted_urls[]  = $customer_upload_url . $webp_filename;
                    $processed_files[] = $filename;
                    continue;
                }

                // Convert image
                try {
                    $image = false;
                    switch (strtolower($original_extension)) {
                        case 'jpg':
                        case 'jpeg':
                            $image = imagecreatefromjpeg($source_file);
                            break;
                        case 'png':
                            $image = imagecreatefrompng($source_file);
                            break;
                        case 'gif':
                            $image = imagecreatefromgif($source_file);
                            break;
                        case 'webp':
                            $image = imagecreatefromwebp($source_file);
                            break;
                        default:
                            file_put_contents($log_file, "  ❌ Unsupported format: $filename\n", FILE_APPEND);
                            continue 2;
                    }

                    if (!$image) {
                        file_put_contents($log_file, "  ❌ Cannot load image: $filename\n", FILE_APPEND);
                        continue;
                    }

                    // Fix EXIF orientation
                    if (function_exists('exif_read_data') && in_array(strtolower($original_extension), ['jpg', 'jpeg'])) {
                        $exif = @exif_read_data($source_file);
                        if ($exif && isset($exif['Orientation'])) {
                            $orientation = $exif['Orientation'];
                            switch ($orientation) {
                                case 3:
                                    $image = imagerotate($image, 180, 0);
                                    break;
                                case 6:
                                    $image = imagerotate($image, -90, 0);
                                    break;
                                case 8:
                                    $image = imagerotate($image, 90, 0);
                                    break;
                            }
                            file_put_contents($log_file, "    ✔ Fixed EXIF orientation: $orientation\n", FILE_APPEND);
                        }
                    }

                    // Save as WebP
                    if (!imagewebp($image, $final_path, 80)) {
                        imagedestroy($image);
                        file_put_contents($log_file, "  ❌ Failed to convert: $filename\n", FILE_APPEND);
                        continue;
                    }

                    imagedestroy($image);
                    $converted_urls[]  = $customer_upload_url . $webp_filename;
                    $processed_files[] = $filename;
                    file_put_contents($log_file, "  ✔ Converted to WebP: $webp_filename\n", FILE_APPEND);

                } catch (Exception $e) {
                    file_put_contents($log_file, "  ❌ Exception for $filename: {$e->getMessage()}\n", FILE_APPEND);
                    continue;
                }
            }

            // Cập nhật DB nếu có file đã convert thành công.
            // Dùng helper atomic (row lock) để không giẫm lên upload API đang chạy song song:
            // - Thay URL temp bằng URL WebP mới ($strip_temp = true)
            // - Giữ nguyên các URL WebP đã có từ các lần convert trước
            if (!empty($converted_urls) && $invoice_id) {
                $field_name  = $is_feedback ? Checkin_MKT192_Invoice_Images::FIELD_FEEDBACK : Checkin_MKT192_Invoice_Images::FIELD_IMAGES;
                $final_list  = Checkin_MKT192_Invoice_Images::add_urls($invoice_id, $converted_urls, $field_name, true);

                if ($final_list !== false) {
                    if ($is_feedback) {
                        Checkin_MKT192_Invoice_Images::sync_feedback_table($invoice_id, $final_list);
                    }
                    file_put_contents($log_file, "  ✔ Updated invoice $invoice_id ({$field_name}) with " . count($converted_urls) . " images\n", FILE_APPEND);
                } else {
                    file_put_contents($log_file, "  ❌ Failed to update invoice $invoice_id: " . $wpdb->last_error . "\n", FILE_APPEND);
                    $all_files_success = false;
                }
            }

            // XÓA file ảnh gốc sau khi đã convert thành công sang WebP
            // (không cần giữ lại vì đã có bản WebP trong customer folder)
            foreach ($processed_files as $filename) {
                $source_file = $source_dir . $filename;
                if (file_exists($source_file)) {
                    @unlink($source_file);
                    file_put_contents($log_file, "  🗑️ Deleted source: $filename\n", FILE_APPEND);
                }
            }

            $file_duration   = round((microtime(true) - $file_start) * 1000, 1);
            $processed_count = count($processed_files);
            $total_count     = count($filenames);
            $pending_count   = $total_count - $processed_count;

            // CHỈ xóa JSON nếu TẤT CẢ file đã xử lý thành công VÀ DB đã cập nhật OK.
            // Nếu DB update fail, giữ JSON (move sang processed/) để reprocess cuối ngày
            // re-link URL WebP vào invoice — tránh mất link vĩnh viễn.
            if ($pending_count === 0 && $all_files_success) {
                // Tất cả đã xử lý → xóa JSON
                @unlink($temp_file);
                file_put_contents($log_file, "✅ Completed $processed_count/$total_count files in {$file_duration}ms (JSON deleted)\n", FILE_APPEND);
            } else {
                // Còn file chưa xử lý (hoặc DB update fail) → update JSON và move sang processed/
                // Khi DB fail: giữ cả các file đã convert để reprocess re-link URL vào invoice
                $pending_files                 = $all_files_success ? array_diff($filenames, $processed_files) : $filenames;
                $updated_metadata              = $metadata;
                $updated_metadata['filenames'] = array_values($pending_files);
                $updated_metadata['urls']      = array_filter($metadata['urls'] ?? [], function($url) use ($pending_files) {
                    foreach ($pending_files as $file) {
                        if (strpos($url, pathinfo($file, PATHINFO_FILENAME)) !== false) {
                            return true;
                        }
                    }
                    return false;
                });
                $updated_metadata['urls']              = array_values($updated_metadata['urls']);
                $updated_metadata['partial_processed'] = true;
                $updated_metadata['processed_at']      = current_time('mysql');

                // Di chuyển JSON sang processed/ folder để reprocess cuối ngày
                $processed_json = $processed_dir . basename($temp_file);
                file_put_contents($processed_json, json_encode($updated_metadata, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
                @unlink($temp_file);

                file_put_contents($log_file, "⚠️ Partial: $processed_count/$total_count files in {$file_duration}ms ($pending_count pending → moved to processed/)\n", FILE_APPEND);
            }

            if ($processed_count > 0) {
                $success_count += $processed_count;
            }
            if ($pending_count > 0) {
                $failure_count += $pending_count;
            }
        }

        // Ghi log và gửi báo cáo qua Lark
        $execution_time = microtime(true) - $start_time;
        file_put_contents($log_file, "✅ Cronjob [$cron_id] finished at " . date('Y-m-d H:i:s') . " — took {$execution_time}s\n", FILE_APPEND);
        file_put_contents($log_file, "📊 Summary: $success_count success, $failure_count failed\n\n", FILE_APPEND);

        $report_message = "📊 *Báo cáo upload ảnh [$cron_id]*\n";
        $report_message .= '🕒 *Thời gian*: ' . date('Y-m-d H:i:s') . "\n";
        $report_message .= '⏱ *Thời gian xử lý*: ' . number_format($execution_time, 2) . " giây\n";
        $report_message .= "📊 *Kết quả*: $success_count đồng bộ, $failure_count lỗi\n";

        // Gửi thông báo qua Bot Manager
        require_once plugin_dir_path(__FILE__) . '../lark/class-checkin-mkt192-message-bot-manager.php';
        $bot_manager = Checkin_MKT192_Message_Bot_Manager::get_instance();

        $result = $bot_manager->send_message('image_processing', $report_message, null);

        if (is_wp_error($result)) {
            file_put_contents($log_file, '❌ Failed to send notification via Bot Manager: ' . $result->get_error_message() . "\n", FILE_APPEND);
        } else if (isset($result['code']) && $result['code'] == 0) {
            file_put_contents($log_file, "✔ Gửi báo cáo Lark OK via Bot Manager\n", FILE_APPEND);
        } else {
            $error_msg = isset($result['msg']) ? $result['msg'] : 'Unknown error';
            file_put_contents($log_file, "❌ Bot Manager returned error: $error_msg\n", FILE_APPEND);
        }
    }
}
?>
