<?php

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

require_once dirname(__FILE__, 2) . '/helpers/class-checkin-mkt192-invoice-images.php';

/**
 * Class xử lý tái xử lý các file tạm (JSON và hình ảnh).
 *
 * Chạy cuối ngày (16:55) để:
 * 1. Quét file JSON còn sót ở temp/ (chưa được cronjob chạm đến)
 * 2. Quét file JSON ở processed/ (đã xử lý một phần)
 * 3. Xử lý các file ảnh orphan (không có JSON)
 */
class Checkin_MKT192_ReprocessTempFiles {
    /**
     * Tái xử lý các file JSON tạm để chuyển đổi và lưu trữ hình ảnh.
     */
    public static function reprocess_temp_files() {
        $cron_id  = uniqid();
        $log_file = checkin_mkt192_log_dir(__DIR__) . '/reprocess_temp_files.log';
        ini_set('log_errors', 1);
        ini_set('error_log', $log_file);
        ini_set('memory_limit', '512M');
        set_time_limit(0);

        $start_time        = microtime(true);
        $temp_upload_dir   = WP_CONTENT_DIR . '/uploads/checkin-mkt192-wp/temp/';
        $temp_feedback_dir = WP_CONTENT_DIR . '/uploads/checkin-mkt192-wp/temp-feedback-image/';
        $processed_dir     = $temp_upload_dir . 'processed/';
        $base_upload_dir   = WP_CONTENT_DIR . '/uploads/checkin-mkt192-wp/customer_image/';
        $base_upload_url   = WP_CONTENT_URL . '/uploads/checkin-mkt192-wp/customer_image/';

        if (!is_dir($processed_dir)) {
            wp_mkdir_p($processed_dir);
            file_put_contents($log_file, "Created processed directory: $processed_dir\n", FILE_APPEND);
        }

        // 🔧 FIX: Quét CẢ temp/ và processed/ để không bỏ sót file
        $temp_json_files      = glob($temp_upload_dir . 'temp_*.json') ?: [];
        $feedback_json_files  = glob($temp_feedback_dir . 'temp_*.json') ?: [];
        $processed_json_files = glob($processed_dir . 'temp_*.json') ?: [];
        $json_files           = array_merge($temp_json_files, $feedback_json_files, $processed_json_files);
        $json_files           = array_unique($json_files); // Tránh duplicate

        $total_files = count($json_files);
        file_put_contents($log_file, "\n🔄 Cronjob reprocess [$cron_id] started at " . date('Y-m-d H:i:s') . "\n", FILE_APPEND);
        file_put_contents($log_file, '📊 Found: ' . count($temp_json_files) . ' temp, ' . count($feedback_json_files) . ' feedback, ' . count($processed_json_files) . " processed = $total_files total\n", FILE_APPEND);

        global $wpdb;
        $invoice_table = $wpdb->prefix . 'checkin_mkt192_invoices_data';

        $recovered = 0;
        $deleted   = 0;
        $skipped   = 0;
        $report    = [];

        foreach ($json_files as $index => $json_file) {
            try {
                $filename    = basename($json_file);
                $json_dir    = dirname($json_file) . '/';
                $file_report = ["📄 File: $filename (" . ($index + 1) . "/$total_files)"];

                // Đọc dữ liệu từ file JSON
                $data = json_decode(file_get_contents($json_file), true);
                if (!$data) {
                    $file_report[] = "❌ Invalid JSON in $filename";
                    file_put_contents($log_file, "Invalid JSON in $filename\n", FILE_APPEND);
                    $skipped++;
                    $report[] = implode("\n", $file_report);
                    continue;
                }

                $customer_id = $data['customer_id'];
                $invoice_id  = $data['invoice_id'];
                $filenames   = array_unique($data['filenames']);
                $created_at  = $data['created_at']  ?? date('Y-m-d H:i:s');
                $is_feedback = $data['is_feedback'] ?? (strpos($filename, 'feedback') !== false);

                // 🔧 Xác định thư mục nguồn dựa trên vị trí JSON và is_feedback
                // Ưu tiên: processed/ → temp/ hoặc temp-feedback/
                $source_dirs   = [];
                $source_dirs[] = $processed_dir; // Luôn check processed/ trước
                if ($is_feedback) {
                    $source_dirs[] = $temp_feedback_dir;
                } else {
                    $source_dirs[] = $temp_upload_dir;
                }

                $filename_parts = pathinfo($filename, PATHINFO_FILENAME);
                $checkin_date   = substr($filename_parts, strrpos($filename_parts, '_') + 1);
                if (!preg_match('/^\d{8}$/', $checkin_date)) {
                    $checkin_date  = date('Ymd', strtotime($created_at));
                    $file_report[] = "⚠ Using created_at for checkin_date: $checkin_date";
                }

                $customer_upload_dir = $base_upload_dir . $customer_id . '/';
                $customer_upload_url = $base_upload_url . $customer_id . '/';
                $field_name          = $is_feedback ? 'image_feedback' : 'images';

                $success_flag     = true;
                $processed_images = [];
                $pending_images   = [];

                foreach ($filenames as $orig_filename) {
                    $sub_report     = ["🔎 Processing: $orig_filename"];
                    $original_ext   = strtolower(pathinfo($orig_filename, PATHINFO_EXTENSION));
                    $webp_filename  = str_replace('.' . $original_ext, '.webp', $orig_filename);
                    $final_path     = $customer_upload_dir . $webp_filename;

                    // Tìm file nguồn từ các thư mục có thể
                    $source_path = null;
                    foreach ($source_dirs as $dir) {
                        if (file_exists($dir . $orig_filename)) {
                            $source_path = $dir . $orig_filename;
                            break;
                        }
                    }

                    // Kiểm tra các điều kiện
                    $source_ok    = !empty($source_path);
                    $sub_report[] = $source_ok ? '✅ Source found: ' . basename(dirname($source_path)) : '❌ Source not found';

                    $customer_folder_ok = file_exists($final_path);
                    $sub_report[]       = $customer_folder_ok ? '✅ Customer folder' : '❌ Customer folder';

                    $invoice_ok = false;
                    if ($invoice_id) {
                        $images = $wpdb->get_var($wpdb->prepare(
                            "SELECT {$field_name} FROM $invoice_table WHERE invoice_id = %s",
                            $invoice_id
                        ));
                        $invoice_ok = !empty($images) && in_array($customer_upload_url . $webp_filename, json_decode($images, true) ?: []);
                    }
                    $sub_report[] = $invoice_ok ? '✅ Invoice table' : '❌ Invoice table';

                    // Nếu tất cả OK → đánh dấu đã xử lý
                    if ($customer_folder_ok && $invoice_ok) {
                        $sub_report[]       = '✅ All checks passed';
                        $file_report[]      = implode("\n", $sub_report);
                        $processed_images[] = $orig_filename;
                        // Xóa file nguồn ở TẤT CẢ các thư mục có thể tồn tại
                        foreach ($source_dirs as $dir) {
                            $file_to_delete = $dir . $orig_filename;
                            if (file_exists($file_to_delete)) {
                                @unlink($file_to_delete);
                                $sub_report[] = '🗑️ Deleted: ' . basename($dir);
                            }
                        }
                        continue;
                    }

                    // (DB write giờ nằm gọn trong Checkin_MKT192_Invoice_Images::add_urls
                    // với transaction + row lock riêng, không cần transaction bao ngoài)

                    // Xử lý thiếu file .webp - tìm và convert từ source
                    if (!$customer_folder_ok && $source_ok) {
                        if (!is_dir($customer_upload_dir)) {
                            wp_mkdir_p($customer_upload_dir);
                        }

                        $image = false;
                        switch ($original_ext) {
                            case 'jpg':
                            case 'jpeg':
                                $image = @imagecreatefromjpeg($source_path);
                                break;
                            case 'png':
                                $image = @imagecreatefrompng($source_path);
                                break;
                            case 'gif':
                                $image = @imagecreatefromgif($source_path);
                                break;
                            case 'webp':
                                $image = @imagecreatefromwebp($source_path);
                                break;
                            default:
                                $pending_images[] = $orig_filename;
                                $sub_report[]     = "🔻 Unsupported file format: $original_ext";
                                $file_report[]    = implode("\n", $sub_report);
                                continue 2;
                        }

                        if ($image && @imagewebp($image, $final_path, 80)) {
                            imagedestroy($image);
                            $customer_folder_ok = true;
                            $sub_report[]       = '🔄 Converted to .webp → customer folder';
                            file_put_contents($log_file, "Converted $orig_filename to .webp: $final_path\n", FILE_APPEND);
                        } else {
                            if ($image) {
                                imagedestroy($image);
                            }
                            $pending_images[] = $orig_filename;
                            $sub_report[]     = '🔻 Failed to convert to .webp';
                            file_put_contents($log_file, "Failed to convert $orig_filename to .webp\n", FILE_APPEND);
                            $file_report[] = implode("\n", $sub_report);
                            continue;
                        }
                    } elseif (!$customer_folder_ok && !$source_ok) {
                        // Không có source và không có webp → file bị mất
                        $pending_images[] = $orig_filename;
                        $sub_report[]     = '🔻 Source file missing, cannot recover';
                        $file_report[]    = implode("\n", $sub_report);
                        continue;
                    }

                    // Xử lý thiếu link trong invoice table — dùng helper atomic (row lock)
                    if ($customer_folder_ok && $invoice_id && !$invoice_ok) {
                        $final_list = Checkin_MKT192_Invoice_Images::add_urls(
                            $invoice_id,
                            [$customer_upload_url . $webp_filename],
                            $field_name,
                            true // loại bỏ URL temp còn sót trong DB
                        );

                        if ($final_list !== false) {
                            if ($is_feedback) {
                                Checkin_MKT192_Invoice_Images::sync_feedback_table($invoice_id, $final_list);
                            }
                            $invoice_ok   = true;
                            $sub_report[] = '🔄 Updated invoice table';
                            file_put_contents($log_file, "Updated invoice table for invoice $invoice_id with $webp_filename\n", FILE_APPEND);
                            $processed_images[] = $orig_filename;
                            // Xóa file nguồn ở TẤT CẢ thư mục sau khi xử lý thành công
                            foreach ($source_dirs as $dir) {
                                $file_to_delete = $dir . $orig_filename;
                                if (file_exists($file_to_delete)) {
                                    @unlink($file_to_delete);
                                }
                            }
                        } else {
                            $pending_images[] = $orig_filename;
                            $sub_report[]     = '🔻 Failed to update invoice table';
                            file_put_contents($log_file, "Failed to update invoice table for invoice $invoice_id: " . $wpdb->last_error . "\n", FILE_APPEND);
                        }
                    } else {
                        // Customer folder OK, invoice OK hoặc no invoice_id
                        $processed_images[] = $orig_filename;
                        // Xóa file nguồn ở TẤT CẢ thư mục
                        foreach ($source_dirs as $dir) {
                            $file_to_delete = $dir . $orig_filename;
                            if (file_exists($file_to_delete)) {
                                @unlink($file_to_delete);
                            }
                        }
                    }

                    $file_report[] = implode("\n", $sub_report);
                }

                // Đếm kết quả
                $total_images   = count($filenames);
                $success_images = count($processed_images);
                $pending_count  = count($pending_images);

                if ($pending_count === 0) {
                    // Tất cả đã xử lý → xóa JSON
                    $recovered++;
                    $file_report[] = "✅ All $success_images images processed successfully";
                    if (file_exists($json_file)) {
                        @unlink($json_file);
                        $deleted++;
                        $file_report[] = '🗑️ Deleted JSON file';
                    }
                } else {
                    // Còn file pending → giữ JSON để retry sau
                    $skipped++;
                    $file_report[] = "⚠️ Partial: $success_images/$total_images processed, $pending_count pending";
                    file_put_contents($log_file, "Partial processing for $filename: $pending_count images pending\n", FILE_APPEND);
                }

                $report[] = implode("\n", $file_report);
            } catch (Exception $e) {
                $skipped++;
                $file_report[] = '🔻 Error processing JSON file: ' . $e->getMessage();
                file_put_contents($log_file, "Error processing $filename: " . $e->getMessage() . "\n", FILE_APPEND);
                $wpdb->query('ROLLBACK');
                $report[] = implode("\n", $file_report);
            }
        }

        // =============================================================================
        // 🧹 CLEANUP: Xóa orphan images trong processed/ (tàn dư từ logic cũ)
        // =============================================================================
        $orphan_deleted   = 0;
        $image_extensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        foreach ($image_extensions as $ext) {
            $orphan_files = glob($processed_dir . "*.$ext") ?: [];
            foreach ($orphan_files as $orphan_file) {
                @unlink($orphan_file);
                $orphan_deleted++;
            }
        }
        if ($orphan_deleted > 0) {
            file_put_contents($log_file, "🧹 Cleanup: Deleted $orphan_deleted orphan images in processed/\n", FILE_APPEND);
        }

        // =============================================================================
        // 🔄 RECOVERY: Quét và khôi phục các ảnh mồ côi (stuck in temp/ without JSON)
        // =============================================================================
        $orphan_recovered = 0;
        $scan_dirs = [
            'customer' => [$temp_upload_dir, false],
            'feedback' => [$temp_feedback_dir, true]
        ];

        foreach ($scan_dirs as $type => $info) {
            $dir = $info[0];
            $is_feedback = $info[1];
            if (!is_dir($dir)) continue;

            $files = glob($dir . "*.{jpg,jpeg,png,webp}", GLOB_BRACE) ?: [];
            foreach ($files as $file_path) {
                if (is_dir($file_path)) continue;

                $filename = basename($file_path);
                $parts = explode('_', pathinfo($filename, PATHINFO_FILENAME));
                
                // Parse customer_id và timestamp
                $cust_id = '';
                $timestamp = 0;

                if ($is_feedback || (isset($parts[0]) && $parts[0] === 'feedback')) {
                    // feedback_{customer_id}_{timestamp}_{random}_{index}
                    if (isset($parts[0]) && $parts[0] === 'feedback') {
                        $cust_id = $parts[1] ?? '';
                        $timestamp = isset($parts[2]) ? floatval($parts[2]) : 0;
                    } else {
                        $cust_id = $parts[0] ?? '';
                        $timestamp = isset($parts[1]) ? floatval($parts[1]) : 0;
                    }
                } else {
                    // {customer_id}_{timestamp}_{random}_{index}
                    $cust_id = $parts[0] ?? '';
                    $timestamp = isset($parts[1]) ? floatval($parts[1]) : 0;
                }

                // If millisecond timestamp (13 digits), convert to seconds (10 digits)
                if ($timestamp > 1000000000000) {
                    $timestamp = intval($timestamp / 1000);
                } else {
                    $timestamp = intval($timestamp);
                }

                // Hợp lệ hóa customer_id (bắt đầu bằng KH hoặc VG) và timestamp
                $cust_id = strtoupper($cust_id);
                if (empty($cust_id) || $timestamp < 1500000000 || $timestamp > 2000000000) {
                    continue; // Bỏ qua nếu không đúng format
                }

                // Tìm hóa đơn phù hợp
                $target_date = date('Y-m-d', $timestamp);
                $invoice = $wpdb->get_row($wpdb->prepare(
                    "SELECT invoice_id FROM {$invoice_table} WHERE customer_id = %s AND DATE(created_at) = %s ORDER BY created_at DESC LIMIT 1",
                    $cust_id,
                    $target_date
                ));

                // Fallback: Tìm hóa đơn trong vòng 3 ngày kể từ lúc checkin
                if (!$invoice) {
                    $start_range = date('Y-m-d H:i:s', $timestamp - 86400 * 2);
                    $end_range = date('Y-m-d H:i:s', $timestamp + 86400 * 2);
                    $invoice = $wpdb->get_row($wpdb->prepare(
                        "SELECT invoice_id FROM {$invoice_table} WHERE customer_id = %s AND created_at BETWEEN %s AND %s ORDER BY created_at DESC LIMIT 1",
                        $cust_id,
                        $start_range,
                        $end_range
                    ));
                }

                if ($invoice && !empty($invoice->invoice_id)) {
                    $invoice_id = $invoice->invoice_id;
                    $customer_upload_dir = $base_upload_dir . $cust_id . '/';
                    $customer_upload_url = $base_upload_url . $cust_id . '/';
                    $field_name = $is_feedback ? 'image_feedback' : 'images';

                    // Convert & Move
                    if (!is_dir($customer_upload_dir)) {
                        wp_mkdir_p($customer_upload_dir);
                    }

                    $original_ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
                    $webp_filename = str_replace('.' . $original_ext, '.webp', $filename);
                    $final_path = $customer_upload_dir . $webp_filename;

                    $converted = false;
                    if (file_exists($final_path)) {
                        $converted = true;
                    } else {
                        // Load image
                        $image = false;
                        switch ($original_ext) {
                            case 'jpg':
                            case 'jpeg':
                                $image = @imagecreatefromjpeg($file_path);
                                break;
                            case 'png':
                                $image = @imagecreatefrompng($file_path);
                                break;
                            case 'gif':
                                $image = @imagecreatefromgif($file_path);
                                break;
                            case 'webp':
                                $image = @imagecreatefromwebp($file_path);
                                break;
                        }

                        if ($image && @imagewebp($image, $final_path, 80)) {
                            imagedestroy($image);
                            $converted = true;
                        } elseif ($image) {
                            imagedestroy($image);
                        }
                    }

                    if ($converted) {
                        // Ghi DB atomic qua helper (row lock, loại URL temp còn sót)
                        $final_list = Checkin_MKT192_Invoice_Images::add_urls(
                            $invoice_id,
                            [$customer_upload_url . $webp_filename],
                            $field_name,
                            true
                        );

                        if ($final_list !== false) {
                            if ($is_feedback) {
                                Checkin_MKT192_Invoice_Images::sync_feedback_table($invoice_id, $final_list);
                            }
                            @unlink($file_path); // Xóa file jpeg nguồn
                            $orphan_recovered++;
                            $recovered++;
                            file_put_contents($log_file, "🩹 RECOVERED ORPHAN: $filename -> Invoice $invoice_id ($field_name)\n", FILE_APPEND);
                        }
                    }
                }
            }
        }
        if ($orphan_recovered > 0) {
            file_put_contents($log_file, "🩹 Recovery: Successfully recovered $orphan_recovered orphan images\n", FILE_APPEND);
        }

        // Ghi và gửi báo cáo
        $execution_time = microtime(true) - $start_time;
        $msg            = "📊 *Reprocess [$cron_id]*\n";
        $msg .= '⏱ Time: ' . number_format($execution_time, 2) . "s\n";
        $msg .= "🔄 Recovered: $recovered\n🔺 Deleted: $deleted\n🔻 Skipped: $skipped\n";
        $msg .= "\n" . implode("\n\n", $report);
        file_put_contents($log_file, $msg . "\n", FILE_APPEND);

        // Gửi thông báo qua Bot Manager
        require_once plugin_dir_path(__FILE__) . '../lark/class-checkin-mkt192-message-bot-manager.php';
        $bot_manager = Checkin_MKT192_Message_Bot_Manager::get_instance();

        $result = $bot_manager->send_message('image_processing', $msg, null);

        if (is_wp_error($result)) {
            file_put_contents($log_file, 'Failed to send notification via Bot Manager: ' . $result->get_error_message() . "\n", FILE_APPEND);
        } else if (isset($result['code']) && $result['code'] == 0) {
            file_put_contents($log_file, "Notification sent successfully via Bot Manager\n", FILE_APPEND);
        } else {
            $error_msg = isset($result['msg']) ? $result['msg'] : 'Unknown error';
            file_put_contents($log_file, "Bot Manager returned error: $error_msg\n", FILE_APPEND);
        }
    }
}
?>
