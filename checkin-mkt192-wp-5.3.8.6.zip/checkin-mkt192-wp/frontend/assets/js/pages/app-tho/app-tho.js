(function () {
  ('use strict');

  // ==============================
  // PERFORMANCE LOGGER
  // ==============================
  const perfLog = {
    startTime: performance.now(),
    marks: [],

    mark(label) {
      const now = performance.now();
      const elapsed = ((now - this.startTime) / 1000).toFixed(3);
      const lastMark = this.marks[this.marks.length - 1];
      const delta = lastMark ? ((now - lastMark.time) / 1000).toFixed(3) : elapsed;

      this.marks.push({ label, time: now, elapsed, delta });
    },

    summary() {
      // Performance summary disabled
    },
  };

  // ==============================
  // 1. App State
  // ==============================
  let invoices = [];
  let currentInvoiceIndex = 0;
  let selectedServiceGroup = 'main';
  let currentServiceForStaff = null;
  let currentProductForStaff = null;
  let invoicesData = [];
  let deletedInvoiceIds = new Set(); // 🔧 Track các invoice_id đã bị xóa trong phiên làm việc

  // ================== BACKGROUND SYNC QUEUE ==================
  const syncQueue = [];
  let isSyncing = false;

  function addToSyncQueue(task) {
    syncQueue.push(task);
    safeSetItem('mkt192_sync_queue', JSON.stringify(syncQueue));
    processSyncQueue();
  }

  async function processSyncQueue() {
    if (isSyncing || syncQueue.length === 0) return;

    isSyncing = true;
    const task = syncQueue[0];

    try {
      console.log('🔄 Syncing:', task.type, task.id);

      if (task.type === 'update_invoice') {
        await fetchAPI(`invoices/${task.id}`, {
          method: 'PUT',
          body: JSON.stringify(task.data),
        });
      } else if (task.type === 'create_invoice') {
        const result = await fetchAPI('invoices', {
          method: 'POST',
          body: JSON.stringify(task.data),
        });
        if (result.invoice_id && task.tempId) {
          const localInv = invoices.find((inv) => inv.invoice_id === task.tempId);
          if (localInv) {
            localInv.invoice_id = result.invoice_id;
            saveInvoicesToLocalStorage();
          }
        }
      }

      console.log('✅ Synced:', task.type, task.id);
      syncQueue.shift();
      safeSetItem('mkt192_sync_queue', JSON.stringify(syncQueue));
    } catch (error) {
      console.error('❌ Sync failed:', task.type, task.id, error);
    } finally {
      isSyncing = false;
      if (syncQueue.length > 0) {
        setTimeout(() => processSyncQueue(), 1000);
      }
    }
  }

  function restoreSyncQueue() {
    try {
      const saved = localStorage.getItem('mkt192_sync_queue');
      if (saved) {
        syncQueue.push(...JSON.parse(saved));
        if (syncQueue.length > 0) {
          console.log('🔄 Restoring sync queue:', syncQueue.length, 'tasks');
          processSyncQueue();
        }
      }
    } catch (e) {
      console.error('Failed to restore sync queue:', e);
    }
  }
  let isInvoicesDataLoaded = false; // ✅ Track xem đã load data chưa
  let loadedDataPeriod = '7days'; // ✅ Track data đang load là của period nào (7days/thisMonth/lastMonth) - Mặc định 7days để giảm tải bộ nhớ localStorage
  // Invoices currently visible in UI (after applying filter/time/search). Used by renderInvoiceTabs.
  let visibleInvoices = [];

  // ✅ URL PARAMS: Đọc section từ URL query params (hỗ trợ push notification deep linking)
  // Ví dụ: /app-tho?view=invoices&invoice_id=123 hoặc /app-tho?view=review-detail&invoice_id=123
  const urlParams = new URLSearchParams(window.location.search);
  const urlView = urlParams.get('view');
  const validSections = [
    'dashboard',
    'services',
    'invoices',
    'bookings',
    'reports',
    'inventory',
    'settings',
    'shifts',
    'review-detail', // Staff review view (read-only)
  ];
  let currentSection = validSections.includes(urlView) ? urlView : 'dashboard';

  let currentFilter = localStorage.getItem('currentFilter') || 'today';
  let customDateRange = null;

  // Khôi phục custom nếu có
  if (currentFilter === 'custom') {
    const start = localStorage.getItem('customStartDate');
    const end = localStorage.getItem('customEndDate');
    if (start && end) {
      customDateRange = { start, end };
    }
  }
  let currentBookingFilter = localStorage.getItem('currentBookingFilter') || 'today';
  let currentReportFilter = localStorage.getItem('currentReportFilter') || 'today'; // ✅ Mặc định là hôm nay
  let currentServiceFilter = localStorage.getItem('currentServiceFilter') || 'today';
  let loadedReportDataPeriod = null; // ✅ Track period nào đã load cho report (thisMonth, lastMonth, custom)
  let reportDataCache = null; // ✅ Cache data đã load để tránh load lại
  let cachedKpiData = {}; // ✅ Cache KPI data theo staff+period: { 'staffName_period': { feedbackKPI, postFbKPI, ... } }
  let cachedSocialPosts = {}; // ✅ Cache social posts theo staff+period
  let lastLoadedStaff = null; // ✅ Track staff đã load để biết khi nào cần reload KPI
  let serviceCustomDateRange = null; // Chúng ta không dùng feature 'custom' cho danh mục Dịch vụ
  // Nếu localStorage chứa giá trị không còn hỗ trợ ('custom' hoặc '7days'), reset về 'today'
  if (currentServiceFilter === 'custom' || currentServiceFilter === '7days') {
    currentServiceFilter = 'today';
    try {
      localStorage.setItem('currentServiceFilter', 'today');
      localStorage.removeItem('serviceCustomStartDate');
      localStorage.removeItem('serviceCustomEndDate');
    } catch (e) {}
  }
  let currentUserRole = null;
  let currentUserDisplayName = null;
  let currentSettingsSubsection = 'promo';
  let ctkmList = [];
  let vouchers = [];
  let isEditingCTKM = false;
  let editingCTKMName = null;
  let isEditingVoucher = false;
  let bookingsData = [];
  let staff = [];
  let showAllTabs = false;
  let isFromMoreTab = false;
  let selectedFromMore = false; // true khi user chọn invoice từ modal "Xem thêm"
  let modalCurrentPage = 1; // Current page in "Xem thêm" modal
  let modalItemsPerPage = 50; // Items per page in modal
  let promoStatus = '';
  let selectedProductGroup = null;
  let revenueChartInstance = null;
  let monthlyRevenueChartInstance = null;
  let detailedRevenueChartInstance = null;
  let customersChartInstance = null;
  let messagesChartInstance = null;
  let currentTab = 'services';
  let currentPage = 1; // ❌ Removed localStorage - không cần lưu page state
  let staffStatus = 'ON';
  let isAdmin = checkinData.currentUser.user_role === 'administrator';
  let currentBookingPage = parseInt(localStorage.getItem('bookingPage')) || 1;
  let itemsPerPage = parseInt(localStorage.getItem('bookingItemsPerPage')) || 10;
  let totalBookingItems = 0;
  let selectedStaffForTruyThu = [];
  let cachedCanViewAll = null; // ✅ Cache result of canViewAllInvoices()

  // ==============================
  // BRANCH SYSTEM VARIABLES
  // ==============================
  let branchHelper = null;
  let currentBranch = '';
  let currentBranchFilter = '';

  // ==============================
  // POLLING STATE
  // ==============================
  let pollingIntervalId = null;
  let isPollingActive = false;

  const serviceGroupMapping = {
    CẮT: 'main',
    RELAX: 'plus',
    'HÓA CHẤT': 'chemical',
    VIP: 'vip',
  };

  const serviceGroupDisplayNames = {
    main: 'Combo',
    plus: 'Relax',
    chemical: 'Hóa chất',
    vip: 'VIP',
  };

  const serviceFilterLabelMap = {
    today: 'Hôm nay',
    yesterday: 'Hôm qua',
    '7days': '7 ngày',
    thisMonth: 'Tháng này',
    lastMonth: 'Tháng trước',
    custom: 'Tùy chỉnh',
  };

  const productGroupMapping = {
    WAX: 'wax',
    'TINH DẦU': 'oil',
    GÔM: 'gom',
    KHÁC: 'other',
  };

  const productGroupDisplayNames = {
    wax: 'Wax',
    oil: 'Tinh Dầu',
    gom: 'Gôm',
    other: 'Khác',
  };

  const sectionTitles = {
    dashboard: 'Dashboard',
    bookings: 'Lịch hẹn',
    customers: 'Khách hàng',
    services: 'Dịch vụ',
    invoices: 'Hóa đơn',
    reports: 'Báo cáo',
    shifts: 'Quản lý Ca',
    settings: 'Cài đặt',
    'review-detail': 'KH đánh giá',
  };

  // ==============================
  // QUICK NAVIGATION - Code Sections
  // ==============================
  // 1. App State (line ~6)
  // 2. DOM Elements (line ~150)
  // 3. Core Utilities & Helpers (line ~500)
  // 4. Storage Manager & Event Listeners (line ~674)
  // 5. API & Data Fetching (line ~900)
  // 6. PAYMENT SYSTEM (line ~1025)
  // 7. INVOICE SYSTEM (line ~1323)
  // 8. CUSTOMER MANAGEMENT (line ~1842)
  // 9. SERVICE MANAGEMENT (line ~2685)
  // 10. PRODUCT MANAGEMENT (line ~3101)
  // 11. PROMO & DISCOUNT SYSTEM (line ~1646)
  // 12. BOOKING MANAGEMENT (line ~8779)
  // 13. INITIALIZATION & APP SETUP (line ~7401)
  // ==============================

  // ==============================
  // 2. DOM Elements
  // ==============================
  const elements = {
    sidebar: document.querySelector('.sidebar'),
    mainContent: document.querySelector('.main-content'),
    sidebarToggle: document.getElementById('sidebarToggle'),
    mobileSidebarToggle: document.getElementById('mobileSidebarToggle'),
    userAvatar: document.getElementById('userAvatar'),
    headerUserDisplayName: document.getElementById('headerUserDisplayName'),
    userMenu: document.getElementById('userMenu'),
    headerAdminBtn: document.getElementById('headerAdminBtn'),
    headerLogoutButton: document.getElementById('headerLogoutButton'),
    sidebarUserAvatar: document.getElementById('sidebarUserAvatar'),
    sidebarUserDisplayName: document.getElementById('sidebarUserDisplayName'),
    sidebarUserRole: document.getElementById('sidebarUserRole'),
    settingsToggle: document.getElementById('settingsToggle'),
    settingAdminBtn: document.getElementById('settingAdminBtn'),
    settingsMenu: document.getElementById('settingsMenu'),
    settingsNavItem: document.getElementById('settingsNavItem'),
    shiftsNavItem: document.getElementById('shiftsNavItem'),
    logoutButton: document.getElementById('logoutButton'),
    clearLocalStorageBtn: document.getElementById('clearLocalStorageBtn'),
    pageTitle: document.getElementById('pageTitle'),
    contentArea: document.getElementById('contentArea'),
    servicesContent: document.getElementById('servicesContent'),
    invoicesContent: document.getElementById('invoicesContent'),
    dashboardContent: document.getElementById('dashboardContent'),
    bookingsContent: document.getElementById('bookingsContent'),
    customersContent: document.getElementById('customersContent'),
    reportsContent: document.getElementById('reportsContent'),
    'review-detailContent': document.getElementById('review-detailContent'),
    invoiceTabs: document.getElementById('invoiceTabs'),
    addInvoiceTab: document.getElementById('addInvoiceTab'),
    customerPhone: document.getElementById('customerPhone'),
    searchCustomerBtn: document.getElementById('searchCustomerBtn'),
    scanQrBtn: document.getElementById('scanQrBtn'),
    customerInfo: document.getElementById('customerInfo'),
    customerHairdresser: document.getElementById('customerHairdresser'),
    customerNotImage: document.getElementById('customerNotImage'),
    newCustomerForm: document.getElementById('newCustomerForm'),
    saveNewCustomerBtn: document.getElementById('saveNewCustomerBtn'),
    serviceGroups: document.getElementById('serviceGroups'),
    serviceList: document.getElementById('serviceList'),
    selectedServices: document.getElementById('selectedServices'),
    promoListSelect: document.getElementById('promoListSelect'),
    paymentMethodSelect: document.getElementById('paymentMethodSelect'),
    subtotalAmount: document.getElementById('subtotalAmount'),
    discountAmount: document.getElementById('discountAmount'),
    discountType: document.getElementById('discountType'),
    tipsAmount: document.getElementById('tipsAmount'),
    totalAmount: document.getElementById('totalAmount'),
    invoiceContent: document.getElementById('invoiceContent'),
    invoicesListTabs: document.getElementById('invoicesListTabs'),
    invoicesDetailContent: document.getElementById('invoicesDetailContent'),
    selectStaffModal: document.getElementById('selectStaffModal'),
    closeStaffModal: document.getElementById('closeStaffModal'),
    modalServiceName: document.getElementById('modalServiceName'),
    staffList: document.getElementById('staffList'),
    confirmStaffBtn: document.getElementById('confirmStaffBtn'),
    paymentMethodModal: document.getElementById('paymentMethodModal'),
    closePaymentModal: document.getElementById('closePaymentModal'),
    qrPaymentSection: document.getElementById('qrPaymentSection'),
    qrPaymentAmount: document.getElementById('qrPaymentAmount'),
    confirmPaymentBtn: document.getElementById('confirmPaymentBtn'),
    createInvoiceBtn: document.getElementById('createInvoiceBtn'),
    payInvoiceBtn: document.getElementById('payInvoiceBtn'),
    reviewInvoiceBtn: document.getElementById('reviewInvoiceBtn'),
    reviewInvoiceListBtn: document.getElementById('reviewInvoiceListBtn'),
    uploadImageBtn: document.getElementById('uploadImageBtn'),
    uploadImageFeedbackBtn: document.getElementById('uploadImageFeedbackBtn'),
    invoiceImages: document.getElementById('invoiceImages'),
    refreshStaffBtn: document.getElementById('refreshStaffBtn'),
    customerName: document.getElementById('customerName'),
    customerDob: document.getElementById('customerDob'),
    customerLastVisit: document.getElementById('customerLastVisit'),
    customerPhoto: document.getElementById('customerPhoto'),
    promoCode: document.getElementById('promoCode'),
    promoForm: document.getElementById('promoForm'),
    voucherForm: document.getElementById('voucherForm'),
    voucherFormContainer: document.getElementById('voucherFormContainer'),
    voucherSubmitBtn: document.getElementById('voucherSubmitBtn'),
    cancelVoucherBtn: document.getElementById('cancelVoucherBtn'),
    addNewVoucherBtn: document.getElementById('addNewVoucherBtn'),
    voucherList: document.getElementById('voucherList'),
    customerMembershipTag: document.getElementById('customerMembershipTag'),
    customerPhoto1: document.getElementById('customerPhoto1'),
    customerPhoto2: document.getElementById('customerPhoto2'),
    customerPhoto3: document.getElementById('customerPhoto3'),
    settingsContent: document.getElementById('settingsContent'),
    shiftsContent: document.getElementById('shiftsContent'),
    notImageBtn: document.getElementById('notImageBtn'),
    totalRevenue: document.getElementById('totalRevenue'),
    cashRevenue: document.getElementById('cashRevenue'),
    totalCkRevenue: document.getElementById('totalCkRevenue'),
    bankRevenue: document.getElementById('bankRevenue'),
    momoRevenue: document.getElementById('momoRevenue'),
    totalTips: document.getElementById('totalTips'),
    cashTips: document.getElementById('cashTips'),
    ckTips: document.getElementById('ckTips'),
    totalDiscount: document.getElementById('totalDiscount'),
    totalBooking: document.getElementById('totalBooking'),
    customersChart: document.getElementById('customersChart').getContext('2d'),
    messagesChart: document.getElementById('messagesChart').getContext('2d'),
    serviceRevenue: document.getElementById('serviceRevenue'),
    chemicalRevenue: document.getElementById('chemicalRevenue'),
    productRevenue: document.getElementById('productRevenue'),
    penaltyRevenue: document.getElementById('penaltyRevenue'),
    overtimeRevenue: document.getElementById('overtimeRevenue'),
    feedbackKPI: document.getElementById('feedbackKPI'),
    postFbKPI: document.getElementById('postFbKPI'),
    productKPI: document.getElementById('productKPI'),
    feedbackProgress: document.getElementById('feedbackProgress'),
    postFbProgress: document.getElementById('postFbProgress'),
    productProgress: document.getElementById('productProgress'),
    servicesTab: document.getElementById('servicesTab'),
    productsTab: document.getElementById('productsTab'),
    productGroups: document.getElementById('productGroups'),
    productList: document.getElementById('productList'),
    totalChemicalBills: document.getElementById('totalChemicalBills'),
    inventoryCheckBtn: document.getElementById('inventoryCheckBtn'),
    stockTransactionBtn: document.getElementById('stockTransactionBtn'),
    staffStatusToggle: document.getElementById('staffStatusToggle'),
    staffStatusLabel: document.getElementById('staffStatusLabel'),
    toggleSwitch: document.querySelector('.toggle-switch'),
    // Theme controls (in header)
    themeToggleBtn: document.getElementById('themeToggleBtn'),
    themeToggleIcon: document.getElementById('themeToggleIcon'),
    themeMenu: document.getElementById('themeMenu'),
    themeOptionLight: document.getElementById('themeOptionLight'),
    themeOptionDark: document.getElementById('themeOptionDark'),
    themeOptionSystem: document.getElementById('themeOptionSystem'),
  };

  // ==============================
  // 3. Helper Functions
  // ==============================
  // --- Core Utility Functions ---

  // 🔧 Helper: Scroll to top mượt mà
  function smoothScrollToTop() {
    try {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (e) {
      // Fallback cho trình duyệt cũ
      window.scrollTo(0, 0);
    }
  }

  // 🔧 Helper: Rebuild visibleInvoices dựa trên filter hiện tại
  function rebuildVisibleInvoices() {
    try {
      // Lấy filter tùy theo section hiện tại
      let filter = currentSection === 'services' ? currentServiceFilter : currentFilter;
      let dateRange = currentSection === 'services' ? serviceCustomDateRange : customDateRange;

      // Nếu không có filter, mặc định hiển thị tất cả
      if (!filter) {
        visibleInvoices = [...invoices];
        return;
      }

      // Helper: Lấy YYYY-MM-DD của hóa đơn ở múi giờ VN
      const getInvoiceDateVN = (dateStr) => {
        try {
          const date = new Date(dateStr);
          const utc = date.getTime() + date.getTimezoneOffset() * 60000;
          const vnDate = new Date(utc + 7 * 3600000);
          return `${vnDate.getFullYear()}-${String(vnDate.getMonth() + 1).padStart(
            2,
            '0'
          )}-${String(vnDate.getDate()).padStart(2, '0')}`;
        } catch (e) {
          return '';
        }
      };

      const now = new Date();
      const utc = now.getTime() + now.getTimezoneOffset() * 60000;
      const vietnamNow = new Date(utc + 7 * 3600000);
      const todayVN = `${vietnamNow.getFullYear()}-${String(vietnamNow.getMonth() + 1).padStart(
        2,
        '0'
      )}-${String(vietnamNow.getDate()).padStart(2, '0')}`;

      // Apply filter
      if (filter === 'today') {
        visibleInvoices = invoices.filter((inv) => getInvoiceDateVN(inv.created_at) === todayVN);
      } else if (filter === 'yesterday') {
        const yesterday = new Date(vietnamNow);
        yesterday.setDate(yesterday.getDate() - 1);
        const yesterdayVN = `${yesterday.getFullYear()}-${String(yesterday.getMonth() + 1).padStart(
          2,
          '0'
        )}-${String(yesterday.getDate()).padStart(2, '0')}`;
        visibleInvoices = invoices.filter(
          (inv) => getInvoiceDateVN(inv.created_at) === yesterdayVN
        );
      } else if (filter === 'thisMonth') {
        const startVN = `${vietnamNow.getFullYear()}-${String(vietnamNow.getMonth() + 1).padStart(
          2,
          '0'
        )}-01`;
        const nextMonth = new Date(vietnamNow);
        nextMonth.setMonth(nextMonth.getMonth() + 1);
        const lastDay = new Date(nextMonth.getFullYear(), nextMonth.getMonth(), 0);
        const endVN = `${lastDay.getFullYear()}-${String(lastDay.getMonth() + 1).padStart(
          2,
          '0'
        )}-${String(lastDay.getDate()).padStart(2, '0')}`;
        visibleInvoices = invoices.filter((inv) => {
          const invDate = getInvoiceDateVN(inv.created_at);
          return invDate >= startVN && invDate <= endVN;
        });
      } else if (filter === 'lastMonth') {
        // ✅ FIX: Thêm xử lý filter lastMonth
        const lastMonthDate = new Date(vietnamNow);
        lastMonthDate.setMonth(lastMonthDate.getMonth() - 1);
        const startVN = `${lastMonthDate.getFullYear()}-${String(
          lastMonthDate.getMonth() + 1
        ).padStart(2, '0')}-01`;
        const lastDay = new Date(lastMonthDate.getFullYear(), lastMonthDate.getMonth() + 1, 0);
        const endVN = `${lastDay.getFullYear()}-${String(lastDay.getMonth() + 1).padStart(
          2,
          '0'
        )}-${String(lastDay.getDate()).padStart(2, '0')}`;
        visibleInvoices = invoices.filter((inv) => {
          const invDate = getInvoiceDateVN(inv.created_at);
          return invDate >= startVN && invDate <= endVN;
        });
      } else if (filter === '7days') {
        // ✅ FIX: Thêm xử lý filter 7days
        const sevenDaysAgo = new Date(vietnamNow);
        sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 6);
        const startVN = `${sevenDaysAgo.getFullYear()}-${String(
          sevenDaysAgo.getMonth() + 1
        ).padStart(2, '0')}-${String(sevenDaysAgo.getDate()).padStart(2, '0')}`;
        visibleInvoices = invoices.filter((inv) => {
          const invDate = getInvoiceDateVN(inv.created_at);
          return invDate >= startVN && invDate <= todayVN;
        });
      } else if (filter === 'custom' && dateRange?.start && dateRange?.end) {
        const startVN = dateRange.start.split('T')[0];
        const endVN = dateRange.end.split('T')[0];
        visibleInvoices = invoices.filter((inv) => {
          const invDate = getInvoiceDateVN(inv.created_at);
          return invDate >= startVN && invDate <= endVN;
        });
      } else {
        // Default: show all
        visibleInvoices = [...invoices];
      }

      // 🔧 FIX: Deduplicate visibleInvoices để tránh hiển thị double tabs
      const seen = new Set();
      visibleInvoices = visibleInvoices.filter((inv) => {
        const id = inv.invoice_id || inv.id;
        if (seen.has(id)) return false;
        seen.add(id);
        return true;
      });
    } catch (e) {
      console.error('Error rebuilding visibleInvoices:', e);
      visibleInvoices = [...invoices];
    }
  }

  function synchronizeActiveInvoiceWithVisible() {
    try {
      const currentInv = invoices[currentInvoiceIndex];
      const activeId = currentInv ? currentInv.invoice_id || currentInv.id : null;
      if (!activeId) return;
      const isActiveVisible = visibleInvoices.some(
        (inv) => (inv.invoice_id && inv.invoice_id === activeId) || (inv.id && inv.id === activeId)
      );
      if (!isActiveVisible && visibleInvoices.length > 0) {
        // 🔧 FIX: Chọn hóa đơn MỚI NHẤT trong danh sách visible
        let newest = visibleInvoices[0];
        let newestTime = new Date(newest.created_at || 0).getTime();

        visibleInvoices.forEach((inv) => {
          const invTime = new Date(inv.created_at || 0).getTime();
          if (invTime > newestTime) {
            newestTime = invTime;
            newest = inv;
          }
        });

        const newActiveId = newest.invoice_id || newest.id;
        const idx = invoices.findIndex(
          (inv) => inv.invoice_id === newActiveId || inv.id === newActiveId
        );
        if (idx !== -1) {
          currentInvoiceIndex = idx;
        }
      }
    } catch (e) {}
  }

  function hasPermission(action) {
    // Assume checkinData.userPermissions is an array of allowed actions for the current user
    // This should be set from PHP side or fetched via API
    return checkinData.userPermissions && checkinData.userPermissions.includes(action);
  }

  // --- App Version & User Role Functions ---

  function updateAppVersion() {
    const versionElement = document.getElementById('appVersion');
    if (versionElement && checkinData && checkinData.version) {
      const sidebar = document.getElementById('sidebar');
      const isCollapsed = sidebar && sidebar.classList.contains('sidebar-collapsed');
      const versionText = isCollapsed ? checkinData.version : `Phiên bản ${checkinData.version}`;
      versionElement.textContent = versionText;
    } else {
      if (versionElement) {
        versionElement.textContent = 'Phiên bản không xác định';
      }
    }
  }

  // Use hasPermission for checking permissions
  function canViewAllInvoices() {
    // ✅ Check permission 'invoice.view_all' HOẶC role Quản lý/Thu ngân
    const managerRoles = ['Quản Lý', 'Thu Ngân', 'administrator', 'admin', 'Quản lý'];
    return hasPermission('invoice.view_all') || managerRoles.includes(currentUserRole);
  }

  // Cache staff data để tránh gọi API nhiều lần
  let cachedStaffData = null;
  let staffDataFetchPromise = null;

  async function fetchStaffData(forceRefresh = false) {
    if (forceRefresh) {
      cachedStaffData = null;
      staffDataFetchPromise = null;
    }

    if (cachedStaffData) {
      return cachedStaffData;
    }

    // Nếu đang fetch, chờ promise hiện tại thay vì tạo request mới
    if (staffDataFetchPromise) {
      return staffDataFetchPromise;
    }

    staffDataFetchPromise = fetchAPI('staff')
      .then((data) => {
        cachedStaffData = data;
        staffDataFetchPromise = null;

        // 🔧 FIX: Save staff data to localStorage after fetch for preload
        saveStaffToLocalStorage(data);

        return data;
      })
      .catch((err) => {
        staffDataFetchPromise = null;
        throw err;
      });

    return staffDataFetchPromise;
  }

  // getCurrentUserRole() removed - use hasPermission() instead for access control

  async function getStaffStatus() {
    // Role data is loaded by updateUserInfo(), just return status
    return staffStatus;
  }

  async function updateUserInfo() {
    const funcStart = performance.now();
    perfLog.mark('👤 START updateUserInfo');
    try {
      const staffData = await fetchStaffData();
      const currentUser = checkinData.currentUser;
      const staff = staffData.find((s) => s.display_name === currentUser.display_name);

      if (staff) {
        // Cập nhật avatar và thông tin người dùng
        const avatarUrl = staff.avatar || 'https://randomuser.me/api/portraits/lego/1.jpg';
        const displayName = staff.display_name || 'Nhân Viên';
        const role = staff.user_role || 'Không xác định';

        // Update global variables for display purposes only
        currentUserRole = role;
        currentUserDisplayName = displayName;
        staffStatus = staff.status || 'ON';

        // Export to window for dashboard module access
        window.currentUserRole = role;
        window.currentUserDisplayName = displayName;

        if (elements.userAvatar) {
          elements.userAvatar.src = avatarUrl;
          elements.userAvatar.alt = `Avatar của ${displayName}`;
        }
        if (elements.sidebarUserAvatar) {
          elements.sidebarUserAvatar.src = avatarUrl;
          elements.sidebarUserAvatar.alt = `Avatar của ${displayName}`;
        }
        if (elements.sidebarUserDisplayName) {
          elements.sidebarUserDisplayName.textContent = displayName;
        }
        if (elements.headerUserDisplayName) {
          elements.headerUserDisplayName.textContent = `Hi, ${displayName}`;
        }
        if (isAdmin) {
          elements.headerAdminBtn.style.display = 'flex';
          elements.settingAdminBtn.style.display = 'flex';
        }
        if (elements.sidebarUserRole) {
          elements.sidebarUserRole.textContent = role;
        }
        if (elements.settingsNavItem) {
          const restrictedRoles = ['Thợ Chính', 'Thợ Phụ'];
          elements.settingsNavItem.classList.toggle('hidden', restrictedRoles.includes(role));
        }

        // 💰 Show/Hide Quản lý Ca menu - Chỉ dành cho Thu Ngân & Quản Lý
        if (elements.shiftsNavItem) {
          const shiftRoles = ['Quản Lý', 'Thu Ngân', 'administrator', 'admin', 'Quản lý'];
          elements.shiftsNavItem.classList.toggle('hidden', !shiftRoles.includes(role));
        }

        staffStatus = staff.status;
      } else {
        if (elements.userAvatar) {
          elements.userAvatar.src = 'https://randomuser.me/api/portraits/lego/1.jpg';
          elements.userAvatar.alt = 'Avatar mặc định';
        }
        if (elements.sidebarUserAvatar) {
          elements.sidebarUserAvatar.src = 'https://randomuser.me/api/portraits/lego/1.jpg';
          elements.sidebarUserAvatar.alt = 'Avatar mặc định';
        }
        if (elements.sidebarUserDisplayName) {
          elements.sidebarUserDisplayName.textContent = 'Nhân Viên';
        }
        if (elements.headerUserDisplayName) {
          elements.headerUserDisplayName.textContent = 'Nhân Viên';
        }
        if (elements.sidebarUserRole) {
          elements.sidebarUserRole.textContent = 'Không xác định';
        }
        if (elements.settingsNavItem) {
          elements.settingsNavItem.classList.add('hidden');
        }

        staffStatus = 'ON';
      }

      updateStaffStatusUI();

      // ✅ Cache permission result for faster access
      cachedCanViewAll = canViewAllInvoices();
      perfLog.mark('✅ User permissions cached');

      perfLog.mark('✅ END updateUserInfo');
    } catch (error) {
      perfLog.mark('❌ ERROR updateUserInfo');
      await showError('Không thể tải thông tin nhân viên');
      windows.location.href = '/user-profile';

      if (elements.settingsNavItem) {
        elements.settingsNavItem.classList.add('hidden');
      }

      updateStaffStatusUI();
    }
  }

  async function updateStaffStatus(status) {
    try {
      if (!checkinData.currentUser?.display_name) {
        throw new Error('Không tìm thấy display_name của người dùng');
      }

      const response = await fetchAPI('staff-status', {
        method: 'POST',
        body: JSON.stringify({
          staff_name: checkinData.currentUser.display_name,
          status: status,
        }),
      });

      staffStatus = response.data.status; // Đồng bộ với response từ API
      updateStaffStatusUI();
    } catch (error) {
      showCheckinToast({
        message: 'Lỗi khi cập nhật trạng thái!',
        type: 'error',
      });
    }
  }

  // --- Status & Menu UI Functions ---

  function updateStaffStatusUI() {
    if (!elements.staffStatusToggle || !elements.staffStatusLabel || !elements.toggleSwitch) {
      return;
    }

    // Lock toggle for inactive statuses (PAUSE, ARCHIVED, DELETED)
    const lockedStatuses = ['PAUSE', 'ARCHIVED', 'DELETED'];
    const isLocked = lockedStatuses.includes(staffStatus);
    elements.staffStatusToggle.disabled = isLocked;
    elements.toggleSwitch.classList.toggle('disabled', isLocked);
    if (isLocked) {
      elements.toggleSwitch.style.opacity = '0.5';
      elements.toggleSwitch.style.pointerEvents = 'none';
    } else {
      elements.toggleSwitch.style.opacity = '';
      elements.toggleSwitch.style.pointerEvents = '';
    }

    elements.staffStatusToggle.checked = staffStatus === 'ON';
    elements.toggleSwitch.setAttribute('aria-checked', staffStatus === 'ON');

    // Add/remove .toggled class for CSS animation
    if (staffStatus === 'ON') {
      elements.toggleSwitch.classList.add('toggled');
    } else {
      elements.toggleSwitch.classList.remove('toggled');
    }

    const statusLabels = {
      ON: 'Online',
      OFF: 'Offline',
      BUSY: 'Đang bận',
      PAUSE: 'Tạm nghỉ',
      ARCHIVED: 'Lưu trữ',
      DELETED: 'Đã xóa',
    };
    elements.staffStatusLabel.textContent = statusLabels[staffStatus] || staffStatus;
    elements.staffStatusLabel.className = `ml-2 text-sm font-medium transition-colors duration-300 staff-status-label ${
      staffStatus === 'ON' ? 'text-green-600 active' : 'text-red-500 busy'
    }`;
  }

  async function handleLogout() {
    const confirmed = await showConfirm('Bạn có chắc muốn đăng xuất?', 'Xác nhận đăng xuất');

    if (!confirmed) return;

    // Xóa localStorage
    const userId = checkinData.currentUser.id;
    const ua = navigator.userAgent;
    localStorage.removeItem('invoices_' + userId + '_' + ua);
    localStorage.removeItem('lastInvoiceDate_' + userId + '_' + ua);

    // Gọi REST API logout
    fetchAPI(`logout`, {
      method: 'POST',
      headers: {
        'X-WP-Nonce': checkinData.nonce,
      },
    })
      .then((data) => {
        if (data.success) {
          window.location.href = '/user-profile';
        } else {
          toastError('Lỗi đăng xuất, vui lòng thử lại');
        }
      })
      .catch((error) => {
        toastError('Lỗi đăng xuất, vui lòng thử lại');
      });
  }

  function toggleSettingsMenu() {
    if (elements.settingsMenu) {
      elements.settingsMenu.classList.toggle('hidden');
    }
  }

  function toggleUserMenu() {
    if (elements.userMenu) {
      elements.userMenu.classList.toggle('hidden');
    }
  }

  // Consolidated: Close menus when clicking outside
  document.addEventListener('click', (event) => {
    // Close settings menu
    if (
      elements.settingsMenu &&
      elements.settingsToggle &&
      !elements.settingsMenu.contains(event.target) &&
      !elements.settingsToggle.contains(event.target)
    ) {
      elements.settingsMenu.classList.add('hidden');
    }

    // Close user menu
    if (
      elements.userMenu &&
      elements.userAvatar &&
      !elements.userMenu.contains(event.target) &&
      !elements.userAvatar.contains(event.target)
    ) {
      elements.userMenu.classList.add('hidden');
    }
  });

  // --- JSON & Formatting Utilities ---

  function safeParseJSON(jsonString, defaultValue = []) {
    if (!jsonString || typeof jsonString !== 'string') return defaultValue;
    try {
      return JSON.parse(jsonString) || defaultValue;
    } catch (e) {
      return defaultValue;
    }
  }

  // ==============================
  // 3a. Formatting & Parsing Utilities
  // ==============================
  function formatCurrency(amount) {
    return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(amount);
  }
  // ✅ Export formatCurrency for dashboard module
  window.formatCurrency = formatCurrency;

  /**
   * Trả về nhãn hiển thị cho phương thức thanh toán
   * @param {Object} invoice - Đối tượng hóa đơn
   * @returns {string} - Nhãn phương thức thanh toán
   */
  function getPaymentMethodLabel(invoice) {
    const method = invoice.payment_method;
    if (!method) return 'Chưa xác định';

    if (method === 'combined') {
      // Parse combined_payment_details để hiển thị chi tiết
      let details = invoice.combined_payment_details;
      if (typeof details === 'string') {
        try {
          details = JSON.parse(details);
        } catch (e) {
          details = null;
        }
      }

      if (details && (details.cash || details.bank)) {
        const cashPart = details.cash ? `TM: ${formatCurrency(details.cash)}` : '';
        const bankPart = details.bank ? `CK: ${formatCurrency(details.bank)}` : '';
        const parts = [cashPart, bankPart].filter(Boolean).join(', ');
        return `Kết hợp (${parts})`;
      }
      return 'Kết hợp';
    }

    // Các phương thức thanh toán khác
    const methodLabels = {
      cash: 'Tiền mặt',
      bank: 'Chuyển khoản',
      momo: 'MoMo',
      zalopay: 'ZaloPay',
    };

    return methodLabels[method] || method;
  }

  function formatNumberInput(value) {
    value = String(value || '');
    if (!value) return '0';
    const cleaned = value.replace(/[^\d]/g, '');
    const num = parseInt(cleaned) || 0;
    return num.toLocaleString('vi-VN');
  }

  function parseFormattedNumber(value) {
    value = String(value || '');
    return parseInt(value.replace(/[^\d]/g, '')) || 0;
  }

  // Common UI helper: Safe element class toggle
  const UI = {
    show: (el) => el && el.classList.remove('hidden'),
    hide: (el) => el && el.classList.add('hidden'),
    toggle: (el, className = 'hidden') => el && el.classList.toggle(className),
    hasClass: (el, className) => el && el.classList.contains(className),
    setText: (el, text) => el && (el.textContent = text),
  };

  // Common state helper: Get active filter
  function getCurrentFilter() {
    return currentSection === 'services' ? currentServiceFilter : currentFilter;
  }

  // ==============================
  // --- Theme & Dark Mode Support ---
  // ==============================
  // Supports 'light', 'dark', 'system'
  // Persists preference in localStorage under key 'mkt192_theme_pref'
  // Provides a small popover menu in header: themeOptionLight/Dark/System

  const THEME_KEY = 'mkt192_theme_pref';
  let systemMediaQuery = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)');

  function getStoredTheme() {
    return localStorage.getItem(THEME_KEY) || 'system';
  }

  function applyTheme(pref) {
    let useDark = false;
    if (pref === 'system') {
      useDark = systemMediaQuery ? systemMediaQuery.matches : false;
    } else {
      useDark = pref === 'dark';
    }

    // Add a short-lived transition helper class to animate many properties smoothly
    try {
      document.body.classList.add('mkt192-theme-transition');
      window.setTimeout(() => document.body.classList.remove('mkt192-theme-transition'), 360);
    } catch (e) {
      // ignore
    }

    if (useDark) {
      document.body.classList.add('mkt192-dark');
    } else {
      document.body.classList.remove('mkt192-dark');
    }

    // Update small icon shape/color
    try {
      if (elements.themeToggleIcon) {
        if (useDark) {
          elements.themeToggleIcon.setAttribute('stroke', '#e5e7eb');
          elements.themeToggleIcon.innerHTML =
            "<path d='M21 12.79A9 9 0 1111.21 3 7 7 0 0021 12.79z'></path>";
        } else {
          elements.themeToggleIcon.setAttribute('stroke', '#374151');
          elements.themeToggleIcon.innerHTML =
            "<circle cx='12' cy='12' r='4'></circle><path d='M12 2v2m0 16v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2m16 0h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41'></path>";
        }
      }
    } catch (e) {}
  }

  function setThemePreference(pref) {
    try {
      localStorage.setItem(THEME_KEY, pref);
    } catch (e) {}
    applyTheme(pref);
  }

  function handleSystemPrefChange() {
    const pref = getStoredTheme();
    if (pref === 'system') applyTheme('system');
  }

  function initThemeUI() {
    if (!elements.themeToggleBtn || !elements.themeMenu) return;

    elements.themeToggleBtn.addEventListener('click', (ev) => {
      ev.stopPropagation();
      const expanded = elements.themeToggleBtn.getAttribute('aria-expanded') === 'true';
      elements.themeToggleBtn.setAttribute('aria-expanded', String(!expanded));
      elements.themeMenu.classList.toggle('hidden');
    });

    // Close when click outside
    document.addEventListener('click', (ev) => {
      if (!elements.themeMenu) return;
      if (!elements.themeMenu.contains(ev.target) && !elements.themeToggleBtn.contains(ev.target)) {
        elements.themeMenu.classList.add('hidden');
        elements.themeToggleBtn.setAttribute('aria-expanded', 'false');
      }
    });

    if (elements.themeOptionLight)
      elements.themeOptionLight.addEventListener('click', () => {
        setThemePreference('light');
        elements.themeMenu.classList.add('hidden');
      });
    if (elements.themeOptionDark)
      elements.themeOptionDark.addEventListener('click', () => {
        setThemePreference('dark');
        elements.themeMenu.classList.add('hidden');
      });
    if (elements.themeOptionSystem)
      elements.themeOptionSystem.addEventListener('click', () => {
        setThemePreference('system');
        elements.themeMenu.classList.add('hidden');
      });
  }

  function initTheme() {
    const pref = getStoredTheme();
    applyTheme(pref);
    if (systemMediaQuery && typeof systemMediaQuery.addEventListener === 'function') {
      systemMediaQuery.addEventListener('change', handleSystemPrefChange);
    } else if (systemMediaQuery && typeof systemMediaQuery.addListener === 'function') {
      systemMediaQuery.addListener(handleSystemPrefChange);
    }
    initThemeUI();
  }

  // ==============================
  // 4. Storage & Cache Management (Optimized)
  // ==============================

  // ==============================
  // 4. Storage Manager & Event Listeners
  // ==============================
  // --- Storage Manager with TTL ---

  // ==============================
  // Ghi localStorage an toàn
  // ==============================
  // Safari trên iPhone chỉ cho mỗi trang web khoảng 5MB. Khi đầy, localStorage.setItem ném
  // QuotaExceededError ("The quota has been exceeded.") và lỗi đó nổi lên tận màn hình thợ,
  // chặn cả việc tải ảnh khách lẫn danh sách khuyến mãi (21/09/2026 thợ Thế Giáp gặp).
  // Rác chính: khoá invoices_<user>_<userAgent> - iOS nâng cấp là userAgent đổi, khoá cũ nằm lại mãi.

  /** Các khoá rác có thể xoá khi hết chỗ, xếp theo thứ tự ưu tiên xoá trước. */
  function collectStaleStorageKeys(keepKey) {
    const stale = [];
    const keep = keepKey || '';
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (!k || k === keep) continue;

      // Bản sao hoá đơn của thiết bị / phiên bản iOS cũ
      if (k.startsWith('invoices_') || k.startsWith('lastInvoiceDate_')) {
        stale.push({ key: k, weight: 3 });
        continue;
      }
      // Cache có mốc thời gian đã quá hạn
      try {
        const raw = localStorage.getItem(k);
        if (raw && raw.charAt(0) === '{' && raw.indexOf('"timestamp"') !== -1) {
          const parsed = JSON.parse(raw);
          if (parsed && parsed.timestamp && Date.now() - parsed.timestamp > 60 * 60 * 1000) {
            stale.push({ key: k, weight: 2 });
          }
        }
      } catch (e) {
        /* khoá không phải JSON thì bỏ qua */
      }
    }
    return stale.sort((a, b) => b.weight - a.weight).map((x) => x.key);
  }

  /**
   * Ghi localStorage không bao giờ ném lỗi ra ngoài.
   * Hết chỗ thì dọn rác rồi thử lại; vẫn không được thì bỏ qua, app vẫn chạy bình thường.
   */
  function safeSetItem(key, value) {
    try {
      localStorage.setItem(key, value);
      return true;
    } catch (e) {
      const stale = collectStaleStorageKeys(key);
      for (const k of stale) {
        try {
          localStorage.removeItem(k);
          localStorage.setItem(key, value);
          console.warn('[storage] đã dọn khoá cũ để có chỗ ghi:', k);
          return true;
        } catch (again) {
          /* dọn tiếp khoá sau */
        }
      }
      console.warn('[storage] bộ nhớ trình duyệt đã đầy, bỏ qua khoá:', key, e && e.name);
      return false;
    }
  }

  /** Dọn bản sao hoá đơn của thiết bị / phiên bản iOS cũ, chỉ giữ khoá đang dùng. */
  function pruneOldInvoiceStorage(currentKey, currentDateKey) {
    const drop = [];
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (!k) continue;
      if ((k.startsWith('invoices_') && k !== currentKey)
        || (k.startsWith('lastInvoiceDate_') && k !== currentDateKey)) {
        drop.push(k);
      }
    }
    drop.forEach((k) => {
      try {
        localStorage.removeItem(k);
      } catch (e) {
        /* bỏ qua */
      }
    });
    if (drop.length) {
      console.warn('[storage] đã dọn', drop.length, 'bản sao hoá đơn của thiết bị cũ');
    }
  }

  // Unified storage helper for data with TTL (time-to-live)
  const StorageManager = {
    EXPIRY_TIME: 60 * 60 * 1000, // 1 hour

    set: (key, data) => {
      safeSetItem(key, JSON.stringify({ data, timestamp: Date.now() }));
    },

    get: (key) => {
      const stored = localStorage.getItem(key);
      if (!stored) return null;
      const { data, timestamp } = JSON.parse(stored);
      return Date.now() - timestamp > StorageManager.EXPIRY_TIME ? null : data;
    },

    clear: (key) => {
      localStorage.removeItem(key);
    },

    clearKeys: (patterns) => {
      Object.keys(localStorage).forEach((key) => {
        if (patterns.some((pattern) => key.startsWith(pattern) || key === pattern)) {
          localStorage.removeItem(key);
        }
      });
    },
  };
  // --- Storage & Data Persistence ---

  // Specific storage operations using unified manager
  function saveCurrentFilter(filter) {
    currentFilter = filter;
    localStorage.setItem('currentFilter', filter);
  }

  function getInvoiceStorageKey(userId, deviceId) {
    return `invoices_${userId}_${deviceId}`;
  }

  function getLastInvoiceDateKey(userId, deviceId) {
    return `lastInvoiceDate_${userId}_${deviceId}`;
  }

  function isUserLoggedIn() {
    return checkinData.currentUser && checkinData.currentUser.is_logged_in;
  }

  function updateLocalStorageKey(key, data = null) {
    if (data) {
      safeSetItem(key, JSON.stringify(data));
    } else {
      localStorage.removeItem(key);
    }
  }

  // Data persistence using StorageManager
  function saveVouchersToLocalStorage() {
    StorageManager.set('voucherList', vouchers);
  }

  function getVouchersFromLocalStorage() {
    return StorageManager.get('voucherList') || [];
  }

  function saveStaffToLocalStorage(staffData) {
    StorageManager.set('staffList', staffData);
  }

  function getStaffFromLocalStorage() {
    return StorageManager.get('staffList');
  }

  /**
   * Trạng thái thợ KHÔNG được hiện ở các chỗ chọn thợ trong app
   * (chọn thợ cho dịch vụ, phân ca…):
   *   OFF      – nghỉ
   *   ARCHIVED – đã nghỉ việc (lưu trữ)
   *   DELETED  – đã xoá
   * PAUSE (tạm dừng) vẫn cho chọn: thợ còn nhận đặt lịch, chỉ là khách nên
   * gọi trước — không đổi hành vi cũ.
   */
  const NON_WORKING_STAFF_STATUS = ['OFF', 'ARCHIVED', 'DELETED'];

  function isWorkingStaff(staff) {
    return !!staff && !NON_WORKING_STAFF_STATUS.includes(String(staff.status || '').toUpperCase());
  }

  function saveCustomersToLocalStorage(customersData) {
    StorageManager.set('customersList', customersData);
  }

  function getCustomersFromLocalStorage() {
    return StorageManager.get('customersList');
  }

  // 🆕 Cache nhẹ cho date_new_member (chỉ lưu id và date để bảo mật)
  function saveNewMemberDatesCache(data) {
    try {
      safeSetItem(
        'newMemberDatesCache',
        JSON.stringify({
          data: data,
          timestamp: Date.now(),
        })
      );
    } catch (e) {
      console.warn('Failed to save newMemberDatesCache:', e);
    }
  }

  function getNewMemberDatesCache() {
    try {
      const cached = localStorage.getItem('newMemberDatesCache');
      if (!cached) return null;

      const parsed = JSON.parse(cached);
      // Cache hết hạn sau 1 giờ (3600000ms) để đảm bảo data fresh
      const ONE_HOUR = 3600000;
      if (Date.now() - parsed.timestamp > ONE_HOUR) {
        localStorage.removeItem('newMemberDatesCache');
        return null;
      }
      return parsed.data;
    } catch (e) {
      return null;
    }
  }

  // Xóa cache khi có thành viên mới đăng ký (gọi từ invoice payment)
  function invalidateNewMemberDatesCache() {
    try {
      localStorage.removeItem('newMemberDatesCache');
    } catch (e) {}
  }

  function saveBookingsToLocalStorage(bookingsData) {
    StorageManager.set('bookingsList', bookingsData);
  }

  function getBookingsFromLocalStorage() {
    return StorageManager.get('bookingsList');
  }

  function saveServicesToLocalStorage(servicesData) {
    // Include branch in cache key để tránh dùng dữ liệu cũ từ branch khác
    const branchKey = currentBranchFilter ? `_${currentBranchFilter}` : '';
    StorageManager.set(`servicesList${branchKey}`, servicesData);
  }

  function getServicesFromLocalStorage() {
    // Include branch in cache key
    const branchKey = currentBranchFilter ? `_${currentBranchFilter}` : '';
    const cached = StorageManager.get(`servicesList${branchKey}`);
    if (cached) {
      return cached;
    }
    return null;
  }

  function saveInvoicesToLocalStorage() {
    if (!checkinData.currentUser || !checkinData.currentUser.is_logged_in) return;

    const userId = checkinData.currentUser.id;
    const deviceId = navigator.userAgent;
    const key = `invoices_${userId}_${deviceId}`;

    // iOS nâng cấp là userAgent đổi và sinh khoá mới; dọn bản cũ để không chiếm chỗ mãi
    pruneOldInvoiceStorage(key, getLastInvoiceDateKey(userId, deviceId));

    invoices.forEach((invoice) => {
      if (invoice.invoice_id) {
        const dbInvoice = invoicesData.find((inv) => inv.invoice_id === invoice.invoice_id);
        if (dbInvoice && !invoice.promoName) {
          invoice.promoName = dbInvoice.promo_name || null;
        }
      }
    });

    safeSetItem(key, JSON.stringify(invoices));
  }

  function clearExpiredInvoicesFromLocalStorage() {
    if (!isUserLoggedIn()) return;

    const userId = checkinData.currentUser.id;
    const deviceId = navigator.userAgent;
    const key = getInvoiceStorageKey(userId, deviceId);
    const lastDateKey = getLastInvoiceDateKey(userId, deviceId);
    const today = new Date().toLocaleDateString('vi-VN', { timeZone: 'Asia/Ho_Chi_Minh' });
    const lastStoredDate = localStorage.getItem(lastDateKey);

    if (lastStoredDate !== today) {
      updateLocalStorageKey(key);
      updateLocalStorageKey(lastDateKey, today);

      currentInvoiceIndex = 0;
      saveInvoicesToLocalStorage();
    }
  }

  function clearDeletedInvoiceFromLocalStorage(invoiceId) {
    if (!isUserLoggedIn()) return;

    const userId = checkinData.currentUser.id;
    const deviceId = navigator.userAgent;
    const key = getInvoiceStorageKey(userId, deviceId);
    const storedInvoices = localStorage.getItem(key);

    if (storedInvoices) {
      const parsedInvoices = JSON.parse(storedInvoices);
      const updatedInvoices = parsedInvoices.filter((inv) => inv.invoice_id !== invoiceId);
      updateLocalStorageKey(key, updatedInvoices);
    }
  }

  function clearAllLocalStorage() {
    StorageManager.clearKeys([
      // Cache dữ liệu chính
      'invoices_',
      'invoicesData',
      'invoicesList',
      'lastInvoiceDate_',
      'customersList',
      'staffList',
      'servicesList',
      'ctkmList',
      'bookingsList',
      'branchesList',
      'paymentMethodsList',
      'productsList',
      'productGroupsList',
      'voucherList',
      'newMemberDatesCache',

      // Filter và pagination
      'currentFilter',
      'customStartDate',
      'customEndDate',
      'currentBookingFilter',
      'customStartBookingDate',
      'customEndBookingDate',
      'currentReportFilter',
      'customStartReportDate',
      'customEndReportDate',
      'currentServiceFilter',
      'serviceCustomStartDate',
      'serviceCustomEndDate',
      'bookingPage',
      'bookingItemsPerPage',
      'invoicesPerPage',
      'currentInvoiceIndex',

      // Inventory
      'mkt192_inventory_cache',
      'inventoryItemsPerPage',
      'currentInventoryPage',
      'inventoryColumnSettings',
      'inventory_columns',

      // Transaction (phiếu xuất/nhập)
      'mkt192_transaction_cache',
      'currentTransactionPage',
      'transactionItemsPerPage',
      'transaction_columns',

      // Cash & Shift Management (Quản lý tiền mặt & Ca làm việc)
      'mkt192_cash_transactions',
      'mkt192_current_shift',
      'mkt192_shift_history',

      // QR Code cache
      'qr_cache_bank',
      'qr_cache_momo',

      // Branch/Chi nhánh
      'checkin_current_branch',
      'checkin_current_branch_id',
      'checkin_branch_manual',
      'checkin_last_gps',
      'checkinBranchId',

      // UI settings
      'sidebarCollapsed',
      'mkt192_theme_pref',
      'mkt192_invoice_columns',
      'booking_columns',
      'theme',

      // Sync queue
      'mkt192_sync_queue',

      // Push notifications
      'push_last_sync',
      'push_subscription_id',

      // User profile
      'checkin_user_profile',
      'checkin_user_profile_timestamp',
      'fb_access_token',

      // Dashboard
      'dashboard_approval_requests',
    ]);

    // Xóa browser cache (Service Worker cache)
    if ('caches' in window) {
      caches.keys().then(function (names) {
        names.forEach(function (name) {
          caches.delete(name);
        });
      });
    }

    // Unregister Service Workers (trừ OneSignal)
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.getRegistrations().then(function (registrations) {
        registrations.forEach(function (registration) {
          // Không unregister OneSignal worker
          if (registration.active && registration.active.scriptURL.indexOf('OneSignal') === -1) {
            registration.unregister();
          }
        });
      });
    }

    showCheckinToast({
      message: 'Đã xóa bộ nhớ đệm và cache trình duyệt!',
      type: 'success',
    });

    // Delay reload để cache xóa xong
    setTimeout(function () {
      window.location.reload();
    }, 500);
  }

  function saveCTKMToLocalStorage() {
    StorageManager.set('ctkmList', ctkmList);
  }

  function getCTKMFromLocalStorage() {
    return StorageManager.get('ctkmList') || [];
  }

  // ✅ OPTIMIZATION: Cache invoicesData vào localStorage
  function saveInvoicesDataToLocalStorage() {
    if (!checkinData.currentUser || !checkinData.currentUser.is_logged_in) return;
    const branchKey = currentBranchFilter ? `_${currentBranchFilter}` : '';
    const key = `invoicesData${branchKey}`;
    StorageManager.set(key, {
      data: invoicesData,
      timestamp: Date.now(),
    });
  }

  function getInvoicesDataFromLocalStorage() {
    const branchKey = currentBranchFilter ? `_${currentBranchFilter}` : '';
    const key = `invoicesData${branchKey}`;
    const cached = StorageManager.get(key);
    if (cached && cached.data) {
      // Cache hợp lệ trong 5 phút (300000ms)
      const isExpired = Date.now() - cached.timestamp > 300000;
      if (!isExpired) {
        return cached.data;
      }
    }
    return null;
  }

  function clearInvoicesDataCache() {
    const branchKey = currentBranchFilter ? `_${currentBranchFilter}` : '';
    const key = `invoicesData${branchKey}`;
    StorageManager.set(key, null);
  }

  function saveProductsToLocalStorage(productsData) {
    // Include branch in cache key để tránh dùng dữ liệu cũ từ branch khác
    const branchKey = currentBranchFilter ? `_${currentBranchFilter}` : '';
    StorageManager.set(`productsList${branchKey}`, productsData);
  }

  function getProductsFromLocalStorage() {
    // Include branch in cache key
    const branchKey = currentBranchFilter ? `_${currentBranchFilter}` : '';
    const cached = StorageManager.get(`productsList${branchKey}`);
    if (cached) {
      return cached;
    }
    return null;
  }

  function saveProductGroupsToLocalStorage(productGroupsData) {
    // Include branch in cache key để tránh dùng dữ liệu cũ từ branch khác
    const branchKey = currentBranchFilter ? `_${currentBranchFilter}` : '';
    StorageManager.set(`productGroupsList${branchKey}`, productGroupsData);
  }

  function getProductGroupsFromLocalStorage() {
    // Include branch in cache key
    const branchKey = currentBranchFilter ? `_${currentBranchFilter}` : '';
    const cached = StorageManager.get(`productGroupsList${branchKey}`);
    if (cached) {
      return cached;
    }
    return null;
  }

  // Branches localStorage functions
  function saveBranchesToLocalStorage(branchesData) {
    StorageManager.set('branchesList', branchesData);
  }

  function getBranchesFromLocalStorage() {
    return StorageManager.get('branchesList');
  }

  // Payment Methods localStorage functions
  function savePaymentMethodsToLocalStorage(paymentMethods) {
    StorageManager.set('paymentMethodsList', paymentMethods);
  }

  function getPaymentMethodsFromLocalStorage() {
    return StorageManager.get('paymentMethodsList');
  }

  // ==============================
  // 5. API Functions
  // ==============================
  async function fetchAPI(endpoint, options = {}) {
    const apiStart = performance.now();
    try {
      // Auto-add branch_id parameter for data endpoints (only when multi-branch mode enabled)
      let urlWithBranch = endpoint;
      const branchModeEnabled =
        checkinData?.branchModeEnabled === true || checkinData?.branchModeEnabled === '1';

      // ✅ List các endpoint cần filter theo branch
      const branchFilterEndpoints = [
        'services',
        'products',
        'staff-invoices',
        'staff-bookings',
        'bookings',
        'inventory-checks',
        'inventory-transactions',
      ];
      const needsBranchFilter = branchFilterEndpoints.some((ep) => endpoint.includes(ep));

      if (branchModeEnabled && needsBranchFilter && !endpoint.includes('branch_id=')) {
        // Get branch_id from branchHelper
        const branchId = branchHelper?.getCurrentBranchId();
        if (branchId) {
          const separator = endpoint.includes('?') ? '&' : '?';
          urlWithBranch = `${endpoint}${separator}branch_id=${branchId}`;
        }
      }

      const response = await fetch(`${checkinData.restUrl}${urlWithBranch}`, {
        ...options,
        headers: {
          'Content-Type': 'application/json',
          'X-WP-Nonce': checkinData.nonce,
          ...options.headers,
        },
      });

      const result = await response.json();

      // Handle WordPress REST API error format
      if (result.code && result.message) {
        throw new Error(result.message);
      }

      if (/^bookings\/[^/]+\/resend$/.test(endpoint)) {
        return result;
      }

      if (result.success === false) {
        if (endpoint.includes('customers')) {
          return result;
        }
        throw new Error(result.message || `Lỗi từ server tại ${endpoint}`);
      }

      if (result.success === false) {
        throw new Error(result.message || `Lỗi từ server tại ${endpoint}`);
      }

      if (
        endpoint.includes('staff-status') ||
        endpoint.includes('inventory-check') ||
        endpoint.includes('notify-review') ||
        endpoint.includes('logout')
      ) {
        return result;
      }

      if (endpoint.includes('settings/ctkm')) {
        let data = result.data || result;
        if (Array.isArray(data)) {
          data = data.map((ctkm) => {
            if (typeof ctkm.membership_label === 'string') {
              try {
                ctkm.membership_label = JSON.parse(ctkm.membership_label);
              } catch {
                ctkm.membership_label = [ctkm.membership_label];
              }
            }
            return ctkm;
          });
        } else {
          if (typeof data.membership_label === 'string') {
            try {
              data.membership_label = JSON.parse(data.membership_label);
            } catch {
              data.membership_label = [data.membership_label];
            }
          }
        }
        return data;
      }

      if (endpoint.includes('customers')) {
        if (!result || typeof result !== 'object') {
          throw new Error('Phản hồi API không hợp lệ');
        }
        return result;
      }

      if (endpoint === 'invoices' || /^invoices\/[\w-]+$/.test(endpoint)) {
        return result;
      }

      if (endpoint.includes('staff-invoices')) {
        return result.success ? result.data || [] : [];
      }

      return result.data || result;
    } catch (error) {
      throw error;
    }
  }

  async function sendReviewNotification(invoiceId) {
    try {
      const updateDataReview = {
        invoice_id: invoiceId,
        cashier: currentUserDisplayName,
      };

      const response = await fetchAPI('notify-review', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-WP-Nonce': checkinData.nonce,
        },
        body: JSON.stringify(updateDataReview),
      });

      if (!response.success) {
        throw new Error(response.message || 'Lỗi khi gửi yêu cầu đánh giá');
      }

      // Cập nhật trạng thái yêu cầu đánh giá cho hóa đơn
      const invoiceIndex = invoices.findIndex(
        (inv) => inv.invoice_id === invoiceId || inv.id === invoiceId
      );
      if (invoiceIndex !== -1) {
        invoices[invoiceIndex].isReviewRequested = true;
        saveInvoicesToLocalStorage();
      }

      toastSuccess('Hóa đơn đã được gửi đến Trang đánh giá!');
      return response;
    } catch (error) {
      toastError(error.message || 'Lỗi xảy ra!');
      await showError(error.message || 'Lỗi xảy ra!');
      throw error;
    }
  }

  // ==============================
  // Modal State Management
  // ==============================
  function openModal(modalElement) {
    if (modalElement) {
      modalElement.classList.remove('opacity-0', 'hidden');
      modalElement.classList.add('opacity-100');
      const container = modalElement.querySelector('.modal-container');
      if (container) {
        container.classList.remove('scale-95');
      }
    }
  }

  function closeModal(modalElement) {
    if (modalElement) {
      modalElement.classList.remove('opacity-100');
      modalElement.classList.add('opacity-0', 'hidden');
      const container = modalElement.querySelector('.modal-container');
      if (container) {
        container.classList.add('scale-95');
      }
    }
  }

  // ==============================
  // 6. PAYMENT SYSTEM
  // ==============================
  // --- Payment Modal & Methods ---

  // ==============================
  // Combined Payment Helper Functions
  // ==============================
  function showCombinedPaymentSection(totalAmount) {
    const combinedSection = document.getElementById('combinedPaymentSection');
    const combinedTotalAmount = document.getElementById('combinedTotalAmount');
    const combinedCashAmount = document.getElementById('combinedCashAmount');
    const combinedBankAmount = document.getElementById('combinedBankAmount');

    if (!combinedSection) return;

    // Reset inputs
    if (combinedCashAmount) combinedCashAmount.value = '';
    if (combinedBankAmount) combinedBankAmount.value = '';

    // Hiển thị tổng tiền cần thanh toán
    if (combinedTotalAmount) {
      combinedTotalAmount.textContent = formatCurrency(totalAmount);
    }

    // Hiển thị section
    combinedSection.classList.remove('hidden');

    // Thiết lập event listeners cho inputs
    setupCombinedPaymentListeners(totalAmount);

    // Cập nhật summary ban đầu
    updateCombinedPaymentSummary(totalAmount);
  }

  function hideCombinedPaymentSection() {
    const combinedSection = document.getElementById('combinedPaymentSection');
    if (combinedSection) {
      combinedSection.classList.add('hidden');
    }
  }

  function setupCombinedPaymentListeners(totalAmount) {
    const combinedCashAmount = document.getElementById('combinedCashAmount');
    const combinedBankAmount = document.getElementById('combinedBankAmount');

    const updateHandler = () => updateCombinedPaymentSummary(totalAmount);

    if (combinedCashAmount) {
      // Remove old listeners by cloning
      const newCashInput = combinedCashAmount.cloneNode(true);
      combinedCashAmount.replaceWith(newCashInput);
      newCashInput.addEventListener('input', updateHandler);
    }

    if (combinedBankAmount) {
      // Remove old listeners by cloning
      const newBankInput = combinedBankAmount.cloneNode(true);
      combinedBankAmount.replaceWith(newBankInput);
      newBankInput.addEventListener('input', updateHandler);
    }
  }

  function updateCombinedPaymentSummary(totalAmount) {
    const combinedCashAmount = document.getElementById('combinedCashAmount');
    const combinedBankAmount = document.getElementById('combinedBankAmount');
    const combinedEnteredTotal = document.getElementById('combinedEnteredTotal');
    const combinedRemainingAmount = document.getElementById('combinedRemainingAmount');
    const combinedPaymentError = document.getElementById('combinedPaymentError');
    const remainingRow = document.querySelector('.combined-remaining');

    const cashValue = parseFloat(combinedCashAmount?.value) || 0;
    const bankValue = parseFloat(combinedBankAmount?.value) || 0;
    const enteredTotal = cashValue + bankValue;
    const remaining = totalAmount - enteredTotal;

    if (combinedEnteredTotal) {
      combinedEnteredTotal.textContent = formatCurrency(enteredTotal);
    }

    if (combinedRemainingAmount) {
      combinedRemainingAmount.textContent = formatCurrency(Math.abs(remaining));
      if (remaining === 0) {
        combinedRemainingAmount.parentElement.querySelector('span').textContent = 'Hoàn tất:';
      } else if (remaining > 0) {
        combinedRemainingAmount.parentElement.querySelector('span').textContent = 'Còn thiếu:';
      } else {
        combinedRemainingAmount.parentElement.querySelector('span').textContent = 'Thừa:';
      }
    }

    if (remainingRow) {
      remainingRow.classList.toggle('valid', remaining === 0);
    }

    if (combinedPaymentError) {
      combinedPaymentError.classList.toggle('hidden', remaining === 0);
    }
  }

  function validateCombinedPayment(totalAmount) {
    const combinedCashAmount = document.getElementById('combinedCashAmount');
    const combinedBankAmount = document.getElementById('combinedBankAmount');

    const cashValue = parseFloat(combinedCashAmount?.value) || 0;
    const bankValue = parseFloat(combinedBankAmount?.value) || 0;
    const enteredTotal = cashValue + bankValue;

    if (enteredTotal !== totalAmount) {
      return {
        valid: false,
        message: `Tổng số tiền nhập (${formatCurrency(
          enteredTotal
        )}) phải bằng tổng cần thanh toán (${formatCurrency(totalAmount)})`,
      };
    }

    if (cashValue <= 0 && bankValue <= 0) {
      return {
        valid: false,
        message: 'Vui lòng nhập ít nhất một phương thức thanh toán',
      };
    }

    return {
      valid: true,
      details: {
        cash: cashValue,
        bank: bankValue,
      },
    };
  }

  /**
   * Cập nhật combined payment details từ inline inputs
   * Được gọi khi user thay đổi giá trị trong section inline
   */
  async function updateCombinedPaymentFromInline() {
    const invoice = invoices[currentInvoiceIndex];
    if (!invoice || invoice.paymentMethod !== 'combined') return;

    const cashInput = document.getElementById('combinedCashInline');
    const bankInput = document.getElementById('combinedBankInline');

    const cashValue = parseFormattedNumber(cashInput?.value || '0');
    const bankValue = parseFormattedNumber(bankInput?.value || '0');

    invoice.combinedPaymentDetails = {
      cash: cashValue,
      bank: bankValue,
    };

    invoice.isDirty = true;
    saveInvoicesToLocalStorage();
  }

  /**
   * Lưu combined payment vào DB khi user bấm nút xác nhận
   */
  async function saveCombinedPaymentToDB() {
    const invoice = invoices[currentInvoiceIndex];
    if (!invoice || invoice.paymentMethod !== 'combined') return;

    // Cập nhật giá trị từ input trước khi lưu
    updateCombinedPaymentFromInline();

    try {
      await saveInvoiceToDB();
      clearInvoicesDataCache();
      await loadStaffInvoices('thisMonth');
      if (currentSection === 'invoices') {
        renderInvoiceList();
      }
    } catch (e) {
      console.error('Failed to save combined payment:', e);
    }
  }

  // ==============================
  // Bank Transfer Info Helpers (QR động)
  // ==============================
  function showBankTransferInfo(addInfo) {
    const infoSection = document.getElementById('bankTransferInfo');
    const transferContent = document.getElementById('transferContent');
    const copyBtn = document.getElementById('copyTransferContent');
    const copyMsg = document.getElementById('copySuccessMsg');

    if (!infoSection || !transferContent) return;

    transferContent.textContent = addInfo;
    infoSection.classList.remove('hidden');

    // Setup copy button
    if (copyBtn) {
      const newCopyBtn = copyBtn.cloneNode(true);
      copyBtn.replaceWith(newCopyBtn);
      newCopyBtn.addEventListener('click', async () => {
        try {
          await navigator.clipboard.writeText(addInfo);
          if (copyMsg) {
            copyMsg.classList.remove('hidden');
            setTimeout(() => copyMsg.classList.add('hidden'), 2000);
          }
        } catch {
          // Fallback for older browsers
          const textArea = document.createElement('textarea');
          textArea.value = addInfo;
          textArea.style.position = 'fixed';
          textArea.style.opacity = '0';
          document.body.appendChild(textArea);
          textArea.select();
          document.execCommand('copy');
          document.body.removeChild(textArea);
          if (copyMsg) {
            copyMsg.classList.remove('hidden');
            setTimeout(() => copyMsg.classList.add('hidden'), 2000);
          }
        }
      });
    }
  }

  function hideBankTransferInfo() {
    const infoSection = document.getElementById('bankTransferInfo');
    if (infoSection) {
      infoSection.classList.add('hidden');
    }
  }

  // ==============================
  // Payment Note Generator
  // ==============================
  function generatePaymentNote(bankData, invoiceId) {
    const prefix = bankData?.note_prefix || 'MKT';
    const syntax = bankData?.note_syntax || '{invoice_id}';

    // Generate random string of length N for {random:N} placeholder
    const randomChars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    function makeRandom(len) {
      let result = '';
      for (let i = 0; i < len; i++) {
        result += randomChars.charAt(Math.floor(Math.random() * randomChars.length));
      }
      return result;
    }

    let note = syntax;
    // Replace {prefix} with the configured prefix
    note = note.replace(/\{prefix\}/gi, prefix);
    // Replace {random:N} with random alphanumeric of length N
    note = note.replace(/\{random:(\d+)\}/gi, (_, len) => makeRandom(parseInt(len, 10)));
    // Replace {invoice_id} with actual invoice ID
    note = note.replace(/\{invoice_id\}/gi, invoiceId || '');
    // Replace {date} with YYYYMMDD
    const now = new Date();
    const dateStr = now.getFullYear().toString()
      + String(now.getMonth() + 1).padStart(2, '0')
      + String(now.getDate()).padStart(2, '0');
    note = note.replace(/\{date\}/gi, dateStr);
    // Replace {timestamp} with unix timestamp
    note = note.replace(/\{timestamp\}/gi, Math.floor(now.getTime() / 1000).toString());

    // Only prepend prefix if syntax doesn't contain {prefix} placeholder
    if (!/\{prefix\}/i.test(syntax)) {
      note = prefix + note;
    }

    return note.toUpperCase();
  }

  // ==============================
  // Payment Polling (auto-confirm)
  // ==============================
  let paymentPollingTimer = null;
  let paymentPollingInvoiceId = null;
  let paymentPollingIsDBInvoice = false;

  function startPaymentPolling(invoiceId, isDBInvoice = false) {
    stopPaymentPolling(); // Clear existing
    paymentPollingInvoiceId = invoiceId;
    paymentPollingIsDBInvoice = isDBInvoice;

    const pollingSection = document.getElementById('paymentPollingSection');
    const intervalLabel = document.getElementById('pollingIntervalLabel');
    const statusText = document.getElementById('pollingStatusText');
    const pollingIcon = document.getElementById('pollingIcon');

    if (!pollingSection) return;
    pollingSection.classList.remove('hidden');

    // Get interval from admin settings (seconds)
    const bankData = checkinData?.paymentQRs?.bank;
    const intervalSec = bankData?.polling_interval || 5;
    const intervalMs = intervalSec * 1000;

    // Display human-readable interval
    if (intervalLabel) {
      if (intervalSec >= 60) {
        intervalLabel.textContent = `${intervalSec / 60} phút`;
      } else {
        intervalLabel.textContent = `${intervalSec} giây`;
      }
    }

    // Reset UI
    if (statusText) statusText.textContent = 'Đang chờ thanh toán...';
    if (pollingIcon) {
      pollingIcon.className = 'fas fa-spinner fa-spin';
      pollingIcon.style.color = '';
    }

    const pollOnce = async () => {
      if (!paymentPollingInvoiceId) return;
      try {
        const res = await fetch(`${checkinData.restUrl}mbbank-check-payment`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-WP-Nonce': checkinData.nonce,
          },
          body: JSON.stringify({ invoice_id: paymentPollingInvoiceId }),
        });
        const data = await res.json();

        // ✅ FIX: Xử lý lỗi 500 từ MonkeyPay (hết quota, server error)
        if (!res.ok) {
          const errMsg = data?.message || '';
          console.error('Payment polling API error:', res.status, errMsg);

          // Lỗi nghiêm trọng (hết quota, server down) → dừng polling, thông báo rõ
          if (res.status === 500 || res.status === 503) {
            stopPaymentPolling();
            if (pollingIcon) {
              pollingIcon.className = 'fas fa-exclamation-triangle';
              pollingIcon.style.color = '#e74c3c';
            }
            // Hiển thị lại polling section với thông báo lỗi
            if (pollingSection) pollingSection.classList.remove('hidden');
            if (statusText) {
              statusText.textContent = errMsg.includes('gói Free') || errMsg.includes('request')
                ? 'MonkeyPay hết quota. Vui lòng xác nhận thủ công.'
                : 'Lỗi hệ thống. Vui lòng xác nhận thủ công.';
            }
            return; // Không schedule next poll
          }

          // Lỗi tạm thời (4xx khác) → vẫn thử lại
          if (statusText) statusText.textContent = 'Lỗi kiểm tra, thử lại...';
          paymentPollingTimer = setTimeout(pollOnce, intervalMs);
          return;
        }

        if (data.success && !data.data?.already_paid) {
          // Thanh toán thành công!
          onPaymentConfirmed(invoiceId);
          return;
        }
        if (data.data?.already_paid) {
          onPaymentConfirmed(invoiceId);
          return;
        }
        // Chưa match → schedule next poll
        if (statusText) {
          statusText.textContent = 'Đang chờ thanh toán...';
        }
      } catch (err) {
        console.error('Payment polling error:', err);
        if (statusText) statusText.textContent = 'Lỗi kiểm tra, thử lại...';
      }
      // Schedule next
      paymentPollingTimer = setTimeout(pollOnce, intervalMs);
    };

    // Start first poll after interval
    paymentPollingTimer = setTimeout(pollOnce, intervalMs);
  }

  function stopPaymentPolling() {
    if (paymentPollingTimer) {
      clearTimeout(paymentPollingTimer);
      paymentPollingTimer = null;
    }
    paymentPollingInvoiceId = null;
    paymentPollingIsDBInvoice = false;
    hidePaymentPolling();
  }

  function hidePaymentPolling() {
    const pollingSection = document.getElementById('paymentPollingSection');
    if (pollingSection) pollingSection.classList.add('hidden');
  }

  /**
   * Phát âm thanh "ting-ting" khi thanh toán thành công
   * Sử dụng Web Audio API — không cần file âm thanh, hoạt động offline (PWA)
   */
  function playPaymentSuccessSound() {
    try {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      if (!AudioContext) return;

      const ctx = new AudioContext();

      // Tạo âm thanh "ting" — 2 nốt liên tiếp giống tiếng xu rơi
      const playTing = (frequency, startTime, duration) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();

        osc.connect(gain);
        gain.connect(ctx.destination);

        osc.type = 'sine';
        osc.frequency.setValueAtTime(frequency, startTime);

        // Envelope: attack nhanh, decay dần → tiếng "ting" trong trẻo
        gain.gain.setValueAtTime(0, startTime);
        gain.gain.linearRampToValueAtTime(0.3, startTime + 0.01);
        gain.gain.exponentialRampToValueAtTime(0.001, startTime + duration);

        osc.start(startTime);
        osc.stop(startTime + duration);
      };

      const now = ctx.currentTime;

      // Ting 1: C6 (1047 Hz) — nốt dài, vang
      playTing(1047, now, 0.9);
      // Ting 2: G6 (1568 Hz) — nốt cao (sau 0.3s)
      playTing(1568, now + 0.3, 0.6);
      // Ting 3: E6 (1319 Hz) — kết thúc (sau 0.55s)
      playTing(1319, now + 0.55, 0.4);

      // Cleanup sau khi âm thanh kết thúc
      setTimeout(() => ctx.close(), 20000);
    } catch (e) {
      // Không crash nếu audio không khả dụng
    }
  }

  function onPaymentConfirmed(invoiceId) {
    // ✅ FIX: Lưu isDBInvoice TRƯỚC khi stopPaymentPolling() reset biến
    const savedIsDBInvoice = paymentPollingIsDBInvoice;
    stopPaymentPolling();

    // ✅ FIX: Vô hiệu hóa nút Xác nhận NGAY LẬP TỨC để tránh thợ bấm trùng
    const confirmBtnImmediate = document.getElementById('confirmPaymentBtn');
    if (confirmBtnImmediate) {
      confirmBtnImmediate.disabled = true;
      confirmBtnImmediate.classList.add('hidden');
    }

    // Ẩn QR, bank info, polling section, total
    const qrCodeContainer = document.getElementById('qrCodeContainer');
    const bankTransferInfo = document.getElementById('bankTransferInfo');
    const pollingSection = document.getElementById('paymentPollingSection');
    const qrLabel = document.querySelector('.qr-payment-label');
    const qrTotal = document.querySelector('.qr-payment-total');
    const confirmBtn = elements.confirmPaymentBtn;

    if (qrCodeContainer) qrCodeContainer.classList.add('hidden');
    if (bankTransferInfo) bankTransferInfo.classList.add('hidden');
    if (pollingSection) pollingSection.classList.add('hidden');
    if (qrLabel) qrLabel.classList.add('hidden');
    if (qrTotal) qrTotal.classList.add('hidden');
    if (confirmBtn) confirmBtn.classList.add('hidden');

    // Phát âm thanh thành công
    playPaymentSuccessSound();

    // Tạo hiệu ứng thành công lớn thay thế QR
    const qrSection = elements.qrPaymentSection;
    if (qrSection) {
      qrSection.classList.remove('hidden');
      const successEl = document.createElement('div');
      successEl.className = 'payment-success-animation';
      successEl.innerHTML = `
        <div class="success-checkmark-wrapper">
          <svg class="success-checkmark" viewBox="0 0 100 100">
            <circle class="success-circle" cx="50" cy="50" r="45" />
            <polyline class="success-check" points="30,52 45,66 72,36" />
          </svg>
        </div>
        <p class="success-text">Thanh toán thành công!</p>
        <p class="success-subtext">Hóa đơn đã được xác nhận tự động</p>
      `;
      qrSection.appendChild(successEl);
    }

    // ✅ FIX: MonkeyPay backend đã xử lý DB (status=paid, payment_method=bank)
    // Không gọi completePayment() nữa để tránh race condition ghi đè payment_method
    // Chỉ cập nhật local state và refresh UI
    setTimeout(async () => {
      try {
        // Cập nhật local state cho invoice
        const invoice = savedIsDBInvoice
          ? invoicesData.find((inv) => inv.invoice_id === invoiceId)
          : invoices.find((inv) => inv.invoice_id === invoiceId || inv.id === invoiceId);

        if (invoice) {
          invoice.status = 'paid';
          invoice.payment_method = invoice.paymentMethod || 'bank';
          invoice.cashier = checkinData.currentUser?.display_name || 'Unknown';
        }

        // Gửi tin nhắn Zalo nếu không phải khách vãng lai
        if (invoice && invoice.customer_name !== 'KHÁCH VÃNG LAI') {
          if (invoice.message_status !== 'success') {
            try {
              const zaloResponse = await fetchAPI('send-invoice-message-type-zalo', {
                method: 'POST',
                body: JSON.stringify({ invoice_id: invoiceId }),
              });
              if (zaloResponse.success) {
                const idx = invoicesData.findIndex((inv) => inv.invoice_id === invoiceId);
                if (idx !== -1) {
                  invoicesData[idx].message_type = zaloResponse.message_type || 'zalo_oa';
                  invoicesData[idx].message_status = zaloResponse.message_status || 'success';
                }
              }
            } catch (zaloError) {
              console.error('Zalo message error (auto-confirm):', zaloError);
            }
          }
        }

        // Lưu và refresh UI
        saveInvoicesToLocalStorage();
        clearInvoicesDataCache();
        invalidateNewMemberDatesCache();

        // Đóng modals
        closeModal(elements.paymentMethodModal);
        closeModal(elements.invoicesDetailContent);

        // Reload data và render
        try {
          await reloadCurrentPeriodInvoices();
        } catch (e) {
          console.error('Failed to reload invoices after auto-confirm:', e);
        }

        if (savedIsDBInvoice) {
          renderInvoiceList();
        } else {
          renderInvoiceTabs();
          renderCurrentInvoice();
          if (currentSection === 'invoices') renderInvoiceList();
        }

        // Giữ nguyên vị trí đang thao tác — không tự cuộn lên đầu trang
        toastSuccess('Thanh toán thành công!');
      } catch (err) {
        console.error('Auto complete payment error:', err);
      }
    }, 4000);
  }

  async function openPaymentMethodModal(invoiceId, isDBInvoice = false) {
    const { paymentMethodModal, qrPaymentSection, confirmPaymentBtn } = elements;

    if (!paymentMethodModal || !qrPaymentSection || !confirmPaymentBtn) {
      await showError('Không tìm thấy modal thanh toán', 'Lỗi giao diện');
      return;
    }

    const invoice = isDBInvoice
      ? invoicesData.find((inv) => inv.invoice_id === invoiceId)
      : invoices.find((inv) => inv.invoice_id === invoiceId || inv.id === invoiceId);

    if (!invoice) {
      await showError('Không tìm thấy hóa đơn', 'Lỗi hóa đơn');
      return;
    }

    if (isDBInvoice) {
      if (invoice.status === 'paid') {
        await toastInfo('Hóa đơn đã được thanh toán', 'Thông báo');
        return;
      }

      if (!invoice.invoice_id) {
        await showError('Hóa đơn không hợp lệ', 'Lỗi hóa đơn');
        return;
      }
    }

    // Reset giao diện modal
    openModal(paymentMethodModal);
    qrPaymentSection.classList.add('hidden');
    hideCombinedPaymentSection(); // Ẩn phần combined payment
    confirmPaymentBtn.classList.add('hidden');
    confirmPaymentBtn.classList.remove('loading', 'success');
    confirmPaymentBtn.disabled = false;

    // Xóa success animation từ lần thanh toán trước (nếu có)
    const prevSuccess = qrPaymentSection.querySelector('.payment-success-animation');
    if (prevSuccess) prevSuccess.remove();

    // Reset các phần tử bị ẩn bởi onPaymentConfirmed
    const bankTransferInfo = document.getElementById('bankTransferInfo');
    const pollingSection = document.getElementById('paymentPollingSection');
    const qrLabel = document.querySelector('.qr-payment-label');
    const qrTotal = document.querySelector('.qr-payment-total');
    if (bankTransferInfo) bankTransferInfo.classList.remove('hidden');
    if (pollingSection) pollingSection.classList.add('hidden');
    if (qrLabel) qrLabel.classList.remove('hidden');
    if (qrTotal) qrTotal.classList.remove('hidden');

    // Reset QR code container
    const qrCodeContainer = document.getElementById('qrCodeContainer');
    if (qrCodeContainer) {
      qrCodeContainer.innerHTML = '';
      qrCodeContainer.classList.remove('hidden');
    }

    // Lấy danh sách phương thức thanh toán đã bật (chỉ QR-based)
    const enabledMethods = checkinData.paymentQRs ? Object.keys(checkinData.paymentQRs) : [];
    document.querySelectorAll('.payment-method-btn').forEach((btn) => {
      const method = btn.dataset.method;
      // combined luôn hiển thị cùng với cash
      const isEnabled =
        method === 'cash' || method === 'combined' || enabledMethods.includes(method);

      // Ẩn nút nếu phương thức không được bật (trừ cash và combined)
      if (!isEnabled) {
        btn.style.display = 'none';
        return;
      }

      // Reset style và thêm sự kiện nếu phương thức được bật
      btn.classList.remove('bg-blue-500', 'text-white', 'selected');
      btn.classList.add('bg-gray-100', 'text-gray-700');
      btn.style.display = ''; // Hiển thị lại nếu trước đó bị ẩn

      // Loại bỏ lắng nghe cũ nếu có (tránh trùng lặp) - Clone button
      const clone = btn.cloneNode(true);
      btn.replaceWith(clone);

      clone.addEventListener('click', () =>
        selectPaymentMethodHandler(clone.dataset.method, invoiceId, isDBInvoice)
      );
    });
  }

  async function selectPaymentMethodHandler(method, invoiceId, isDBInvoice) {
    if (!elements.qrPaymentSection || !elements.confirmPaymentBtn || !elements.qrPaymentAmount) {
      await showError('Không tìm thấy phần tử QR thanh toán', 'Lỗi giao diện');
      return;
    }

    const invoice = isDBInvoice
      ? invoicesData.find((inv) => inv.invoice_id === invoiceId)
      : invoices.find((inv) => inv.invoice_id === invoiceId || inv.id === invoiceId);

    if (!invoice) {
      await showError('Không tìm thấy hóa đơn', 'Lỗi dữ liệu');
      return;
    }

    invoice.paymentMethod = method;
    // Update button styles
    document.querySelectorAll('.payment-method-btn').forEach((btn) => {
      const isSelected = btn.dataset.method === method && btn.style.display !== 'none';
      btn.classList.toggle('selected', isSelected);
    });

    const qrCodeContainer = document.getElementById('qrCodeContainer');
    if (!qrCodeContainer) {
      await showError('Không tìm thấy container QR', 'Lỗi giao diện');
      return;
    }

    const totalFormatted = formatCurrency(invoice.total);
    const showQRCode = (src) => {
      elements.qrPaymentAmount.textContent = totalFormatted;
      elements.qrPaymentSection.classList.remove('hidden');
      qrCodeContainer.innerHTML = `<img src="${src}" alt="${method} QR Code">`;
    };

    /**
     * Helper: Lấy QR URL theo branch_id nếu site bật multi-branch
     * @param {string} type - 'bank', 'momo', 'zalopay'
     * @param {string} defaultUrl - URL mặc định nếu không tìm thấy
     * @returns {string} QR URL
     */
    const getPaymentQRUrl = (type, defaultUrl) => {
      const paymentData = checkinData.paymentQRs?.[type];
      if (!paymentData) return defaultUrl;

      // Nếu chế độ QR per branch được bật và có branch_id
      if (paymentData.qr_per_branch && paymentData.qr_branches) {
        const rawBranchId = branchHelper?.getCurrentBranchId();
        if (rawBranchId) {
          // Thử cả string và integer key vì PHP có thể lưu dưới dạng khác nhau
          const branchIdStr = String(rawBranchId);
          const branchIdInt = parseInt(rawBranchId, 10);
          const qrUrl =
            paymentData.qr_branches[branchIdStr] || paymentData.qr_branches[branchIdInt];
          if (qrUrl) {
            return qrUrl;
          }
        }
      }

      // Fallback về QR mặc định
      return paymentData.qr_url || defaultUrl;
    };

    if (method === 'cash') {
      elements.qrPaymentSection.classList.add('hidden');
      hideCombinedPaymentSection();
      hideBankTransferInfo();
      stopPaymentPolling();
    } else if (method === 'bank') {
      hideCombinedPaymentSection();
      const bankData = checkinData.paymentQRs?.bank;
      if (bankData?.account_number && bankData?.bank_bin) {
        if (bankData.is_monkeypay) {
          // MonkeyPay mode (both auto & manual): call API to create/poll TX
          let shouldStartPolling = true;
          try {
            const res = await fetch(`${checkinData.restUrl}mbbank-check-payment`, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'X-WP-Nonce': checkinData.nonce,
              },
              body: JSON.stringify({ invoice_id: invoice.invoice_id }),
            });
            const data = await res.json();

            // ✅ FIX: Xử lý lỗi 500 từ MonkeyPay (hết quota)
            if (!res.ok && (res.status === 500 || res.status === 503)) {
              const errMsg = data?.message || '';
              console.error('MonkeyPay init error:', res.status, errMsg);
              shouldStartPolling = false; // Không poll nếu MonkeyPay lỗi

              // Vẫn hiển thị QR tĩnh để thợ xác nhận thủ công
              const addInfo = generatePaymentNote(bankData, invoice.invoice_id);
              let vietQRUrl = `https://img.vietqr.io/image/${bankData.bank_bin}-${bankData.account_number}-compact2.png`
                + `?addInfo=${encodeURIComponent(addInfo)}`
                + `&accountName=${encodeURIComponent(bankData.account_name || '')}`;
              if (bankData.auto_amount) {
                vietQRUrl += `&amount=${Math.round(invoice.total)}`;
              }
              showQRCode(vietQRUrl);
              showBankTransferInfo(addInfo);

              // Hiện thông báo lỗi cho thợ
              toastWarning(
                errMsg.includes('gói Free') || errMsg.includes('request')
                  ? 'MonkeyPay hết quota. Vui lòng xác nhận thanh toán thủ công.'
                  : 'Không thể kết nối MonkeyPay. Vui lòng xác nhận thủ công.'
              );
            } else {
              const mpNote = data.data?.payment_note || '';
              const addInfo = mpNote || generatePaymentNote(bankData, invoice.invoice_id);

              // Build VietQR URL
              let vietQRUrl = `https://img.vietqr.io/image/${bankData.bank_bin}-${bankData.account_number}-compact2.png`
                + `?addInfo=${encodeURIComponent(addInfo)}`
                + `&accountName=${encodeURIComponent(bankData.account_name || '')}`;

              // Auto mode: include amount in QR; Manual mode: no amount
              if (bankData.auto_amount) {
                vietQRUrl += `&amount=${Math.round(invoice.total)}`;
              }

              showQRCode(vietQRUrl);
              showBankTransferInfo(addInfo);
            }
          } catch (err) {
            console.error('MonkeyPay init error:', err);
            shouldStartPolling = false; // Network error → không poll
            // Fallback: generate local payment note
            const addInfo = generatePaymentNote(bankData, invoice.invoice_id);
            let vietQRUrl = `https://img.vietqr.io/image/${bankData.bank_bin}-${bankData.account_number}-compact2.png`
              + `?addInfo=${encodeURIComponent(addInfo)}`
              + `&accountName=${encodeURIComponent(bankData.account_name || '')}`;
            if (bankData.auto_amount) {
              vietQRUrl += `&amount=${Math.round(invoice.total)}`;
            }
            showQRCode(vietQRUrl);
            showBankTransferInfo(addInfo);
          }
          // ✅ FIX: Chỉ poll khi MonkeyPay init thành công
          if (shouldStartPolling) {
            startPaymentPolling(invoice.invoice_id, isDBInvoice);
          }
        } else {
          // Legacy mode: generate local payment note, no polling
          const addInfo = generatePaymentNote(bankData, invoice.invoice_id);
          const vietQRUrl = `https://img.vietqr.io/image/${bankData.bank_bin}-${bankData.account_number}-compact2.png`
            + `?amount=${Math.round(invoice.total)}&addInfo=${encodeURIComponent(addInfo)}`
            + `&accountName=${encodeURIComponent(bankData.account_name || '')}`;
          showQRCode(vietQRUrl);
          showBankTransferInfo(addInfo);
          hidePaymentPolling();
        }
      } else {
        // Fallback: QR tĩnh cũ
        const qrUrl = getPaymentQRUrl(
          'bank',
          'https://vangroupbarbershop.store/wp-content/uploads/2025/05/Untitled.png'
        );
        showQRCode(qrUrl);
        hideBankTransferInfo();
        stopPaymentPolling();
      }
    } else if (method === 'momo') {
      hideCombinedPaymentSection();
      hideBankTransferInfo();
      stopPaymentPolling();
      const qrUrl = getPaymentQRUrl(
        'momo',
        'https://vangroupbarbershop.store/wp-content/uploads/2025/05/MOMO-NGOC-QUYNH.png'
      );
      showQRCode(qrUrl);
    } else if (method === 'zalopay') {
      hideCombinedPaymentSection();
      hideBankTransferInfo();
      stopPaymentPolling();
      const qrUrl = getPaymentQRUrl(
        'zalopay',
        'https://vangroupbarbershop.store/wp-content/uploads/2025/05/ZALOPAY-DEFAULT.png'
      );
      showQRCode(qrUrl);
    } else if (method === 'combined') {
      // Hiển thị phần nhập tiền kết hợp
      elements.qrPaymentSection.classList.add('hidden');
      hideBankTransferInfo();
      stopPaymentPolling();
      showCombinedPaymentSection(invoice.total);
    }

    // Tìm button trực tiếp từ DOM mỗi lần để đảm bảo lấy đúng element
    const confirmBtn = document.getElementById('confirmPaymentBtn');
    if (!confirmBtn) {
      return;
    }

    // Clone button để loại bỏ tất cả event listeners cũ
    const newConfirmBtn = confirmBtn.cloneNode(true);
    confirmBtn.parentNode.replaceChild(newConfirmBtn, confirmBtn);

    // Cập nhật reference trong elements object
    elements.confirmPaymentBtn = newConfirmBtn;

    // ✅ FIX: Capture method trong closure để tránh mất khi invoice object bị refresh từ DB
    const capturedMethod = method;

    // Hiển thị button và gán event listener mới
    newConfirmBtn.classList.remove('hidden');
    newConfirmBtn.addEventListener('click', async function (e) {
      e.preventDefault();
      e.stopPropagation();

      // Prevent double-click
      if (newConfirmBtn.classList.contains('loading') || newConfirmBtn.disabled) {
        return;
      }

      // Validate combined payment if applicable
      if (capturedMethod === 'combined') {
        const validation = validateCombinedPayment(invoice.total);
        if (!validation.valid) {
          await showError(validation.message);
          return;
        }
        // Lưu chi tiết thanh toán kết hợp vào invoice
        invoice.combinedPaymentDetails = validation.details;
      }

      // Add loading state
      setButtonLoading(newConfirmBtn, 'Đang xử lý...');

      try {
        await completePayment(invoiceId, isDBInvoice, capturedMethod);
      } catch (error) {
        console.error('Payment error:', error);
      } finally {
        // ✅ Luôn reset button trong finally
        resetButtonLoading(newConfirmBtn);
      }
    });
    toastSuccess('Đã chọn phương thức thanh toán');
  }

  async function completePayment(invoiceId, isDBInvoice, selectedPaymentMethod) {
    if (!elements.paymentMethodModal) {
      return;
    }

    const invoice = isDBInvoice
      ? invoicesData.find((inv) => inv.invoice_id === invoiceId)
      : invoices.find((inv) => inv.invoice_id === invoiceId || inv.id === invoiceId);

    if (!invoice) {
      await showError('Không tìm thấy hóa đơn');
      return;
    }

    // 🛡️ CHỐT CHẶN: hoá đơn còn thay đổi chưa lưu (sửa dịch vụ/đổi thợ) thì phải
    // lưu lên DB thành công TRƯỚC khi thanh toán — nếu không sẽ chốt sổ với
    // dịch vụ/thợ CŨ trong DB dù màn hình đang hiển thị bản mới.
    const localInvoiceForPay = invoices.find(
      (inv) => inv.invoice_id === invoiceId || inv.id === invoiceId
    );
    if (localInvoiceForPay && localInvoiceForPay.isDirty && localInvoiceForPay.invoice_id) {
      if (!Array.isArray(localInvoiceForPay.services) || localInvoiceForPay.services.length === 0) {
        await showError('Hóa đơn chưa có dịch vụ nào. Hãy thêm dịch vụ trước khi thanh toán!');
        return;
      }
      const saved = await saveInvoiceToDB(localInvoiceForPay);
      if (!saved) {
        await showError('Chưa lưu được thay đổi của hóa đơn — vui lòng thử lại trước khi thanh toán!');
        return;
      }
    }

    const cashier = checkinData.currentUser?.is_logged_in
      ? checkinData.currentUser.display_name
      : 'Unknown';

    invoice.status = 'paid';
    invoice.cashier = cashier;

    try {
      // ✅ FIX: Ưu tiên dùng selectedPaymentMethod từ closure (chắc chắn đúng)
      // Fallback chain: closure param > invoice.paymentMethod > invoice.payment_method > 'cash'
      const finalPaymentMethod = selectedPaymentMethod || invoice.paymentMethod || invoice.payment_method || 'cash';

      // Chuẩn bị dữ liệu cập nhật
      const updatePayload = {
        payment_method: finalPaymentMethod,
        status: 'paid',
        promo_name: invoice.promoName,
        cashier,
      };

      // Thêm chi tiết thanh toán kết hợp nếu có
      if (finalPaymentMethod === 'combined' && invoice.combinedPaymentDetails) {
        updatePayload.combined_payment_details = invoice.combinedPaymentDetails;
      }

      const updatedInvoice = await fetchAPI(`invoices/${invoice.invoice_id}`, {
        method: 'PUT',
        body: JSON.stringify(updatePayload),
      });

      // Cập nhật invoicesData
      const indexInData = invoicesData.findIndex((inv) => inv.invoice_id === invoiceId);
      const updatedData = {
        ...invoice,
        status: 'paid',
        payment_method: invoice.paymentMethod,
        combined_payment_details: invoice.combinedPaymentDetails || null,
        promo_name: invoice.promoName,
        cashier,
        ...updatedInvoice,
      };

      if (indexInData !== -1) {
        invoicesData[indexInData] = updatedData;
      } else {
        invoicesData.push(updatedData);
      }

      // Nếu là invoice chưa lưu DB thì cũng cập nhật local
      if (!isDBInvoice) {
        const index = invoices.findIndex(
          (inv) => inv.invoice_id === invoiceId || inv.id === invoiceId
        );
        if (index !== -1) {
          invoices[index] = updatedData;
        }
      }

      // Gửi tin nhắn Zalo nếu không phải khách vãng lai và chưa gửi thành công trước đó
      if (invoice.customer_name !== 'KHÁCH VÃNG LAI') {
        if (invoice.message_status === 'success') {
        } else {
          try {
            const zaloResponse = await fetchAPI('send-invoice-message-type-zalo', {
              method: 'POST',
              body: JSON.stringify({ invoice_id: invoiceId }),
            });

            if (zaloResponse.success) {
              // 🔄 Cập nhật realtime message_type và message_status vào invoicesData
              const invoiceIndex = invoicesData.findIndex((inv) => inv.invoice_id === invoiceId);
              if (invoiceIndex !== -1) {
                invoicesData[invoiceIndex].message_type = zaloResponse.message_type || 'zalo_oa';
                invoicesData[invoiceIndex].message_status =
                  zaloResponse.message_status || 'success';
              }
            } else {
              // Cập nhật status = failed nếu gửi thất bại
              const invoiceIndex = invoicesData.findIndex((inv) => inv.invoice_id === invoiceId);
              if (invoiceIndex !== -1) {
                invoicesData[invoiceIndex].message_status = 'failed';
              }
            }
          } catch (zaloError) {
            // Cập nhật status = failed nếu có lỗi
            const invoiceIndex = invoicesData.findIndex((inv) => inv.invoice_id === invoiceId);
            if (invoiceIndex !== -1) {
              invoicesData[invoiceIndex].message_status = 'failed';
            }
          }
        }
      }

      saveInvoicesToLocalStorage();

      // ✅ Clear cache và refresh data sau khi thanh toán thành công
      clearInvoicesDataCache();
      invalidateNewMemberDatesCache(); // Clear cache thành viên mới khi có thanh toán

      // Show success state briefly
      if (elements.confirmPaymentBtn) {
        elements.confirmPaymentBtn.classList.remove('loading');
        elements.confirmPaymentBtn.classList.add('success');
        await new Promise((resolve) => setTimeout(resolve, 800)); // Wait 800ms to show success
      }

      // Reset payment method state
      invoice.paymentMethod = null;

      // Close modals
      closeModal(elements.paymentMethodModal);
      closeModal(elements.invoicesDetailContent);

      // ✅ Reload data theo period hiện tại (7days nếu đang xem today/yesterday)
      try {
        await reloadCurrentPeriodInvoices();
      } catch (e) {
        console.error('Failed to reload invoices after payment:', e);
      }

      // Refresh UI
      if (isDBInvoice) {
        renderInvoiceList();
      } else {
        renderInvoiceTabs();
        renderCurrentInvoice();
        if (currentSection === 'invoices') renderInvoiceList();
      }

      // Giữ nguyên vị trí đang thao tác — không tự cuộn lên đầu trang
      toastSuccess('Thanh toán thành công!');
    } catch (error) {
      await showError('Lỗi khi thanh toán');
      throw error; // Re-throw để finally của caller xử lý reset button
    }
    // ✅ KHÔNG tự remove loading - finally của caller sẽ xử lý
  }

  // ==============================
  // 7. INVOICE SYSTEM
  // ==============================

  // --- Invoice Storage & Lifecycle ---
  function createDefaultInvoice() {
    return {
      id: invoices.length + 1,
      customer: null,
      services: [],
      status: 'pending',
      subtotal: 0,
      discount: 0,
      tips: 0,
      total: 0,
      paymentMethod: null,
      images: [],
      created_user: checkinData.currentUser.display_name,
      invoice_id: null,
      booking_id: null,
      promoName: null,
      discountType: 'percent',
      isFromDB: false,
      isDirty: true,
      created_at: new Date().toISOString(), // Thêm created_at để sắp xếp
    };
  }

  async function loadInvoicesFromLocalStorage() {
    if (!checkinData.currentUser || !checkinData.currentUser.is_logged_in) return;

    const userId = checkinData.currentUser.id;
    const deviceId = navigator.userAgent;
    const key = `invoices_${userId}_${deviceId}`;

    let storedInvoices = localStorage.getItem(key);
    invoices = [];

    if (storedInvoices) {
      const parsedInvoices = JSON.parse(storedInvoices).map((invoice) => ({
        ...invoice,
        status: invoice.status === 'paid' ? 'paid' : 'pending',
        tips: parseFloat(invoice.tips) || 0,
        discount: parseFloat(invoice.discount) || 0,
        total: parseFloat(invoice.total) || 0,
        subtotal: parseFloat(invoice.subtotal) || 0,
        services: safeParseJSON(invoice.services, []).map((s) => ({
          service_id: s.service_id || null,
          service_name: s.service_name || 'Dịch vụ không xác định',
          price: parseFloat(s.price) || 0,
          staff_id: s.staff_id || null,
          staff_name: s.staff_name || 'Thợ không xác định',
          type: s.type || 'service',
          quantity: s.quantity || 1,
        })),
        images: safeParseJSON(invoice.images, []),
        isFromDB: invoice.isFromDB || false,
      }));

      // Kiểm tra và đồng bộ services từ invoicesData nếu rỗng
      const hasEmptyServices = parsedInvoices.some(
        (inv) =>
          inv.isFromDB &&
          inv.services.length === 0 &&
          invoicesData.some(
            (dbInv) => dbInv.invoice_id === inv.invoice_id && dbInv.services.length > 0
          )
      );

      if (hasEmptyServices) {
        parsedInvoices.forEach((inv, index) => {
          if (inv.isFromDB && inv.services.length === 0) {
            const dbInvoice = invoicesData.find((dbInv) => dbInv.invoice_id === inv.invoice_id);
            if (dbInvoice && dbInvoice.services.length > 0) {
              parsedInvoices[index].services = dbInvoice.services.map((s) => ({
                service_id: s.service_id || null,
                service_name: s.service_name || 'Dịch vụ không xác định',
                price: parseFloat(s.price) || 0,
                staff_id: s.staff_id || null,
                staff_name: s.staff_name || 'Thợ không xác định',
                type: s.type || 'service',
                quantity: s.quantity || 1,
              }));
            }
          }
        });
        invoices = parsedInvoices;
        saveInvoicesToLocalStorage(); // Lưu lại sau khi đồng bộ
      } else {
        invoices = parsedInvoices;
      }
    }

    // 🔧 FIX 1: Sửa logic chọn hóa đơn mặc định - LUÔN CHỌN MỚI NHẤT
    if (invoices.length > 0) {
      let newestIdx = 0;
      let newestTime = -Infinity;

      invoices.forEach((inv, idx) => {
        const t = new Date(inv.created_at || 0).getTime();
        if (t > newestTime) {
          newestTime = t;
          newestIdx = idx;
        }
      });

      currentInvoiceIndex = newestIdx;
    } else {
      currentInvoiceIndex = 0;
    }

    // Sync customer photos từ localStorage cho tất cả invoices
    invoices.forEach((invoice, index) => {
      if (invoice.customer && invoice.customer.id) {
        const syncedCustomer = syncCustomerFromLocalStorage(index, invoice.customer.id);
        if (syncedCustomer) {
          // Customer đã được sync trong syncCustomerFromLocalStorage
        }
      }
    });

    // Đồng bộ với invoicesData
    for (const invoice of invoices.filter(
      (inv) => inv.isFromDB && inv.invoice_id && inv.invoice_id !== 'unpaid'
    )) {
      try {
        const dbInvoice = invoicesData.find((inv) => inv.invoice_id === invoice.invoice_id);
        if (dbInvoice) {
          const index = invoices.findIndex((inv) => inv.invoice_id === invoice.invoice_id);
          invoices[index] = {
            ...invoices[index],
            status: dbInvoice.status,
            subtotal: parseFloat(dbInvoice.subtotal) || invoices[index].subtotal,
            discount: parseFloat(dbInvoice.discount) || invoices[index].discount,
            tips: parseFloat(dbInvoice.tips) || invoices[index].tips,
            total: parseFloat(dbInvoice.total) || invoices[index].total,
            services: (dbInvoice.services || []).map((s) => ({
              service_id: s.service_id || null,
              service_name: s.service_name || 'Dịch vụ không xác định',
              price: parseFloat(s.price) || 0,
              staff_id: s.staff_id || null,
              staff_name: s.staff_name || 'Thợ không xác định',
              type: s.type || 'service',
              quantity: s.quantity || 1,
            })),
            images: dbInvoice.images || invoices[index].images,
            promoName: dbInvoice.promo_name || invoices[index].promoName,
            discountType: dbInvoice.discount_type || invoices[index].discountType,
            isFromDB: true,
          };
        }
      } catch (error) {}
    }

    // ✅ OPTIMIZED: Không gọi API ở đây - chỉ load từ localStorage
    // API sẽ được gọi một lần duy nhất trong initializeApp() -> loadStaffInvoices('7days')
    // Điều này tránh gọi API trùng lặp khi khởi tạo app
    saveInvoicesToLocalStorage();
  }

  /**
   * Lưu hoá đơn lên DB.
   * @param {Object} [invoiceParam] Hoá đơn cần lưu — caller NÊN truyền object mình
   *        vừa sửa (tránh đọc lại invoices[currentInvoiceIndex]: mảng có thể đã bị
   *        reload thay thế giữa chừng, index lệch → lưu nhầm/lưu dữ liệu cũ).
   * @returns {boolean} true nếu lưu thành công.
   */
  async function saveInvoiceToDB(invoiceParam) {
    const invoice = invoiceParam || invoices[currentInvoiceIndex];
    if (!invoice) return false;

    try {
      if (elements.promoListSelect) {
        invoice.promoName = elements.promoListSelect.value || null;
      }

      const isNew = !invoice.invoice_id;
      const invoiceData = prepareInvoiceData(invoice, isNew);
      const method = isNew ? 'POST' : 'PUT';
      const endpoint = isNew ? 'invoices' : `invoices/${invoice.invoice_id}`;

      const response = await fetchAPI(endpoint, {
        method,
        body: JSON.stringify(invoiceData),
      });

      if (!response || response.success === false) {
        throw new Error(response.message || 'Phản hồi API không hợp lệ');
      }

      if (isNew) {
        const { invoice_id, booking_id } = response.data;
        Object.assign(invoice, {
          invoice_id,
          booking_id: booking_id || null,
          status: 'pending',
          isFromDB: true,
        });

        invoicesData.push({
          ...invoiceData,
          invoice_id,
          booking_id: booking_id || null,
          services: invoiceData.services,
          images: invoiceData.images || [],
        });
      } else {
        const index = invoicesData.findIndex((inv) => inv.invoice_id === invoice.invoice_id);
        if (index !== -1) {
          invoicesData[index] = {
            ...invoicesData[index],
            ...invoiceData,
            services: invoiceData.services,
            booking_id: invoiceData.booking_id,
            // ⚠️ Payload update KHÔNG còn chứa images (server tự quản) — phải giữ
            // ảnh từ local/mirror, nếu lấy invoiceData.images sẽ wipe thành []
            // → ảnh biến mất trên UI + modal báo "Chưa up" dù đã upload
            images:
              (invoice.images && invoice.images.length
                ? invoice.images
                : invoicesData[index].images) || [],
            promo_name: invoice.promoName,
            discount_type: invoice.discountType,
          };
        }
      }

      invoice.isDirty = false;
      invoice.images = invoice.images || [];

      // Ẩn nút tạo hóa đơn và hiển thị 2 nút còn lại
      elements.createInvoiceBtn.classList.add('hidden');
      if (elements.reviewInvoiceBtn) {
        elements.reviewInvoiceBtn.classList.remove('hidden');
      }
      if (elements.payInvoiceBtn) {
        elements.payInvoiceBtn.classList.remove('hidden');
      }

      if (!isUserInteractingWithElements()) {
        isUserInteracting = false;
      }

      // 💾 Lưu invoice_id trước khi reload (vì invoice object sẽ bị thay thế)
      const savedInvoiceId = invoice.invoice_id;

      saveInvoicesToLocalStorage();

      // ✅ Refresh data sau khi lưu invoice (có thể tạo thành viên mới)
      clearInvoicesDataCache();
      invalidateNewMemberDatesCache(); // Clear cache vì có thể khách hàng mới được upgrade
      try {
        await reloadCurrentPeriodInvoices();

        // 🎯 ACTIVE HÓA ĐƠN VỪA TẠO/CẬP NHẬT (dùng savedInvoiceId vì invoice đã bị replace)
        if (savedInvoiceId) {
          const newIndex = invoices.findIndex((inv) => inv.invoice_id === savedInvoiceId);
          if (newIndex !== -1) {
            currentInvoiceIndex = newIndex;
            console.log(
              '🎯 Switched to saved invoice ID:',
              savedInvoiceId,
              'at index:',
              currentInvoiceIndex
            );
          } else {
            console.warn('⚠️ Could not find invoice with ID:', savedInvoiceId);
          }
        }
      } catch (e) {
        console.error('Failed to reload after invoice save:', e);
      }

      // ⚡ Chỉ render lại toàn trang khi TẠO MỚI — với cập nhật, handler thao tác
      // đã update đúng phần UI liên quan; render lại lần 2 (rebuild lưới dịch vụ,
      // tab, thông tin khách) chính là nguyên nhân trang bị chớp sau mỗi thao tác
      if (isNew) {
        renderInvoiceTabs();
        await renderCurrentInvoice();
      }
      if (currentSection === 'invoices') {
        renderInvoiceList();
      }

      // Chỉ cuộn lên đầu khi TẠO MỚI (về khu nhập khách); cập nhật thì giữ
      // nguyên vị trí thợ đang thao tác
      if (isNew) {
        smoothScrollToTop();
        setTimeout(() => {
          toastSuccess('Tạo hóa đơn thành công!');
        }, 300);
      } else {
        toastSuccess('Cập nhật hóa đơn thành công!');
      }
      return true;
    } catch (error) {
      await showError(error.message || 'Lỗi khi lưu hóa đơn');
      return false;
    }
  }

  // Hàm hỗ trợ tạo dữ liệu hóa đơn
  function prepareInvoiceData(invoice, isNew = true) {
    if (!invoice.customer || invoice.services.length === 0) {
      throw new Error('Vui lòng chọn khách hàng và ít nhất một dịch vụ');
    }
    if (!invoice.services.every((s) => s.service_name && s.staff_name && s.price)) {
      throw new Error('Dữ liệu dịch vụ không đầy đủ. Vui lòng kiểm tra lại.');
    }

    // ✅ Đảm bảo customer_name luôn được gửi đúng (không phải 'KHÁCH VÃNG LAI')
    const customerName =
      invoice.customer.name && invoice.customer.name !== 'KHÁCH VÃNG LAI'
        ? invoice.customer.name
        : invoice.customer.name || 'Khách không tên';

    const payload = {
      customer_id: invoice.customer.id,
      customer_name: customerName,
      customer_phone: invoice.customer.phone,
      promo_code: invoice.customer.promoCode || null,
      promo_status: promoStatus || null,
      promo_name: invoice.promoName || null, // Lấy trực tiếp từ invoice.promoName
      membership_label: invoice.customer.membership || 'Khách thường',
      services: invoice.services.map((s) => ({
        service_id: s.service_id,
        service_name: s.service_name,
        price: s.price,
        staff_id: s.staff_id,
        staff_name: s.staff_name,
        type: s.type,
        quantity: s.quantity,
      })),
      cashier: null,
      payment_method: invoice.paymentMethod,
      ctkm: null,
      subtotal: invoice.subtotal,
      discount: invoice.discount,
      tips: invoice.tips,
      total: invoice.total,
      status: invoice.status || 'pending',
      created_user: checkinData.currentUser.display_name,
      discount_type: invoice.discountType || 'percent',
      booking_id: invoice.booking_id || null,
      new_customer: invoice.customer.new_customer || null,
      branch_id: branchHelper?.getCurrentBranchId() || null, // Gửi branch_id đã chọn thay vì dùng mặc định từ staff table
    };

    // ⚠️ KHÔNG gửi images khi update (PUT): trường images do upload API + cron
    // quản lý. Gửi bản local (temp URL cũ) sẽ ghi đè mất URL WebP trong DB
    // → ảnh khách "biến mất". Server cũng đã chặn, đây là lớp bảo vệ thứ 2.
    if (isNew) {
      payload.images = invoice.images || [];
    }

    return payload;
  }

  async function deleteInvoiceFromDB(invoiceId) {
    try {
      const invoice = invoicesData.find((inv) => inv.invoice_id === invoiceId);
      const customerName = invoice?.customer_name || 'Không xác định';

      const confirmed = await showConfirm(
        `Bạn có chắc muốn xóa hóa đơn của khách ${customerName}?`,
        'Xác nhận xóa'
      );

      if (!confirmed) return;

      await fetchAPI(`invoices/${invoiceId}`, { method: 'DELETE' });

      // Xóa khỏi invoicesData (dữ liệu từ DB)
      const invoicesDataIndex = invoicesData.findIndex((inv) => inv.invoice_id === invoiceId);
      if (invoicesDataIndex !== -1) invoicesData.splice(invoicesDataIndex, 1);

      // Xóa khỏi invoices (tabs đang mở)
      const invoicesIndex = invoices.findIndex((inv) => inv.invoice_id === invoiceId);
      if (invoicesIndex !== -1) {
        invoices.splice(invoicesIndex, 1);

        // Điều chỉnh currentInvoiceIndex nếu cần
        if (currentInvoiceIndex >= invoicesIndex && invoices.length > 0) {
          currentInvoiceIndex = Math.max(0, currentInvoiceIndex - 1);
        }
      }

      // Xóa khỏi localStorage
      clearDeletedInvoiceFromLocalStorage(invoiceId);
      saveInvoicesToLocalStorage();

      // Re-render UI
      renderInvoiceList();
      renderInvoiceTabs();
      renderCurrentInvoice();

      toastSuccess('Xóa hóa đơn thành công!');
    } catch (error) {
      await showError('Lỗi khi xóa hóa đơn', 'Lỗi');
    }
  }
  // ==============================
  // 11. PROMO & DISCOUNT SYSTEM
  // ==============================

  function applyPromoLogic(invoice, servicesData, ctkmList, vouchers) {
    // ✅ BƯỚC 1: Kiểm tra nếu khách là thành viên có new_code hợp lệ → Tự động chọn CTKM phù hợp
    const customer = invoice?.customer;
    const isMember = customer?.membership === 'Thành Viên';
    const hasNewCode = customer?.promoCode && customer.promoCode !== 'Không có';
    const hasValidStatus = customer?.promoStatus === 'CÓ HIỆU LỰC';

    if (isMember && hasNewCode && hasValidStatus) {
      // ✅ FIX: Tìm TẤT CẢ CTKM phù hợp, sau đó ưu tiên theo độ cụ thể
      const eligibleCTKMs = ctkmList.filter((ctkm) => {
        const membershipLabels = Array.isArray(ctkm.membership_label)
          ? ctkm.membership_label
          : [ctkm.membership_label || 'Tất cả'];

        const isForMember =
          membershipLabels.includes('Thành Viên') ||
          membershipLabels.includes('VIP') ||
          membershipLabels.includes('Tất cả');
        const isActive = ctkm.status === 'active';

        // Kiểm tra thời gian hiệu lực
        const today = new Date();
        const startDate = new Date(ctkm.start_date);
        const endDate = new Date(ctkm.end_date);
        const isInPeriod = today >= startDate && today <= endDate;

        return isForMember && isActive && isInPeriod;
      });

      if (eligibleCTKMs.length > 0) {
        // ✅ ƯU TIÊN:
        // 1. CTKM có membership_label CỤ THỂ ("Thành Viên") trước
        // 2. Nếu cùng độ ưu tiên, chọn giá trị CAO NHẤT
        const sortedCTKMs = eligibleCTKMs.sort((a, b) => {
          const labelsA = Array.isArray(a.membership_label)
            ? a.membership_label
            : [a.membership_label];
          const labelsB = Array.isArray(b.membership_label)
            ? b.membership_label
            : [b.membership_label];

          // Priority: Cụ thể ("Thành Viên", "VIP") > Chung ("Tất cả")
          const isSpecificA = labelsA.some((l) => l === 'Thành Viên' || l === 'VIP');
          const isSpecificB = labelsB.some((l) => l === 'Thành Viên' || l === 'VIP');

          if (isSpecificA && !isSpecificB) return -1; // A cụ thể hơn
          if (!isSpecificA && isSpecificB) return 1; // B cụ thể hơn

          // Cùng độ ưu tiên → Chọn giá trị cao nhất
          return parseFloat(b.value) - parseFloat(a.value);
        });

        const eligibleCTKM = sortedCTKMs[0];
        return {
          promoName: eligibleCTKM.ctkm_name,
          discountValue: parseFloat(eligibleCTKM.value) || 0,
          discountType: 'fixed',
        };
      }
    }

    // ✅ BƯỚC 2: Kiểm tra discounted_price CHỈ KHI KHÔNG CÓ CTKM THÀNH VIÊN
    // Lưu ý: Khi dùng discounted_price, subtotal đã bao gồm giá giảm
    // → Cần tính totalDiscount để HIỂN THỊ, nhưng KHÔNG TRỪ VÀO TOTAL
    const discountedServices = invoice.services.filter((s) => {
      if (s.type === 'product') return false;
      const serviceData = servicesData.find((srv) => srv.service_name === s.service_name);
      return serviceData?.discounted_price && parseFloat(serviceData.discounted_price) > 0;
    });

    let totalDiscount = 0;
    let promoName = null;

    // Kiểm tra voucher cho các dịch vụ có discounted_price
    if (discountedServices.length > 0) {
      discountedServices.forEach((s) => {
        const serviceData = servicesData.find((srv) => srv.service_name === s.service_name);
        const matchingVoucher = vouchers.find((voucher) => {
          const applicableServices = voucher.applicable_services || '[]';
          return applicableServices.includes(serviceData.service_id);
        });

        if (matchingVoucher) {
          // Nếu có voucher khớp, sử dụng tên và giá trị voucher
          promoName = matchingVoucher.ctkm_name;
          totalDiscount += parseFloat(matchingVoucher.value) * (s.quantity || 1);
        } else {
          // Tính giảm giá từ discounted_price (CHỈ ĐỂ HIỂN THỊ)
          totalDiscount +=
            (parseFloat(serviceData.service_price) - parseFloat(serviceData.discounted_price)) *
            (s.quantity || 1);
          promoName = promoName || 'Giảm giá dịch vụ';
        }
      });

      // Nếu có từ 2 dịch vụ trở lên, ưu tiên "Ưu đãi Combo"
      if (discountedServices.length >= 2 && !promoName.includes('HS-SV')) {
        promoName = 'Ưu đãi Combo';
      }

      // ⚠️ QUAN TRỌNG: totalDiscount CHỈ ĐỂ HIỂN THỊ CHO KHÁCH HÀNG
      // Vì subtotal đã dùng discounted_price rồi (giá đã giảm)
      // → Trả về totalDiscount để hiển thị trong UI, nhưng KHÔNG trừ vào total (vì đã trừ trong subtotal)
      //
      // Ví dụ: Dịch vụ giá gốc 100k, ưu đãi 90k
      //   - Subtotal = 90k (đã dùng discounted_price)
      //   - totalDiscount = 10k (hiển thị cho khách thấy)
      //   - Total = 90k - 0 = 90k (KHÔNG trừ totalDiscount vì đã giảm trong subtotal)
      return {
        promoName,
        discountValue: totalDiscount, // ✅ Trả về để HIỂN THỊ
        discountType: 'display_only', // ✅ Đánh dấu là CHỈ HIỂN THỊ, không trừ vào total
      };
    }

    // Kiểm tra voucher nếu không có dịch vụ nào có discounted_price
    const matchingVoucher = vouchers.find((voucher) => {
      const applicableServices = voucher.applicable_services || '[]';
      return invoice.services.some((s) => applicableServices.includes(s.service_id));
    });

    if (matchingVoucher) {
      return {
        promoName: matchingVoucher.ctkm_name,
        discountValue: parseFloat(matchingVoucher.value) || 0,
        discountType: 'fixed',
      };
    }

    return {
      promoName: null,
      discountValue: 0,
      discountType: 'fixed',
    };
  }

  // --- Invoice Calculations ---

  /**
   * 📊 DISPLAY Invoice Totals - Chỉ hiển thị data có sẵn, KHÔNG tính toán lại
   * Dùng khi switch giữa các invoices để render nhanh
   */
  function displayInvoiceTotals() {
    if (!elements.selectedServices || !elements.subtotalAmount || !elements.totalAmount) return;
    const invoice = invoices[currentInvoiceIndex];
    if (!invoice) return;

    // 📊 Hiển thị data có sẵn từ invoice object
    elements.subtotalAmount.textContent = formatCurrency(invoice.subtotal || 0);
    elements.totalAmount.textContent = formatCurrency(invoice.total || 0);
    elements.discountType.value = invoice.discountType || 'fixed';
    elements.discountAmount.value = formatNumberInput(String(invoice.discount || 0));
    elements.tipsAmount.value = formatNumberInput(String(invoice.tips || 0));
    // ✅ KHÔNG set promoListSelect.value ở đây - để loadPromoSettings() xử lý
  }

  /**
   * 🧮 CALCULATE Invoice Totals - Tính toán LẠI và cập nhật DB
   * Chỉ gọi khi user thay đổi: discount, tips, promo, add/remove services
   */
  async function calculateInvoiceTotals() {
    if (!elements.selectedServices || !elements.subtotalAmount || !elements.totalAmount) return;
    const invoice = invoices[currentInvoiceIndex];
    const servicesData = getServicesFromLocalStorage() || [];
    const productsData = getProductsFromLocalStorage() || [];

    // ✅ Load CTKM data (không render UI vì invoice.promoName chưa được update)
    // Chỉ cần ensure ctkmList/vouchers có data
    if (ctkmList.length === 0 && vouchers.length === 0) {
      await loadPromoSettings(invoice);
    }

    // ✅ Kiểm tra xem có CTKM thành viên hợp lệ không (để quyết định có dùng discounted_price hay không)
    const customer = invoice?.customer;
    const isMember = customer?.membership === 'Thành Viên';
    const hasNewCode = customer?.promoCode && customer.promoCode !== 'Không có';
    const hasValidStatus = customer?.promoStatus === 'CÓ HIỆU LỰC';
    const hasMemberCTKM = isMember && hasNewCode && hasValidStatus;

    // ✅ FIX: Tính subtotal LUÔN dùng GIÁ GỐC (service_price)
    // Discount từ discounted_price sẽ được tính riêng trong applyPromoLogic()
    // Ví dụ: Combo HS-SV giá gốc 100k, giá ưu đãi 90k
    //   → Subtotal = 100k (giá gốc)
    //   → Discount = 10k (được tính từ applyPromoLogic)
    //   → Total = 100k - 10k = 90k
    invoice.subtotal = invoice.services.reduce((sum, service) => {
      let price = 0;
      let quantity = service.quantity || 1;

      if (service.type === 'product') {
        const productData = productsData.find((p) => p.id === service.service_id);
        price = parseFloat(productData?.price) || service.price / quantity;
      } else {
        const serviceData = servicesData.find((s) => s.service_name === service.service_name);
        // ✅ LUÔN dùng giá GỐC (service_price) cho subtotal
        // Giảm giá sẽ được tính riêng ở discount field
        price = parseFloat(serviceData?.service_price) || service.price / quantity;
      }

      service.price = price * quantity;
      return sum + service.price;
    }, 0);

    let discountValue = 0;
    let discountType = invoice.discountType || 'fixed';

    // Nếu người dùng chọn CTKM thủ công, ưu tiên giữ promoName
    if (invoice.isManualPromo && invoice.promoName) {
      const ctkm = [...ctkmList, ...vouchers].find((c) => c.ctkm_name === invoice.promoName);
      if (ctkm) {
        discountValue = parseFloat(ctkm.value) || 0;
        discountType = 'fixed';
      } else {
        // Nếu CTKM không hợp lệ, reset về trạng thái tự động
        invoice.promoName = null;
        invoice.isManualPromo = false;
      }
    }

    // Nếu không có CTKM thủ công, áp dụng logic tự động
    if (!invoice.isManualPromo) {
      const {
        promoName,
        discountValue: calcDiscount,
        discountType: calcType,
      } = applyPromoLogic(invoice, servicesData, ctkmList, vouchers);

      if (promoName) {
        // Có CTKM tự động → CTKM thắng, tắt chế độ giảm giá thủ công
        invoice.promoName = promoName;
        discountValue = calcDiscount;
        discountType = calcType;
        invoice.isManualDiscount = false;
      } else {
        invoice.promoName = null;
        if (invoice.isManualDiscount) {
          // ✅ CTKM = "Không có" → cho phép giảm giá THỦ CÔNG theo % hoặc đ
          // (đọc từ ô input, KHÔNG để logic tự động ghi đè về 0)
          discountType = elements.discountType.value === 'percent' ? 'percent' : 'fixed';
          discountValue = parseFormattedNumber(elements.discountAmount.value) || 0;
          if (discountType === 'percent') {
            discountValue = Math.min(discountValue, 100);
          }
        } else {
          discountValue = calcDiscount;
          discountType = calcType;
        }
      }
    }

    // Cập nhật UI
    invoice.discountType = discountType;
    elements.discountType.value = discountType;
    elements.discountAmount.value = formatNumberInput(String(discountValue));

    // ✅ Render CTKM select và set value SAU KHI invoice.promoName đã được update
    await loadPromoSettings(invoice);

    // ✅ FIX: Khi có discounted_price, VẪN PHẢI TRỪ discount vào total
    // Vì subtotal đang dùng GIÁ GỐC (service_price = 100k)
    // Discount = 10k → Total = 100k - 10k = 90k ✅
    if (discountType === 'display_only') {
      invoice.discount = discountValue;
      invoice.discountApplied = discountValue; // ✅ TRỪ vào total thay vì = 0
    } else {
      // ✅ Trường hợp CTKM thành viên hoặc manual: Trừ vào total
      invoice.discount =
        invoice.discountType === 'percent'
          ? invoice.subtotal * (discountValue / 100)
          : discountValue;
      invoice.discount = Math.min(invoice.discount, invoice.subtotal);
      invoice.discountApplied = invoice.discount; // Số tiền thực tế trừ
    }

    // Tính tips
    let tipsValue = parseFormattedNumber(elements.tipsAmount.value) || 0;
    invoice.tips = tipsValue;
    elements.tipsAmount.value = formatNumberInput(String(tipsValue));

    // Tính tổng (dùng discountApplied thay vì discount)
    const actualDiscount =
      invoice.discountApplied !== undefined ? invoice.discountApplied : invoice.discount;
    invoice.total = invoice.subtotal - actualDiscount + invoice.tips;

    // Cập nhật giao diện
    elements.subtotalAmount.textContent = formatCurrency(invoice.subtotal);
    elements.totalAmount.textContent = formatCurrency(invoice.total);

    // 🔄 Mark as dirty và sync to DB if invoice is created
    invoice.isDirty = true;
    saveInvoicesToLocalStorage();

    // 💾 Auto-sync to DB if invoice already created
    if (invoice.invoice_id && !invoice.isFromDB) {
      setTimeout(() => saveInvoiceToDB(), 500); // Debounce 500ms
    }
  }

  // ==============================
  // 9. Customer Functions
  // ==============================

  // ==============================
  // 🎯 CUSTOMER DATA ARCHITECTURE (Single Source of Truth)
  // ==============================
  // KIẾN TRÚC DỮ LIỆU KHÁCH HÀNG - TỐI ƯU HÓA
  //
  // 📊 NGUỒN DỮ LIỆU DUY NHẤT: localStorage.customersList
  //   - Format: API raw (customer_id, customer_phone, customer_images, hairdresser_name, etc.)
  //   - Được update từ API khi: search customer, update customer, create customer
  //
  // 🔄 SYNC STRATEGY:
  //   1. API → localStorage (saveCustomersToLocalStorage)
  //   2. localStorage → Invoice (syncCustomerFromLocalStorage)
  //   3. Invoice → Display (displayCustomerInfo)
  //
  // ✨ HELPER FUNCTIONS:
  //   - mapCustomerFromLocalStorage(): Map API format → Invoice format
  //   - syncCustomerFromLocalStorage(): Sync từ localStorage vào invoice
  //
  // 🎨 FLOW KHI UPDATE CUSTOMER:
  //   1. Update API
  //   2. Update localStorage (giữ nguyên customer_images, hairdresser_name)
  //   3. Sync tất cả invoice có customer này (gọi syncCustomerFromLocalStorage)
  //   4. Update database (batch update qua Promise.all)
  //   5. Display customer (từ data vừa sync)
  //
  // 🎨 FLOW KHI RENDER INVOICE:
  //   1. renderCurrentInvoice() → updateCustomerInfo()
  //   2. syncCustomerFromLocalStorage() → lấy data mới nhất từ localStorage
  //   3. displayCustomerInfo() → hiển thị (bao gồm photos)
  //
  // ✅ LỢI ÍCH:
  //   - Không cần gọi API nhiều lần
  //   - Data luôn đồng bộ giữa invoice và localStorage
  //   - Photos/hairdressers tự động persist
  //   - Code đơn giản, dễ maintain

  // ==============================
  // 8. CUSTOMER MANAGEMENT
  // ==============================

  // --- Customer Data Mapping & Sync ---

  /**
   * Fetch customer data từ API và lưu vào localStorage
   * Dùng khi thiết bị khác xem hóa đơn nhưng chưa có data trong localStorage
   * @param {string} phone - Số điện thoại khách hàng (có hoặc không có số 0 đầu)
   * @returns {Object|null} Customer data đã được map
   */
  async function fetchCustomerByPhone(phone) {
    if (!phone) return null;

    // Chuẩn hóa phone (bỏ số 0 đầu)
    const phoneWithoutZero = String(phone).replace(/^0+/, '');

    try {
      const response = await fetchAPI(`customers?phone=${phoneWithoutZero}`);

      if (response?.success && Array.isArray(response.data) && response.data.length > 0) {
        // Lưu vào localStorage
        saveCustomersToLocalStorage(response.data);

        // Tìm customer khớp với phone
        const customerRaw = response.data.find((c) => {
          const customerPhone = String(c.customer_phone).replace(/^0+/, '');
          return customerPhone === phoneWithoutZero;
        });

        if (customerRaw) {
          return mapCustomerFromLocalStorage(customerRaw);
        }
      }
    } catch (error) {
      console.error('fetchCustomerByPhone error:', error);
    }

    return null;
  }

  /**
   * Kiểm tra customer có đủ data hay không
   * @param {Object} customer - Customer object
   * @returns {boolean} true nếu thiếu data quan trọng
   */
  function isCustomerDataIncomplete(customer) {
    if (!customer) return true;

    // Thiếu data nếu:
    // - Không có lastVisit hoặc lastVisit là "Chưa có"
    // - Không có hairdressers
    // - Không có dob hoặc dob là "Không rõ"
    // VÀ có phone để fetch
    const hasPhone = customer.phone && customer.phone !== '0';
    const missingLastVisit = !customer.lastVisit || customer.lastVisit === 'Chưa có';
    const missingHairdressers = !customer.hairdressers || customer.hairdressers.length === 0;
    const missingDob = !customer.dob || customer.dob === 'Không rõ';

    // Nếu thiếu nhiều thông tin quan trọng, cần fetch
    return hasPhone && missingLastVisit && missingHairdressers && missingDob;
  }

  /**
   * Helper: Map customer từ localStorage (API raw format) sang invoice format
   * Data được lấy trực tiếp từ localStorage, không cần fallback
   * @param {Object} customerRaw - Customer từ localStorage (customer_id, customer_phone, customer_images, etc.)
   * @param {Object} extraData - Dữ liệu bổ sung từ invoice hiện tại (notImage, lastVisit, etc.)
   * @returns {Object} Customer theo format invoice
   */
  function mapCustomerFromLocalStorage(customerRaw, extraData = {}) {
    if (!customerRaw) return null;

    // Parse photos từ customer_images - data từ API/localStorage
    let photos = [];
    if (Array.isArray(customerRaw.customer_images)) {
      photos = customerRaw.customer_images.filter((url) => url && !url.includes('lego'));
    } else if (typeof customerRaw.customer_images === 'string' && customerRaw.customer_images) {
      // Thử parse JSON trước, nếu không được thì split by comma
      try {
        const parsed = JSON.parse(customerRaw.customer_images);
        photos = Array.isArray(parsed) ? parsed.filter((url) => url && !url.includes('lego')) : [];
      } catch {
        photos = customerRaw.customer_images
          .split(',')
          .map((url) => url.trim())
          .filter((url) => url && !url.includes('lego'));
      }
    }

    // Parse hairdressers từ hairdresser_name
    let hairdressers = [];
    if (customerRaw.hairdresser_name) {
      const names = Array.isArray(customerRaw.hairdresser_name)
        ? customerRaw.hairdresser_name
        : customerRaw.hairdresser_name.split(',').map((n) => n.trim());
      hairdressers = [...new Set(names.filter((n) => n))];
    }

    return {
      id: customerRaw.customer_id,
      phone: `0${customerRaw.customer_phone}`,
      name: customerRaw.customer_name || 'Khách không tên',
      dob: customerRaw.customer_birthday || 'Không rõ',
      membership: customerRaw.membership_level === 'Thành Viên' ? 'Thành Viên' : 'Khách thường',
      lastVisit: customerRaw.new_checkin || extraData.lastVisit || 'Chưa có',
      photo: customerRaw.avatar || photos[0] || 'https://randomuser.me/api/portraits/lego/1.jpg',
      promoCode: customerRaw.new_code || 'Không có',
      promoStatus: customerRaw.status_code || extraData.promoStatus || '',
      photos: photos.slice(0, 3), // Giới hạn 3 ảnh
      invoices: customerRaw.invoices || [],
      hairdressers,
      notImage: extraData.notImage || [],
      new_customer: customerRaw.new_customer,
    };
  }

  /**
   * Helper: Sync customer từ localStorage vào invoice
   * Luôn lấy dữ liệu mới nhất từ localStorage, giữ lại notImage và MERGE photos từ invoice
   * @param {number|string} invoiceIndex - Index của invoice cần sync
   * @param {number|string} customerId - ID khách hàng cần sync
   */
  function syncCustomerFromLocalStorage(invoiceIndex, customerId) {
    const customers = getCustomersFromLocalStorage() || [];
    const customerRaw = customers.find((c) => c.customer_id === customerId);

    if (!customerRaw) {
      return null;
    }

    const invoice = invoices[invoiceIndex];
    const mappedCustomer = mapCustomerFromLocalStorage(customerRaw, {
      notImage: invoice?.customer?.notImage || [],
      lastVisit: invoice?.customer?.lastVisit,
      promoStatus: invoice?.customer?.promoStatus,
    });

    if (mappedCustomer) {
      // ✅ SINGLE SOURCE: Chỉ dùng photos từ mappedCustomer (đã có từ localStorage)
      invoices[invoiceIndex].customer = mappedCustomer;
      saveInvoicesToLocalStorage();
    }

    return mappedCustomer;
  }

  // --- Customer Search & Lookup ---

  async function searchCustomer(showMessage = true) {
    if (!elements.customerPhone || !elements.customerInfo) return;

    let input = elements.customerPhone.value.trim();

    // 🔧 FIX: Lấy searchBtn và originalHTML TRƯỚC khi validate
    const searchBtn = elements.searchCustomerBtn;
    const originalHTML = searchBtn.innerHTML;

    if (!input) {
      if (showMessage) {
        await showInfo('Vui lòng nhập số điện thoại hoặc mã booking');
      }
      return;
    }

    // Thêm loading state SAU khi đã validate input
    searchBtn.disabled = true;
    searchBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> ...';

    let phone = input;
    let bookingServices = [];
    let booking_id = null;
    let bookingPromoStatus = '';

    // === Check nếu là mã booking ===
    if (input.toUpperCase().startsWith('BK')) {
      const booking = await fetchBookingById(input);
      if (booking) {
        phone = booking.customer_phone;
        bookingServices = booking.services || [];
        booking_id = input;
        bookingPromoStatus = booking.promo_status || '';
      } else {
        if (showMessage) {
          await showInfo('Không tìm thấy booking với mã này');
        }
        return;
      }
    }

    // === Chuẩn hóa số điện thoại ===
    if (phone.startsWith('0')) {
      phone = phone.substring(1);
    }

    try {
      const response = await fetchAPI(`customers?phone=${phone}`);

      if (response?.success && Array.isArray(response.data)) {
        const customers = response.data;
        saveCustomersToLocalStorage(customers);

        // So sánh phone với cả 2 format (có và không có số 0)
        const phoneWithoutZero = phone.replace(/^0+/, '');
        const customerRaw = customers.find((c) => {
          const customerPhone = c.customer_phone.replace(/^0+/, '');
          return customerPhone === phoneWithoutZero;
        });

        if (customerRaw) {
          // Sử dụng helper function để map customer
          const mappedCustomer = mapCustomerFromLocalStorage(customerRaw, {
            lastVisit: customerRaw.new_checkin || new Date().toISOString().split('T')[0],
            promoStatus: bookingPromoStatus || customerRaw.status_code || '',
            notImage: invoices[currentInvoiceIndex]?.customer?.notImage || [],
          });

          displayCustomerInfo(mappedCustomer);
          assignCustomerToInvoice(mappedCustomer);

          if (bookingServices.length > 0) {
            const invoice = invoices[currentInvoiceIndex];
            const servicesData = getServicesFromLocalStorage() || [];

            // Thêm dịch vụ từ booking vào hóa đơn
            bookingServices.forEach((service) => {
              const exists = invoice.services.some((s) => s.service_name === service.service_name);
              if (!exists) {
                const serviceData = servicesData.find(
                  (s) => s.service_name === service.service_name
                );
                // ✅ FIX: LUÔN dùng giá GỐC (service_price) khi thêm từ booking
                // Giảm giá sẽ được tính tự động trong calculateInvoiceTotals()
                const price = parseFloat(serviceData?.service_price || service.service_price) || 0;
                invoice.services.push({
                  service_id: serviceData?.service_id,
                  service_name: service.service_name || 'Dịch vụ không xác định',
                  price: price * (service.quantity || 1),
                  staff_id: service.staff_id,
                  staff_name: service.hairdresser_name || 'Thợ không xác định',
                  type: 'service',
                  quantity: service.quantity || 1,
                });
              }
            });

            invoice.booking_id = booking_id;
            invoice.isManualPromo = false; // Đảm bảo áp dụng logic giảm giá tự động

            // Áp dụng logic giảm giá
            const { promoName, discountValue, discountType } = applyPromoLogic(
              invoice,
              servicesData,
              ctkmList,
              vouchers
            );
            invoice.promoName = promoName;
            invoice.discount = discountValue;
            invoice.discountType = discountType;

            // Cập nhật giao diện giảm giá
            if (elements.promoListSelect) {
              elements.promoListSelect.value = promoName || '';
            }
            if (elements.discountAmount) {
              elements.discountAmount.value = formatNumberInput(String(discountValue));
            }

            // Lưu hóa đơn và cập nhật giao diện
            saveInvoicesToLocalStorage();
            await calculateInvoiceTotals();
            await renderCurrentInvoice();

            // Cập nhật giao diện dịch vụ đã chọn
            await loadServicesForGroup(invoice.services.map((s) => s.service_name));

            if (showMessage) {
              toastSuccess('Đã thêm dịch vụ từ booking và áp dụng giảm giá thành công');
            }
          } else {
            if (showMessage) {
              toastSuccess('Khách hàng đã được tìm thấy');
            }
          }
        } else {
          if (booking_id) {
            elements.customerPhone.value = `0${phone}`;
          }
          showNewCustomerForm();
          if (showMessage) {
            toastInfo('Không tìm thấy khách hàng, mời tạo mới');
          }
        }
      } else {
        if (booking_id) {
          elements.customerPhone.value = `0${phone}`;
        }
        showNewCustomerForm();
        if (showMessage) {
          toastInfo('Không có dữ liệu khách hàng');
        }
      }
    } catch (error) {
      if (booking_id) {
        elements.customerPhone.value = `0${phone}`;
      }
      showNewCustomerForm();
      if (showMessage) {
        // Kiểm tra xem có message lỗi chi tiết từ API hay không
        const errorMessage = error.message || error?.data?.message || 'Lỗi khi tìm khách hàng';
        toastError(errorMessage);
      }
    } finally {
      // Xóa loading state
      searchBtn.disabled = false;
      searchBtn.innerHTML = originalHTML;
    }
  }

  async function fetchBookingById(id_booking) {
    try {
      const response = await fetch(`${checkinData.restUrl}bookings/${id_booking}`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
          'X-WP-Nonce': checkinData.nonce,
        },
      });

      const result = await response.json();

      if (result.success) {
        return result.data;
      }

      await showWarning('Mã booking không tồn tại hoặc đã bị xóa.', 'Không tìm thấy lịch hẹn');
      return null;
    } catch (err) {
      await showError('Không thể kết nối đến máy chủ. Vui lòng thử lại sau.', 'Lỗi Server');
      return null;
    }
  }

  function displayCustomerInfo(customer) {
    if (
      !elements.customerInfo ||
      !elements.customerName ||
      !elements.customerDob ||
      !elements.customerLastVisit ||
      !elements.customerPhoto ||
      !elements.promoCode ||
      !elements.customerMembershipTag ||
      !elements.customerPhoto1 ||
      !elements.customerPhoto2 ||
      !elements.customerPhoto3 ||
      !elements.uploadImageBtn ||
      !elements.customerHairdresser
    ) {
      return;
    }

    // ✅ Kiểm tra nếu customer thiếu data, fetch từ API
    if (isCustomerDataIncomplete(customer) && customer.phone) {
      fetchCustomerByPhone(customer.phone).then((enrichedCustomer) => {
        if (enrichedCustomer) {
          // Merge data: giữ lại notImage từ customer gốc
          const mergedCustomer = {
            ...enrichedCustomer,
            notImage: customer.notImage || enrichedCustomer.notImage || [],
          };
          // Gọi lại displayCustomerInfo với data đầy đủ
          displayCustomerInfo(mergedCustomer);

          // Cập nhật invoice nếu đang ở tab hiện tại
          if (invoices[currentInvoiceIndex]?.customer?.phone === mergedCustomer.phone) {
            invoices[currentInvoiceIndex].customer = mergedCustomer;
            saveInvoicesToLocalStorage();
          }
        }
      });
      // Tiếp tục render với data hiện có (sẽ update sau khi fetch xong)
    }

    elements.customerInfo.classList.remove('hidden');
    if (elements.newCustomerForm) {
      elements.newCustomerForm.classList.add('hidden');
    }

    // Hiển thị tên với icon edit
    elements.customerName.innerHTML = `
      ${customer.name}
      <button class="edit-customer-btn ml-2 text-blue-500 hover:text-blue-700" title="Sửa thông tin khách hàng">
        <i class="fas fa-edit"></i>
      </button>
    `;

    // Thêm event listener cho nút edit
    const editBtn = elements.customerName.querySelector('.edit-customer-btn');
    if (editBtn) {
      editBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        showCustomerModal('update', customer);
      });
    }

    elements.customerDob.textContent = `Ngày sinh: ${customer.dob || 'Không rõ'}`;
    elements.customerLastVisit.textContent = `Lần cuối: ${customer.lastVisit || 'Chưa có'}`;
    // Hiển thị danh sách thợ cũ
    const hairdressers = Array.isArray(customer.hairdressers) ? customer.hairdressers : [];
    elements.customerHairdresser.textContent =
      hairdressers.length > 0 ? `Thợ cũ: ${hairdressers.join(', ')}` : 'Thợ cũ: Không có';
    // Hiển thị ghi chú không phải hình ảnh
    const notImageArray = Array.isArray(customer.notImage) ? customer.notImage : [];
    elements.customerNotImage.textContent =
      notImageArray.length > 0 ? `Lý do ko có hình: ${notImageArray.join(', ')}` : '';

    const defaultImage1 = 'https://randomuser.me/api/portraits/lego/1.jpg';
    const defaultImage2 = 'https://randomuser.me/api/portraits/lego/2.jpg';
    const defaultImage3 = 'https://randomuser.me/api/portraits/lego/3.jpg';

    // Lấy photos trực tiếp từ customer object (đã được map từ localStorage)
    // Filter out ảnh lego và randomuser.me, giữ lại blob URLs
    let photos = Array.isArray(customer.photos)
      ? customer.photos.filter(
          (url) => url && !url.includes('lego') && !url.includes('randomuser.me')
        )
      : [];

    // Lazy load: Chỉ load ảnh đầu tiên, các ảnh khác sẽ load khi scroll/click
    const photo1 = photos[0] || defaultImage1;
    const photo2 = photos[1] || defaultImage2;
    const photo3 = photos[2] || defaultImage3;

    // Set loading="lazy" để browser tự quản lý lazy load
    elements.customerPhoto.loading = 'lazy';
    elements.customerPhoto1.loading = 'lazy';
    elements.customerPhoto2.loading = 'lazy';
    elements.customerPhoto3.loading = 'lazy';

    // Set ảnh trực tiếp (không cần clear trước)
    elements.customerPhoto.src = photo1;
    elements.customerPhoto1.src = photo1;
    elements.customerPhoto2.src = photo2;
    elements.customerPhoto3.src = photo3;

    const today = new Date();
    const dobDate = customer.dob && customer.dob !== 'Không rõ' ? new Date(customer.dob) : null;
    const lastVisitDate = customer.lastVisit ? new Date(customer.lastVisit) : null;
    const isTodayRegistration = dobDate ? dobDate.toDateString() === today.toDateString() : false;
    // Đồng bộ logic với PHP: so sánh <= 30 để tính hiệu lực
    const daysSinceLastVisit = lastVisitDate
      ? Math.floor((today - lastVisitDate) / (1000 * 60 * 60 * 24))
      : 999;
    const isNotMember =
      customer.membership === 'Khách thường' || customer.name === 'Khách Vãng Lai';
    const isWeekend = today.getDay() === 6 || today.getDay() === 0; // 6: Saturday, 0: Sunday

    // Tính toán promoStatus theo logic
    let calculatedStatus = '';
    if (isTodayRegistration || isNotMember || isWeekend) {
      calculatedStatus = 'Không áp dụng';
    } else if (daysSinceLastVisit <= 30) {
      calculatedStatus = 'Có hiệu lực';
    } else {
      calculatedStatus = 'Hết hạn sử dụng';
    }

    // ✅ So sánh với DB và đồng bộ nếu khác
    const dbStatus = customer.promoStatus; // Giá trị từ DB (status_code)
    const statusMapping = {
      'Không áp dụng': 'KHÔNG ÁP DỤNG',
      'Có hiệu lực': 'CÓ HIỆU LỰC',
      'Hết hạn sử dụng': 'HẾT HẠN SỬ DỤNG',
    };
    const calculatedStatusDB = statusMapping[calculatedStatus];

    if (dbStatus && dbStatus !== calculatedStatusDB && customer.id) {
      // Đồng bộ về DB (async, không block UI)
      syncPromoStatusToDB(customer.id, calculatedStatusDB).catch((err) => {
        console.error('Failed to sync promoStatus to DB:', err);
      });
      // Cập nhật customer object
      customer.promoStatus = calculatedStatusDB;
    }

    promoStatus = calculatedStatus;

    if (isNotMember) {
      elements.promoCode.textContent = `Không có (${promoStatus})`;
    } else {
      const promoCodeDisplay =
        customer.promoCode && customer.promoCode !== 'Không có' ? customer.promoCode : 'Không có';
      elements.promoCode.textContent = `${promoCodeDisplay} (${promoStatus})`;
    }

    // Đặt giá trị mặc định là "Khách thường" nếu không có membership
    const membershipLevel = customer.membership || 'Khách thường';
    elements.customerMembershipTag.textContent = membershipLevel;

    if (membershipLevel === 'VIP') {
      elements.customerMembershipTag.classList.add('vip-tag');
      elements.customerMembershipTag.classList.remove('normal-tag', 'member-tag');
    } else if (membershipLevel === 'Thành Viên') {
      elements.customerMembershipTag.classList.add('member-tag');
      elements.customerMembershipTag.classList.remove('vip-tag', 'normal-tag');
    } else {
      elements.customerMembershipTag.classList.add('normal-tag');
      elements.customerMembershipTag.classList.remove('vip-tag', 'member-tag');
    }

    // Remove old event listeners để tránh gắn nhiều lần gây lag
    [
      elements.customerPhoto,
      elements.customerPhoto1,
      elements.customerPhoto2,
      elements.customerPhoto3,
    ].forEach((img, index) => {
      img.classList.add('cursor-pointer');

      // Clone node để remove tất cả event listeners cũ
      const newImg = img.cloneNode(true);
      img.parentNode.replaceChild(newImg, img);

      // Update reference
      if (index === 0) elements.customerPhoto = newImg;
      if (index === 1) elements.customerPhoto1 = newImg;
      if (index === 2) elements.customerPhoto2 = newImg;
      if (index === 3) elements.customerPhoto3 = newImg;

      // Add new listener
      newImg.addEventListener('click', () => {
        // Đảm bảo photos là array trước khi spread
        const photoArray = Array.isArray(customer.photos) ? customer.photos : [];
        const images = photoArray.filter((url) => url && !url.includes('lego'));

        // ✅ LIMIT TO 3 IMAGES (User request)
        const limitedImages = images.slice(0, 3);

        if (limitedImages.length > 0) {
          // Luôn bắt đầu từ ảnh đầu tiên (index 0) khi mở modal
          openImagePopup(limitedImages, 0);
        }
      });
    });

    elements.uploadImageBtn.disabled = !customer.id;
    elements.uploadImageBtn.classList.toggle('bg-gray-400', !customer.id);
    elements.uploadImageBtn.classList.toggle('bg-blue-500', customer.id);
  }

  // --- Customer Creation ---

  async function createCustomer(customerData) {
    // Chuẩn hóa tên khách hàng thành chữ IN HOA
    const normalizedName = customerData.name.trim().toUpperCase();

    // Validate đầu vào
    const phoneRegex = /^[0-9]{9,10}$/;
    if (!phoneRegex.test(customerData.phone)) {
      throw new Error('Số điện thoại không hợp lệ. Vui lòng nhập 9-10 chữ số.');
    }
    if (!normalizedName || normalizedName.length < 2) {
      throw new Error('Tên khách hàng phải có ít nhất 2 ký tự.');
    }
    if (customerData.birthday) {
      const dob = new Date(customerData.birthday);
      const today = new Date();
      if (isNaN(dob.getTime()) || dob > today) {
        throw new Error('Ngày sinh không hợp lệ hoặc trong tương lai.');
      }
    }

    // Gửi yêu cầu API
    const response = await fetchAPI('customers', {
      method: 'POST',
      body: JSON.stringify({
        customer_phone: customerData.phone,
        customer_name: normalizedName,
        customer_birthday: customerData.birthday || '',
        customer_images: '',
        new_code: null,
        new_customer: 'true',
      }),
    });

    // Chuẩn hóa đối tượng khách hàng mới
    const newCustomer = {
      id: response.data.customer_id,
      phone: `0${customerData.phone}`,
      name: normalizedName,
      dob: customerData.birthday || 'Không rõ',
      membership: 'Khách thường',
      lastVisit: new Date().toISOString().split('T')[0],
      new_customer: 'true',
      photo: 'https://randomuser.me/api/portraits/lego/1.jpg',
      promoCode: 'Không có',
      photos: [],
      invoices: [],
      hairdressers: [],
    };

    // Lưu vào localStorage
    const customers = getCustomersFromLocalStorage() || [];
    customers.push(newCustomer);
    saveCustomersToLocalStorage(customers);

    // Gán khách hàng cho hóa đơn hiện tại
    invoices[currentInvoiceIndex].customer = newCustomer;
    saveInvoicesToLocalStorage();

    return newCustomer;
  }

  async function saveNewCustomer() {
    if (!elements.newCustomerForm) return;

    // Lấy phone từ input trong form (ưu tiên) hoặc từ input tìm kiếm
    const phoneInput = document.getElementById('newCustomerPhone');
    let phone = phoneInput ? phoneInput.value.trim() : elements.customerPhone?.value.trim() || '';
    const name = document.getElementById('newCustomerName').value.trim();
    const dob = document.getElementById('newCustomerDob').value;

    if (!name || !phone) {
      await showError('Vui lòng nhập tên và số điện thoại', 'Thông báo');
      return;
    }

    // Chuẩn hóa số điện thoại
    if (phone.startsWith('0')) {
      phone = phone.substring(1);
    }

    const customerData = {
      phone,
      name,
      birthday: dob || '',
    };

    try {
      // createCustomer() đã return object customer hoàn chỉnh và đã lưu vào localStorage + invoice
      const newCustomer = await createCustomer(customerData);

      displayCustomerInfo(newCustomer);
      elements.newCustomerForm.classList.add('hidden');

      toastSuccess('Tạo khách hàng thành công!');
    } catch (error) {
      toastError(error.message || 'Đã xảy ra lỗi khi tạo khách hàng.');
    }
  }

  async function showNewCustomerForm() {
    await showInfo(
      'Không tìm thấy khách hàng với số điện thoại này. Vui lòng tạo khách hàng mới.',
      'Khách hàng mới'
    );

    // Lấy SĐT từ input tìm kiếm để auto-fill
    const phoneValue = elements.customerPhone?.value || '';
    showCustomerModal('create', null, phoneValue);
  }

  function showCustomerModal(mode = 'create', customer = null, prefilledPhone = '') {
    // mode: 'create' hoặc 'update'
    const isUpdate = mode === 'update' && customer;
    const title = isUpdate ? 'Cập nhật khách hàng' : 'Thêm mới khách hàng';
    const saveButtonText = isUpdate ? 'Cập nhật' : 'Tạo mới';

    // Debug: log customer object để kiểm tra
    if (isUpdate) {
    }

    const modal = document.createElement('div');
    modal.className = 'customer-modal-overlay';
    modal.id = 'customerModal';

    // Lưu customer ID vào data attribute nếu đang update
    if (isUpdate && customer) {
      modal.dataset.customerId = customer.id || customer.customer_id || '';
    }
    modal.innerHTML = `
      <div class="customer-modal-container">
        <div class="customer-modal-header">
          <h3 class="customer-modal-title">${title}</h3>
          <button class="customer-modal-close" aria-label="Đóng">
            <i class="fas fa-times"></i>
          </button>
        </div>

        <div class="customer-modal-body">
          <div class="customer-form-group">
            <label class="customer-form-label">
              <i class="fas fa-user"></i>
              Tên khách hàng
            </label>
            <input type="text" id="customerModalName" class="customer-form-input"
              placeholder="Nhập tên khách hàng" value="${isUpdate ? customer.name : ''}" required>
          </div>

          <div class="customer-form-group">
            <label class="customer-form-label">
              <i class="fas fa-phone"></i>
              Số điện thoại
            </label>
            <input type="tel" id="customerModalPhone" class="customer-form-input"
              placeholder="0xxxxxxxxx" value="${
                isUpdate ? customer.phone : prefilledPhone
              }" required>
          </div>

          <div class="customer-form-group">
            <label class="customer-form-label">
              <i class="fas fa-birthday-cake"></i>
              Ngày sinh
            </label>
            <input type="date" id="customerModalDob" class="customer-form-input"
              value="${isUpdate && customer.dob !== 'Không rõ' ? customer.dob : ''}">
          </div>
        </div>

        <div class="customer-modal-footer">
          <button class="customer-btn customer-btn-cancel">
            <i class="fas fa-times"></i>
            Hủy
          </button>
          <button class="customer-btn customer-btn-save">
            <i class="fas fa-check"></i>
            ${saveButtonText}
          </button>
        </div>
      </div>
    `;

    document.body.appendChild(modal);

    // Trigger animation
    setTimeout(() => modal.classList.add('show'), 10);

    const closeModal = () => {
      modal.classList.remove('show');
      setTimeout(() => modal.remove(), 300);
    };

    // Event listeners
    modal.querySelector('.customer-modal-close').addEventListener('click', closeModal);
    modal.querySelector('.customer-btn-cancel').addEventListener('click', closeModal);
    modal.addEventListener('click', (e) => {
      if (e.target === modal) closeModal();
    });

    modal.querySelector('.customer-btn-save').addEventListener('click', async () => {
      const name = document.getElementById('customerModalName').value.trim();
      const phone = document.getElementById('customerModalPhone').value.trim();
      const dob = document.getElementById('customerModalDob').value;

      if (!name || !phone) {
        toastError('Vui lòng nhập đầy đủ tên và số điện thoại');
        return;
      }

      const saveBtn = modal.querySelector('.customer-btn-save');
      setButtonLoading(saveBtn, 'Đang xử lý...');

      try {
        if (isUpdate) {
          // Lấy customer ID từ data attribute hoặc từ customer object
          const customerId = modal.dataset.customerId || customer?.id || customer?.customer_id;
          if (!customerId) {
            throw new Error('Không tìm thấy ID khách hàng để cập nhật');
          }

          await updateCustomer(customerId, { name, phone, dob });
          toastSuccess('Cập nhật thông tin khách hàng thành công!');
        } else {
          await createAndSaveCustomer(name, phone, dob);
          toastSuccess('Tạo khách hàng mới thành công!');
        }
        closeModal();
      } catch (error) {
        toastError(error.message || 'Đã xảy ra lỗi.');
      } finally {
        // ✅ Luôn reset button trong finally
        resetButtonLoading(saveBtn);
      }
    });
  }

  async function createAndSaveCustomer(name, phone, dob) {
    // Chuẩn hóa tên khách hàng thành chữ IN HOA
    const normalizedName = name.trim().toUpperCase();

    // Chuẩn hóa số điện thoại
    let normalizedPhone = phone;
    if (normalizedPhone.startsWith('0')) {
      normalizedPhone = normalizedPhone.substring(1);
    }

    // Validate
    const phoneRegex = /^[0-9]{9,10}$/;
    if (!phoneRegex.test(normalizedPhone)) {
      throw new Error('Số điện thoại không hợp lệ. Vui lòng nhập 9-10 chữ số.');
    }
    if (!normalizedName || normalizedName.length < 2) {
      throw new Error('Tên khách hàng phải có ít nhất 2 ký tự.');
    }

    // Gọi API tạo khách hàng
    const newCustomerData = await createCustomer({
      phone: normalizedPhone,
      name: normalizedName,
      birthday: dob || '',
    });

    // Lưu vào localStorage
    const customers = getCustomersFromLocalStorage() || [];
    customers.push({
      id: newCustomerData.id,
      name: newCustomerData.name,
      phone: `0${normalizedPhone}`,
      dob: dob || 'Không rõ',
      lastVisit: new Date().toISOString().split('T')[0],
      hairdressers: [],
      notImage: [],
      photos: [],
    });
    saveCustomersToLocalStorage(customers);

    // ✅ NULL CHECK: Ensure invoice exists before assigning customer
    if (!invoices || invoices.length === 0) {
      invoices = [createDefaultInvoice()];
      currentInvoiceIndex = 0;
    }

    // Gán khách hàng vào hóa đơn hiện tại
    invoices[currentInvoiceIndex].customer = {
      id: newCustomerData.id,
      name: newCustomerData.name,
      phone: `0${normalizedPhone}`,
      dob: dob || 'Không rõ',
      hairdressers: [],
      notImage: [],
      photos: [],
      lastVisit: new Date().toISOString().split('T')[0],
    };
    saveInvoicesToLocalStorage();

    // Hiển thị thông tin khách hàng
    displayCustomerInfo(invoices[currentInvoiceIndex].customer);
  }

  async function updateCustomer(customerId, updates) {
    // Validate customerId trước - chấp nhận cả số và chuỗi (VG0004, 123, etc.)
    if (!customerId || (typeof customerId !== 'string' && typeof customerId !== 'number')) {
      throw new Error('ID khách hàng không hợp lệ');
    }
    // Lấy thông tin khách hàng cũ để so sánh
    const customers = getCustomersFromLocalStorage() || [];
    // customers trong localStorage có format API raw: customer_id, customer_phone, customer_name
    const oldCustomer = customers.find((c) => c.customer_id === customerId);
    const oldPhone = oldCustomer?.customer_phone ? `0${oldCustomer.customer_phone}` : null;
    const oldName = oldCustomer?.customer_name || null;
    // Chuẩn hóa tên khách hàng thành chữ IN HOA
    const normalizedName = updates.name.trim().toUpperCase();

    // Chuẩn hóa số điện thoại
    let phone = updates.phone;
    if (phone.startsWith('0')) {
      phone = phone.substring(1);
    }

    // Validate
    const phoneRegex = /^[0-9]{9,10}$/;
    if (!phoneRegex.test(phone)) {
      throw new Error('Số điện thoại không hợp lệ. Vui lòng nhập 9-10 chữ số.');
    }
    if (!normalizedName || normalizedName.length < 2) {
      throw new Error('Tên khách hàng phải có ít nhất 2 ký tự.');
    }
    // Gọi API update
    const response = await fetchAPI(`customers/${customerId}`, {
      method: 'PUT',
      body: JSON.stringify({
        customer_name: normalizedName,
        customer_phone: phone,
        customer_birthday: updates.dob || '',
      }),
    });

    if (!response.success) {
      throw new Error(response.message || 'Cập nhật thất bại');
    }

    // Cập nhật trong localStorage customers - GIỮ LẠI tất cả field cũ (format API raw)
    const customerIndex = customers.findIndex((c) => c.customer_id === customerId);
    if (customerIndex !== -1) {
      customers[customerIndex] = {
        ...customers[customerIndex], // Giữ lại customer_images, hairdresser_name, membership_level, etc.
        customer_name: normalizedName,
        customer_phone: phone, // Không có số 0
        customer_birthday: updates.dob || customers[customerIndex].customer_birthday || '',
      };
      saveCustomersToLocalStorage(customers);
    }

    // Cập nhật TẤT CẢ invoice có thông tin khách hàng này - ĐƠN GIẢN HƠN
    let updatedInvoiceCount = 0;
    const newPhoneWithZero = `0${phone}`;
    const invoicesToUpdateInDB = []; // Danh sách invoice cần update lên database
    invoices.forEach((invoice, index) => {
      if (invoice.customer) {
        // Kiểm tra theo ID hoặc số điện thoại cũ hoặc tên cũ
        const matchById = invoice.customer.id === customerId;
        const matchByPhone = oldPhone && invoice.customer.phone === oldPhone;
        const matchByName = oldName && invoice.customer.name === oldName;

        if (matchById || matchByPhone || matchByName) {
          // Sync từ localStorage - tự động lấy đầy đủ data (photos, hairdressers, etc.)
          syncCustomerFromLocalStorage(index, customerId);
          updatedInvoiceCount++;

          // Thêm vào danh sách cần update lên DB (nếu có invoice_id)
          if (invoice.invoice_id) {
            invoicesToUpdateInDB.push({
              invoice_id: invoice.invoice_id,
              customer_name: normalizedName,
              customer_phone: newPhoneWithZero,
            });
          }
        }
      }
    });

    if (updatedInvoiceCount > 0) {
      saveInvoicesToLocalStorage();

      // ✅ Refresh data theo period hiện tại
      clearInvoicesDataCache();
      try {
        await reloadCurrentPeriodInvoices();
      } catch (e) {
        console.error('Failed to reload after customer update:', e);
      }

      // Re-render invoice tabs để hiển thị tên mới realtime
      renderInvoiceTabs();
      // Update customer info display nếu invoice hiện tại đã được update
      const currentInvoice = invoices[currentInvoiceIndex];
      if (currentInvoice && currentInvoice.customer) {
        displayCustomerInfo(currentInvoice.customer);
      }
      // Refresh invoice list nếu đang ở section invoices
      if (currentSection === 'invoices') {
        renderInvoiceList();
      }

      // Cập nhật lên database
      if (invoicesToUpdateInDB.length > 0) {
        // Update từng invoice lên database
        const updatePromises = invoicesToUpdateInDB.map(async (invoiceData) => {
          try {
            await fetchAPI(`invoices/${invoiceData.invoice_id}`, {
              method: 'PUT',
              body: JSON.stringify({
                customer_id: customerId,
                customer_name: invoiceData.customer_name,
                customer_phone: invoiceData.customer_phone,
              }),
            });
            return { success: true, invoice_id: invoiceData.invoice_id };
          } catch (error) {
            return { success: false, invoice_id: invoiceData.invoice_id, error };
          }
        });

        // Chờ tất cả update hoàn thành
        const results = await Promise.all(updatePromises);
        const successCount = results.filter((r) => r.success).length;
        const failCount = results.filter((r) => !r.success).length;
        if (failCount > 0) {
        }
      }
    }

    // Refresh customer info nếu đang hiển thị khách hàng này
    if (invoices[currentInvoiceIndex]?.customer?.id === customerId) {
      if (elements.customerPhone) {
        elements.customerPhone.value = newPhoneWithZero;
      }

      // Sync customer từ localStorage - đơn giản, nhẹ nhàng
      const refreshedCustomer = syncCustomerFromLocalStorage(currentInvoiceIndex, customerId);
      if (refreshedCustomer) {
        displayCustomerInfo(refreshedCustomer);
      }
    }

    // Hiển thị thông báo về booking updates nếu có
    if (response.data?.booking_updated) {
      const bookingCount = response.data.booking_updated;
      const bookingFields = response.data.booking_fields?.join(', ') || '';

      // Xóa cache booking để force reload lần sau
      localStorage.removeItem('bookingsList');
      // Reload booking list nếu đang ở trang bookings
      if (currentSection === 'bookings') {
        await renderBookingList();
      }
    }

    return response;
  }

  /**
   * 🔄 Đồng bộ promoStatus (status_code) về database
   * @param {string} customerId - ID khách hàng
   * @param {string} newStatus - Status mới ('CÓ HIỆU LỰC', 'KHÔNG ÁP DỤNG', 'HẾT HẠN SỬ DỤNG')
   */
  async function syncPromoStatusToDB(customerId, newStatus) {
    if (!customerId || !newStatus) {
      console.warn('⚠️ syncPromoStatusToDB: Missing params', { customerId, newStatus });
      return;
    }

    try {
      const response = await fetchAPI(`customers/${customerId}`, {
        method: 'PUT',
        body: JSON.stringify({
          status_code: newStatus,
        }),
      });

      if (response.success) {
        // Cập nhật trong localStorage
        const customers = getCustomersFromLocalStorage() || [];
        const customerIndex = customers.findIndex((c) => c.customer_id === customerId);
        if (customerIndex !== -1) {
          customers[customerIndex].status_code = newStatus;
          saveCustomersToLocalStorage(customers);
        }
      }
    } catch (error) {
      console.error('❌ Failed to sync promoStatus:', error);
    }
  }

  function assignCustomerToInvoice(customer) {
    // ✅ NULL CHECK: Ensure invoice exists
    if (!invoices || invoices.length === 0) {
      invoices = [createDefaultInvoice()];
      currentInvoiceIndex = 0;
    }

    // Lưu toàn bộ customer object (bao gồm photos, hairdressers, etc.)
    invoices[currentInvoiceIndex].customer = { ...customer };
    invoices[currentInvoiceIndex].promoName = null;
    saveInvoicesToLocalStorage();
  }

  // ==============================
  // 9. SERVICE MANAGEMENT
  // ==============================
  // --- Service Groups Loading ---

  async function loadServiceGroups() {
    if (!elements.serviceGroups) return;

    // Luôn fetch từ API nếu branch filter thay đổi hoặc cache hết hạn
    let services = getServicesFromLocalStorage();

    // Nếu không có cache hoặc cache hết hạn, fetch từ API
    if (!services) {
      // CRITICAL: fetchAPI() tự động thêm branch_id parameter, không cần params.append('branch')
      services = await fetchAPI('services');

      // Kiểm tra response format
      if (!Array.isArray(services)) {
        services = services?.data || [];
      }

      // Lưu vào localStorage
      saveServicesToLocalStorage(services);
    }

    const rawGroups = [...new Set(services.map((service) => service.service_group))];
    const mappedGroups = rawGroups.map(
      (group) => serviceGroupMapping[group] || group.toLowerCase().replace(/\s/g, '-')
    );

    const displayOrder = ['main', 'plus', 'chemical', 'vip'];
    const sortedGroups = displayOrder.filter((group) => mappedGroups.includes(group));

    elements.serviceGroups.innerHTML = '';

    sortedGroups.forEach((mappedGroup) => {
      const displayName = serviceGroupDisplayNames[mappedGroup] || mappedGroup;

      const button = document.createElement('button');
      button.className = `service-group-btn service-group-btn-style ${
        mappedGroup === selectedServiceGroup
          ? 'service-group-btn-active'
          : 'service-group-btn-inactive'
      }`;
      button.dataset.group = mappedGroup;
      button.textContent = displayName;

      elements.serviceGroups.appendChild(button);
    });
  }

  async function loadServicesForGroup() {
    if (!elements.serviceList) return;

    // Luôn fetch từ API nếu branch filter thay đổi hoặc cache hết hạn
    let services = getServicesFromLocalStorage();
    if (!services) {
      // CRITICAL: fetchAPI() tự động thêm branch_id parameter
      services = await fetchAPI('services');

      // Kiểm tra response format
      if (!Array.isArray(services)) {
        services = services?.data || [];
      }

      // Lưu vào localStorage
      saveServicesToLocalStorage(services);
    }

    const filteredServices = services
      .filter(
        (service) =>
          serviceGroupMapping[service.service_group] === selectedServiceGroup ||
          service.service_group === selectedServiceGroup
      )
      .sort((a, b) => (a.sort_order || 0) - (b.sort_order || 0));

    elements.serviceList.innerHTML = '';

    if (!filteredServices || filteredServices.length === 0) {
      elements.serviceList.innerHTML =
        '<div class="service-list-empty">Không có dịch vụ nào trong nhóm này</div>';
      return;
    }

    // ✅ Helper: Generate HTML hiển thị giá (giá gốc gạch + giá giảm nếu có discounted_price)
    const renderServicePriceHTML = (service) => {
      const originalPrice = parseFloat(service.service_price);
      const discountedPrice = service.discounted_price ? parseFloat(service.discounted_price) : 0;

      // Nếu có giá giảm và giá giảm nhỏ hơn giá gốc
      if (discountedPrice > 0 && discountedPrice < originalPrice) {
        return `
          <div class="service-item-price-wrapper">
            <span class="service-item-original-price">${formatCurrency(originalPrice)}</span>
            <span class="service-item-discounted-price">${formatCurrency(discountedPrice)}</span>
          </div>
        `;
      }
      // Không có giá giảm - hiển thị giá bình thường
      return `<div class="service-item-price">${formatCurrency(originalPrice)}</div>`;
    };

    // ✅ NULL CHECK: Verify that current invoice exists and has services array
    if (!invoices || !invoices[currentInvoiceIndex] || !invoices[currentInvoiceIndex].services) {
      // Still display services without marking as added
      filteredServices.forEach((service) => {
        const serviceItem = document.createElement('div');
        serviceItem.className = `service-item service-item-style`;
        serviceItem.dataset.id = service.service_id;
        serviceItem.dataset.name = service.service_name;
        serviceItem.dataset.price = service.service_price;

        serviceItem.innerHTML = `
              <div class="service-item-name">${service.service_name}</div>
              ${renderServicePriceHTML(service)}
          `;

        serviceItem.addEventListener('click', () => {
          selectServiceForStaff(service.service_id, 1);
        });

        elements.serviceList.appendChild(serviceItem);
      });
      return;
    }

    const currentInvoiceServices = invoices[currentInvoiceIndex].services.map((s) => s.service_id);

    filteredServices.forEach((service) => {
      const isAdded = currentInvoiceServices.includes(service.service_id);

      const serviceItem = document.createElement('div');
      serviceItem.className = `service-item service-item-style ${
        isAdded ? 'service-item-added' : ''
      }`;
      serviceItem.dataset.id = service.service_id;
      serviceItem.dataset.name = service.service_name;
      serviceItem.dataset.price = service.service_price;

      serviceItem.innerHTML = `
            <div class="service-item-name">${service.service_name}</div>
            ${!isAdded ? renderServicePriceHTML(service) : ''}
            ${isAdded ? '<div class="service-item-selected">Đã chọn</div>' : ''}
        `;

      if (!isAdded) {
        serviceItem.addEventListener('click', () => {
          selectServiceForStaff(service.service_id, 1);
        });
      }

      elements.serviceList.appendChild(serviceItem);
    });
  }

  function handleServiceGroupClick(e) {
    if (!elements.serviceGroups) return;
    const target = e.target.closest('.service-group-btn');
    if (!target) return;

    selectedServiceGroup = target.dataset.group;

    document.querySelectorAll('.service-group-btn').forEach((btn) => {
      if (btn.dataset.group === selectedServiceGroup) {
        btn.classList.add('service-group-btn-active');
        btn.classList.remove('service-group-btn-inactive');
      } else {
        btn.classList.remove('service-group-btn-active');
        btn.classList.add('service-group-btn-inactive');
      }
    });

    loadServicesForGroup();
  }

  // --- Service Selection & Assignment ---

  // ✅ Helper function để xử lý service selection (tránh duplicate code)
  function processServiceSelection(service, service_id, quantity) {
    currentServiceForStaff = {
      id: service.service_id,
      name: service.service_name,
      price: parseFloat(service.service_price),
      quantity: quantity,
      type: 'service',
    };

    // ✅ Dùng currentUserRole (đã load sẵn trong sidebar) để check
    // Thu Ngân hoặc Quản Lý → hiện modal chọn thợ
    // Thợ → tự động gán cho user hiện tại (instant, không cần modal)
    const rolesWithStaffModal = ['Thu Ngân', 'Quản Lý'];
    if (rolesWithStaffModal.includes(currentUserRole)) {
      openStaffModal(currentServiceForStaff);
    } else {
      const staff_id = checkinData.currentUser.employee_id;
      const staff_name = checkinData.currentUser.display_name;
      addServiceToInvoice(service_id, staff_id, staff_name, quantity);
    }
  }

  // ✅ OPTIMIZED: Lấy từ cache thay vì fetch API mỗi lần
  function selectServiceForStaff(service_id, quantity = 1) {
    const cachedServices = getServicesFromLocalStorage();

    if (cachedServices && cachedServices.length > 0) {
      // Dùng cache - instant response
      const service = cachedServices.find((s) => s.service_id === service_id);
      if (!service) {
        toastError('Không tìm thấy dịch vụ');
        return;
      }
      processServiceSelection(service, service_id, quantity);
    } else {
      // Fallback: Fetch nếu cache trống
      fetchAPI('services').then((services) => {
        const service = services.find((s) => s.service_id === service_id);
        if (!service) return;

        // Save to cache for next time
        saveServicesToLocalStorage(services);
        processServiceSelection(service, service_id, quantity);
      });
    }
  }

  // ✅ OPTIMIZED: Mở modal ngay lập tức, không cần await
  function openStaffModal(item) {
    // Kiểm tra các elements cần thiết cho modal chọn thợ
    if (!elements.modalServiceName || !elements.selectStaffModal) {
      toastError('Không thể mở modal do thiếu phần tử DOM.');
      return;
    }
    elements.modalServiceName.innerHTML = `<strong>Dịch vụ:</strong> ${item.name}`;

    // Set currentServiceForStaff for the modal
    currentServiceForStaff = item;

    // Xóa input số lượng cũ nếu có
    const quantityContainer = document.getElementById('quantity-container');
    if (quantityContainer) {
      quantityContainer.innerHTML = '';
    }

    // Tạo và gắn input số lượng mới vào container riêng
    const quantityInputContainer = document.createElement('div');
    quantityInputContainer.className = 'quantity-input-container';
    quantityInputContainer.innerHTML = `
        <div class="quantity-row">
            <label class="quantity-label"><strong>Số lượng:</strong></label>
            <div class="quantity-controls">
                <button type="button" class="qty-btn qty-btn-decrement">-</button>
                <input type="number" min="1" value="${item.quantity || 1}" class="quantity-input" />
                <button type="button" class="qty-btn qty-btn-increment">+</button>
            </div>
        </div>
    `;
    if (quantityContainer) {
      quantityContainer.appendChild(quantityInputContainer);
    }

    const input = quantityInputContainer.querySelector('.quantity-input');
    quantityInputContainer.querySelector('.qty-btn-decrement').addEventListener('click', () => {
      const current = parseInt(input.value) || 1;
      if (current > 1) input.value = current - 1;
    });
    quantityInputContainer.querySelector('.qty-btn-increment').addEventListener('click', () => {
      const current = parseInt(input.value) || 1;
      input.value = current + 1;
    });

    // Clear selected pills container to ensure clean state
    const selectedPillsContainer = document.getElementById('staff-selected-pills');
    if (selectedPillsContainer) {
      selectedPillsContainer.innerHTML = '';
    }

    // ✅ Hiển thị modal NGAY LẬP TỨC
    elements.selectStaffModal.classList.remove('hidden');

    // ✅ Render danh sách thợ (sync, lấy từ localStorage)
    renderStaffList(item);

    // Pre-select staff if editing
    if (item.editIndex !== undefined && item.selectedStaffId) {
      // Kiểm tra window.currentStaffList tồn tại trước khi gọi find
      if (window.currentStaffList && Array.isArray(window.currentStaffList)) {
        const selectedStaff = window.currentStaffList.find(
          (s) => s.employee_id == item.selectedStaffId
        );
        if (selectedStaff) {
          toggleStaffSelection(selectedStaff);
        }
      }
    }
  }

  async function addServiceToInvoice(service_id, staff_id, staff_name, quantity = 1) {
    // ✅ NULL CHECK: Ensure invoice exists
    if (!invoices || !invoices[currentInvoiceIndex]) {
      toastError('Không có hóa đơn để thêm dịch vụ. Vui lòng tìm khách hàng trước.');
      return;
    }

    const invoice = invoices[currentInvoiceIndex];

    // 🔧 FIX: Ngăn chặn thêm dịch vụ cho hóa đơn đã thanh toán
    if (invoice.status === 'paid') {
      toastError('Không thể thêm dịch vụ cho hóa đơn đã thanh toán!');
      return;
    }

    // ✅ NULL CHECK: Ensure services array exists
    if (!invoice.services || !Array.isArray(invoice.services)) {
      invoice.services = [];
    }

    const services = getServicesFromLocalStorage() || [];
    const service = services.find((s) => s.service_id === service_id);

    if (!service) {
      toastError('Không tìm thấy dịch vụ.');
      return;
    }

    // ✅ FIX: LUÔN dùng giá GỐC (service_price) khi thêm dịch vụ
    // Logic giảm giá sẽ được tính tự động trong calculateInvoiceTotals()
    // Ví dụ: Combo HS-SV giá gốc 100k, giá ưu đãi 90k
    //   → Thêm vào invoice: price = 100k
    //   → calculateInvoiceTotals() sẽ tự động áp giảm 10k nếu có discounted_price
    const selectedPrice = parseFloat(service.service_price) || 0;
    const totalPrice = selectedPrice * quantity;

    invoice.services.push({
      service_id: service_id,
      service_name: service.service_name || 'Dịch vụ không xác định',
      price: totalPrice,
      quantity: quantity,
      staff_id: staff_id,
      staff_name: staff_name || 'Thợ không xác định',
      type: 'service',
    });

    invoice.isDirty = true;
    invoice.isManualPromo = false; // ✅ Reset để áp dụng logic tự động chọn CTKM

    // Debug: Service added to invoice

    // ✅ Tối ưu: Cập nhật UI ngay lập tức, không chờ async
    saveInvoicesToLocalStorage();
    await calculateInvoiceTotals();

    // Render selected services trước để user thấy ngay
    renderSelectedServices();

    // Update totals display
    if (elements.subtotalAmount) {
      elements.subtotalAmount.textContent = formatCurrency(invoice.subtotal);
    }
    if (elements.totalAmount) {
      elements.totalAmount.textContent = formatCurrency(invoice.total);
    }

    // ✅ Không scroll - user đang xây dựng hóa đơn
    toastSuccess('Đã thêm dịch vụ vào hóa đơn!');

    // ✅ Background save (saveInvoiceToDB tự reload data sau khi lưu)
    if (invoice.invoice_id) {
      saveInvoiceToDB(invoice)
        .then((ok) => {
          if (!ok) {
            toastError('⚠️ Dịch vụ vừa thêm CHƯA lưu được lên hệ thống — kiểm tra lại hóa đơn!');
          }
        })
        .catch((e) => {
          console.error('Failed to save after adding service:', e);
          toastError('⚠️ Dịch vụ vừa thêm CHƯA lưu được lên hệ thống — kiểm tra lại hóa đơn!');
        });
    }
  }

  function renderSelectedServices() {
    if (!elements.selectedServices) {
      return;
    }

    // Safety check: if no invoices or invalid index
    if (invoices.length === 0 || currentInvoiceIndex < 0 || !invoices[currentInvoiceIndex]) {
      elements.selectedServices.innerHTML =
        '<div class="selected-services-empty">Chưa có dịch vụ hoặc sản phẩm nào được chọn</div>';
      return;
    }

    const invoice = invoices[currentInvoiceIndex];
    const isPaid = invoice.status === 'paid';

    if (invoice.services.length === 0) {
      elements.selectedServices.innerHTML =
        '<div class="selected-services-empty">Chưa có dịch vụ hoặc sản phẩm nào được chọn</div>';
      return;
    }

    elements.selectedServices.innerHTML = '';

    invoice.services.forEach((service, index) => {
      const service_name = service.service_name || 'Dịch vụ không xác định';
      const staff_name = service.staff_name || 'Thợ không xác định';
      const price = service.price || 0;
      const quantity = service.quantity || 1;
      const serviceItem = document.createElement('div');
      serviceItem.className = 'selected-service-item';
      serviceItem.dataset.index = index;

      serviceItem.innerHTML = `
            <div>
                <div class="selected-service-name">${service_name}</div>
                <div class="selected-service-staff">Thợ: ${staff_name}</div>
                <div class="selected-service-quantity">Số lượng: ${quantity}</div>
                <div class="hidden quantity-input-container quantity-input-container-style">
                    <label class="selected-service-quantity-label">Số lượng:</label>
                    <input type="number" min="1" value="${quantity}" class="quantity-input quantity-input-style">
                </div>
            </div>
            <div class="selected-service-actions">
                <span class="selected-service-price">${formatCurrency(price)}</span>
                ${
                  !isPaid
                    ? `
                    <button class="edit-service-btn edit-service-btn-style" data-index="${index}" title="Chỉnh sửa">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="remove-service-btn remove-service-btn-style" data-index="${index}" title="Xóa">
                        <i class="fas fa-trash"></i>
                    </button>
                `
                    : ''
                }
            </div>
        `;

      elements.selectedServices.appendChild(serviceItem);
    });

    if (!isPaid) {
      document.querySelectorAll('.edit-service-btn').forEach((btn) => {
        btn.addEventListener('click', (e) => {
          const index = e.currentTarget.dataset.index;
          editService(index);
        });
      });

      document.querySelectorAll('.remove-service-btn').forEach((btn) => {
        btn.addEventListener('click', (e) => {
          const index = e.currentTarget.dataset.index;
          removeService(index);
        });
      });
    }
  }

  function editService(index) {
    if (!elements.selectStaffModal) return;
    const service = invoices[currentInvoiceIndex].services[index];
    const item = {
      id: service.service_id,
      name: service.service_name,
      price: service.price / (service.quantity || 1),
      quantity: service.quantity || 1,
      selectedStaffId: service.staff_id,
      selectedStaffName: service.staff_name,
      type: service.type || 'service',
      editIndex: index,
    };

    openStaffModal(item);
  }

  async function updateServiceStaff(index, staff_id, staff_name, quantity) {
    const invoice = invoices[currentInvoiceIndex];
    if (index < 0 || index >= invoice.services.length) {
      toastError('Dịch vụ hoặc sản phẩm không hợp lệ.');
      return;
    }

    const service = invoice.services[index];
    const basePrice = service.price / (service.quantity || 1);

    if (service.type === 'product') {
      const product = getProductsFromLocalStorage().find((p) => p.id === service.service_id);
      if (!product) {
        toastError('Không tìm thấy sản phẩm!');
        return;
      }

      const oldQuantity = service.quantity || 1;
      const availableStock = parseInt(product.stock) + oldQuantity;
      if (quantity > availableStock) {
        toastWarning(`Số lượng vượt quá tồn kho! Tồn kho hiện tại: ${availableStock}`);
        return;
      }
    }

    service.staff_id = staff_id;
    service.staff_name = staff_name;
    service.quantity = quantity;
    service.price = basePrice * quantity;

    invoice.isDirty = true;

    saveInvoicesToLocalStorage();
    await calculateInvoiceTotals(); // ✅ FIX: AWAIT để đảm bảo total được tính lại trước khi save
    renderSelectedServices();

    // saveInvoiceToDB tự reload data sau khi lưu — không reload lặp ở đây nữa
    if (invoice.invoice_id) {
      const ok = await saveInvoiceToDB(invoice);
      if (!ok) return; // lỗi đã hiện popup, không toast thành công ảo
    }

    toastSuccess('Đã cập nhật thông tin dịch vụ.');
  }

  async function removeService(index) {
    const invoice = invoices[currentInvoiceIndex];

    // 🔧 FIX: Ngăn chặn xóa dịch vụ cho hóa đơn đã thanh toán
    if (invoice.status === 'paid') {
      toastError('Không thể xóa dịch vụ cho hóa đơn đã thanh toán!');
      return;
    }

    const services = invoice.services;
    const invoice_id = invoice.invoice_id;

    const hasInvoiceId = !!invoice_id;
    const hasOnlyOneService = services.length === 1;

    // Nếu chỉ còn 1 dịch vụ, yêu cầu xác nhận trước khi xóa
    if (hasOnlyOneService) {
      const confirmRemove = await showConfirm(
        'Có chắc muốn xóa dịch vụ này không bro? Nếu xóa dịch vụ này hóa đơn sẽ không còn dịch vụ nào. Hãy thêm lại dịch vụ khác sau khi xóa!',
        'Xác nhận'
      );

      if (!confirmRemove) return;
    }

    // Thực hiện xóa
    services.splice(index, 1);
    invoice.isDirty = true; // Đánh dấu hóa đơn có thay đổi
    invoice.isManualPromo = false; // Reset khi xóa dịch vụ để áp dụng logic tự động

    renderSelectedServices();
    await calculateInvoiceTotals(); // ✅ FIX: AWAIT để đảm bảo total được tính lại trước khi save
    // ⚡ KHÔNG renderCurrentInvoice() ở đây — nó rebuild cả lưới dịch vụ/thông tin
    // khách gây chớp trang; renderSelectedServices + calculateInvoiceTotals đã
    // cập nhật đủ phần UI liên quan.

    // ✅ FIX: LUÔN lưu vào localStorage khi xóa dịch vụ (tương tự addServiceToInvoice)
    saveInvoicesToLocalStorage();

    // ⚠️ Hoá đơn 0 dịch vụ: KHÔNG thể lưu DB (server yêu cầu ≥1 dịch vụ).
    // Giữ isDirty = true để reload không đè lại dịch vụ cũ từ DB; khi thợ thêm
    // dịch vụ mới, lần save đó sẽ ghi danh sách đúng lên DB.
    if (hasInvoiceId && services.length === 0) {
      toastWarning('Đã xóa. Hóa đơn chưa có dịch vụ — hãy thêm dịch vụ mới để lưu lên hệ thống!');
      return;
    }

    // Nếu hóa đơn có id thì đồng bộ với DB (saveInvoiceToDB tự reload data sau khi lưu)
    if (hasInvoiceId) {
      const ok = await saveInvoiceToDB(invoice);
      if (!ok) return; // lỗi đã hiện popup, KHÔNG toast thành công ảo
    }

    toastSuccess('Đã xóa dịch vụ khỏi hóa đơn.');
  }

  // ==============================
  // 10. PRODUCT MANAGEMENT
  // ==============================
  // --- Product Groups Loading ---

  async function renderProductGroups() {
    if (!elements.productGroups) return;

    try {
      // ✅ CACHE-FIRST: Lấy từ localStorage trước, không gọi API
      let productGroups = getProductGroupsFromLocalStorage();

      // Kiểm tra response có lỗi permission không
      if (!productGroups || (Array.isArray(productGroups) && productGroups.length === 0)) {
        elements.productGroups.innerHTML =
          '<div class="product-groups-empty">Bạn không có quyền xem sản phẩm hoặc chi nhánh này không có sản phẩm</div>';
        elements.productList.innerHTML = '';
        selectedProductGroup = null;
        return;
      }

      // Kiểm tra productGroups có phải array không
      if (!Array.isArray(productGroups)) {
        elements.productGroups.innerHTML =
          '<div class="product-groups-empty">Lỗi định dạng dữ liệu sản phẩm</div>';
        elements.productList.innerHTML = '';
        selectedProductGroup = null;
        return;
      }

      const rawGroups = [...new Set(productGroups.map((group) => group.group_code))];
      const mappedGroups = rawGroups.map(
        (code) => productGroupMapping[code] || code.toLowerCase().replace(/\s/g, '-')
      );

      const displayOrder = ['wax', 'gom', 'oil', 'other'];
      const sortedGroups = displayOrder.filter((group) => mappedGroups.includes(group));

      elements.productGroups.innerHTML = '';

      if (sortedGroups.length === 0) {
        elements.productGroups.innerHTML =
          '<div class="product-groups-empty">Không có nhóm sản phẩm nào</div>';
        elements.productList.innerHTML = '';
        selectedProductGroup = null;
        return;
      }

      sortedGroups.forEach((mappedGroup) => {
        const displayName = productGroupDisplayNames[mappedGroup] || mappedGroup;

        const button = document.createElement('button');
        button.className = `product-group-btn product-group-btn-style ${
          mappedGroup === selectedProductGroup
            ? 'product-group-btn-active'
            : 'product-group-btn-inactive'
        }`;
        button.dataset.group = mappedGroup;
        button.textContent = displayName;

        button.addEventListener('click', handleProductGroupClick);

        elements.productGroups.appendChild(button);
      });

      if (!selectedProductGroup && sortedGroups.length > 0) {
        selectedProductGroup = sortedGroups[0];
        const firstButton = elements.productGroups.querySelector(
          `.product-group-btn[data-group="${selectedProductGroup}"]`
        );
        if (firstButton) {
          firstButton.classList.add('product-group-btn-active');
          firstButton.classList.remove('product-group-btn-inactive');
        }
        await renderProductList();
      }
    } catch (error) {
      elements.productGroups.innerHTML =
        '<div class="product-groups-empty">Lỗi khi tải nhóm sản phẩm. Vui lòng thử lại.</div>';
      elements.productList.innerHTML = '';
      selectedProductGroup = null;
    }
  }

  async function renderProductList() {
    if (!elements.productList) return;

    // Nếu chưa chọn nhóm sản phẩm thì return
    if (!selectedProductGroup) return;

    try {
      // ✅ CACHE-FIRST: Lấy từ localStorage trước, không gọi API
      let products = getProductsFromLocalStorage() || [];

      const filteredProducts = products.filter(
        (product) =>
          productGroupMapping[product.group_code] === selectedProductGroup ||
          product.group_code === selectedProductGroup
      );

      elements.productList.innerHTML = '';

      if (!filteredProducts || filteredProducts.length === 0) {
        // Nếu không có sản phẩm nào trong group này, hiển thị message
        elements.productList.innerHTML =
          '<div class="product-list-empty">Không có sản phẩm nào trong nhóm này</div>';

        // Nếu API products trả về rỗng (do permission hoặc branch), cũng ẩn product groups
        if (products.length === 0) {
          if (elements.productGroups) {
            elements.productGroups.innerHTML =
              '<div class="product-groups-empty">Bạn không có quyền xem sản phẩm hoặc chi nhánh này không có sản phẩm</div>';
          }
        }
        return;
      }

      // Kiểm tra invoices[currentInvoiceIndex] tồn tại trước khi access
      const currentInvoice = invoices[currentInvoiceIndex];
      const currentInvoiceProducts =
        currentInvoice && Array.isArray(currentInvoice.services)
          ? currentInvoice.services.filter((s) => s.type === 'product').map((s) => s.service_id)
          : [];

      elements.productList.className = 'product-list product-list-style';

      filteredProducts.forEach((product) => {
        const isAdded = currentInvoiceProducts.includes(product.id);

        const productItem = document.createElement('div');
        productItem.className = `product-item product-item-style ${
          isAdded ? 'product-item-added' : ''
        }`;
        productItem.dataset.id = product.id;
        productItem.dataset.name = product.product_name;
        productItem.dataset.price = product.price;

        productItem.innerHTML = `
              <div class="product-item-name">${product.product_name}</div>
              <div class="product-item-price">${formatCurrency(parseFloat(product.price))}</div>
              <div class="product-item-stock">Tồn kho: ${product.stock}</div>
              ${isAdded ? '<div class="product-item-selected">Đã chọn</div>' : ''}
          `;

        if (!isAdded) {
          productItem.addEventListener('click', async () => {
            if (parseInt(product.stock) < 1) {
              await showWarning(`Sản phẩm "${product.product_name}" đã hết hàng!`, 'Hết hàng');
              return;
            }
            selectProductForStaff(product.id, 1);
          });
        }

        elements.productList.appendChild(productItem);
      });
    } catch (error) {
      console.error('Error in renderProductList:', error);
      elements.productList.innerHTML =
        '<div class="product-list-empty">Lỗi khi tải sản phẩm. Vui lòng thử lại.</div>';
    }
  }

  function handleProductGroupClick(e) {
    if (!elements.productGroups) return;

    const target = e.target.closest('.product-group-btn');
    if (!target) return;

    selectedProductGroup = target.dataset.group;
    currentTab = 'products';
    updateTabState();

    document.querySelectorAll('.product-group-btn').forEach((btn) => {
      if (btn.dataset.group === selectedProductGroup) {
        btn.classList.add('product-group-btn-active');
        btn.classList.remove('product-group-btn-inactive');
      } else {
        btn.classList.remove('product-group-btn-active');
        btn.classList.add('product-group-btn-inactive');
      }
    });

    renderProductList();
  }

  // --- Product Selection ---

  // ✅ Helper function để xử lý product selection (tránh duplicate code)
  function processProductSelection(product, product_id, quantity) {
    currentProductForStaff = {
      id: product.id,
      name: product.product_name,
      price: parseFloat(product.price),
      quantity: quantity,
      type: 'product',
    };

    // ✅ Dùng currentUserRole (đã load sẵn trong sidebar) để check
    // Thu Ngân hoặc Quản Lý → hiện modal chọn thợ
    // Thợ → tự động gán cho user hiện tại (instant, không cần modal)
    const rolesWithStaffModal = ['Thu Ngân', 'Quản Lý'];
    if (rolesWithStaffModal.includes(currentUserRole)) {
      openStaffModal(currentProductForStaff);
    } else {
      const staff_id = checkinData.currentUser.employee_id;
      const staff_name = checkinData.currentUser.display_name;
      addProductToInvoice(product_id, staff_id, staff_name, quantity);
    }
  }

  // ✅ OPTIMIZED: Lấy từ cache thay vì fetch API mỗi lần
  function selectProductForStaff(product_id, quantity = 1) {
    const cachedProducts = getProductsFromLocalStorage();

    if (cachedProducts && cachedProducts.length > 0) {
      // Dùng cache - instant response
      const product = cachedProducts.find((p) => p.id === product_id);
      if (!product) {
        toastError('Không tìm thấy sản phẩm');
        return;
      }
      processProductSelection(product, product_id, quantity);
    } else {
      // Fallback: Fetch nếu cache trống
      fetchAPI('products')
        .then((response) => {
          let products = [];

          // Xử lý response - có thể là array hoặc object {success: true, data: [...]}
          if (Array.isArray(response)) {
            products = response;
          } else if (response?.data && Array.isArray(response.data)) {
            products = response.data;
          } else {
            console.warn('Unexpected products response format:', response);
            toastError('Lỗi định dạng dữ liệu sản phẩm');
            return;
          }

          const product = products.find((p) => p.id === product_id);
          if (!product) {
            toastError('Không tìm thấy sản phẩm');
            return;
          }

          // Save to cache for next time
          saveProductsToLocalStorage(products);
          processProductSelection(product, product_id, quantity);
        })
        .catch((error) => {
          toastError('Lỗi khi tải danh sách sản phẩm');
        });
    }
  }

  async function addProductToInvoice(product_id, staff_id, staff_name, quantity = 1) {
    const invoice = invoices[currentInvoiceIndex];
    const products = getProductsFromLocalStorage() || [];
    const product = products.find((p) => p.id === product_id);

    if (!product) {
      toastError('Không tìm thấy sản phẩm');
      return;
    }

    const stock = parseInt(product.stock);
    const selectedPrice = parseFloat(product.price) || 0;

    let existing = invoice.services.find(
      (s) => s.type === 'product' && s.service_id === product.id && s.staff_id === staff_id
    );

    const totalRequested = quantity + (existing ? existing.quantity : 0);
    if (stock < totalRequested) {
      toastWarning(
        `Không đủ hàng trong kho. Tồn: ${stock}, đã chọn: ${existing ? existing.quantity : 0}`
      );
      return;
    }

    if (existing) {
      existing.quantity += quantity;
      existing.price += selectedPrice * quantity;
    } else {
      invoice.services.push({
        type: 'product',
        service_id: product.id,
        service_name: product.product_name || 'Sản phẩm không xác định',
        price: selectedPrice * quantity,
        quantity: quantity,
        staff_id: staff_id,
        staff_name: staff_name || 'Thợ không xác định',
      });
    }

    invoice.isDirty = true;
    saveInvoicesToLocalStorage();
    // ✅ FIX: AWAIT để total được tính lại (bao gồm sản phẩm mới) TRƯỚC khi lưu DB —
    // thiếu await thì saveInvoiceToDB chạy trước, đẩy tổng cũ lên server
    await calculateInvoiceTotals();
    renderCurrentInvoice();
    renderProductList();

    if (invoice.invoice_id) {
      saveInvoiceToDB();
    }

    toastSuccess('Đã thêm sản phẩm vào hóa đơn!');
  }

  function updateTabState() {
    if (
      !elements.servicesTab ||
      !elements.productsTab ||
      !elements.serviceGroups ||
      !elements.productGroups ||
      !elements.serviceList ||
      !elements.productList
    )
      return;

    if (currentTab === 'services') {
      elements.servicesTab.classList.add('services-tab-active');
      elements.servicesTab.classList.remove('services-tab-inactive');
      elements.productsTab.classList.add('products-tab-inactive');
      elements.productsTab.classList.remove('products-tab-active');
      elements.serviceGroups.classList.remove('hidden');
      elements.serviceList.classList.remove('hidden');
      elements.productGroups.classList.add('hidden');
      elements.productList.classList.add('hidden');

      // Reset product state
      selectedProductGroup = null;

      // ✅ KHÔNG gọi loadServiceGroups() để tránh auto-scroll
      // Chỉ load services for current group
      loadServicesForGroup();
    } else {
      elements.servicesTab.classList.add('services-tab-inactive');
      elements.servicesTab.classList.remove('services-tab-active');
      elements.productsTab.classList.add('products-tab-active');
      elements.productsTab.classList.remove('products-tab-inactive');
      elements.serviceGroups.classList.add('hidden');
      elements.serviceList.classList.add('hidden');
      elements.productGroups.classList.remove('hidden');
      elements.productList.classList.remove('hidden');

      // Reset service state
      selectedServiceGroup = 'main';

      renderProductGroups();
      renderProductList();
    }
  }

  // ==============================
  // 11. Invoice UI Functions
  // =============================

  /**
   * Helper function để reload invoices data theo period hiện tại
   * Dùng sau các actions (payment, save, delete) để refresh data mà không thay đổi context
   * Mặc định sẽ reload 7days (nhẹ nhất), chỉ reload thisMonth/lastMonth nếu đó là period đang xem
   */
  async function reloadCurrentPeriodInvoices() {
    // Nếu đang xem thisMonth hoặc lastMonth, reload đúng period đó
    // Ngược lại, reload 7days (đủ cho today/yesterday và nhẹ localStorage)
    const periodToLoad =
      loadedDataPeriod === 'thisMonth' || loadedDataPeriod === 'lastMonth'
        ? loadedDataPeriod
        : '7days';
    return loadStaffInvoices(periodToLoad);
  }

  async function loadStaffInvoices(filter = 'today', startDate = null, endDate = null) {
    const funcStart = performance.now();
    perfLog.mark(`📥 START loadStaffInvoices(${filter})`);

    // ⚠️ Nếu đang có fetch chạy: KHÔNG trả về promise cũ (nó đọc DB TRƯỚC khi
    // thao tác vừa rồi được lưu → dữ liệu ôi thiu ghi đè mất dịch vụ/thợ vừa sửa).
    // Đợi fetch cũ xong rồi fetch LẠI để chắc chắn lấy dữ liệu sau-save.
    if (isFetching && currentFetchPromise) {
      perfLog.mark(`⏳ CHAINING after ongoing loadStaffInvoices(${filter})`);
      return currentFetchPromise
        .catch(() => {})
        .then(() => loadStaffInvoices(filter, startDate, endDate));
    }

    // ✅ Tạo promise mới và track nó
    isFetching = true;
    currentFetchPromise = (async () => {
      try {
        const canViewAll = canViewAllInvoices();
        const displayName = checkinData.currentUser.display_name;
        if (!displayName && !canViewAll) {
          return;
        }
        // Xây dựng URL API
        // Luôn gọi lấy tất cả hóa đơn từ server; phần lọc theo vai trò sẽ xử lý ở client
        // (Backend vẫn nên kiểm soát quyền truy cập để tránh lộ dữ liệu ngoài ý muốn.)
        let url = `staff-invoices?filter=${encodeURIComponent(filter)}`;
        // ✅ FIX: Không thêm branch_id ở đây vì fetchAPI() đã tự động thêm rồi
        // Tránh duplicate: staff-invoices?filter=thisMonth&branch_id=1&branch_id=1
        if (filter === 'custom' && startDate && endDate) {
          url += `&start_date=${startDate}&end_date=${endDate}`;
        }

        // Tải dữ liệu từ API
        const invoicesFromDB = await fetchAPI(url);
        // Nếu là Thợ (không phải Thu ngân/Quản lý) thì chỉ hiển thị hóa đơn liên quan đến chính mình
        const belongsToMe = (inv) => {
          try {
            const dn = (displayName || '').trim();
            if (!dn) return false;
            // Kiểm tra theo danh sách dịch vụ (staff_name)
            const services = Array.isArray(inv.services) ? inv.services : [];
            const byService = services.some((s) => (s?.staff_name || '').trim() === dn);
            // Một số invoice có thể có created_user/cashier hoặc staff_name trên hóa đơn
            const byCreator =
              (inv.created_user || '').trim() === dn || (inv.cashier || '').trim() === dn;
            const byHeaderStaff = (inv.staff_name || '').trim() === dn;
            // Nếu API trả về staff_id, so sánh với id người dùng để tránh lệ thuộc vào display_name
            const currentUserId = String(checkinData.currentUser?.id || '');
            const byStaffId = (Array.isArray(inv.services) ? inv.services : []).some(
              (s) => s && s.staff_id && String(s.staff_id) === currentUserId
            );
            return byService || byCreator || byHeaderStaff || byStaffId;
          } catch (e) {
            return false;
          }
        };

        const visibleFromDB = canViewAll ? invoicesFromDB : invoicesFromDB.filter(belongsToMe);
        if (!canViewAll && visibleFromDB.length === 0) {
          try {
            const sample = (invoicesFromDB || []).slice(0, 5).map((inv) => ({
              invoice_id: inv.invoice_id,
              services: (inv.services || []).map((s) => ({
                staff_name: s?.staff_name,
                staff_id: s?.staff_id,
              })),
            }));
          } catch (e) {}
        }

        // Làm mới danh sách hóa đơn
        invoicesData = visibleFromDB.map((invoice) => ({
          ...invoice,
          services: Array.isArray(invoice.services) ? invoice.services : [],
          images: Array.isArray(invoice.images) ? invoice.images : [],
        }));

        // Loại bỏ trùng lặp trong invoicesData
        invoicesData = [...new Map(invoicesData.map((item) => [item.invoice_id, item])).values()];

        // 🔧 FIX: Lưu invoice đang active TRƯỚC khi merge để tránh mất đồng bộ
        const activeInvoiceBeforeMerge = invoices[currentInvoiceIndex];
        const activeIdentifier =
          activeInvoiceBeforeMerge?.invoice_id || activeInvoiceBeforeMerge?.id;

        // 🔧 FIX: Lọc bỏ các invoice đã bị xóa trong phiên này
        const validInvoicesData = invoicesData.filter(
          (inv) => !deletedInvoiceIds.has(inv.invoice_id)
        );

        // 🎯 ĐỒNG BỘ 2 CHIỀU THÔNG MINH:
        // 1. Giữ lại invoice LOCAL có invoice_id (đã tạo nhưng có thể chưa có trong DB response)
        // 2. Giữ lại invoice LOCAL chưa có invoice_id (draft - chưa lưu)
        // 3. Merge/Update invoice từ DB
        const localInvoicesWithId = invoices.filter(
          (inv) => inv.invoice_id && !deletedInvoiceIds.has(inv.invoice_id)
        );
        const localDrafts = invoices.filter((inv) => !inv.invoice_id);

        // Map invoice_id → local invoice để tra cứu nhanh
        const localInvoiceMap = new Map(localInvoicesWithId.map((inv) => [inv.invoice_id, inv]));

        // Merge DB invoices với local
        const mergedInvoices = [];

        // Thêm tất cả invoice từ DB (update hoặc thêm mới)
        for (const dbInvoice of validInvoicesData) {
          const existingLocal = localInvoiceMap.get(dbInvoice.invoice_id);

          // ⚠️ Hoá đơn đang có thay đổi local CHƯA LƯU (isDirty) — giữ nguyên bản
          // local, tuyệt đối không đè bằng data DB (có thể cũ hơn thao tác đang làm).
          // Bản local sẽ được đẩy lên DB ở lần saveInvoiceToDB kế tiếp.
          if (existingLocal && existingLocal.isDirty) {
            mergedInvoices.push(existingLocal);
            localInvoiceMap.delete(dbInvoice.invoice_id); // tránh push trùng ở vòng dưới
            continue;
          }

          // 🔧 SMART MERGE IMAGES: Giữ lại temp URLs và blob URLs từ local
          const localImages = existingLocal?.images || [];
          const dbImages = dbInvoice.images || [];

          // Lọc temp URLs và blob URLs từ local
          const tempAndBlobUrls = localImages.filter(
            (url) =>
              url &&
              (url.includes('/temp/') ||
                url.includes('/temp-feedback-image/') ||
                url.startsWith('blob:'))
          );

          // Merge: temp/blob URLs từ local + real URLs từ DB (loại trùng)
          const mergedImages = [...new Set([...tempAndBlobUrls, ...dbImages])];

          // Tương tự cho feedbackImages
          const localFeedbackImages = existingLocal?.feedbackImages || [];
          const dbFeedbackImages = dbInvoice.feedback_images || [];
          const tempAndBlobFeedbackUrls = localFeedbackImages.filter(
            (url) => url && (url.includes('/temp-feedback-image/') || url.startsWith('blob:'))
          );
          const mergedFeedbackImages = [
            ...new Set([...tempAndBlobFeedbackUrls, ...dbFeedbackImages]),
          ];

          // ✅ Prepare customer.photos từ mergedImages (temp URLs từ DB)
          const latest3Photos = mergedImages
            .filter((url) => url && !url.includes('lego'))
            .slice(-3);

          const invoiceData = {
            id: existingLocal ? existingLocal.id : mergedInvoices.length + localDrafts.length + 1,
            invoice_id: dbInvoice.invoice_id,
            customer: {
              name: dbInvoice.customer_name || 'Khách hàng vãng lai',
              phone: dbInvoice.customer_phone || '',
              id: dbInvoice.customer_id || null,
              membership: dbInvoice.membership_label || 'Khách thường',
              promoCode: dbInvoice.promo_code || null,
              photos: latest3Photos, // ✅ Set photos ngay từ đầu
            },
            status: dbInvoice.status,
            subtotal: parseFloat(dbInvoice.subtotal) || 0,
            discount: parseFloat(dbInvoice.discount) || 0,
            tips: parseFloat(dbInvoice.tips) || 0,
            total: parseFloat(dbInvoice.total) || 0,
            services: (dbInvoice.services || []).map((s) => ({
              service_id: s.service_id || null,
              service_name: s.service_name || 'Dịch vụ không xác định',
              price: parseFloat(s.price) || 0,
              staff_id: s.staff_id || null,
              staff_name: s.staff_name || 'Thợ không xác định',
              type: s.type || 'service',
              quantity: s.quantity || 1,
            })),
            images: mergedImages, // ✅ Merged images
            feedbackImages: mergedFeedbackImages, // ✅ Merged feedback images
            notImage: dbInvoice.not_image || [],
            paymentMethod: dbInvoice.payment_method || null,
            promoName: dbInvoice.promo_name || null,
            discountType: dbInvoice.discount_type || 'percent',
            created_at: dbInvoice.created_at,
            created_user: dbInvoice.created_user || 'Unknown',
            booking_id: dbInvoice.booking_id || null,
            promo_code: dbInvoice.promo_code || null,
            promo_status: dbInvoice.promo_status || null,
            membership_label: dbInvoice.membership_label || 'Khách thường',
            isFromDB: true,
            isManualPromo: !!dbInvoice.promo_name,
            // Không có CTKM mà vẫn có discount → là giảm giá thủ công đã lưu,
            // giữ cờ để calculateInvoiceTotals không reset về 0
            isManualDiscount: !dbInvoice.promo_name && parseFloat(dbInvoice.discount) > 0,
          };

          // Nếu có local invoice, merge với ưu tiên DB data (mới hơn)
          if (existingLocal) {
            // ✅ SINGLE SOURCE: Giữ nguyên customer.photos từ existingLocal (đã được update khi search/upload)
            const mergedCustomer = {
              ...invoiceData.customer,
              photos: existingLocal.customer?.photos || [],
            };

            mergedInvoices.push({
              ...existingLocal,
              ...invoiceData,
              customer: mergedCustomer,
            });
            localInvoiceMap.delete(dbInvoice.invoice_id); // Đánh dấu đã merge
          } else {
            // ✅ NEW INVOICE từ DB: customer.photos đã được set ở trên từ mergedImages
            mergedInvoices.push(invoiceData);
          }
        }

        // Thêm các invoice LOCAL có invoice_id nhưng CHƯA CÓ trong DB response
        // (Trường hợp vừa tạo xong, API chưa kịp trả về)
        for (const [invoiceId, localInvoice] of localInvoiceMap) {
          // Keeping local invoice silently
          mergedInvoices.push(localInvoice);
        }

        // Thêm các invoice DRAFT (chưa có invoice_id)
        invoices = [...mergedInvoices, ...localDrafts];

        if (invoices.length === 0) {
          // Không tạo invoice mặc định nữa
          currentInvoiceIndex = -1; // Reset current invoice index when no invoices
        } else {
          // 🔧 FIX: Tìm lại vị trí invoice đang active sau khi merge (sử dụng activeIdentifier đã lưu ở trên)
          if (activeIdentifier) {
            const newIndex = invoices.findIndex(
              (inv) => inv.invoice_id === activeIdentifier || inv.id === activeIdentifier
            );

            if (newIndex !== -1) {
              currentInvoiceIndex = newIndex;
            } else {
              // Invoice không còn trong danh sách → fallback về invoice mới nhất
              currentInvoiceIndex = invoices.length - 1;
            }
          } else {
            // Không có identifier → clamp về bounds
            currentInvoiceIndex = Math.max(0, Math.min(currentInvoiceIndex, invoices.length - 1));
          }
        }

        // Lưu vào localStorage
        saveInvoicesToLocalStorage();
        // ✅ OPTIMIZATION: Cache invoicesData
        saveInvoicesDataToLocalStorage();

        // ✅ Export invoicesData to window for dashboard module
        window.invoicesData = invoicesData;

        // ✅ Mark data đã được load
        isInvoicesDataLoaded = true;
        // ✅ Track period nào đã load - QUAN TRỌNG: Phải set đúng để logic chuyển filter hoạt động
        // 7days là default - chứa data 7 ngày gần nhất (bao gồm today và yesterday)
        // thisMonth, lastMonth, custom cần load riêng khi user chọn
        // today, yesterday cần track riêng vì data nhỏ hơn 7days
        if (filter === 'lastMonth') {
          loadedDataPeriod = 'lastMonth';
        } else if (filter === 'thisMonth') {
          loadedDataPeriod = 'thisMonth';
        } else if (filter === 'custom') {
          loadedDataPeriod = 'custom';
        } else if (filter === '7days') {
          loadedDataPeriod = '7days';
        } else if (filter === 'today') {
          loadedDataPeriod = 'today'; // ✅ FIX: Track khi chỉ load data hôm nay
        } else if (filter === 'yesterday') {
          loadedDataPeriod = 'yesterday'; // ✅ FIX: Track khi chỉ load data hôm qua
        }
        perfLog.mark(`✅ END loadStaffInvoices(${filter}) - ${invoicesData.length} invoices`);
      } catch (error) {
        perfLog.mark(`❌ ERROR loadStaffInvoices(${filter})`);
        if (invoices.length === 0) {
          invoices.push(createDefaultInvoice());
          currentInvoiceIndex = 0;
        }
        saveInvoicesToLocalStorage();
      } finally {
        isFetching = false;
        currentFetchPromise = null;
      }
    })(); // ✅ Kết thúc async IIFE

    return currentFetchPromise;
  }
  // ✅ Export loadStaffInvoices for dashboard module
  window.loadStaffInvoices = loadStaffInvoices;

  let isUserInteracting = false;
  let idleTimeout = null;
  const IDLE_TIMEOUT_MS = 30000; // 30 giây không thao tác thì coi là nhàn rỗi

  function isUserInteractingWithElements() {
    // Kiểm tra xem có phần tử nào đang được focus (ví dụ: input, textarea, select)
    const activeElement = document.activeElement;
    if (activeElement && ['INPUT', 'TEXTAREA', 'SELECT'].includes(activeElement.tagName)) {
      return true;
    }

    // Kiểm tra xem có modal nào đang mở (ví dụ: modal danh sách hóa đơn)
    const modals = document.querySelectorAll('.modal, .fixed.inset-0');
    if (modals.length > 0 && Array.from(modals).some((modal) => modal.style.display !== 'none')) {
      return true;
    }

    // Kiểm tra các sự kiện gần đây (dựa vào idleTimeout)
    return !!idleTimeout && isUserInteracting;
  }

  // Hàm thiết lập theo dõi tương tác người dùng
  function setupUserInteractionTracking() {
    const interactiveElements = document.querySelectorAll(
      'input, textarea, select, button, [contenteditable], #serviceList, #selectedServices, #addServiceBtn'
    );
    const events = ['input', 'click', 'keydown', 'change', 'focus', 'blur'];

    interactiveElements.forEach((element) => {
      events.forEach((event) => {
        element.addEventListener(event, () => {
          if (event === 'blur') {
            // Khi người dùng rời khỏi phần tử, kiểm tra lại trạng thái tương tác
            setTimeout(() => {
              if (!isUserInteractingWithElements()) {
                isUserInteracting = false;
              }
            }, 100); // Đợi một chút để đảm bảo các sự kiện khác không ghi đè
          } else {
            isUserInteracting = true;
            resetIdleTimer();
          }
        });
      });
    });

    const globalEvents = ['scroll', 'touchstart', 'mousedown'];
    globalEvents.forEach((event) => {
      document.addEventListener(event, resetIdleTimer);
    });

    function resetIdleTimer() {
      isUserInteracting = true;
      if (idleTimeout) {
        clearTimeout(idleTimeout);
      }
      idleTimeout = setTimeout(() => {
        isUserInteracting = false;
      }, IDLE_TIMEOUT_MS);
    }
  }

  function stopPolling() {
    if (pollingIntervalId) {
      clearInterval(pollingIntervalId);
      pollingIntervalId = null;
      isPollingActive = false;
    }
  }

  async function pollInvoiceStatus() {
    // Nếu đã có polling active, không start lại
    if (isPollingActive || pollingIntervalId) {
      return;
    }

    if (!window.interactionTrackingSetup) {
      setupUserInteractionTracking();
      window.interactionTrackingSetup = true;
    }

    isPollingActive = true;

    pollingIntervalId = setInterval(async () => {
      try {
        // 🔧 FIX: Chỉ polling khi filter là 'today' HOẶC user đang idle
        // - Filter 'today': Cần cập nhật realtime vì có thể có hóa đơn mới
        // - User idle: Có thể sync data ngầm mà không ảnh hưởng UX
        // - Kiểm tra cả currentFilter (invoices) và currentServiceFilter (services)
        const activeFilter = currentSection === 'services' ? currentServiceFilter : currentFilter;
        const isFilterToday = activeFilter === 'today';
        const isUserIdle = !isUserInteracting;

        if (!isFilterToday && !isUserIdle) {
          // Skip polling: Filter không phải hôm nay VÀ user đang tương tác
          return;
        }

        // ✅ CHỈ SKIP polling nếu đang ACTIVELY edit (focus vào input/textarea)
        const activeElement = document.activeElement;
        const isActivelyEditing =
          activeElement && ['INPUT', 'TEXTAREA'].includes(activeElement.tagName);

        if (isActivelyEditing) {
          // Polling skipped: User is actively editing
          return;
        }

        const currentInvoice = invoices[currentInvoiceIndex];

        // ✅ CHỈ SKIP nếu invoice có thay đổi chưa lưu
        if (currentInvoice && currentInvoice.isDirty) {
          // Polling skipped: Invoice has unsaved changes
          return;
        }

        // ✅ CHỈ SKIP nếu đang upload ảnh
        if (currentInvoice && currentInvoice.isUploadingImages) {
          // Polling skipped: Uploading images
          return;
        }

        // ✅ CHỈ SKIP nếu đang fetch dữ liệu
        if (isFetching) {
          // Polling skipped: Already fetching
          return;
        }
        const status = await getStaffStatus();
        updateStaffStatusUI();

        const previousInvoicesData = JSON.stringify(invoicesData);
        const previousCurrentInvoiceId = currentInvoice?.invoice_id;
        const previousCurrentIndex = currentInvoiceIndex;

        // ✅ Tìm invoice mới nhất TRƯỚC khi load (dựa vào created_at)
        const previousLatestInvoice =
          invoicesData.length > 0
            ? invoicesData.reduce((latest, inv) => {
                const latestTime = new Date(latest.created_at || 0).getTime();
                const invTime = new Date(inv.created_at || 0).getTime();
                return invTime > latestTime ? inv : latest;
              }, invoicesData[0])
            : null;
        const previousLatestInvoiceId = previousLatestInvoice?.invoice_id;

        // ✅ OPTIMIZED: Polling chỉ load period đang xem để giảm tải localStorage
        // Nếu đang xem thisMonth/lastMonth thì load đúng period đó, ngược lại load 7days
        await reloadCurrentPeriodInvoices();

        // 🎯 LOGIC ACTIVE INVOICE SAU KHI POLLING:
        // 1. Tìm invoice mới nhất SAU khi load (dựa vào created_at)
        // 2. Nếu có hóa đơn MỚI HƠN → Active hóa đơn mới nhất
        // 3. Nếu KHÔNG có hóa đơn mới → Giữ nguyên invoice đang active
        const currentLatestInvoice =
          invoicesData.length > 0
            ? invoicesData.reduce((latest, inv) => {
                const latestTime = new Date(latest.created_at || 0).getTime();
                const invTime = new Date(inv.created_at || 0).getTime();
                return invTime > latestTime ? inv : latest;
              }, invoicesData[0])
            : null;
        const currentLatestInvoiceId = currentLatestInvoice?.invoice_id;
        const hasNewInvoice =
          currentLatestInvoiceId && currentLatestInvoiceId !== previousLatestInvoiceId;

        if (hasNewInvoice) {
          // ✅ CÓ HÓA ĐƠN MỚI → Active hóa đơn mới nhất
          const newestInvoiceIndex = invoices.findIndex(
            (inv) => inv.invoice_id === currentLatestInvoiceId
          );
          if (newestInvoiceIndex !== -1) {
            currentInvoiceIndex = newestInvoiceIndex;
            console.log(
              '📋 Polling: New invoice detected, switching to latest invoice ID:',
              currentLatestInvoiceId
            );
          } else {
            currentInvoiceIndex = 0;
          }
        } else if (previousCurrentInvoiceId) {
          // ✅ KHÔNG CÓ HÓA ĐƠN MỚI → Giữ nguyên invoice đang active
          const newIndex = invoices.findIndex((inv) => inv.invoice_id === previousCurrentInvoiceId);
          if (newIndex !== -1) {
            currentInvoiceIndex = newIndex;
          } else {
            // Invoice đã bị xóa, giữ nguyên vị trí index nếu có thể
            currentInvoiceIndex = Math.min(previousCurrentIndex, invoices.length - 1);
          }
        } else {
          // Không có invoice_id (invoice mới chưa lưu), giữ nguyên vị trí
          currentInvoiceIndex = Math.min(previousCurrentIndex, invoices.length - 1);
        }

        const currentInvoicesData = JSON.stringify(invoicesData);
        const hasChanges = previousInvoicesData !== currentInvoicesData;

        if (hasChanges) {
          // Polling detected changes - refreshing UI
          saveInvoicesToLocalStorage();
          if (currentSection === 'services') {
            renderInvoiceList(
              currentServiceFilter,
              serviceCustomDateRange?.start,
              serviceCustomDateRange?.end
            );
          } else {
            renderInvoiceList(currentFilter, customDateRange?.start, customDateRange?.end);
          }
          renderInvoiceTabs(); // Tabs sẽ hiển thị với currentInvoiceIndex không đổi
          await renderCurrentInvoice();
          // Polling refresh completed
        } else {
          // Polling: No changes detected
        }
      } catch (error) {
        console.error('❌ Polling error:', error);
      }
    }, 30000); // Polling mỗi 30 giây
  }

  // --- Invoice Rendering & Display ---
  function renderInvoiceTabs() {
    // ✅ SIMPLIFIED: Luôn rebuild visibleInvoices từ invoices local trước khi render
    // Không cần phụ thuộc vào renderInvoiceList() nữa
    rebuildVisibleInvoices();

    // Ensure active invoice index is visible before rendering
    synchronizeActiveInvoiceWithVisible();
    // Helper: ensure the active invoice index points to an invoice in the current visibleInvoices
    // synchronizeActiveInvoiceWithVisible is handled globally; call it here to ensure active index is visible
    if (!elements.invoiceTabs) {
      return;
    }

    const maxTabs = window.innerWidth <= 768 ? 3 : 5; // Mobile: 3 tabs, Desktop: 5 tabs
    elements.invoiceTabs.innerHTML = '';

    // Đảm bảo currentInvoiceIndex hợp lệ
    if (
      currentInvoiceIndex < 0 ||
      currentInvoiceIndex >= invoices.length ||
      !invoices[currentInvoiceIndex]
    ) {
      currentInvoiceIndex = invoices.length > 0 ? invoices.length - 1 : 0;
    }

    // 🎯 SẮP XẾP THỨ TỰ HIỂN THỊ TABS
    // Logic: Tab active → Hóa đơn mới nhất → Hóa đơn cũ hơn
    const currentInvoice = invoices[currentInvoiceIndex];

    // Sắp xếp invoices theo created_at giảm dần (mới nhất trước) - use visibleInvoices to reflect filter
    const sortedInvoices = [...visibleInvoices].sort((a, b) => {
      const dateA = new Date(a.created_at || 0).getTime();
      const dateB = new Date(b.created_at || 0).getTime();
      return dateB - dateA;
    });

    // Tạo danh sách hiển thị - giữ nguyên thứ tự sortedInvoices, không push currentInvoice lên đầu.
    const displayOrder = sortedInvoices;

    // Xác định invoices hiển thị trên thanh tabs
    let visibleTabs = displayOrder;

    if (!showAllTabs && displayOrder.length > maxTabs) {
      // Lấy maxTabs đầu tiên từ displayOrder
      visibleTabs = displayOrder.slice(0, maxTabs);
    }

    const activeInvoice = invoices[currentInvoiceIndex];

    // Nếu chọn từ modal 'Xem thêm', đảm bảo activeInvoice được chèn vào visibleTabs
    if (isFromMoreTab) {
      // Nếu active chưa có trong visibleTabs, loại bỏ phần tử cuối cùng để nhường chỗ
      const alreadyIncluded = visibleTabs.some((inv) => {
        const a = inv.invoice_id || inv.id;
        const b = activeInvoice.invoice_id || activeInvoice.id;
        return a && b && a === b;
      });
      if (!alreadyIncluded) {
        if (visibleTabs.length >= maxTabs) visibleTabs.pop();
        visibleTabs.push(activeInvoice);
      }
    }

    // Render các tab trong visibleTabs theo thứ tự
    visibleTabs.forEach((invoice) => {
      // Sync tên khách và status từ DB (KHÔNG load ảnh để tránh lag)
      if (invoice.invoice_id) {
        const dbInvoice = invoicesData.find((inv) => inv.invoice_id === invoice.invoice_id);
        if (dbInvoice) {
          // Sync status và tên khách (không sync ảnh)
          invoice.status = dbInvoice.status;
          if (!invoice.customer || !invoice.customer.name) {
            invoice.customer = {
              name: dbInvoice.customer_name || 'Khách vãng lai',
              phone: dbInvoice.customer_phone || '',
              id: dbInvoice.customer_id || null,
            };
          }
        }
      }

      // Tìm index chính xác trong mảng invoices gốc (nếu có)
      const invoiceIdentifier = invoice.invoice_id || invoice.id;
      const originalIndex = invoices.findIndex(
        (inv) =>
          (inv.invoice_id && inv.invoice_id === invoiceIdentifier) ||
          (inv.id && inv.id === invoiceIdentifier)
      );

      const tab = document.createElement('div');
      // If we have an index, mark active by comparing indexes; otherwise compare by identifier
      const isActive =
        originalIndex !== -1
          ? originalIndex === currentInvoiceIndex
          : invoices[currentInvoiceIndex] &&
            (invoices[currentInvoiceIndex].invoice_id || invoices[currentInvoiceIndex].id) ===
              invoiceIdentifier;
      tab.className = `invoice-tab ${isActive ? 'active' : ''}`;
      // Store invoice identifier and index (if exists). We'll resolve to index when user clicks.
      if (originalIndex !== -1) tab.dataset.index = originalIndex;
      if (invoiceIdentifier) tab.dataset.invoiceId = invoiceIdentifier;

      const customerName =
        invoice.customer && invoice.customer.name ? invoice.customer.name : 'Khách vãng lai';
      const statusDotColor = invoice.status === 'paid' ? 'bg-green-500' : 'bg-red-500';

      tab.innerHTML = `
            <span>${customerName}</span>
            <span class="ml-1.5 w-1.5 h-1.5 rounded-full ${statusDotColor}"></span>
            ${
              isAdmin
                ? `
                <button class="close-tab-btn">
                    <i class="fas fa-times"></i>
                </button>
            `
                : ''
            }
        `;

      tab.addEventListener('click', (e) => {
        if (!e.target.closest('.close-tab-btn')) {
          const currentInvoice = invoices[currentInvoiceIndex];
          const hasImportantData =
            currentInvoice.customer ||
            (currentInvoice.services && currentInvoice.services.length > 0);

          if (currentInvoice.isDirty && hasImportantData && !currentInvoice.invoice_id) {
            showWarning('Vui lòng lưu hoặc hủy hóa đơn trước khi chuyển tab!');
            return;
          }
          // Use invoiceId if present, otherwise use numeric index
          const idx = tab.dataset.index !== undefined ? parseInt(tab.dataset.index) : null;
          const invId = tab.dataset.invoiceId || null;
          if (invId) {
            switchToInvoiceByIdentifier(invId);
          } else if (idx !== null) {
            switchToInvoice(idx);
          }
        }
      });

      if (isAdmin) {
        const closeBtn = tab.querySelector('.close-tab-btn');
        if (closeBtn) {
          closeBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            closeInvoiceTab(originalIndex);
          });
        }
      }

      elements.invoiceTabs.appendChild(tab);
    });

    // Thêm nút "Thêm hóa đơn"
    const addTabButton = document.createElement('button');
    addTabButton.id = 'addInvoiceTab';
    addTabButton.innerHTML = '<i class="fas fa-plus"></i>';
    addTabButton.addEventListener('click', addNewInvoice);
    elements.invoiceTabs.appendChild(addTabButton);

    // ✅ Thêm nút "Xem thêm" dựa trên visibleInvoices (đã lọc)
    // 🔧 FIX: Không fallback sang invoices nếu visibleInvoices rỗng
    // Để đảm bảo empty state hiển thị đúng khi không có hóa đơn theo bộ lọc hiện tại
    if (visibleInvoices.length > maxTabs) {
      const moreTab = document.createElement('div');
      moreTab.className = 'invoice-tab invoice-tab-more';
      const hiddenCount = visibleInvoices.length - visibleTabs.length;
      moreTab.innerHTML = `
            <span><i class="fas fa-ellipsis-h"></i> ${
              hiddenCount > 0 ? `+${hiddenCount}` : 'Tất cả'
            }</span>
        `;
      moreTab.addEventListener('click', openAllInvoicesModal);
      elements.invoiceTabs.appendChild(moreTab);
    }

    // Cuộn đến tab active và đồng bộ trạng thái
    scrollToInvoiceTab(currentInvoiceIndex);
    synchronizeActiveInvoiceWithVisible();
    isFromMoreTab = false;
  }

  function scrollToInvoiceTab(index) {
    setTimeout(() => {
      const tab = document.querySelector(`.invoice-tab[data-index="${index}"]`);
      if (tab && elements.invoiceTabs) {
        // ⚠️ KHÔNG dùng scrollIntoView: khi thợ đang thao tác ở cuối trang,
        // nó kéo CẢ TRANG lên khu tab/thông tin khách. Chỉ cuộn NGANG
        // bên trong thanh tab, tuyệt đối không đụng cuộn dọc của trang.
        const container = elements.invoiceTabs;
        const targetLeft = tab.offsetLeft - container.offsetLeft;
        container.scrollTo({ left: targetLeft, behavior: 'smooth' });
      }
    }, 200); // Tăng timeout để đảm bảo DOM render
  }

  function switchToInvoice(index) {
    if (index < 0 || index >= invoices.length) {
      return;
    }

    // If selection comes from the "Xem thêm" modal, mark to render it specially
    if (selectedFromMore) {
      currentInvoiceIndex = index;
      isFromMoreTab = true;
      selectedFromMore = false;
    } else {
      // Normal activation: keep invoices order unchanged
      currentInvoiceIndex = index;
      isFromMoreTab = false;
    }

    showAllTabs = false;

    // ⚡ OPTIMIZED: Render UI first, save to localStorage in background
    renderInvoiceTabs();
    scrollToInvoiceTab(currentInvoiceIndex);
    renderCurrentInvoice();

    // 💾 Save to localStorage asynchronously (không block UI)
    setTimeout(() => saveInvoicesToLocalStorage(), 0);
  }

  // Switch to invoice by invoice_id or id (keeps behavior when tab was rendered from visibleInvoices)
  function switchToInvoiceByIdentifier(identifier) {
    if (!identifier) return;
    const idx = invoices.findIndex(
      (inv) => inv.invoice_id === identifier || String(inv.id) === String(identifier)
    );
    if (idx !== -1) {
      switchToInvoice(idx);
    } else {
      // If not found in invoices list, try to find in invoicesData and reload to make it available
      const dbIdx = invoicesData.findIndex((inv) => inv.invoice_id === identifier);
      if (dbIdx !== -1) {
        // If found in invoicesData but not yet in invoices array, merge it into invoices
        const dbInv = invoicesData[dbIdx];
        const existing = invoices.find((inv) => inv.invoice_id === dbInv.invoice_id);
        if (!existing) {
          const invoiceData = {
            id: invoices.length + 1,
            invoice_id: dbInv.invoice_id,
            customer: {
              name: dbInv.customer_name || 'Khách hàng vãng lai',
              phone: dbInv.customer_phone || '',
              id: dbInv.customer_id || null,
              membership: dbInv.membership_label || 'Khách thường',
              promoCode: dbInv.promo_code || null,
            },
            status: dbInv.status,
            subtotal: parseFloat(dbInv.subtotal) || 0,
            discount: parseFloat(dbInv.discount) || 0,
            tips: parseFloat(dbInv.tips) || 0,
            total: parseFloat(dbInv.total) || 0,
            services: (dbInv.services || []).map((s) => ({
              service_id: s.service_id || null,
              service_name: s.service_name || 'Dịch vụ không xác định',
              price: parseFloat(s.price) || 0,
              staff_id: s.staff_id || null,
              staff_name: s.staff_name || 'Thợ không xác định',
              type: s.type || 'service',
              quantity: s.quantity || 1,
            })),
            images: dbInv.images || [],
            notImage: dbInv.not_image || [],
            paymentMethod: dbInv.payment_method || null,
            promoName: dbInv.promo_name || null,
            discountType: dbInv.discount_type || 'percent',
            created_at: dbInv.created_at,
            created_user: dbInv.created_user || 'Unknown',
            booking_id: dbInv.booking_id || null,
            promo_code: dbInv.promo_code || null,
            promo_status: dbInv.promo_status || null,
            membership_label: dbInv.membership_label || 'Khách thường',
            isFromDB: true,
            isManualPromo: !!dbInv.promo_name,
          };

          invoices.push(invoiceData);
        }

        // Now switch to it
        const newIdx = invoices.findIndex(
          (inv) => inv.invoice_id === identifier || String(inv.id) === String(identifier)
        );
        if (newIdx !== -1) {
          switchToInvoice(newIdx);
        } else {
        }
      } else {
      }
    }
  }

  // ✅ Helper: Rút gọn tên khách hàng
  function formatShortCustomerName(fullName) {
    if (!fullName || fullName === 'Khách vãng lai') return fullName;

    const words = fullName.trim().split(/\s+/);

    if (words.length >= 4) {
      // 4+ chữ: Ẩn 2 chữ đầu, hiển thị 2 chữ cuối (Hồ Lê Minh Tuấn → Minh Tuấn)
      return words.slice(-2).join(' ');
    } else if (words.length === 3) {
      // 3 chữ: Ẩn 1 chữ đầu, hiển thị 2 chữ cuối (Hồ Minh Tuấn → Minh Tuấn)
      return words.slice(-2).join(' ');
    } else {
      // 2 chữ trở xuống: Hiển thị đầy đủ (Minh Tuấn → Minh Tuấn)
      return fullName;
    }
  }

  // ✅ Helper: Format mã hóa đơn từ yymmddxxx thành HD...ddxyz
  function formatShortInvoiceId(invoiceId) {
    if (!invoiceId || invoiceId === 'N/A') return invoiceId;

    const idStr = invoiceId.toString();

    // Format: YYMMDDXXX (ví dụ: 241126001)
    // YY = năm (0-1), MM = tháng (2-3), DD = ngày (4-5), XXX = số thứ tự (6-8)
    if (idStr.length >= 9) {
      const dd = idStr.substring(2, 4); // Lấy ngày (vị trí 4-5)
      const xyz = idStr.slice(-3); // Lấy 3 số cuối
      return `HD...${dd}${xyz}`;
    }

    return invoiceId; // Giữ nguyên nếu format không đúng
  }

  function openAllInvoicesModal() {
    const modalContent = document.createElement('div');
    modalContent.className = 'modal-all-tabs';

    // ✅ SỬ DỤNG visibleInvoices để tôn trọng bộ lọc hiện tại
    // 🔧 FIX: Không fallback sang invoices nếu visibleInvoices rỗng
    // Điều này đảm bảo modal hiển thị đúng empty state theo filter
    const invoicesToShow = visibleInvoices;

    // Reset to first page when opening modal
    modalCurrentPage = 1;

    modalContent.innerHTML = `
        <div class="modal-all-tabs-content">
            <div class="modal-header">
                <h3 class="modal-all-tabs-title">Tất cả hóa đơn (${invoicesToShow.length})</h3>
                <button id="closeAllInvoicesModal" class="modal-all-tabs-close">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-search-wrapper">
                <input
                    type="text"
                    id="searchInvoiceModal"
                    placeholder="🔍 Tìm theo tên khách, SĐT, ID hóa đơn..."
                    class="modal-search-input"
                />
            </div>
            <div id="allInvoicesList" class="modal-all-tabs-list"></div>
            <div class="modal-pagination" id="modalPagination"></div>
        </div>
    `;

    document.body.appendChild(modalContent);

    const allInvoicesList = modalContent.querySelector('#allInvoicesList');
    const searchInput = modalContent.querySelector('#searchInvoiceModal');
    const paginationDiv = modalContent.querySelector('#modalPagination');

    // ✅ Sắp xếp theo created_at giảm dần (chỉ invoices đã lọc)
    const sortedInvoices = [...invoicesToShow].sort(
      (a, b) => new Date(b.created_at || 0) - new Date(a.created_at || 0)
    );

    // Find newest invoice's original index in the invoices array (for modal default highlight)
    let newestOriginalIndex = -1;
    if (sortedInvoices.length > 0) {
      const newestIdentifier = sortedInvoices[0].invoice_id || sortedInvoices[0].id;
      newestOriginalIndex = invoices.findIndex(
        (inv) => (inv.invoice_id || inv.id) === newestIdentifier
      );
    }

    // If we're not on the invoices section, make the main UI switch to the newest invoice
    // so the tabs reflect the same default shown in the modal.
    if (currentSection !== 'invoices' && newestOriginalIndex !== -1) {
      currentInvoiceIndex = newestOriginalIndex;
      try {
        localStorage.setItem('currentInvoiceIndex', String(currentInvoiceIndex));
      } catch (e) {}
      // Re-render tabs and current invoice to reflect change
      try {
        renderInvoiceTabs();
        renderCurrentInvoice();
      } catch (e) {}
    }

    // Function to render paginated invoices
    const renderModalInvoices = (invoicesToRender, page = 1) => {
      allInvoicesList.innerHTML = '';

      if (!invoicesToRender || invoicesToRender.length === 0) {
        allInvoicesList.innerHTML = `
          <div class="modal-empty-state">
            <i class="fas fa-inbox text-5xl text-gray-400 mb-4"></i>
            <p class="text-gray-600">Không có hóa đơn nào</p>
          </div>
        `;
        paginationDiv.innerHTML = '';
        return;
      }

      // Calculate pagination
      const totalItems = invoicesToRender.length;
      const totalPages = Math.ceil(totalItems / modalItemsPerPage);
      const startIndex = (page - 1) * modalItemsPerPage;
      const endIndex = Math.min(startIndex + modalItemsPerPage, totalItems);
      const pageItems = invoicesToRender.slice(startIndex, endIndex);

      if (pageItems.length === 0) {
        allInvoicesList.innerHTML = `
          <div class="modal-empty-state">
            <i class="fas fa-search text-5xl text-gray-400 mb-4"></i>
            <p class="text-gray-600">Không tìm thấy hóa đơn nào</p>
          </div>
        `;
        paginationDiv.innerHTML = '';
        return;
      }

      pageItems.forEach((invoice, index) => {
        // ✅ Tìm invoice từ local invoices[] để lấy data mới nhất (sau upload)
        const localInvoice = invoices.find((inv) => inv.invoice_id === invoice.invoice_id);

        // ✅ Đồng bộ dữ liệu từ invoicesData (bao gồm cả tên khách)
        if (invoice.invoice_id) {
          const dbInvoice = invoicesData.find((inv) => inv.invoice_id === invoice.invoice_id);
          if (dbInvoice) {
            // Đồng bộ tên khách từ DB
            if (dbInvoice.customer_name && (!invoice.customer || !invoice.customer.name)) {
              invoice.customer = invoice.customer || {};
              invoice.customer.name = dbInvoice.customer_name;
            }
            // ✅ Ưu tiên images từ local invoice (mới upload) > DB > rỗng
            const localImages = localInvoice?.images || [];
            const dbImages = safeParseJSON(dbInvoice.images, []);
            invoice.images = localImages.length > 0 ? localImages : dbImages || [];
            invoice.not_image = Array.isArray(dbInvoice.not_image)
              ? ''
              : dbInvoice.not_image || invoice.not_image || '';
            saveInvoicesToLocalStorage();
          }
        }

        // Tính chỉ số thực trong danh sách gốc
        const originalIndex = invoices.findIndex((inv) => inv.invoice_id === invoice.invoice_id);

        const invoiceItem = document.createElement('div');
        const isActiveForModal =
          currentSection === 'invoices'
            ? originalIndex === currentInvoiceIndex
            : originalIndex === newestOriginalIndex;
        invoiceItem.className = `modal-all-tabs-item ${isActiveForModal ? 'active' : ''}`;
        invoiceItem.dataset.index = originalIndex;

        // ✅ Lấy tên khách và format
        const fullCustomerName = invoice.customer?.name || 'Khách vãng lai';
        const shortCustomerName = formatShortCustomerName(fullCustomerName);

        // ✅ Format mã hóa đơn
        const fullInvoiceId = invoice.invoice_id || 'N/A';
        const shortInvoiceId = formatShortInvoiceId(fullInvoiceId);

        const hasImages = invoice.images && invoice.images.length > 0;
        const notImageReason = !hasImages ? invoice.not_image || 'Chưa up' : '';

        // ✅ Hiển thị tên rút gọn và mã HD
        invoiceItem.innerHTML = `
            <span>${shortCustomerName} (${shortInvoiceId})</span>
            ${hasImages ? `<i class="fas fa-check-circle has-image-icon"></i>` : ''}
            ${
              !hasImages && notImageReason
                ? `<span class="not-image-reason">${notImageReason}</span>`
                : ''
            }
        `;

        invoiceItem.addEventListener('click', () => {
          // Mark that selection comes from the "Xem thêm" modal so render will show it left of +
          selectedFromMore = true;
          switchToInvoice(originalIndex);
          modalContent.remove();
        });

        allInvoicesList.appendChild(invoiceItem);
      });

      // Render pagination controls
      if (totalPages > 1) {
        const paginationHTML = `
          <div class="pagination-controls">
            <button class="pagination-btn" ${page === 1 ? 'disabled' : ''} data-page="${page - 1}">
              <i class="fas fa-chevron-left"></i>
            </button>
            <span class="pagination-info">Trang ${page} / ${totalPages} (${
              startIndex + 1
            }-${endIndex} / ${totalItems})</span>
            <button class="pagination-btn" ${page === totalPages ? 'disabled' : ''} data-page="${
              page + 1
            }">
              <i class="fas fa-chevron-right"></i>
            </button>
          </div>
        `;
        paginationDiv.innerHTML = paginationHTML;

        // Add click handlers for pagination buttons
        paginationDiv.querySelectorAll('.pagination-btn').forEach((btn) => {
          btn.addEventListener('click', (e) => {
            const newPage = parseInt(e.currentTarget.dataset.page);
            if (newPage >= 1 && newPage <= totalPages) {
              modalCurrentPage = newPage;
              renderModalInvoices(invoicesToRender, newPage);
            }
          });
        });
      } else {
        paginationDiv.innerHTML = `<div class="pagination-info">Hiển thị ${totalItems} hóa đơn</div>`;
      }
    };

    // Initial render
    renderModalInvoices(sortedInvoices, modalCurrentPage);

    // Thêm chức năng tìm kiếm
    const renderFilteredInvoices = (searchTerm, keepPage = false) => {
      const filtered = sortedInvoices.filter((invoice) => {
        const customerName = (invoice.customer?.name || 'Khách vãng lai').toLowerCase();
        const customerPhone = invoice.customer?.phone || '';
        const invoiceId = (invoice.invoice_id || '').toString().toLowerCase();
        const search = searchTerm.toLowerCase();

        return (
          customerName.includes(search) ||
          customerPhone.includes(search) ||
          invoiceId.includes(search)
        );
      });

      // Reset to first page when searching (giữ trang khi refresh realtime)
      if (!keepPage) {
        modalCurrentPage = 1;
      }
      renderModalInvoices(filtered, modalCurrentPage);
    };

    // Search input handler
    searchInput.addEventListener('input', (e) => {
      renderFilteredInvoices(e.target.value);
    });

    // 🔄 Realtime: thợ upload xong ảnh → trạng thái "Chưa up"/✓ tự cập nhật,
    // không cần đóng mở lại modal. Listener tự gỡ khi modal đã bị remove.
    const handleImagesUpdated = () => {
      if (!document.body.contains(modalContent)) {
        document.removeEventListener('checkin:invoice-images-updated', handleImagesUpdated);
        return;
      }
      renderFilteredInvoices(searchInput.value || '', true);
    };
    document.addEventListener('checkin:invoice-images-updated', handleImagesUpdated);

    const closeBtn = modalContent.querySelector('#closeAllInvoicesModal');
    closeBtn.addEventListener('click', () => {
      modalContent.remove();
    });

    // Close on backdrop click
    modalContent.addEventListener('click', (e) => {
      if (e.target === modalContent) {
        modalContent.remove();
      }
    });

    // Close on ESC key
    const handleEsc = (e) => {
      if (e.key === 'Escape') {
        modalContent.remove();
        document.removeEventListener('keydown', handleEsc);
      }
    };
    document.addEventListener('keydown', handleEsc);
  }

  // 🔧 Helper: Hiển thị empty state với message tùy chỉnh
  function showInvoiceEmptyState(message, subMessage = '') {
    const emptyStateDiv = document.getElementById('servicesEmptyState');
    const invoiceContent = document.getElementById('invoiceContent');

    if (emptyStateDiv) {
      emptyStateDiv.classList.remove('hidden');
      const titleEl = emptyStateDiv.querySelector('.empty-state-title');
      const textEl = emptyStateDiv.querySelector('.empty-state-text');
      if (titleEl) titleEl.textContent = message;
      if (textEl)
        textEl.innerHTML =
          subMessage ||
          'Vui lòng click nút <strong>+</strong> ở thanh tab phía trên để tạo hóa đơn mới';
    }
    if (invoiceContent) invoiceContent.classList.add('hidden');
  }

  // 🔧 Helper: Clear tất cả UI liên quan đến invoice
  function clearInvoiceUI() {
    elements.customerPhone.value = '';
    elements.customerInfo.classList.add('hidden');
    if (elements.customerName) elements.customerName.innerHTML = '';
    if (elements.customerDob) elements.customerDob.textContent = '';
    if (elements.customerLastVisit) elements.customerLastVisit.textContent = '';
    if (elements.customerHairdresser) elements.customerHairdresser.textContent = '';
    if (elements.customerNotImage) elements.customerNotImage.textContent = '';
    if (elements.promoCode) elements.promoCode.textContent = '';
    if (elements.customerMembershipTag) elements.customerMembershipTag.innerHTML = '';

    elements.selectedServices.innerHTML = '';
    elements.subtotalAmount.textContent = formatCurrency(0);
    elements.totalAmount.textContent = formatCurrency(0);
    elements.discountAmount.value = '0';
    elements.tipsAmount.value = '0';
    elements.promoListSelect.value = '';

    elements.createInvoiceBtn.classList.add('hidden');
    if (elements.payInvoiceBtn) elements.payInvoiceBtn.classList.add('hidden');
    if (elements.reviewInvoiceBtn) elements.reviewInvoiceBtn.classList.add('hidden');

    const invoiceInfoContainer = elements.invoiceContent?.querySelector('.invoice-info');
    if (invoiceInfoContainer) invoiceInfoContainer.innerHTML = '';
  }

  async function renderCurrentInvoice() {
    const funcStart = performance.now();
    perfLog.mark('🎨 START renderCurrentInvoice');
    if (!elements.customerPhone || !elements.customerInfo) return;

    // ✅ Check branch selection
    if (!currentBranch) {
      showInvoiceEmptyState(
        'Chưa chọn chi nhánh',
        'Vui lòng chọn chi nhánh hoặc bấm <strong>Tìm tự động</strong> trước khi tạo hóa đơn'
      );
      return;
    }

    // ✅ Không có invoice nào trong mảng
    if (invoices.length === 0 || !invoices[currentInvoiceIndex]) {
      showInvoiceEmptyState('Chưa có hóa đơn nào');
      clearInvoiceUI();
      return;
    }

    // 🔧 FIX: Không có hóa đơn nào theo filter hiện tại
    if (visibleInvoices.length === 0) {
      const filterLabels = {
        today: 'hôm nay',
        yesterday: 'hôm qua',
        '7days': '7 ngày qua',
        thisMonth: 'tháng này',
        lastMonth: 'tháng trước',
        custom: 'khoảng thời gian đã chọn',
      };
      const filterLabel = filterLabels[currentFilter] || currentFilter;
      showInvoiceEmptyState(
        `Không có hóa đơn nào ${filterLabel}`,
        'Hãy tạo hóa đơn mới hoặc chọn bộ lọc khác'
      );
      clearInvoiceUI();
      return;
    }

    // ✅ Có invoices → Ẩn empty state và hiện invoiceContent
    const emptyStateDiv = document.getElementById('servicesEmptyState');
    const invoiceContent = document.getElementById('invoiceContent');

    if (emptyStateDiv) emptyStateDiv.classList.add('hidden');
    if (invoiceContent) invoiceContent.classList.remove('hidden');

    const invoice = invoices[currentInvoiceIndex];

    // 📊 STEP 1: Sync critical data from invoicesData (status, images, etc.)
    if (invoice.invoice_id && !invoice.isDirty) {
      const dbInvoice = invoicesData.find((inv) => inv.invoice_id === invoice.invoice_id);
      if (dbInvoice) {
        // Sync invoice status and images only
        invoice.status = dbInvoice.status;
        invoice.images = dbInvoice.images || [];
        invoice.notImage = Array.isArray(dbInvoice.not_image) ? dbInvoice.not_image : [];
        // ✅ Sync payment method và combined details từ DB
        invoice.paymentMethod = dbInvoice.payment_method || invoice.paymentMethod;
        invoice.combinedPaymentDetails =
          dbInvoice.combined_payment_details || invoice.combinedPaymentDetails;
        // ✅ customer.photos KHÔNG ĐỘNG VÀO - đã được set khi search hoặc upload
      }
    }

    // 🎭 STEP 2: Update customer info and form fields (synchronous - fast!)
    updateCustomerInfo(invoice);

    if (elements.paymentMethodSelect) {
      elements.paymentMethodSelect.value = invoice.paymentMethod || '';
    }

    // 💳 Hiển thị combined payment section nếu payment method là combined
    const combinedSection = document.getElementById('combinedPaymentDetailsSection');
    if (combinedSection) {
      if (invoice.paymentMethod === 'combined') {
        combinedSection.classList.remove('hidden');
        const cashInput = document.getElementById('combinedCashInline');
        const bankInput = document.getElementById('combinedBankInline');
        // Load giá trị từ combinedPaymentDetails nếu có
        if (invoice.combinedPaymentDetails) {
          const details =
            typeof invoice.combinedPaymentDetails === 'string'
              ? JSON.parse(invoice.combinedPaymentDetails)
              : invoice.combinedPaymentDetails;
          if (cashInput) cashInput.value = formatNumberInput(String(details.cash || 0));
          if (bankInput) bankInput.value = formatNumberInput(String(details.bank || 0));
        } else {
          // Khởi tạo mặc định 50-50
          const total = invoice.total || 0;
          if (cashInput) cashInput.value = formatNumberInput(String(Math.floor(total / 2)));
          if (bankInput) bankInput.value = formatNumberInput(String(total - Math.floor(total / 2)));
        }
      } else {
        combinedSection.classList.add('hidden');
      }
    }

    if (elements.tipsAmount) {
      elements.tipsAmount.value = formatNumberInput(String(invoice.tips));
    }

    setupReviewButton(invoice);

    // 📋 STEP 3: Render selected services/products immediately (from memory)
    renderSelectedServices();
    renderInvoiceInfo(invoice);

    // 💰 STEP 3.5: Display totals immediately (từ data có sẵn - nhanh!)
    displayInvoiceTotals();

    // 🎯 STEP 4: Refresh ALL UI states immediately (no race conditions!)
    refreshInvoiceUI(invoice);

    // ⚡ STEP 5: Load async data in background (không block UI render)
    Promise.all([
      updatePromoAndDiscount(invoice), // Chỉ update promo UI, không tính lại totals
      currentTab === 'services' ? loadServicesForGroup() : renderProductList(),
    ]).catch((err) => {
      console.error('Background data load error:', err);
    });

    perfLog.mark('✅ END renderCurrentInvoice');
  }

  function syncInvoiceWithDB(invoice) {
    if (!invoice.invoice_id || invoice.isDirty) {
      // Không đồng bộ nếu hóa đơn chưa tạo hoặc đang có thay đổi cục bộ
      return;
    }

    const dbInvoice = invoicesData.find((inv) => inv.invoice_id === invoice.invoice_id);
    if (dbInvoice && dbInvoice.services && dbInvoice.services.length > 0) {
      invoice.status = dbInvoice.status;
      invoice.subtotal = parseFloat(dbInvoice.subtotal) || invoice.subtotal;
      invoice.discount = parseFloat(dbInvoice.discount) || invoice.discount;
      invoice.tips = parseFloat(dbInvoice.tips) || invoice.tips;
      invoice.total = parseFloat(dbInvoice.total) || invoice.total;
      invoice.services = (dbInvoice.services || []).map((s) => ({
        service_id: s.service_id || null,
        service_name: s.service_name || 'Dịch vụ không xác định',
        price: parseFloat(s.price) || 0,
        staff_id: s.staff_id || null,
        staff_name: s.staff_name || 'Thợ không xác định',
        type: s.type || 'service',
        quantity: s.quantity || 1,
      }));
      // ✅ Chỉ sync invoice.images, customer.photos giữ nguyên
      invoice.images = dbInvoice.images || [];
      invoice.notImage = Array.isArray(dbInvoice.not_image) ? dbInvoice.not_image : [];
      invoice.booking_id = dbInvoice.booking_id;
      // Ưu tiên promo_name từ DB và giữ isManualPromo nếu có
      if (dbInvoice.promo_name) {
        invoice.promoName = dbInvoice.promo_name;
        invoice.isManualPromo = true;
      } else {
        invoice.promoName = null;
        invoice.isManualPromo = false;
      }
      invoice.discountType = dbInvoice.discount_type || invoice.discountType || 'fixed';
      invoice.isDirty = false; // Reset isDirty sau khi đồng bộ
      saveInvoicesToLocalStorage();
    } else if (dbInvoice) {
    } else {
    }
  }

  function updateCustomerInfo(invoice) {
    if (invoice.customer) {
      elements.customerPhone.value = invoice.customer.phone;

      // ✅ ALWAYS display customer from current invoice - không search lại
      const customerId = invoice.customer.id;

      // 🖼️ Ưu tiên hiển thị ảnh từ invoice.images (data từ DB) nếu có
      if (invoice.images && Array.isArray(invoice.images) && invoice.images.length > 0) {
        // Đã có ảnh từ DB trong invoice.customer.photos (được sync ở renderCurrentInvoice)
        displayCustomerInfo(invoice.customer);
        return;
      }

      // Nếu chưa có ảnh, thử sync từ localStorage
      if (customerId) {
        const syncedCustomer = syncCustomerFromLocalStorage(currentInvoiceIndex, customerId);
        if (syncedCustomer) {
          displayCustomerInfo(syncedCustomer);
          return;
        }
      }

      // Hiển thị thông tin khách hàng từ invoice hiện tại
      displayCustomerInfo(invoice.customer);
    } else {
      elements.customerPhone.value = '';
      elements.customerInfo.classList.add('hidden');
      if (elements.newCustomerForm) {
        elements.newCustomerForm.classList.add('hidden');
      }
    }
  }

  async function updatePromoAndDiscount(invoice) {
    const servicesData = getServicesFromLocalStorage() || [];

    let discountValue = 0;
    let discountType = invoice.discountType || 'fixed';

    // ✅ CHỈ giữ promoName nếu user đã chọn CTKM thủ công (isManualPromo)
    if (invoice.isManualPromo && invoice.promoName) {
      const ctkm = [...ctkmList, ...vouchers].find((c) => c.ctkm_name === invoice.promoName);
      if (ctkm) {
        discountValue = parseFloat(ctkm.value) || 0;
        discountType = 'fixed';
      } else {
        // Nếu CTKM không hợp lệ, reset về trạng thái tự động
        invoice.promoName = null;
        invoice.isManualPromo = false;
      }
    }

    // ✅ Nếu KHÔNG phải chọn thủ công → Luôn áp dụng logic tự động (kể cả isFromDB)
    if (!invoice.isManualPromo) {
      const {
        promoName,
        discountValue: calcDiscount,
        discountType: calcType,
      } = applyPromoLogic(invoice, servicesData, ctkmList, vouchers);
      invoice.promoName = promoName;
      discountValue = calcDiscount;
      discountType = calcType;
    }

    // Cập nhật UI - CHỈ HIỂN THỊ, không tính lại
    invoice.discountType = discountType;
    elements.discountType.value = discountType;
    elements.discountAmount.value = formatNumberInput(String(discountValue));
    elements.tipsAmount.value = formatNumberInput(String(invoice.tips || 0));

    // ✅ Load CTKM list và tự động set promoListSelect.value
    await loadPromoSettings(invoice);

    // ⚡ Chỉ display, không calculate (nhanh hơn!)
    displayInvoiceTotals();
  }
  function setupReviewButton(invoice) {
    const isCreated = !!invoice.invoice_id;
    const isPaid = invoice.status === 'paid';
    // ✅ Ẩn nút mời đánh giá nếu hóa đơn đã thanh toán hoặc đã gửi lời mời đánh giá
    if (elements.reviewInvoiceBtn && isCreated && !invoice.isReviewRequested && !isPaid) {
      elements.reviewInvoiceBtn.style.display = 'inline-block';
      elements.reviewInvoiceBtn.removeEventListener('click', elements.reviewInvoiceBtn._handler);
      const handler = () => {
        sendReviewNotification(invoice.invoice_id);
        elements.reviewInvoiceBtn.style.display = 'none';
      };
      elements.reviewInvoiceBtn._handler = handler;
      elements.reviewInvoiceBtn.addEventListener('click', handler);
    } else if (elements.reviewInvoiceBtn) {
      elements.reviewInvoiceBtn.style.display = 'none';
    }
  }

  /**
   * 🎯 UNIFIED UI REFRESH - Single source of truth for all invoice UI updates
   * This function handles ALL UI updates in correct order to prevent race conditions
   * @param {Object} invoice - The invoice object to render
   */
  function refreshInvoiceUI(invoice) {
    if (!invoice) return;

    // 📊 STEP 1: Determine invoice state (single source of truth)
    const isPaid = invoice.status === 'paid';
    const isCreated = !!invoice.invoice_id;
    const hasCustomer = !!invoice.customer;

    // 🎭 STEP 2: Setup button structure (visibility, text, classes)
    const payInvoiceBtn = document.getElementById('payInvoiceBtn');
    const reviewInvoiceBtn = document.getElementById('reviewInvoiceBtn');

    if (elements.createInvoiceBtn && payInvoiceBtn) {
      // Reset all classes
      elements.createInvoiceBtn.classList.remove(
        'disabled-btn',
        'center-btn',
        'block-btn',
        'hidden'
      );
      payInvoiceBtn.classList.remove(
        'disabled-btn',
        'center-btn',
        'block-btn',
        'hidden',
        'disabled-paid-btn',
        'block-btn-bg',
        'pay-invoice-btn'
      );
      if (reviewInvoiceBtn) reviewInvoiceBtn.classList.remove('hidden');

      if (isPaid) {
        // ✅ Đã thanh toán: Hiển thị nút "Đã thanh toán" (disabled)
        elements.createInvoiceBtn.classList.add('hidden');
        payInvoiceBtn.textContent = 'Đã thanh toán';
        payInvoiceBtn.classList.add('disabled-paid-btn', 'block-btn-bg');
        payInvoiceBtn.disabled = true;
        if (reviewInvoiceBtn) reviewInvoiceBtn.classList.add('hidden');
      } else if (isCreated) {
        // 📄 Đã tạo hóa đơn: Hiển thị "Thanh toán" + "Mời đánh giá"
        elements.createInvoiceBtn.classList.add('hidden');
        payInvoiceBtn.textContent = 'Thanh toán';
        payInvoiceBtn.classList.add('pay-invoice-btn');
        payInvoiceBtn.disabled = false;
        if (reviewInvoiceBtn) reviewInvoiceBtn.classList.remove('hidden');
      } else {
        // 🆕 Chưa tạo hóa đơn: Chỉ hiển thị "Tạo hóa đơn"
        elements.createInvoiceBtn.textContent = 'Tạo hóa đơn';
        elements.createInvoiceBtn.disabled = false;
        elements.createInvoiceBtn.classList.add('create-invoice-btn', 'center-btn-block');
        payInvoiceBtn.classList.add('hidden');
        if (reviewInvoiceBtn) reviewInvoiceBtn.classList.add('hidden');
      }
    }

    // 🔒 STEP 3: Apply disabled states to all form elements
    if (elements.customerPhone) elements.customerPhone.disabled = isPaid;
    if (elements.searchCustomerBtn) {
      elements.searchCustomerBtn.disabled = isPaid;
      elements.searchCustomerBtn.style.opacity = isPaid ? '0.5' : '1';
      elements.searchCustomerBtn.style.cursor = isPaid ? 'not-allowed' : 'pointer';
    }
    if (elements.scanQrBtn) {
      elements.scanQrBtn.disabled = isPaid;
      elements.scanQrBtn.style.opacity = isPaid ? '0.5' : '1';
      elements.scanQrBtn.style.cursor = isPaid ? 'not-allowed' : 'pointer';
    }
    if (elements.saveNewCustomerBtn) elements.saveNewCustomerBtn.disabled = isPaid;
    if (elements.discountAmount) elements.discountAmount.disabled = isPaid;
    if (elements.discountType) elements.discountType.disabled = isPaid;
    if (elements.promoListSelect) elements.promoListSelect.disabled = isPaid;
    if (elements.paymentMethodSelect) {
      elements.paymentMethodSelect.disabled = isPaid && !canViewAllInvoices();
    }
    if (reviewInvoiceBtn) reviewInvoiceBtn.disabled = isPaid;

    // 🔒 STEP 4: Lock/unlock service and product sections
    if (elements.serviceGroups) {
      elements.serviceGroups.style.pointerEvents = isPaid ? 'none' : 'auto';
      elements.serviceGroups.style.opacity = isPaid ? '0.5' : '1';
    }
    document.querySelectorAll('#serviceList').forEach((item) => {
      item.style.pointerEvents = isPaid ? 'none' : 'auto';
      item.style.opacity = isPaid ? '0.5' : '1';
    });
    document.querySelectorAll('#productList').forEach((item) => {
      item.style.pointerEvents = isPaid ? 'none' : 'auto';
      item.style.opacity = isPaid ? '0.5' : '1';
    });

    // 🔒 STEP 5: Lock/unlock service/product tabs
    const servicesTabsContainer = document.querySelector('.services-tabs');
    if (servicesTabsContainer) {
      servicesTabsContainer.style.pointerEvents = isPaid ? 'none' : 'auto';
      servicesTabsContainer.style.opacity = isPaid ? '0.5' : '1';
      servicesTabsContainer.style.filter = isPaid ? 'grayscale(50%)' : '';
    }
    const servicesTab = document.getElementById('servicesTab');
    const productsTab = document.getElementById('productsTab');
    [servicesTab, productsTab].forEach((tab) => {
      if (!tab) return;
      tab.style.pointerEvents = isPaid ? 'none' : 'auto';
      tab.style.cursor = isPaid ? 'not-allowed' : 'pointer';
      tab.disabled = isPaid;
    });

    // 🖼️ STEP 6: Update image upload buttons based on customer
    if (elements.uploadImageBtn) elements.uploadImageBtn.disabled = !hasCustomer;
    if (elements.uploadImageFeedbackBtn) elements.uploadImageFeedbackBtn.disabled = !hasCustomer;
    if (elements.notImageBtn) elements.notImageBtn.disabled = !hasCustomer;
  }

  function updateButtonStates(invoice) {
    if (elements.uploadImageBtn) {
      elements.uploadImageBtn.disabled = !invoice.customer;
    }
    if (elements.uploadImageFeedbackBtn) {
      elements.uploadImageFeedbackBtn.disabled = !invoice.customer;
    }
    if (elements.notImageBtn) {
      elements.notImageBtn.disabled = !invoice.customer;
    }
  }

  // ❌ DEPRECATED: updateUIState() replaced by refreshInvoiceUI()
  // Keeping for backwards compatibility if needed
  function updateUIState(invoice) {
    // This function is now handled by refreshInvoiceUI()
    // Keeping empty stub in case any code still calls it
    console.warn('updateUIState() is deprecated. Use refreshInvoiceUI() instead.');
  } // ❌ DEPRECATED: setupActionButtons() replaced by refreshInvoiceUI()
  // Keeping for backwards compatibility if needed
  function setupActionButtons(invoice) {
    // This function is now handled by refreshInvoiceUI()
    // Keeping empty stub in case any code still calls it
    console.warn('setupActionButtons() is deprecated. Use refreshInvoiceUI() instead.');
  }

  function renderInvoiceInfo(invoice) {
    const invoiceInfoContainer = elements.invoiceContent.querySelector('.invoice-info');
    if (!invoiceInfoContainer) {
      const newContainer = document.createElement('div');
      newContainer.className = 'invoice-info mb-6';
      elements.invoiceContent.insertBefore(newContainer, elements.invoiceContent.firstChild);
    }

    const date = invoice.created_at
      ? new Date(invoice.created_at).toLocaleString('vi-VN', {
          hour: '2-digit',
          minute: '2-digit',
          day: '2-digit',
          month: '2-digit',
          year: 'numeric',
        })
      : new Date().toLocaleString('vi-VN', {
          hour: '2-digit',
          minute: '2-digit',
          day: '2-digit',
          month: '2-digit',
          year: 'numeric',
        });

    elements.invoiceContent.querySelector('.invoice-info').innerHTML = `
            <h3 class="invoice-info-section">Thông tin hóa đơn</h3>
            <div class="info-invoice">
                <div class="invoice-info">Ngày tạo: ${date}</div>
                <div class="invoice-info">Mã hóa đơn: ${invoice.invoice_id || 'Chưa tạo'}</div>
                <div class="invoice-info">Người tạo: ${invoice.created_user || 'Unknown'}</div>
            </div>
        `;
  }

  function addNewInvoice() {
    // ✅ Check branch selection first
    if (!currentBranch) {
      toastError('Vui lòng chọn chi nhánh trước khi tạo hóa đơn!');
      return;
    }

    const newInvoice = createDefaultInvoice();
    newInvoice.isDirty = true; // Đánh dấu hóa đơn mới là đang chỉnh sửa
    newInvoice.created_at = new Date().toISOString(); // Set created_at để sắp xếp đúng

    invoices.push(newInvoice);
    currentInvoiceIndex = invoices.length - 1; // Chọn tab mới nhất
    showAllTabs = false; // Đảm bảo không hiển thị tất cả tab để ưu tiên tab mới

    // Cập nhật visibleInvoices nếu invoice mới match filter
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    let matches = false;
    if (currentFilter === 'today') {
      matches = new Date(newInvoice.created_at) >= today;
    } else if (currentFilter === 'thisMonth') {
      const start = new Date(now.getFullYear(), now.getMonth(), 1);
      matches = new Date(newInvoice.created_at) >= start;
    } else if (currentFilter === '7days') {
      const sevenDaysAgo = new Date(today);
      sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 6);
      matches = new Date(newInvoice.created_at) >= sevenDaysAgo;
    } else {
      matches = true; // cho các filter khác
    }
    if (matches) {
      visibleInvoices.push(newInvoice);
    }
    saveInvoicesToLocalStorage();
    renderInvoiceTabs(); // Render lại danh sách tab với thứ tự mới
    scrollToInvoiceTab(currentInvoiceIndex); // Cuộn đến tab mới
    renderCurrentInvoice(); // Hiển thị giao diện hóa đơn mới
  }

  async function closeInvoiceTab(index) {
    if (invoices.length <= 1) return;

    const invoice = invoices[index];

    // ✅ Nếu hóa đơn đã có invoice_id (lưu trong DB), hiển thị modal xác nhận
    if (invoice.invoice_id) {
      const customerName = invoice.customer?.name || 'Không xác định';
      const confirmed = await showConfirm(
        `Bạn có chắc muốn xóa hóa đơn của khách ${customerName}?`,
        'Xác nhận xóa'
      );

      if (!confirmed) return;

      try {
        await fetchAPI(`invoices/${invoice.invoice_id}`, { method: 'DELETE' });

        // 🔧 FIX: Track invoice đã bị xóa để tránh polling merge lại
        deletedInvoiceIds.add(invoice.invoice_id);

        // 🔧 FIX: Xóa khỏi invoices array TRƯỚC để UI update ngay lập tức
        invoices.splice(index, 1);

        // Xóa khỏi invoicesData (dữ liệu từ DB)
        const invoicesDataIndex = invoicesData.findIndex(
          (inv) => inv.invoice_id === invoice.invoice_id
        );
        if (invoicesDataIndex !== -1) {
          invoicesData.splice(invoicesDataIndex, 1);
        }

        clearDeletedInvoiceFromLocalStorage(invoice.invoice_id);

        // Điều chỉnh currentInvoiceIndex
        if (currentInvoiceIndex >= index) {
          currentInvoiceIndex = Math.max(0, currentInvoiceIndex - 1);
        }

        // 🔧 FIX: Rebuild visibleInvoices với filter đúng
        rebuildVisibleInvoices();

        // 🔧 FIX: Re-render UI NGAY LẬP TỨC trước khi refresh data
        renderInvoiceTabs();
        renderCurrentInvoice();
        saveInvoicesToLocalStorage();

        // ✅ Refresh data theo period hiện tại
        clearInvoicesDataCache();
        try {
          await reloadCurrentPeriodInvoices();
          if (currentSection === 'invoices') {
            renderInvoiceList();
          }
        } catch (e) {
          console.error('Failed to reload after deleting invoice:', e);
        }

        toastSuccess('Xóa hóa đơn thành công!');
      } catch (error) {
        await showError('Lỗi khi xóa hóa đơn khỏi cơ sở dữ liệu');
        return;
      }
      return; // 🔧 Early return để không chạy logic bên dưới
    }

    // 🔧 FIX: Logic này chỉ chạy cho tab chưa lưu DB (không có invoice_id)
    // Remove from invoices array
    invoices.splice(index, 1);

    // Điều chỉnh currentInvoiceIndex
    if (currentInvoiceIndex >= index) {
      currentInvoiceIndex = Math.max(0, currentInvoiceIndex - 1);
    }

    // 🔧 FIX: Rebuild visibleInvoices với filter đúng
    rebuildVisibleInvoices();

    // Re-render UI
    renderInvoiceTabs();
    renderCurrentInvoice();
    saveInvoicesToLocalStorage();
  }

  let isFetching = false; // Biến để ngăn gọi API đồng thời
  let currentFetchPromise = null; // Promise đang chạy để các caller có thể await

  // ⏱ Mốc thời gian hoá đơn: giờ TẠO (created_at) và giờ THANH TOÁN (paid_at).
  // paid_at chỉ set một lần khi hoá đơn chuyển sang 'paid', KHÔNG dùng updated_at.
  function formatInvoiceStamp(value) {
    if (!value) return null;
    const d = new Date(value);
    if (Number.isNaN(d.getTime())) return null;
    return {
      time: d.toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }),
      date: d.toLocaleDateString('vi-VN', { day: 'numeric', month: 'numeric', year: '2-digit' }),
    };
  }

  // Số phút từ lúc tạo đến lúc thanh toán; null nếu thiếu mốc hoặc âm (dữ liệu lệch)
  function formatInvoiceDuration(createdAt, paidAt) {
    if (!createdAt || !paidAt) return null;
    const a = new Date(createdAt).getTime();
    const b = new Date(paidAt).getTime();
    if (Number.isNaN(a) || Number.isNaN(b) || b < a) return null;
    const minutes = Math.round((b - a) / 60000);
    if (minutes < 1440) return `${minutes} phút`;
    const days = Math.floor(minutes / 1440);
    const restMin = minutes - days * 1440;
    return `${days} ngày ${Math.round(restMin / 60)}g`;
  }

  // Dải timeline 2 mốc dùng chung cho bảng desktop (xếp dọc) và card mobile (nằm ngang)
  function renderInvoiceTimeline(invoice) {
    const isPaid = invoice.status === 'paid';
    const created = formatInvoiceStamp(invoice.created_at);
    const paid = isPaid ? formatInvoiceStamp(invoice.paid_at) : null;
    const state = !isPaid ? 'pending' : paid ? 'paid' : 'unknown';
    const duration = paid ? formatInvoiceDuration(invoice.created_at, invoice.paid_at) : null;

    const node = (cls, icon, label, stamp, emptyText, title) => `
      <div class="inv-tl-node ${cls}" title="${title}">
        <span class="inv-tl-label"><i class="${icon}"></i>${label}</span>
        ${
          stamp
            ? `<span class="inv-tl-value">${stamp.time}<small>${stamp.date}</small></span>`
            : `<span class="inv-tl-value inv-tl-empty">${emptyText}</span>`
        }
      </div>`;

    const stampCreated = created
      ? `<div class="inv-stamp inv-stamp-created" title="Thời gian tạo hoá đơn"><b>${created.time}</b><small>${created.date}</small></div>`
      : `<div class="inv-stamp"><b class="inv-stamp-muted">-</b></div>`;
    let stampPaid;
    if (state === 'paid') {
      stampPaid = `<div class="inv-stamp inv-stamp-paid" data-state="paid" title="Thời gian thanh toán"><b>${
        paid.time
      }</b><small>${paid.date}${duration ? ` · ${duration}` : ''}</small></div>`;
    } else if (state === 'pending') {
      stampPaid = `<div class="inv-stamp inv-stamp-paid" data-state="pending" title="Chưa thanh toán"><b>Chưa</b></div>`;
    } else {
      stampPaid = `<div class="inv-stamp inv-stamp-paid" data-state="unknown"><b class="inv-stamp-muted">Không rõ</b></div>`;
    }

    const timeline = `<div class="inv-timeline" data-state="${state}">
      ${node('inv-tl-created', 'far fa-file-alt', 'Tạo', created, '-', 'Thời gian tạo hoá đơn')}
      <span class="inv-tl-line" title="Thời gian từ lúc tạo đến lúc thanh toán">${
        duration ? `<em class="inv-tl-dur"><i class="far fa-hourglass"></i>${duration}</em>` : ''
      }</span>
      ${node(
        'inv-tl-paid',
        isPaid ? 'far fa-check-circle' : 'far fa-hourglass',
        'Thanh toán',
        paid,
        isPaid ? 'Không rõ' : 'Chưa',
        isPaid ? 'Thời gian thanh toán' : 'Chưa thanh toán'
      )}
    </div>`;

    // Ô 1 (time-column): mốc tạo trên desktop + cả dải timeline cho card mobile.
    // Ô 2 (paid-time-column): mốc thanh toán trên desktop, ẩn trên mobile.
    return {
      createdCell: stampCreated + timeline,
      paidCell: stampPaid,
    };
  }

  async function renderInvoiceList(filter = currentFilter, startDate = null, endDate = null) {
    const funcStart = performance.now();
    perfLog.mark(`📋 START renderInvoiceList(${filter})`);
    if (!elements.invoicesListTabs) return;
    const tbody = elements.invoicesListTabs.querySelector('tbody');
    if (!tbody) return;

    // ✅ Check branch selection
    if (!currentBranch) {
      tbody.innerHTML = `
        <tr>
          <td colspan="19" class="text-center py-10 text-gray-500">
            <i class="fas fa-map-marker-alt text-4xl mb-4 text-red-400"></i>
            <p class="text-lg">Vui lòng chọn chi nhánh để xem danh sách hóa đơn.</p>
          </td>
        </tr>
      `;
      return;
    }

    tbody.innerHTML =
      '<tr><td colspan="19" class="text-center py-8"><i class="fas fa-spinner fa-spin"></i> Đang tải...</td></tr>';

    const invoicesPerPage = parseInt(localStorage.getItem('invoicesPerPage')) || 100;
    // Update select value when rendering
    const itemsPerPageSelect = document.getElementById('itemsPerPageSelect');
    if (itemsPerPageSelect) {
      itemsPerPageSelect.value = invoicesPerPage;
    }

    try {
      // ✅ REMOVED: isFetching check - render không cần block, chỉ API calls cần
      // isFetching được dùng trong loadStaffInvoices để prevent concurrent API calls

      // === LOẠI BỎ TRÙNG LẶP ===
      invoicesData = [...new Map(invoicesData.map((item) => [item.invoice_id, item])).values()];

      // === 🔧 FIX: LỌC THEO THỜI GIAN VỚI TIMEZONE VIỆT NAM ===
      // Hàm lấy YYYY-MM-DD của hóa đơn ở múi giờ VN (không include giờ/phút)
      const getInvoiceDateVN = (dateStr) => {
        try {
          const date = new Date(dateStr);
          const utc = date.getTime() + date.getTimezoneOffset() * 60000;
          const vnDate = new Date(utc + 7 * 3600000); // UTC+7
          return `${vnDate.getFullYear()}-${String(vnDate.getMonth() + 1).padStart(
            2,
            '0'
          )}-${String(vnDate.getDate()).padStart(2, '0')}`;
        } catch (e) {
          return '';
        }
      };

      const now = new Date();
      const utc = now.getTime() + now.getTimezoneOffset() * 60000;
      const vietnamNow = new Date(utc + 7 * 3600000);
      const todayVN = `${vietnamNow.getFullYear()}-${String(vietnamNow.getMonth() + 1).padStart(
        2,
        '0'
      )}-${String(vietnamNow.getDate()).padStart(2, '0')}`;

      const getYesterdayVN = () => {
        const yesterday = new Date(vietnamNow);
        yesterday.setDate(yesterday.getDate() - 1);
        return `${yesterday.getFullYear()}-${String(yesterday.getMonth() + 1).padStart(
          2,
          '0'
        )}-${String(yesterday.getDate()).padStart(2, '0')}`;
      };

      const getSevenDaysAgoVN = () => {
        const sevenDaysAgo = new Date(vietnamNow);
        sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 6);
        return `${sevenDaysAgo.getFullYear()}-${String(sevenDaysAgo.getMonth() + 1).padStart(
          2,
          '0'
        )}-${String(sevenDaysAgo.getDate()).padStart(2, '0')}`;
      };

      const getStartOfMonthVN = (baseDate) => {
        return `${baseDate.getFullYear()}-${String(baseDate.getMonth() + 1).padStart(2, '0')}-01`;
      };

      const getEndOfMonthVN = (baseDate) => {
        const nextMonth = new Date(baseDate);
        nextMonth.setMonth(nextMonth.getMonth() + 1);
        const lastDay = new Date(nextMonth.getFullYear(), nextMonth.getMonth(), 0);
        return `${lastDay.getFullYear()}-${String(lastDay.getMonth() + 1).padStart(
          2,
          '0'
        )}-${String(lastDay.getDate()).padStart(2, '0')}`;
      };

      let timeFiltered = invoicesData;

      if (filter === 'today') {
        timeFiltered = invoicesData.filter((inv) => {
          const invDateVN = getInvoiceDateVN(inv.created_at);
          return invDateVN === todayVN;
        });
      } else if (filter === 'yesterday') {
        const yesterdayVN = getYesterdayVN();
        timeFiltered = invoicesData.filter((inv) => {
          const invDateVN = getInvoiceDateVN(inv.created_at);
          return invDateVN === yesterdayVN;
        });
      } else if (filter === '7days') {
        const sevenDaysAgoVN = getSevenDaysAgoVN();
        timeFiltered = invoicesData.filter((inv) => {
          const invDateVN = getInvoiceDateVN(inv.created_at);
          return invDateVN >= sevenDaysAgoVN && invDateVN <= todayVN;
        });
      } else if (filter === 'thisMonth') {
        const startVN = getStartOfMonthVN(vietnamNow);
        const endVN = getEndOfMonthVN(vietnamNow);
        timeFiltered = invoicesData.filter((inv) => {
          const invDateVN = getInvoiceDateVN(inv.created_at);
          return invDateVN >= startVN && invDateVN <= endVN;
        });
      } else if (filter === 'lastMonth') {
        const lastMonthDate = new Date(vietnamNow);
        lastMonthDate.setMonth(lastMonthDate.getMonth() - 1);
        const startVN = getStartOfMonthVN(lastMonthDate);
        const endVN = getEndOfMonthVN(lastMonthDate);
        timeFiltered = invoicesData.filter((inv) => {
          const invDateVN = getInvoiceDateVN(inv.created_at);
          return invDateVN >= startVN && invDateVN <= endVN;
        });
      } else if (filter === 'custom') {
        const useStart = startDate || (customDateRange && customDateRange.start);
        const useEnd = endDate || (customDateRange && customDateRange.end);
        if (useStart && useEnd) {
          // Parse startDate/endDate từ input format YYYY-MM-DD
          const startVN = useStart.split('T')[0]; // Lấy phần YYYY-MM-DD
          const endVN = useEnd.split('T')[0];

          timeFiltered = invoicesData.filter((inv) => {
            const invDateVN = getInvoiceDateVN(inv.created_at);
            return invDateVN >= startVN && invDateVN <= endVN;
          });
        }
      } else {
      }

      // === LỌC TÌM KIẾM (sau thời gian) ===
      const staffFilter = document.getElementById('staffFilter')?.value.toLowerCase() || '';
      const invoiceIdFilter = document.getElementById('invoiceIdFilter')?.value.toLowerCase() || '';
      const paymentMethodFilter = document.getElementById('paymentMethodFilter')?.value || '';

      const filteredBySearch = timeFiltered.filter((invoice) => {
        const services = Array.isArray(invoice.services) ? invoice.services : [];

        const hasStaffMatch = staffFilter
          ? services.some((s) => s.staff_name?.toLowerCase().includes(staffFilter))
          : true;

        const hasInvoiceIdMatch = invoiceIdFilter
          ? invoice.invoice_id.toLowerCase().includes(invoiceIdFilter)
          : true;

        const hasPaymentMethodMatch = paymentMethodFilter
          ? invoice.payment_method === paymentMethodFilter
          : true;

        return hasStaffMatch && hasInvoiceIdMatch && hasPaymentMethodMatch;
      });

      // === SẮP XẾP ===
      const sortedInvoices = filteredBySearch.sort((a, b) => {
        if (a.status === 'pending' && b.status === 'paid') return -1;
        if (a.status === 'paid' && b.status === 'pending') return 1;
        return new Date(b.created_at) - new Date(a.created_at);
      });

      // === LỌC ĐÁNH GIÁ TRƯỚC KHI PHÂN TRANG ===
      const reviewTypeFilter = document.getElementById('reviewTypeFilter')?.value || '';
      const reviewRatingFilter = document.getElementById('reviewRatingFilter')?.value || '';

      let totalFiltered = sortedInvoices;
      if (reviewTypeFilter || reviewRatingFilter) {
        totalFiltered = sortedInvoices.filter((invoice) => {
          const review = invoice.reviews || { online: null, offline: null };
          const onlineRating = review.online?.service_rating;
          const offlineRating = review.offline?.service_rating;

          let hasReviewMatch = true;
          if (reviewTypeFilter && reviewRatingFilter) {
            const rating = reviewTypeFilter === 'online' ? onlineRating : offlineRating;
            hasReviewMatch = rating == reviewRatingFilter;
          } else if (reviewTypeFilter) {
            const rating = reviewTypeFilter === 'online' ? onlineRating : offlineRating;
            hasReviewMatch = rating !== undefined && rating !== null;
          } else if (reviewRatingFilter) {
            hasReviewMatch =
              onlineRating == reviewRatingFilter || offlineRating == reviewRatingFilter;
          }
          return hasReviewMatch;
        });
      }

      // === PHÂN TRANG ===
      const totalInvoices = totalFiltered.length;
      const totalPages = Math.ceil(totalInvoices / invoicesPerPage);
      if (currentPage < 1) currentPage = 1;
      if (currentPage > totalPages) currentPage = totalPages || 1;
      // ❌ Removed localStorage.setItem('currentInvoicePage') - không cần thiết

      const startIndex = (currentPage - 1) * invoicesPerPage;
      const endIndex = startIndex + invoicesPerPage;
      const paginatedInvoices = totalFiltered.slice(startIndex, endIndex);

      // === SỬ DỤNG REVIEW EMBEDDED TỪ API staff-invoices ===
      const reviewMap = {};
      paginatedInvoices.forEach((inv) => {
        reviewMap[inv.invoice_id] = inv.reviews || { online: null, offline: null };
      });

      // === KHÔNG CẦN LỌC ĐÁNH GIÁ NỮA VÌ ĐÃ LỌC TRƯỚC ===
      let finalFiltered = paginatedInvoices;

      // Add any unsaved (local) invoices that pass the same filter and search
      // These are in `invoices` array with isFromDB===false. We'll include them
      // only when they match the time filter OR when they are dirty (being edited).
      const unsavedLocal = invoices.filter((inv) => !inv.isFromDB);
      for (const localInv of unsavedLocal) {
        // Check if already included (merge by invoice_id or id)
        const exists = finalFiltered.some(
          (f) =>
            (f.invoice_id && localInv.invoice_id && f.invoice_id === localInv.invoice_id) ||
            (f.id && localInv.id && f.id === localInv.id)
        );
        if (exists) continue;

        // Determine if localInv matches the time filter - dùng format YYYY-MM-DD như timeFiltered
        let matchesTime = true;
        try {
          const localInvDateVN = getInvoiceDateVN(localInv.created_at);

          if (filter === 'today') {
            matchesTime = localInvDateVN === todayVN;
          } else if (filter === 'yesterday') {
            matchesTime = localInvDateVN === getYesterdayVN();
          } else if (filter === '7days') {
            const sevenDaysAgoVN = getSevenDaysAgoVN();
            matchesTime = localInvDateVN >= sevenDaysAgoVN && localInvDateVN <= todayVN;
          } else if (filter === 'thisMonth') {
            const startVN = getStartOfMonthVN(vietnamNow);
            const endVN = getEndOfMonthVN(vietnamNow);
            matchesTime = localInvDateVN >= startVN && localInvDateVN <= endVN;
          } else if (filter === 'lastMonth') {
            const lastMonthDate = new Date(vietnamNow);
            lastMonthDate.setMonth(lastMonthDate.getMonth() - 1);
            const startVN = getStartOfMonthVN(lastMonthDate);
            const endVN = getEndOfMonthVN(lastMonthDate);
            matchesTime = localInvDateVN >= startVN && localInvDateVN <= endVN;
          } else if (filter === 'custom') {
            const useStart = startDate || (customDateRange && customDateRange.start);
            const useEnd = endDate || (customDateRange && customDateRange.end);
            if (useStart && useEnd) {
              const startVN = useStart.split('T')[0];
              const endVN = useEnd.split('T')[0];
              matchesTime = localInvDateVN >= startVN && localInvDateVN <= endVN;
            }
          }
        } catch (e) {
          matchesTime = false;
        }

        // Only include local (unsaved) invoice when it matches the time filter
        if (matchesTime) {
          finalFiltered.push(localInv);
        }
      }

      // ✅ Keep visibleInvoices with ALL filtered invoices (not paginated) for modal "Xem thêm"
      // This includes both finalFiltered (paginated) + remaining from totalFiltered
      const allFilteredWithLocal = [...totalFiltered];
      // Add local invoices that match time filter (already in finalFiltered)
      unsavedLocal.forEach((localInv) => {
        const exists = allFilteredWithLocal.some(
          (f) =>
            (f.invoice_id && localInv.invoice_id && f.invoice_id === localInv.invoice_id) ||
            (f.id && localInv.id && f.id === localInv.id)
        );
        if (!exists) {
          // Check if it matches time (same logic as above)
          let matchesTime = true;
          try {
            const localInvDateVN = getInvoiceDateVN(localInv.created_at);
            if (filter === 'today') {
              matchesTime = localInvDateVN === todayVN;
            } else if (filter === 'yesterday') {
              matchesTime = localInvDateVN === getYesterdayVN();
            } else if (filter === '7days') {
              const sevenDaysAgoVN = getSevenDaysAgoVN();
              matchesTime = localInvDateVN >= sevenDaysAgoVN && localInvDateVN <= todayVN;
            } else if (filter === 'thisMonth') {
              const startVN = getStartOfMonthVN(vietnamNow);
              const endVN = getEndOfMonthVN(vietnamNow);
              matchesTime = localInvDateVN >= startVN && localInvDateVN <= endVN;
            } else if (filter === 'lastMonth') {
              const lastMonthDate = new Date(vietnamNow);
              lastMonthDate.setMonth(lastMonthDate.getMonth() - 1);
              const startVN = getStartOfMonthVN(lastMonthDate);
              const endVN = getEndOfMonthVN(lastMonthDate);
              matchesTime = localInvDateVN >= startVN && localInvDateVN <= endVN;
            } else if (filter === 'custom') {
              const useStart = startDate || (customDateRange && customDateRange.start);
              const useEnd = endDate || (customDateRange && customDateRange.end);
              if (useStart && useEnd) {
                const startVN = useStart.split('T')[0];
                const endVN = useEnd.split('T')[0];
                matchesTime = localInvDateVN >= startVN && localInvDateVN <= endVN;
              }
            }
          } catch (e) {
            matchesTime = false;
          }
          if (matchesTime) {
            allFilteredWithLocal.push(localInv);
          }
        }
      });

      visibleInvoices = allFilteredWithLocal;
      // If current active invoice is not in visibleInvoices, adjust active to first visible invoice
      synchronizeActiveInvoiceWithVisible();

      // ✅ OPTIMIZATION: Nếu đang ở màn hình Services (ẩn danh sách hóa đơn), không render DOM để tránh load ảnh
      if (currentSection === 'services') {
        return;
      }

      // === XÓA TẢI TRƯỚC KHI RENDER ===
      tbody.innerHTML = '';

      // === RENDER HÓA ĐƠN ===
      finalFiltered.forEach((invoice, index) => {
        const row = document.createElement('tr');
        row.className = 'cursor-pointer transition-colors';
        row.dataset.invoiceId = invoice.invoice_id;

        const statusClass = invoice.status === 'paid' ? 'status-paid' : 'status-pending';
        const paymentMethod = getPaymentMethodLabel(invoice);
        const messageType = invoice.message_type || 'Không có';
        const messageStatus = invoice.message_status || 'Không có';
        const timeCells = renderInvoiceTimeline(invoice);

        // ✅ Avatar lấy từ invoice.images của chính hóa đơn đó (theo bộ lọc)
        // Đây là ảnh được upload cùng với hóa đơn này
        const invoiceImages = Array.isArray(invoice.images)
          ? invoice.images.filter((url) => url && !url.includes('lego'))
          : [];
        const previewImage =
          invoiceImages.length > 0
            ? invoiceImages[0]
            : 'https://randomuser.me/api/portraits/lego/2.jpg';

        const services = Array.isArray(invoice.services) ? invoice.services : [];
        const serviceStaffDisplay =
          services.length > 0
            ? services
                .filter((s) => !s.is_penalty) // Filter out penalized services
                .map((s) => `${s.service_name || 'Dịch vụ'} - ${s.staff_name || 'Thợ'}`)
                .join('<br>')
            : 'Không có dịch vụ';

        const invoiceIdDisplay = invoice.booking_id
          ? `${invoice.invoice_id} <i class="fas fa-calendar-check text-blue-500" title="Có đặt lịch"></i>`
          : invoice.invoice_id;

        // Thêm icon tăng ca nếu hóa đơn có dịch vụ tăng ca
        const overtimeIcon = invoice.has_overtime
          ? `<i class="fas fa-clock text-red-500 ml-1" title="Tăng ca (từ 20:30)"></i>`
          : '';
        const finalInvoiceIdDisplay = invoiceIdDisplay + overtimeIcon;

        // 🎨 Hiệu ứng đánh dấu khách hàng Thành Viên và Promo
        let customerNameDisplay = '';
        if (invoice.customer_name) {
          const isMember = invoice.membership_label === 'Thành Viên';

          // Chỉ hiển thị badge cho Thành Viên
          if (isMember) {
            // Tạo tag promo dựa trên promo_code và promo_status
            let promoBadgeHTML = '';
            if (invoice.promo_code && invoice.promo_status) {
              const today = new Date();
              const isWeekend = today.getDay() === 0 || today.getDay() === 6;
              const promoStatusUpper = invoice.promo_status.toUpperCase();

              if (promoStatusUpper === 'CÓ HIỆU LỰC') {
                const badgeColor = isWeekend ? 'promo-badge-invalid' : 'promo-badge-valid';
                const tooltipText = isWeekend ? 'Không áp dụng cuối tuần' : 'Có mã KM';
                promoBadgeHTML = `<span class="promo-badge ${badgeColor}" title="${tooltipText}: ${invoice.promo_code}">
                  <i class="fas fa-ticket-alt"></i>
                </span>`;
              } else if (promoStatusUpper === 'HẾT HẠN SỬ DỤNG') {
                promoBadgeHTML = `<span class="promo-badge promo-badge-expired" title="Hết hạn: ${invoice.promo_code}">
                  <i class="fas fa-ticket-alt"></i>
                </span>`;
              }
            }

            customerNameDisplay = `
              <div class="flex justify-center items-center gap-2">
                <span class="customer-name-text">${invoice.customer_name}</span>
                <span class="membership-badge" title="Thành Viên">
                  <i class="fas fa-crown"></i>
                </span>
                ${promoBadgeHTML}
              </div>
            `;
          } else {
            customerNameDisplay = invoice.customer_name;
          }
        } else {
          customerNameDisplay = 'KHÁCH VÃNG LAI';
        }

        const deleteButton =
          checkinData.currentUser.user_role === 'administrator'
            ? `<button class="remove-invoice-btn text-red-400 hover:text-red-600 px-1.5 py-1" data-invoice-id="${invoice.invoice_id}"><i class="fas fa-trash"></i></button>`
            : '';

        const showResendButton =
          invoice.status === 'paid' &&
          invoice.message_status !== 'success' &&
          hasPermission('invoice.send_message');
        const resendButton = showResendButton
          ? `<button class="resend-zalo-btn text-blue-500 hover:text-blue-700 px-1.5 py-1" data-invoice-id="${invoice.invoice_id}" title="Gửi lại Zalo"><i class="fas fa-redo"></i></button>`
          : '';

        const hasPenalty =
          Array.isArray(invoice.services) && invoice.services.some((s) => s.is_penalty);
        const showTruyThuButton = invoice.status === 'paid' && hasPermission('invoice.penalty');
        const truyThuButton = showTruyThuButton
          ? `<button class="truy-thu-btn text-orange-500 hover:text-orange-700 px-1.5 py-1 ${
              hasPenalty ? 'has-penalty' : ''
            }" data-invoice-id="${
              invoice.invoice_id
            }" title="Truy thu phạt"><i class="fas fa-hand-holding-usd"></i></button>`
          : '';

        const review = reviewMap[invoice.invoice_id] || {};
        const onlineRating = review.online
          ? `DV: ${review.online.service_rating}⭐ | Thợ: ${review.online.staff_rating}⭐`
          : '-';
        const offlineRating = review.offline
          ? `DV: ${review.offline.service_rating}⭐ | Thợ: ${review.offline.staff_rating}⭐`
          : '-';

        row.innerHTML = `
                <td class="p-3 stt-column">${startIndex + index + 1}</td>
                <td class="p-3 image-column">
                    <img src="${previewImage}" loading="lazy" alt="Ảnh KH" class="w-5 h-5 object-cover rounded cursor-pointer invoice-image" data-images='${JSON.stringify(
                      invoiceImages
                    )}' />
                </td>
                <td class="p-3 customer-column">${customerNameDisplay}</td>
                <td class="p-3 invoice-id-column">${finalInvoiceIdDisplay}</td>
                <td class="p-3 services-column">
                    ${
                      services
                        .map((s) => {
                          const text = `${s.service_name || 'Dịch vụ'} - ${s.staff_name || 'Thợ'}`;
                          if (s.is_penalty) {
                            return `<span style="text-decoration: line-through; color: #999;">${text}</span>`;
                          }
                          return text;
                        })
                        .join('<br>') || 'Không có dịch vụ'
                    }
                </td>
                <td class="p-3 text-right subtotal-column">${formatCurrency(invoice.subtotal)}</td>
                <td class="p-3 text-right discount-column" data-has="${
                  (parseFloat(invoice.discount) || 0) > 0 ? 1 : 0
                }">${formatCurrency(invoice.discount)}</td>
                <td class="p-3 text-right tips-column" data-has="${
                  (parseFloat(invoice.tips) || 0) > 0 ? 1 : 0
                }">${formatCurrency(invoice.tips)}</td>
                <td class="p-3 text-right total-column font-medium text-green-600" data-has-discount="${
                  (parseFloat(invoice.discount) || 0) > 0 ? 1 : 0
                }" data-subtotal="${formatCurrency(invoice.subtotal)}">${formatCurrency(
                  invoice.total
                )}</td>
                <td class="p-3 status-column">
                    <span class="${statusClass}">${
                      invoice.status === 'paid' ? 'Đã thanh toán' : 'Đang phục vụ'
                    }</span>
                </td>
                <td class="p-3 payment-column" data-pm="${invoice.payment_method || ''}">${paymentMethod}</td>
                <td class="p-3 zns-column" data-mok="${
                  invoice.message_status === 'success' ? 1 : 0
                }" data-mtype="${invoice.message_type || ''}">${messageType}</td>
                <td class="p-3 result-column">${messageStatus}</td>
                <td class="p-3 time-column">${timeCells.createdCell}</td>
                <td class="p-3 paid-time-column">${timeCells.paidCell}</td>
                <td class="p-3 review-online-column text-center"><span class="font-medium text-yellow-600">${onlineRating}</span></td>
                <td class="p-3 review-offline-column text-center"><span class="font-medium text-green-600">${offlineRating}</span></td>
                <td class="p-3 reconcile-column text-center">${(() => {
                  if (invoice.payment_method !== 'bank') return '<span class="text-gray-300">-</span>';
                  const rs = (invoice.reconcile_status || 'pending').toLowerCase();
                  if (rs === 'matched') return '<span class="reconcile-badge reconcile-matched" title="Đã khớp: ' + (invoice.reconcile_tx_ref || '') + '"><i class="fas fa-check-circle"></i> Khớp</span>';
                  if (rs === 'unmatched') return '<span class="reconcile-badge reconcile-unmatched" title="Chưa khớp"><i class="fas fa-times-circle"></i> Lệch</span>';
                  return '<span class="reconcile-badge reconcile-pending" title="Chưa đối soát"><i class="far fa-circle"></i> Chờ</span>';
                })()}</td>
                <td class="p-3 actions-column">
                    <button class="review-invoice-list-btn text-purple-500 hover:text-purple-700 px-1.5 py-1" data-invoice-id="${
                      invoice.invoice_id
                    }" title="Mời đánh giá">
                        <i class="fas fa-star"></i>
                    </button>
                    ${resendButton}
                    ${deleteButton}
                    ${truyThuButton}
                </td>
                <td class="mobile-badges-cell">
                    <span class="mb-badge mb-pay" data-pm="${invoice.payment_method || ''}">${paymentMethod}</span>
                    ${
                      invoice.message_status === 'success' && invoice.message_type
                        ? `<span class="mb-badge mb-zns" data-mtype="${invoice.message_type}">${invoice.message_type}</span>`
                        : ''
                    }
                    ${
                      (parseFloat(invoice.discount) || 0) > 0
                        ? `<span class="mb-badge mb-discount"><i class="fas fa-tag"></i>Giảm ${formatCurrency(
                            invoice.discount
                          )}</span>`
                        : ''
                    }
                    ${
                      (parseFloat(invoice.tips) || 0) > 0
                        ? `<span class="mb-badge mb-tips">Tips +${formatCurrency(invoice.tips)}</span>`
                        : ''
                    }
                </td>
            `;

        row.addEventListener('click', async (e) => {
          const invoiceId = row.dataset.invoiceId;
          if (e.target.closest('.truy-thu-btn')) {
            e.stopPropagation();
            openTruyThuModal(invoiceId, invoice);
          } else if (e.target.closest('.review-invoice-list-btn')) {
            e.stopPropagation();
            sendReviewNotification(invoice.invoice_id);
          } else if (e.target.closest('.remove-invoice-btn')) {
            e.stopPropagation();
            deleteInvoiceFromDB(invoiceId);
          } else if (e.target.closest('.resend-zalo-btn')) {
            e.stopPropagation();
            resendZaloMessage(invoiceId);
          } else if (e.target.closest('.invoice-image')) {
            const images = JSON.parse(e.target.dataset.images || '[]');
            openImagePopup(images);
          } else {
            openInvoiceDetailModal(invoiceId);
          }
        });

        tbody.appendChild(row);
      });

      if (finalFiltered.length === 0) {
        tbody.innerHTML =
          '<tr><td colspan="19" class="text-center text-gray-500 py-6">Không có hóa đơn nào</td></tr>';
      }

      renderPagination(totalInvoices, totalPages, startIndex, endIndex);
      perfLog.mark(`✅ END renderInvoiceList(${filter}) - ${totalInvoices} invoices`);
    } catch (error) {
      perfLog.mark(`❌ ERROR renderInvoiceList(${filter})`);
      tbody.innerHTML =
        '<tr><td colspan="19" class="text-center text-red-500 py-6">Lỗi tải dữ liệu</td></tr>';
    }
    // ✅ REMOVED: finally block với isFetching = false
    // isFetching chỉ được quản lý bởi loadStaffInvoices

    // Áp dụng cài đặt hiển thị cột sau khi render
    applyInvoiceColumnVisibility();
    // 📱 Gắn nhãn cho chế độ card mobile
    annotateTableForMobileCards(elements.invoicesListTabs);
  }

  // ============================================
  // RECONCILE INVOICES (Đối soát hóa đơn)
  // ============================================
  // Mini toast helper for reconciliation — delegates to shared toast
  function _reconcileToast(msg, type = 'info') {
    showCheckinToast({ message: msg, type: type, duration: 3500 });
  }

  async function reconcileInvoices() {
    const btn = document.getElementById('reconcileBtn');
    if (!btn) return;

    const originalHTML = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Đang đối soát...';

    try {
      // Calculate date range from current filter (same logic as renderInvoiceList)
      const _now = new Date();
      const _utc = _now.getTime() + _now.getTimezoneOffset() * 60000;
      const vietnamNow = new Date(_utc + 7 * 3600000);
      const fmtDate = (d) =>
        d.getFullYear() +
        '-' +
        String(d.getMonth() + 1).padStart(2, '0') +
        '-' +
        String(d.getDate()).padStart(2, '0');

      let fromDate, toDate;
      const filter = currentFilter;

      if (filter === 'today') {
        fromDate = toDate = fmtDate(vietnamNow);
      } else if (filter === 'yesterday') {
        const yd = new Date(vietnamNow);
        yd.setDate(yd.getDate() - 1);
        fromDate = toDate = fmtDate(yd);
      } else if (filter === '7days') {
        const sd = new Date(vietnamNow);
        sd.setDate(sd.getDate() - 6);
        fromDate = fmtDate(sd);
        toDate = fmtDate(vietnamNow);
      } else if (filter === 'thisMonth') {
        fromDate =
          vietnamNow.getFullYear() +
          '-' +
          String(vietnamNow.getMonth() + 1).padStart(2, '0') +
          '-01';
        toDate = fmtDate(vietnamNow);
      } else if (filter === 'lastMonth') {
        const lm = new Date(vietnamNow);
        lm.setMonth(lm.getMonth() - 1);
        fromDate =
          lm.getFullYear() +
          '-' +
          String(lm.getMonth() + 1).padStart(2, '0') +
          '-01';
        const lastDay = new Date(lm.getFullYear(), lm.getMonth() + 1, 0);
        toDate = fmtDate(lastDay);
      } else if (filter === 'custom' && customDateRange?.start && customDateRange?.end) {
        fromDate = customDateRange.start.split('T')[0];
        toDate = customDateRange.end.split('T')[0];
      } else {
        // Default: last 7 days
        const sd = new Date(vietnamNow);
        sd.setDate(sd.getDate() - 6);
        fromDate = fmtDate(sd);
        toDate = fmtDate(vietnamNow);
      }

      // Backend handles everything: fetches invoices + bank transactions + matches
      const reconcileRes = await fetch(
        `${checkinData.restUrl}reconcile-invoices`,
        {
          method: 'POST',
          headers: {
            'X-WP-Nonce': checkinData.nonce,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            from_date: fromDate,
            to_date: toDate,
          }),
        }
      );

      if (!reconcileRes.ok) {
        const errData = await reconcileRes.json().catch(() => ({}));
        throw new Error(errData.message || `Reconcile API error: ${reconcileRes.status}`);
      }

      const result = await reconcileRes.json();

      // Update UI — backend returns { data: { invoices: [...] } }
      const invoiceResults = result.data?.invoices || [];
      if (Array.isArray(invoiceResults)) {
        invoiceResults.forEach((r) => {
          const inv = invoicesData.find((i) => i.invoice_id === r.invoice_id);
          if (inv) {
            inv.reconcile_status = r.reconcile_status;
            inv.reconcile_at = r.reconcile_at;
            inv.reconcile_tx_ref = r.reconcile_tx_ref || '';
          }
        });
      }

      // Re-render table with updated badges
      await renderInvoiceList(currentFilter);

      // Show result summary
      // matched = new matches this run, skipped = already matched before
      const matched = result.data?.matched || 0;
      const unmatched = result.data?.unmatched || 0;
      const skipped = result.data?.skipped || 0;
      const total = result.data?.total || 0;
      const totalMatched = matched + skipped; // skipped = previously matched
      let toastMsg = `Đối soát ${fromDate} → ${toDate}: ${totalMatched}/${total} đã khớp`;
      if (matched > 0) toastMsg += ` (${matched} mới)`;
      if (unmatched > 0) toastMsg += `, ${unmatched} chưa khớp`;
      toastMsg += '.';
      _reconcileToast(
        toastMsg,
        unmatched === 0 ? 'success' : 'warning'
      );
    } catch (error) {
      console.error('[Reconcile] Error:', error);
      _reconcileToast(`Lỗi đối soát: ${error.message}`, 'error');
    } finally {
      btn.disabled = false;
      btn.innerHTML = originalHTML;
    }
  }

  // Init nút đối soát
  function initReconcileButton() {
    const btn = document.getElementById('reconcileBtn');
    if (btn) {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        reconcileInvoices();
      });
    }
  }

  function renderPagination(totalInvoices, totalPages, startIndex, endIndex) {
    const container = document.getElementById('paginationContainer');
    if (!container) return;

    const info = container.querySelector('.pagination-info');
    info.textContent = `Hiển thị ${startIndex + 1} - ${Math.min(
      endIndex,
      totalInvoices
    )} / Tổng ${totalInvoices}`;

    const buttons = container.querySelector('.pagination-buttons');
    buttons.innerHTML = '';

    // Nút prev
    const prevBtn = document.createElement('button');
    prevBtn.className = 'pagination-btn';
    prevBtn.innerHTML = '&laquo;';
    prevBtn.disabled = currentPage === 1;
    prevBtn.dataset.page = 'prev';
    buttons.appendChild(prevBtn);

    // Trang
    for (let i = 1; i <= totalPages; i++) {
      if (totalPages > 7 && i > 2 && i < totalPages - 1 && Math.abs(i - currentPage) > 2) {
        if (i === 3 || i === totalPages - 2) {
          const dots = document.createElement('span');
          dots.textContent = '...';
          dots.style.padding = '0 0.5rem';
          buttons.appendChild(dots);
        }
        continue;
      }
      const btn = document.createElement('button');
      btn.className = 'pagination-btn' + (i === currentPage ? ' active' : '');
      btn.textContent = i;
      btn.dataset.page = i;
      buttons.appendChild(btn);
    }

    // Nút next
    const nextBtn = document.createElement('button');
    nextBtn.className = 'pagination-btn';
    nextBtn.innerHTML = '&raquo;';
    nextBtn.disabled = currentPage === totalPages;
    nextBtn.dataset.page = 'next';
    buttons.appendChild(nextBtn);

    // Sự kiện
    buttons.querySelectorAll('.pagination-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        const page = btn.dataset.page;
        if (page === 'prev') currentPage = Math.max(1, currentPage - 1);
        else if (page === 'next') currentPage = Math.min(totalPages, currentPage + 1);
        else currentPage = parseInt(page);
        renderInvoiceList();
      });
    });
  }

  function attachSearchListeners() {
    ['staffFilter', 'invoiceIdFilter'].forEach((id) => {
      const el = document.getElementById(id);
      if (el && !el.dataset.listener) {
        el.dataset.listener = 'true';
        el.addEventListener(
          'input',
          debounce(() => {
            currentPage = 1;
            renderInvoiceList(); // OK vì không phụ thuộc reviewMap
          }, 300)
        );
      }
    });

    // === PTTT: render ngay ===
    const paymentSelect = document.getElementById('paymentMethodFilter');
    if (paymentSelect && !paymentSelect.dataset.listener) {
      paymentSelect.dataset.listener = 'true';
      paymentSelect.addEventListener('change', () => {
        currentPage = 1;
        renderInvoiceList(); // OK
      });
    }

    // === REVIEW TYPE: chỉ hiện select sao, KHÔNG render ===
    const reviewTypeFilter = document.getElementById('reviewTypeFilter');
    if (reviewTypeFilter && !reviewTypeFilter.dataset.listener) {
      reviewTypeFilter.dataset.listener = 'true';
      reviewTypeFilter.addEventListener('change', function () {
        const ratingSelect = document.getElementById('reviewRatingFilter');
        if (this.value === 'online' || this.value === 'offline') {
          ratingSelect.classList.remove('hidden');
        } else {
          ratingSelect.classList.add('hidden');
          ratingSelect.value = '';
        }
        // KHÔNG GỌI renderInvoiceList() ở đây → chỉ render khi nhấn nút Lọc
      });
    }

    // === REVIEW RATING: không tự động render ===
    const reviewRatingFilter = document.getElementById('reviewRatingFilter');
    if (reviewRatingFilter && !reviewRatingFilter.dataset.listener) {
      reviewRatingFilter.dataset.listener = 'true';
      // Không cần addEventListener change vì sẽ dùng nút Lọc
    }

    // === NÚT LỌC ĐÁNH GIÁ ===
    const applyReviewFilterBtn = document.getElementById('applyReviewFilterBtn');
    if (applyReviewFilterBtn && !applyReviewFilterBtn.dataset.listener) {
      applyReviewFilterBtn.dataset.listener = 'true';
      applyReviewFilterBtn.addEventListener('click', () => {
        currentPage = 1;
        renderInvoiceList();
        showCheckinToast({ message: 'Đã áp dụng bộ lọc đánh giá', type: 'success' });
      });
    }

    // === NÚT RESET LỌC ĐÁNH GIÁ ===
    const resetReviewFilterBtn = document.getElementById('resetReviewFilterBtn');
    if (resetReviewFilterBtn && !resetReviewFilterBtn.dataset.listener) {
      resetReviewFilterBtn.dataset.listener = 'true';
      resetReviewFilterBtn.addEventListener('click', () => {
        const reviewTypeFilter = document.getElementById('reviewTypeFilter');
        const reviewRatingFilter = document.getElementById('reviewRatingFilter');

        if (reviewTypeFilter) {
          reviewTypeFilter.value = '';
        }
        if (reviewRatingFilter) {
          reviewRatingFilter.value = '';
          reviewRatingFilter.classList.add('hidden');
        }

        currentPage = 1;
        renderInvoiceList();
        showCheckinToast({ message: 'Đã đặt lại bộ lọc đánh giá', type: 'info' });
      });
    }

    // === ITEMS PER PAGE SELECT ===
    const itemsPerPageSelect = document.getElementById('itemsPerPageSelect');
    if (itemsPerPageSelect && !itemsPerPageSelect.dataset.listener) {
      itemsPerPageSelect.dataset.listener = 'true';
      // Set initial value from localStorage
      const savedItemsPerPage = localStorage.getItem('invoicesPerPage') || '25';
      itemsPerPageSelect.value = savedItemsPerPage;
      itemsPerPageSelect.addEventListener('change', () => {
        const selectedValue = parseInt(itemsPerPageSelect.value);
        localStorage.setItem('invoicesPerPage', selectedValue);
        currentPage = 1;
        renderInvoiceList();
        showCheckinToast({ message: 'Đã cập nhật số mục trên trang', type: 'success' });
      });
    }

    // === RECONCILE BUTTON (MonkeyPay Đối soát) ===
    if (typeof checkinData !== 'undefined' && checkinData.isMonkeyPayMode) {
      const reconcileBtn = document.getElementById('reconcileBtn');
      if (reconcileBtn) {
        reconcileBtn.style.display = '';
      }
      initReconcileButton();
    }
  }

  function updateFilterButtons() {
    document.querySelectorAll('.time-filter-btn').forEach((btn) => {
      if (btn.dataset.filter === currentFilter) {
        btn.classList.add('bg-blue-600', 'text-white');
        btn.classList.remove('bg-gray-100', 'text-gray-700');
      } else {
        btn.classList.remove('bg-blue-600', 'text-white');
        btn.classList.add('bg-gray-100', 'text-gray-700');
      }
    });
  }

  function updateTimeFilterButtons() {
    const quickDateFilter = document.getElementById('quickDateFilter');
    const customDateRangeContainer = document.getElementById('customDateRangeContainer');
    const customStartDate = document.getElementById('customStartDate');
    const customEndDate = document.getElementById('customEndDate');
    const applyCustomDate = document.getElementById('applyCustomDate');
    const reviewTypeFilter = document.getElementById('reviewTypeFilter');
    const reviewRatingFilter = document.getElementById('reviewRatingFilter');

    // === KHỞI TẠO ===
    const savedFilter = localStorage.getItem('currentFilter') || 'today';
    currentFilter = savedFilter;
    quickDateFilter.value = savedFilter;

    if (savedFilter === 'custom') {
      const start = localStorage.getItem('customStartDate');
      const end = localStorage.getItem('customEndDate');
      if (start && end) {
        customDateRange = { start, end };
        showCustomDateInputs(start, end);
      }
    }

    // === HIỂN THỊ/ẨN INPUT NGÀY ===
    function showCustomDateInputs(start = '', end = '') {
      customDateRangeContainer.classList.remove('hidden');
      customStartDate.value = start || new Date().toISOString().split('T')[0];
      customEndDate.value = end || new Date().toISOString().split('T')[0];
      setTimeout(() => customStartDate.focus(), 100);
    }

    function hideCustomDateInputs() {
      customDateRangeContainer.classList.add('hidden');
    }

    // === XỬ LÝ CHANGE ===
    quickDateFilter.addEventListener('change', async function () {
      const selectedValue = this.value;

      // Reset đánh giá
      if (reviewTypeFilter) reviewTypeFilter.value = '';
      if (reviewRatingFilter) {
        reviewRatingFilter.classList.add('hidden');
        reviewRatingFilter.value = '';
      }

      if (selectedValue === 'custom') {
        // HIỆN INPUT NGÀY
        showCustomDateInputs(customDateRange?.start, customDateRange?.end);
        return;
      }

      // CÁC FILTER KHÁC → ẨN INPUT + ÁP DỤNG
      hideCustomDateInputs();

      // ✅ OPTIMIZED: Logic load data thông minh - Giảm tải localStorage cho thiết bị cũ
      // - Mặc định load 7days để giảm dung lượng localStorage
      // - thisMonth/lastMonth: LUÔN show loading và load data mới vì data lớn
      // - today, yesterday, 7days: dùng data 7days đã có

      if (selectedValue === 'thisMonth') {
        // ✅ thisMonth: LUÔN show loading và load data mới (data lớn, cần load riêng)
        if (window.showPageLoader) {
          window.showPageLoader({
            text: 'Đang tải hóa đơn tháng này...',
            subtitle: 'Vui lòng đợi',
          });
        }
        try {
          await loadStaffInvoices('thisMonth');
          await applyFilter(selectedValue);
        } catch (error) {
          console.error('Error loading thisMonth:', error);
        } finally {
          await new Promise((resolve) => setTimeout(resolve, 100));
          if (window.hidePageLoader) {
            window.hidePageLoader(100);
          }
        }
      } else if (selectedValue === 'lastMonth') {
        // ✅ lastMonth: LUÔN show loading và load data mới
        if (window.showPageLoader) {
          window.showPageLoader({
            text: 'Đang tải hóa đơn tháng trước...',
            subtitle: 'Vui lòng đợi',
          });
        }
        try {
          await loadStaffInvoices('lastMonth');
          await applyFilter(selectedValue);
        } catch (error) {
          console.error('Error loading lastMonth:', error);
        } finally {
          await new Promise((resolve) => setTimeout(resolve, 100));
          if (window.hidePageLoader) {
            window.hidePageLoader(100);
          }
        }
      } else if (
        (selectedValue === 'today' || selectedValue === 'yesterday' || selectedValue === '7days') &&
        loadedDataPeriod !== '7days' &&
        loadedDataPeriod !== 'thisMonth' &&
        // ✅ FIX: Nếu đang có data 'today' mà chọn 'yesterday' hoặc '7days' → cần load 7days
        // Nếu đang có data 'yesterday' mà chọn filter khác → cũng cần load 7days
        !(loadedDataPeriod === 'today' && selectedValue === 'today') &&
        !(loadedDataPeriod === 'yesterday' && selectedValue === 'yesterday')
      ) {
        // ✅ Nếu đang có data lastMonth/custom/today/yesterday mà chọn filter khác → load lại 7days
        if (window.showPageLoader) {
          window.showPageLoader({ text: 'Đang tải hóa đơn...', subtitle: 'Vui lòng đợi' });
        }
        try {
          await loadStaffInvoices('7days');
          await applyFilter(selectedValue);
        } catch (error) {
          console.error('Error loading 7days:', error);
        } finally {
          await new Promise((resolve) => setTimeout(resolve, 100));
          if (window.hidePageLoader) {
            window.hidePageLoader(100);
          }
        }
      } else {
        // ✅ today/yesterday/7days với data 7days/thisMonth đã có → render trực tiếp, KHÔNG loading
        // Hoặc đang chọn cùng filter đã load (today→today, yesterday→yesterday)
        applyFilter(selectedValue);
      }
    });

    // === NÚT ÁP DỤNG ===
    applyCustomDate.onclick = async () => {
      const start = customStartDate.value;
      const end = customEndDate.value;
      if (start && end && start <= end) {
        // ✅ Kiểm tra xem custom range có nằm trong tháng này không
        // ✅ OPTIMIZED: Custom date range luôn load từ API để đảm bảo có đủ data
        // và giảm tải localStorage (không cần cache data lớn)
        if (window.showPageLoader) {
          window.showPageLoader({ text: 'Đang tải hóa đơn...', subtitle: 'Vui lòng đợi' });
        }
        try {
          await loadStaffInvoices('custom', start, end);
          await applyFilter('custom', start, end);
        } catch (error) {
          console.error('Error loading custom range:', error);
        } finally {
          await new Promise((resolve) => setTimeout(resolve, 100));
          if (window.hidePageLoader) {
            window.hidePageLoader(100);
          }
        }

        quickDateFilter.value = 'custom'; // giữ chọn custom
      } else {
        showWarning('Vui lòng chọn khoảng thời gian hợp lệ!');
      }
    };

    // === ÁP DỤNG FILTER ===
    // ✅ OPTIMIZED: Chỉ render lại, không gọi API
    // Data đã được sync bởi polling và các operations
    async function applyFilter(filterValue, start = null, end = null) {
      currentFilter = filterValue;
      localStorage.setItem('currentFilter', currentFilter);

      if (filterValue === 'custom') {
        customDateRange = { start, end };
        localStorage.setItem('customStartDate', start);
        localStorage.setItem('customEndDate', end);
      } else {
        customDateRange = null;
        localStorage.removeItem('customStartDate');
        localStorage.removeItem('customEndDate');
      }

      currentPage = 1;

      // ✅ MỚI: Chỉ render, không gọi API
      // invoicesData đã được sync bởi polling và các operations
      await renderInvoiceList(); // ✅ CRITICAL: Phải await để đợi render xong mới hide loading
    }

    // === NÚT LÀM MỚI DỮ LIỆU ===
    const refreshInvoicesBtn = document.getElementById('refreshInvoicesBtn');
    if (refreshInvoicesBtn) {
      refreshInvoicesBtn.addEventListener('click', async () => {
        setButtonLoading(refreshInvoicesBtn, 'Đang tải...');
        try {
          if (currentFilter === 'custom') {
            await loadStaffInvoices('custom', customDateRange?.start, customDateRange?.end);
          } else {
            await loadStaffInvoices(currentFilter);
          }
          renderInvoiceList();
          toastSuccess('Đã làm mới dữ liệu');
        } catch (e) {
          toastError('Lỗi khi làm mới dữ liệu');
        } finally {
          resetButtonLoading(refreshInvoicesBtn);
        }
      });
    }
  }

  async function resendZaloMessage(invoiceId) {
    const resendButton = document.querySelector(`.resend-zalo-btn[data-invoice-id="${invoiceId}"]`);
    if (resendButton) {
      resendButton.disabled = true; // Vô hiệu hóa nút khi đang xử lý
      resendButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i>'; // Hiển thị loading
    }

    try {
      const response = await fetchAPI('send-invoice-message-type-zalo', {
        method: 'POST',
        body: JSON.stringify({
          invoice_id: invoiceId,
        }),
      });

      if (response.success) {
        const invoiceIndex = invoicesData.findIndex((inv) => inv.invoice_id === invoiceId);
        if (invoiceIndex !== -1) {
          invoicesData[invoiceIndex].message_type = response.message_type || 'zalo_oa';
          invoicesData[invoiceIndex].message_status = response.message_status || 'success';
        }

        // 🔄 Cập nhật DOM realtime thay vì reload toàn bộ list
        const row = document.querySelector(`tr[data-invoice-id="${invoiceId}"]`);
        if (row) {
          const znsCell = row.querySelector('.zns-column');
          const resultCell = row.querySelector('.result-column');

          if (znsCell) znsCell.textContent = response.message_type || 'zalo_oa';
          if (resultCell) resultCell.textContent = response.message_status || 'success';
        }

        toastSuccess('Gửi lại tin nhắn Zalo thành công!');
      } else {
        // Cập nhật status = failed trong DOM
        const row = document.querySelector(`tr[data-invoice-id="${invoiceId}"]`);
        if (row) {
          const resultCell = row.querySelector('.result-column');
          if (resultCell) resultCell.textContent = 'failed';
        }

        showError('Lỗi khi gửi lại tin nhắn Zalo: ' + response.message);
      }
    } catch (error) {
      // Cập nhật status = failed trong DOM
      const row = document.querySelector(`tr[data-invoice-id="${invoiceId}"]`);
      if (row) {
        const resultCell = row.querySelector('.result-column');
        if (resultCell) resultCell.textContent = 'failed';
      }

      showError('Lỗi khi gửi lại tin nhắn Zalo');
    } finally {
      if (resendButton) {
        resendButton.disabled = false; // Kích hoạt lại nút
        resendButton.innerHTML = '<i class="fas fa-redo"></i>'; // Khôi phục icon
      }
    }
  }

  // Hàm debounce để tránh gọi API quá nhiều khi người dùng nhập liên tục
  function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
      const later = () => {
        clearTimeout(timeout);
        func(...args);
      };
      clearTimeout(timeout);
      timeout = setTimeout(later, wait);
    };
  }

  // ==============================
  // 12. Modal Functions
  // ==============================
  // === CẤU HÌNH CỘT ===
  const COLUMN_CONFIG = [
    { key: 'stt', label: 'STT', locked: true },
    { key: 'image', label: 'Ảnh', locked: true },
    { key: 'customer', label: 'Khách hàng', locked: true },
    { key: 'invoice_id', label: 'ID Hóa đơn', locked: true },
    { key: 'services', label: 'Dịch vụ & Thợ', locked: false },
    { key: 'subtotal', label: 'Tạm tính', locked: false },
    { key: 'discount', label: 'Giảm giá', locked: false },
    { key: 'tips', label: 'Tips', locked: false },
    { key: 'total', label: 'Thanh toán', locked: true },
    { key: 'status', label: 'Trạng thái', locked: true },
    { key: 'payment', label: 'Phương thức', locked: false },
    { key: 'zns', label: 'Zalo ZNS', locked: false },
    { key: 'result', label: 'Kết quả gửi', locked: false },
    { key: 'time', label: 'Tạo lúc', locked: true },
    { key: 'paid_time', label: 'Thanh toán lúc', locked: true },
    { key: 'review_online', label: 'Online', locked: false },
    { key: 'review_offline', label: 'Offline', locked: false },
    { key: 'reconcile', label: 'Đối soát', locked: false },
    { key: 'actions', label: 'Thao tác', locked: true },
  ];

  // === KHỞI TẠO MODAL CÀI ĐẶT BẢNG (DÙNG CHUNG) ===
  function initTableSettings() {
    // Cấu hình cho từng loại bảng
    const settingsConfigs = {
      invoice: {
        openBtnId: 'mkt192-open-table-settings',
        columnConfig: COLUMN_CONFIG,
        storageKey: 'mkt192_invoice_columns',
        applyVisibilityCallback: applyInvoiceColumnVisibility,
      },
      booking: {
        openBtnId: 'booking-table-settings-btn',
        columnConfig: BOOKING_COLUMN_CONFIG,
        storageKey: 'booking_columns',
        applyVisibilityCallback: applyBookingColumnVisibility,
      },
      inventory: {
        openBtnId: 'inventory-table-settings-btn',
        columnConfig: INVENTORY_COLUMN_CONFIG,
        storageKey: 'inventory_columns',
        applyVisibilityCallback: applyInventoryColumnVisibility,
      },
      transaction: {
        openBtnId: 'transaction-table-settings-btn',
        columnConfig: TRANSACTION_COLUMN_CONFIG,
        storageKey: 'transaction_columns',
        applyVisibilityCallback: applyTransactionColumnVisibility,
      },
    };

    const modal = document.getElementById('mkt192-table-settings-modal');
    const closeBtn = document.getElementById('mkt192-close-table-settings');
    const saveBtn = document.getElementById('mkt192-save-columns');
    const resetBtn = document.getElementById('mkt192-reset-columns');
    const container = document.getElementById('mkt192-column-toggles');

    if (!modal || !closeBtn || !saveBtn || !resetBtn || !container) {
      return;
    }

    let currentConfig = null;
    let saveHandler = null;
    let resetHandler = null;

    const openModal = (config) => {
      currentConfig = config;
      renderToggles();

      // Xóa các event listener cũ
      if (saveHandler) saveBtn.removeEventListener('click', saveHandler);
      if (resetHandler) resetBtn.removeEventListener('click', resetHandler);

      // Tạo và gắn các event listener mới
      saveHandler = () => saveColumnSettings();
      resetHandler = () => resetColumnSettings();
      saveBtn.addEventListener('click', saveHandler);
      resetBtn.addEventListener('click', resetHandler);

      modal.classList.add('show');
    };

    const closeModal = () => {
      modal.classList.remove('show');
      // Xóa event listener khi đóng để tránh rò rỉ bộ nhớ
      if (saveHandler) saveBtn.removeEventListener('click', saveHandler);
      if (resetHandler) resetBtn.removeEventListener('click', resetHandler);
      saveHandler = null;
      resetHandler = null;
    };

    closeBtn.onclick = closeModal;
    modal.onclick = (e) => {
      if (e.target === modal) closeModal();
    };

    Object.values(settingsConfigs).forEach((config) => {
      const openBtn = document.getElementById(config.openBtnId);
      if (openBtn) {
        openBtn.onclick = () => openModal(config);
      }
    });

    function renderToggles() {
      if (!currentConfig) return;
      const settings = JSON.parse(localStorage.getItem(currentConfig.storageKey) || '{}');
      container.innerHTML = currentConfig.columnConfig
        .map((col) => {
          const isChecked = col.locked ? true : settings[col.key] !== false;
          return `
            <div class="mkt192-toggle-item ${col.locked ? 'locked' : ''}">
                <span class="mkt192-toggle-label">${col.label}</span>
                <label class="mkt192-toggle-switch ${col.locked ? 'locked' : ''}">
                    <input type="checkbox" data-key="${col.key}"
                           ${isChecked ? 'checked' : ''}
                           ${col.locked ? 'disabled' : ''}>
                    <span class="mkt192-toggle-slider"></span>
                </label>
            </div>
        `;
        })
        .join('');
    }

    function saveColumnSettings() {
      if (!currentConfig) return;
      const settings = {};
      container.querySelectorAll('input[type="checkbox"]').forEach((input) => {
        const key = input.dataset.key;
        const col = currentConfig.columnConfig.find((c) => c.key === key);
        if (col && !col.locked) {
          settings[key] = input.checked;
        }
      });
      safeSetItem(currentConfig.storageKey, JSON.stringify(settings));
      showCheckinToast({ message: 'Đã lưu cài đặt cột!', type: 'success' });
      closeModal();
      if (currentConfig.applyVisibilityCallback) {
        currentConfig.applyVisibilityCallback();
      }
    }

    function resetColumnSettings() {
      if (!currentConfig) return;
      localStorage.removeItem(currentConfig.storageKey);
      renderToggles();
      showCheckinToast({ message: 'Đã đặt lại mặc định!', type: 'info' });
    }
  }

  // === ÁP DỤNG ẨN/HIỆN CỘT CHO HÓA ĐƠN ===
  function applyInvoiceColumnVisibility() {
    const settings = JSON.parse(localStorage.getItem('mkt192_invoice_columns') || '{}');
    const table = document.querySelector('#invoicesListTabs');
    if (!table) return;

    COLUMN_CONFIG.forEach((col, idx) => {
      const shouldShow = col.locked || settings[col.key] !== false;
      const cells = table.querySelectorAll(`th:nth-child(${idx + 1}), td:nth-child(${idx + 1})`);
      cells.forEach((cell) => {
        cell.style.display = shouldShow ? '' : 'none';
      });
    });
  }

  // Khởi tạo modal truy thu
  function initTruyThuModal() {
    const modal = document.getElementById('mkt192-truy-thu-modal');
    const closeBtn = document.getElementById('mkt192-close-truy-thu-modal');
    const cancelBtn = document.getElementById('mkt192-cancel-truy-thu');
    const saveBtn = document.getElementById('mkt192-save-truy-thu');
    const changeStaffToggle = document.getElementById('mkt192-change-staff-toggle');

    closeBtn.onclick = () => closeTruyThuModal();
    cancelBtn.onclick = () => closeTruyThuModal();
    saveBtn.onclick = () => handleSaveTruyThu();

    const changeStaffLabel = document.querySelector('label[for="mkt192-change-staff-toggle"]');
    if (changeStaffLabel) {
      changeStaffLabel.addEventListener('click', (e) => {
        // Ngăn hành vi mặc định của label để có thể tự quản lý checkbox
        e.preventDefault();

        const changeStaffToggle = document.getElementById('mkt192-change-staff-toggle');
        if (changeStaffToggle) {
          // Đảo ngược trạng thái checked của checkbox
          changeStaffToggle.checked = !changeStaffToggle.checked;

          // Gọi hàm để cập nhật UI với trạng thái mới
          toggleChangeStaffMode(changeStaffToggle.checked);
        }
      });
    }

    modal.addEventListener('click', (e) => {
      if (e.target === modal) closeTruyThuModal();
    });
  }

  function toggleChangeStaffMode(isChangeMode) {
    const modal = document.getElementById('mkt192-truy-thu-modal');
    modal.classList.toggle('change-staff-mode', isChangeMode);
    // Hide all dropdowns when toggling mode off
    if (!isChangeMode) {
      modal.querySelectorAll('.mkt192-staff-select-container').forEach((container) => {
        container.classList.add('hidden');
      });
    } else {
      // When toggling mode on, show dropdowns for checked checkboxes
      modal.querySelectorAll('.mkt192-service-item-wrapper').forEach((wrapper) => {
        const checkbox = wrapper.querySelector('.mkt192-truy-thu-checkbox');
        const selectContainer = wrapper.querySelector('.mkt192-staff-select-container');
        if (checkbox && checkbox.checked) {
          selectContainer.classList.remove('hidden');
        }
      });
    }
  }

  let currentTruyThuInvoice = null;
  let truyThuReasonPillSelect = null;

  async function openTruyThuModal(invoiceId, invoice) {
    currentTruyThuInvoice = invoice;

    const modal = document.getElementById('mkt192-truy-thu-modal');
    const invoiceIdEl = modal.querySelector('#mkt192-truy-thu-invoice-id');
    const serviceListEl = modal.querySelector('#mkt192-truy-thu-service-list');
    const changeStaffToggle = document.getElementById('mkt192-change-staff-toggle');

    // Reset UI
    if (changeStaffToggle) {
      changeStaffToggle.checked = false;
    }
    modal.classList.remove('change-staff-mode');
    invoiceIdEl.textContent = invoiceId;
    serviceListEl.innerHTML = '<p class="mkt192-no-data">Đang tải...</p>';
    modal.classList.add('show');

    // Initialize hoặc reset pill-select component
    if (!truyThuReasonPillSelect) {
      truyThuReasonPillSelect = initPillSelect('truy-thu-reason-pill-select', getTruyThuReasons(), {
        multiSelect: false,
        color: 'blue',
        placeholder: 'Chọn lý do truy thu...',
        onSelect: (value, label) => {},
      });
    } else {
      truyThuReasonPillSelect.reset();
    }

    // Fetch staff list
    let staffList = [];
    try {
      staffList = getStaffFromLocalStorage() || (await fetchAPI('staff'));
      if (!getStaffFromLocalStorage()) saveStaffToLocalStorage(staffList);
    } catch (error) {
      serviceListEl.innerHTML = '<p class="mkt192-no-data text-red-500">Lỗi tải danh sách thợ.</p>';
      return;
    }

    const activeStaff = staffList.filter(isWorkingStaff);
    const staffOptionsHtml =
      '<option value="">-- Chọn thợ --</option>' +
      activeStaff
        .map(
          (staff) =>
            `<option value="${staff.employee_id}" data-staff-name="${escapeHtml(
              staff.display_name
            )}">${escapeHtml(staff.display_name)}</option>`
        )
        .join('');

    const services = Array.isArray(invoice.services) ? invoice.services : [];

    if (services.length === 0) {
      serviceListEl.innerHTML = '<p class="mkt192-no-data">Không có dịch vụ nào.</p>';
    } else {
      serviceListEl.innerHTML = '';
      services.forEach((svc, idx) => {
        const isPenalty = svc.is_penalty === true || svc.is_penalty === '1';
        const item = document.createElement('div');
        item.className = 'mkt192-service-item-wrapper';
        item.innerHTML = `
            <div class="mkt192-service-item">
                <input type="checkbox" class="mkt192-truy-thu-checkbox" data-idx="${idx}" ${
                  isPenalty ? 'checked' : ''
                }>
                <div class="mkt192-service-info">
                    <div class="mkt192-service-name">${escapeHtml(
                      svc.service_name || 'Dịch vụ'
                    )}</div>
                    <div class="mkt192-staff-name">${escapeHtml(
                      svc.staff_name || 'Thợ không xác định'
                    )}</div>
                </div>
                <div class="mkt192-service-price">${formatCurrency(svc.price)}</div>
            </div>
            <div class="mkt192-staff-select-container hidden mt-2 ml-8">
                <select class="mkt192-staff-select w-full p-2 border rounded-md">
                    ${staffOptionsHtml}
                </select>
            </div>
            `;
        serviceListEl.appendChild(item);
      });

      // Attach event listeners
      serviceListEl.querySelectorAll('.mkt192-truy-thu-checkbox').forEach((checkbox) => {
        checkbox.addEventListener('change', (e) => {
          const isChangeMode = modal.classList.contains('change-staff-mode');
          if (isChangeMode) {
            const wrapper = e.target.closest('.mkt192-service-item-wrapper');
            const selectContainer = wrapper.querySelector('.mkt192-staff-select-container');
            selectContainer.classList.toggle('hidden', !e.target.checked);
          }
        });
      });

      // Nếu hóa đơn có dịch vụ đã bị truy thu, hiển thị lý do cũ
      const hasPenalizedService = services.some(
        (svc) => svc.is_penalty === true || svc.is_penalty === '1'
      );

      if (hasPenalizedService && truyThuReasonPillSelect) {
        const penalizedService = services.find(
          (svc) => svc.is_penalty === true || svc.is_penalty === '1'
        );

        if (penalizedService && penalizedService.penalty_reason) {
          // Sử dụng component API để set giá trị
          truyThuReasonPillSelect.setSelectedValues([penalizedService.penalty_reason]);
        }
      }
    }
  }

  function closeTruyThuModal() {
    document.getElementById('mkt192-truy-thu-modal').classList.remove('show');
  }

  async function handleSaveTruyThu() {
    // Kiểm tra validation cho lý do truy thu bắt buộc
    if (!truyThuReasonPillSelect) {
      return;
    }

    const selectedValues = truyThuReasonPillSelect.getSelectedValues();
    if (selectedValues.length === 0) {
      showCheckinToast({ message: 'Vui lòng chọn lý do truy thu!', type: 'warning' });
      return;
    }

    const isChangeMode = document
      .getElementById('mkt192-truy-thu-modal')
      .classList.contains('change-staff-mode');
    if (isChangeMode) {
      executeChangeStaff();
    } else {
      executePenalty();
    }
  }

  async function executePenalty() {
    const selectedServices = [];
    document
      .querySelectorAll('#mkt192-truy-thu-service-list .mkt192-truy-thu-checkbox:checked')
      .forEach((cb) => {
        const idx = cb.dataset.idx;
        const svc = currentTruyThuInvoice.services[idx];
        if (svc) {
          selectedServices.push({ service_name: svc.service_name, staff_name: svc.staff_name });
        }
      });

    if (selectedServices.length === 0) {
      showCheckinToast({ message: 'Vui lòng chọn ít nhất 1 dịch vụ!', type: 'warning' });
      return;
    }

    const invoiceId = currentTruyThuInvoice.invoice_id;
    const selectedReasons = truyThuReasonPillSelect.getSelectedValues();

    // Lấy nút submit và thêm loading state
    const submitBtn = document.getElementById('mkt192-save-truy-thu');
    if (!submitBtn) {
      return;
    }
    setButtonLoading(submitBtn, 'Đang xử lý...');

    try {
      const response = await fetchAPI(`invoices/${invoiceId}/penalty`, {
        method: 'PUT',
        body: JSON.stringify({
          services: selectedServices,
          reasons: selectedReasons,
        }),
      });

      if (response.success) {
        showCheckinToast({ message: 'Truy thu phạt thành công!', type: 'success' });
        closeTruyThuModal();
        renderInvoiceList();
      } else {
        throw new Error(response.message);
      }
    } catch (err) {
      showCheckinToast({ message: err.message || 'Lỗi không xác định', type: 'error' });
    } finally {
      // Khôi phục trạng thái nút
      resetButtonLoading(submitBtn);
    }
  }

  async function executeChangeStaff() {
    // ✅ CHO PHÉP truy thu ngay cả khi hóa đơn đã thanh toán
    const servicesToChange = [];
    let validationError = false;

    document
      .querySelectorAll('#mkt192-truy-thu-service-list .mkt192-service-item-wrapper')
      .forEach((wrapper) => {
        const checkbox = wrapper.querySelector('.mkt192-truy-thu-checkbox');
        if (checkbox && checkbox.checked) {
          const idx = checkbox.dataset.idx;
          const originalService = currentTruyThuInvoice.services[idx];
          const staffSelect = wrapper.querySelector('.mkt192-staff-select');
          const newStaffId = staffSelect.value;
          const selectedOption = staffSelect.options[staffSelect.selectedIndex];
          const newStaffName = selectedOption ? selectedOption.textContent.trim() : '';

          if (!newStaffId || newStaffId === '') {
            showCheckinToast({
              message: `Vui lòng chọn thợ mới cho dịch vụ: ${originalService.service_name}`,
              type: 'warning',
            });
            validationError = true;
            return;
          }

          servicesToChange.push({
            service_name: originalService.service_name,
            staff_name: originalService.staff_name,
            new_staff_id: newStaffId,
            new_staff_name: newStaffName,
          });
        }
      });

    if (validationError) return;

    if (servicesToChange.length === 0) {
      showCheckinToast({
        message: 'Vui lòng chọn ít nhất 1 dịch vụ để chuyển đổi!',
        type: 'warning',
      });
      return;
    }

    const invoiceId = currentTruyThuInvoice.invoice_id;

    // Lấy lý do truy thu đã chọn
    const reasonPillSelect = document.getElementById('truy-thu-reason-pill-select');
    const selectedPill = reasonPillSelect.querySelector('.mkt192-pill');
    const selectedReasonValue = selectedPill
      ? selectedPill.querySelector('.mkt192-pill-remove').dataset.value
      : null;
    const selectedReasons = selectedReasonValue ? [selectedReasonValue] : [];

    // Lấy nút submit và thêm loading state
    const submitBtn = document.getElementById('mkt192-save-truy-thu');
    if (!submitBtn) {
      return;
    } // Disable nút và hiển thị loading
    setButtonLoading(submitBtn, 'Đang xử lý...');

    try {
      const response = await fetchAPI(`invoices/${invoiceId}/change-staff`, {
        method: 'POST',
        body: JSON.stringify({
          services: servicesToChange,
          reasons: selectedReasons,
        }),
      });

      if (response.success) {
        showCheckinToast({
          message: response.message || 'Chuyển đổi thợ thành công!',
          type: 'success',
        });
        closeTruyThuModal();
        await loadStaffInvoices(
          currentFilter,
          localStorage.getItem('customStartDate'),
          localStorage.getItem('customEndDate')
        );
        renderInvoiceList();
      } else {
        throw new Error(response.message);
      }
    } catch (err) {
      showCheckinToast({ message: err.message || 'Lỗi không xác định', type: 'error' });
    } finally {
      // Khôi phục trạng thái nút
      resetButtonLoading(submitBtn);
    }
  }

  // Helper: escape HTML
  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  function openInvoiceDetailModal(invoiceId) {
    try {
      if (!elements.invoicesDetailContent) {
        return;
      }

      const invoice = invoicesData.find((inv) => inv.invoice_id === invoiceId);
      if (!invoice) {
        showError('Không tìm thấy hóa đơn');
        return;
      }

      const services = invoice.services || [];
      const images = invoice.images || [];
      const createdAt = new Date(invoice.created_at).toLocaleString('vi-VN', {
        dateStyle: 'medium',
        timeStyle: 'short',
      });
      // Giờ thanh toán lấy từ paid_at (set một lần khi chuyển 'paid'), không dùng updated_at
      let paidAtText = 'Chưa thanh toán';
      if (invoice.status === 'paid') {
        const paidDate = invoice.paid_at ? new Date(invoice.paid_at) : null;
        paidAtText =
          paidDate && !Number.isNaN(paidDate.getTime())
            ? paidDate.toLocaleString('vi-VN', { dateStyle: 'medium', timeStyle: 'short' })
            : 'Không rõ';
      }

      const renderModalContent = () => {
        const modalContent = `
                <div class="modal-overlay"></div>
                <div class="modal-container">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h3 id="invoiceModalTitle" class="modal-title">Hóa đơn #${
                              invoice.invoice_id
                            }</h3>
                            <button id="closeModalXBtn" class="close-btn">
                                <i class="fas fa-times text-lg"></i>
                            </button>
                        </div>
                        <div class="modal-section">
                            <div class="modal-grid">
                                <div>
                                    <p class="modal-text"><strong>Ngày tạo:</strong> ${createdAt}</p>
                                    <p class="modal-text"><strong>Thanh toán lúc:</strong> ${paidAtText}</p>
                                    <p class="modal-text"><strong>Khách hàng:</strong> ${
                                      invoice.customer_name
                                    }</p>
                                    <p class="modal-text"><strong>Số điện thoại:</strong> ${
                                      invoice.customer_phone
                                    }</p>
                                    <p class="modal-text flex items-center space-x-2">
                                        <span><strong>Mã KM:</strong> ${
                                          invoice.promo_code || 'Không có'
                                        }</span>
                                        <span>|</span>
                                        <span><strong>Hạng:</strong> ${
                                          invoice.membership_label || 'Khách thường'
                                        }</span>
                                    </p>
                                    <p class="modal-text"><strong>Hạn sử dụng:</strong> ${
                                      invoice.promo_status || 'Không có'
                                    }</p>
                                    <p class="modal-text"><strong>CTKM:</strong> ${
                                      invoice.promo_name || 'Không có'
                                    }</p>
                                </div>
                                <div>
                                    <p class="modal-text"><strong>Người tạo:</strong> ${
                                      invoice.created_user || 'Unknown'
                                    }</p>
                                    <p class="modal-text"><strong>Thu ngân:</strong> ${
                                      invoice.cashier || 'Chưa xác định'
                                    }</p>
                                    <p class="modal-text"><strong>Trạng thái:</strong>
                                        <span class="${
                                          invoice.status === 'paid'
                                            ? 'status-paid'
                                            : 'status-serving'
                                        }">
                                            ${
                                              invoice.status === 'paid'
                                                ? 'Đã thanh toán'
                                                : 'Đang phục vụ'
                                            }
                                        </span>
                                    </p>
                                    <p class="modal-text"><strong>Phương thức:</strong> ${getPaymentMethodLabel(
                                      invoice
                                    )}</p>
                                    <p class="modal-text"><strong>Loại tin nhắn:</strong> ${
                                      invoice.message_type || 'Không có'
                                    }</p>
                                    <p class="modal-text"><strong>Kết quả gửi:</strong> ${
                                      invoice.message_status || 'Không có'
                                    }</p>
                                </div>
                            </div>
                        </div>
                        <h4 class="section-title">Dịch vụ</h4>
                        <div class="modal-section">
                            ${
                              services.length > 0
                                ? services
                                    .map((s) => {
                                      const isPenalty = s.is_penalty === true || s.is_penalty === 1;
                                      const style = isPenalty
                                        ? 'style="text-decoration: line-through; color: #999;"'
                                        : '';
                                      return `
                                <div class="service-item" ${style}>
                                    <div>
                                        <div class="service-name">${s.service_name}</div>
                                        <div class="staff-name">Thợ: ${s.staff_name}</div>
                                    </div>
                                    <div class="service-price">${formatCurrency(s.price)}</div>
                                </div>
                            `;
                                    })
                                    .join('')
                                : '<p class="no-services">Không có dịch vụ</p>'
                            }
                        </div>
                        <h4 class="section-title">Thanh toán</h4>
                        <div class="modal-section">
                            <div class="payment-item">
                                <span class="payment-label">Tạm tính</span>
                                <span class="payment-value">${formatCurrency(
                                  invoice.subtotal
                                )}</span>
                            </div>
                            <div class="payment-item">
                                <span class="payment-label">Giảm giá ${
                                  invoice.discount_type === 'percent'
                                    ? `(${Math.round(
                                        (invoice.discount / invoice.subtotal) * 100
                                      )}%)`
                                    : ''
                                }</span>
                                <span class="payment-discount">-${formatCurrency(
                                  invoice.discount
                                )}</span>
                            </div>
                            <div class="payment-item">
                                <span class="payment-label">Tips</span>
                                <span class="payment-value">${formatCurrency(invoice.tips)}</span>
                            </div>
                            <div class="payment-item">
                                <span class="payment-total-label">Tổng cộng</span>
                                <span class="payment-total">${formatCurrency(invoice.total)}</span>
                            </div>
                        </div>
                        <h4 class="section-title">Hình ảnh</h4>
                        <div class="modal-section">
                            ${
                              images.length > 0
                                ? `
                                <div class="images-container">
                                    ${images
                                      .slice(0, 3)
                                      .map(
                                        (img) => `
                                        <div class="image-wrapper">
                                            <img src="${img}" alt="Invoice Image" class="invoice-image">
                                        </div>
                                    `
                                      )
                                      .join('')}
                                </div>
                            `
                                : `
                                <div class="no-images">
                                    <i class="fas fa-image no-images-icon"></i>
                                    <p class="no-services">Không có hình ảnh</p>
                                </div>
                            `
                            }
                        </div>
                        ${
                          invoice.status === 'paid'
                            ? `
                            <div class="actions-container">
                                <button id="uploadImageDetailBtn" class="action-btn upload-image-btn">Upload Image</button>
                                <button id="uploadFeedbackDetailBtn" class="action-btn upload-feedback-btn">Upload Feedback</button>
                                <button id="notImageDetailBtn" class="action-btn not-image-btn">Not Image</button>
                            </div>
                        `
                            : `
                            <div class="actions-container">
                                <button id="reviewInvoiceDetailBtn" class="action-btn review-btn">Mời đánh giá</button>
                                <button id="payInvoiceDetailBtn" class="action-btn pay-btn">Thanh toán</button>
                            </div>
                        `
                        }
                    </div>
                </div>
            `;

        elements.invoicesDetailContent.innerHTML = modalContent;
        openModal(elements.invoicesDetailContent);

        // Xử lý nút Upload Image
        const uploadImageDetailBtn = document.getElementById('uploadImageDetailBtn');
        if (uploadImageDetailBtn) {
          uploadImageDetailBtn.addEventListener('click', () => {
            openUploadImageModalInvoice(invoice, false);
          });
        }

        // Xử lý nút Upload Feedback
        const uploadFeedbackDetailBtn = document.getElementById('uploadFeedbackDetailBtn');
        if (uploadFeedbackDetailBtn) {
          uploadFeedbackDetailBtn.addEventListener('click', () => {
            openUploadImageModalInvoice(invoice, true);
          });
        }

        // Xử lý nút Not Image
        const notImageDetailBtn = document.getElementById('notImageDetailBtn');
        if (notImageDetailBtn) {
          notImageDetailBtn.addEventListener('click', () => {
            handleNotImageClick(invoice);
          });
        }

        // Xử lý nút thanh toán
        const payBtn = document.getElementById('payInvoiceDetailBtn');
        if (payBtn) {
          payBtn.addEventListener('click', () => {
            openPaymentMethodModal(invoice.invoice_id, true);
            closeModal(elements.invoicesDetailContent);
          });
        }

        // Xử lý nút mời đánh giá
        const reviewBtn = document.getElementById('reviewInvoiceDetailBtn');
        if (reviewBtn) {
          reviewBtn.addEventListener('click', () => {
            sendReviewNotification(invoice.invoice_id);
          });
        }

        // Xử lý đóng modal
        const closeXBtn = document.getElementById('closeModalXBtn');
        const modalOverlay = elements.invoicesDetailContent.querySelector('.modal-overlay');

        if (closeXBtn) {
          closeXBtn.addEventListener('click', () => closeModal(elements.invoicesDetailContent));
        }
        if (modalOverlay) {
          modalOverlay.addEventListener('click', () => closeModal(elements.invoicesDetailContent));
        }

        // Đóng bằng phím Esc
        document.addEventListener('keydown', function closeOnEsc(e) {
          if (e.key === 'Escape' && !elements.invoicesDetailContent.classList.contains('hidden')) {
            closeModal(elements.invoicesDetailContent);
            document.removeEventListener('keydown', closeOnEsc);
          }
        });
      };

      renderModalContent();
    } catch (error) {
      showError('Lỗi khi mở chi tiết hóa đơn');
    }
  }

  // ==============================
  // 13. Image Upload Functions - Modern Implementation
  // ==============================

  /**
   * 🔧 Compress image on client-side before upload
   */
  // ============================================================
  // 🚀 MODERN IMAGE UPLOAD - Optimized for iPhone
  // ============================================================
  // Strategy:
  // 1. Upload raw files PARALLEL (no compression = fast)
  // 2. Show instant preview with blob URLs
  // 3. Backend saves to temp + creates JSON metadata
  // 4. Cronjob processes in background (WebP conversion, DB update)
  // ============================================================

  /**
   * 🔧 Smart merge images: Giữ lại temp URLs và blob URLs từ local
   * @param {Array} localImages - Images từ local invoice
   * @param {Array} dbImages - Images từ database
   * @returns {Array} Merged images (temp/blob URLs + real URLs)
   */

  /**
   * 🔧 Compress image on client-side using Canvas
   * Max width/height: 1200px, Quality: 0.75
   *
   * ⚠️ Nén MỌI loại ảnh (kể cả HEIC của iPhone — Safari decode được qua <img>).
   * Trước đây HEIC bị bỏ qua → upload nguyên gốc 5-10MB/ảnh → mạng yếu là
   * treo "đang tải" hàng chục phút, thợ reload là mất ảnh.
   */
  async function compressImage(file) {
    if (!file.type.startsWith('image/')) {
      return file;
    }

    // 🚀 Đường nhanh: createImageBitmap decode ngoài main-thread (chuẩn app native),
    // nhanh hơn nhiều lần so với FileReader → base64 → <img> với ảnh 24-48MP.
    try {
      if (typeof createImageBitmap === 'function') {
        let bmp;
        try {
          bmp = await createImageBitmap(file, { imageOrientation: 'from-image' });
        } catch (e) {
          bmp = await createImageBitmap(file); // Safari cũ không nhận options
        }
        const maxDim = 1200;
        const scale = Math.min(1, maxDim / Math.max(bmp.width, bmp.height));
        const w = Math.max(1, Math.round(bmp.width * scale));
        const h = Math.max(1, Math.round(bmp.height * scale));
        const canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        canvas.getContext('2d').drawImage(bmp, 0, 0, w, h);
        bmp.close();
        const blob = await new Promise((res) => canvas.toBlob(res, 'image/jpeg', 0.75));
        if (blob && blob.size > 0) {
          const newFilename = file.name.replace(/\.[^/.]+$/, '') + '.jpg';
          return new File([blob], newFilename, { type: 'image/jpeg', lastModified: Date.now() });
        }
      }
    } catch (err) {
      console.warn('createImageBitmap path failed, falling back to legacy compress', err);
    }

    // Đường dự phòng: FileReader + <img> (trình duyệt cũ)
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = function (e) {
        const img = new Image();
        img.onload = function () {
          const maxDim = 1200;
          let width = img.width;
          let height = img.height;

          if (width > maxDim || height > maxDim) {
            if (width > height) {
              height = Math.round((height * maxDim) / width);
              width = maxDim;
            } else {
              width = Math.round((width * maxDim) / height);
              height = maxDim;
            }
          }

          // Downscale bậc thang cho ảnh cực lớn (24-48MP): iOS giới hạn kích thước
          // canvas/drawImage, scale thẳng 1 phát dễ fail im lặng → toBlob null
          let source = img;
          let sw = img.width;
          let sh = img.height;
          while (sw > 2400 && sh > 2400 && sw / 2 >= width && sh / 2 >= height) {
            const step = document.createElement('canvas');
            step.width = Math.round(sw / 2);
            step.height = Math.round(sh / 2);
            step.getContext('2d').drawImage(source, 0, 0, step.width, step.height);
            source = step;
            sw = step.width;
            sh = step.height;
          }

          const canvas = document.createElement('canvas');
          canvas.width = width;
          canvas.height = height;

          const ctx = canvas.getContext('2d');
          ctx.drawImage(source, 0, 0, sw, sh, 0, 0, width, height);

          canvas.toBlob(
            (blob) => {
              if (blob) {
                const newFilename = file.name.replace(/\.[^/.]+$/, "") + '.jpg';
                const compressedFile = new File([blob], newFilename, {
                  type: 'image/jpeg',
                  lastModified: Date.now()
                });
                console.log(`Original: ${(file.size / 1024 / 1024).toFixed(2)}MB, Compressed: ${(compressedFile.size / 1024 / 1024).toFixed(2)}MB`);
                resolve(compressedFile);
              } else {
                resolve(file);
              }
            },
            'image/jpeg',
            0.75
          );
        };
        img.onerror = () => resolve(file);
        img.src = e.target.result;
      };
      reader.onerror = () => resolve(file);
      reader.readAsDataURL(file);
    });
  }

  /**
   * 🚀 Upload single image (đã nén sẵn từ uploadImages) — XHR, timeout ngắn, tự retry.
   *
   * @param {File}   fileToUpload File ĐÃ nén (compressImage chạy ở tầng uploadImages
   *                              theo kiểu pipeline — nén ảnh kế tiếp trong lúc upload)
   * @param {Object} metadata     {customerId, invoiceId, isFeedback}
   */
  async function uploadSingleImage(fileToUpload, metadata, stat) {
    const { customerId, invoiceId, isFeedback } = metadata;
    const TIMEOUT_MS = 90000; // ảnh đã nén ~100-300KB, quá 90s là mạng có vấn đề → retry
    const MAX_ATTEMPTS = 3;   // tự retry khi rớt mạng/timeout — thợ không phải bấm lại

    const fileSizeMB = (fileToUpload.size / 1024 / 1024).toFixed(2);
    if (stat) stat.sizeKB = Math.round(fileToUpload.size / 1024);

    // Validate file size (max 50MB raw)
    if (fileToUpload.size > 50 * 1024 * 1024) {
      throw new Error(`File quá lớn (${fileSizeMB}MB). Vui lòng chọn ảnh nhỏ hơn 50MB.`);
    }

    const endpoint = isFeedback ? 'upload-feedback-image' : 'upload-customer-image';

    const attemptUpload = () =>
      new Promise((resolve, reject) => {
        const formData = new FormData();
        formData.append('image', fileToUpload);
        formData.append('customer_id', String(customerId));
        formData.append('invoice_id', invoiceId || '');
        formData.append('random', Math.random().toString(36).substr(2, 9));

        const xhr = new XMLHttpRequest();
        xhr.open('POST', `${checkinData.restUrl}${endpoint}`);
        xhr.setRequestHeader('X-WP-Nonce', checkinData.nonce);
        xhr.timeout = TIMEOUT_MS;
        xhr.responseType = 'json';

        xhr.onload = () => {
          if (xhr.status < 200 || xhr.status >= 300) {
            reject(new Error(`HTTP ${xhr.status}`));
            return;
          }
          const result = xhr.response || {};
          if (!result.success) {
            reject(new Error(result.message || 'Upload failed'));
            return;
          }
          if (stat) stat.serverMs = Math.round(result.data?.server_ms || 0);
          const urlData =
            result.data?.url || result.data?.temp_url || result.data?.image_url || result.url || null;
          if (!urlData) {
            resolve(null);
            return;
          }
          resolve(urlData.includes(',') ? urlData.split(',')[0] : urlData);
        };
        xhr.onerror = () => reject(new Error('network'));
        xhr.ontimeout = () => reject(new Error(`Timeout - File ${fileSizeMB}MB upload quá lâu`));
        xhr.send(formData);
      });

    let lastError;
    for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
      try {
        const t0 = Date.now();
        const url = await attemptUpload();
        if (stat) {
          stat.uploadMs = Date.now() - t0;
          stat.attempts = attempt;
        }
        return url;
      } catch (error) {
        lastError = error;
        if (attempt < MAX_ATTEMPTS) {
          await new Promise((r) => setTimeout(r, 1000 * attempt)); // backoff nhẹ rồi thử lại
        }
      }
    }
    throw lastError;
  }

  /**
   * 🔔 Banner tiến trình upload — nhắc thợ giữ app mở tới khi tải xong.
   * Gọi với text = null để gỡ banner.
   */
  function showUploadBanner(text) {
    let el = document.getElementById('ccUploadProgressBanner');
    if (text === null) {
      if (el) el.remove();
      return;
    }
    if (!el) {
      el = document.createElement('div');
      el.id = 'ccUploadProgressBanner';
      // Trên cùng màn hình, canh giữa ngang (cùng tầm toast) cho thợ dễ chú ý
      el.style.cssText =
        'position:fixed;top:calc(env(safe-area-inset-top, 0px) + 70px);left:50%;transform:translateX(-50%);' +
        'background:#1d4ed8;color:#fff;padding:10px 18px;border-radius:12px;' +
        'z-index:2147483000;font-size:13px;font-weight:600;text-align:center;' +
        'box-shadow:0 4px 14px rgba(0,0,0,.35);max-width:92vw;pointer-events:none;';
      document.body.appendChild(el);
    }
    el.textContent = text;
  }

  /**
   * 🚀 Upload nhiều ảnh kiểu app native: HÀNG ĐỢI TUẦN TỰ + PIPELINE.
   *
   * - Upload từng ảnh một (không bắn song song — trên mạng yếu các request
   *   song song giành băng thông của nhau, tổng thời gian còn lâu hơn).
   * - Trong lúc upload ảnh N thì NÉN SẴN ảnh N+1 (pipeline) → không có
   *   thời gian chết giữa các ảnh.
   * - Banner tiến trình đếm theo ảnh: "Đang tải ảnh 2/3…"
   */
  async function uploadImages(files, metadata) {
    const total = files.length;
    const uploadedUrls = new Array(total);
    const stats = [];
    uploadImages.lastStatsText = '';

    showUploadBanner(`📤 Đang chuẩn bị ${total} ảnh…`);

    const safeCompress = (file, stat) => {
      const t0 = Date.now();
      return compressImage(file)
        .catch((err) => {
          console.warn('Compress failed, dùng file gốc', err);
          return file;
        })
        .then((f) => {
          stat.compressMs = Date.now() - t0;
          stat.originalKB = Math.round(file.size / 1024);
          return f;
        });
    };

    // Nén trước ảnh đầu tiên; các ảnh sau nén song song trong lúc upload ảnh trước
    for (let i = 0; i < total; i++) stats.push({});
    let nextCompressed = safeCompress(files[0], stats[0]);

    try {
      for (let i = 0; i < total; i++) {
        const fileToUpload = await nextCompressed;
        if (i + 1 < total) {
          nextCompressed = safeCompress(files[i + 1], stats[i + 1]); // pipeline: nén ảnh kế tiếp ngay
        }

        showUploadBanner(`📤 Đang tải ảnh ${i + 1}/${total} — đừng đóng app!`);

        try {
          uploadedUrls[i] = await uploadSingleImage(fileToUpload, metadata, stats[i]);
        } catch (err) {
          throw new Error(`Ảnh ${i + 1}/${total}: ${err.message}`);
        }
      }

      // 📊 Chuỗi chẩn đoán gắn vào toast thành công — tách "chậm do đâu":
      // nén (client) / server (PHP xử lý) / còn lại = mạng
      uploadImages.lastStatsText = stats
        .map((s, i) => {
          const net = Math.max(0, (s.uploadMs || 0) - (s.serverMs || 0));
          const retry = s.attempts > 1 ? ` L${s.attempts}` : '';
          return `A${i + 1}: nén ${((s.compressMs || 0) / 1000).toFixed(1)}s→${s.sizeKB || '?'}KB, mạng ${(net / 1000).toFixed(1)}s, sv ${((s.serverMs || 0) / 1000).toFixed(1)}s${retry}`;
        })
        .join(' | ');
      console.table(stats);

      return uploadedUrls;
    } finally {
      showUploadBanner(null);
    }
  }

  /**
   * Update UI with images (blob URLs for instant display)
   */
  function updateUIWithImages(invoice, blobUrls, isFeedback) {
    if (isFeedback) {
      invoice.feedbackImages = [...(invoice.feedbackImages || []), ...blobUrls];
    } else {
      invoice.images = [...(invoice.images || []), ...blobUrls];

      if (invoice.customer) {
        // ✅ Thêm blob URLs vào customer.photos, giữ 3 ảnh mới nhất
        const existing = Array.isArray(invoice.customer.photos) ? invoice.customer.photos : [];
        invoice.customer.photos = [...existing, ...blobUrls].slice(-3);
        displayCustomerInfo(invoice.customer);
      }

      renderInvoiceTabs();
    }
    saveInvoicesToLocalStorage();

    // 🔄 Báo realtime cho modal "Tất cả hóa đơn" cập nhật trạng thái up hình
    document.dispatchEvent(
      new CustomEvent('checkin:invoice-images-updated', {
        detail: { invoice_id: invoice.invoice_id },
      })
    );
  }

  /**
   * Replace blob URLs with real server URLs
   * Sau khi upload thành công, cập nhật:
   * 1. invoice.images - ảnh của hóa đơn
   * 2. invoice.customer.photos - ảnh để hiển thị
   * 3. localStorage customersList - để data sync
   */
  function replaceBlobURLs(invoice, blobUrls, realUrls, isFeedback) {
    // Nếu không có realUrls hợp lệ, giữ nguyên blob URLs
    const validRealUrls = realUrls.filter((url) => url && typeof url === 'string');
    if (validRealUrls.length === 0) {
      return;
    }

    if (isFeedback) {
      invoice.feedbackImages = invoice.feedbackImages.map((url, idx) =>
        url.startsWith('blob:') && realUrls[idx] ? realUrls[idx] : url
      );
    } else {
      // Replace blob URLs trong invoice.images
      invoice.images = invoice.images.map((url) => {
        if (url.startsWith('blob:')) {
          const blobIndex = blobUrls.findIndex((blob) => blob === url);
          return blobIndex !== -1 && realUrls[blobIndex] ? realUrls[blobIndex] : url;
        }
        return url;
      });

      console.log('  - invoice.images AFTER replace:', invoice.images);

      if (invoice.customer) {
        // Replace blob URLs trong customer.photos
        const photos = Array.isArray(invoice.customer.photos) ? invoice.customer.photos : [];
        const newPhotos = photos
          .map((url) => {
            if (url.startsWith('blob:')) {
              const blobIndex = blobUrls.findIndex((blob) => blob === url);
              return blobIndex !== -1 && realUrls[blobIndex] ? realUrls[blobIndex] : url;
            }
            return url;
          })
          .slice(-3);

        invoice.customer.photos = newPhotos;

        // ✅ SYNC: Cập nhật photos vào localStorage để data luôn đồng bộ
        if (invoice.customer.id) {
          const customers = getCustomersFromLocalStorage() || [];
          const customerIndex = customers.findIndex((c) => c.customer_id === invoice.customer.id);
          if (customerIndex !== -1) {
            // Lấy ảnh hiện tại từ localStorage, thêm ảnh mới
            let existingImages = [];
            if (typeof customers[customerIndex].customer_images === 'string') {
              try {
                existingImages = JSON.parse(customers[customerIndex].customer_images);
              } catch {
                existingImages = customers[customerIndex].customer_images
                  .split(',')
                  .map((s) => s.trim())
                  .filter(Boolean);
              }
            } else if (Array.isArray(customers[customerIndex].customer_images)) {
              existingImages = customers[customerIndex].customer_images;
            }

            // Merge ảnh mới vào (không trùng lặp)
            const mergedImages = [...new Set([...existingImages, ...validRealUrls])];
            customers[customerIndex].customer_images = mergedImages;
            saveCustomersToLocalStorage(customers);
          }
        }

        // Refresh UI
        displayCustomerInfo(invoice.customer);
      }
      renderInvoiceTabs();
    }

    // 🔄 Đồng bộ mirror invoicesData với ảnh vừa upload — nếu bỏ qua, lần lưu hoá đơn
    // hoặc sync tiếp theo sẽ lấy dữ liệu cũ từ mirror và làm ảnh "biến mất" trên UI
    if (invoice.invoice_id) {
      const dataIdx = invoicesData.findIndex((inv) => inv.invoice_id === invoice.invoice_id);
      if (dataIdx !== -1) {
        if (isFeedback) {
          invoicesData[dataIdx].feedback_images = [...(invoice.feedbackImages || [])];
        } else {
          invoicesData[dataIdx].images = [...(invoice.images || [])];
        }
      }
    }
    saveInvoicesToLocalStorage();

    // 🔄 Báo realtime cho modal "Tất cả hóa đơn" cập nhật trạng thái up hình
    document.dispatchEvent(
      new CustomEvent('checkin:invoice-images-updated', {
        detail: { invoice_id: invoice.invoice_id },
      })
    );

    // Cleanup blob URLs đã được replace thành công
    blobUrls.forEach((blobUrl, idx) => {
      if (realUrls[idx] && typeof realUrls[idx] === 'string') {
        URL.revokeObjectURL(blobUrl);
      }
    });
  } // Hàm mở modal upload ảnh danh mục Dịch vụ
  function openUploadImageModalService(invoiceIndex, isDBInvoice, isFeedback = false) {
    const invoice = isDBInvoice
      ? invoicesData.find((inv) => inv.invoice_id === invoices[invoiceIndex].invoice_id)
      : invoices[invoiceIndex];

    if (!invoice || !invoice.customer) {
      showWarning('Vui lòng chọn khách hàng trước khi tải ảnh lên');
      return;
    }

    const modal = document.getElementById('imageUploadModal');
    const imageInput = document.getElementById('imageUploadInput');
    const previewContainer = document.getElementById('imagePreview');
    const confirmBtn = document.getElementById('confirmUploadBtn');
    const closeBtn = document.getElementById('closeUploadModal');
    const title = document.getElementById('imageUploadTitle');

    title.textContent = isFeedback ? 'Upload Feedback' : 'Upload Khách Hàng';
    modal.style.display = 'flex';

    let selectedFiles = [];

    // Reset
    imageInput.value = '';
    previewContainer.innerHTML = '';
    confirmBtn.disabled = true;

    // Preview selected images
    imageInput.onchange = () => {
      selectedFiles = Array.from(imageInput.files);
      previewContainer.innerHTML = '';

      selectedFiles.forEach((file, index) => {
        const img = document.createElement('img');
        img.src = URL.createObjectURL(file);
        img.alt = `Preview ${index + 1}`;
        img.onload = () => URL.revokeObjectURL(img.src); // Cleanup after preview
        previewContainer.appendChild(img);
      });

      confirmBtn.disabled = selectedFiles.length === 0;
    };

    // Upload handler
    confirmBtn.onclick = async () => {
      if (selectedFiles.length === 0) {
        showWarning('Vui lòng chọn ít nhất một ảnh');
        return;
      }

      const customerId = invoice.customer?.id;
      if (!customerId) {
        showWarning('Không tìm thấy thông tin khách hàng');
        return;
      }

      const originalBtnText = confirmBtn.innerHTML;
      confirmBtn.disabled = true;
      confirmBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Đang tải...';

      try {
        // 1. Create blob URLs for instant UI
        const blobUrls = selectedFiles.map((file) => URL.createObjectURL(file));

        // 2. Update UI immediately
        updateUIWithImages(invoice, blobUrls, isFeedback);

        // 3. Close modal immediately
        confirmBtn.disabled = false;
        confirmBtn.innerHTML = originalBtnText;
        modal.style.display = 'none';
        toastSuccess(`Đang tải ${selectedFiles.length} ảnh lên server...`, 2000);

        // 4. Background upload (non-blocking)
        const uploadStartTime = Date.now();
        uploadImages(selectedFiles, {
          customerId,
          invoiceId: invoice.invoice_id,
          isFeedback,
        })
          .then((realUrls) => {
            const uploadDuration = ((Date.now() - uploadStartTime) / 1000).toFixed(1);
            replaceBlobURLs(invoice, blobUrls, realUrls, isFeedback);
            toastSuccess(
              `✅ Upload thành công ${selectedFiles.length} ảnh (${uploadDuration}s)`,
              3000
            );
          })
          .catch((err) => {
            const uploadDuration = ((Date.now() - uploadStartTime) / 1000).toFixed(1);

            // Show user-friendly error message
            if (err.message.includes('timeout')) {
              toastError(
                `⏱️ Upload quá chậm (${uploadDuration}s). Vui lòng thử lại với ít ảnh hơn hoặc kết nối WiFi tốt hơn.`,
                5000
              );
            } else if (err.message.includes('network') || err.message.includes('fetch')) {
              toastError(`📡 Lỗi kết nối mạng. Vui lòng kiểm tra internet và thử lại.`, 5000);
            } else {
              toastError(`❌ Lỗi upload: ${err.message}`, 4000);
            }
          });
      } catch (err) {
        toastError(`Lỗi: ${err.message}`);
        confirmBtn.disabled = false;
        confirmBtn.innerHTML = originalBtnText;
      }
    };

    closeBtn.onclick = () => {
      modal.style.display = 'none';
    };
  }

  // Hàm mở modal upload ảnh danh mục Hóa đơn
  function openUploadImageModalInvoice(invoice, isFeedback = false) {
    if (!invoice) {
      showWarning('Vui lòng chọn hóa đơn trước khi tải ảnh lên');
      return;
    }

    const customerId = invoice.customer_id;
    if (!customerId) {
      showWarning('Hóa đơn không có thông tin khách hàng');
      return;
    }

    const modal = document.getElementById('imageUploadModal');
    const imageInput = document.getElementById('imageUploadInput');
    const previewContainer = document.getElementById('imagePreview');
    const confirmBtn = document.getElementById('confirmUploadBtn');
    const closeBtn = document.getElementById('closeUploadModal');
    const title = document.getElementById('imageUploadTitle');

    title.textContent = isFeedback ? 'Upload Feedback' : 'Upload Khách Hàng';
    modal.style.display = 'flex';

    let selectedFiles = [];

    // Reset
    imageInput.value = '';
    previewContainer.innerHTML = '';
    confirmBtn.disabled = true;

    // Preview selected images
    imageInput.onchange = () => {
      selectedFiles = Array.from(imageInput.files);
      previewContainer.innerHTML = '';

      selectedFiles.forEach((file, index) => {
        const img = document.createElement('img');
        img.src = URL.createObjectURL(file);
        img.alt = `Preview ${index + 1}`;
        img.onload = () => URL.revokeObjectURL(img.src);
        previewContainer.appendChild(img);
      });

      confirmBtn.disabled = selectedFiles.length === 0;
    };

    // Upload handler
    confirmBtn.onclick = async () => {
      if (selectedFiles.length === 0) {
        showWarning('Vui lòng chọn ít nhất một ảnh');
        return;
      }

      const originalBtnText = confirmBtn.innerHTML;
      confirmBtn.disabled = true;
      confirmBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Đang tải...';

      try {
        // 1. Create blob URLs for instant UI
        const blobUrls = selectedFiles.map((file) => URL.createObjectURL(file));

        // 2. Update UI immediately
        updateUIWithImages(invoice, blobUrls, isFeedback);

        // 3. Close modal immediately
        confirmBtn.disabled = false;
        confirmBtn.innerHTML = originalBtnText;
        modal.style.display = 'none';
        toastSuccess(`Đang tải ${selectedFiles.length} ảnh lên server...`, 2000);

        // 4. Background upload (non-blocking)
        const uploadStartTime = Date.now();
        uploadImages(selectedFiles, {
          customerId,
          invoiceId: invoice.invoice_id,
          isFeedback,
        })
          .then((realUrls) => {
            const uploadDuration = ((Date.now() - uploadStartTime) / 1000).toFixed(1);
            replaceBlobURLs(invoice, blobUrls, realUrls, isFeedback);
            toastSuccess(
              `✅ Upload thành công ${selectedFiles.length} ảnh (${uploadDuration}s)`,
              3000
            );
          })
          .catch((err) => {
            const uploadDuration = ((Date.now() - uploadStartTime) / 1000).toFixed(1);

            // Show user-friendly error message
            if (err.message.includes('timeout')) {
              toastError(
                `⏱️ Upload quá chậm (${uploadDuration}s). Vui lòng thử lại với ít ảnh hơn hoặc kết nối WiFi tốt hơn.`,
                5000
              );
            } else if (err.message.includes('network') || err.message.includes('fetch')) {
              toastError(`📡 Lỗi kết nối mạng. Vui lòng kiểm tra internet và thử lại.`, 5000);
            } else {
              toastError(`❌ Lỗi upload: ${err.message}`, 4000);
            }
          });
      } catch (err) {
        toastError(`Lỗi: ${err.message}`);
        confirmBtn.disabled = false;
        confirmBtn.innerHTML = originalBtnText;
      }
    };

    closeBtn.onclick = () => {
      modal.style.display = 'none';
    };
  }

  /**
   * Mở modal chọn lý do không có hình.
   * @param {object} [targetInvoice] Hóa đơn cần ghi lý do. Bỏ trống thì lấy hóa đơn đang active.
   *   ⚠️ Nút "Not Image" trong modal chi tiết PHẢI truyền hóa đơn đang mở — trước đây nó dùng
   *   invoices[currentInvoiceIndex] nên có thể ghi nhầm sang hóa đơn khác.
   */
  function handleNotImageClick(targetInvoice) {
    const modal = document.getElementById('notImageModal');
    const checkboxes = modal.querySelectorAll('input[type="checkbox"]');
    const submitBtn = document.getElementById('notImageSubmit');
    const cancelBtn = document.getElementById('notImageCancel');

    // Chốt hóa đơn NGAY lúc mở modal, không đọc lại lúc bấm Gửi (danh sách có thể đã đổi)
    const invoice =
      targetInvoice && targetInvoice.invoice_id ? targetInvoice : invoices[currentInvoiceIndex];

    if (!invoice || !invoice.invoice_id) {
      showError('Hóa đơn không hợp lệ');
      return;
    }

    // Reset lựa chọn cũ — modal dùng chung cho mọi hóa đơn
    checkboxes.forEach((cb) => {
      cb.checked = false;
    });

    modal.style.display = 'flex';

    submitBtn.onclick = async () => {
      const selected = Array.from(checkboxes)
        .filter((cb) => cb.checked)
        .map((cb) => cb.value);

      if (selected.length === 0) {
        showWarning('Vui lòng chọn ít nhất một lý do');
        return;
      }

      submitBtn.disabled = true;

      try {
        await fetchAPI(`invoices/${invoice.invoice_id}`, {
          method: 'PUT',
          body: JSON.stringify({ not_image: selected }),
        });

        invoice.notImage = selected;
        invoice.not_image = selected;

        // Đồng bộ sang bản ghi trong danh sách hóa đơn đã tải từ DB
        const localInvoice = invoices.find((inv) => inv.invoice_id === invoice.invoice_id);
        if (localInvoice && localInvoice !== invoice) {
          localInvoice.notImage = selected;
          localInvoice.not_image = selected;
        }
        const dbInvoice = invoicesData.find((inv) => inv.invoice_id === invoice.invoice_id);
        if (dbInvoice) {
          dbInvoice.not_image = selected;
        }

        saveInvoicesToLocalStorage();

        // ✅ Refresh data theo period hiện tại
        clearInvoicesDataCache();
        try {
          await reloadCurrentPeriodInvoices();
          if (currentSection === 'invoices') {
            renderInvoiceList();
          }
        } catch (e) {
          console.error('Failed to reload after notImage submit:', e);
        }

        toastSuccess('Đã gửi lý do thành công!');
      } catch (err) {
        // Hiện đúng lý do server từ chối (vd 409 invoice_locked_paid) thay vì báo chung chung,
        // tuyệt đối không được im lặng coi như đã lưu.
        toastError(`Lỗi khi gửi lý do: ${err.message || 'không rõ nguyên nhân'}`, 5000);
      } finally {
        submitBtn.disabled = false;
      }

      modal.style.display = 'none';
    };

    cancelBtn.onclick = () => {
      modal.style.display = 'none';
    };
  }

  // ==============================
  // 14. Sidebar and Navigation
  // ==============================
  function toggleSidebar() {
    const isMobile = window.innerWidth < 768;
    const isCollapsed = elements.sidebar.classList.contains('sidebar-collapsed');
    const icon = document.querySelector('#sidebarToggle i');
    const overlay = document.getElementById('overlay');

    if (isMobile) {
      elements.sidebar.classList.toggle('open');
      elements.sidebar.classList.toggle('sidebar-collapsed');
      elements.mainContent.classList.toggle('main-content-expanded');
    } else {
      elements.sidebar.classList.toggle('sidebar-collapsed');
      elements.mainContent.classList.toggle('main-content-expanded');
    }

    const nowCollapsed = elements.sidebar.classList.contains('sidebar-collapsed');
    localStorage.setItem('sidebarCollapsed', nowCollapsed);

    if (icon) {
      icon.classList.remove('fa-chevron-circle-left', 'fa-chevron-circle-right');
      icon.classList.add(nowCollapsed ? 'fa-chevron-circle-right' : 'fa-chevron-circle-left');
    }

    // 👉 Hiện hoặc ẩn overlay
    if (!nowCollapsed && isMobile) {
      overlay.classList.remove('hidden', 'opacity-0', 'pointer-events-none');
      overlay.classList.add('opacity-100');
    } else {
      overlay.classList.remove('opacity-100');
      overlay.classList.add('opacity-0', 'pointer-events-none');
      setTimeout(() => overlay.classList.add('hidden'), 300);
    }
  }

  // ==============================
  // DASHBOARD FUNCTIONS
  // Dashboard logic moved to dashboard.js
  // This file delegates to AppThoDashboard module
  // ==============================

  /**
   * Delegate to Dashboard Module (dashboard.js)
   * All dashboard logic is now in separate dashboard.js file
   */
  async function renderDashboard() {
    if (!elements.dashboardContent) return;

    // Delegate to dashboard module
    if (window.AppThoDashboard && typeof window.AppThoDashboard.init === 'function') {
      window.AppThoDashboard.init();
    } else {
      console.warn('Dashboard module not loaded');
    }
  }

  function attachDashboardListeners() {
    // Handled by dashboard.js
  }

  // ============================================================
  // 📱 MOBILE CARD LIST — gắn nhãn data-label cho từng ô từ thead
  // để CSS biến bảng thành card native trên mobile (desktop giữ bảng)
  // ============================================================
  function annotateTableForMobileCards(table) {
    if (!table) return;
    const headers = Array.from(table.querySelectorAll('thead th')).map((th) =>
      th.textContent.trim()
    );
    table.querySelectorAll('tbody tr').forEach((tr) => {
      Array.from(tr.children).forEach((td, i) => {
        if (!td.hasAttribute('colspan')) {
          td.setAttribute('data-label', headers[i] || '');
        }
      });
    });
  }

  // ============================================================
  // 📱 MOBILE FILTER TOGGLE — thu gọn khu bộ lọc hoá đơn thành nút "Lọc"
  // ============================================================
  function initMobileFilterToggle() {
    if (document.getElementById('mobileFilterToggle')) return;
    const container = document.querySelector('#invoicesContent .time-filter-container');
    const panel = document.querySelector('#invoicesContent .search-filters-container');
    if (!container || !panel) return;

    const btn = document.createElement('button');
    btn.id = 'mobileFilterToggle';
    btn.type = 'button';
    btn.className = 'mobile-filter-toggle';
    btn.innerHTML = '<i class="fas fa-sliders-h"></i> Lọc';
    btn.addEventListener('click', () => {
      const open = panel.classList.toggle('open');
      btn.classList.toggle('active', open);
    });
    container.appendChild(btn);

    // Mobile: dời nút Đối soát (admin) lên cùng hàng với nút Lọc
    if (window.matchMedia('(max-width: 767px)').matches) {
      const reconcile = document.getElementById('reconcileBtn');
      if (reconcile) container.appendChild(reconcile);
    }
  }

  // ============================================================
  // 📱 BOTTOM NAVIGATION — thanh điều hướng chuẩn app native (mobile)
  // Tái dùng handleNavigation + class menu-item nên active-state của
  // các tab tự đồng bộ với sidebar, không cần logic riêng.
  // ============================================================
  // 🔒 iOS: khi focus input có font-size <16px, Safari tự phóng to trang và
  // GIỮ mức zoom sau khi tắt bàn phím → visual viewport tách khỏi layout
  // viewport, mọi phần tử position:fixed (header, bottom bar) trôi theo nội
  // dung khi cuộn. maximum-scale=1 chặn auto-zoom này nhưng iOS vẫn cho
  // pinch-zoom thủ công (accessibility). Chỉ áp cho iOS để không khoá
  // pinch-zoom trên Android. Sửa MỌI meta viewport vì trang shortcode có
  // cả meta của theme lẫn meta của app — WebKit lấy meta parse sau cùng.
  // Chạy ngay khi script load, không đợi app init (init lỗi vẫn phải fix).
  (function fixIOSViewportZoom() {
    const isIOS =
      /iPad|iPhone|iPod/.test(navigator.userAgent) ||
      (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
    if (!isIOS) return;
    const apply = () => {
      let metas = document.querySelectorAll('meta[name="viewport"]');
      if (!metas.length) {
        const meta = document.createElement('meta');
        meta.name = 'viewport';
        document.head.appendChild(meta);
        metas = [meta];
      }
      metas.forEach((meta) => {
        if (!/maximum-scale/i.test(meta.content)) {
          meta.content = 'width=device-width, initial-scale=1.0, maximum-scale=1.0';
        }
      });
    };
    apply();
    // Chạy lại sau khi DOM đủ — phòng meta của app (trong shortcode) parse sau script
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', apply);
    }
  })();

  function initBottomNav() {
    if (document.getElementById('bottomNav')) return;

    // ── Bar chính: 4 tab + 1 FAB giữa ──
    const nav = document.createElement('nav');
    nav.id = 'bottomNav';
    nav.className = 'bottom-nav';
    nav.innerHTML = `
      <button type="button" class="bottom-nav-item menu-item" data-section="dashboard">
        <i class="fas fa-home bnav-icon"></i><span class="bnav-label">Trang chủ</span>
      </button>
      <button type="button" class="bottom-nav-item menu-item" data-section="bookings">
        <i class="fas fa-calendar-alt bnav-icon"></i><span class="bnav-label">Lịch hẹn</span>
      </button>
      <button type="button" class="bottom-nav-item bnav-fab-slot menu-item" data-section="services">
        <span class="bnav-fab"><i class="fas fa-cut bnav-icon"></i></span>
        <span class="bnav-label">Dịch vụ</span>
      </button>
      <button type="button" class="bottom-nav-item menu-item" data-section="invoices">
        <i class="fas fa-file-invoice-dollar bnav-icon"></i><span class="bnav-label">Hóa đơn</span>
      </button>
      <button type="button" class="bottom-nav-item" id="bnavMoreBtn">
        <i class="fas fa-ellipsis-h bnav-icon"></i><span class="bnav-label">Thêm</span>
      </button>
    `;
    document.body.appendChild(nav);

    // ── Bottom sheet "Thêm" ──
    const backdrop = document.createElement('div');
    backdrop.className = 'bottom-nav-sheet-backdrop';
    document.body.appendChild(backdrop);

    const sheet = document.createElement('div');
    sheet.className = 'bottom-nav-sheet';
    sheet.innerHTML = `
      <div class="bnav-sheet-handle"></div>
      <button type="button" class="bnav-sheet-item menu-item" data-section="reports">
        <i class="fas fa-chart-line"></i>Báo cáo
      </button>
      <button type="button" class="bnav-sheet-item menu-item" data-section="shifts" id="bnavShiftsItem">
        <i class="fas fa-cash-register"></i>Quản lý Ca
      </button>
      <button type="button" class="bnav-sheet-item menu-item" data-section="settings">
        <i class="fas fa-cog"></i>Cài đặt
      </button>
      <hr class="bnav-sheet-divider" />
      <a href="/user-profile" class="bnav-sheet-item">
        <i class="fas fa-user"></i>Trang cá nhân
      </a>
      <a href="/diem-danh" class="bnav-sheet-item">
        <i class="fas fa-clock"></i>Điểm danh
      </a>
      <button type="button" class="bnav-sheet-item" id="bnavVersionBtn" title="Bấm để xoá bộ nhớ đệm">
        <i class="fas fa-broom"></i><span id="bnavVersionText">Phiên bản</span>
      </button>
      <button type="button" class="bnav-sheet-item bnav-danger" id="bnavLogoutBtn">
        <i class="fas fa-sign-out-alt"></i>Đăng xuất
      </button>
    `;
    document.body.appendChild(sheet);

    const openSheet = () => {
      // Quản lý Ca chỉ hiện với vai trò có quyền — mượn trạng thái từ sidebar
      const shiftsItem = document.getElementById('bnavShiftsItem');
      if (shiftsItem && elements.shiftsNavItem) {
        shiftsItem.style.display = elements.shiftsNavItem.classList.contains('hidden')
          ? 'none'
          : '';
      }
      backdrop.classList.add('open');
      sheet.classList.add('open');
    };
    const closeSheet = () => {
      backdrop.classList.remove('open');
      sheet.classList.remove('open');
    };

    nav.querySelector('#bnavMoreBtn').addEventListener('click', () => {
      sheet.classList.contains('open') ? closeSheet() : openSheet();
    });
    backdrop.addEventListener('click', closeSheet);

    // Tab chính: điều hướng qua handleNavigation (active-state tự sync)
    nav.querySelectorAll('.bottom-nav-item[data-section]').forEach((item) => {
      item.addEventListener('click', () => {
        closeSheet();
        handleNavigation(item.dataset.section);
      });
    });
    // Item trong sheet
    sheet.querySelectorAll('.bnav-sheet-item[data-section]').forEach((item) => {
      item.addEventListener('click', () => {
        closeSheet();
        handleNavigation(item.dataset.section);
      });
    });
    // Phiên bản + xoá bộ nhớ đệm (giống bấm version ở sidebar desktop)
    const versionBtn = sheet.querySelector('#bnavVersionBtn');
    if (versionBtn) {
      const versionText = sheet.querySelector('#bnavVersionText');
      if (versionText && checkinData && checkinData.version) {
        versionText.textContent = `Phiên bản ${checkinData.version} — xoá bộ nhớ đệm`;
      }
      versionBtn.addEventListener('click', async () => {
        closeSheet();
        const confirmed = await showConfirm(
          'Bạn có chắc muốn xóa tất cả dữ liệu bộ nhớ đệm của ứng dụng?',
          'Xác nhận xóa'
        );
        if (confirmed) {
          clearAllLocalStorage();
        }
      });
    }

    // Đăng xuất: dùng lại flow của nút sidebar
    sheet.querySelector('#bnavLogoutBtn').addEventListener('click', () => {
      closeSheet();
      const logoutBtn = document.getElementById('logoutButton');
      if (logoutBtn) logoutBtn.click();
    });

    updateBottomNavActive(currentSection);
  }

  // Tab "Thêm" sáng khi đang ở section nằm trong sheet
  function updateBottomNavActive(section) {
    const moreBtn = document.getElementById('bnavMoreBtn');
    if (!moreBtn) return;
    const sheetSections = ['reports', 'shifts', 'settings'];
    moreBtn.classList.toggle('bnav-more-active', sheetSections.includes(section));
  }

  function handleNavigation(section) {
    currentSection = section;

    updateBottomNavActive(section);

    elements.pageTitle.textContent = sectionTitles[section] || 'Unknown';

    document.querySelectorAll('.content-section').forEach((section) => {
      section.classList.add('hidden');
    });

    // Support sections with hyphens (e.g., review-detail) by using bracket notation
    const contentKey = `${section}Content`;
    const sectionElement = elements[contentKey] || document.getElementById(contentKey);
    if (sectionElement) {
      sectionElement.classList.remove('hidden');
    }

    document.querySelectorAll('.menu-item').forEach((item) => {
      if (item.dataset.section === section) {
        item.classList.add('menu-item-active');
      } else {
        item.classList.remove('menu-item-active');
      }
    });

    const isMobile = window.innerWidth < 768;
    if (isMobile && elements.sidebar && elements.mainContent) {
      elements.sidebar.classList.add('sidebar-collapsed');
      elements.sidebar.classList.remove('open');
      elements.mainContent.classList.add('main-content-expanded');
      localStorage.setItem('sidebarCollapsed', true);

      const overlay = document.getElementById('overlay');
      overlay.classList.remove('opacity-100');
      overlay.classList.add('opacity-0', 'pointer-events-none');
      setTimeout(() => overlay.classList.add('hidden'), 300);
    }

    // 🚀 POLLING CONTROL: Chỉ polling khi ở section services/invoices
    const needsPolling = section === 'services' || section === 'invoices';
    if (needsPolling && !isPollingActive) {
      pollInvoiceStatus().catch(() => {});
    } else if (!needsPolling && isPollingActive) {
      stopPolling();
    }

    if (section === 'dashboard') {
      renderDashboard();
    } else if (section === 'reports') {
      // ✅ Mặc định filter là 'today' và sử dụng invoicesData có sẵn
      // Set filter TRƯỚC khi update UI
      currentReportFilter = 'today';
      localStorage.setItem('currentReportFilter', 'today');

      // 🚀 Setup UI sau khi đã set filter (để UI hiển thị đúng)
      updateReportFilterUI();
      populateStaffFilter();

      // ✅ Show page loader khi vào section reports
      if (window.showPageLoader) {
        window.showPageLoader({ text: 'Đang tải báo cáo...', subtitle: 'Vui lòng đợi' });
      }

      // Render ngay từ invoicesData có sẵn
      setTimeout(async () => {
        try {
          await loadReportData();
        } catch (e) {
          console.error('Reports section load error:', e);
        } finally {
          // Hide page loader sau khi render xong
          await new Promise((resolve) => setTimeout(resolve, 100));
          if (window.hidePageLoader) {
            window.hidePageLoader(100);
          }
        }
      }, 0);
    } else if (section === 'services') {
      // Set currentTab to 'services' BEFORE calling updateTabState
      currentTab = 'services';

      // ✅ SIMPLIFIED: Reset filter về today khi vào section
      currentServiceFilter = 'today';
      serviceCustomDateRange = null;
      isFromMoreTab = false;
      selectedFromMore = false;
      try {
        localStorage.setItem('currentServiceFilter', 'today');
        localStorage.removeItem('serviceCustomStartDate');
        localStorage.removeItem('serviceCustomEndDate');
      } catch (e) {}

      // 🚀 Render UI ngay lập tức từ data có sẵn (invoicesData đã được load thisMonth)
      loadServiceGroups();
      loadServicesForGroup();
      updateTabState();
      updateServiceFilterUI();

      // ✅ Chọn hóa đơn mới nhất TRƯỚC khi render
      if (invoices && invoices.length > 0) {
        let newestIndex = 0;
        try {
          let maxTime = -Infinity;
          invoices.forEach((inv, idx) => {
            const t = new Date(inv.created_at || 0).getTime();
            if (!isNaN(t) && t > maxTime) {
              maxTime = t;
              newestIndex = idx;
            }
          });
        } catch (e) {
          newestIndex = invoices.length - 1;
        }
        currentInvoiceIndex = newestIndex;
      }

      // Render với filter 'today' từ invoicesData có sẵn
      // ✅ SIMPLIFIED: renderInvoiceTabs() sẽ tự động gọi rebuildVisibleInvoices()
      renderInvoiceTabs();
      scrollToInvoiceTab(currentInvoiceIndex); // Scroll đến tab active
      renderCurrentInvoice();
    } else if (section === 'settings') {
      handleSettingsNavigation(currentSettingsSubsection);
    } else if (section === 'bookings') {
      // Reset bộ lọc Bookings về hôm nay khi click vào menu
      currentBookingFilter = 'today';
      currentBookingPage = 1;
      try {
        localStorage.setItem('currentBookingFilter', 'today');
        localStorage.setItem('bookingPage', '1');
      } catch (e) {}

      // 🚀 CACHE-FIRST: Hiển thị cache trước (nếu có)
      updateBookingFilterUI();

      const cachedBookings = getBookingsFromLocalStorage();
      if (cachedBookings && cachedBookings.length > 0) {
        bookingsData = cachedBookings;
        renderBookingList();
      }

      // 🔄 Fetch fresh data từ API ở background
      loadStaffBookings('today')
        .then(() => {
          renderBookingList();
        })
        .catch((e) => console.error('Bookings section load error:', e));
    } else if (section === 'invoices') {
      // ✅ SIMPLIFIED: Reset filter về today khi vào section
      currentFilter = 'today';
      try {
        localStorage.setItem('currentFilter', 'today');
      } catch (e) {}

      // 🚀 Render UI ngay lập tức từ data có sẵn (invoicesData đã được load thisMonth)
      updateTimeFilterButtons();
      renderInvoiceList('today');
      renderInvoiceTabs();
    } else if (section === 'shifts') {
      // 📋 Quản lý Ca - Delegate to Shift Management Module
      if (window.AppThoShiftManagement && typeof window.AppThoShiftManagement.init === 'function') {
        window.AppThoShiftManagement.init();
      } else {
        console.warn('Shift Management module not loaded');
        // Fallback message
        if (elements.shiftsContent) {
          elements.shiftsContent.innerHTML = `
            <div class="shift-access-denied">
              <i class="fas fa-exclamation-triangle"></i>
              <h3>Module chưa được tải</h3>
              <p>Vui lòng tải lại trang</p>
            </div>
          `;
        }
      }
    } else if (section === 'review-detail') {
      // 📝 Review Detail View (Staff read-only mode)
      // Load and display review details for the invoice specified in URL params
      handleReviewDetailView();
    }
  }

  // 📝 Handle Review Detail View (Staff read-only mode)
  async function handleReviewDetailView() {
    const invoiceId = urlParams.get('invoice_id');

    if (!invoiceId) {
      const container = document.getElementById('reviewDetailContainer');
      if (container) {
        container.innerHTML = `
          <div class="review-error-message">
            <i class="fas fa-exclamation-circle"></i>
            <h3>Thiếu thông tin hóa đơn</h3>
            <p>Không tìm thấy ID hóa đơn trong URL</p>
          </div>
        `;
      }
      return;
    }

    try {
      // Show loading state
      const container = document.getElementById('reviewDetailContainer');
      if (container) {
        container.innerHTML = `
          <div class="review-loading">
            <div class="loading-spinner"></div>
            <p>Đang tải chi tiết đánh giá...</p>
          </div>
        `;
      }

      // Fetch review detail from API
      const response = await fetch(`${checkinData.restUrl}review-detail/${invoiceId}`, {
        headers: {
          'X-WP-Nonce': checkinData.nonce,
        },
      });

      const result = await response.json();

      if (!result.success) {
        if (container) {
          container.innerHTML = `
            <div class="review-error-message">
              <i class="fas fa-info-circle"></i>
              <h3>${result.message || 'Không tìm thấy đánh giá'}</h3>
              <p>Hóa đơn này chưa được đánh giá hoặc đánh giá không tồn tại.</p>
            </div>
          `;
        }
        return;
      }

      const { invoice, review } = result.data;

      // Render review detail in read-only mode
      if (container) {
        const ratingText = {
          1: 'Rất tệ',
          2: 'Chê nhá',
          3: 'Không ưng lắm',
          4: 'Hài lòng',
          5: 'Siêu hài lòng',
        };

        const serviceRating = review.service_rating || 0;
        const staffRating = review.staff_rating || 0;
        const serviceRatingText = ratingText[serviceRating] || 'Chưa đánh giá';
        const staffRatingText = ratingText[staffRating] || 'Chưa đánh giá';
        const stars = (rating) => '⭐'.repeat(Math.min(Math.max(rating, 0), 5));

        const reviewDate = review.created_at
          ? (() => {
              const date = new Date(review.created_at);
              const hh = String(date.getHours()).padStart(2, '0');
              const mm = String(date.getMinutes()).padStart(2, '0');
              const ss = String(date.getSeconds()).padStart(2, '0');
              const dd = String(date.getDate()).padStart(2, '0');
              const m = String(date.getMonth() + 1).padStart(2, '0');
              const yy = String(date.getFullYear()).slice(-2);
              return `${hh}:${mm}:${ss} ${dd}/${m}/${yy}`;
            })()
          : 'N/A';

        container.innerHTML = `
          <div class="review-detail-view">
            <!-- Header with Date -->
            <div class="review-detail-header">
              <h2>Chi tiết đánh giá</h2>
              <p class="review-date-badge">${reviewDate}</p>
            </div>

            <!-- Invoice Info -->
            <div class="review-section invoice-info-section">
              <h3 class="section-title">Thông tin hóa đơn</h3>
              <div class="info-grid info-grid-2">
                <div class="info-item">
                  <label>Mã hóa đơn</label>
                  <value>${invoice.invoice_id}</value>
                </div>
                <div class="info-item">
                  <label>Khách hàng</label>
                  <value>${invoice.customer_name}</value>
                </div>
              </div>
              <div class="info-grid info-grid-2">
                <div class="info-item">
                  <label>Dịch vụ</label>
                  <value>${review.service_name || 'N/A'}</value>
                </div>
                <div class="info-item">
                  <label>Thợ/Nhân viên</label>
                  <value>${review.staff_name || 'N/A'}</value>
                </div>
              </div>
            </div>

            <!-- Rating Section -->
            <div class="review-section rating-section">
              <h3 class="section-title">Đánh giá</h3>
              <div class="rating-grid">
                <div class="rating-item">
                  <div class="rating-label">Dịch vụ</div>
                  <div class="rating-stars">${stars(serviceRating)}</div>
                  <div class="rating-text">${serviceRatingText}</div>
                </div>
                <div class="rating-item">
                  <div class="rating-label">Nhân viên phục vụ</div>
                  <div class="rating-stars">${stars(staffRating)}</div>
                  <div class="rating-text">${staffRatingText}</div>
                </div>
              </div>
            </div>

            <!-- Feedback Section -->
            <div class="review-section feedback-section">
              <h3 class="section-title"><i class="fas fa-comment-dots"></i> Phản hồi của khách hàng</h3>
              ${
                review.service_feedback
                  ? `
                <div class="feedback-group">
                  <div class="feedback-label">Hài lòng dịch vụ:</div>
                  <div class="feedback-content">
                    ${review.service_feedback
                      .split(/[,;]/)
                      .map((item) => item.trim())
                      .filter((item) => item.length > 0)
                      .map((item) => `<span class="feedback-pill">${item}</span>`)
                      .join('')}
                  </div>
                </div>
              `
                  : ''
              }
              ${
                review.staff_feedback
                  ? `
                <div class="feedback-group">
                  <div class="feedback-label">Hài lòng thợ:</div>
                  <div class="feedback-content">
                    ${review.staff_feedback
                      .split(/[,;]/)
                      .map((item) => item.trim())
                      .filter((item) => item.length > 0)
                      .map((item) => `<span class="feedback-pill">${item}</span>`)
                      .join('')}
                  </div>
                </div>
              `
                  : ''
              }
            </div>

            <!-- Read-only Badge -->
            <div class="review-readonly-badge">
              <i class="fas fa-lock"></i> Chế độ xem
            </div>
          </div>
        `;

        // Load CSS file if not already loaded
        if (!document.getElementById('review-detail-css')) {
          const link = document.createElement('link');
          link.id = 'review-detail-css';
          link.rel = 'stylesheet';
          link.href =
            '/wp-content/plugins/checkin-mkt192-wp/frontend/assets/css/pages/app-tho/review-detail.css';
          document.head.appendChild(link);
        }
      }
    } catch (error) {
      console.error('Error loading review detail:', error);
      const container = document.getElementById('reviewDetailContainer');
      if (container) {
        container.innerHTML = `
          <div class="review-error-message">
            <i class="fas fa-exclamation-triangle"></i>
            <h3>Lỗi khi tải dữ liệu</h3>
            <p>${error.message}</p>
          </div>
        `;
      }
    }
  }

  // Đồng bộ giao diện bộ lọc thời gian của Dịch vụ
  function updateServiceFilterUI() {
    const buttons = document.querySelectorAll('.service-time-filter-btn');
    buttons.forEach((btn) => {
      if (btn.dataset.filter === currentServiceFilter) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });
  }

  // Đồng bộ giao diện bộ lọc thời gian của Báo cáo
  function updateReportFilterUI() {
    try {
      const saved = localStorage.getItem('currentReportFilter') || currentReportFilter || 'today';
      currentReportFilter = saved;

      // Cập nhật giá trị select
      const select = document.getElementById('quickReportDateFilter');
      if (select) {
        select.value = saved;
      }

      // Ẩn/hiện container chọn ngày tùy chỉnh
      const customContainer = document.getElementById('customDateReportContainer');
      if (!customContainer) return;
      if (saved === 'custom') {
        customContainer.classList.remove('hidden');
        const start = localStorage.getItem('customStartReportDate') || '';
        const end = localStorage.getItem('customEndReportDate') || '';
        const startInput = document.getElementById('customStartReportDate');
        const endInput = document.getElementById('customEndReportDate');
        if (startInput && endInput) {
          if (start) startInput.value = start;
          if (end) endInput.value = end;
        }
      } else {
        customContainer.classList.add('hidden');
      }
    } catch (e) {}
  }

  // Đồng bộ giao diện bộ lọc thời gian của Lịch hẹn
  function updateBookingFilterUI() {
    try {
      const saved = localStorage.getItem('currentBookingFilter') || currentBookingFilter || 'today';
      currentBookingFilter = saved;

      // Cập nhật giá trị select
      const select = document.getElementById('quickBookingDateFilter');
      if (select) {
        select.value = saved;
      }

      // Ẩn/hiện container chọn ngày tùy chỉnh
      const customContainer = document.getElementById('customBookingDateContainer');
      if (!customContainer) return;
      if (saved === 'custom') {
        customContainer.classList.remove('hidden');
        const start = localStorage.getItem('customStartBookingDate') || '';
        const end = localStorage.getItem('customEndBookingDate') || '';
        const startInput = document.getElementById('customStartBookingDate');
        const endInput = document.getElementById('customEndBookingDate');
        if (startInput && endInput) {
          if (start) startInput.value = start;
          if (end) endInput.value = end;
        }
      } else {
        customContainer.classList.add('hidden');
      }
    } catch (e) {}
  }

  // ==============================
  // 15. Event Listeners
  // ==============================
  function setupEventListeners() {
    // Service time filter listeners
    document.addEventListener('click', async (e) => {
      const btn = e.target.closest('.service-time-filter-btn');
      if (!btn) return;

      const filter = btn.dataset.filter;

      currentServiceFilter = filter;
      try {
        localStorage.setItem('currentServiceFilter', filter);
      } catch (e) {}

      updateServiceFilterUI();

      // ✅ OPTIMIZED: Logic load data thông minh - Giảm tải localStorage cho thiết bị cũ
      // - Mặc định load 7days để giảm dung lượng localStorage
      // - thisMonth/lastMonth: LUÔN show loading và load data mới vì data lớn
      // - today, yesterday: dùng data 7days đã có
      // - 7days: dùng data đã có (default)

      if (filter === 'thisMonth') {
        // ✅ thisMonth: LUÔN show loading và load data mới (data lớn, cần load riêng)
        if (window.showPageLoader) {
          window.showPageLoader({
            text: 'Đang tải dữ liệu tháng này...',
            subtitle: 'Vui lòng đợi',
          });
        }
        try {
          await loadStaffInvoices('thisMonth');
        } finally {
          if (window.hidePageLoader) {
            window.hidePageLoader(100);
          }
        }
      } else if (filter === 'lastMonth') {
        // ✅ lastMonth: LUÔN show loading và load data mới
        if (window.showPageLoader) {
          window.showPageLoader({
            text: 'Đang tải dữ liệu tháng trước...',
            subtitle: 'Vui lòng đợi',
          });
        }
        try {
          await loadStaffInvoices('lastMonth');
        } finally {
          if (window.hidePageLoader) {
            window.hidePageLoader(100);
          }
        }
      } else if (
        (filter === 'today' || filter === 'yesterday' || filter === '7days') &&
        loadedDataPeriod !== '7days' &&
        loadedDataPeriod !== 'thisMonth'
      ) {
        // ✅ Nếu đang có data lastMonth/custom mà chọn filter ngắn hạn → load lại 7days
        if (window.showPageLoader) {
          window.showPageLoader({ text: 'Đang tải dữ liệu...', subtitle: 'Vui lòng đợi' });
        }
        try {
          await loadStaffInvoices('7days');
        } finally {
          if (window.hidePageLoader) {
            window.hidePageLoader(100);
          }
        }
      }
      // else: today/yesterday/7days với data 7days đã có → render trực tiếp, KHÔNG loading

      // Render lại từ data hiện có
      renderInvoiceList(currentServiceFilter);
      renderInvoiceTabs();
      await renderCurrentInvoice();
    });

    if (elements.servicesTab) {
      elements.servicesTab.addEventListener('click', async () => {
        currentTab = 'services';
        updateTabState();

        // Khi quay về tab Dịch vụ luôn reset bộ lọc về Hôm nay
        try {
          currentServiceFilter = 'today';
          localStorage.setItem('currentServiceFilter', 'today');
          localStorage.removeItem('serviceCustomStartDate');
          localStorage.removeItem('serviceCustomEndDate');
          serviceCustomDateRange = null;
        } catch (e) {}
        // Nếu user từng chọn từ modal "Xem thêm", huỷ trạng thái đó
        isFromMoreTab = false;
        selectedFromMore = false;

        updateServiceFilterUI();

        // ✅ OPTIMIZED: Chỉ gọi API nếu invoicesData rỗng
        if (invoicesData.length === 0) {
          await loadStaffInvoices('today');
        }

        // ✅ GIỮ NGUYÊN hóa đơn hiện tại, không chuyển về mới nhất
        // Chỉ render lại UI
        renderInvoiceList(currentServiceFilter);
        renderInvoiceTabs();
        scrollToInvoiceTab(currentInvoiceIndex); // Scroll đến tab active
        await renderCurrentInvoice();

        loadServiceGroups();
      });
    }

    if (elements.productsTab) {
      elements.productsTab.addEventListener('click', async () => {
        currentTab = 'products';
        updateTabState();

        // ✅ CACHE-FIRST: Load từ localStorage trước (như services tab)
        const cachedProductGroups = getProductGroupsFromLocalStorage();
        const cachedProducts = getProductsFromLocalStorage();

        if (cachedProductGroups && cachedProducts) {
          // Hiển thị data cache ngay lập tức
          renderProductGroups();
        } else {
          // Nếu chưa có cache, load từ API
          try {
            const productGroups = await fetchAPI('product-groups');
            if (productGroups && Array.isArray(productGroups)) {
              saveProductGroupsToLocalStorage(productGroups);
            }

            const products = await fetchAPI('products');
            const productData = Array.isArray(products) ? products : products?.data || [];
            if (productData.length > 0) {
              saveProductsToLocalStorage(productData);
            }

            renderProductGroups();
          } catch (e) {
            console.error('Failed to load products:', e);
            renderProductGroups(); // Vẫn render để hiển thị thông báo lỗi
          }
        }
      });
    }

    if (elements.sidebarToggle) {
      elements.sidebarToggle.addEventListener('click', toggleSidebar);
    }

    if (elements.mobileSidebarToggle) {
      elements.mobileSidebarToggle.addEventListener('click', () => {
        elements.sidebar.classList.toggle('open');
      });
    }

    if (elements.serviceGroups) {
      elements.serviceGroups.addEventListener('click', handleServiceGroupClick);
    }

    if (elements.addInvoiceTab) {
      elements.addInvoiceTab.addEventListener('click', addNewInvoice);
    }

    if (elements.searchCustomerBtn) {
      elements.searchCustomerBtn.addEventListener('click', searchCustomer);
    }

    if (elements.saveNewCustomerBtn) {
      elements.saveNewCustomerBtn.addEventListener('click', saveNewCustomer);
    }

    if (elements.closeStaffModal) {
      elements.closeStaffModal.addEventListener('click', () => {
        if (elements.selectStaffModal) {
          elements.selectStaffModal.classList.add('hidden');
        }
      });
    }

    if (elements.confirmStaffBtn) {
      elements.confirmStaffBtn.addEventListener('click', () => {
        // Always prioritize pill selection over pre-selected staff
        const selectedStaffFromPill = getSelectedStaffFromList();
        if (selectedStaffFromPill && currentServiceForStaff) {
          if (currentServiceForStaff.editIndex !== undefined) {
            // Chế độ chỉnh sửa: Cập nhật thợ cho dịch vụ hiện có
            const quantityInput = elements.selectStaffModal.querySelector('.quantity-input');
            const quantity = quantityInput ? parseInt(quantityInput.value) || 1 : 1;
            updateServiceStaff(
              currentServiceForStaff.editIndex,
              selectedStaffFromPill.id,
              selectedStaffFromPill.name,
              quantity
            );
          } else {
            // Chế độ thêm mới: Kiểm tra type để gọi đúng hàm
            const quantityInput = elements.selectStaffModal.querySelector('.quantity-input');
            const quantity = quantityInput ? parseInt(quantityInput.value) || 1 : 1;

            if (currentServiceForStaff.type === 'product') {
              // Thêm sản phẩm
              addProductToInvoice(
                currentServiceForStaff.id,
                selectedStaffFromPill.id,
                selectedStaffFromPill.name,
                quantity
              );
            } else {
              // Thêm dịch vụ
              addServiceToInvoice(
                currentServiceForStaff.id,
                selectedStaffFromPill.id,
                selectedStaffFromPill.name,
                quantity
              );
            }
          }
          if (elements.selectStaffModal) {
            elements.selectStaffModal.classList.add('hidden');
          }
          // Reset currentServiceForStaff
          currentServiceForStaff = null;
        } else if (currentServiceForStaff && currentServiceForStaff.selectedStaffId) {
          // Fallback to pre-selected staff if no pill selection (shouldn't happen in normal flow)
          if (currentServiceForStaff.editIndex !== undefined) {
            // Chế độ chỉnh sửa: Cập nhật thợ cho dịch vụ hiện có
            const quantityInput = elements.selectStaffModal.querySelector('.quantity-input');
            const quantity = quantityInput ? parseInt(quantityInput.value) || 1 : 1;
            updateServiceStaff(
              currentServiceForStaff.editIndex,
              currentServiceForStaff.selectedStaffId,
              currentServiceForStaff.selectedStaffName,
              quantity
            );
          } else {
            // Chế độ thêm mới: Kiểm tra type để gọi đúng hàm
            const quantityInput = elements.selectStaffModal.querySelector('.quantity-input');
            const quantity = quantityInput ? parseInt(quantityInput.value) || 1 : 1;

            if (currentServiceForStaff.type === 'product') {
              // Thêm sản phẩm
              addProductToInvoice(
                currentServiceForStaff.id,
                currentServiceForStaff.selectedStaffId,
                currentServiceForStaff.selectedStaffName,
                quantity
              );
            } else {
              // Thêm dịch vụ
              addServiceToInvoice(
                currentServiceForStaff.id,
                currentServiceForStaff.selectedStaffId,
                currentServiceForStaff.selectedStaffName,
                quantity
              );
            }
          }
          if (elements.selectStaffModal) {
            elements.selectStaffModal.classList.add('hidden');
          }
          // Reset currentServiceForStaff
          currentServiceForStaff = null;
        } else {
          showWarning('Vui lòng chọn một thợ');
        }
      });
    }

    if (elements.closePaymentModal) {
      elements.closePaymentModal.addEventListener('click', () => {
        if (elements.paymentMethodModal) {
          elements.paymentMethodModal.classList.add('hidden');
        }
        stopPaymentPolling();
      });
    }

    if (elements.createInvoiceBtn) {
      elements.createInvoiceBtn.addEventListener('click', async () => {
        const invoice = invoices[currentInvoiceIndex];
        if (invoice.status === 'paid') {
          showWarning('Không thể chỉnh sửa hóa đơn đã thanh toán');
          return;
        }
        try {
          elements.createInvoiceBtn.disabled = true;
          elements.createInvoiceBtn.innerHTML = '<span class="loading-spinner"></span> Loading...';
          await saveInvoiceToDB();
          // ✅ Không cần gọi renderCurrentInvoice() vì saveInvoiceToDB() đã gọi rồi
        } catch (error) {
          showError('Có lỗi xảy ra khi tạo hóa đơn.');
        } finally {
          elements.createInvoiceBtn.disabled = false;
          elements.createInvoiceBtn.innerHTML = 'Tạo hóa đơn';
        }
      });
    }
    if (elements.payInvoiceBtn) {
      elements.payInvoiceBtn.addEventListener('click', () => {
        if (!invoices || !invoices[currentInvoiceIndex]) {
          showWarning('Không có hóa đơn nào để thanh toán. Vui lòng tạo hóa đơn mới.');
          return;
        }
        const invoice = invoices[currentInvoiceIndex];
        if (!invoice.invoice_id) {
          showWarning('Vui lòng tạo hóa đơn trước khi thanh toán');
          return;
        }
        openPaymentMethodModal(invoice.invoice_id);
      });
    }

    if (elements.uploadImageBtn) {
      elements.uploadImageBtn.addEventListener('click', () => {
        openUploadImageModalService(currentInvoiceIndex, false);
      });
    }

    if (elements.uploadImageFeedbackBtn) {
      elements.uploadImageFeedbackBtn.addEventListener('click', () => {
        openUploadImageModalService(currentInvoiceIndex, false, true); // isFeedback = true
      });
    }

    if (elements.notImageBtn) {
      elements.notImageBtn.disabled = false;
      elements.notImageBtn.addEventListener('click', () =>
        handleNotImageClick(invoices[currentInvoiceIndex])
      );
    }

    if (elements.refreshStaffBtn) {
      elements.refreshStaffBtn.addEventListener('click', async () => {
        try {
          const staffData = await fetchAPI('staff');
          saveStaffToLocalStorage(staffData);
          toastSuccess('Danh sách thợ đã được làm mới');
          if (currentServiceForStaff) {
            openStaffModal(currentServiceForStaff);
          }
        } catch (error) {
          showError('Lỗi khi làm mới danh sách thợ');
        }
      });
    }

    // Thêm sự kiện change cho promoCodeSelect
    if (elements.promoListSelect) {
      elements.promoListSelect.addEventListener('change', async () => {
        const invoice = invoices[currentInvoiceIndex];
        invoice.promoName = elements.promoListSelect.value || null;
        invoice.isManualPromo = !!invoice.promoName; // Đánh dấu chọn thủ công
        invoice.isManualDiscount = false; // Chọn CTKM → bỏ chế độ giảm thủ công
        invoice.isDirty = true;
        await updatePromoAndDiscount(invoice);
        await calculateInvoiceTotals();
        saveInvoicesToLocalStorage();
        await saveInvoiceToDB();
        // ✅ Refresh data sau khi thay đổi CTKM
        clearInvoicesDataCache();
        try {
          await loadStaffInvoices('thisMonth');
          if (currentSection === 'invoices') {
            renderInvoiceList();
          }
        } catch (e) {
          console.error('Failed to reload after promo change:', e);
        }
      });
    }

    if (elements.discountAmount) {
      elements.discountAmount.addEventListener('input', async (e) => {
        if (elements.discountType.value === 'percent') {
          e.target.value = e.target.value.replace(/[^\d]/g, '');
        } else {
          e.target.value = formatNumberInput(e.target.value);
        }
        // ✅ CTKM = "Không có" → người dùng gõ vào ô này là GIẢM GIÁ THỦ CÔNG
        const invoice = invoices[currentInvoiceIndex];
        if (invoice && (!invoice.promoName || invoice.promoName === 'Không có')) {
          invoice.isManualDiscount = true;
          invoice.isDirty = true;
        }
        await calculateInvoiceTotals();
      });

      // Lưu DB khi rời ô giảm giá (giống ô tips)
      elements.discountAmount.addEventListener('blur', async () => {
        const invoice = invoices[currentInvoiceIndex];
        if (invoice && invoice.isDirty && invoice.invoice_id) {
          saveInvoicesToLocalStorage();
          await saveInvoiceToDB(invoice);
        }
      });
    }

    if (elements.tipsAmount) {
      elements.tipsAmount.addEventListener('input', async (e) => {
        e.target.value = formatNumberInput(e.target.value);
        await calculateInvoiceTotals();
      });

      elements.tipsAmount.addEventListener('blur', async () => {
        saveInvoicesToLocalStorage();
        await saveInvoiceToDB();
        // ✅ Refresh data sau khi thay đổi tips
        clearInvoicesDataCache();
        try {
          await loadStaffInvoices('thisMonth');
          if (currentSection === 'invoices') {
            renderInvoiceList();
          }
        } catch (e) {
          console.error('Failed to reload after tips change:', e);
        }
      });
    }

    if (elements.discountType) {
      elements.discountType.addEventListener('change', async () => {
        const invoice = invoices[currentInvoiceIndex];
        if (elements.discountType.value === 'percent') {
          elements.discountAmount.value =
            invoice.discount > 0
              ? String(Math.round((invoice.discount / invoice.subtotal) * 100))
              : '0';
        } else {
          elements.discountAmount.value = formatNumberInput(String(invoice.discount));
        }
        // Đổi kiểu %/đ khi không có CTKM cũng là thao tác giảm giá thủ công
        if (invoice && (!invoice.promoName || invoice.promoName === 'Không có')) {
          invoice.isManualDiscount = true;
          invoice.isDirty = true;
        }
        await calculateInvoiceTotals();
      });
    }

    // Trong hàm setupEventListeners()
    if (elements.paymentMethodSelect) {
      elements.paymentMethodSelect.addEventListener('change', async () => {
        const invoice = invoices[currentInvoiceIndex];
        const selectedMethod = elements.paymentMethodSelect.value;

        // Xử lý phương thức Kết hợp
        const combinedSection = document.getElementById('combinedPaymentDetailsSection');
        if (selectedMethod === 'combined') {
          // Hiển thị section nhập chi tiết và khởi tạo giá trị
          if (combinedSection) {
            combinedSection.classList.remove('hidden');
            const total = invoice.total || 0;
            const cashInput = document.getElementById('combinedCashInline');
            const bankInput = document.getElementById('combinedBankInline');
            if (cashInput) cashInput.value = formatNumberInput(String(Math.floor(total / 2)));
            if (bankInput)
              bankInput.value = formatNumberInput(String(total - Math.floor(total / 2)));
            // Lưu combined details
            invoice.combinedPaymentDetails = {
              cash: Math.floor(total / 2),
              bank: total - Math.floor(total / 2),
            };
          }
          // Chỉ lưu local, KHÔNG lưu DB ngay - đợi user nhập xong
          invoice.paymentMethod = selectedMethod;
          invoice.isDirty = true;
          saveInvoicesToLocalStorage();
          // Không gọi saveInvoiceToDB() ở đây - sẽ lưu khi blur khỏi input
        } else {
          // Ẩn section combined nếu chọn phương thức khác
          if (combinedSection) combinedSection.classList.add('hidden');
          invoice.combinedPaymentDetails = null;

          invoice.paymentMethod = selectedMethod || null;
          invoice.isDirty = true;
          saveInvoicesToLocalStorage();
          await saveInvoiceToDB();
          // ✅ Refresh data sau khi thay đổi phương thức thanh toán
          clearInvoicesDataCache();
          try {
            await loadStaffInvoices('thisMonth');
            if (currentSection === 'invoices') {
              renderInvoiceList();
            }
          } catch (e) {
            console.error('Failed to reload after payment method change:', e);
          }
        }
      });
    }

    // Event listeners cho combined payment inputs
    const combinedCashInline = document.getElementById('combinedCashInline');
    const combinedBankInline = document.getElementById('combinedBankInline');
    const confirmCombinedBtn = document.getElementById('confirmCombinedPaymentBtn');

    if (combinedCashInline) {
      combinedCashInline.addEventListener('input', function () {
        this.value = formatNumberInput(this.value);
        updateCombinedPaymentFromInline();
      });
    }

    if (combinedBankInline) {
      combinedBankInline.addEventListener('input', function () {
        this.value = formatNumberInput(this.value);
        updateCombinedPaymentFromInline();
      });
    }

    // Nút xác nhận combined payment
    if (confirmCombinedBtn) {
      confirmCombinedBtn.addEventListener('click', async function () {
        await saveCombinedPaymentToDB();
        toastSuccess('Đã lưu phương thức kết hợp', 'Thành công');
      });
    }

    // Gắn sự kiện cho nút filter hóa đơn
    document.querySelectorAll('.time-filter-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        const filter = btn.dataset.filter;
        saveCurrentFilter(filter);
        updateFilterButtons();
        renderInvoiceList();
      });
    });

    // Khôi phục trạng thái filter khi vào tab hóa đơn
    if (currentSection === 'invoices') {
      updateFilterButtons();
      renderInvoiceList();
    }

    document.querySelectorAll('.menu-item').forEach((item) => {
      item.addEventListener('click', (e) => {
        const section = item.dataset.section;
        if (section) {
          handleNavigation(section);
        }
      });
    });

    // 📱 Thanh điều hướng bottom native cho mobile
    initBottomNav();
    // 📱 Nút "Lọc" thu gọn bộ lọc hoá đơn trên mobile
    initMobileFilterToggle();

    document.querySelectorAll('.settings-menu-item').forEach((item) => {
      item.addEventListener('click', (e) => {
        e.preventDefault();
        handleSettingsNavigation(item.dataset.subsection);
      });
    });

    document.querySelectorAll('.promo-tab-item').forEach((item) => {
      item.addEventListener('click', (e) => {
        e.preventDefault();
        handlePromoTabNavigation(item.dataset.tab);
      });
    });

    const promoForm = document.getElementById('promoForm');
    if (promoForm) {
      promoForm.addEventListener('submit', saveCTKM);
    }

    if (elements.voucherForm) {
      elements.voucherForm.addEventListener('submit', saveCTKM);
    }

    if (elements.cancelVoucherBtn) {
      elements.cancelVoucherBtn.addEventListener('click', hideVoucherForm);
    }

    const cancelPromoBtn = document.getElementById('cancelPromoBtn');
    if (cancelPromoBtn) {
      cancelPromoBtn.addEventListener('click', hidePromoForm);
    }

    // Sự kiện cho nút Thêm mới CTKM
    const addNewPromoBtn = document.getElementById('addNewPromoBtn');
    if (addNewPromoBtn) {
      addNewPromoBtn.addEventListener('click', () => showPromoForm(false));
    }

    // Sự kiện cho nút Thêm mới Voucher
    const addNewVoucherBtn = document.getElementById('addNewVoucherBtn');
    if (addNewVoucherBtn) {
      addNewVoucherBtn.addEventListener('click', () => showVoucherForm(false));
    }

    if (elements.inventoryCheckBtn) {
      elements.inventoryCheckBtn.addEventListener('click', handleInventoryCheck);
    }

    if (elements.stockTransactionBtn) {
      elements.stockTransactionBtn.addEventListener('click', handleStockTransaction);
    }

    // Event listener for inventory items per page
    const inventoryItemsPerPageSelect = document.getElementById('inventory-items-per-page');
    if (inventoryItemsPerPageSelect) {
      inventoryItemsPerPageSelect.addEventListener('change', (e) => {
        inventoryItemsPerPage = parseInt(e.target.value);
        currentInventoryPage = 1;
        localStorage.setItem('inventoryItemsPerPage', inventoryItemsPerPage);
        localStorage.setItem('currentInventoryPage', 1);
        loadInventoryList();
      });
    }

    // Event listener for inventory refresh button
    const refreshInventoryBtn = document.getElementById('refreshInventoryBtn');
    if (refreshInventoryBtn) {
      refreshInventoryBtn.addEventListener('click', refreshInventoryList);
    }

    // Sự kiện cho select lọc thời gian của Report
    const quickReportDateFilter = document.getElementById('quickReportDateFilter');
    if (quickReportDateFilter) {
      quickReportDateFilter.addEventListener('change', async () => {
        const selectedValue = quickReportDateFilter.value;
        currentReportFilter = selectedValue;
        localStorage.setItem('currentReportFilter', currentReportFilter);

        // Nếu chọn "custom", hiển thị form
        if (currentReportFilter === 'custom') {
          document.getElementById('customDateReportContainer').classList.remove('hidden');
          return;
        }

        document.getElementById('customDateReportContainer').classList.add('hidden');

        // ✅ Show page loader cho các filter cần load dữ liệu lớn
        const needsLoader = selectedValue === 'lastMonth' || selectedValue === 'thisMonth';
        if (needsLoader && window.showPageLoader) {
          window.showPageLoader({ text: 'Đang tải báo cáo...', subtitle: 'Vui lòng đợi' });
        }
        try {
          await loadReportData();
        } catch (error) {
          console.error('Error loading report:', error);
        } finally {
          if (needsLoader) {
            await new Promise((resolve) => setTimeout(resolve, 100));
            if (window.hidePageLoader) {
              window.hidePageLoader(100);
            }
          }
        }
      });
    }

    // Sự kiện cho nút lọc tùy chỉnh của Report
    const applyCustomReportDateBtn = document.getElementById('applyCustomReportDate');
    if (applyCustomReportDateBtn) {
      applyCustomReportDateBtn.addEventListener('click', async () => {
        const startDate = document.getElementById('customStartReportDate').value;
        const endDate = document.getElementById('customEndReportDate').value;
        if (startDate && endDate) {
          if (new Date(startDate) > new Date(endDate)) {
            showWarning('Ngày bắt đầu phải nhỏ hơn hoặc bằng ngày kết thúc');
            return;
          }

          // ✅ Button loader
          setButtonLoading(applyCustomReportDateBtn, 'Đang lọc...');

          localStorage.setItem('customStartReportDate', startDate);
          localStorage.setItem('customEndReportDate', endDate);
          currentReportFilter = 'custom';
          localStorage.setItem('currentReportFilter', currentReportFilter);

          try {
            await loadReportData();
          } catch (error) {
            console.error('Error loading custom report:', error);
          } finally {
            resetButtonLoading(applyCustomReportDateBtn);
          }
        } else {
          showWarning('Vui lòng nhập cả ngày bắt đầu và ngày kết thúc');
        }
      });
    }

    // Gắn sự kiện change cho select
    const staffReportFilter = document.getElementById('staffReportFilter');
    if (staffReportFilter) {
      staffReportFilter.addEventListener('change', handleStaffFilterChange);
    }

    // Sự kiện toggle menu cài đặt
    if (elements.settingsToggle) {
      elements.settingsToggle.addEventListener('click', (event) => {
        event.stopPropagation(); // Ngăn click lan ra document
        toggleSettingsMenu();
      });
    }

    // Sự kiện toggle menu cài đặt từ avatar
    const sidebarUserAvatar = document.getElementById('sidebarUserAvatar');
    if (sidebarUserAvatar) {
      sidebarUserAvatar.addEventListener('click', (event) => {
        event.stopPropagation(); // Ngăn click lan ra document
        toggleSettingsMenu();
      });
    }

    // Sự kiện toggle menu cài đặt
    if (elements.userAvatar) {
      elements.userAvatar.addEventListener('click', (event) => {
        event.stopPropagation(); // Ngăn click lan ra document
        toggleUserMenu();
      });
    }

    if (elements.staffStatusToggle && elements.toggleSwitch) {
      elements.staffStatusToggle.addEventListener('change', async () => {
        if (elements.staffStatusToggle.disabled) return;
        const newStatus = elements.staffStatusToggle.checked ? 'ON' : 'OFF';
        await updateStaffStatus(newStatus);
      });

      // Thêm sự kiện click cho div toggle-switch để hỗ trợ click trực tiếp
      elements.toggleSwitch.addEventListener('click', () => {
        if (elements.staffStatusToggle.disabled) return;
        elements.staffStatusToggle.checked = !elements.staffStatusToggle.checked;
        elements.staffStatusToggle.dispatchEvent(new Event('change'));
      });

      // Thêm sự kiện keydown để hỗ trợ điều khiển bằng bàn phím
      elements.toggleSwitch.addEventListener('keydown', (e) => {
        if (elements.staffStatusToggle.disabled) return;
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          elements.staffStatusToggle.checked = !elements.staffStatusToggle.checked;
          elements.staffStatusToggle.dispatchEvent(new Event('change'));
        }
      });
    }
    updateStaffStatusUI();

    // Sự kiện đăng xuất
    if (elements.logoutButton) {
      elements.logoutButton.addEventListener('click', handleLogout);
    }

    // Sự kiện đăng xuất
    if (elements.headerLogoutButton) {
      elements.headerLogoutButton.addEventListener('click', handleLogout);
    }

    const clearLocalStorageBtn = document.getElementById('clearLocalStorageBtn');
    if (clearLocalStorageBtn) {
      clearLocalStorageBtn.addEventListener('click', clearAllLocalStorage);
    }

    // Sự kiện click vào text phiên bản để xóa cache
    const appVersion = document.getElementById('appVersion');
    if (appVersion) {
      appVersion.addEventListener('click', async () => {
        const confirmed = await showConfirm(
          'Bạn có chắc muốn xóa tất cả dữ liệu bộ nhớ đệm của ứng dụng?',
          'Xác nhận xóa'
        );
        if (confirmed) {
          clearAllLocalStorage();
        }
      });
    }

    // Sự kiện đóng modal clear cache
    const closeClearCacheModal = document.getElementById('closeClearCacheModal');
    if (closeClearCacheModal) {
      closeClearCacheModal.addEventListener('click', () => {
        const modal = document.getElementById('clearCacheModal');
        if (modal) {
          modal.classList.add('hidden');
        }
      });
    }

    // Sự kiện hủy modal clear cache
    const cancelClearCache = document.getElementById('cancelClearCache');
    if (cancelClearCache) {
      cancelClearCache.addEventListener('click', () => {
        const modal = document.getElementById('clearCacheModal');
        if (modal) {
          modal.classList.add('hidden');
        }
      });
    }

    // Sự kiện xác nhận xóa cache
    const confirmClearCache = document.getElementById('confirmClearCache');
    if (confirmClearCache) {
      confirmClearCache.addEventListener('click', () => {
        clearAllLocalStorage();
        const modal = document.getElementById('clearCacheModal');
        if (modal) {
          modal.classList.add('hidden');
        }
      });
    }

    // Sự kiện quét mã QR Booking
    if (elements.scanQrBtn) {
      elements.scanQrBtn.addEventListener('click', async () => {
        if (typeof Html5Qrcode === 'undefined') {
          showError('Thư viện quét QR chưa được tải. Vui lòng thêm thư viện html5-qrcode.');
          return;
        }

        // Tạo modal động
        const qrModal = document.createElement('div');
        qrModal.id = 'qrModal';
        qrModal.style =
          'position:fixed;top:0;left:0;width:100%;height:100%;background:#000000cc;display:flex;justify-content:center;align-items:center;z-index:9999;';
        qrModal.innerHTML = `
    <div class="qr-modal-content">
        <button id="closeQrModal" class="qr-modal-close">✖</button>
        <div id="qr-reader" class="qr-reader-box"></div>
    </div>
`;
        document.body.appendChild(qrModal);

        // Khởi tạo quét QR
        const qrCodeScanner = new Html5Qrcode('qr-reader');
        try {
          await qrCodeScanner.start(
            { facingMode: 'environment' },
            { fps: 10, qrbox: 250 },
            (decodedText) => {
              document.getElementById('customerPhone').value = decodedText;
              qrCodeScanner
                .stop()
                .then(() => {
                  document.body.removeChild(qrModal);
                  // Gọi tìm kiếm khách hàng ngay sau khi quét
                  searchCustomer(true);
                })
                .catch((err) => {
                  document.body.removeChild(qrModal);
                });
            },
            (errorMessage) => {
              // Bỏ qua lỗi đọc liên tục
            }
          );
        } catch (err) {
          showError('Không thể khởi động quét QR: ' + err.message);
          document.body.removeChild(qrModal);
        }

        // Xử lý đóng modal
        document.getElementById('closeQrModal').addEventListener('click', () => {
          qrCodeScanner
            .stop()
            .then(() => {
              document.body.removeChild(qrModal);
            })
            .catch((err) => {
              document.body.removeChild(qrModal);
            });
        });
      });
    }
  }

  // ==============================
  // 16. Initialization
  // ==============================
  function applyBookingColumnVisibility() {
    const settings = JSON.parse(localStorage.getItem('booking_columns') || '{}');
    const table = document.getElementById('bookingsListTabs');
    if (!table) return;

    BOOKING_COLUMN_CONFIG.forEach((col, idx) => {
      const shouldShow = col.locked || settings[col.key] !== false;
      const display = shouldShow ? '' : 'none';

      // Áp dụng cho header
      const header = table.querySelector(`thead th:nth-child(${idx + 1})`);
      if (header) header.style.display = display;

      // Áp dụng cho tất cả các ô trong cột
      table.querySelectorAll(`tbody td:nth-child(${idx + 1})`).forEach((cell) => {
        cell.style.display = display;
      });
    });
  }

  // ==============================
  // 13. INITIALIZATION & APP SETUP
  // ==============================

  async function initializeApp() {
    perfLog.mark('🚀 START initializeApp');

    // Show page loader at app start
    if (window.showPageLoader) {
      window.showPageLoader({
        text: 'Đang khởi tạo ứng dụng...',
        subtitle: 'Vui lòng đợi...',
      });
    }
    perfLog.mark('✅ Page loader shown');

    // CRITICAL FIX: Clear legacy localStorage với branch_name trước khi init BranchHelper
    const legacyBranchName = localStorage.getItem('checkin_current_branch');
    if (
      legacyBranchName &&
      typeof legacyBranchName === 'string' &&
      !legacyBranchName.match(/^\d+$/)
    ) {
      localStorage.removeItem('checkin_current_branch');
      localStorage.removeItem('checkin_current_branch_id');
    }
    perfLog.mark('✅ Legacy localStorage cleared');

    // 🚀 PRIORITY 1: Core initialization (blocking - cần thiết)
    // Khởi tạo BranchHelper - sẽ tự động lấy branch từ staff table
    if (typeof BranchHelper !== 'undefined') {
      branchHelper = new BranchHelper();
      await branchHelper.initialize().catch(() => {});
      currentBranch = branchHelper.getCurrentBranchName() || '';
      currentBranchFilter = currentBranch;

      // ✅ Expose branchHelper to global for other modules (shift-management, etc.)
      window.branchHelper = branchHelper;

      // ✅ Register callback để clear cache và reload data khi branch thay đổi
      branchHelper.on('onBranchChange', async (data) => {
        // ✅ CRITICAL: Update currentBranch và currentBranchFilter khi branch thay đổi
        // BranchHelper gửi: { oldBranch, newBranch, oldBranchId, newBranchId, isManual }
        currentBranch = data.newBranch || '';
        currentBranchFilter = currentBranch;
        console.log('🔄 Branch changed to:', currentBranch, 'ID:', data.newBranchId);

        // Clear all caches when branch changes
        cachedKpiData = {};
        cachedSocialPosts = {};
        lastLoadedStaff = null;

        // Clear inventory và transaction cache
        clearInventoryCache();
        clearTransactionCache();

        // Clear other localStorage caches for this branch
        localStorage.removeItem('bookingsList');
        localStorage.removeItem('invoicesList');
        localStorage.removeItem('servicesList');
        localStorage.removeItem('productsList'); // ✅ ADDED: Clear products cache
        localStorage.removeItem('staffList');

        // ✅ CRITICAL: Clear invoicesData để force reload từ API
        invoicesData = [];
        window.invoicesData = [];

        console.log('✅ All caches cleared after branch change');

        // ✅ Reload data với branch mới (chỉ reload nếu element đang hiển thị)
        const inventoryList = document.getElementById('inventoryList');
        const transactionList = document.getElementById('transactionList');
        const bookingList = document.getElementById('bookingsListTabs');
        const invoiceList = document.getElementById('invoiceList');
        const reportsContent = document.getElementById('reportsContent');
        const shiftsContent = document.getElementById('shiftsContent');

        if (inventoryList) {
          loadInventoryList(true);
        }
        if (transactionList) {
          loadInventoryTransactions(currentTransactionFilter, true);
        }
        // ✅ Reload bookings nếu đang hiển thị (gọi renderBookingList thay vì loadBookingList)
        if (bookingList && typeof renderBookingList === 'function') {
          renderBookingList();
        }
        // ✅ Reload invoices nếu đang hiển thị - PHẢI gọi loadStaffInvoices trước để lấy data mới
        if (invoiceList) {
          await loadStaffInvoices(currentFilter);
          if (typeof renderInvoiceList === 'function') {
            renderInvoiceList();
          }
        }
        // ✅ Reload reports nếu đang hiển thị
        if (reportsContent && !reportsContent.classList.contains('hidden')) {
          // Clear report cache
          reportDataCache = null;
          loadedReportDataPeriod = null;
          if (typeof loadReportData === 'function') {
            loadReportData();
          }
        }
        // ✅ Reload shift management nếu đang hiển thị
        if (shiftsContent && !shiftsContent.classList.contains('hidden')) {
          if (window.AppThoShiftManagement) {
            if (typeof window.AppThoShiftManagement.clearCache === 'function') {
              window.AppThoShiftManagement.clearCache();
            }
            if (typeof window.AppThoShiftManagement.refresh === 'function') {
              window.AppThoShiftManagement.refresh();
            }
          }
        }
        // ✅ Reload dashboard nếu đang hiển thị (reset cache + refresh)
        if (window.AppThoDashboard) {
          // Reset dashboard cache để force reload từ API
          if (typeof window.AppThoDashboard.resetCache === 'function') {
            window.AppThoDashboard.resetCache();
          }
          // Clear global data cache
          window.invoicesData = [];
          window.bookingsData = [];
          // Refresh dashboard với data mới
          if (typeof window.AppThoDashboard.refresh === 'function') {
            window.AppThoDashboard.refresh();
          }
        }
      });
    }
    perfLog.mark('✅ BranchHelper initialized');

    // ✅ Cache sẽ được clear tự động khi branch change (qua callback)
    // Không clear cache ở đây để tận dụng cache từ lần trước
    perfLog.mark('✅ Cache strategy: reuse existing');

    // updateUserInfo() now handles loading role for sidebar display
    // No need for separate getCurrentUserRole() call - using permissions instead
    await updateUserInfo().then(() => perfLog.mark('✅ User info updated'));

    // Initialize theme (sync - nhanh)
    try {
      initTheme();
    } catch (e) {}
    updateAppVersion();
    // ❌ Removed clearExpiredInvoicesFromLocalStorage - không còn sử dụng
    perfLog.mark('✅ Theme + version');

    // Render branch selector (sync - nhanh)
    try {
      renderAppBranchSelector();
    } catch (e) {}
    perfLog.mark('✅ Branch selector rendered');

    // Cache branches to localStorage
    if (branchHelper && branchHelper.branches) {
      saveBranchesToLocalStorage(branchHelper.branches);
    }

    // Cache payment methods to localStorage
    if (checkinData.paymentQRs) {
      savePaymentMethodsToLocalStorage(checkinData.paymentQRs);
    }
    perfLog.mark('✅ Branches and payment methods cached');

    // 🚀 PRIORITY 2: Load từ localStorage (nhanh - không chặn)
    await loadInvoicesFromLocalStorage();
    perfLog.mark('✅ Invoices loaded from localStorage');

    // Setup filters
    // 🔧 FIX: Luôn reset về 'today' khi load trang để đảm bảo hiển thị đúng hóa đơn hôm nay
    // Điều này đảm bảo empty state hiển thị khi không có hóa đơn hôm nay
    currentFilter = 'today';
    localStorage.setItem('currentFilter', 'today');
    currentServiceFilter = 'today';
    try {
      localStorage.setItem('currentServiceFilter', 'today');
      localStorage.removeItem('serviceCustomStartDate');
      localStorage.removeItem('serviceCustomEndDate');
      serviceCustomDateRange = null;
    } catch (e) {}
    perfLog.mark('✅ Filters setup');

    // Chọn hoá đơn mới nhất từ localStorage (nếu có)
    if (invoices && invoices.length > 0) {
      let newestIndex = 0;
      try {
        let maxTime = -Infinity;
        invoices.forEach((inv, idx) => {
          const t = new Date(inv.created_at || 0).getTime();
          if (!isNaN(t) && t > maxTime) {
            maxTime = t;
            newestIndex = idx;
          }
        });
      } catch (e) {
        newestIndex = invoices.length - 1;
      }
      currentInvoiceIndex = newestIndex;
    }
    perfLog.mark('✅ Invoice index selected');

    // 🚀 PRIORITY 3: Setup UI & event listeners (sync - rất nhanh)
    initTruyThuModal();
    initTableSettings();
    updateTimeFilterButtons();
    attachSearchListeners();
    initBookingFilters();
    updateServiceFilterUI();
    applyInvoiceColumnVisibility();
    applyBookingColumnVisibility();
    setupEventListeners();
    perfLog.mark('✅ UI & event listeners setup');

    // Sidebar state
    const sidebarCollapsed = localStorage.getItem('sidebarCollapsed') === 'true';
    if (sidebarCollapsed && elements.sidebar && elements.mainContent) {
      elements.sidebar.classList.add('sidebar-collapsed');
      elements.mainContent.classList.add('main-content-expanded');
    } else {
      elements.sidebar.classList.remove('sidebar-collapsed');
      elements.mainContent.classList.remove('main-content-expanded');
    }
    perfLog.mark('✅ Sidebar state applied');

    // ✅ PRELOAD: Load data from localStorage first, fetch API only if missing
    setTimeout(() => {
      // Preload staff data (cache-first)
      const cachedStaff = getStaffFromLocalStorage();
      if (!cachedStaff) {
        fetchStaffData().catch(() => {});
      }

      // Preload CTKM/vouchers (cache-first)
      const cachedCTKM = getCTKMFromLocalStorage();
      const cachedVouchers = getVouchersFromLocalStorage();
      if (cachedCTKM && cachedCTKM.length > 0) {
        ctkmList = cachedCTKM;
        vouchers = cachedVouchers || [];
      } else {
        // Fetch from API only if no cache
        fetchAPI('settings/ctkm')
          .then((allCTKMs) => {
            if (Array.isArray(allCTKMs)) {
              ctkmList = allCTKMs.filter(
                (c) => !c.applicable_services || c.applicable_services.length === 0
              );
              vouchers = allCTKMs.filter(
                (c) => c.applicable_services && c.applicable_services.length > 0
              );
              saveCTKMToLocalStorage();
              saveVouchersToLocalStorage();
            }
          })
          .catch(() => {});
      }

      // Preload services (cache-first - đã có trong loadServiceGroups)
      // Không cần fetch ở đây vì loadServiceGroups sẽ tự fetch khi cần

      // Preload products (cache-first - đã có trong renderProductList)
      // Không cần fetch ở đây vì renderProductList sẽ tự fetch khi cần
    }, 0);
    perfLog.mark('✅ Data preload scheduled (cache-first)');

    // 🎯 CRITICAL: Ẩn loader NGAY SAU KHI UI sẵn sàng
    if (window.hidePageLoader) {
      window.hidePageLoader(100);
    }
    perfLog.mark('🎉 PAGE LOADER HIDDEN - UI READY');

    // 🚀 OPTIMIZED: Load 7days thay vì thisMonth để giảm tải localStorage cho thiết bị cũ
    // iOS 15.x có localStorage quota nhỏ hơn, dễ bị tràn khi load toàn bộ tháng
    const cachedInvoicesData = getInvoicesDataFromLocalStorage();
    if (cachedInvoicesData && cachedInvoicesData.length > 0) {
      invoicesData = cachedInvoicesData;
      isInvoicesDataLoaded = true;
      // ✅ Không assume cache là period nào, sẽ load fresh 7days bên dưới
      perfLog.mark('✅ Loaded invoicesData from cache: ' + cachedInvoicesData.length + ' items');
    }

    // Navigate to current section - render từ cache trước
    handleNavigation(currentSection);
    perfLog.mark('✅ handleNavigation completed');

    // 🚀 LOAD 7days: Đủ data cho today/yesterday và nhẹ localStorage
    // thisMonth/lastMonth sẽ được load khi user chọn filter đó
    setTimeout(() => {
      // ✅ OPTIMIZED: Load cả invoices và bookings 7days song song
      // Để Dashboard có đủ data cho filter "Hôm qua"
      const loadPromises = [];

      if (
        currentSection === 'services' ||
        currentSection === 'invoices' ||
        currentSection === 'dashboard'
      ) {
        loadPromises.push(
          loadStaffInvoices('7days')
            .then(() => {
              // Re-render với filter mặc định (today)
              const filterToRender = currentSection === 'services' ? 'today' : 'today';
              renderInvoiceList(filterToRender);
              renderInvoiceTabs();
              // 🔧 FIX: Gọi renderCurrentInvoice sau khi visibleInvoices được cập nhật
              // để đảm bảo empty state hiển thị đúng khi không có hóa đơn hôm nay
              renderCurrentInvoice();
            })
            .catch(() => {})
        );
      }

      // ✅ Luôn load bookings 7days để Dashboard có data cho "Hôm qua"
      loadPromises.push(loadStaffBookings('7days').catch(() => {}));

      Promise.all(loadPromises).catch(() => {});
    }, 0);

    // Auto-detect branch (background)
    if (branchHelper && !currentBranch) {
      setTimeout(() => {
        handleAppBranchAutoDetect().catch(() => {});
      }, 0);
    }

    perfLog.mark('✅ Background tasks scheduled');
    perfLog.summary();
  }

  // ==============================
  // 17. Settings Functions
  // ==============================
  function handleSettingsNavigation(subsection) {
    currentSettingsSubsection = subsection;

    // Ẩn tất cả các subsection
    document.querySelectorAll('.settings-subsection').forEach((section) => {
      section.classList.add('hidden');
    });

    // Hiển thị subsection được chọn
    const subsectionElement = document.getElementById(`${subsection}Settings`);
    if (subsectionElement) {
      subsectionElement.classList.remove('hidden');
    }

    // Cập nhật active state cho menu items
    document.querySelectorAll('.settings-menu-item').forEach((item) => {
      if (item.dataset.subsection === subsection) {
        item.classList.add('active');
      } else {
        item.classList.remove('active');
      }
    });

    // Load nội dung tương ứng
    if (subsection === 'promo') {
      handlePromoTabNavigation('ctkm');
    } else if (subsection === 'inventory') {
      // Load tab inventory checks (default)
      handleInventoryTabSwitch('checks');
    }
  }

  function handlePromoTabNavigation(tab) {
    // Ẩn tất cả các tab content
    document.querySelectorAll('.promo-tab-content').forEach((tabContent) => {
      tabContent.classList.add('hidden');
    });

    // Hiển thị tab được chọn
    const tabElement = document.getElementById(`${tab}Tab`);
    if (tabElement) {
      tabElement.classList.remove('hidden');
    }

    // Cập nhật active state cho tab items
    document.querySelectorAll('.promo-tab-item').forEach((item) => {
      if (item.dataset.tab === tab) {
        item.classList.add('active');
      } else {
        item.classList.remove('active');
      }
    });

    // Tải danh sách tương ứng với tab
    if (tab === 'ctkm') {
      loadCTKMList();
    } else if (tab === 'voucher') {
      loadVoucherList();
    }
  }

  // ==============================
  // Inventory Checks State & Cache
  // ==============================
  let currentInventoryPage = parseInt(localStorage.getItem('currentInventoryPage')) || 1;
  let inventoryItemsPerPage = parseInt(localStorage.getItem('inventoryItemsPerPage')) || 20;
  let inventoryChecks = [];
  let inventoryColumnSettings = JSON.parse(localStorage.getItem('inventoryColumnSettings')) || {
    checkCode: true,
    staffName: true,
    checkDate: true,
    totalProducts: true,
    mismatchedCount: true,
    status: true,
    note: true,
    actions: true,
  };

  // ==============================
  // Inventory Cache System
  // ==============================
  const INVENTORY_CACHE_KEY = 'mkt192_inventory_cache';
  const INVENTORY_CACHE_EXPIRY = 30 * 60 * 1000; // 30 phút

  /**
   * Lấy cache inventory checks từ localStorage
   */
  function getInventoryCache() {
    try {
      const cached = localStorage.getItem(INVENTORY_CACHE_KEY);
      if (!cached) return null;

      const { data, timestamp, branchId } = JSON.parse(cached);
      const currentBranchId = localStorage.getItem('checkinBranchId') || '';

      // Check expiry và branch
      if (Date.now() - timestamp > INVENTORY_CACHE_EXPIRY || branchId !== currentBranchId) {
        localStorage.removeItem(INVENTORY_CACHE_KEY);
        return null;
      }

      return data;
    } catch (e) {
      console.error('❌ Lỗi đọc inventory cache:', e);
      return null;
    }
  }

  /**
   * Lưu cache inventory checks vào localStorage
   */
  function setInventoryCache(data) {
    try {
      const currentBranchId = localStorage.getItem('checkinBranchId') || '';
      safeSetItem(
        INVENTORY_CACHE_KEY,
        JSON.stringify({
          data,
          timestamp: Date.now(),
          branchId: currentBranchId,
        })
      );
    } catch (e) {
      console.error('❌ Lỗi lưu inventory cache:', e);
    }
  }

  /**
   * Xóa cache inventory checks
   */
  function clearInventoryCache() {
    localStorage.removeItem(INVENTORY_CACHE_KEY);
  }

  /**
   * Lấy inventory check từ cache theo check_code
   */
  function getInventoryCheckFromCache(checkCode) {
    const cache = getInventoryCache();
    if (!cache) return null;
    return cache.find((c) => c.check_code === checkCode) || null;
  }

  /**
   * Load danh sách phiếu kiểm kê (có cache)
   */
  async function loadInventoryList(forceRefresh = false) {
    const inventoryList = document.getElementById('inventoryList');
    const inventoryListContainer = document.querySelector('.inventory-list-container');

    if (!inventoryList) return;

    // Thử lấy từ cache trước (nếu không force refresh)
    if (!forceRefresh) {
      const cachedData = getInventoryCache();
      if (cachedData && cachedData.length > 0) {
        console.log('📦 Using cached inventory checks:', cachedData.length, 'items');
        inventoryChecks = cachedData;
        renderInventoryList(inventoryChecks);
        return;
      }
    }

    // Show loading state in button if exists
    const refreshBtn = document.querySelector('#refreshInventoryBtn');
    if (refreshBtn) {
      refreshBtn.classList.add('loading');
      refreshBtn.disabled = true;
    }

    inventoryList.innerHTML = '<tr><td colspan="8" class="loading">Đang tải...</td></tr>';

    try {
      // ✅ Lọc theo branch_id đang được chọn ở thanh selector
      const branchId = branchHelper?.getCurrentBranchId() || 0;
      const params = new URLSearchParams({
        page: 1,
        per_page: 500,
      });
      if (branchId > 0) {
        params.append('branch_id', branchId);
      }

      const response = await fetchAPI(`inventory-checks?${params.toString()}`);

      if (!response.success) {
        throw new Error(response.message || 'Lỗi khi tải danh sách kiểm kê');
      }

      const allChecks = response.data || [];
      console.log('✅ All inventory checks loaded:', allChecks.length, 'items');

      // Lưu vào cache
      setInventoryCache(allChecks);

      inventoryChecks = allChecks;
      renderInventoryList(inventoryChecks);
    } catch (error) {
      inventoryList.innerHTML = `<tr><td colspan="8" class="empty text-red-500">Lỗi: ${error.message}</td></tr>`;
    } finally {
      // Remove loading state
      if (refreshBtn) {
        refreshBtn.classList.remove('loading');
        refreshBtn.disabled = false;
      }
    }
  }

  /**
   * Render danh sách inventory checks ra UI
   */
  function renderInventoryList(checksToRender) {
    const inventoryList = document.getElementById('inventoryList');
    if (!inventoryList) return;

    inventoryList.innerHTML = '';

    if (checksToRender.length === 0) {
      inventoryList.innerHTML =
        '<tr><td colspan="8" class="empty">Chưa có phiếu kiểm kê nào</td></tr>';
      updateInventoryPagination({
        total: 0,
        per_page: inventoryItemsPerPage,
        current_page: 1,
        total_pages: 0,
      });
      return;
    }

    // Pagination: tính toán trang hiện tại
    const totalItems = checksToRender.length;
    const totalPages = Math.ceil(totalItems / inventoryItemsPerPage);
    const startIndex = (currentInventoryPage - 1) * inventoryItemsPerPage;
    const endIndex = Math.min(startIndex + inventoryItemsPerPage, totalItems);
    const paginatedData = checksToRender.slice(startIndex, endIndex);

    // Render từng phiếu kiểm kê
    paginatedData.forEach((check) => {
      const row = document.createElement('tr');
      row.className = 'cursor-pointer transition-colors';
      row.dataset.checkCode = check.check_code;

      // Xác định status icon
      let statusIcon = '';
      let statusClass = '';
      if (check.status === 'matched') {
        statusIcon = '<i class="fas fa-check-circle p-3 text-green-500"></i>';
        statusClass = 'text-green-600';
      } else if (check.status === 'mismatched') {
        statusIcon = '<i class="fas fa-times-circle p-3 text-red-500"></i>';
        statusClass = 'text-red-600';
      } else {
        statusIcon = '<i class="fas fa-exclamation-triangle p-3 text-yellow-500"></i>';
        statusClass = 'text-yellow-600';
      }

      const statusText = {
        matched: 'Khớp',
        mismatched: 'Không khớp',
        partial: 'Một phần',
      }[check.status];

      const checkDate = new Date(check.check_date).toLocaleString('vi-VN', {
        dateStyle: 'short',
        timeStyle: 'short',
      });

      // Build row HTML (all columns, visibility controlled by CSS)
      row.innerHTML = `
        <td class="font-semibold text-blue-600">${check.check_code}</td>
        <td>${check.staff_name}</td>
        <td>${checkDate}</td>
        <td class="text-center">${check.total_products}</td>
        <td class="text-center ${statusClass}">${check.mismatched_count}</td>
        <td class="text-center">${statusIcon} <span class="${statusClass}">${statusText}</span></td>
        <td class="truncate max-w-xs" title="${check.note || ''}">${check.note || '-'}</td>
        <td class="text-center">
          <button class="view-inventory-btn text-blue-600 hover:text-blue-800" data-check-code="${
            check.check_code
          }" title="Xem chi tiết">
            <i class="fas fa-eye"></i>
          </button>
        </td>
      `;
      inventoryList.appendChild(row);

      // Click row to view details
      row.addEventListener('click', (e) => {
        if (!e.target.closest('.view-inventory-btn')) {
          viewInventoryCheckDetail(check.check_code);
        }
      });
    });

    // Add event listeners for view buttons
    document.querySelectorAll('.view-inventory-btn').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const checkCode = btn.dataset.checkCode;
        viewInventoryCheckDetail(checkCode);
      });
    });

    // Update pagination và column visibility
    updateInventoryPagination({
      total: totalItems,
      per_page: inventoryItemsPerPage,
      current_page: currentInventoryPage,
      total_pages: totalPages,
    });
    applyInventoryColumnVisibility();
  }

  /**
   * Refresh danh sách inventory checks từ API (xóa cache)
   */
  async function refreshInventoryList() {
    clearInventoryCache();
    await loadInventoryList(true);
    toastSuccess('Đã làm mới danh sách phiếu kiểm kê');
  }

  function updateInventoryPagination(pagination) {
    const paginationInfo = document.getElementById('inventory-pagination-info');
    const paginationButtons = document.getElementById('inventory-pagination-buttons');

    if (!paginationInfo || !paginationButtons) return;

    const { total, per_page, current_page, total_pages } = pagination;

    // Update info text
    const start = total === 0 ? 0 : (current_page - 1) * per_page + 1;
    const end = Math.min(current_page * per_page, total);
    paginationInfo.textContent = `Hiển thị ${start} - ${end} / Tổng ${total}`;

    // Update buttons
    paginationButtons.innerHTML = `
      <button
        class="pagination-btn"
        ${current_page === 1 ? 'disabled' : ''}
        onclick="changeInventoryPage(${current_page - 1})">
        «
      </button>
      <span class="pagination-current">Trang ${current_page} / ${total_pages || 1}</span>
      <button
        class="pagination-btn"
        ${current_page === total_pages || total_pages === 0 ? 'disabled' : ''}
        onclick="changeInventoryPage(${current_page + 1})">
        »
      </button>
    `;
  }

  // Expose functions to global scope
  window.createNewInvoice = function () {
    addNewInvoice();
  };

  window.changeInventoryPage = function (page) {
    currentInventoryPage = page;
    localStorage.setItem('currentInventoryPage', page);

    // ✅ Re-render từ cache thay vì gọi API
    const cachedData = getInventoryCache();
    if (cachedData) {
      inventoryChecks = cachedData;
      renderInventoryList(inventoryChecks);
    } else {
      loadInventoryList();
    }
  };

  window.changeInventoryItemsPerPage = function (perPage) {
    inventoryItemsPerPage = parseInt(perPage);
    currentInventoryPage = 1;
    localStorage.setItem('inventoryItemsPerPage', inventoryItemsPerPage);
    localStorage.setItem('currentInventoryPage', 1);

    // ✅ Re-render từ cache thay vì gọi API
    const cachedData = getInventoryCache();
    if (cachedData) {
      inventoryChecks = cachedData;
      renderInventoryList(inventoryChecks);
    } else {
      loadInventoryList();
    }
  };

  async function viewInventoryCheckDetail(checkCode) {
    const modal = document.getElementById('inventoryDetailModal');
    const modalBody = document.getElementById('inventoryDetailBody');

    if (!modal || !modalBody) return;

    modalBody.innerHTML =
      '<div class="text-center py-8"><i class="fas fa-spinner fa-spin"></i> Đang tải...</div>';
    modal.classList.add('show');

    try {
      const response = await fetchAPI(`inventory-checks/${checkCode}`);

      if (!response.success) {
        throw new Error(response.message || 'Không tìm thấy phiếu kiểm kê');
      }

      const check = response.data;
      const inventoryData = check.inventory_data || [];

      const checkDate = new Date(check.check_date).toLocaleString('vi-VN', {
        dateStyle: 'long',
        timeStyle: 'short',
      });

      let detailHTML = `
        <div class="mb-6">
          <h3 class="text-xl font-semibold mb-2">Phiếu kiểm kê: ${check.check_code}</h3>
          <div class="grid grid-cols-2 gap-4 text-sm">
            <div><strong>Nhân viên:</strong> ${check.staff_name}</div>
            <div>
              <strong>Ngày kiểm:</strong>
              <div>${checkDate}</div>
            </div>
            <div><strong>Tổng sản phẩm:</strong> ${check.total_products}</div>
            <div><strong>Không khớp:</strong> ${check.mismatched_count}</div>
            <div class="col-span-2"><strong>Ghi chú:</strong> ${check.note || '-'}</div>
          </div>
        </div>

        <div class="overflow-x-auto">
          <table class="inventory-check-table">
            <thead>
              <tr>
                <th>STT</th>
                <th>Sản phẩm</th>
                <th>Tồn kho</th>
                <th>Kiểm kê</th>
                <th>Chênh lệch</th>
                <th>Trạng thái</th>
                <th>Lý do</th>
              </tr>
            </thead>
            <tbody>
      `;

      inventoryData.forEach((item, index) => {
        const statusIcon = item.is_mismatched
          ? '<i class="fas fa-times text-red-500"></i>'
          : '<i class="fas fa-check text-green-500"></i>';
        const differenceClass =
          item.difference > 0 ? 'text-blue-600' : item.difference < 0 ? 'text-red-600' : '';

        detailHTML += `
          <tr>
            <td class="text-center">${index + 1}</td>
            <td>${item.product_name}</td>
            <td class="text-center">${item.stock}</td>
            <td class="text-center">${item.actual_quantity}</td>
            <td class="text-center ${differenceClass}">${item.difference >= 0 ? '+' : ''}${
              item.difference
            }</td>
            <td class="text-center">${statusIcon}</td>
            <td>${item.reason || '-'}</td>
          </tr>
        `;
      });

      detailHTML += `
            </tbody>
          </table>
        </div>
      `;

      modalBody.innerHTML = detailHTML;
    } catch (error) {
      modalBody.innerHTML = `<div class="text-center text-red-500 py-8">Lỗi: ${error.message}</div>`;
    }
  }

  // Hàm xử lý kiểm kê
  let isInventorySubmitting = false; // Flag để ngăn duplicate submissions

  async function handleInventoryCheck() {
    const inventoryCheckBtn = document.getElementById('inventoryCheckBtn');

    // Add loading state to button
    if (inventoryCheckBtn) {
      setButtonLoading(inventoryCheckBtn, 'Đang xử lý...');
    }

    try {
      const modal = document.getElementById('inventoryCheckModal');
      const table = document.getElementById('inventoryCheckTable');
      const submitBtn = document.getElementById('submitBtn');
      const cancelBtn = document.getElementById('cancelInventoryCheckBtn');
      const closeBtn = document.getElementById('closeInventoryCheckModal');

      // Mở modal ngay lập tức với loading state
      modal.classList.add('show');
      table.innerHTML = '<tr><td colspan="4" class="loading">Đang tải...</td></tr>';

      // Ưu tiên lấy từ cache local trước, fetch API ở background nếu cần
      let products = getProductsFromLocalStorage();
      let isFromCache = !!products;

      if (!products || products.length === 0) {
        // Không có cache, phải fetch từ API
        products = await fetchAPI('products');
        if (products && products.length > 0) {
          saveProductsToLocalStorage(products);
        }
      } else {
        // Có cache, fetch API ở background để cập nhật stock mới nhất
        fetchAPI('products')
          .then((freshProducts) => {
            if (freshProducts && freshProducts.length > 0) {
              saveProductsToLocalStorage(freshProducts);
              // Cập nhật stock trong bảng nếu có thay đổi
              freshProducts.forEach((fp) => {
                const input = table.querySelector(`input[data-id="${fp.id}"]`);
                if (input) {
                  const currentStock = parseInt(input.dataset.stock);
                  if (currentStock !== fp.stock) {
                    input.dataset.stock = fp.stock;
                    const row = input.closest('tr');
                    const stockCell = row.querySelector('td:nth-child(2)');
                    if (stockCell) {
                      stockCell.textContent = fp.stock;
                      stockCell.classList.add('stock-updated');
                      setTimeout(() => stockCell.classList.remove('stock-updated'), 1000);
                    }
                  }
                }
              });
            }
          })
          .catch((err) => console.warn('Background refresh products failed:', err));
      }

      table.innerHTML = '';
      if (!products || products.length === 0) {
        table.innerHTML = '<tr><td colspan="4" class="empty">Không có sản phẩm nào</td></tr>';
        toastError('Không có sản phẩm nào để kiểm kê', 3000);
        if (inventoryCheckBtn) resetButtonLoading(inventoryCheckBtn);
        return;
      }

      products.forEach((product) => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${product.product_name}</td>
            <td>${product.stock}</td>
            <td>
                <input type="number" inputmode="numeric" data-id="${product.id}" data-stock="${product.stock}" class="actual-quantity" min="0" required>
            </td>
            <td class="status"></td>
        `;
        table.appendChild(row);
      });

      // Xóa tất cả event listeners cũ bằng cách clone và replace
      const newSubmitBtn = submitBtn.cloneNode(true);
      submitBtn.parentNode.replaceChild(newSubmitBtn, submitBtn);

      const newCancelBtn = cancelBtn.cloneNode(true);
      cancelBtn.parentNode.replaceChild(newCancelBtn, cancelBtn);

      const newCloseBtn = closeBtn.cloneNode(true);
      closeBtn.parentNode.replaceChild(newCloseBtn, closeBtn);

      // Cập nhật references
      const currentSubmitBtn = document.getElementById('submitBtn');
      const currentCancelBtn = document.getElementById('cancelInventoryCheckBtn');
      const currentCloseBtn = document.getElementById('closeInventoryCheckModal');

      table.addEventListener(
        'blur',
        (e) => {
          if (e.target.classList.contains('actual-quantity')) {
            const row = e.target.closest('tr');
            const currentQty = parseInt(e.target.dataset.stock);
            const actualQty = parseInt(e.target.value) || 0;
            const statusCell = row.querySelector('.status');
            const nextRow = row.nextElementSibling;

            if (actualQty === currentQty) {
              statusCell.innerHTML = '<i class="fas fa-check"></i>';
              if (nextRow && nextRow.classList.contains('reason-row')) {
                nextRow.remove();
              }
              e.target.dataset.isMismatched = 'false';
            } else {
              statusCell.innerHTML = '<i class="fas fa-times"></i>';
              if (!nextRow || !nextRow.classList.contains('reason-row')) {
                const reasonRow = document.createElement('tr');
                reasonRow.classList.add('reason-row');
                reasonRow.innerHTML = `
                            <td colspan="4">
                                <input type="text" class="reason-input" placeholder="Lý do không khớp">
                            </td>
                        `;
                row.insertAdjacentElement('afterend', reasonRow);
              }
              e.target.dataset.isMismatched = 'true';
            }

            // Kích hoạt nút Gửi khi tất cả số lượng thực tế đã nhập
            const allFilled = Array.from(table.querySelectorAll('.actual-quantity')).every(
              (input) => input.value !== ''
            );
            currentSubmitBtn.disabled = !allFilled;
          }
        },
        true
      );

      // Thêm sự kiện cho nút Gửi - CHỈ 1 LẦN
      currentSubmitBtn.addEventListener('click', async () => {
        // Kiểm tra flag để ngăn duplicate submissions
        if (isInventorySubmitting) {
          return;
        }

        isInventorySubmitting = true;
        setButtonLoading(currentSubmitBtn, 'Đang xử lý...');

        const inventoryData = Array.from(table.querySelectorAll('.actual-quantity')).map(
          (input) => {
            const row = input.closest('tr');
            const reasonInput = row.nextElementSibling?.querySelector('.reason-input');
            return {
              product_id: input.dataset.id,
              stock: parseInt(input.dataset.stock),
              actual_quantity: parseInt(input.value) || 0,
              reason: reasonInput ? reasonInput.value || '' : '',
              is_mismatched: input.dataset.isMismatched === 'true',
            };
          }
        );

        try {
          const result = await fetchAPI('inventory-check', {
            method: 'POST',
            body: JSON.stringify({
              inventory: inventoryData,
            }),
          });

          if (result.success) {
            toastSuccess('Cập nhật phiếu kiểm kê thành công', 3000);
            modal.classList.remove('show');
            loadInventoryList(true); // Force refresh để hiển thị dữ liệu mới ngay

            // Refresh dashboard inventory status if on dashboard
            if (typeof window.AppThoDashboard?.refreshInventoryStatus === 'function') {
              window.AppThoDashboard.refreshInventoryStatus();
            }
          } else {
            toastError(
              'Lỗi khi cập nhật phiếu kiểm kê: ' + (result.message || 'Không rõ nguyên nhân'),
              3000
            );
          }
        } catch (error) {
          toastError('Lỗi khi gửi phiếu kiểm kê: ' + error.message, 3000);
        } finally {
          // Luôn reset trạng thái sau khi xử lý xong
          resetButtonLoading(currentSubmitBtn);
          isInventorySubmitting = false;
        }
      });

      // Thêm sự kiện cho nút Hủy
      currentCancelBtn.addEventListener('click', () => {
        modal.classList.remove('show');
      });

      // Thêm sự kiện cho nút Đóng
      currentCloseBtn.addEventListener('click', () => {
        modal.classList.remove('show');
      });
    } finally {
      // Remove loading state from button
      if (inventoryCheckBtn) {
        resetButtonLoading(inventoryCheckBtn);
      }
    }
  }

  // Hàm xử lý xuất/nhập kho
  async function handleStockTransaction() {
    const stockTransactionBtn = document.getElementById('stockTransactionBtn');

    // Add loading state to button
    if (stockTransactionBtn) {
      setButtonLoading(stockTransactionBtn, 'Đang xử lý...');
    }

    try {
      const modal = document.getElementById('stockTransactionModal');
      const productSelect = document.getElementById('transactionProducts');
      const quantityInput = document.getElementById('transactionQuantity');
      const addProductBtn = document.getElementById('addProductBtn');
      const selectedProductsDiv = document.getElementById('selectedProducts');
      const form = document.getElementById('stockTransactionForm');
      const submitStockTransactionBtn = document.getElementById('submitStockTransactionBtn');
      const imageInput = document.getElementById('transactionImage');
      const reasonInput = document.getElementById('transactionReason');
      const cancelBtn = document.getElementById('cancelStockTransactionBtn');
      const closeBtn = document.getElementById('closeStockTransactionModal');

      // Mở modal ngay lập tức
      modal.classList.add('show');
      productSelect.innerHTML = '<option value="">Đang tải...</option>';
      productSelect.disabled = true;

      // Ưu tiên lấy từ cache local trước
      let products = getProductsFromLocalStorage();

      if (!products || products.length === 0) {
        // Không có cache, phải fetch từ API
        products = await fetchAPI('products');
        if (products && products.length > 0) {
          saveProductsToLocalStorage(products);
        }
      } else {
        // Có cache, fetch API ở background để cập nhật
        fetchAPI('products')
          .then((freshProducts) => {
            if (freshProducts && freshProducts.length > 0) {
              saveProductsToLocalStorage(freshProducts);
            }
          })
          .catch((err) => console.warn('Background refresh products failed:', err));
      }

      productSelect.disabled = false;
      productSelect.innerHTML =
        `<option value="">Chọn sản phẩm</option>` +
        (products || [])
          .map((product) => `<option value="${product.id}">${product.product_name}</option>`)
          .join('');

      const selectedItems = [];
      let uploadedImageKey = ''; // Lark image key (cho notification)
      let uploadedImageUrl = ''; // WordPress URL (cho hiển thị)

      // Reset form
      form.reset();
      quantityInput.value = '1';
      selectedProductsDiv.style.display = 'none';
      selectedProductsDiv.innerHTML = '';
      submitStockTransactionBtn.disabled = true;

      // Clone form trước để remove old event listeners
      const newForm = form.cloneNode(true);
      form.parentNode.replaceChild(newForm, form);

      // Lấy lại references sau khi clone form
      const currentProductSelect = document.getElementById('transactionProducts');
      const currentQuantityInput = document.getElementById('transactionQuantity');
      const currentSelectedProductsDiv = document.getElementById('selectedProducts');
      const currentSubmitBtn = document.getElementById('submitStockTransactionBtn');
      const currentReasonInput = document.getElementById('transactionReason');
      const currentImageInput = document.getElementById('transactionImage');
      const currentAddBtn = document.getElementById('addProductBtn');
      const currentCancelBtn = document.getElementById('cancelStockTransactionBtn');
      const currentCloseBtn = document.getElementById('closeStockTransactionModal');

      // Thêm sự kiện cho input hình ảnh
      currentImageInput.addEventListener('change', async (e) => {
        const file = e.target.files[0];
        if (!file) return;

        // Hiển thị loader và disable submit button
        window.showPageLoader({ text: 'Đang upload ảnh...', subtitle: 'Vui lòng đợi' });
        currentSubmitBtn.disabled = true;

        // Đọc file thành base64
        const reader = new FileReader();
        reader.onload = async (event) => {
          try {
            const base64Data = event.target.result;

            const response = await fetch(`${checkinData.restUrl}upload-image-inventory`, {
              method: 'POST',
              headers: {
                'X-WP-Nonce': checkinData.nonce,
                'Content-Type': 'application/json',
              },
              credentials: 'same-origin',
              body: JSON.stringify({
                image_data: base64Data,
                filename: file.name,
              }),
            });

            const result = await response.json();

            if (result.success && (result.img_key || result.image_url)) {
              // Lưu cả 2 giá trị: img_key cho Lark notification, image_url cho hiển thị
              uploadedImageKey = result.img_key || '';
              uploadedImageUrl = result.image_url || '';
              toastSuccess('Upload hình ảnh thành công', 3000);
              // Enable submit button sau khi upload thành công
              currentSubmitBtn.disabled = selectedItems.length === 0;
            } else {
              toastError(
                'Lỗi khi upload hình ảnh: ' + (result.message || 'Không rõ nguyên nhân'),
                3000
              );
              // Vẫn enable submit button nếu có sản phẩm (có thể gửi không kèm ảnh)
              currentSubmitBtn.disabled = selectedItems.length === 0;
            }
          } catch (error) {
            console.error('❌ Upload error:', error);
            toastError('Lỗi khi upload hình ảnh: ' + error.message, 3000);
            // Vẫn enable submit button nếu có sản phẩm
            currentSubmitBtn.disabled = selectedItems.length === 0;
          } finally {
            // Ẩn loader
            hidePageLoader();
          }
        };

        reader.onerror = () => {
          hidePageLoader();
          toastError('Lỗi đọc file hình ảnh', 3000);
          currentSubmitBtn.disabled = selectedItems.length === 0;
        };

        reader.readAsDataURL(file);
      });

      // Thêm sự kiện cho nút Thêm sản phẩm
      currentAddBtn.addEventListener('click', () => {
        const product_id = currentProductSelect.value;
        const quantity = currentQuantityInput.value;
        if (!product_id || !quantity || quantity < 1) {
          toastError('Vui lòng chọn sản phẩm và nhập số lượng hợp lệ', 3000);
          return;
        }

        const product = products.find((p) => p.id == product_id);
        if (!product) {
          return;
        }

        const existingItem = selectedItems.find((item) => item.product_id === product_id);
        if (existingItem) {
          existingItem.quantity = quantity;
        } else {
          selectedItems.push({
            product_id: product_id,
            quantity,
            product_name: product.product_name,
          });
        }
        currentSelectedProductsDiv.innerHTML = selectedItems
          .map(
            (item, index) => `
                <div class="selected-products-item">
                    <span>${item.product_name} - Số lượng: ${item.quantity}</span>
                    <button type="button" class="remove-item" data-index="${index}">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            `
          )
          .join('');

        // Hiện selectedProducts khi có sản phẩm
        currentSelectedProductsDiv.style.display = selectedItems.length > 0 ? 'block' : 'none';

        currentSubmitBtn.disabled = selectedItems.length === 0;

        currentProductSelect.value = '';
        currentQuantityInput.value = '1';

        document.querySelectorAll('.remove-item').forEach((btn) => {
          const btnClone = btn.cloneNode(true);
          btn.parentNode.replaceChild(btnClone, btn);
          btnClone.addEventListener('click', () => {
            const index = parseInt(btnClone.dataset.index);
            selectedItems.splice(index, 1);
            currentSelectedProductsDiv.innerHTML = selectedItems
              .map(
                (item, i) => `
                        <div class="selected-products-item">
                            <span>${item.product_name} - Số lượng: ${item.quantity}</span>
                            <button type="button" class="remove-item" data-index="${i}">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    `
              )
              .join('');

            // Ẩn selectedProducts khi không còn sản phẩm nào
            currentSelectedProductsDiv.style.display = selectedItems.length > 0 ? 'block' : 'none';

            currentSubmitBtn.disabled = selectedItems.length === 0;
          });
        });
      });

      // Thêm sự kiện cho form submit
      document.getElementById('stockTransactionForm').addEventListener('submit', async (e) => {
        e.preventDefault();

        const submitBtn = currentSubmitBtn;
        setButtonLoading(submitBtn, 'Đang xử lý...');

        if (selectedItems.length === 0) {
          resetButtonLoading(submitBtn);
          toastError('Vui lòng thêm ít nhất một sản phẩm', 3000);
          return;
        }

        const type = document.getElementById('transactionType').value;
        const reason = currentReasonInput.value.trim();
        try {
          // ✅ Lấy branch_id từ branchHelper (nếu multi-branch enabled)
          const currentBranchId = branchHelper?.getCurrentBranchId() || 0;

          const payload = {
            type,
            products: selectedItems.map((item) => ({
              product_id: parseInt(item.product_id),
              quantity: item.quantity,
            })),
            reason,
            image_key: uploadedImageKey || '', // Lark key cho notification
            image_url: uploadedImageUrl || '', // WordPress URL cho hiển thị
            branch_id: currentBranchId, // ✅ Gửi branch_id để lưu vào database
          };
          const result = await fetchAPI('stock-transaction', {
            method: 'POST',
            body: JSON.stringify(payload),
          });

          if (result.success) {
            toastSuccess('Giao dịch thành công', 3000);
            modal.classList.remove('show');
            uploadedImageKey = ''; // Reset image key
            uploadedImageUrl = ''; // Reset image url

            // ✅ Update UI realtime: Load lại inventory list và transactions list (force refresh để bỏ cache)
            loadInventoryList(true);
            loadInventoryTransactions(currentTransactionFilter, true);

            // ✅ Realtime: Refresh dashboard stock transfer status
            if (window.AppThoDashboard?.refreshStockTransferStatus) {
              window.AppThoDashboard.refreshStockTransferStatus();
            }
          } else {
            toastError(
              'Lỗi khi xử lý giao dịch: ' + (result.message || 'Không rõ nguyên nhân'),
              3000
            );
          }
        } catch (error) {
          toastError('Lỗi khi xử lý giao dịch: ' + error.message, 3000);
        } finally {
          // ✅ Luôn reset button trong finally
          resetButtonLoading(submitBtn);
        }
      });

      // Thêm sự kiện cho nút Hủy
      currentCancelBtn.addEventListener('click', () => {
        modal.classList.remove('show');
      });

      // Thêm sự kiện cho nút Đóng
      currentCloseBtn.addEventListener('click', () => {
        modal.classList.remove('show');
      });
    } finally {
      // Remove loading state from button
      if (stockTransactionBtn) {
        resetButtonLoading(stockTransactionBtn);
      }
    }
  }

  async function loadPromoSettings(currentInvoice = null) {
    const invoiceDetailPromoSelect = document.getElementById('editPromoCode');
    const invoice = currentInvoice || invoices[currentInvoiceIndex];

    if (!elements.promoListSelect && !invoiceDetailPromoSelect && !elements.voucherList) {
      return;
    }

    // Helper function để normalize applicable_services
    function normalizeApplicableServices(services) {
      if (Array.isArray(services)) {
        return services;
      }
      if (typeof services === 'string') {
        try {
          const parsed = JSON.parse(services);
          return Array.isArray(parsed) ? parsed : [];
        } catch (e) {
          return [];
        }
      }
      return [];
    }

    // 🚀 CACHE-FIRST: Sử dụng cache nếu có, chỉ fetch API khi cần
    const cachedCTKM = getCTKMFromLocalStorage();
    const cachedVouchers = getVouchersFromLocalStorage();

    if (cachedCTKM && cachedCTKM.length > 0) {
      // ✅ Normalize cache data trước khi phân loại
      const normalizedCache = cachedCTKM.map((ctkm) => ({
        ...ctkm,
        applicable_services: normalizeApplicableServices(ctkm.applicable_services),
      }));

      ctkmList = normalizedCache.filter(
        (ctkm) => !ctkm.applicable_services || ctkm.applicable_services.length === 0
      );
      vouchers =
        cachedVouchers ||
        normalizedCache.filter(
          (ctkm) => ctkm.applicable_services && ctkm.applicable_services.length > 0
        );

      // Loaded from cache
      // ✅ KHÔNG return - tiếp tục render UI phía dưới
    } else {
      // ✅ Không có cache - fetch từ API
      try {
        const allCTKMs = await fetchAPI('settings/ctkm');
        if (!Array.isArray(allCTKMs)) {
          ctkmList = [];
          vouchers = [];
        } else {
          // ✅ NORMALIZE TRƯỚC, sau đó filter
          const normalizedCTKMs = allCTKMs.map((ctkm) => ({
            ...ctkm,
            applicable_services: normalizeApplicableServices(ctkm.applicable_services),
          }));

          // ✅ Phân loại: CTKM (không có dịch vụ áp dụng) vs Voucher (có dịch vụ áp dụng)
          ctkmList = normalizedCTKMs.filter(
            (ctkm) => !ctkm.applicable_services || ctkm.applicable_services.length === 0
          );
          vouchers = normalizedCTKMs.filter(
            (ctkm) => ctkm.applicable_services && ctkm.applicable_services.length > 0
          );

          // Loaded CTKM from API
        }
        saveCTKMToLocalStorage();
        saveVouchersToLocalStorage();
      } catch (error) {
        showError('Không thể tải danh sách chương trình khuyến mãi và mã ưu đãi');
        ctkmList = getCTKMFromLocalStorage().map((ctkm) => ({
          ...ctkm,
          applicable_services: normalizeApplicableServices(ctkm.applicable_services),
        }));
        vouchers = getVouchersFromLocalStorage().map((voucher) => ({
          ...voucher,
          applicable_services: normalizeApplicableServices(voucher.applicable_services),
        }));
        if (!Array.isArray(ctkmList)) ctkmList = [];
        if (!Array.isArray(vouchers)) vouchers = [];
      }
    }

    const today = new Date();

    function parseDate(dateStr) {
      if (!dateStr) return null;
      if (/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
        return new Date(dateStr);
      }
      if (/^\d{1,2}\/\d{1,2}\/\d{4}$/.test(dateStr)) {
        const [day, month, year] = dateStr.split('/').map(Number);
        return new Date(year, month - 1, day);
      }
      return null;
    }

    // ✅ Lấy membership hiện tại của khách hàng
    const customerMembership = invoice?.customer?.membership || 'Khách thường';

    // ✅ Helper: Kiểm tra membership có khớp với các label của CTKM không
    // Xử lý mapping: "Khách thường" ↔ "Thường", "Thành Viên" ↔ "Thành Viên", "VIP" ↔ "VIP"
    function isMembershipMatch(membershipLabels, customerMembership) {
      // Nếu CTKM áp dụng cho "Tất cả" → khớp với mọi khách
      if (membershipLabels.includes('Tất cả')) return true;

      // Kiểm tra khớp trực tiếp
      if (membershipLabels.includes(customerMembership)) return true;

      // Mapping "Khách thường" ↔ "Thường"
      if (customerMembership === 'Khách thường' && membershipLabels.includes('Thường')) return true;
      if (customerMembership === 'Thường' && membershipLabels.includes('Khách thường')) return true;

      return false;
    }

    // Filter CTKM by membership

    const validCTKMs = ctkmList.filter((ctkm) => {
      const startDate = parseDate(ctkm.start_date);
      const endDate = parseDate(ctkm.end_date);
      if (!startDate || !endDate || isNaN(startDate.getTime()) || isNaN(endDate.getTime())) {
        return false;
      }

      // ✅ Kiểm tra CTKM có active và trong thời gian hiệu lực
      const isActive = ctkm.status === 'active' && today >= startDate && today <= endDate;
      if (!isActive) return false;

      // ✅ Lọc CTKM theo membership_label
      const membershipLabels = Array.isArray(ctkm.membership_label)
        ? ctkm.membership_label
        : [ctkm.membership_label || 'Tất cả'];

      // ✅ Sử dụng helper function để kiểm tra membership match
      return isMembershipMatch(membershipLabels, customerMembership);
    });

    // Debug: Filtered CTKMs

    const validVouchers = vouchers.filter((voucher) => {
      const startDate = parseDate(voucher.start_date);
      const endDate = parseDate(voucher.end_date);
      if (!startDate || !endDate || isNaN(startDate.getTime()) || isNaN(endDate.getTime())) {
        return false;
      }

      // ✅ Kiểm tra voucher có active và trong thời gian hiệu lực
      const isActive = voucher.status === 'active' && today >= startDate && today <= endDate;
      if (!isActive) return false;

      // ✅ Lọc voucher theo membership_label
      const membershipLabels = Array.isArray(voucher.membership_label)
        ? voucher.membership_label
        : [voucher.membership_label || 'Tất cả'];

      // ✅ Sử dụng helper function để kiểm tra membership match
      return isMembershipMatch(membershipLabels, customerMembership);
    });

    if (elements.promoListSelect) {
      elements.promoListSelect.innerHTML = '<option value="">Không có</option>';
      // Thêm Ưu đãi Combo nếu có nhiều dịch vụ với discounted_price
      const discountedServicesCount = invoice.services.filter((s) => {
        const serviceData = (getServicesFromLocalStorage() || []).find(
          (srv) => srv.service_id === s.service_id
        );
        return serviceData?.discounted_price && parseFloat(serviceData.discounted_price) > 0;
      }).length;
      if (discountedServicesCount >= 2) {
        const comboOption = document.createElement('option');
        comboOption.value = 'Ưu đãi Combo';
        comboOption.textContent = 'Ưu đãi Combo';
        elements.promoListSelect.appendChild(comboOption);
      }
      validCTKMs.forEach((ctkm) => {
        const option = document.createElement('option');
        option.value = ctkm.ctkm_name;
        option.textContent = `${ctkm.ctkm_name} (${formatCurrency(ctkm.value)})`;
        elements.promoListSelect.appendChild(option);
      });
      validVouchers.forEach((voucher) => {
        const option = document.createElement('option');
        option.value = voucher.ctkm_name;
        option.textContent = `${voucher.ctkm_name} (${formatCurrency(voucher.value)})`;
        elements.promoListSelect.appendChild(option);
      });

      // ✅ Set value NGAY SAU KHI render options xong
      if (invoice?.promoName) {
        elements.promoListSelect.value = invoice.promoName;
      }
    }

    if (invoiceDetailPromoSelect) {
      invoiceDetailPromoSelect.innerHTML = '<option value="">Không có</option>';
      validCTKMs.forEach((ctkm) => {
        const option = document.createElement('option');
        option.value = ctkm.ctkm_name;
        option.textContent = `${ctkm.ctkm_name} (${formatCurrency(ctkm.value)})`;
        invoiceDetailPromoSelect.appendChild(option);
      });
      validVouchers.forEach((voucher) => {
        const option = document.createElement('option');
        option.value = voucher.ctkm_name;
        option.textContent = `${voucher.ctkm_name} (${formatCurrency(voucher.value)})`;
        invoiceDetailPromoSelect.appendChild(option);
      });

      if (invoice && invoice.promoName) {
        invoiceDetailPromoSelect.value = invoice.promoName;
      }
    }
  }

  function showPromoForm(isEditing, ctkm = null) {
    const promoFormContainer = document.getElementById('promoFormContainer');
    const promoSubmitBtn = document.getElementById('promoSubmitBtn');
    const promoForm = document.getElementById('promoForm');

    if (!promoFormContainer || !promoSubmitBtn || !promoForm) return;

    promoFormContainer.classList.remove('hidden');
    isEditingCTKM = isEditing;
    editingCTKMName = isEditing ? ctkm.ctkm_name : null;

    promoSubmitBtn.textContent = isEditing ? 'Sửa CTKM' : 'Lưu';

    if (isEditing && ctkm) {
      document.getElementById('promoName').value = ctkm.ctkm_name;
      document.getElementById('promoValue').value = ctkm.value;
      document.getElementById('promoDescription').value = ctkm.description || '';
      document.getElementById('promoStartDate').value = ctkm.start_date;
      document.getElementById('promoEndDate').value = ctkm.end_date;
      document.getElementById('promoStatus').value = ctkm.status;

      const membershipCheckboxes = document.querySelectorAll(
        '#promoMembership input[type="checkbox"]'
      );
      const membershipLabels = Array.isArray(ctkm.membership_label)
        ? ctkm.membership_label
        : [ctkm.membership_label || 'Tất cả'];
      membershipCheckboxes.forEach((checkbox) => {
        checkbox.checked = membershipLabels.includes(checkbox.value);
      });
    } else {
      promoForm.reset();
      document.querySelector('#promoMembership input[value="Tất cả"]').checked = true;
    }
  }

  function showVoucherForm(isEditing, voucher = null) {
    const voucherFormContainer = document.getElementById('voucherFormContainer');
    const voucherSubmitBtn = document.getElementById('voucherSubmitBtn');
    const voucherForm = document.getElementById('voucherForm');

    if (!voucherFormContainer || !voucherSubmitBtn || !voucherForm) return;

    voucherFormContainer.classList.remove('hidden');
    isEditingVoucher = isEditing;
    editingVoucherName = isEditing ? voucher.ctkm_name : null;

    voucherSubmitBtn.textContent = isEditing ? 'Sửa Mã Ưu Đãi' : 'Lưu';

    // Tải danh sách dịch vụ từ localStorage
    let services = getServicesFromLocalStorage() || [];

    // Nếu services nằm trong object có key 'data', lấy mảng từ services.data
    if (services.data && Array.isArray(services.data)) {
      services = services.data;
    }

    const voucherServicesSelect = document.getElementById('voucherServices');
    voucherServicesSelect.innerHTML = ''; // Xóa các option cũ

    // Kiểm tra dữ liệu dịch vụ
    if (!Array.isArray(services) || services.length === 0) {
      const option = document.createElement('option');
      option.value = '';
      option.textContent = 'Không có dịch vụ nào';
      voucherServicesSelect.appendChild(option);
      return;
    }

    // Thêm các option cho select
    services.forEach((service) => {
      const option = document.createElement('option');
      option.value = service.service_id; // Sử dụng service_id thay vì id
      // Định dạng tên và giá
      const price = parseFloat(service.service_price) || 0; // Chuyển chuỗi thành số
      option.textContent = `${service.service_name} (${formatCurrency(price)})`;
      voucherServicesSelect.appendChild(option);
    });

    if (isEditing && voucher) {
      document.getElementById('voucherName').value = voucher.ctkm_name;
      document.getElementById('voucherValue').value = voucher.value;
      document.getElementById('voucherDescription').value = voucher.description || '';
      document.getElementById('voucherStartDate').value = voucher.start_date;
      document.getElementById('voucherEndDate').value = voucher.end_date;
      document.getElementById('voucherStatus').value = voucher.status;

      const membershipCheckboxes = document.querySelectorAll(
        '#voucherMembership input[type="checkbox"]'
      );
      const membershipLabels = Array.isArray(voucher.membership_label)
        ? voucher.membership_label
        : [voucher.membership_label || 'Tất cả'];
      membershipCheckboxes.forEach((checkbox) => {
        checkbox.checked = membershipLabels.includes(checkbox.value);
      });

      const applicableServices = Array.isArray(voucher.applicable_services)
        ? voucher.applicable_services
        : [];
      Array.from(voucherServicesSelect.options).forEach((option) => {
        option.selected = applicableServices.includes(option.value);
      });
    } else {
      voucherForm.reset();
      document.querySelector('#voucherMembership input[value="Tất cả"]').checked = true;
    }
  }

  function hidePromoForm() {
    const promoFormContainer = document.getElementById('promoFormContainer');
    const promoForm = document.getElementById('promoForm');
    if (promoFormContainer && promoForm) {
      promoFormContainer.classList.add('hidden');
      promoForm.reset();
      isEditingCTKM = false;
      editingCTKMName = null;
    }
  }

  function hideVoucherForm() {
    const voucherFormContainer = document.getElementById('voucherFormContainer');
    const voucherForm = document.getElementById('voucherForm');
    if (voucherFormContainer && voucherForm) {
      voucherFormContainer.classList.add('hidden');
      voucherForm.reset();
      isEditingVoucher = false;
      editingVoucherName = null;
    }
  }

  // --- CTKM / Promotion Loading ---

  async function loadCTKMList() {
    const promoList = document.getElementById('promoList');
    if (!promoList) return;

    try {
      ctkmList = await fetchAPI('settings/ctkm?promo_type=ctkm');
      ctkmList = ctkmList.filter((ctkm) => ctkm.promo_type === 'ctkm'); // Đảm bảo lọc ở frontend
      saveCTKMToLocalStorage();
    } catch (error) {
      showError('Không thể tải danh sách chương trình khuyến mãi');
      ctkmList = getCTKMFromLocalStorage();
    }

    promoList.innerHTML = '';

    if (ctkmList.length === 0) {
      promoList.innerHTML = `
        <div class="settings-empty-state">
          <i class="fas fa-tags"></i>
          <p>Chưa có chương trình khuyến mãi nào</p>
        </div>
      `;
      return;
    }

    ctkmList.forEach((ctkm) => {
      const item = document.createElement('div');
      item.className = 'settings-item-card';
      item.innerHTML = `
        <div class="settings-item-header">
          <h4 class="settings-item-title">${ctkm.ctkm_name}</h4>
          <span class="settings-item-badge ${ctkm.status === 'active' ? 'active' : 'inactive'}">
            ${ctkm.status === 'active' ? 'Đang hoạt động' : 'Ngưng hoạt động'}
          </span>
        </div>
        <div class="settings-item-body">
          <div class="settings-item-info">
            <i class="fas fa-money-bill-wave"></i>
            <span>Giá trị:</span>
            <span class="settings-item-value">${formatCurrency(ctkm.value)}</span>
          </div>
          <div class="settings-item-info">
            <i class="fas fa-calendar-alt"></i>
            <span>Thời gian:</span>
            <span class="settings-item-value">
              ${new Date(ctkm.start_date).toLocaleDateString('vi-VN')} -
              ${new Date(ctkm.end_date).toLocaleDateString('vi-VN')}
            </span>
          </div>
          <div class="settings-item-info">
            <i class="fas fa-crown"></i>
            <span>Hạng thành viên:</span>
            <span class="settings-item-value">
              ${
                Array.isArray(ctkm.membership_label)
                  ? ctkm.membership_label.join(', ')
                  : ctkm.membership_label || 'Tất cả'
              }
            </span>
          </div>
          ${
            ctkm.description
              ? `<div class="settings-item-description">${ctkm.description}</div>`
              : ''
          }
        </div>
        <div class="settings-item-footer">
          <button class="settings-item-action edit edit-ctkm-btn" data-name="${ctkm.ctkm_name}">
            <i class="fas fa-edit"></i> Sửa
          </button>
          <button class="settings-item-action delete delete-ctkm-btn" data-name="${ctkm.ctkm_name}">
            <i class="fas fa-trash"></i> Xóa
          </button>
        </div>
      `;
      promoList.appendChild(item);
    });

    document.querySelectorAll('.edit-ctkm-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        const ctkm = ctkmList.find((c) => c.ctkm_name === btn.dataset.name);
        showPromoForm(true, ctkm);
      });
    });

    document.querySelectorAll('.delete-ctkm-btn').forEach((btn) => {
      btn.addEventListener('click', () => deleteCTKM(btn.dataset.name));
    });
  }

  async function loadVoucherList() {
    const voucherList = document.getElementById('voucherList');
    if (!voucherList) return;

    try {
      vouchers = await fetchAPI('settings/ctkm?promo_type=voucher');
      vouchers = vouchers.filter((voucher) => voucher.promo_type === 'voucher'); // Đảm bảo lọc ở frontend
      saveVouchersToLocalStorage();
    } catch (error) {
      alert('Không thể tải danh sách mã ưu đãi');
      vouchers = getVouchersFromLocalStorage();
    }

    let services = getServicesFromLocalStorage() || [];
    if (services.data && Array.isArray(services.data)) {
      services = services.data;
    }

    voucherList.innerHTML = '';

    if (vouchers.length === 0) {
      voucherList.innerHTML = `
        <div class="settings-empty-state">
          <i class="fas fa-ticket-alt"></i>
          <p>Chưa có mã ưu đãi nào</p>
        </div>
      `;
      return;
    }

    vouchers.forEach((voucher) => {
      // Xử lý applicable_services có thể là chuỗi JSON
      let applicableServices = [];
      if (typeof voucher.applicable_services === 'string') {
        try {
          applicableServices = JSON.parse(voucher.applicable_services);
        } catch (e) {
          applicableServices = [];
        }
      } else if (Array.isArray(voucher.applicable_services)) {
        applicableServices = voucher.applicable_services;
      }

      // Ánh xạ service_id sang service_name
      const serviceNames = applicableServices
        .map((id) => {
          const service = services.find((s) => s.service_id === id);
          return service ? service.service_name : `Dịch vụ không xác định (${id})`;
        })
        .join(', ');

      const item = document.createElement('div');
      item.className = 'settings-item-card';
      item.innerHTML = `
        <div class="settings-item-header">
          <h4 class="settings-item-title">${voucher.ctkm_name}</h4>
          <span class="settings-item-badge ${voucher.status === 'active' ? 'active' : 'inactive'}">
            ${voucher.status === 'active' ? 'Đang hoạt động' : 'Ngưng hoạt động'}
          </span>
        </div>
        <div class="settings-item-body">
          <div class="settings-item-info">
            <i class="fas fa-money-bill-wave"></i>
            <span>Giá trị:</span>
            <span class="settings-item-value">${formatCurrency(voucher.value)}</span>
          </div>
          <div class="settings-item-info">
            <i class="fas fa-calendar-alt"></i>
            <span>Thời gian:</span>
            <span class="settings-item-value">
              ${new Date(voucher.start_date).toLocaleDateString('vi-VN')} -
              ${new Date(voucher.end_date).toLocaleDateString('vi-VN')}
            </span>
          </div>
          <div class="settings-item-info">
            <i class="fas fa-crown"></i>
            <span>Hạng thành viên:</span>
            <span class="settings-item-value">
              ${
                Array.isArray(voucher.membership_label)
                  ? voucher.membership_label.join(', ')
                  : voucher.membership_label || 'Tất cả'
              }
            </span>
          </div>
          <div class="settings-item-info">
            <i class="fas fa-cut"></i>
            <span>Dịch vụ áp dụng:</span>
            <span class="settings-item-value">${serviceNames || 'Không có'}</span>
          </div>
          ${
            voucher.description
              ? `<div class="settings-item-description">${voucher.description}</div>`
              : ''
          }
        </div>
        <div class="settings-item-footer">
          <button class="settings-item-action edit edit-voucher-btn" data-name="${
            voucher.ctkm_name
          }">
            <i class="fas fa-edit"></i> Sửa
          </button>
          <button class="settings-item-action delete delete-voucher-btn" data-name="${
            voucher.ctkm_name
          }">
            <i class="fas fa-trash"></i> Xóa
          </button>
        </div>
      `;
      voucherList.appendChild(item);
    });

    // Gắn sự kiện cho các nút
    document.querySelectorAll('.edit-voucher-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        const voucher = vouchers.find((v) => v.ctkm_name === btn.dataset.name);
        showVoucherForm(true, voucher);
      });
    });

    document.querySelectorAll('.delete-voucher-btn').forEach((btn) => {
      btn.addEventListener('click', () => deleteCTKM(btn.dataset.name));
    });
  }

  async function saveCTKM(e) {
    e.preventDefault();
    const form = e.target;
    const isVoucherForm = form.id === 'voucherForm';
    const name = document.getElementById(isVoucherForm ? 'voucherName' : 'promoName').value.trim();
    const value =
      parseInt(document.getElementById(isVoucherForm ? 'voucherValue' : 'promoValue').value) || 0;
    const description = document
      .getElementById(isVoucherForm ? 'voucherDescription' : 'promoDescription')
      .value.trim();
    const startDate = document.getElementById(
      isVoucherForm ? 'voucherStartDate' : 'promoStartDate'
    ).value;
    const endDate = document.getElementById(
      isVoucherForm ? 'voucherEndDate' : 'promoEndDate'
    ).value;
    const status = document.getElementById(isVoucherForm ? 'voucherStatus' : 'promoStatus').value;

    const membershipCheckboxes = document.querySelectorAll(
      `#${isVoucherForm ? 'voucherMembership' : 'promoMembership'} input[type="checkbox"]:checked`
    );
    const membershipLabel = Array.from(membershipCheckboxes).map((cb) => cb.value);

    let applicableServices = [];
    if (isVoucherForm) {
      const voucherServicesSelect = document.getElementById('voucherServices');
      applicableServices = Array.from(voucherServicesSelect.selectedOptions).map(
        (option) => option.value
      );
    }

    if (
      !name ||
      value < 0 ||
      !startDate ||
      !endDate ||
      membershipLabel.length === 0 ||
      !status ||
      (isVoucherForm && applicableServices.length === 0)
    ) {
      alert('Vui lòng điền đầy đủ và hợp lệ các trường bắt buộc');
      return;
    }

    const start = new Date(startDate);
    const end = new Date(endDate);
    if (start > end) {
      alert('Ngày bắt đầu phải nhỏ hơn hoặc bằng ngày kết thúc');
      return;
    }

    const ctkmData = {
      ctkm_name: name,
      value,
      description,
      start_date: startDate,
      end_date: endDate,
      membership_label: membershipLabel,
      status,
      applicable_services: applicableServices,
      promo_type: isVoucherForm ? 'voucher' : 'ctkm', // Thêm promo_type
    };

    try {
      if (isVoucherForm ? isEditingVoucher : isEditingCTKM) {
        await fetchAPI('settings/ctkm', {
          method: 'PUT',
          body: JSON.stringify(ctkmData),
        });
        alert(isVoucherForm ? 'Cập nhật Mã Ưu Đãi thành công!' : 'Cập nhật CTKM thành công!');
      } else {
        await fetchAPI('settings/ctkm', {
          method: 'POST',
          body: JSON.stringify(ctkmData),
        });
        alert(isVoucherForm ? 'Tạo Mã Ưu Đãi thành công!' : 'Tạo CTKM thành công!');
      }

      ctkmList = await fetchAPI('settings/ctkm');
      ctkmList = ctkmList.filter(
        (ctkm) => !ctkm.applicable_services || ctkm.applicable_services.length === 0
      );
      vouchers = await fetchAPI('settings/ctkm');
      vouchers = vouchers.filter(
        (voucher) => voucher.applicable_services && voucher.applicable_services.length > 0
      );
      saveCTKMToLocalStorage();
      saveVouchersToLocalStorage();
      loadCTKMList();
      loadVoucherList();
      loadPromoSettings();
      isVoucherForm ? hideVoucherForm() : hidePromoForm();
    } catch (error) {
      alert(`${error.message}`);
    }
  }

  async function deleteCTKM(name) {
    try {
      await fetchAPI(`settings/ctkm/${name}`, {
        method: 'DELETE',
      });
      ctkmList = await fetchAPI('settings/ctkm');
      ctkmList = ctkmList.filter(
        (ctkm) => !ctkm.applicable_services || ctkm.applicable_services.length === 0
      );
      vouchers = await fetchAPI('settings/ctkm');
      vouchers = vouchers.filter(
        (voucher) => voucher.applicable_services && voucher.applicable_services.length > 0
      );
      saveCTKMToLocalStorage();
      saveVouchersToLocalStorage();
      loadCTKMList();
      loadVoucherList();
      loadPromoSettings();
      alert('Xóa thành công!');
    } catch (error) {
      alert(`${error.message}`);
    }
  }

  // ==============================
  // 12. BOOKING MANAGEMENT
  // ==============================
  // --- Booking Loading ---

  async function loadStaffBookings(filter = 'today', startDate = null, endDate = null) {
    const funcStart = performance.now();
    perfLog.mark(`📅 START loadStaffBookings(${filter})`);
    try {
      const displayName = checkinData.currentUser.display_name;
      if (!displayName) {
        throw new Error('Missing display_name');
      }

      let url = `staff-bookings?staff_name=${encodeURIComponent(displayName)}&filter=${filter}`;
      if (filter === 'custom' && startDate && endDate) {
        url += `&start_date=${startDate}&end_date=${endDate}`;
      }

      const response = await fetchAPI(url);

      // === XỬ LÝ CẢ 2 TRƯỜNG HỢP ===
      let rawData = [];
      if (Array.isArray(response)) {
        // Trường hợp fetchAPI trả về mảng trực tiếp
        rawData = response;
      } else if (response && response.success && Array.isArray(response.data)) {
        // Trường hợp chuẩn: { success, data }
        rawData = response.data;
      } else {
        rawData = [];
      }

      // Gán dữ liệu
      bookingsData = rawData.map((booking) => ({
        ...booking,
        customer_images: Array.isArray(booking.customer_images) ? booking.customer_images : [],
        booking_images: Array.isArray(booking.booking_images) ? booking.booking_images : [],
        display_image: booking.display_image || 'https://randomuser.me/api/portraits/lego/1.jpg',
      }));

      // Sắp xếp theo thời gian booking (mới nhất trước)
      bookingsData.sort((a, b) => {
        const dateA = new Date(`${a.booking_date}T${a.booking_time || '00:00:00'}`);
        const dateB = new Date(`${b.booking_date}T${b.booking_time || '00:00:00'}`);
        return dateB - dateA;
      });

      saveBookingsToLocalStorage();

      // ✅ Export bookingsData to window for dashboard module
      window.bookingsData = bookingsData;

      perfLog.mark(`✅ END loadStaffBookings(${filter}) - ${bookingsData.length} bookings`);
    } catch (error) {
      perfLog.mark(`❌ ERROR loadStaffBookings(${filter})`);
      bookingsData = [];
      saveBookingsToLocalStorage();
      throw error; // Ném lỗi để renderBookingList xử lý
    }
  }
  // ✅ Export loadStaffBookings for dashboard module
  window.loadStaffBookings = loadStaffBookings;

  // === CẤU HÌNH CỘT ===
  const BOOKING_COLUMN_CONFIG = [
    { key: 'image', label: 'Ảnh', locked: true },
    { key: 'id', label: 'ID Booking', locked: true },
    { key: 'date', label: 'Ngày hẹn', locked: true },
    { key: 'customer', label: 'Khách hàng', locked: true },
    { key: 'phone', label: 'Số điện thoại', locked: false },
    { key: 'staff', label: 'Thợ yêu cầu', locked: false },
    { key: 'service', label: 'Dịch vụ', locked: true },
    { key: 'status', label: 'Trạng thái', locked: true },
    { key: 'message', label: 'Gửi lịch hẹn', locked: false },
    { key: 'reminder', label: 'Nhắc lịch hẹn', locked: false },
    { key: 'cancel', label: 'Hủy lịch hẹn', locked: false },
    { key: 'note', label: 'Ghi chú', locked: false },
    { key: 'actions', label: 'Thao tác', locked: true },
  ];

  const INVENTORY_COLUMN_CONFIG = [
    { key: 'checkCode', label: 'Mã phiếu', locked: true },
    { key: 'staffName', label: 'Nhân viên', locked: true },
    { key: 'checkDate', label: 'Ngày kiểm', locked: true },
    { key: 'totalProducts', label: 'Tổng SP', locked: false },
    { key: 'mismatchedCount', label: 'Không khớp', locked: false },
    { key: 'status', label: 'Trạng thái', locked: true },
    { key: 'note', label: 'Ghi chú', locked: false },
    { key: 'actions', label: 'Thao tác', locked: true },
  ];

  const TRANSACTION_COLUMN_CONFIG = [
    { key: 'transactionId', label: 'Mã phiếu', locked: true },
    { key: 'type', label: 'Loại', locked: true },
    { key: 'date', label: 'Ngày', locked: true },
    { key: 'staff', label: 'Nhân viên', locked: false },
    { key: 'status', label: 'Trạng thái', locked: true },
    { key: 'products', label: 'Sản phẩm', locked: false },
    { key: 'quantity', label: 'Số lượng', locked: false },
    { key: 'actions', label: 'Thao tác', locked: true },
  ];

  // --- Booking Rendering & Display ---

  async function renderBookingList() {
    const tbody = document.querySelector('#bookingsListTabs tbody');
    if (!tbody) return;

    tbody.innerHTML = '<tr><td colspan="13" class="p-3 text-center">Đang tải...</td></tr>';

    try {
      const bookingItemsPerPage = parseInt(localStorage.getItem('bookingItemsPerPage')) || 25;
      // Update select value when rendering
      const itemsPerPageSelect = document.getElementById('booking-items-per-page');
      if (itemsPerPageSelect) {
        itemsPerPageSelect.value = bookingItemsPerPage;
      }
      let startDate = null;
      let endDate = null;
      if (currentBookingFilter === 'custom') {
        startDate = localStorage.getItem('customStartBookingDate');
        endDate = localStorage.getItem('customEndBookingDate');
      }
      await loadStaffBookings(currentBookingFilter, startDate, endDate);

      if (!bookingsData || bookingsData.length === 0) {
        tbody.innerHTML =
          '<tr><td colspan="13" class="p-3 text-center text-gray-500">Không có lịch hẹn nào</td></tr>';
        applyBookingColumnVisibility(); // ← Vẫn cần gọi để ẩn cột nếu có
        // Update pagination UI for empty data
        updateBookingPaginationUI(0, bookingItemsPerPage, currentBookingPage);
        return;
      }

      // === GỌI TRƯỚC KHI RENDER ĐỂ ĐẢM BẢO CỘT ĐÃ SẴN SÀNG ===
      applyBookingColumnVisibility();

      // Sắp xếp bookings theo thời gian (mới nhất trước)
      bookingsData.sort((a, b) => {
        const dateA = new Date(`${a.booking_date}T${a.booking_time || '00:00:00'}`);
        const dateB = new Date(`${b.booking_date}T${b.booking_time || '00:00:00'}`);
        return dateB - dateA; // Giảm dần (mới nhất trước)
      });

      // === PAGINATION LOGIC ===
      totalBookingItems = bookingsData.length;

      // ✅ Auto-reset page nếu vượt quá dữ liệu thực tế
      const maxPages = Math.ceil(totalBookingItems / bookingItemsPerPage) || 1;
      if (currentBookingPage > maxPages) {
        currentBookingPage = 1;
        try { localStorage.setItem('bookingPage', '1'); } catch (e) {}
      }

      const startIndex = (currentBookingPage - 1) * bookingItemsPerPage;
      const endIndex = startIndex + bookingItemsPerPage;
      const paginatedData = bookingsData.slice(startIndex, endIndex);

      renderBookingRows(paginatedData);

      // === UPDATE PAGINATION UI ===
      updateBookingPaginationUI(totalBookingItems, bookingItemsPerPage, currentBookingPage);
    } catch (err) {
      tbody.innerHTML =
        '<tr><td colspan="13" class="p-3 text-center text-red-500">Lỗi tải dữ liệu</td></tr>';
      applyBookingColumnVisibility(); // ← Vẫn cần
      toastError('Không thể tải lịch hẹn');
    }
  }

  // === RENDER ROWS (GIỮ NGUYÊN LOGIC CŨ) ===
  function renderBookingRows(data) {
    const tbody = document.querySelector('#bookingsListTabs tbody');
    if (!tbody) {
      return;
    }

    if (!data || data.length === 0) {
      tbody.innerHTML =
        '<tr><td colspan="13" class="p-3 text-center text-gray-500">Không có lịch hẹn nào</td></tr>';
      return;
    }

    let html = '';
    data.forEach((booking, index) => {
      const images = [...(booking.booking_images || []), ...(booking.customer_images || [])].filter(
        Boolean
      );

      const statusClass =
        {
          success: 'status-success',
          deleted: 'status-deleted',
          pending: 'status-pending',
          waiting: 'status-waiting',
        }[booking.status] || 'status-waiting';

      const messageStatusClass =
        {
          success: 'status-message-success',
          failed: 'status-message-failed',
        }[booking.message_status] || 'status-message-failed';

      const reminderStatusClass =
        {
          success: 'status-reminder-success',
          deleted: 'status-reminder-deleted',
          start: 'status-reminder-waiting',
          failed: 'status-reminder-failed',
        }[booking.reminder_status] || 'status-reminder-waiting';

      const cancelStatusClass =
        {
          success: 'status-cancel-success',
          failed: 'status-cancel-failed',
        }[booking.cancel_message_status] || 'status-cancel-failed';

      const statusText =
        booking.status === 'success'
          ? 'Hoàn thành'
          : booking.status === 'deleted'
            ? 'Đã hủy'
            : booking.status === 'pending'
              ? 'Đang phục vụ'
              : 'Chờ phục vụ';

      const messageText =
        booking.message_status === 'success'
          ? 'Đã gửi'
          : !booking.cancel_message_status?.trim()
            ? ''
            : 'Gửi thất bại';

      const reminderText =
        booking.reminder_status === 'success'
          ? 'Đã nhắc hẹn'
          : booking.reminder_status === 'deleted'
            ? 'Đã hủy'
            : !booking.reminder_status || booking.reminder_status === 'start'
              ? 'Chờ nhắc hẹn'
              : 'Nhắc hẹn thất bại';

      const cancelText =
        booking.cancel_message_status === 'success'
          ? 'Đã gửi'
          : !booking.cancel_message_status?.trim()
            ? ''
            : 'Gửi thất bại';

      html += `
      <tr class="hover:bg-gray-50" data-id="${booking.id_booking}">
        <td class="p-3 image-column">
          <img src="${booking.display_image}" alt="Display Image"
               class="w-7 h-7 rounded-full object-cover cursor-pointer customer-image"
               data-images='${JSON.stringify(images)}'>
        </td>
        <td class="p-3 id-column">${booking.id_booking}</td>
        <td class="p-3 date-column">${new Date(booking.booking_date).toLocaleDateString('vi-VN')} ${(
          booking.booking_time || ''
        ).slice(0, 5)}</td>
        <td class="p-3 customer-column">${booking.customer_name}</td>
        <td class="p-3 phone-column"><span class="phone-text">${booking.customer_phone}</span><button type="button" class="booking-id-copy" data-id="${booking.id_booking}" title="Sao chép ID lịch hẹn">#${booking.id_booking} <i class="far fa-copy"></i></button></td>
        <td class="p-3 staff-column">${booking.hairdresser_name || 'Chưa xác định'}</td>
        <td class="p-3 service-column">${booking.service_name}</td>
        <td class="p-3 status-column">
          <span class="${statusClass} px-2 py-1 rounded text-xs font-medium">
            ${statusText}
          </span>
        </td>
        <td class="p-3 message-column">
          <div class="flex items-center justify-center">
            ${
              messageText
                ? `<span class="${messageStatusClass} px-2 py-1 rounded text-xs font-medium">${messageText}</span>`
                : ''
            }
            ${
              booking.message_status && booking.message_status !== 'success'
                ? `<button class="resend-message-btn text-blue-500 hover:text-blue-700 ml-2" data-id="${booking.id_booking}" title="Gửi lại lịch hẹn">
              <i class="fas fa-redo"></i>
            </button>`
                : ''
            }
          </div>
        </td>
        <td class="p-3 reminder-column">
          <div class="flex items-center justify-center">
            ${
              reminderText
                ? `<span class="${reminderStatusClass} px-2 py-1 rounded text-xs font-medium">${reminderText}</span>`
                : ''
            }
            ${
              booking.reminder_status && booking.reminder_status !== 'success'
                ? `<button class="resend-reminder-btn text-blue-500 hover:text-blue-700 ml-2" data-id="${booking.id_booking}" title="Gửi lại nhắc hẹn">
              <i class="fas fa-redo"></i>
            </button>`
                : ''
            }
          </div>
        </td>
        <td class="p-3 cancel-column">
          <div class="flex items-center justify-center">
            ${
              cancelText
                ? `<span class="${cancelStatusClass} px-2 py-1 rounded text-xs font-medium">${cancelText}</span>`
                : ''
            }
            ${
              booking.cancel_message_status && booking.cancel_message_status !== 'success'
                ? `<button class="resend-cancel-btn text-blue-500 hover:text-blue-700 ml-2" data-id="${booking.id_booking}" title="Gửi lại hủy lịch">
              <i class="fas fa-redo"></i>
            </button>`
                : ''
            }
          </div>
        </td>
        <td class="p-3 note-column">
          <span class="text-red-600 font-medium">${booking.customer_note || ''}</span>
        </td>
        <td class="p-3 actions-column text-center">
          ${
            booking.status !== 'deleted'
              ? `
            <button class="cancel-booking-btn text-red-500 hover:text-red-700 mr-2 relative" data-id="${booking.id_booking}" title="Hủy">
              <i class="fas fa-trash cancel-icon"></i>
              <i class="fas fa-spinner fa-spin cancel-loading-icon hidden"></i>
            </button>
          `
              : ''
          }
        </td>
        <td class="booking-badges-cell">
          ${
            messageText
              ? `<span class="${messageStatusClass} px-2 py-1 rounded text-xs font-medium">${messageText}</span>`
              : ''
          }
          ${
            booking.message_status && booking.message_status !== 'success'
              ? `<button class="resend-message-btn text-blue-500" data-id="${booking.id_booking}" title="Gửi lại lịch hẹn"><i class="fas fa-redo"></i></button>`
              : ''
          }
          ${
            reminderText
              ? `<span class="${reminderStatusClass} px-2 py-1 rounded text-xs font-medium">${reminderText}</span>`
              : ''
          }
          ${
            booking.reminder_status && booking.reminder_status !== 'success'
              ? `<button class="resend-reminder-btn text-blue-500" data-id="${booking.id_booking}" title="Gửi lại nhắc hẹn"><i class="fas fa-redo"></i></button>`
              : ''
          }
        </td>
      </tr>
    `;
    });

    tbody.innerHTML = html;

    // === THÊM: ÁP DỤNG ẨN CỘT SAU KHI RENDER ===
    applyBookingColumnVisibility();

    // 📱 Gắn nhãn cho chế độ card mobile
    annotateTableForMobileCards(document.getElementById('bookingsListTabs'));

    // === THÊM EVENT LISTENERS SAU KHI RENDER ===
    tbody.querySelectorAll('tr').forEach((row) => {
      row.addEventListener('click', async (e) => {
        // Ảnh
        if (e.target.closest('.customer-image')) {
          const images = JSON.parse(e.target.closest('.customer-image').dataset.images || '[]');
          openImagePopup(images);
          return;
        }

        // Sao chép ID lịch hẹn — icon copy đổi thành tick khi xong
        if (e.target.closest('.booking-id-copy')) {
          e.stopPropagation();
          const copyBtn = e.target.closest('.booking-id-copy');
          const id = String(copyBtn.dataset.id || '');
          try {
            await navigator.clipboard.writeText(id);
          } catch (err) {
            const ta = document.createElement('textarea');
            ta.value = id;
            ta.style.position = 'fixed';
            ta.style.opacity = '0';
            document.body.appendChild(ta);
            ta.select();
            document.execCommand('copy');
            ta.remove();
          }
          const icon = copyBtn.querySelector('i');
          if (icon && !copyBtn.classList.contains('copied')) {
            copyBtn.classList.add('copied');
            icon.className = 'fas fa-check';
            setTimeout(() => {
              icon.className = 'far fa-copy';
              copyBtn.classList.remove('copied');
            }, 1600);
          }
          return;
        }

        // Hủy
        if (e.target.closest('.cancel-booking-btn')) {
          e.stopPropagation();
          const btn = e.target.closest('.cancel-booking-btn');
          const id = btn.dataset.id;

          // Show loading state
          const trashIcon = btn.querySelector('.cancel-icon');
          const loadingIcon = btn.querySelector('.cancel-loading-icon');
          if (trashIcon) trashIcon.classList.add('hidden');
          if (loadingIcon) loadingIcon.classList.remove('hidden');
          btn.disabled = true;

          try {
            await openCancelBookingModal(id);
          } finally {
            // Reset loading state
            if (trashIcon) trashIcon.classList.remove('hidden');
            if (loadingIcon) loadingIcon.classList.add('hidden');
            btn.disabled = false;
          }
          return;
        }

        // Gửi lại message
        if (e.target.closest('.resend-message-btn')) {
          e.stopPropagation();
          const id = e.target.closest('.resend-message-btn').dataset.id;
          const confirmed = await showConfirm(
            'Bạn có chắc muốn gửi lại thông báo lịch hẹn này?',
            'Xác nhận gửi lại'
          );
          if (confirmed) {
            resendBookingNotification(id);
            toastSuccess('Đã gửi lại thông báo lịch hẹn');
          }
          return;
        }

        // Gửi lại reminder
        if (e.target.closest('.resend-reminder-btn')) {
          e.stopPropagation();
          const id = e.target.closest('.resend-reminder-btn').dataset.id;
          const confirmed = await showConfirm(
            'Bạn có chắc muốn gửi lại nhắc hẹn này?',
            'Xác nhận gửi lại'
          );
          if (confirmed) {
            resendReminderNotification(id);
            toastSuccess('Đã gửi lại nhắc hẹn');
          }
          return;
        }

        // Gửi lại cancel
        if (e.target.closest('.resend-cancel-btn')) {
          e.stopPropagation();
          const id = e.target.closest('.resend-cancel-btn').dataset.id;
          const confirmed = await showConfirm(
            'Bạn có chắc muốn gửi lại thông báo hủy lịch này?',
            'Xác nhận gửi lại'
          );
          if (confirmed) {
            resendCancelNotification(id);
            toastSuccess('Đã gửi lại thông báo hủy lịch');
          }
          return;
        }

        // Bấm vào card → mở chi tiết lịch hẹn
        openBookingDetailModal(row.dataset.id);
      });
    });
  }

  // === MODAL CHI TIẾT LỊCH HẸN (giao diện đồng bộ modal chi tiết hoá đơn) ===
  function openBookingDetailModal(bookingId) {
    try {
      if (!elements.invoicesDetailContent || !bookingId) {
        return;
      }

      const booking = bookingsData.find(
        (b) => String(b.id_booking) === String(bookingId) || String(b.id) === String(bookingId)
      );
      if (!booking) {
        showError('Không tìm thấy lịch hẹn');
        return;
      }

      const images = [...(booking.booking_images || []), ...(booking.customer_images || [])].filter(
        Boolean
      );
      const bookingDate = new Date(booking.booking_date).toLocaleDateString('vi-VN');
      const bookingTime = (booking.booking_time || '').slice(0, 5);

      const statusChip =
        booking.status === 'success'
          ? '<span class="status-paid">Hoàn thành</span>'
          : booking.status === 'deleted'
            ? '<span class="status-cancelled">Đã hủy</span>'
            : booking.status === 'pending'
              ? '<span class="status-serving">Đang phục vụ</span>'
              : '<span class="status-serving">Chờ phục vụ</span>';

      const messageText =
        booking.message_status === 'success'
          ? 'Đã gửi'
          : booking.message_status
            ? 'Gửi thất bại'
            : 'Chưa gửi';
      const reminderText =
        booking.reminder_status === 'success'
          ? 'Đã nhắc hẹn'
          : booking.reminder_status === 'deleted'
            ? 'Đã hủy'
            : !booking.reminder_status || booking.reminder_status === 'start'
              ? 'Chờ nhắc hẹn'
              : 'Nhắc hẹn thất bại';

      const services = (booking.service_name || '')
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean);

      const modalContent = `
            <div class="modal-overlay"></div>
            <div class="modal-container">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3 id="invoiceModalTitle" class="modal-title">Lịch hẹn #${booking.id_booking}</h3>
                        <button id="closeBookingModalXBtn" class="close-btn">
                            <i class="fas fa-times text-lg"></i>
                        </button>
                    </div>
                    <div class="modal-section">
                        <div class="modal-grid">
                            <div>
                                <p class="modal-text"><strong>Khách hàng:</strong> ${booking.customer_name}</p>
                                <p class="modal-text"><strong>Số điện thoại:</strong> ${booking.customer_phone}</p>
                                <p class="modal-text"><strong>Ngày hẹn:</strong> ${bookingDate} ${bookingTime}</p>
                            </div>
                            <div>
                                <p class="modal-text"><strong>Thợ:</strong> ${booking.hairdresser_name || 'Chưa xác định'}</p>
                                <p class="modal-text"><strong>Trạng thái:</strong> ${statusChip}</p>
                                <p class="modal-text"><strong>Gửi lịch hẹn:</strong> ${messageText}</p>
                                <p class="modal-text"><strong>Nhắc hẹn:</strong> ${reminderText}</p>
                            </div>
                        </div>
                    </div>
                    <h4 class="section-title">Dịch vụ</h4>
                    <div class="modal-section">
                        ${
                          services.length > 0
                            ? services
                                .map(
                                  (s) => `
                            <div class="service-item">
                                <div>
                                    <div class="service-name">${s}</div>
                                </div>
                            </div>
                        `
                                )
                                .join('')
                            : '<p class="no-services">Không có dịch vụ</p>'
                        }
                    </div>
                    ${
                      booking.customer_note
                        ? `
                    <h4 class="section-title">Ghi chú</h4>
                    <div class="modal-section">
                        <p class="modal-text booking-note-text">${booking.customer_note}</p>
                    </div>
                    `
                        : ''
                    }
                    <h4 class="section-title">Hình ảnh</h4>
                    <div class="modal-section">
                        ${
                          images.length > 0
                            ? `
                            <div class="images-container">
                                ${images
                                  .slice(0, 3)
                                  .map(
                                    (img) => `
                                    <div class="image-wrapper">
                                        <img src="${img}" alt="Booking Image" class="invoice-image">
                                    </div>
                                `
                                  )
                                  .join('')}
                            </div>
                        `
                            : `
                            <div class="no-images">
                                <i class="fas fa-image no-images-icon"></i>
                                <p class="no-services">Không có hình ảnh</p>
                            </div>
                        `
                        }
                    </div>
                    ${
                      booking.status !== 'deleted' && booking.status !== 'success'
                        ? `
                        <div class="actions-container">
                            <button id="cancelBookingDetailBtn" class="action-btn not-image-btn">Hủy lịch hẹn</button>
                        </div>
                    `
                        : ''
                    }
                </div>
            </div>
        `;

      // Modal gốc nằm trong #invoicesContent (bị hidden khi ở tab khác)
      // → dời ra body để hiển thị được từ tab Lịch hẹn
      if (elements.invoicesDetailContent.parentElement !== document.body) {
        document.body.appendChild(elements.invoicesDetailContent);
      }
      elements.invoicesDetailContent.innerHTML = modalContent;
      openModal(elements.invoicesDetailContent);

      // Xem ảnh lớn
      elements.invoicesDetailContent.querySelectorAll('.invoice-image').forEach((img) => {
        img.addEventListener('click', () => openImagePopup(images));
      });

      // Nút hủy lịch
      const cancelBtn = document.getElementById('cancelBookingDetailBtn');
      if (cancelBtn) {
        cancelBtn.addEventListener('click', () => {
          closeModal(elements.invoicesDetailContent);
          openCancelBookingModal(booking.id_booking);
        });
      }

      // Đóng modal
      const closeXBtn = document.getElementById('closeBookingModalXBtn');
      const modalOverlay = elements.invoicesDetailContent.querySelector('.modal-overlay');
      if (closeXBtn) {
        closeXBtn.addEventListener('click', () => closeModal(elements.invoicesDetailContent));
      }
      if (modalOverlay) {
        modalOverlay.addEventListener('click', () => closeModal(elements.invoicesDetailContent));
      }
      document.addEventListener('keydown', function closeOnEsc(e) {
        if (e.key === 'Escape' && !elements.invoicesDetailContent.classList.contains('hidden')) {
          closeModal(elements.invoicesDetailContent);
          document.removeEventListener('keydown', closeOnEsc);
        }
      });
    } catch (error) {
      showError('Lỗi khi mở chi tiết lịch hẹn');
    }
  }

  // === KHỞI TẠO FILTERS ===
  function initBookingFilters() {
    const select = document.getElementById('quickBookingDateFilter');
    const container = document.getElementById('customBookingDateContainer');
    const startInput = document.getElementById('customStartBookingDate');
    const endInput = document.getElementById('customEndBookingDate');
    const applyBtn = document.getElementById('applyCustomBookingDate');

    select.value = currentBookingFilter;
    if (currentBookingFilter === 'custom') {
      const start = localStorage.getItem('customStartBookingDate');
      const end = localStorage.getItem('customEndBookingDate');
      if (start && end) {
        container.classList.remove('hidden');
        startInput.value = start;
        endInput.value = end;
      }
    }

    // Set items per page select from localStorage
    const itemsPerPageSelect = document.getElementById('booking-items-per-page');
    if (itemsPerPageSelect) {
      const savedItemsPerPage = localStorage.getItem('bookingItemsPerPage') || '25';
      itemsPerPageSelect.value = savedItemsPerPage;
      // Note: itemsPerPage is used for invoice pagination, bookingItemsPerPage for bookings
    }

    select.onchange = () => {
      const val = select.value;
      currentBookingFilter = val;
      localStorage.setItem('currentBookingFilter', val);
      if (val === 'custom') {
        container.classList.remove('hidden');
      } else {
        container.classList.add('hidden');
        localStorage.removeItem('customStartBookingDate');
        localStorage.removeItem('customEndBookingDate');
        currentBookingPage = 1;
        renderBookingList();
      }
    };

    applyBtn.onclick = () => {
      const start = startInput.value;
      const end = endInput.value;
      if (start && end && start <= end) {
        localStorage.setItem('customStartBookingDate', start);
        localStorage.setItem('customEndBookingDate', end);
        currentBookingPage = 1;
        renderBookingList();
      } else {
        alert('Vui lòng chọn khoảng thời gian hợp lệ!');
      }
    };
  }

  // === PHÂN TRANG & CÀI ĐẶT BẢNG ===
  document.getElementById('booking-items-per-page').onchange = (e) => {
    const newItemsPerPage = parseInt(e.target.value);
    localStorage.setItem('bookingItemsPerPage', newItemsPerPage);

    // Reset to page 1 and check if current page is still valid
    const maxPages = Math.ceil(totalBookingItems / newItemsPerPage);
    if (currentBookingPage > maxPages) {
      currentBookingPage = 1;
    }

    renderBookingList();
  };

  document.getElementById('booking-prev-page').onclick = () => {
    if (currentBookingPage > 1) {
      currentBookingPage--;
      localStorage.setItem('bookingPage', currentBookingPage);
      renderBookingList();
    }
  };

  document.getElementById('booking-next-page').onclick = () => {
    const itemsPerPage = parseInt(localStorage.getItem('bookingItemsPerPage')) || 25;
    const totalPages = Math.ceil(totalBookingItems / itemsPerPage);
    if (currentBookingPage < totalPages) {
      currentBookingPage++;
      localStorage.setItem('bookingPage', currentBookingPage);
      renderBookingList();
    }
  };

  function applyBookingColumnVisibility() {
    const settings = JSON.parse(localStorage.getItem('booking_columns') || '{}');
    const table = document.getElementById('bookingsListTabs');
    if (!table) return;

    BOOKING_COLUMN_CONFIG.forEach((col, idx) => {
      const shouldShow = col.locked || settings[col.key] !== false;
      const display = shouldShow ? '' : 'none';

      // Áp dụng cho header
      const header = table.querySelector(`thead th:nth-child(${idx + 1})`);
      if (header) header.style.display = display;

      // Áp dụng cho tất cả các ô trong cột
      table.querySelectorAll(`tbody td:nth-child(${idx + 1})`).forEach((cell) => {
        cell.style.display = display;
      });

      // === ĐÈ CSS MOBILE (nếu có class ẩn) ===
      if (!shouldShow) {
        const className = col.key + '-column';
        table.querySelectorAll(`.${className}`).forEach((el) => {
          el.style.display = 'none';
        });
      }
    });
  }

  function applyInventoryColumnVisibility() {
    const settings = JSON.parse(localStorage.getItem('inventory_columns') || '{}');
    const table = document.querySelector('.inventory-list-table');
    if (!table) return;

    INVENTORY_COLUMN_CONFIG.forEach((col, idx) => {
      const shouldShow = col.locked || settings[col.key] !== false;
      const display = shouldShow ? '' : 'none';

      // Áp dụng cho header
      const header = table.querySelector(`thead th:nth-child(${idx + 1})`);
      if (header) header.style.display = display;

      // Áp dụng cho tất cả các ô trong cột
      table.querySelectorAll(`tbody td:nth-child(${idx + 1})`).forEach((cell) => {
        cell.style.display = display;
      });
    });
  }

  function applyTransactionColumnVisibility() {
    const settings = JSON.parse(localStorage.getItem('transaction_columns') || '{}');
    const table = document.querySelector('.transaction-list-table');
    if (!table) return;

    TRANSACTION_COLUMN_CONFIG.forEach((col, idx) => {
      const shouldShow = col.locked || settings[col.key] !== false;
      const display = shouldShow ? '' : 'none';

      // Áp dụng cho header
      const header = table.querySelector(`thead th:nth-child(${idx + 1})`);
      if (header) header.style.display = display;

      // Áp dụng cho tất cả các ô trong cột
      table.querySelectorAll(`tbody td:nth-child(${idx + 1})`).forEach((cell) => {
        cell.style.display = display;
      });
    });
  }

  function resendBookingNotification(id_booking) {
    fetchAPI(`bookings/${id_booking}/resend`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-WP-Nonce': checkinData.nonce,
      },
    })
      .then((result) => {
        if (result.success) {
          showCheckinToast({
            message: result.message || 'Gửi lại thông báo thành công!',
            type: 'success',
          });
          renderBookingList();
        } else {
          showCheckinToast({
            message: result.message || 'Lỗi khi gửi lại thông báo!',
            type: 'error',
          });
        }
      })
      .catch((err) => {
        showCheckinToast({
          message: 'Đã xảy ra lỗi khi gửi lại thông báo.',
          type: 'error',
        });
      });
  }

  function resendReminderNotification(id_booking) {
    fetchAPI(`bookings/${id_booking}/resend-reminder`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-WP-Nonce': checkinData.nonce,
      },
    })
      .then((result) => {
        if (result.success) {
          showCheckinToast({
            message: result.message || 'Gửi lại nhắc hẹn thành công!',
            type: 'success',
          });
          renderBookingList();
        } else {
          showCheckinToast({
            message: result.message || 'Lỗi khi gửi lại nhắc hẹn!',
            type: 'error',
          });
        }
      })
      .catch((err) => {
        showCheckinToast({
          message: 'Đã xảy ra lỗi khi gửi lại nhắc hẹn.',
          type: 'error',
        });
      });
  }

  function resendCancelNotification(id_booking) {
    fetchAPI(`bookings/${id_booking}/resend-cancel`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-WP-Nonce': checkinData.nonce,
      },
    })
      .then((result) => {
        if (result.success) {
          showCheckinToast({
            message: result.message || 'Gửi lại thông báo hủy lịch thành công!',
            type: 'success',
          });
          renderBookingList();
        } else {
          showCheckinToast({
            message: result.message || 'Lỗi khi gửi lại thông báo hủy lịch!',
            type: 'error',
          });
        }
      })
      .catch((err) => {
        showCheckinToast({
          message: 'Đã xảy ra lỗi khi gửi lại thông báo hủy lịch.',
          type: 'error',
        });
      });
  }

  async function deleteBookingFromDB(id_booking) {
    try {
      await fetchAPI(`bookings/${id_booking}`, {
        method: 'DELETE',
        credentials: 'include',
        headers: {
          'X-WP-Nonce': checkinData.nonce,
        },
      });

      const index = bookingsData.findIndex((b) => b.id_booking === id_booking);
      if (index !== -1) {
        bookingsData[index].status = 'deleted';
      }

      renderBookingList();
      showCheckinToast({
        message: 'Hủy lịch hẹn thành công!',
        type: 'success',
      });
    } catch (error) {
      showCheckinToast({
        message: 'Lỗi khi hủy lịch hẹn',
        type: 'error',
      });
    }
  }

  function updateBookingPaginationUI(totalItems, itemsPerPage, currentPage) {
    const paginationInfo = document.getElementById('booking-pagination-info');
    const prevBtn = document.getElementById('booking-prev-page');
    const nextBtn = document.getElementById('booking-next-page');

    if (!paginationInfo || !prevBtn || !nextBtn) return;

    // Get the pagination buttons container (parent of prevBtn)
    const paginationButtons = prevBtn.parentElement;

    const totalPages = Math.ceil(totalItems / itemsPerPage);
    const startItem = totalItems === 0 ? 0 : (currentPage - 1) * itemsPerPage + 1;
    const endItem = Math.min(currentPage * itemsPerPage, totalItems);

    // Update pagination info
    paginationInfo.textContent = `Hiển thị ${startItem} - ${endItem} / Tổng ${totalItems}`;

    // Clear existing page buttons (keep prev and next)
    const existingPageButtons = paginationButtons.querySelectorAll(
      '.pagination-btn:not(#booking-prev-page):not(#booking-next-page)'
    );
    existingPageButtons.forEach((btn) => btn.remove());

    // Create page number buttons
    if (totalPages > 1) {
      // Insert page buttons between prev and next
      for (let i = 1; i <= totalPages; i++) {
        const pageBtn = document.createElement('button');
        pageBtn.className = 'pagination-btn';
        pageBtn.id = `booking-page-${i}`;
        pageBtn.textContent = i;
        pageBtn.dataset.page = i;

        if (i === currentPage) {
          pageBtn.classList.add('active');
        }

        pageBtn.onclick = () => {
          currentBookingPage = i;
          localStorage.setItem('bookingPage', currentBookingPage);
          renderBookingList();
        };

        // Insert before next button
        paginationButtons.insertBefore(pageBtn, nextBtn);
      }
    }

    // Update prev/next button states
    prevBtn.disabled = currentPage <= 1;
    nextBtn.disabled = currentPage >= totalPages;

    // Update button classes for styling
    prevBtn.classList.toggle('disabled', currentPage <= 1);
    nextBtn.classList.toggle('disabled', currentPage >= totalPages);
  }

  /**
   * Modern Image Popup với thumbnails, smooth animations, và responsive
   * @param {Array|string} images - Mảng URLs hoặc single URL
   * @param {number} startIndex - Index ảnh đầu tiên (default: 0)
   */
  function openImagePopup(images, startIndex = 0) {
    const popup = document.getElementById('imagePopup');
    const popupImage = document.getElementById('popupImage');
    const closeBtn = document.getElementById('closePopup');
    const prevBtn = document.getElementById('prevImage');
    const nextBtn = document.getElementById('nextImage');
    const counter = document.getElementById('imageCounter');
    const thumbnailsContainer = document.getElementById('imageThumbnails');
    const loadingIndicator = popup?.querySelector('.image-popup-loading');

    // Validate elements
    if (
      !popup ||
      !popupImage ||
      !closeBtn ||
      !prevBtn ||
      !nextBtn ||
      !counter ||
      !thumbnailsContainer
    ) {
      return;
    }

    // Normalize images to array
    const imageArray = Array.isArray(images) ? images : [images];
    if (imageArray.length === 0) {
      return;
    }

    let currentIndex = Math.max(0, Math.min(startIndex, imageArray.length - 1));
    let touchStartX = 0;
    let touchEndX = 0;

    // ===== UPDATE IMAGE (FAST TRANSITION - USE CSS CLASSES) =====
    function updateImage() {
      const newSrc = imageArray[currentIndex];

      // Nếu src giống nhau, không cần reload
      if (popupImage.src === newSrc) {
        updateThumbnails();
        return;
      }

      // Update UI elements ngay lập tức
      counter.textContent = `${currentIndex + 1} / ${imageArray.length}`;
      prevBtn.disabled = imageArray.length <= 1;
      nextBtn.disabled = imageArray.length <= 1;
      updateThumbnails();

      // Remove loaded class để bắt đầu fade out (CSS transition: opacity 0.25s)
      popupImage.classList.remove('loaded');

      // Đổi src ngay lập tức (không chờ)
      popupImage.src = newSrc;

      // Khi ảnh load xong, add class để fade in
      popupImage.onload = () => {
        popupImage.classList.add('loaded');
        if (loadingIndicator) {
          loadingIndicator.classList.add('hidden');
        }
      };

      popupImage.onerror = () => {
        popupImage.classList.add('loaded');
        if (loadingIndicator) {
          loadingIndicator.classList.add('hidden');
        }
      };

      // Show loading chỉ nếu load lâu hơn 200ms
      const loadingTimeout = setTimeout(() => {
        if (!popupImage.classList.contains('loaded')) {
          if (loadingIndicator) {
            loadingIndicator.classList.remove('hidden');
          }
        }
      }, 200);

      // Nếu ảnh đã cached, hiển thị ngay
      if (popupImage.complete && popupImage.naturalHeight !== 0) {
        clearTimeout(loadingTimeout);
        popupImage.classList.add('loaded');
        if (loadingIndicator) {
          loadingIndicator.classList.add('hidden');
        }
      }

      // Preload ảnh kế tiếp để navigation mượt hơn
      // preloadAdjacentImages(); // ❌ REMOVED: Thumbnails đã load ảnh rồi, không cần preload thêm gây duplicate request
    }

    /* ❌ REMOVED: preloadAdjacentImages - Gây duplicate request mỗi khi chuyển ảnh
    function preloadAdjacentImages() {
      const nextIndex = (currentIndex + 1) % imageArray.length;
      const prevIndex = (currentIndex - 1 + imageArray.length) % imageArray.length;

      // Preload next image
      if (imageArray[nextIndex]) {
        const nextImg = new Image();
        nextImg.src = imageArray[nextIndex];
      }

      // Preload previous image
      if (imageArray[prevIndex] && prevIndex !== nextIndex) {
        const prevImg = new Image();
        prevImg.src = imageArray[prevIndex];
      }
    }
    */

    // ===== RENDER THUMBNAILS =====
    function renderThumbnails() {
      // Clear old content
      thumbnailsContainer.innerHTML = '';

      if (imageArray.length <= 1) {
        thumbnailsContainer.style.display = 'none';
        return;
      }

      thumbnailsContainer.style.display = 'flex';

      // Use DocumentFragment for better performance
      const fragment = document.createDocumentFragment();

      imageArray.forEach((url, index) => {
        const thumb = document.createElement('div');
        thumb.className = 'image-popup-thumbnail';
        if (index === currentIndex) {
          thumb.classList.add('active');
        }

        const img = document.createElement('img');
        img.src = url;
        img.alt = `Thumbnail ${index + 1}`;
        // img.loading = 'lazy'; // ❌ REMOVED: Load eager để làm cache cho ảnh lớn luôn
        img.style.pointerEvents = 'none'; // Prevent image drag

        thumb.appendChild(img);
        thumb.addEventListener(
          'click',
          (e) => {
            e.stopPropagation();
            if (currentIndex !== index) {
              currentIndex = index;
              updateImage();
            }
          },
          { passive: true }
        );

        fragment.appendChild(thumb);
      });

      thumbnailsContainer.appendChild(fragment);
    }

    // ===== UPDATE THUMBNAILS ACTIVE STATE =====
    function updateThumbnails() {
      const thumbs = thumbnailsContainer.querySelectorAll('.image-popup-thumbnail');
      thumbs.forEach((thumb, index) => {
        thumb.classList.toggle('active', index === currentIndex);
      });

      // Scroll active thumbnail into view
      const activeThumb = thumbnailsContainer.querySelector('.image-popup-thumbnail.active');
      if (activeThumb) {
        activeThumb.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
      }
    }

    // ===== NAVIGATION =====
    function goToPrev() {
      currentIndex = (currentIndex - 1 + imageArray.length) % imageArray.length;
      resetImgTransform(false);
      updateImage();
    }

    function goToNext() {
      currentIndex = (currentIndex + 1) % imageArray.length;
      resetImgTransform(false);
      updateImage();
    }

    // ===== CLOSE POPUP =====
    function handleClose() {
      popup.classList.add('hidden');
      document.body.style.overflow = ''; // Restore scroll
      cleanup();
    }

    // ===== KEYBOARD NAVIGATION =====
    function handleKeydown(e) {
      if (popup.classList.contains('hidden')) return;

      switch (e.key) {
        case 'ArrowLeft':
          goToPrev();
          break;
        case 'ArrowRight':
          goToNext();
          break;
        case 'Escape':
          handleClose();
          break;
      }
    }

    // ===== NATIVE GESTURES (Mobile): vuốt ngang chuyển ảnh, kéo xuống
    // đóng (ảnh chạy theo ngón tay), double-tap zoom + pan khi đang zoom =====
    const gesture = {
      startX: 0, startY: 0, startTime: 0, mode: null,
      zoomed: false, panX: 0, panY: 0, baseX: 0, baseY: 0, lastTap: 0,
    };
    const ZOOM_SCALE = 2.5;

    function setImgTransform(x, y, scale, animate) {
      popupImage.style.transition = animate
        ? 'transform 0.25s cubic-bezier(0.2, 0.8, 0.2, 1)'
        : 'none';
      popupImage.style.transform = `translate(${x}px, ${y}px) scale(${scale})`;
    }
    function resetImgTransform(animate = true) {
      gesture.zoomed = false;
      gesture.panX = 0;
      gesture.panY = 0;
      setImgTransform(0, 0, 1, animate);
      popup.style.opacity = '';
    }

    function handleTouchStart(e) {
      if (e.touches.length !== 1) return;
      const t = e.touches[0];
      gesture.startX = t.clientX;
      gesture.startY = t.clientY;
      gesture.startTime = Date.now();
      gesture.mode = gesture.zoomed ? 'pan' : null;
      gesture.baseX = gesture.panX;
      gesture.baseY = gesture.panY;
      touchStartX = t.screenX; // giữ biến cũ cho tương thích
    }

    function handleTouchMove(e) {
      if (e.touches.length !== 1) return;
      const t = e.touches[0];
      const dx = t.clientX - gesture.startX;
      const dy = t.clientY - gesture.startY;

      if (gesture.mode === 'pan') {
        // Đang zoom: kéo để xem các góc ảnh
        gesture.panX = gesture.baseX + dx;
        gesture.panY = gesture.baseY + dy;
        setImgTransform(gesture.panX, gesture.panY, ZOOM_SCALE, false);
        e.preventDefault();
        return;
      }

      if (gesture.mode === null && (Math.abs(dx) > 10 || Math.abs(dy) > 10)) {
        gesture.mode = Math.abs(dy) > Math.abs(dx) ? 'dismiss' : 'swipe';
      }

      if (gesture.mode === 'dismiss' && dy > 0) {
        // Kéo xuống đóng: ảnh theo ngón tay, thu nhỏ nhẹ, nền mờ dần
        const progress = Math.min(dy / 300, 1);
        setImgTransform(dx * 0.4, dy, 1 - progress * 0.18, false);
        popup.style.opacity = String(1 - progress * 0.45);
        e.preventDefault();
      } else if (gesture.mode === 'swipe') {
        // Vuốt ngang: ảnh trượt nhẹ theo tay tạo cảm giác bám
        setImgTransform(dx * 0.35, 0, 1, false);
        e.preventDefault();
      }
    }

    function handleTouchEnd(e) {
      const t = e.changedTouches[0];
      const dx = t.clientX - gesture.startX;
      const dy = t.clientY - gesture.startY;
      const elapsed = Date.now() - gesture.startTime;
      const isTap = Math.abs(dx) < 10 && Math.abs(dy) < 10 && elapsed < 300;

      if (isTap) {
        // Double-tap: zoom vào đúng điểm chạm / thu về
        const now = Date.now();
        if (now - gesture.lastTap < 320) {
          if (gesture.zoomed) {
            resetImgTransform(true);
          } else {
            const rect = popupImage.getBoundingClientRect();
            const offsetX = (rect.left + rect.width / 2 - t.clientX) * (ZOOM_SCALE - 1);
            const offsetY = (rect.top + rect.height / 2 - t.clientY) * (ZOOM_SCALE - 1);
            gesture.zoomed = true;
            gesture.panX = offsetX;
            gesture.panY = offsetY;
            setImgTransform(offsetX, offsetY, ZOOM_SCALE, true);
          }
          gesture.lastTap = 0;
        } else {
          gesture.lastTap = now;
        }
        gesture.mode = null;
        return;
      }

      if (gesture.mode === 'pan') {
        gesture.mode = null;
        return;
      }

      if (gesture.mode === 'dismiss') {
        if (dy > 110) {
          // Đủ xa → đóng với animation trượt xuống
          popupImage.style.transition = 'transform 0.22s ease-in';
          popupImage.style.transform = `translate(${dx * 0.4}px, ${window.innerHeight}px) scale(0.8)`;
          popup.style.opacity = '0';
          setTimeout(() => {
            resetImgTransform(false);
            handleClose();
          }, 200);
        } else {
          resetImgTransform(true); // bật ngược về vị trí cũ
        }
        gesture.mode = null;
        return;
      }

      if (gesture.mode === 'swipe') {
        resetImgTransform(false);
        if (Math.abs(dx) > 50) {
          if (dx < 0) goToNext();
          else goToPrev();
        }
        gesture.mode = null;
      }
    }

    // ===== CLICK OUTSIDE TO CLOSE =====
    function handleOutsideClick(e) {
      if (e.target === popup) {
        handleClose();
      }
    }

    // ===== CLEANUP =====
    function cleanup() {
      document.removeEventListener('keydown', handleKeydown);
      popup.removeEventListener('click', handleOutsideClick);
      popupImage.removeEventListener('touchstart', handleTouchStart);
      popupImage.removeEventListener('touchmove', handleTouchMove);
      popupImage.removeEventListener('touchend', handleTouchEnd);
      popupImage.style.transform = '';
      popupImage.style.transition = '';
      popup.style.opacity = '';
      prevBtn.onclick = null;
      nextBtn.onclick = null;
      closeBtn.onclick = null;
    }

    // ===== INITIALIZE =====
    cleanup(); // Remove old listeners

    // 📱 Mobile: dời counter + nút đóng vào TRONG lòng ảnh cho gọn
    const viewerHeader = popup.querySelector('.image-popup-header');
    const counterWrap = popup.querySelector('.image-popup-counter');
    const imageWrapper = popupImage.closest('.image-popup-image-wrapper');
    const isMobileViewer = window.matchMedia('(max-width: 767px)').matches;
    if (isMobileViewer && imageWrapper && counterWrap) {
      imageWrapper.appendChild(counterWrap);
      imageWrapper.appendChild(closeBtn);
    } else if (!isMobileViewer && viewerHeader && counterWrap.parentElement !== viewerHeader) {
      viewerHeader.insertBefore(counterWrap, viewerHeader.firstChild);
      viewerHeader.appendChild(closeBtn);
    }

    renderThumbnails();
    updateImage();

    // Show popup
    popup.classList.remove('hidden');
    document.body.style.overflow = 'hidden'; // Prevent background scroll

    // Attach event listeners
    closeBtn.onclick = handleClose;
    prevBtn.onclick = goToPrev;
    nextBtn.onclick = goToNext;
    popup.addEventListener('click', handleOutsideClick);
    document.addEventListener('keydown', handleKeydown);
    popupImage.addEventListener('touchstart', handleTouchStart, { passive: true });
    popupImage.addEventListener('touchmove', handleTouchMove, { passive: false });
    popupImage.addEventListener('touchend', handleTouchEnd);
  }

  // Hàm lấy danh sách thợ từ localStorage và hiển thị trong select
  function populateStaffFilter() {
    const staffReportFilter = document.getElementById('staffReportFilter');
    const canViewAll = canViewAllInvoices();

    // Hiển thị select nếu có quyền view_all_invoices
    if (canViewAll) {
      staffReportFilter.classList.remove('hidden');
    } else {
      staffReportFilter.classList.add('hidden');
      return;
    }

    // Lấy danh sách thợ từ localStorage
    const staffListData = JSON.parse(localStorage.getItem('staffList')) || {};
    const staffList = staffListData.data || []; // Truy cập thuộc tính data

    // Xóa các tùy chọn hiện tại (trừ tùy chọn mặc định)
    staffReportFilter.innerHTML = '<option value="">Tất cả thợ</option>';

    // Thêm các thợ vào select
    staffList.forEach((staff) => {
      const option = document.createElement('option');
      option.value = staff.display_name; // Sử dụng display_name làm giá trị
      option.textContent = staff.display_name; // Hiển thị display_name
      staffReportFilter.appendChild(option);
    });
  }

  // Hàm xử lý sự kiện thay đổi giá trị trong select
  async function handleStaffFilterChange() {
    currentReportFilter = currentReportFilter || 'today'; // Đảm bảo có bộ lọc thời gian

    // ✅ Chỉ show loading nếu cần gọi API (lastMonth hoặc custom ngoài tháng)
    const needsAPICall =
      currentReportFilter === 'lastMonth' ||
      (currentReportFilter === 'custom' &&
        (() => {
          const now = new Date();
          const utc = now.getTime() + now.getTimezoneOffset() * 60000;
          const vietnamNow = new Date(utc + 7 * 3600000);
          const thisMonthStart = new Date(vietnamNow.getFullYear(), vietnamNow.getMonth(), 1);
          const todayVN = `${vietnamNow.getFullYear()}-${String(vietnamNow.getMonth() + 1).padStart(
            2,
            '0'
          )}-${String(vietnamNow.getDate()).padStart(2, '0')}`;
          const startDate = localStorage.getItem('customStartReportDate');
          const endDate = localStorage.getItem('customEndReportDate');
          const formatVN = (d) =>
            `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(
              d.getDate()
            ).padStart(2, '0')}`;
          const thisMonthStartStr = formatVN(thisMonthStart);
          return startDate < thisMonthStartStr || endDate > todayVN;
        })());

    if (needsAPICall && window.showPageLoader) {
      window.showPageLoader({ text: 'Đang tải báo cáo...', subtitle: 'Vui lòng đợi' });
    }

    try {
      await loadReportData();
    } catch (error) {
      console.error('Error loading report after staff change:', error);
    } finally {
      if (needsAPICall) {
        await new Promise((resolve) => setTimeout(resolve, 100));
        if (window.hidePageLoader) {
          window.hidePageLoader(100);
        }
      }
    }
  }

  // Hàm lấy dữ liệu báo cáo
  async function loadReportData() {
    // ✅ Sử dụng invoicesData từ localStorage (đã có sẵn thisMonth)
    // Chỉ gọi API khi cần load lastMonth hoặc custom ngoài tháng

    try {
      const canViewAll = canViewAllInvoices();
      let selectedStaff = canViewAll
        ? document.getElementById('staffReportFilter').value
        : checkinData.currentUser.display_name;
      selectedStaff = selectedStaff ? selectedStaff.normalize('NFC').trim() : '';

      // Hàm phụ để định dạng ngày theo múi giờ Việt Nam (UTC+7)
      function formatVietnamDate(date) {
        const vietnamOffset = 7 * 60; // Phút
        const utcDate = new Date(date.getTime() + date.getTimezoneOffset() * 60 * 1000);
        const vietnamDate = new Date(utcDate.getTime() + vietnamOffset * 60 * 1000);
        const year = vietnamDate.getFullYear();
        const month = String(vietnamDate.getMonth() + 1).padStart(2, '0');
        const day = String(vietnamDate.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`; // Trả về YYYY-MM-DD
      }

      // Hàm helper lấy ngày theo múi giờ VN
      const getInvoiceDateVN = (dateString) => {
        const d = new Date(dateString);
        const utc = d.getTime() + d.getTimezoneOffset() * 60000;
        const vnTime = new Date(utc + 7 * 3600000);
        return `${vnTime.getFullYear()}-${String(vnTime.getMonth() + 1).padStart(2, '0')}-${String(
          vnTime.getDate()
        ).padStart(2, '0')}`;
      };

      const now = new Date();
      const utc = now.getTime() + now.getTimezoneOffset() * 60000;
      const vietnamNow = new Date(utc + 7 * 3600000);
      const todayVN = `${vietnamNow.getFullYear()}-${String(vietnamNow.getMonth() + 1).padStart(
        2,
        '0'
      )}-${String(vietnamNow.getDate()).padStart(2, '0')}`;

      // Xác định startDate và endDate cho filter
      let startDate, endDate;
      let invoices = [];
      let needsAPICall = false;

      // Quản Lý xem tổng quan (không chọn Thợ cụ thể) cần gọi API để lấy tất cả data
      // vì invoicesData chỉ chứa data đã filter theo role
      const isOverviewMode = canViewAll && !selectedStaff;

      if (currentReportFilter === 'yesterday') {
        const yesterday = new Date(vietnamNow);
        yesterday.setDate(yesterday.getDate() - 1);
        startDate = formatVietnamDate(yesterday);
        endDate = startDate;
        // Nếu overview mode thì cần gọi API, ngược lại dùng invoicesData
        needsAPICall = isOverviewMode;
        console.log(
          `📊 Report filter: yesterday, date: ${startDate}, isOverviewMode: ${isOverviewMode}`
        );
      } else if (currentReportFilter === 'thisMonth') {
        startDate = formatVietnamDate(new Date(vietnamNow.getFullYear(), vietnamNow.getMonth(), 1));
        endDate = todayVN;
        // Kiểm tra xem startDate có nằm trong 7 ngày qua không
        const sevenDaysAgo = new Date(vietnamNow);
        sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
        const sevenDaysAgoStr = formatVietnamDate(sevenDaysAgo);
        // Nếu overview mode hoặc startDate trước 7 ngày qua thì cần gọi API
        if (isOverviewMode || startDate < sevenDaysAgoStr) {
          needsAPICall = true;
        }
      } else if (currentReportFilter === 'lastMonth') {
        needsAPICall = true;
        const lastMonth = new Date(vietnamNow.getFullYear(), vietnamNow.getMonth() - 1, 1);
        startDate = formatVietnamDate(lastMonth);
        const lastMonthEnd = new Date(vietnamNow.getFullYear(), vietnamNow.getMonth(), 0);
        endDate = formatVietnamDate(lastMonthEnd);
      } else if (currentReportFilter === 'custom') {
        startDate = localStorage.getItem('customStartReportDate');
        endDate = localStorage.getItem('customEndReportDate');
        // ✅ Custom filter luôn gọi API để đảm bảo có đúng dữ liệu
        // (invoicesData có thể chỉ chứa data của filter trước đó, không đủ)
        needsAPICall = true;
      } else {
        // today - nếu overview mode thì cần gọi API
        startDate = todayVN;
        endDate = startDate;
        needsAPICall = isOverviewMode;
      }

      // Lấy invoices từ invoicesData hoặc API
      if (needsAPICall) {
        // Gọi API cho overview mode hoặc các filter cần data ngoài 7 ngày
        let url = `staff-invoices`;
        // Chỉ thêm staff_name nếu có (overview mode không cần)
        if (selectedStaff) {
          url += `?staff_name=${encodeURIComponent(selectedStaff)}`;
        }
        const separator = selectedStaff ? '&' : '?';
        if (currentReportFilter === 'lastMonth') {
          url += `${separator}filter=lastMonth`;
        } else if (currentReportFilter === 'thisMonth') {
          url += `${separator}filter=thisMonth`;
        } else if (currentReportFilter === 'yesterday') {
          url += `${separator}filter=yesterday`;
        } else if (currentReportFilter === 'custom') {
          url += `${separator}filter=custom&start_date=${startDate}&end_date=${endDate}`;
        } else {
          // today
          url += `${separator}filter=today`;
        }
        invoices = await fetchAPI(url);
      } else {
        // Sử dụng invoicesData có sẵn và filter
        invoices = invoicesData.filter((inv) => {
          const invDateVN = getInvoiceDateVN(inv.created_at);
          return invDateVN >= startDate && invDateVN <= endDate;
        });
      }
      const serviceList = getServicesFromLocalStorage() || [];

      // Khởi tạo biến tổng hợp
      let totalRevenue = 0,
        cashRevenue = 0,
        totalCkRevenue = 0,
        bankRevenue = 0,
        momoRevenue = 0;
      let totalTips = 0,
        cashTips = 0,
        ckTips = 0,
        totalDiscount = 0,
        totalBooking = 0;
      let totalCustomers = 0,
        totalMembers = 0,
        totalNewCustomers = 0,
        totalNewMemberRegistrations = 0,
        zaloOA = 0,
        zns = 0;
      let totalChemicalBills = 0,
        serviceRevenue = 0,
        chemicalRevenue = 0,
        productRevenue = 0;
      let penaltyRevenue = 0,
        overtimeRevenue = 0,
        feedbackCount = 0,
        postFbCount = 0,
        productCount = 0,
        totalProductsSold = 0,
        cashInSafe = 0,
        totalExpenses = 0;

      // Tính toán từ invoices
      invoices.forEach((invoice) => {
        if (invoice.status === 'paid') {
          const services = Array.isArray(invoice.services) ? invoice.services : [];
          const hasStaff = selectedStaff
            ? services.some((service) => service.staff_name === selectedStaff)
            : true;

          if (!selectedStaff || hasStaff) {
            totalRevenue += parseFloat(invoice.total) || 0;
            totalDiscount += parseFloat(invoice.discount) || 0;
            totalTips += parseFloat(invoice.tips) || 0;
            totalCustomers += 1;

            if (invoice.new_customer === 'true') totalNewCustomers += 1;
            if (invoice.membership_label === 'Thành Viên') totalMembers += 1;

            if (invoice.payment_method === 'bank') {
              bankRevenue += parseFloat(invoice.total) || 0;
              ckTips += parseFloat(invoice.tips) || 0;
            } else if (invoice.payment_method === 'momo') {
              momoRevenue += parseFloat(invoice.total) || 0;
              ckTips += parseFloat(invoice.tips) || 0;
            } else if (invoice.payment_method === 'cash') {
              cashRevenue += parseFloat(invoice.total) || 0;
              cashTips += parseFloat(invoice.tips) || 0;
            } else if (invoice.payment_method === 'combined') {
              // Thanh toán kết hợp: parse combined_payment_details để tách tiền mặt/chuyển khoản
              let combinedDetails = invoice.combined_payment_details;
              if (typeof combinedDetails === 'string') {
                try {
                  combinedDetails = JSON.parse(combinedDetails);
                } catch (e) {
                  combinedDetails = {};
                }
              }
              const combinedCash = parseFloat(combinedDetails?.cash) || 0;
              const combinedBank = parseFloat(combinedDetails?.bank) || 0;
              cashRevenue += combinedCash;
              bankRevenue += combinedBank;
              // Tips trong thanh toán kết hợp thường được tính vào chuyển khoản
              ckTips += parseFloat(invoice.tips) || 0;
            }
            if (invoice.booking_id && invoice.booking_id !== '') totalBooking += 1;
            if (invoice.message_type === 'zalo_oa') zaloOA += 1;
            else if (invoice.message_type === 'zns') zns += 1;
            if (invoice.image_feedback) feedbackCount += 1;
            if (invoice.is_penalty === '1') penaltyRevenue += parseFloat(invoice.total) || 0;
            if (invoice.is_overtime === '1')
              overtimeRevenue += parseFloat(invoice.overtime_value) || 0;

            services.forEach((service) => {
              if (!selectedStaff || service.staff_name === selectedStaff) {
                if (service.service_type === 'service') {
                  serviceRevenue += parseFloat(service.total) || 0;
                } else if (service.service_type === 'chemical') {
                  chemicalRevenue += parseFloat(service.total) || 0;
                } else if (service.type === 'product') {
                  productRevenue += parseFloat(service.total) || 0;
                  const quantity = parseFloat(service.quantity) || 1;
                  productCount += quantity;
                  totalProductsSold += quantity;
                }
              }
            });

            const hasChemicalService = services.some((service) => {
              const matchingService = serviceList.find(
                (s) => s.service_name === service.service_name
              );
              return matchingService && matchingService.service_group === 'HÓA CHẤT';
            });
            if (hasChemicalService && (!selectedStaff || hasStaff)) totalChemicalBills += 1;
          }
        }
      });

      totalCkRevenue = bankRevenue + momoRevenue;

      // 🆕 Gọi API lấy tổng phiếu chi theo khoảng thời gian
      try {
        let expenseUrl = `cash-shifts/total-expenses?filter=${currentReportFilter}`;
        if (currentReportFilter === 'custom' && startDate && endDate) {
          expenseUrl += `&start_date=${startDate}&end_date=${endDate}`;
        }
        const expenseResponse = await fetchAPI(expenseUrl);
        if (expenseResponse && expenseResponse.success) {
          totalExpenses = expenseResponse.total_expenses || 0;
        }
      } catch (e) {
        console.warn('Failed to load total expenses:', e);
        totalExpenses = 0;
      }

      // Tính tiền két: Tiền mặt - Tổng chi (không trừ tips vì tổng chi đã bao gồm tips)
      cashInSafe = cashRevenue - totalExpenses;

      // 🆕 Đếm thành viên đăng ký mới từ cache nhẹ (chỉ chứa date_new_member)
      let newMemberDates = getNewMemberDatesCache();

      // Nếu cache rỗng, load từ API và cache lại
      if (!newMemberDates || newMemberDates.length === 0) {
        try {
          const customersResult = await fetchAPI('customers');
          let customers = [];
          if (customersResult && customersResult.data) {
            customers = customersResult.data;
          } else if (Array.isArray(customersResult)) {
            customers = customersResult;
          }

          // Chỉ lưu customer_id và date_new_member để bảo mật và giảm dung lượng
          newMemberDates = customers
            .filter((c) => c.date_new_member)
            .map((c) => ({
              id: c.customer_id,
              date: c.date_new_member,
            }));

          // Lưu vào cache
          saveNewMemberDatesCache(newMemberDates);
        } catch (e) {
          console.warn('Failed to load customers for report:', e);
          newMemberDates = [];
        }
      }

      const startDateTime = new Date(startDate + 'T00:00:00');
      const endDateTime = new Date(endDate + 'T23:59:59');

      // Đếm thành viên mới trong khoảng thời gian
      newMemberDates.forEach((member) => {
        if (member.date) {
          const dateNewMember = new Date(member.date);
          if (dateNewMember >= startDateTime && dateNewMember <= endDateTime) {
            totalNewMemberRegistrations += 1;
          }
        }
      });

      // ✅ Lấy dữ liệu KPI - CHỈ GỌI API KHI CẦN (thay đổi staff hoặc period)
      // ⚠️ CHỈ load KPI khi có selectedStaff (giao diện Thợ) - KHÔNG load cho giao diện tổng quan
      let feedbackKPI = 0,
        postFbKPI = 0,
        productKPI = 0,
        serviceKPI = 0,
        productKpiType = 'doanh_thu'; // Mặc định là doanh thu

      if (selectedStaff) {
        // ✅ CÓ selectedStaff → Load KPI cho staff cụ thể
        // Xác định period cho cache key (thisMonth, lastMonth, hoặc custom range)
        let cachePeriod = currentReportFilter;
        if (
          currentReportFilter === 'today' ||
          currentReportFilter === 'yesterday' ||
          currentReportFilter === 'thisMonth'
        ) {
          cachePeriod = 'thisMonth';
        }
        const kpiCacheKey = `${selectedStaff}_${cachePeriod}`;
        const staffChanged = lastLoadedStaff !== selectedStaff;

        // Kiểm tra cache trước khi gọi API
        if (!staffChanged && cachedKpiData[kpiCacheKey]) {
          // ✅ Sử dụng cache - KHÔNG gọi API
          const cached = cachedKpiData[kpiCacheKey];
          feedbackKPI = cached.feedbackKPI;
          postFbKPI = cached.postFbKPI;
          productKPI = cached.productKPI;
          serviceKPI = cached.serviceKPI;
          productKpiType = cached.productKpiType;
        } else {
          // ❌ Cache miss hoặc staff thay đổi - GỌI API
          try {
            let kpiUrl = `kpi-settings?staff_name=${encodeURIComponent(
              selectedStaff
            )}&start_date=${startDate}&end_date=${endDate}`;

            const kpiResponse = await fetchAPI(kpiUrl);

            let kpiData = Array.isArray(kpiResponse) ? kpiResponse : kpiResponse.data || [];

            if (kpiData.length > 0) {
              const selectedStaffNFC = selectedStaff.normalize('NFC').trim();
              for (const setting of kpiData) {
                const staffNames = Array.isArray(setting.staff_name)
                  ? setting.staff_name
                  : [setting.staff_name];
                const staffNamesNFC = staffNames.map((name) => name.normalize('NFC').trim());

                if (staffNamesNFC.includes(selectedStaffNFC)) {
                  // Lấy giá trị lớn nhất hoặc khác 0 cho mỗi KPI
                  feedbackKPI = Math.max(feedbackKPI, parseFloat(setting.feedback_kpi) || 0);
                  postFbKPI = Math.max(postFbKPI, parseFloat(setting.post_fb_kpi) || 0);
                  productKPI = Math.max(productKPI, parseFloat(setting.product_kpi_lv1) || 0);
                  serviceKPI = Math.max(serviceKPI, parseFloat(setting.service_kpi) || 0);
                  // Lấy loại KPI sản phẩm (ưu tiên setting có product_kpi > 0)
                  if (parseFloat(setting.product_kpi_lv1) > 0 && setting.product_kpi_type) {
                    productKpiType = setting.product_kpi_type;
                  }
                }
              }
            }

            // ✅ Lưu vào cache
            cachedKpiData[kpiCacheKey] = {
              feedbackKPI,
              postFbKPI,
              productKPI,
              serviceKPI,
              productKpiType,
            };
            lastLoadedStaff = selectedStaff;
          } catch (error) {
            console.error('Error loading KPI:', error);
          }
        }

        // ✅ Lấy số lượng bài đăng Facebook - CHỈ GỌI API KHI CẦN
        if (!staffChanged && cachedSocialPosts[kpiCacheKey] !== undefined) {
          // ✅ Sử dụng cache - KHÔNG gọi API
          postFbCount = cachedSocialPosts[kpiCacheKey];
        } else {
          // ❌ Cache miss - GỌI API
          try {
            let socialPostsUrl = `kpi-social-posts-count?staff_name=${encodeURIComponent(
              selectedStaff
            )}&start_date=${startDate}&end_date=${endDate}`;
            const socialResponse = await fetchAPI(socialPostsUrl);
            if (socialResponse.success) {
              postFbCount = parseInt(socialResponse.post_count) || 0;
              // ✅ Lưu vào cache
              cachedSocialPosts[kpiCacheKey] = postFbCount;
            }
          } catch (error) {
            console.error('Error loading social posts:', error);
          }
        }
      } else {
        // ❌ KHÔNG có selectedStaff (giao diện tổng quan) → KHÔNG load KPI
      }

      // Cập nhật giao diện
      elements.totalRevenue.textContent = formatCurrency(totalRevenue);
      elements.cashRevenue.textContent = formatCurrency(cashRevenue);
      if (elements.totalCkRevenue)
        elements.totalCkRevenue.textContent = formatCurrency(totalCkRevenue);
      elements.totalTips.textContent = formatCurrency(totalTips);
      elements.cashTips.textContent = formatCurrency(cashTips);
      elements.ckTips.textContent = formatCurrency(ckTips);
      elements.totalDiscount.textContent = formatCurrency(totalDiscount);
      elements.totalBooking.textContent = totalBooking;
      elements.totalChemicalBills.textContent = totalChemicalBills;
      elements.serviceRevenue.textContent = formatCurrency(serviceRevenue);
      elements.chemicalRevenue.textContent = formatCurrency(chemicalRevenue);
      elements.productRevenue.textContent = formatCurrency(productRevenue);
      elements.penaltyRevenue.textContent = formatCurrency(penaltyRevenue);
      elements.overtimeRevenue.textContent = formatCurrency(overtimeRevenue);

      // Cập nhật card tổng sản phẩm, tiền két và tổng chi
      const totalProductsSoldElement = document.getElementById('totalProductsSold');
      const cashInSafeElement = document.getElementById('cashInSafe');
      const totalExpensesElement = document.getElementById('totalExpenses');
      if (totalProductsSoldElement) totalProductsSoldElement.textContent = totalProductsSold;
      if (cashInSafeElement) cashInSafeElement.textContent = formatCurrency(cashInSafe);
      if (totalExpensesElement) totalExpensesElement.textContent = formatCurrency(totalExpenses);

      elements.feedbackKPI.textContent = `${feedbackCount} / ${feedbackKPI}`;
      elements.postFbKPI.textContent = `${postFbCount} / ${postFbKPI}`;

      // Tính % KPI
      const feedbackPercentage = feedbackKPI
        ? Math.min((feedbackCount / feedbackKPI) * 100, 100).toFixed(0)
        : 0;
      const postFbPercentage = postFbKPI
        ? Math.min((postFbCount / postFbKPI) * 100, 100).toFixed(0)
        : 0;
      let productPercentage = 0;

      // Hiển thị KPI sản phẩm dựa trên loại KPI
      if (productKpiType === 'san_pham') {
        // Hiển thị số lượng sản phẩm
        elements.productKPI.textContent = `${totalProductsSold} / ${productKPI}`;
        productPercentage = productKPI
          ? Math.min((totalProductsSold / productKPI) * 100, 100).toFixed(0)
          : 0;
        elements.productProgress.style.width = `${productPercentage}%`;
      } else {
        // Hiển thị doanh thu sản phẩm (mặc định)
        elements.productKPI.textContent = `${formatCurrency(productRevenue)} / ${formatCurrency(
          productKPI
        )}`;
        productPercentage = productKPI
          ? Math.min((productRevenue / productKPI) * 100, 100).toFixed(0)
          : 0;
        elements.productProgress.style.width = `${productPercentage}%`;
      }

      elements.feedbackProgress.style.width = `${feedbackPercentage}%`;
      elements.postFbProgress.style.width = `${postFbPercentage}%`;

      // Cập nhật % hiển thị trong footer
      const feedbackPercentageElement = document
        .querySelector('#feedbackProgress')
        .closest('.modern-kpi-card')
        .querySelector('.kpi-percentage');
      const postFbPercentageElement = document
        .querySelector('#postFbProgress')
        .closest('.modern-kpi-card')
        .querySelector('.kpi-percentage');
      const productPercentageElement = document
        .querySelector('#productProgress')
        .closest('.modern-kpi-card')
        .querySelector('.kpi-percentage');

      if (feedbackPercentageElement)
        feedbackPercentageElement.textContent = `${feedbackPercentage}%`;
      if (postFbPercentageElement) postFbPercentageElement.textContent = `${postFbPercentage}%`;
      if (productPercentageElement) productPercentageElement.textContent = `${productPercentage}%`; // Ẩn/hiện giao diện theo vai trò và lựa chọn thợ
      const customersChartContainer = document.querySelector('#customersChartContainer');
      const messagesChartContainer = document.querySelector('#messagesChartContainer');
      const revenueChartContainer = document.querySelector('#revenueChartContainer');
      const kpiSection = document.querySelector('#kpiSection');
      const totalRevenueCard = document.querySelector('#totalRevenueCard');
      const tipsCard = document.querySelector('#tipsCard');
      const discountCard = document.querySelector('#discountCard');
      const bookingCard = document.querySelector('#bookingCard');
      const chemicalBillsCard = document.querySelector('#chemicalBillsCard');
      const serviceRevenueCard = document.querySelector('#serviceRevenueCard');
      const chemicalRevenueCard = document.querySelector('#chemicalRevenueCard');
      const productRevenueCard = document.querySelector('#productRevenueCard');
      const penaltyRevenueCard = document.querySelector('#penaltyRevenueCard');
      const overtimeRevenueCard = document.querySelector('#overtimeRevenueCard');
      const totalProductsSoldCard = document.querySelector('#totalProductsSoldCard');
      const cashInSafeCard = document.querySelector('#cashInSafeCard');
      const totalExpensesCard = document.querySelector('#totalExpensesCard');
      const staffReportFilterLabel = document.querySelector(
        '.filter-item:has(#staffReportFilter) .filter-label'
      );

      // Ẩn label "Nhân viên" cho user không có quyền view_all_invoices
      if (!canViewAll && staffReportFilterLabel) {
        staffReportFilterLabel.style.display = 'none';
      }

      // ✅ Logic hiển thị giao diện dựa trên VAI TRÒ và selectedStaff:
      // - Quản lý/Thu ngân/Admin KHÔNG chọn staff → Giao diện TỔNG QUAN (charts, tổng doanh thu)
      // - Thợ HOẶC có chọn staff cụ thể → Giao diện KPI CÁ NHÂN

      // Check nếu là Manager/Admin role (các role có quyền xem tổng quan)
      const managerRoles = ['Quản Lý', 'Thu Ngân', 'administrator', 'admin', 'Quản lý'];
      const isManagerRole = managerRoles.includes(currentUserRole) || canViewAll;
      const showOverviewInterface = isManagerRole && !selectedStaff;

      if (showOverviewInterface) {
        // 📊 GIAO DIỆN THU NGÂN/QUẢN LÝ - Hiển thị tổng quan
        serviceRevenueCard.style.display = 'none';
        chemicalRevenueCard.style.display = 'none';
        productRevenueCard.style.display = 'none';
        penaltyRevenueCard.style.display = 'none';
        overtimeRevenueCard.style.display = 'none';
        kpiSection.style.display = 'none';
        revenueChartContainer.style.display = 'flex';
        totalRevenueCard.style.display = 'flex';
        tipsCard.style.display = 'flex';
        discountCard.style.display = 'flex';
        bookingCard.style.display = 'flex';
        chemicalBillsCard.style.display = 'flex';
        if (totalProductsSoldCard) totalProductsSoldCard.style.display = 'flex';
        if (cashInSafeCard) cashInSafeCard.style.display = 'flex';
        if (totalExpensesCard) totalExpensesCard.style.display = 'flex';
        customersChartContainer.style.display = 'flex';
        messagesChartContainer.style.display = 'flex';
      } else {
        // 👤 GIAO DIỆN THỢ - Hiển thị KPI cá nhân
        serviceRevenueCard.style.display = 'flex';
        chemicalRevenueCard.style.display = 'flex';
        productRevenueCard.style.display = 'flex';
        penaltyRevenueCard.style.display = 'flex';
        overtimeRevenueCard.style.display = 'flex';
        bookingCard.style.display = 'flex';
        kpiSection.style.display = 'block';
        revenueChartContainer.style.display = 'flex';
        chemicalBillsCard.style.display = 'none';
        totalRevenueCard.style.display = 'none';
        tipsCard.style.display = 'none';
        discountCard.style.display = 'none';
        if (totalProductsSoldCard) totalProductsSoldCard.style.display = 'none';
        if (cashInSafeCard) cashInSafeCard.style.display = 'none';
        if (totalExpensesCard) totalExpensesCard.style.display = 'none';
        customersChartContainer.style.display = 'none';
        messagesChartContainer.style.display = 'none';
      }
      if (revenueChartInstance) {
        revenueChartInstance.destroy();
        revenueChartInstance = null;
      }
      if (monthlyRevenueChartInstance) {
        monthlyRevenueChartInstance.destroy();
        monthlyRevenueChartInstance = null;
      }
      if (detailedRevenueChartInstance) {
        detailedRevenueChartInstance.destroy();
        detailedRevenueChartInstance = null;
      }
      if (customersChartInstance) {
        customersChartInstance.destroy();
        customersChartInstance = null;
      }
      if (messagesChartInstance) {
        messagesChartInstance.destroy();
        messagesChartInstance = null;
      }

      // Cập nhật biểu đồ khách (nếu hiển thị)
      if (customersChartContainer && customersChartContainer.style.display !== 'none') {
        customersChartInstance = new Chart(document.querySelector('#customersChart'), {
          type: 'pie',
          data: {
            labels: ['Tổng khách', 'Khách thành viên', 'Khách mới', 'Thành viên đăng ký mới'],
            datasets: [
              {
                data: [
                  totalCustomers,
                  totalMembers,
                  totalNewCustomers,
                  totalNewMemberRegistrations,
                ],
                backgroundColor: ['#0071E3', '#34C759', '#FF3B30', '#5856D6'],
                borderWidth: 2,
                borderColor: 'rgba(255, 255, 255, 0.5)',
                hoverOffset: 8,
              },
            ],
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              legend: {
                display: false,
              },
              tooltip: {
                callbacks: {
                  label: function (context) {
                    const label = context.label || '';
                    const value = context.parsed || 0;
                    const total = context.dataset.data.reduce((a, b) => a + b, 0);
                    const percentage = total > 0 ? ((value / total) * 100).toFixed(1) : 0;
                    return `${label}: ${value} (${percentage}%)`;
                  },
                },
              },
            },
          },
        });

        // 🆕 Cập nhật legend dưới chart
        const legendContainer = document.getElementById('customersChartLegend');
        if (legendContainer) {
          legendContainer.innerHTML = `
          <div class="legend-item">
            <span class="legend-color" style="background: #0071E3;"></span>
            <span class="legend-label">Tổng khách:</span>
            <span class="legend-value">${totalCustomers}</span>
          </div>
          <div class="legend-item">
            <span class="legend-color" style="background: #34C759;"></span>
            <span class="legend-label">Thành viên:</span>
            <span class="legend-value">${totalMembers}</span>
          </div>
          <div class="legend-item">
            <span class="legend-color" style="background: #FF3B30;"></span>
            <span class="legend-label">Khách mới:</span>
            <span class="legend-value">${totalNewCustomers}</span>
          </div>
          <div class="legend-item">
            <span class="legend-color" style="background: #5856D6;"></span>
            <span class="legend-label">TV ĐK mới:</span>
            <span class="legend-value">${totalNewMemberRegistrations}</span>
          </div>
        `;
        }
      }

      // Cập nhật biểu đồ Zalo OA và ZNS (nếu hiển thị)
      if (messagesChartContainer && messagesChartContainer.style.display !== 'none') {
        messagesChartInstance = new Chart(document.querySelector('#messagesChart'), {
          type: 'bar',
          data: {
            labels: ['Zalo OA', 'ZNS'],
            datasets: [
              {
                label: 'Số lượng tin nhắn',
                data: [zaloOA, zns],
                backgroundColor: ['#FF9500', '#FF3B30'],
                borderRadius: 4,
              },
            ],
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
              y: {
                beginAtZero: true,
                ticks: { stepSize: 1 },
              },
            },
            plugins: {
              legend: { display: false },
              title: { display: true, text: 'Zalo OA và ZNS' },
            },
          },
        });
      }

      // ✅ Cập nhật biểu đồ doanh số (2 loại chart khác nhau)
      if (revenueChartContainer && revenueChartContainer.style.display !== 'none') {
        // Tạo 2 canvas riêng nếu chưa có
        if (!document.querySelector('#monthlyRevenueChart')) {
          revenueChartContainer.innerHTML = `
            <canvas id="monthlyRevenueChart" style="max-height: 300px;"></canvas>
            <canvas id="detailedRevenueChart" style="max-height: 300px;"></canvas>
          `;
        }

        // Xác định loại chart cần hiển thị
        const managerRoles = ['Quản Lý', 'Thu Ngân', 'administrator', 'admin', 'Quản lý'];
        const isManagerRole = managerRoles.includes(currentUserRole);
        const isMonthFilter =
          currentReportFilter === 'thisMonth' || currentReportFilter === 'lastMonth';
        // Chỉ hiển thị chart 12 tháng khi là Manager VÀ filter theo tháng (để tránh load invoice cả năm)
        const showMonthlyTrendChart = showOverviewInterface && isMonthFilter;

        // Ẩn/hiện các canvas dựa trên điều kiện
        const monthlyCanvas = document.querySelector('#monthlyRevenueChart');
        const detailedCanvas = document.querySelector('#detailedRevenueChart');

        // ✅ Chart chi tiết luôn hiển thị
        if (detailedCanvas) detailedCanvas.style.display = 'block';

        // Điều chỉnh height của chart container tùy thuộc vào việc có hiển thị yearly chart hay không
        if (showMonthlyTrendChart) {
          revenueChartContainer.style.maxHeight = '620px'; // Có 2 chart
        } else {
          revenueChartContainer.style.maxHeight = '320px'; // Chỉ có 1 chart chi tiết
        }

        if (showMonthlyTrendChart) {
          // Hiển thị chart 12 tháng khi là Manager và filter theo tháng
          if (monthlyCanvas) monthlyCanvas.style.display = 'block';

          // 📈 CHART 1: Doanh số từ tháng 1 đến tháng hiện tại của năm hiện tại
          // Load dữ liệu riêng cho chart này, chỉ khi cần hiển thị
          const now = new Date();
          const utc = now.getTime() + now.getTimezoneOffset() * 60000;
          const vietnamNow = new Date(utc + 7 * 3600000);
          const currentYear = vietnamNow.getFullYear();
          const currentMonth = vietnamNow.getMonth(); // 0-indexed

          // Khởi tạo các tháng từ T1 đến tháng hiện tại của năm hiện tại với giá trị 0
          const monthlyData = {};
          for (let i = 0; i <= currentMonth; i++) {
            const monthKey = `${currentYear}-${String(i + 1).padStart(2, '0')}`;
            monthlyData[monthKey] = 0;
          }

          // Load dữ liệu cả năm từ API (không phụ thuộc filter hiện tại)
          try {
            let yearApiUrl = `${checkinData.restUrl}staff-invoices?filter=thisYear`;

            // Add branch_id if available
            if (branchHelper && typeof branchHelper.getCurrentBranchId === 'function') {
              const branchId = branchHelper.getCurrentBranchId();
              if (branchId) {
                yearApiUrl += `&branch_id=${branchId}`;
              }
            }

            const yearResponse = await fetch(yearApiUrl, {
              headers: {
                'X-WP-Nonce': checkinData.nonce,
                'Content-Type': 'application/json',
              },
            });

            const yearResult = await yearResponse.json();
            let yearInvoices = [];
            if (Array.isArray(yearResult)) {
              yearInvoices = yearResult;
            } else if (yearResult && yearResult.success && Array.isArray(yearResult.data)) {
              yearInvoices = yearResult.data;
            } else if (yearResult && Array.isArray(yearResult.data)) {
              yearInvoices = yearResult.data;
            }

            // Tính tổng doanh thu theo tháng
            yearInvoices.forEach((invoice) => {
              if (invoice.status === 'paid') {
                const invDate = new Date(invoice.created_at);
                const invUtc = invDate.getTime() + invDate.getTimezoneOffset() * 60000;
                const invVN = new Date(invUtc + 7 * 3600000);
                const monthKey = `${invVN.getFullYear()}-${String(invVN.getMonth() + 1).padStart(
                  2,
                  '0'
                )}`;

                if (monthlyData.hasOwnProperty(monthKey)) {
                  monthlyData[monthKey] += parseFloat(invoice.total) || 0;
                }
              }
            });
          } catch (e) {
            console.warn('Failed to load yearly data for chart:', e);
            // Fallback: dùng invoicesData hiện có nếu API thất bại
            invoicesData.forEach((invoice) => {
              if (invoice.status === 'paid') {
                const invDate = new Date(invoice.created_at);
                const invUtc = invDate.getTime() + invDate.getTimezoneOffset() * 60000;
                const invVN = new Date(invUtc + 7 * 3600000);
                const monthKey = `${invVN.getFullYear()}-${String(invVN.getMonth() + 1).padStart(
                  2,
                  '0'
                )}`;

                if (monthlyData.hasOwnProperty(monthKey)) {
                  monthlyData[monthKey] += parseFloat(invoice.total) || 0;
                }
              }
            });
          }

          // Chuẩn bị labels và data cho chart
          const chartLabels = [];
          const chartData = [];
          Object.keys(monthlyData)
            .sort()
            .forEach((key) => {
              const [year, month] = key.split('-');
              chartLabels.push(`T${parseInt(month)}/${year}`);
              chartData.push(monthlyData[key]);
            });

          monthlyRevenueChartInstance = new Chart(document.querySelector('#monthlyRevenueChart'), {
            type: 'bar',
            data: {
              labels: chartLabels,
              datasets: [
                {
                  label: 'Doanh thu',
                  data: chartData,
                  backgroundColor: '#0071E3',
                  borderRadius: 4,
                },
              ],
            },
            options: {
              responsive: true,
              maintainAspectRatio: false,
              scales: {
                y: {
                  beginAtZero: true,
                  ticks: {
                    callback: function (value) {
                      return formatCurrency(value);
                    },
                  },
                },
              },
              plugins: {
                legend: { display: false },
                title: { display: true, text: `Doanh số năm ${currentYear}` },
                tooltip: {
                  callbacks: {
                    label: function (context) {
                      return 'Doanh thu: ' + formatCurrency(context.parsed.y);
                    },
                  },
                },
              },
            },
          });
        } else {
          // Ẩn chart 12 tháng khi không phải Manager hoặc filter không phải theo tháng
          if (monthlyCanvas) monthlyCanvas.style.display = 'none';
        }

        // 📊 CHART 2: Doanh số chi tiết theo bộ lọc hiện tại (Dịch vụ, Hóa chất, Sản phẩm) - LUÔN HIỂN THỊ
        const filterLabels = {
          today: 'hôm nay',
          yesterday: 'hôm qua',
          thisMonth: 'tháng này',
          lastMonth: 'tháng trước',
          custom: 'thời gian tùy chỉnh',
        };
        const filterLabel = filterLabels[currentReportFilter] || 'thời gian đã chọn';

        detailedRevenueChartInstance = new Chart(document.querySelector('#detailedRevenueChart'), {
          type: 'bar',
          data: {
            labels: ['Dịch vụ', 'Hóa chất', 'Sản phẩm'],
            datasets: [
              {
                label: 'Doanh số',
                data: [serviceRevenue, chemicalRevenue, productRevenue],
                backgroundColor: ['#0071E3', '#34C759', '#FF3B30'],
                borderRadius: 4,
              },
            ],
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
              y: {
                beginAtZero: true,
                ticks: {
                  callback: function (value) {
                    return formatCurrency(value);
                  },
                },
              },
            },
            plugins: {
              legend: { display: false },
              title: { display: true, text: `Doanh số chi tiết ${filterLabel}` },
              tooltip: {
                callbacks: {
                  label: function (context) {
                    return context.label + ': ' + formatCurrency(context.parsed.y);
                  },
                },
              },
            },
          },
        });
      }

      // Thêm functionality cho chart action buttons
      document.querySelectorAll('.chart-action-btn').forEach((btn) => {
        btn.addEventListener('click', function (e) {
          e.preventDefault();
          const chartCard = this.closest('.modern-chart-card');
          if (chartCard) {
            chartCard.classList.toggle('expanded');
            const icon = this.querySelector('i');
            if (icon) {
              if (chartCard.classList.contains('expanded')) {
                icon.classList.remove('fa-expand');
                icon.classList.add('fa-compress');
                this.title = 'Thu gọn';
              } else {
                icon.classList.remove('fa-compress');
                icon.classList.add('fa-expand');
                this.title = 'Xem chi tiết';
              }
            }
          }
        });
      });
    } catch (error) {
      console.error('Error loading report data:', error);
    }
    // ✅ KHÔNG hide loader - caller sẽ quản lý
  }

  // Hàm khởi tạo pill-select cho lý do truy thu và staff selection
  function initPillSelect(containerId, options, onChange = null, isRequired = false) {
    const container = document.getElementById(containerId);
    if (!container) return;

    const valueWrapper = container.querySelector('.mkt192-pill-select-value-wrapper');
    const optionsContainer = container.querySelector('.mkt192-pill-select-options');
    const placeholder = container.querySelector('.mkt192-pill-select-placeholder');

    if (!valueWrapper || !optionsContainer) return;

    // Tạo hidden input nếu chưa có
    let hiddenInput = container.querySelector('input[type="hidden"]');
    if (!hiddenInput) {
      hiddenInput = document.createElement('input');
      hiddenInput.type = 'hidden';
      hiddenInput.name = containerId;
      container.appendChild(hiddenInput);
    }

    // Reset container
    valueWrapper.innerHTML = '';
    optionsContainer.innerHTML = '';

    // Thêm placeholder nếu chưa có pills
    if (placeholder) {
      valueWrapper.appendChild(placeholder);
    } else {
      const placeholderEl = document.createElement('span');
      placeholderEl.className = 'mkt192-pill-select-placeholder';
      placeholderEl.textContent = 'Chọn...';
      valueWrapper.appendChild(placeholderEl);
    }

    // Tạo options
    options.forEach((option) => {
      const optionEl = document.createElement('div');
      optionEl.className = 'mkt192-pill-select-option';
      optionEl.dataset.value = option.value || option.id;
      optionEl.textContent = option.label || option.name;
      optionsContainer.appendChild(optionEl);
    });

    // Khởi tạo selected values
    let currentSelected = [];
    let isOpen = false;

    function updatePills() {
      valueWrapper.innerHTML = '';

      if (currentSelected.length > 0) {
        currentSelected.forEach((value) => {
          const option = options.find((opt) => (opt.value || opt.id) === value);
          if (option) {
            const pill = document.createElement('div');
            pill.className = 'mkt192-pill';
            pill.innerHTML = `
              <span class="mkt192-pill-text">${option.label || option.name}</span>
              <button type="button" class="mkt192-pill-remove" data-value="${value}">
                <i class="fas fa-times"></i>
              </button>
            `;
            valueWrapper.appendChild(pill);
          }
        });
      } else {
        // Thêm placeholder
        const placeholderEl = document.createElement('span');
        placeholderEl.className = 'mkt192-pill-select-placeholder';
        placeholderEl.textContent = 'Chọn...';
        valueWrapper.appendChild(placeholderEl);
      }

      // Cập nhật hidden input
      hiddenInput.value = currentSelected.join(',');

      // Cập nhật trạng thái options
      optionsContainer.querySelectorAll('.mkt192-pill-select-option').forEach((optionEl) => {
        const value = optionEl.dataset.value;
        if (currentSelected.includes(value)) {
          optionEl.classList.add('selected');
        } else {
          optionEl.classList.remove('selected');
        }
      });

      // Gọi callback nếu có
      if (onChange) {
        const selectedItems = currentSelected
          .map((value) => options.find((opt) => (opt.value || opt.id) === value))
          .filter(Boolean);
        onChange(selectedItems);
      }
    }

    function toggleOptions() {
      isOpen = !isOpen;
      if (isOpen) {
        optionsContainer.classList.remove('hidden');
      } else {
        optionsContainer.classList.add('hidden');
      }
    }

    function closeOptions() {
      isOpen = false;
      optionsContainer.classList.add('hidden');
    }

    // Event listener cho container để toggle options
    container.addEventListener('click', (e) => {
      if (!e.target.closest('.mkt192-pill-remove')) {
        toggleOptions();
      }
    });

    // Event listeners cho options
    optionsContainer.addEventListener('click', (e) => {
      const optionEl = e.target.closest('.mkt192-pill-select-option');
      if (!optionEl) return;

      e.stopPropagation();
      const value = optionEl.dataset.value;
      const index = currentSelected.indexOf(value);

      if (index > -1) {
        // Bỏ chọn
        currentSelected.splice(index, 1);
      } else {
        // Chọn
        currentSelected.push(value);
      }

      updatePills();
    });

    // Event listeners cho remove buttons
    valueWrapper.addEventListener('click', (e) => {
      const removeBtn = e.target.closest('.mkt192-pill-remove');
      if (!removeBtn) return;

      e.stopPropagation();
      const value = removeBtn.dataset.value;
      const index = currentSelected.indexOf(value);
      if (index > -1) {
        currentSelected.splice(index, 1);
        updatePills();
      }
    });

    // Đóng options khi click bên ngoài
    document.addEventListener('click', (e) => {
      if (!container.contains(e.target)) {
        closeOptions();
      }
    });

    // Khởi tạo ban đầu
    updatePills();

    // Trả về object để có thể kiểm tra validation
    return {
      getSelectedValues: () => currentSelected,
      isValid: () => !isRequired || currentSelected.length > 0,
      clear: () => {
        currentSelected = [];
        updatePills();
      },
      setSelectedValues: (values) => {
        currentSelected = [...values];
        updatePills();
      },
    };
  }

  // ✅ OPTIMIZED: Render danh sách staff ngay lập tức từ localStorage
  // Lọc theo chi nhánh và role (Thu Ngân chỉ hiển thị cho sản phẩm)
  function renderStaffList(item) {
    const staffListEl = document.getElementById('staffList');
    const searchInput = document.getElementById('staff-search-input');

    if (!staffListEl) {
      return;
    }

    // Clear existing staff list
    staffListEl.innerHTML = '';

    // ✅ Lấy staff từ localStorage ngay lập tức (đã được load sẵn khi khởi động app)
    let staffList = getStaffFromLocalStorage();

    // Kiểm tra xem dữ liệu có mới (có user_branch) hay không
    // Nếu dữ liệu cũ thì fetch lại từ API
    const needsRefresh =
      staffList && staffList.length > 0 && !staffList.some((s) => s.hasOwnProperty('user_branch'));

    if (!staffList || staffList.length === 0 || needsRefresh) {
      // Nếu localStorage trống hoặc dữ liệu cũ, hiển thị loading và fetch API background
      staffListEl.innerHTML = '<div class="no-staff">Đang tải danh sách thợ...</div>';
      fetchAPI('staff')
        .then((fetchedStaff) => {
          saveStaffToLocalStorage(fetchedStaff);
          // Re-render sau khi fetch xong
          renderStaffList(item);
        })
        .catch(() => {
          staffListEl.innerHTML = '<div class="no-staff">Lỗi tải danh sách thợ</div>';
        });
      return;
    }

    // Lấy branch_id hiện tại từ branchHelper
    const currentBranchId = branchHelper?.getCurrentBranchId();

    // Lọc staff theo các điều kiện:
    // 1. Đang còn làm việc (bỏ nghỉ ca/xoá/lưu trữ/nghỉ việc)
    // 2. Thuộc chi nhánh hiện tại (nếu có chọn chi nhánh)
    // 3. Theo loại item: service → không hiển thị Thu Ngân, product → hiển thị tất cả
    const activeStaff = staffList.filter((s) => {
      // Điều kiện 1: chỉ nhận thợ còn làm việc
      if (!isWorkingStaff(s)) return false;

      // Điều kiện 2: Lọc theo chi nhánh (nếu có chọn chi nhánh)
      if (currentBranchId) {
        // Kiểm tra staff có thuộc chi nhánh hiện tại không
        // user_branch là mảng branch_ids, branch_id là primary branch
        // Cần parse JSON nếu user_branch hoặc branch là string
        let staffBranches = s.user_branch || [];

        // Nếu user_branch chưa có (dữ liệu cũ), thử parse từ cột branch
        if ((!staffBranches || staffBranches.length === 0) && s.branch) {
          try {
            const parsed = typeof s.branch === 'string' ? JSON.parse(s.branch) : s.branch;
            if (Array.isArray(parsed)) {
              staffBranches = parsed.map((id) => parseInt(id));
            }
          } catch (e) {
            // branch không phải JSON, có thể là số đơn lẻ
            if (!isNaN(parseInt(s.branch))) {
              staffBranches = [parseInt(s.branch)];
            }
          }
        }

        const staffPrimaryBranch = s.branch_id ? parseInt(s.branch_id) : null;

        // Staff thuộc chi nhánh nếu: branch_id khớp HOẶC currentBranchId nằm trong user_branch
        const belongsToBranch =
          staffPrimaryBranch === parseInt(currentBranchId) ||
          (Array.isArray(staffBranches) &&
            staffBranches.map((id) => parseInt(id)).includes(parseInt(currentBranchId)));

        if (!belongsToBranch) return false;
      }

      // Điều kiện 3: Lọc theo loại item (service vs product)
      const role = (s.user_role || '').toLowerCase();
      const isCashier = role === 'thu ngân' || role === 'thungan' || role === 'cashier';

      if (item && item.type === 'product') {
        // Sản phẩm: Hiển thị CẢ thợ VÀ Thu Ngân (tất cả nhân viên)
        return true;
      } else {
        // Dịch vụ: KHÔNG hiển thị Thu Ngân (chỉ thợ làm dịch vụ)
        return !isCashier;
      }
    });

    console.log('🔍 renderStaffList - filtered activeStaff count:', activeStaff.length);

    // Store staff data globally
    window.currentStaffList = activeStaff;

    // Render all staff
    renderStaffItems(activeStaff);

    // Add search functionality
    if (searchInput) {
      // Clear previous value
      searchInput.value = '';

      // Remove old listeners (if any)
      const newSearchInput = searchInput.cloneNode(true);
      searchInput.parentNode.replaceChild(newSearchInput, searchInput);

      // Add new listener
      newSearchInput.addEventListener('input', (e) => {
        const searchTerm = e.target.value.toLowerCase().trim();
        const filteredStaff = activeStaff.filter((staff) =>
          staff.display_name.toLowerCase().includes(searchTerm)
        );
        renderStaffItems(filteredStaff);
      });
    }
  }

  function renderStaffItems(staffArray) {
    const staffListEl = document.getElementById('staffList');
    if (!staffListEl) return;

    staffListEl.innerHTML = '';

    if (staffArray.length === 0) {
      staffListEl.innerHTML = '<div class="no-staff">Không tìm thấy thợ nào</div>';
      return;
    }

    staffArray.forEach((staff) => {
      const staffItem = document.createElement('div');
      staffItem.className = 'staff-item';
      staffItem.dataset.staffId = staff.employee_id;
      staffItem.dataset.staffName = staff.display_name;

      // Check if this staff is already selected
      const selectedPills = document.querySelectorAll('#staff-selected-pills .staff-selected-pill');
      const isSelected = Array.from(selectedPills).some(
        (pill) => pill.dataset.staffId === staff.employee_id
      );

      if (isSelected) {
        staffItem.classList.add('selected');
      }

      staffItem.innerHTML = `
        <div class="staff-item-avatar">
          <img src="${staff.avatar || 'https://randomuser.me/api/portraits/lego/1.jpg'}"
               alt="${staff.display_name}">
        </div>
        <div class="staff-item-info">
          <div class="staff-item-name">${staff.display_name}</div>
          <div class="staff-item-role">${staff.user_role || 'Thợ'}</div>
        </div>
        <div class="staff-item-check">✓</div>
      `;

      staffItem.addEventListener('click', () => {
        toggleStaffSelection(staff);
      });

      staffListEl.appendChild(staffItem);
    });
  }

  function toggleStaffSelection(staff) {
    const selectedPillsContainer = document.getElementById('staff-selected-pills');
    const existingPill = selectedPillsContainer.querySelector(
      `[data-staff-id="${staff.employee_id}"]`
    );
    if (existingPill) {
      // Remove selection
      existingPill.remove();
      updateStaffItemSelection(staff.employee_id, false);
    } else {
      // Remove all existing pills first (single selection)
      const allPills = selectedPillsContainer.querySelectorAll('.staff-selected-pill');
      allPills.forEach((pill) => {
        const staffId = pill.dataset.staffId;
        updateStaffItemSelection(staffId, false);
        pill.remove();
      });

      // Add new selection
      const pill = document.createElement('div');
      pill.className = 'staff-selected-pill';
      pill.dataset.staffId = staff.employee_id;
      pill.innerHTML = `
        <span>${staff.display_name}</span>
        <button type="button" class="staff-selected-pill-remove" data-staff-id="${staff.employee_id}">&times;</button>
      `;

      // Add remove event listener
      pill.querySelector('.staff-selected-pill-remove').addEventListener('click', (e) => {
        e.stopPropagation();
        toggleStaffSelection(staff);
      });

      selectedPillsContainer.appendChild(pill);
      updateStaffItemSelection(staff.employee_id, true);
    }
  }

  function updateStaffItemSelection(staffId, isSelected) {
    const staffItems = document.querySelectorAll('.staff-item');
    staffItems.forEach((item) => {
      if (item.dataset.staffId === staffId) {
        if (isSelected) {
          item.classList.add('selected');
        } else {
          item.classList.remove('selected');
        }
      }
    });
  }

  // Hàm lấy staff đã chọn từ pill-select
  function getSelectedStaffFromList() {
    const selectedPills = document.querySelectorAll('#staff-selected-pills .staff-selected-pill');
    if (selectedPills.length === 0) {
      return null;
    }

    const firstPill = selectedPills[0];
    const staffId = firstPill.dataset.staffId;
    const staffName = firstPill.textContent.replace('×', '').trim();
    return {
      id: staffId,
      name: staffName,
    };
  }

  // Hàm lấy danh sách lý do truy thu
  function getTruyThuReasons() {
    return [
      { value: 'san_pham_khong_dat', label: 'Sản phẩm không đạt' },
      { value: 'san_pham_chuyen_tho_khac', label: 'Sản phẩm chuyển Thợ khác sửa' },
      { value: 'khach_danh_gia_te_tai_shop', label: 'Khách đánh giá tệ tại Shop' },
      { value: 'khach_danh_gia_te_tren_hoa_don', label: 'Khách đánh giá tệ trên Hóa đơn' },
    ];
  }

  // Hàm cập nhật hiển thị phiên bản
  function updateAppVersion() {
    const appVersion = document.getElementById('appVersion');
    if (appVersion && checkinData && checkinData.version) {
      const sidebar = document.querySelector('.sidebar');
      const isCollapsed = sidebar && sidebar.classList.contains('sidebar-collapsed');
      const versionText = isCollapsed ? checkinData.version : `Phiên bản ${checkinData.version}`;
      appVersion.textContent = versionText;
    } else {
      if (appVersion) {
        appVersion.textContent = 'Phiên bản không xác định';
      }
    }
  }

  // ==============================
  // GENERIC PILL-SELECT COMPONENT
  // ==============================

  /**
   * Khởi tạo Pill-Select Component (tái sử dụng cho nhiều modal)
   * @param {string} containerId - ID của container element
   * @param {Array} options - Mảng các lựa chọn [{value, label}, ...]
   * @param {Object} config - Cấu hình component
   * @param {boolean} config.multiSelect - Cho phép chọn nhiều (default: false)
   * @param {string} config.color - Màu theme: 'blue'|'red'|'green' (default: 'blue')
   * @param {string} config.placeholder - Placeholder text
   * @param {Function} config.onSelect - Callback khi chọn option
   * @param {Function} config.onRemove - Callback khi xóa pill
   * @returns {Object} API để tương tác với component
   */
  function initPillSelect(containerId, options = [], config = {}) {
    const {
      multiSelect = false,
      color = 'blue',
      placeholder = 'Chọn...',
      onSelect = null,
      onRemove = null,
    } = config;

    const container = document.getElementById(containerId);
    if (!container) {
      return null;
    }

    const valueWrapper = container.querySelector('.mkt192-pill-select-value-wrapper');
    const optionsContainer = container.querySelector('.mkt192-pill-select-options');
    const placeholderEl = container.querySelector('.mkt192-pill-select-placeholder');

    if (!valueWrapper || !optionsContainer || !placeholderEl) {
      return null;
    }

    // State management
    let selectedValues = [];

    // Clear và reset
    function reset() {
      selectedValues = [];
      const existingPills = valueWrapper.querySelectorAll('.mkt192-pill');
      existingPills.forEach((pill) => pill.remove());
      placeholderEl.style.display = 'inline';
      optionsContainer.classList.remove('hidden');
      optionsContainer.style.display = 'none';
      optionsContainer.style.visibility = 'hidden';

      // Reset selected state
      optionsContainer.querySelectorAll('.mkt192-pill-option').forEach((opt) => {
        opt.classList.remove('selected');
      });
    }

    // Populate options
    function populateOptions() {
      optionsContainer.innerHTML = '';
      options.forEach((option, index) => {
        const optionEl = document.createElement('div');
        optionEl.className = 'mkt192-pill-option';
        optionEl.textContent = option.label;
        optionEl.dataset.value = option.value;
        optionEl.dataset.index = index;
        optionsContainer.appendChild(optionEl);
      });
    }

    // Create pill
    function createPill(value, label) {
      const pill = document.createElement('div');
      pill.className = 'mkt192-pill';

      // Override color nếu cần
      if (color === 'red') {
        pill.style.background = 'linear-gradient(135deg, #ff3b30 0%, #dc2626 100%)';
        pill.style.boxShadow = '0 2px 4px rgba(239, 68, 68, 0.2)';
      } else if (color === 'green') {
        pill.style.background = 'linear-gradient(135deg, #34c759 0%, #059669 100%)';
        pill.style.boxShadow = '0 2px 4px rgba(16, 185, 129, 0.2)';
      }

      pill.innerHTML = `
        <span>${label}</span>
        <button type="button" class="mkt192-pill-remove" data-value="${value}">&times;</button>
      `;

      return pill;
    }

    // Add pill
    function addPill(value, label) {
      // Nếu single-select, xóa pill cũ
      if (!multiSelect) {
        const existingPills = valueWrapper.querySelectorAll('.mkt192-pill');
        existingPills.forEach((pill) => pill.remove());
        selectedValues = [];
      }

      // Kiểm tra đã chọn chưa
      if (selectedValues.includes(value)) return;

      const pill = createPill(value, label);
      valueWrapper.insertBefore(pill, placeholderEl);
      selectedValues.push(value);
      placeholderEl.style.display = 'none';

      // Handle remove
      pill.querySelector('.mkt192-pill-remove').addEventListener('click', (e) => {
        e.stopPropagation();
        removePill(value);
      });
    }

    // Remove pill
    function removePill(value) {
      const pills = valueWrapper.querySelectorAll('.mkt192-pill');
      pills.forEach((pill) => {
        const removeBtn = pill.querySelector('.mkt192-pill-remove');
        if (removeBtn && removeBtn.dataset.value === value) {
          pill.remove();
          selectedValues = selectedValues.filter((v) => v !== value);

          // Update option state
          const option = optionsContainer.querySelector(
            `.mkt192-pill-option[data-value="${value}"]`
          );
          if (option) option.classList.remove('selected');

          // Callback
          if (onRemove) onRemove(value);
        }
      });

      // Show placeholder nếu không còn pill
      if (selectedValues.length === 0) {
        placeholderEl.style.display = 'inline';
      }
    }

    // Toggle dropdown
    valueWrapper.addEventListener('click', (e) => {
      e.stopPropagation();

      if (optionsContainer.style.display === 'none' || optionsContainer.style.display === '') {
        optionsContainer.style.display = 'block';
        optionsContainer.style.visibility = 'visible';
      } else {
        optionsContainer.style.display = 'none';
        optionsContainer.style.visibility = 'hidden';
      }
    });

    // Handle option click
    optionsContainer.addEventListener('click', (e) => {
      if (e.target.classList.contains('mkt192-pill-option')) {
        const value = e.target.dataset.value;
        const label = e.target.textContent;

        addPill(value, label);
        e.target.classList.add('selected');

        // Hide dropdown nếu single-select
        if (!multiSelect) {
          optionsContainer.style.display = 'none';
          optionsContainer.style.visibility = 'hidden';
        }

        // Callback
        if (onSelect) onSelect(value, label);
      }
    });

    // Close dropdown khi click outside
    document.addEventListener('click', (e) => {
      if (!container.contains(e.target)) {
        optionsContainer.style.display = 'none';
        optionsContainer.style.visibility = 'hidden';
      }
    });

    // Initialize
    reset();
    populateOptions();

    // Return API
    return {
      reset,
      getSelectedValues: () => [...selectedValues],
      setSelectedValues: (values) => {
        reset();
        values.forEach((val) => {
          const option = options.find((opt) => opt.value === val);
          if (option) {
            addPill(option.value, option.label);
            const optionEl = optionsContainer.querySelector(
              `.mkt192-pill-option[data-value="${val}"]`
            );
            if (optionEl) optionEl.classList.add('selected');
          }
        });
      },
      updateOptions: (newOptions) => {
        options = newOptions;
        populateOptions();
      },
    };
  }

  // ==============================
  // Cancel Booking Modal Functions
  // ==============================
  let currentCancelBookingId = null;
  let cancelReasonPillSelect = null;

  function getCancelReasons() {
    return [
      { value: 'test', label: 'Test' },
      { value: 'khach_khong_den', label: 'Khách không đến' },
      { value: 'khach_yeu_cau_huy', label: 'Khách yêu cầu hủy' },
      { value: 'tho_off_dot_xuat', label: 'Thợ off đột xuất' },
    ];
  }

  async function openCancelBookingModal(bookingId) {
    currentCancelBookingId = bookingId;
    const modal = document.getElementById('mkt192-cancel-booking-modal');

    if (!modal) {
      return;
    }

    // Tìm booking từ bookingsData trước (nguồn dữ liệu chính xác)
    let bookingFromList = null;
    if (bookingsData && bookingsData.length > 0) {
      bookingFromList = bookingsData.find((b) => b.id_booking === bookingId || b.id === bookingId);
    }

    // Load thông tin booking từ API
    try {
      const response = await fetchAPI(`bookings/${bookingId}`);
      // Handle different response structures
      const bookingData = response?.data || response;

      if (bookingData) {
        // Cập nhật thông tin booking vào modal
        document.getElementById('cancel-booking-id').textContent =
          bookingData.id_booking || bookingData.id || '-';
        document.getElementById('cancel-customer-name').textContent =
          bookingData.customer_name || '-';
        document.getElementById('cancel-customer-phone').textContent =
          bookingData.customer_phone || bookingData.phone || '-';

        // Lấy thông tin datetime - ưu tiên từ bookingsData (danh sách), sau đó từ API
        const datetimeElement = document.getElementById('cancel-booking-datetime');
        if (datetimeElement) {
          let dateStr = '';
          let timeStr = '';

          if (bookingFromList) {
            // Lấy từ bookingsData (chính xác nhất)
            if (bookingFromList.booking_date) {
              dateStr = new Date(bookingFromList.booking_date).toLocaleDateString('vi-VN');
              timeStr = bookingFromList.booking_time || '';
            }
          } else if (bookingData.booking_date) {
            // Fallback: Lấy từ API response
            dateStr = new Date(bookingData.booking_date).toLocaleDateString('vi-VN');
            timeStr = bookingData.booking_time || '';
          }

          datetimeElement.textContent = dateStr ? `${dateStr} ${timeStr}`.trim() : '-';
        }

        // Xử lý services (là array)
        if (bookingData.services && bookingData.services.length > 0) {
          const serviceNames = bookingData.services.map((s) => s.service_name).join(', ');
          const hairdresserNames = bookingData.services.map((s) => s.hairdresser_name).join(', ');

          document.getElementById('cancel-service-name').textContent = serviceNames || '-';
          document.getElementById('cancel-hairdresser-name').textContent = hairdresserNames || '-';
        } else {
          document.getElementById('cancel-service-name').textContent = '-';
          document.getElementById('cancel-hairdresser-name').textContent = '-';
        }
      } else {
        toastError('Không tìm thấy thông tin lịch hẹn');
        return;
      }
    } catch (error) {
      toastError('Không thể tải thông tin lịch hẹn');
      return;
    }

    // Initialize hoặc reset pill-select component
    if (!cancelReasonPillSelect) {
      cancelReasonPillSelect = initPillSelect('cancel-reason-pill-select', getCancelReasons(), {
        multiSelect: false,
        color: 'red',
        placeholder: 'Chọn lý do hủy lịch...',
        onSelect: (value, label) => {},
      });
    } else {
      cancelReasonPillSelect.reset();
    }

    modal.classList.add('show');
  }

  function closeCancelBookingModal() {
    const modal = document.getElementById('mkt192-cancel-booking-modal');
    if (modal) {
      modal.classList.remove('show');
      currentCancelBookingId = null;
    }
  }

  async function handleCancelBooking() {
    if (!cancelReasonPillSelect) {
      return;
    }

    const selectedValues = cancelReasonPillSelect.getSelectedValues();

    if (selectedValues.length === 0) {
      showCheckinToast({ message: 'Vui lòng chọn lý do hủy lịch!', type: 'warning' });
      return;
    }

    const selectedReasonValue = selectedValues[0];
    const submitBtn = document.getElementById('mkt192-save-cancel-booking');

    if (!submitBtn) {
      return;
    }

    setButtonLoading(submitBtn, 'Đang xử lý...');

    try {
      const response = await fetchAPI(`bookings/${currentCancelBookingId}`, {
        method: 'DELETE',
        body: JSON.stringify({
          cancel_reason: selectedReasonValue,
        }),
      });

      if (response.success) {
        showCheckinToast({ message: 'Đã hủy lịch hẹn thành công!', type: 'success' });
        closeCancelBookingModal();
        renderBookingList();
      } else {
        throw new Error(response.message || 'Lỗi khi hủy lịch hẹn');
      }
    } catch (err) {
      showCheckinToast({ message: err.message || 'Lỗi không xác định', type: 'error' });
    } finally {
      resetButtonLoading(submitBtn);
    }
  }

  function initCancelBookingModal() {
    const modal = document.getElementById('mkt192-cancel-booking-modal');
    if (!modal) {
      return;
    }

    const closeBtn = document.getElementById('mkt192-close-cancel-booking-modal');
    const cancelBtn = document.getElementById('mkt192-cancel-cancel-booking');
    const saveBtn = document.getElementById('mkt192-save-cancel-booking');

    if (closeBtn) closeBtn.onclick = () => closeCancelBookingModal();
    if (cancelBtn) cancelBtn.onclick = () => closeCancelBookingModal();
    if (saveBtn) saveBtn.onclick = () => handleCancelBooking();

    modal.addEventListener('click', (e) => {
      if (e.target === modal) closeCancelBookingModal();
    });
  }

  // ============================================
  // BRANCH SYSTEM FUNCTIONS - CHI NHÁNH
  // ============================================

  /**
   * Render branch selector component in app header
   */
  function renderAppBranchSelector() {
    if (!branchHelper || !branchHelper.branches || branchHelper.branches.length === 0) {
      console.warn('No branches available for selector in app-tho');
      return;
    }

    // Check if selector already exists
    if (document.getElementById('app-branch-selector')) {
      return;
    }

    // 🔧 FIX: Chỉ vai trò Quản Lý/Thu Ngân/Admin mới có option "Tất cả chi nhánh"
    const managerRolesForBranch = ['Quản Lý', 'administrator', 'admin', 'Quản lý'];
    const canViewAllBranches = managerRolesForBranch.includes(currentUserRole) || isAdmin;
    const allBranchesOption = canViewAllBranches
      ? '<option value="">-- Tất cả chi nhánh --</option>'
      : '';

    const selector = document.createElement('div');
    selector.id = 'app-branch-selector';
    selector.className = 'app-branch-selector';
    selector.innerHTML = `
      <div class="branch-selector-wrapper">
        <label for="app-branch-select" class="branch-label" title="Chi nhánh" aria-label="Chi nhánh">📍</label>
        <select id="app-branch-select" class="branch-select">
          ${allBranchesOption}
          ${branchHelper.branches
            .map(
              (b) => `
            <option value="${b.branch_name || b.location_name}">
              ${b.branch_name || b.location_name}
            </option>
          `
            )
            .join('')}
        </select>
        <button class="btn-auto-detect" id="btn-auto-detect-app" title="Tìm tự động">🔍<span class="btn-auto-detect-text"> Tìm tự động</span></button>
      </div>
    `;

    // Insert vào header-container cùng cấp với .header-wrap & user-menu-container
    let inserted = false;
    const headerContainer = document.querySelector('.header-left');

    if (headerContainer) {
      headerContainer.appendChild(selector);
      inserted = true;
    }

    if (!inserted) {
      return;
    }

    // Add event listeners
    const select = document.getElementById('app-branch-select');
    const btnAutoDetect = document.getElementById('btn-auto-detect-app');

    if (select) {
      select.addEventListener('change', (e) => handleAppBranchChange(e.target.value));
    }

    if (btnAutoDetect) {
      btnAutoDetect.addEventListener('click', handleAppBranchAutoDetect);
    }

    // Set current branch in selector
    if (currentBranch && select) {
      select.value = currentBranch;
    }
  }

  /**
   * Handle branch change in app
   */
  async function handleAppBranchChange(branchName) {
    if (!branchHelper) return;

    currentBranchFilter = branchName || '';
    currentBranch = branchName || '';

    // Show page loader
    if (window.showPageLoader) {
      window.showPageLoader({
        text: 'Đang tải dữ liệu chi nhánh...',
        subtitle: branchName ? `Chi nhánh: ${branchName}` : 'Tất cả chi nhánh',
      });
    }

    // Clear cached data for all sections - both memory and localStorage
    invoices = [];
    invoicesData = [];
    servicesData = [];
    bookingsData = [];
    visibleInvoices = [];
    currentInvoiceIndex = -1;

    // Clear localStorage cache for services and invoices
    // Clear both old static keys and new branch-specific keys
    StorageManager.clear('servicesList');
    StorageManager.clear('productsList');
    StorageManager.clear('productGroupsList');
    // Also clear any branch-specific cache keys (servicesList_*, productsList_*, etc)
    StorageManager.clearKeys(['servicesList_', 'productsList_', 'productGroupsList_']);

    // Immediately render empty state
    renderCurrentInvoice();
    renderInvoiceList(); // This updates visibleInvoices

    // Always reload all sections regardless of current section
    if (branchName) {
      branchHelper.setCurrentBranch(branchName).then(async () => {
        // Reload all sections and wait for them to complete
        try {
          // ✅ OPTIMIZED: Load 7days thay vì thisMonth để giảm tải localStorage
          // Khi user chọn thisMonth/lastMonth filter sẽ load riêng
          await loadStaffInvoices('7days');

          // 2. Set active invoice index sau khi load invoices xong
          if (invoices && invoices.length > 0) {
            let newestIndex = 0;
            try {
              let maxTime = -Infinity;
              invoices.forEach((inv, idx) => {
                const t = new Date(inv.created_at || 0).getTime();
                if (!isNaN(t) && t > maxTime) {
                  maxTime = t;
                  newestIndex = idx;
                }
              });
            } catch (e) {
              newestIndex = invoices.length - 1;
            }
            currentInvoiceIndex = newestIndex;
          }

          // 3. Load booking và update tab (đến đây currentInvoiceIndex đã được set)
          await loadStaffBookings(currentBookingFilter);
          // Update tab state will load appropriate content (services or products)
          updateTabState();

          // Re-render with new data - dùng filter hiện tại
          // renderInvoiceList sẽ tự filter từ invoicesData (đã có dữ liệu tháng)
          if (currentSection === 'services') {
            await renderInvoiceList('today');
          } else if (currentSection === 'invoices') {
            if (currentFilter === 'custom') {
              const startDate = localStorage.getItem('customStartDate');
              const endDate = localStorage.getItem('customEndDate');
              if (startDate && endDate) {
                await renderInvoiceList('custom', startDate, endDate);
              } else {
                await renderInvoiceList('today');
              }
            } else {
              await renderInvoiceList(currentFilter);
            }
          } else {
            await renderInvoiceList();
          }

          renderInvoiceTabs(); // Now renderInvoiceTabs can use updated visibleInvoices
          await renderCurrentInvoice();

          // 4. 🆕 Reload báo cáo (reports) nếu đang ở trang báo cáo
          if (currentSection === 'reports') {
            try {
              // invoicesData đã được load với 'thisMonth' ở trên
              await loadReportData();
            } catch (e) {
              console.error('Error reloading reports after branch change:', e);
            }
          }

          // 5. 🆕 Reload danh sách kiểm kê (inventory) nếu đang ở trang settings > inventory
          if (currentSection === 'settings' && currentSettingsSubsection === 'inventory') {
            try {
              await loadInventoryList();
            } catch (e) {}
          }

          // 6. 🆕 Reload CTKM/Voucher nếu đang ở trang settings > promo
          if (currentSection === 'settings' && currentSettingsSubsection === 'promo') {
            try {
              // Reload CTKM list
              ctkmList = await fetchAPI('settings/ctkm');
              ctkmList = ctkmList.filter(
                (ctkm) => !ctkm.applicable_services || ctkm.applicable_services.length === 0
              );

              // Reload Voucher list
              vouchers = await fetchAPI('settings/ctkm');
              vouchers = vouchers.filter(
                (voucher) => voucher.applicable_services && voucher.applicable_services.length > 0
              );

              // Save to localStorage
              saveCTKMToLocalStorage();
              saveVouchersToLocalStorage();

              // Re-render lists based on active tab
              const activePromoTab = document.querySelector('.promo-tab-item.active');
              if (activePromoTab) {
                const activeTab = activePromoTab.dataset.tab;
                if (activeTab === 'ctkm') {
                  loadCTKMList();
                } else if (activeTab === 'voucher') {
                  loadVoucherList();
                }
              }

              console.log('✅ Đã reload CTKM/Voucher theo chi nhánh:', branchName);
            } catch (e) {
              console.error('❌ Lỗi reload CTKM/Voucher:', e);
            }
          }

          // 7. 🆕 Reload Dashboard nếu đang ở trang dashboard
          if (currentSection === 'dashboard') {
            try {
              await renderDashboard();
              console.log('✅ Đã reload Dashboard theo chi nhánh:', branchName);
            } catch (e) {
              console.error('❌ Lỗi reload Dashboard:', e);
            }
          }

          // 8. 🆕 Reload Shift Management (Quản lý ca) nếu đang ở trang shifts
          if (currentSection === 'shifts') {
            try {
              if (window.AppThoShiftManagement) {
                // Clear cached shift data trước khi refresh
                if (typeof window.AppThoShiftManagement.clearCache === 'function') {
                  window.AppThoShiftManagement.clearCache();
                }
                if (typeof window.AppThoShiftManagement.refresh === 'function') {
                  await window.AppThoShiftManagement.refresh();
                }
                console.log('✅ Đã reload Shift Management theo chi nhánh:', branchName);
              }
            } catch (e) {
              console.error('❌ Lỗi reload Shift Management:', e);
            }
          }

          // ✅ Hide loader SAU KHI tất cả data đã được load và render xong
          if (window.hidePageLoader) {
            window.hidePageLoader(300);
          }
        } catch (e) {
          console.error('Error reloading sections:', e);
        }
      });
    } else {
      currentBranchFilter = '';

      // Reload all sections without branch filter
      try {
        // ✅ OPTIMIZED: Load 7days thay vì thisMonth để giảm tải localStorage
        await loadStaffInvoices('7days');

        // 2. Set active invoice index sau khi load invoices xong
        if (invoices && invoices.length > 0) {
          let newestIndex = 0;
          try {
            let maxTime = -Infinity;
            invoices.forEach((inv, idx) => {
              const t = new Date(inv.created_at || 0).getTime();
              if (!isNaN(t) && t > maxTime) {
                maxTime = t;
                newestIndex = idx;
              }
            });
          } catch (e) {
            newestIndex = invoices.length - 1;
          }
          currentInvoiceIndex = newestIndex;
        }

        // 3. Load bookings and update tab (currentInvoiceIndex is now valid)
        await loadStaffBookings(currentBookingFilter);
        // Update tab state will load appropriate content (services or products)
        updateTabState();

        // Re-render with new data - dùng filter hiện tại
        if (currentSection === 'services') {
          await renderInvoiceList('today');
        } else if (currentSection === 'invoices') {
          if (currentFilter === 'custom') {
            const startDate = localStorage.getItem('customStartDate');
            const endDate = localStorage.getItem('customEndDate');
            if (startDate && endDate) {
              await renderInvoiceList('custom', startDate, endDate);
            } else {
              await renderInvoiceList('today');
            }
          } else {
            await renderInvoiceList(currentFilter);
          }
        } else {
          await renderInvoiceList();
        }

        renderInvoiceTabs();
        await renderCurrentInvoice();

        // 4. 🆕 Reload báo cáo (reports) nếu đang ở trang báo cáo
        if (currentSection === 'reports') {
          try {
            // invoicesData đã được load với 'thisMonth' ở trên
            await loadReportData();
          } catch (e) {
            console.error('Error reloading reports after branch change:', e);
          }
        }

        // 5. 🆕 Reload danh sách kiểm kê (inventory) nếu đang ở trang settings > inventory
        if (currentSection === 'settings' && currentSettingsSubsection === 'inventory') {
          try {
            await loadInventoryList();
          } catch (e) {}
        }

        // 6. 🆕 Reload CTKM/Voucher nếu đang ở trang settings > promo
        if (currentSection === 'settings' && currentSettingsSubsection === 'promo') {
          try {
            // Reload CTKM list
            ctkmList = await fetchAPI('settings/ctkm');
            ctkmList = ctkmList.filter(
              (ctkm) => !ctkm.applicable_services || ctkm.applicable_services.length === 0
            );

            // Reload Voucher list
            vouchers = await fetchAPI('settings/ctkm');
            vouchers = vouchers.filter(
              (voucher) => voucher.applicable_services && voucher.applicable_services.length > 0
            );

            // Save to localStorage
            saveCTKMToLocalStorage();
            saveVouchersToLocalStorage();

            // Re-render lists based on active tab
            const activePromoTab = document.querySelector('.promo-tab-item.active');
            if (activePromoTab) {
              const activeTab = activePromoTab.dataset.tab;
              if (activeTab === 'ctkm') {
                loadCTKMList();
              } else if (activeTab === 'voucher') {
                loadVoucherList();
              }
            }
          } catch (e) {}
        }

        // 7. 🆕 Reload Dashboard nếu đang ở trang dashboard
        if (currentSection === 'dashboard') {
          try {
            await renderDashboard();
            console.log('✅ Đã reload Dashboard theo chi nhánh: Tất cả');
          } catch (e) {
            console.error('❌ Lỗi reload Dashboard:', e);
          }
        }

        // 8. 🆕 Reload Shift Management (Quản lý ca) nếu đang ở trang shifts
        if (currentSection === 'shifts') {
          try {
            if (window.AppThoShiftManagement) {
              // Clear cached shift data trước khi refresh
              if (typeof window.AppThoShiftManagement.clearCache === 'function') {
                window.AppThoShiftManagement.clearCache();
              }
              if (typeof window.AppThoShiftManagement.refresh === 'function') {
                await window.AppThoShiftManagement.refresh();
              }
              console.log('✅ Đã reload Shift Management theo chi nhánh: Tất cả');
            }
          } catch (e) {
            console.error('❌ Lỗi reload Shift Management:', e);
          }
        }

        // ✅ Hide loader SAU KHI tất cả data đã được load và render xong
        if (window.hidePageLoader) {
          window.hidePageLoader(300);
        }
      } catch (e) {}
    }
  }

  /**
   * Handle auto-detect branch for app
   */
  async function handleAppBranchAutoDetect() {
    if (!branchHelper) {
      return;
    }

    try {
      const detected = await branchHelper.detectBranch();
      if (detected) {
        const select = document.getElementById('app-branch-select');
        if (select) {
          select.value = detected.branch_name;
          handleAppBranchChange(detected.branch_name);
        }
      }
    } catch (error) {}
  }

  // ==============================
  // 18. Inventory Transaction Management
  // ==============================
  let currentTransactionFilter = ''; // '', 'CHỜ DUYỆT', 'HOÀN THÀNH'
  let transactions = [];
  let currentTransactionPage = parseInt(localStorage.getItem('currentTransactionPage')) || 1;
  let transactionItemsPerPage = parseInt(localStorage.getItem('transactionItemsPerPage')) || 20;
  let transactionPaginationData = null;

  // ==============================
  // 18.1 Transaction Cache System
  // ==============================
  const TRANSACTION_CACHE_KEY = 'mkt192_transaction_cache';
  const TRANSACTION_CACHE_EXPIRY = 30 * 60 * 1000; // 30 phút

  /**
   * Lấy cache transactions từ localStorage
   */
  function getTransactionCache() {
    try {
      const cached = localStorage.getItem(TRANSACTION_CACHE_KEY);
      if (!cached) return null;

      const { data, timestamp, branchId } = JSON.parse(cached);
      const currentBranchId = localStorage.getItem('checkinBranchId') || '';

      // Check expiry và branch
      if (Date.now() - timestamp > TRANSACTION_CACHE_EXPIRY || branchId !== currentBranchId) {
        localStorage.removeItem(TRANSACTION_CACHE_KEY);
        return null;
      }

      return data;
    } catch (e) {
      console.error('❌ Lỗi đọc cache:', e);
      return null;
    }
  }

  /**
   * Lưu cache transactions vào localStorage
   */
  function setTransactionCache(data) {
    try {
      const currentBranchId = localStorage.getItem('checkinBranchId') || '';
      localStorage.setItem(
        TRANSACTION_CACHE_KEY,
        JSON.stringify({
          data,
          timestamp: Date.now(),
          branchId: currentBranchId,
        })
      );
    } catch (e) {
      console.error('❌ Lỗi lưu cache:', e);
    }
  }

  /**
   * Xóa cache transactions
   */
  function clearTransactionCache() {
    localStorage.removeItem(TRANSACTION_CACHE_KEY);
  }

  /**
   * Cập nhật 1 transaction trong cache
   */
  function updateTransactionInCache(transactionId, updates) {
    const cache = getTransactionCache();
    if (!cache) return;

    const index = cache.findIndex((t) => t.transaction_id === transactionId);
    if (index !== -1) {
      cache[index] = { ...cache[index], ...updates };
      setTransactionCache(cache);
    }
  }

  /**
   * Xóa 1 transaction khỏi cache
   */
  function removeTransactionFromCache(transactionId) {
    const cache = getTransactionCache();
    if (!cache) return;

    const newCache = cache.filter((t) => t.transaction_id !== transactionId);
    setTransactionCache(newCache);
  }

  /**
   * Lấy transaction từ cache theo ID
   */
  function getTransactionFromCache(transactionId) {
    const cache = getTransactionCache();
    if (!cache) return null;
    return cache.find((t) => t.transaction_id === transactionId) || null;
  }

  /**
   * Lọc transactions theo status từ cache
   */
  function filterTransactionsFromCache(status = '') {
    const cache = getTransactionCache();
    if (!cache) return null;

    if (!status) return cache;
    return cache.filter((t) => t.status === status);
  }

  /**
   * Load danh sách phiếu xuất/nhập kho (có cache)
   */
  async function loadInventoryTransactions(status = '', forceRefresh = false) {
    const transactionList = document.getElementById('transactionList');
    if (!transactionList) return;

    // Thử lấy từ cache trước (nếu không force refresh)
    if (!forceRefresh) {
      const cachedData = filterTransactionsFromCache(status);
      if (cachedData && cachedData.length > 0) {
        console.log('📦 Using cached transactions:', cachedData.length, 'items');
        transactions = cachedData;
        renderTransactionList(transactions);
        return;
      }
    }

    transactionList.innerHTML = '<tr><td colspan="8" class="loading">Đang tải...</td></tr>';

    try {
      // ✅ Lọc theo branch_id đang được chọn ở thanh selector
      const branchId = branchHelper?.getCurrentBranchId() || 0;
      const params = new URLSearchParams({
        page: 1,
        per_page: 500, // Lấy nhiều để cache
      });
      if (branchId > 0) {
        params.append('branch_id', branchId);
      }

      console.log('🔍 Loading ALL transactions for cache...');
      const url = `inventory-transactions?${params.toString()}`;

      const response = await fetchAPI(url);

      if (!response) {
        console.error('❌ Response is null/undefined');
        throw new Error('API không trả về dữ liệu');
      }

      // Handle response with pagination
      let allTransactions = [];
      if (response.data && response.pagination) {
        allTransactions = response.data;
        transactionPaginationData = response.pagination;
      } else {
        allTransactions = Array.isArray(response) ? response : response.data || [];
        transactionPaginationData = null;
      }

      console.log('✅ All transactions loaded:', allTransactions.length, 'items');

      // Lưu vào cache
      setTransactionCache(allTransactions);

      // Lọc theo status hiện tại
      transactions = status ? allTransactions.filter((t) => t.status === status) : allTransactions;

      renderTransactionList(transactions);
    } catch (error) {
      console.error('❌ Lỗi khi tải phiếu xuất/nhập:', error);
      transactionList.innerHTML = `<tr><td colspan="9" class="error">Lỗi: ${error.message}</td></tr>`;
    }
  }

  /**
   * Render danh sách transactions ra UI
   */
  function renderTransactionList(transactionsToRender) {
    const transactionList = document.getElementById('transactionList');
    if (!transactionList) return;

    transactionList.innerHTML = '';

    if (transactionsToRender.length === 0) {
      transactionList.innerHTML =
        '<tr><td colspan="8" class="empty">Chưa có phiếu xuất/nhập kho nào</td></tr>';
      updateTransactionPaginationInfo();
      return;
    }

    // Pagination: tính toán trang hiện tại
    const totalItems = transactionsToRender.length;
    const totalPages = Math.ceil(totalItems / transactionItemsPerPage);
    const startIndex = (currentTransactionPage - 1) * transactionItemsPerPage;
    const endIndex = Math.min(startIndex + transactionItemsPerPage, totalItems);
    const paginatedData = transactionsToRender.slice(startIndex, endIndex);

    // Render từng phiếu
    paginatedData.forEach((txn) => {
      const row = document.createElement('tr');
      row.dataset.transactionId = txn.transaction_id;

      const transactionDate = new Date(txn.transaction_date).toLocaleString('vi-VN', {
        dateStyle: 'short',
        timeStyle: 'short',
      });

      const typeClass =
        txn.transaction_type === 'IN' ? 'transaction-type-in' : 'transaction-type-out';
      const typeText = txn.transaction_type === 'IN' ? 'Nhập' : 'Xuất';

      const statusClass =
        txn.status === 'CHỜ DUYỆT' ? 'transaction-status-pending' : 'transaction-status-completed';
      const statusText = txn.status;

      // Hiển thị danh sách sản phẩm (tối đa 2, sau đó +X)
      const productNamesStr = txn.products || '';
      const productNames = productNamesStr
        .split(', ')
        .filter((p) => p.trim())
        .map((p) => p.trim());
      let productDisplay = productNames.slice(0, 2).join(', ');
      if (productNames.length > 2) {
        productDisplay += ` +${productNames.length - 2}`;
      }
      if (!productDisplay) {
        productDisplay = '-';
      }

      row.innerHTML = `
        <td data-label="Mã phiếu" class="font-semibold text-blue-600">${txn.transaction_id}</td>
        <td data-label="Loại"><span class="transaction-type-badge ${typeClass}">${typeText}</span></td>
        <td data-label="Ngày">${transactionDate}</td>
        <td data-label="Nhân viên">${txn.staff_name || '-'}</td>
        <td data-label="Trạng thái"><span class="transaction-status-badge ${statusClass}">${statusText}</span></td>
        <td data-label="Sản phẩm" class="truncate max-w-xs" title="${productDisplay}">${productDisplay}</td>
        <td data-label="Số lượng" class="text-center font-semibold">${txn.total_quantity || 0}</td>
        <td data-label="Thao tác" class="transaction-actions-cell">
          <div class="transaction-actions-wrapper">
            ${
              txn.status === 'CHỜ DUYỆT'
                ? `<button class="transaction-action-btn approve-transaction-btn" data-transaction-id="${txn.transaction_id}" title="Duyệt phiếu">
                   <i class="fas fa-check"></i><span class="btn-text">Duyệt</span>
                 </button>`
                : `<span class="transaction-approved-badge"><i class="fas fa-check-double"></i><span class="btn-text">Đã duyệt</span></span>`
            }
            <button class="transaction-delete-btn" data-transaction-id="${
              txn.transaction_id
            }" title="Xóa phiếu">
              <i class="fas fa-trash-alt"></i>
            </button>
          </div>
        </td>
      `;

      transactionList.appendChild(row);

      // Click row to view details
      row.addEventListener('click', (e) => {
        if (
          !e.target.closest('.approve-transaction-btn') &&
          !e.target.closest('.transaction-delete-btn')
        ) {
          viewTransactionDetail(txn.transaction_id);
        }
      });
    });

    // Add event listeners for approve buttons
    document.querySelectorAll('.approve-transaction-btn').forEach((btn) => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        const transactionId = btn.dataset.transactionId;
        await approveTransaction(transactionId, btn);
      });
    });

    // Add event listeners for delete buttons
    document.querySelectorAll('.transaction-delete-btn').forEach((btn) => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        const transactionId = btn.dataset.transactionId;
        await deleteTransaction(transactionId);
      });
    });

    // ✅ Áp dụng cài đặt ẩn/hiện cột
    applyTransactionColumnVisibility();

    // Update pagination với dữ liệu từ cache
    updateTransactionPagination({
      total: totalItems,
      per_page: transactionItemsPerPage,
      current_page: currentTransactionPage,
      total_pages: totalPages,
    });
  }

  /**
   * Xóa phiếu xuất/nhập kho
   */
  async function deleteTransaction(transactionId) {
    // Xác nhận trước khi xóa
    const confirmed = await showConfirm(
      `Bạn có chắc chắn muốn xóa phiếu <strong>${transactionId}</strong>?<br><br><span class="text-red-600">Hành động này không thể hoàn tác!</span>`,
      'Xác nhận xóa phiếu'
    );

    if (!confirmed) return;

    try {
      const response = await fetchAPI(`inventory-transactions/${transactionId}`, {
        method: 'DELETE',
      });

      if (response.success) {
        toastSuccess('Đã xóa phiếu thành công');

        // ✅ Cập nhật cache: xóa transaction khỏi cache
        removeTransactionFromCache(transactionId);

        // ✅ Re-render UI từ cache (không cần gọi API)
        const filteredData = filterTransactionsFromCache(currentTransactionFilter);
        if (filteredData) {
          transactions = filteredData;
          renderTransactionList(transactions);
        } else {
          // Fallback: load lại từ API
          await loadInventoryTransactions(currentTransactionFilter, true);
        }
      } else {
        throw new Error(response.message || 'Lỗi khi xóa phiếu');
      }
    } catch (error) {
      console.error('❌ Lỗi khi xóa phiếu:', error);
      toastError('Lỗi: ' + error.message);
    }
  }

  /**
   * View chi tiết phiếu xuất/nhập - Giao diện giống Dashboard
   */
  async function viewTransactionDetail(transactionId) {
    const modal = document.getElementById('transactionDetailModal');
    if (!modal) return;

    const modalBody = document.getElementById('transactionDetailBody');
    if (!modalBody) return;

    modalBody.innerHTML =
      '<div class="text-center py-8"><i class="fas fa-spinner fa-spin"></i> Đang tải...</div>';
    modal.classList.add('show');

    try {
      const response = await fetchAPI(`inventory-transactions/${transactionId}`);
      console.log('📦 Transaction detail response:', response);

      // API có thể trả về {success: true, data: {...}} hoặc trực tiếp {...}
      let data;
      if (response.success !== undefined) {
        if (!response.success) {
          throw new Error(response.message || 'Không tìm thấy phiếu');
        }
        data = response.data || {};
      } else if (response.transaction_id) {
        data = response;
      } else {
        throw new Error('Không tìm thấy phiếu');
      }

      const items = data.items || [];
      if (items.length === 0) {
        throw new Error('Phiếu không có sản phẩm');
      }

      // Format date
      const formatDate = (dateStr) => {
        if (!dateStr) return '--';
        const d = new Date(dateStr);
        return d.toLocaleString('vi-VN', {
          hour: '2-digit',
          minute: '2-digit',
          day: '2-digit',
          month: '2-digit',
        });
      };

      const isIn = data.transaction_type === 'IN' || data.transaction_type === 'in';
      const typeLabel = isIn ? 'Nhập kho' : 'Xuất kho';
      const typeClass = isIn ? 'type-in' : 'type-out';
      const typeIcon = isIn ? 'fa-arrow-down' : 'fa-arrow-up';
      const isPending = data.status === 'CHỜ DUYỆT' || data.status === 'pending';
      const statusLabel = isPending ? 'Chờ duyệt' : 'Đã duyệt';
      const statusClass = isPending ? 'status-pending' : 'status-approved';

      // Tính tổng số lượng
      const totalQuantity = items.reduce((sum, item) => sum + parseInt(item.quantity || 0), 0);
      const productNames = items.map((i) => i.product_name).join(', ');

      // Check permission for approve button
      const canApprove =
        window.checkinData?.userPermissions?.includes('inventory.approve') ||
        ['Quản lý', 'Administrator', 'administrator'].includes(window.currentUserRole || '');
      const showApproveBtn = canApprove && isPending;

      let detailHTML = `
        <div class="stock-transfer-card">
          <div class="stock-transfer-card-header">
            <span class="stock-transfer-type ${typeClass}">
              <i class="fas ${typeIcon}"></i> ${typeLabel}
            </span>
            <span class="stock-transfer-status ${statusClass}">${statusLabel}</span>
          </div>
          <div class="stock-transfer-card-body">
            <div class="detail-row">
              <i class="fas fa-hashtag"></i>
              <span class="label">Mã phiếu:</span>
              <span class="value">${transactionId}</span>
            </div>
            <div class="detail-row">
              <i class="fas fa-user"></i>
              <span class="label">Nhân viên:</span>
              <span class="value">${data.staff_name || '--'}</span>
            </div>
            <div class="detail-row">
              <i class="fas fa-clock"></i>
              <span class="label">Thời gian:</span>
              <span class="value">${formatDate(data.transaction_date)}</span>
            </div>
            <div class="detail-row">
              <i class="fas fa-boxes"></i>
              <span class="label">Sản phẩm:</span>
              <span class="value">${items.length} SP (${totalQuantity} đơn vị)</span>
            </div>
            ${
              data.note
                ? `
            <div class="detail-row">
              <i class="fas fa-sticky-note"></i>
              <span class="label">Ghi chú:</span>
              <span class="value">${data.note}</span>
            </div>
            `
                : ''
            }
            <div class="detail-row">
              <i class="fas fa-list"></i>
              <span class="label">Chi tiết:</span>
              <span class="value products">${productNames}</span>
            </div>
            ${
              (data.image_url || data.image_key) &&
              (data.image_url || data.image_key).startsWith('http')
                ? `
            <div class="detail-row" style="flex-direction: column; align-items: flex-start;">
              <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 8px;">
                <i class="fas fa-image"></i>
                <span class="label">Ảnh đính kèm:</span>
              </div>
              <img src="${data.image_url || data.image_key}" alt="Ảnh phiếu kho"
                style="max-width: 100%; border-radius: 8px; border: 1px solid #e5e7eb; cursor: pointer;"
                onclick="window.open('${data.image_url || data.image_key}', '_blank')" />
            </div>
            `
                : ''
            }
          </div>
          ${
            showApproveBtn
              ? `
          <div class="stock-transfer-card-actions">
            <button class="btn-approve" onclick="window.approveTransactionFromDetail('${transactionId}')">
              <i class="fas fa-check"></i> Duyệt
            </button>
            <button class="btn-reject" onclick="window.rejectTransactionFromDetail('${transactionId}')">
              <i class="fas fa-times"></i> Từ chối
            </button>
          </div>
          `
              : ''
          }
        </div>
      `;

      modalBody.innerHTML = detailHTML;
    } catch (error) {
      console.error('❌ Lỗi khi xem chi tiết:', error);
      modalBody.innerHTML = `
        <div style="text-align: center; padding: 48px 24px;">
          <i class="fas fa-exclamation-triangle" style="font-size: 3rem; color: #ff3b30; margin-bottom: 16px;"></i>
          <p style="color: #ff3b30; font-weight: 600;">Lỗi: ${error.message}</p>
        </div>
      `;
    }
  }

  // Reject từ modal chi tiết
  window.rejectTransactionFromDetail = async function (transactionId) {
    const confirmed = await showConfirm(
      `Bạn có chắc muốn từ chối phiếu <strong>${transactionId}</strong>?`,
      'Xác nhận từ chối'
    );
    if (!confirmed) return;

    try {
      const response = await fetchAPI(`inventory-transactions/${transactionId}/reject`, {
        method: 'POST',
      });

      if (response.success) {
        toastSuccess('Đã từ chối phiếu!', 3000);
        const modal = document.getElementById('transactionDetailModal');
        if (modal) modal.classList.remove('show');
        loadInventoryTransactions(currentTransactionFilter, true);
        if (window.clearTransactionCache) window.clearTransactionCache();
        if (window.AppThoDashboard?.refreshStockTransferStatus) {
          window.AppThoDashboard.refreshStockTransferStatus();
        }
      } else {
        toastError(response.message || 'Lỗi khi từ chối phiếu', 3000);
      }
    } catch (error) {
      console.error('Reject error:', error);
      toastError('Lỗi kết nối: ' + error.message, 3000);
    }
  };

  // Approve từ modal chi tiết
  window.approveTransactionFromDetail = async function (transactionId) {
    const confirmed = await showConfirm(
      `Bạn có chắc muốn duyệt phiếu <strong>${transactionId}</strong>?`,
      'Xác nhận duyệt'
    );
    if (!confirmed) return;

    try {
      const response = await fetchAPI(`inventory-transactions/${transactionId}/approve`, {
        method: 'POST',
      });

      if (response.success) {
        toastSuccess('Đã duyệt phiếu thành công!', 3000);
        // Đóng modal
        const modal = document.getElementById('transactionDetailModal');
        if (modal) modal.classList.remove('show');
        // Refresh data
        loadInventoryTransactions(currentTransactionFilter, true);
        if (window.clearTransactionCache) window.clearTransactionCache();
        if (window.AppThoDashboard?.refreshStockTransferStatus) {
          window.AppThoDashboard.refreshStockTransferStatus();
        }
      } else {
        toastError(response.message || 'Lỗi khi duyệt phiếu', 3000);
      }
    } catch (error) {
      console.error('Approve error:', error);
      toastError('Lỗi kết nối: ' + error.message, 3000);
    }
  };

  /**
   * Approve phiếu xuất/nhập
   */
  async function approveTransaction(transactionId, buttonElement) {
    // Hiển thị modal xác nhận
    const confirmed = await showConfirm(
      `Bạn có chắc chắn muốn duyệt phiếu <strong>${transactionId}</strong>?`,
      'Xác nhận duyệt phiếu'
    );

    if (!confirmed) return;

    // Hiển thị button loader nếu có button element
    if (buttonElement) {
      setButtonLoading(buttonElement, 'Đang duyệt...');
    }

    // Hiển thị page loader
    window.showPageLoader({ text: 'Đang duyệt phiếu...', subtitle: 'Vui lòng đợi' });

    try {
      console.log('🔍 Approving transaction:', transactionId);
      const endpoint = `inventory-transactions/${transactionId}/approve`;
      console.log('🌐 Full URL:', `${checkinData.restUrl}${endpoint}`);

      const response = await fetchAPI(endpoint, {
        method: 'POST',
      });

      console.log('📦 Response:', response);

      if (!response.success) {
        throw new Error(response.message || 'Lỗi khi duyệt phiếu');
      }

      toastSuccess('✅ Đã duyệt phiếu thành công!', 3000);

      // ✅ Cập nhật cache: đổi status thành HOÀN THÀNH
      updateTransactionInCache(transactionId, { status: 'HOÀN THÀNH' });

      // ✅ Re-render UI từ cache (không cần gọi API)
      const filteredData = filterTransactionsFromCache(currentTransactionFilter);
      if (filteredData) {
        transactions = filteredData;
        renderTransactionList(transactions);
      }

      // Load lại inventory list (vẫn cần vì stock đã thay đổi)
      loadInventoryList();
    } catch (error) {
      console.error('❌ Lỗi khi duyệt phiếu:', error);
      toastError(`Lỗi khi duyệt phiếu: ${error.message}`, 3000);
    } finally {
      if (buttonElement) {
        resetButtonLoading(buttonElement);
      }
      window.hidePageLoader();
    }
  }

  /**
   * Update pagination (old version - for fallback)
   */
  function updateTransactionPaginationInfo() {
    const info = document.getElementById('transaction-pagination-info');
    if (info) {
      info.textContent = `Hiển thị ${transactions.length} / Tổng ${transactions.length}`;
    }
  }

  /**
   * Update pagination with full controls
   */
  function updateTransactionPagination(pagination) {
    const paginationInfo = document.getElementById('transaction-pagination-info');
    const paginationButtons = document.getElementById('transaction-pagination-buttons');

    if (!paginationInfo || !paginationButtons) return;

    const { total, per_page, current_page, total_pages } = pagination;

    // Update info text
    const start = total === 0 ? 0 : (current_page - 1) * per_page + 1;
    const end = Math.min(current_page * per_page, total);
    paginationInfo.textContent = `Hiển thị ${start} - ${end} / Tổng ${total}`;

    // Update buttons
    paginationButtons.innerHTML = `
      <button
        class="pagination-btn"
        ${current_page === 1 ? 'disabled' : ''}
        onclick="changeTransactionPage(${current_page - 1})">
        «
      </button>
      <span class="pagination-current">Trang ${current_page} / ${total_pages || 1}</span>
      <button
        class="pagination-btn"
        ${current_page === total_pages || total_pages === 0 ? 'disabled' : ''}
        onclick="changeTransactionPage(${current_page + 1})">
        »
      </button>
    `;
  }

  // Expose transaction pagination functions to global scope
  window.changeTransactionPage = function (page) {
    currentTransactionPage = page;
    localStorage.setItem('currentTransactionPage', page);

    // ✅ Re-render từ cache thay vì gọi API
    const cachedData = filterTransactionsFromCache(currentTransactionFilter);
    if (cachedData) {
      transactions = cachedData;
      renderTransactionList(transactions);
    } else {
      loadInventoryTransactions(currentTransactionFilter);
    }
  };

  window.changeTransactionItemsPerPage = function (perPage) {
    transactionItemsPerPage = parseInt(perPage);
    currentTransactionPage = 1;
    localStorage.setItem('transactionItemsPerPage', transactionItemsPerPage);
    localStorage.setItem('currentTransactionPage', 1);

    // ✅ Re-render từ cache thay vì gọi API
    const cachedData = filterTransactionsFromCache(currentTransactionFilter);
    if (cachedData) {
      transactions = cachedData;
      renderTransactionList(transactions);
    } else {
      loadInventoryTransactions(currentTransactionFilter);
    }
  };

  /**
   * Handle inventory tab switching
   */
  function handleInventoryTabSwitch(tab) {
    // Hide all tab contents
    document.querySelectorAll('.inventory-tab-content').forEach((content) => {
      content.classList.add('hidden');
    });

    // Show selected tab
    const tabContent = document.getElementById(
      tab === 'checks' ? 'inventoryChecksTab' : 'inventoryTransactionsTab'
    );
    if (tabContent) {
      tabContent.classList.remove('hidden');
    }

    // Update active state
    document.querySelectorAll('.inventory-tab-btn').forEach((btn) => {
      if (btn.dataset.tab === tab) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });

    // Load data
    if (tab === 'checks') {
      loadInventoryList();
    } else if (tab === 'transactions') {
      loadInventoryTransactions(currentTransactionFilter);
    }
  }

  /**
   * Handle transaction filter change
   */
  function handleTransactionFilterChange(status) {
    currentTransactionFilter = status;
    currentTransactionPage = 1; // Reset về trang 1 khi đổi filter

    // Update active state
    document.querySelectorAll('.transaction-filter-btn').forEach((btn) => {
      if (btn.dataset.status === status) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });

    // ✅ Lọc từ cache nếu có, không cần gọi API
    const cachedData = filterTransactionsFromCache(status);
    if (cachedData) {
      transactions = cachedData;
      renderTransactionList(transactions);
    } else {
      // Nếu không có cache, load từ API
      loadInventoryTransactions(status, true);
    }
  }

  /**
   * Refresh danh sách transactions từ API (xóa cache)
   */
  async function refreshTransactions() {
    const refreshBtn = document.getElementById('refreshTransactionsBtn');
    if (refreshBtn) {
      refreshBtn.classList.add('loading');
      refreshBtn.disabled = true;
    }

    try {
      clearTransactionCache();
      await loadInventoryTransactions(currentTransactionFilter, true);
      toastSuccess('Đã làm mới danh sách');
    } catch (error) {
      console.error('❌ Lỗi khi làm mới:', error);
      toastError('Lỗi khi làm mới danh sách');
    } finally {
      if (refreshBtn) {
        refreshBtn.classList.remove('loading');
        refreshBtn.disabled = false;
      }
    }
  }

  // Start the app
  document.addEventListener('DOMContentLoaded', initializeApp);
  document.addEventListener('DOMContentLoaded', initCancelBookingModal);
  document.addEventListener('DOMContentLoaded', restoreSyncQueue);

  // ✅ Setup event listeners for inventory tabs
  document.addEventListener('DOMContentLoaded', () => {
    // Inventory tab buttons
    document.querySelectorAll('.inventory-tab-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        handleInventoryTabSwitch(btn.dataset.tab);
      });
    });

    // Transaction filter buttons
    document.querySelectorAll('.transaction-filter-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        handleTransactionFilterChange(btn.dataset.status);
      });
    });

    // Transaction refresh button
    const refreshBtn = document.getElementById('refreshTransactionsBtn');
    if (refreshBtn) {
      refreshBtn.addEventListener('click', refreshTransactions);
    }

    // Transaction items per page selector
    const transactionItemsPerPageSelect = document.getElementById('transaction-items-per-page');
    if (transactionItemsPerPageSelect) {
      transactionItemsPerPageSelect.value = transactionItemsPerPage;
      transactionItemsPerPageSelect.addEventListener('change', (e) => {
        changeTransactionItemsPerPage(e.target.value);
      });
    }
  });

  // ✅ Export handleNavigation for dashboard module
  window.handleNavigation = handleNavigation;

  // ✅ Export openInventoryCheckModal for dashboard inventory status card
  window.openInventoryCheckModal = handleInventoryCheck;

  // ✅ Export cache functions for dashboard to reuse
  window.getInventoryCache = getInventoryCache;
  window.getTransactionCache = getTransactionCache;
  window.inventoryChecks = inventoryChecks;

  // ✅ Export inventory transaction functions for dashboard
  window.viewTransactionDetail = viewTransactionDetail;
  window.approveTransaction = approveTransaction;
  window.loadInventoryTransactions = loadInventoryTransactions;
  window.clearTransactionCache = clearTransactionCache;
})();
