<?php

/**
 * Push Notifications Settings Page
 *
 * Admin page for configuring push notification types, roles, and content
 *
 * @package    Checkin_MKT192_WP
 * @subpackage Admin/Pages
 * @since      6.1.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class Checkin_MKT192_WP_Push_Notifications_Page
 */
class Checkin_MKT192_WP_Push_Notifications_Page {

    /**
     * Singleton instance
     */
    private static $instance = null;

    /**
     * Page slug
     */
    private $page_slug = 'checkin-mkt192-push-notifications';

    /**
     * Notification types configuration
     * Defines all available notification types with default settings
     */
    private $notification_types = [];

    /**
     * Available roles for notifications
     */
    private $available_roles = [];

    /**
     * Get singleton instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor
     */
    public function __construct() {
        $this->setup_notification_types();
        $this->setup_available_roles();
        $this->register_ajax_handlers();
    }

    /**
     * Setup default notification types configuration
     */
    private function setup_notification_types() {
        $this->notification_types = [
            // Booking notifications
            'booking' => [
                'name'            => __('Lịch hẹn mới', 'checkin-mkt192'),
                'description'     => __('Thông báo khi có khách đặt lịch mới', 'checkin-mkt192'),
                'category'        => 'booking',
                'icon'            => '📅',
                'default_title'   => '📅 Lịch hẹn mới',
                'default_body'    => '{customer_name} đặt lịch lúc {booking_time}',
                'default_roles'   => ['administrator', 'manager', 'staff'],
                'variables'       => ['customer_name', 'staff_name', 'booking_time', 'branch_name'],
            ],
            'booking_cancelled' => [
                'name'            => __('Hủy lịch hẹn', 'checkin-mkt192'),
                'description'     => __('Thông báo khi khách hủy lịch hẹn', 'checkin-mkt192'),
                'category'        => 'booking',
                'icon'            => '❌',
                'default_title'   => '❌ Hủy lịch hẹn',
                'default_body'    => '{customer_name} đã hủy lịch lúc {booking_time}',
                'default_roles'   => ['administrator', 'manager', 'staff'],
                'variables'       => ['customer_name', 'staff_name', 'booking_time', 'branch_name'],
            ],

            // Invoice notifications
            'payment_success' => [
                'name'            => __('Thanh toán thành công', 'checkin-mkt192'),
                'description'     => __('Thông báo khi hóa đơn được thanh toán', 'checkin-mkt192'),
                'category'        => 'invoice',
                'icon'            => '💰',
                'default_title'   => '💰 Thanh toán thành công',
                'default_body'    => 'Hóa đơn #{invoice_id} đã thanh toán: {total}đ',
                'default_roles'   => ['administrator', 'manager', 'staff'],
                'variables'       => ['invoice_id', 'total', 'branch_name'],
            ],
            'invoice_surcharge' => [
                'name'            => __('Hóa đơn truy thu', 'checkin-mkt192'),
                'description'     => __('Thông báo khi có hóa đơn bị truy thu', 'checkin-mkt192'),
                'category'        => 'invoice',
                'icon'            => '⚠️',
                'default_title'   => '⚠️ Hóa đơn truy thu',
                'default_body'    => 'Hóa đơn #{invoice_id} bị truy thu: {surcharge_amount}đ',
                'default_roles'   => ['administrator', 'manager', 'cashier', 'staff'],
                'variables'       => ['invoice_id', 'surcharge_amount', 'staff_name', 'branch_name'],
            ],
            'invoice_deleted' => [
                'name'            => __('Xóa hóa đơn', 'checkin-mkt192'),
                'description'     => __('Thông báo khi hóa đơn bị xóa', 'checkin-mkt192'),
                'category'        => 'invoice',
                'icon'            => '🗑️',
                'default_title'   => '🗑️ Xóa hóa đơn',
                'default_body'    => 'Hóa đơn #{invoice_id} đã bị xóa bởi {deleted_by}',
                'default_roles'   => ['administrator', 'manager', 'cashier'],
                'variables'       => ['invoice_id', 'deleted_by', 'branch_name'],
            ],
            // Báo cáo cuối ngày 23:00 (cron daily_no_image_penalty_report): card chi tiết đi Lark (bot gán loại
            // no_image_penalty_report), tiêu đề + nội dung ở đây dùng làm header/tóm tắt của card VÀ push cho vai trò chọn.
            // Tắt template này = tắt cả báo cáo.
            'no_image_penalty_report' => [
                'name'            => __('Báo cáo truy thu không ảnh 23:00', 'checkin-mkt192'),
                'description'     => __('23:00 mỗi ngày: hoá đơn không ảnh khách, không lý do, không phải khách vãng lai, gom theo thợ. Card chi tiết gửi Lark, push tóm tắt cho vai trò chọn', 'checkin-mkt192'),
                'category'        => 'invoice',
                'icon'            => '🧾',
                'default_title'   => '🧾 Truy thu hoá đơn không ảnh · {date}',
                'default_body'    => '{violations} hoá đơn / {staff_count} thợ · dự kiến truy thu {total_penalty}đ',
                'default_roles'   => ['administrator'],
                'variables'       => ['date', 'total_invoices', 'violations', 'staff_count', 'total_penalty', 'penalty_rule', 'staff_list'],
                // Phải chạy sau cron xử lý ảnh 23:55, nếu không cột images chưa có URL chính thức và báo cáo sẽ
                // kết luận nhầm là hoá đơn không ảnh
                'supports_schedule' => true,
                'default_schedule'  => '00:15',
                // Bảng 4 chỉ số (2 cột) trên card Lark - đổi được nhãn và biến. Nhãn để trống = ẩn ô đó.
                'stats_label'     => __('Bảng chỉ số trên card Lark', 'checkin-mkt192'),
                'default_stats'   => [
                    ['label' => '🧾 Hoá đơn vi phạm', 'value' => '{violations}'],
                    ['label' => '✂️ Thợ vi phạm',     'value' => '{staff_count}'],
                    ['label' => '📏 Mức truy thu',    'value' => '{penalty_rule}'],
                    ['label' => '💸 Dự kiến truy thu', 'value' => '{total_penalty}đ'],
                ],
            ],

            // Attendance notifications
            'late_checkin_report' => [
                'name'            => __('Báo cáo chấm công cuối ngày', 'checkin-mkt192'),
                'description'     => __('Cuối ngày: thợ đi trễ phải nộp heo, thợ chưa chấm công vào, thợ quên chấm công ra. Card chi tiết gửi Lark, push tóm tắt cho vai trò chọn', 'checkin-mkt192'),
                'category'        => 'attendance',
                'icon'            => '⏰',
                'default_title'   => '⏰ Chấm công cuối ngày · {date}',
                'default_body'    => '{late_count} thợ đi trễ · nộp heo {late_total}đ · {no_checkin_count} chưa chấm vào · {no_checkout_count} quên chấm ra',
                'default_roles'   => ['administrator'],
                'variables'       => ['date', 'late_count', 'late_total', 'no_checkin_count', 'no_checkout_count', 'on_duty_count', 'penalty_rule', 'late_list'],
                'supports_schedule' => true,
                'default_schedule'  => '23:00',
                'stats_label'     => __('Bảng chỉ số trên card Lark', 'checkin-mkt192'),
                'default_stats'   => [
                    ['label' => '⏰ Thợ đi trễ', 'value' => '{late_count}'],
                    ['label' => '🐷 Tiền nộp heo', 'value' => '{late_total}đ'],
                    ['label' => '📵 Chưa chấm công vào', 'value' => '{no_checkin_count}'],
                    ['label' => '🚪 Quên chấm công ra', 'value' => '{no_checkout_count}'],
                ],
            ],

            // Review notifications
            'review' => [
                'name'            => __('Đánh giá mới', 'checkin-mkt192'),
                'description'     => __('Thông báo khi khách đánh giá dịch vụ', 'checkin-mkt192'),
                'category'        => 'review',
                'icon'            => '⭐',
                'default_title'   => '⭐ Đánh giá mới',
                'default_body'    => '{customer_name} đã đánh giá bạn {rating_stars}',
                'default_roles'   => ['administrator', 'manager', 'staff'],
                'variables'       => ['customer_name', 'staff_name', 'rating_stars', 'branch_name'],
            ],

            // Approval notifications
            'approval_request' => [
                'name'            => __('Đơn cần duyệt', 'checkin-mkt192'),
                'description'     => __('Thông báo khi có đơn mới cần duyệt (nghỉ phép, tăng ca...)', 'checkin-mkt192'),
                'category'        => 'approval',
                'icon'            => '📝',
                'default_title'   => '📝 Đơn mới cần duyệt',
                'default_body'    => '{staff_name} đã gửi đơn {request_type}',
                'default_roles'   => ['administrator', 'manager'],
                'variables'       => ['staff_name', 'request_type', 'branch_name'],
            ],
            'approval_result' => [
                'name'            => __('Kết quả duyệt đơn', 'checkin-mkt192'),
                'description'     => __('Thông báo cho nhân viên khi đơn được duyệt/từ chối', 'checkin-mkt192'),
                'category'        => 'approval',
                'icon'            => '✅',
                'default_title'   => '{status_icon} Đơn {request_type} {status_text}',
                'default_body'    => 'Đơn {request_type} của bạn đã {status_text}',
                'default_roles'   => ['staff'],
                'variables'       => ['request_type', 'status_icon', 'status_text'],
            ],

            // Salary notifications
            'salary_slip' => [
                'name'            => __('Phiếu lương', 'checkin-mkt192'),
                'description'     => __('Thông báo gửi đến nhân viên khi Admin gửi phiếu lương', 'checkin-mkt192'),
                'category'        => 'salary',
                'icon'            => '💵',
                'default_title'   => '💵 Phiếu lương tháng {month}/{year}',
                'default_body'    => 'Phiếu lương của bạn đã sẵn sàng. Vui lòng vào xác nhận.',
                'default_roles'   => ['staff', 'cashier'],
                'variables'       => ['month', 'year', 'staff_name'],
            ],
            'salary_slip_confirmed' => [
                'name'            => __('Xác nhận phiếu lương', 'checkin-mkt192'),
                'description'     => __('Thông báo gửi đến Admin khi nhân viên xác nhận phiếu lương', 'checkin-mkt192'),
                'category'        => 'salary',
                'icon'            => '✅',
                'default_title'   => '✅ {staff_name} đã xác nhận phiếu lương',
                'default_body'    => '{staff_name} đã xác nhận phiếu lương tháng {month}/{year}',
                'default_roles'   => ['administrator'],
                'variables'       => ['month', 'year', 'staff_name', 'branch_name'],
            ],
            'salary_payment' => [
                'name'            => __('Thanh toán lương', 'checkin-mkt192'),
                'description'     => __('Thông báo gửi đến nhân viên khi Admin upload ảnh chuyển khoản', 'checkin-mkt192'),
                'category'        => 'salary',
                'icon'            => '💰',
                'default_title'   => '💰 Lương tháng {month}/{year} đã thanh toán',
                'default_body'    => 'Lương của bạn đã được thanh toán. Vui lòng vào xác nhận.',
                'default_roles'   => ['staff', 'cashier'],
                'variables'       => ['month', 'year', 'staff_name'],
            ],
            'salary_payment_confirmed' => [
                'name'            => __('Xác nhận thanh toán lương', 'checkin-mkt192'),
                'description'     => __('Thông báo gửi đến Admin khi nhân viên xác nhận đã nhận lương', 'checkin-mkt192'),
                'category'        => 'salary',
                'icon'            => '🎉',
                'default_title'   => '🎉 {staff_name} đã xác nhận thanh toán',
                'default_body'    => '{staff_name} đã xác nhận nhận lương tháng {month}/{year}',
                'default_roles'   => ['administrator'],
                'variables'       => ['month', 'year', 'staff_name', 'status', 'branch_name'],
            ],
            'salary_batch' => [
                'name'            => __('Bảng lương cập nhật', 'checkin-mkt192'),
                'description'     => __('Thông báo cho quản lý khi bảng lương được tạo/cập nhật', 'checkin-mkt192'),
                'category'        => 'salary',
                'icon'            => '📊',
                'default_title'   => '📊 Bảng lương {action_text}',
                'default_body'    => 'Bảng lương tháng {month}/{year} {action_text}',
                'default_roles'   => ['administrator'],
                'variables'       => ['month', 'year', 'action_text'],
            ],

            // Inventory notifications
            'inventory_pending' => [
                'name'            => __('Phiếu kho cần duyệt', 'checkin-mkt192'),
                'description'     => __('Thông báo khi có phiếu xuất/nhập kho mới cần duyệt', 'checkin-mkt192'),
                'category'        => 'inventory',
                'icon'            => '📦',
                'default_title'   => '📦 Phiếu {type_text} mới cần duyệt',
                'default_body'    => '{staff_name} đã tạo phiếu {type_text} ({product_count} sản phẩm)',
                'default_roles'   => ['administrator', 'manager'],
                'variables'       => ['staff_name', 'type_text', 'product_count', 'branch_name'],
            ],
            'inventory_approved' => [
                'name'            => __('Phiếu kho đã duyệt', 'checkin-mkt192'),
                'description'     => __('Thông báo khi phiếu xuất/nhập kho được duyệt', 'checkin-mkt192'),
                'category'        => 'inventory',
                'icon'            => '✅',
                'default_title'   => '✅ Phiếu {type_text} đã được duyệt',
                'default_body'    => 'Phiếu #{transaction_id} của bạn đã được {approved_by} duyệt',
                'default_roles'   => ['cashier', 'staff'],
                'variables'       => ['transaction_id', 'type_text', 'approved_by', 'branch_name'],
            ],

            // Staff announcement notifications
            'staff_announcement' => [
                'name'            => __('Thông báo nhân viên', 'checkin-mkt192'),
                'description'     => __('Thông báo từ quản lý gửi đến nhân viên (tạo từ trang Thông báo)', 'checkin-mkt192'),
                'category'        => 'announcement',
                'icon'            => '📢',
                'default_title'   => '📢 {title}',
                'default_body'    => '{content}',
                'default_roles'   => ['administrator', 'cashier', 'staff'],
                'variables'       => ['title', 'content', 'branch_name'],
            ],
        ];
    }

    /**
     * Setup available roles for notifications
     */
    private function setup_available_roles() {
        $this->available_roles = [
            'administrator' => [
                'name'  => __('Administrator', 'checkin-mkt192'),
                'label' => __('Quản trị viên', 'checkin-mkt192'),
                'icon'  => 'dashicons-admin-users',
                'color' => '#dc2626',
            ],
            'cashier' => [
                'name'  => __('Cashier', 'checkin-mkt192'),
                'label' => __('Thu ngân', 'checkin-mkt192'),
                'icon'  => 'dashicons-money-alt',
                'color' => '#059669',
            ],
            'staff' => [
                'name'  => __('Staff', 'checkin-mkt192'),
                'label' => __('Nhân viên', 'checkin-mkt192'),
                'icon'  => 'dashicons-admin-users',
                'color' => '#2563eb',
            ],
        ];
    }

    /**
     * Register AJAX handlers
     */
    private function register_ajax_handlers() {
        add_action('wp_ajax_checkin_push_save_notification_settings', [$this, 'ajax_save_notification_settings']);
        add_action('wp_ajax_checkin_push_get_notification_settings', [$this, 'ajax_get_notification_settings']);
        add_action('wp_ajax_checkin_push_reset_notification_settings', [$this, 'ajax_reset_notification_settings']);
        add_action('wp_ajax_checkin_push_test_notification', [$this, 'ajax_test_notification']);
        add_action('wp_ajax_checkin_push_save_onesignal_config', [$this, 'ajax_save_onesignal_config']);
        add_action('wp_ajax_checkin_push_export_settings', [$this, 'ajax_export_settings']);
        add_action('wp_ajax_checkin_push_import_settings', [$this, 'ajax_import_settings']);
    }

    /**
     * AJAX handler: Save OneSignal configuration
     */
    public function ajax_save_onesignal_config() {
        check_ajax_referer('checkin-admin-nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Không có quyền thực hiện.', 'checkin-mkt192')]);
        }

        $push_enabled  = isset($_POST['push_enabled']) && $_POST['push_enabled'] === '1';
        $app_id        = sanitize_text_field($_POST['app_id'] ?? '');
        $api_key       = sanitize_text_field($_POST['api_key'] ?? '');
        $safari_web_id = sanitize_text_field($_POST['safari_web_id'] ?? '');

        // Validate required fields when enabling
        if ($push_enabled) {
            if (empty($app_id) || empty($api_key)) {
                wp_send_json_error([
                    'message' => __('Vui lòng nhập App ID và REST API Key', 'checkin-mkt192')
                ]);
            }
        }

        // Save settings
        update_option('checkin_push_enabled', $push_enabled ? '1' : '0');
        update_option('checkin_onesignal_app_id', $app_id);
        update_option('checkin_onesignal_api_key', $api_key);
        update_option('checkin_onesignal_safari_web_id', $safari_web_id);

        wp_send_json_success([
            'message'      => __('Đã lưu cấu hình OneSignal', 'checkin-mkt192'),
            'isConfigured' => !empty($app_id) && !empty($api_key),
            'pushEnabled'  => $push_enabled,
        ]);
    }

    /**
     * Get saved notification settings from database
     *
     * @param string $type Notification type key
     * @return array Settings for the notification type
     */
    public function get_notification_settings($type) {
        $saved_settings = get_option('checkin_push_notification_settings', []);

        // Return saved settings if exists
        if (isset($saved_settings[$type])) {
            return wp_parse_args($saved_settings[$type], $this->get_default_settings($type));
        }

        // Return default settings
        return $this->get_default_settings($type);
    }

    /**
     * Get default settings for a notification type
     *
     * @param string $type Notification type key
     * @return array Default settings
     */
    private function get_default_settings($type) {
        if (!isset($this->notification_types[$type])) {
            return [];
        }

        $config = $this->notification_types[$type];

        $defaults = [
            'enabled'        => true,
            'title'          => $config['default_title'],
            'body'           => $config['default_body'],
            'roles'          => $config['default_roles'],
        ];

        if (!empty($config['default_stats'])) {
            $defaults['stats'] = $config['default_stats'];
        }

        if (!empty($config['supports_schedule'])) {
            $defaults['schedule'] = $config['default_schedule'] ?? '23:00';
        }

        return $defaults;
    }

    /**
     * Get all notification types
     *
     * @return array All notification types with current settings
     */
    public function get_all_notification_types() {
        $result = [];

        foreach ($this->notification_types as $type => $config) {
            $settings      = $this->get_notification_settings($type);
            $result[$type] = array_merge($config, [
                'settings' => $settings
            ]);
        }

        return $result;
    }

    /**
     * AJAX: Save notification settings
     */
    public function ajax_save_notification_settings() {
        // Verify nonce
        if (!check_ajax_referer('checkin-admin-nonce', 'nonce', false)) {
            wp_send_json_error(['message' => __('Lỗi bảo mật', 'checkin-mkt192')]);
        }

        // Check permission
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Không có quyền', 'checkin-mkt192')]);
        }

        $type     = sanitize_text_field($_POST['notification_type'] ?? '');
        $settings = $_POST['settings'] ?? [];

        if (empty($type) || !isset($this->notification_types[$type])) {
            wp_send_json_error(['message' => __('Loại thông báo không hợp lệ', 'checkin-mkt192')]);
        }

        // Sanitize settings - preserve line breaks in body
        $sanitized_settings = [
            'enabled'        => !empty($settings['enabled']),
            'title'          => sanitize_text_field($settings['title'] ?? ''),
            'body'           => sanitize_textarea_field($settings['body'] ?? ''),
            'roles'          => array_map('sanitize_text_field', (array)($settings['roles'] ?? [])),
        ];

        // Giờ gửi (HH:MM, múi giờ WordPress); sai định dạng thì giữ mặc định của loại đó
        if (!empty($this->notification_types[$type]['supports_schedule'])) {
            $schedule = sanitize_text_field($settings['schedule'] ?? '');
            $sanitized_settings['schedule'] = preg_match('/^([01][0-9]|2[0-3]):[0-5][0-9]$/', $schedule)
                ? $schedule
                : ($this->notification_types[$type]['default_schedule'] ?? '23:00');
        }

        // Bảng chỉ số (chỉ loại nào khai báo default_stats mới có); nhãn rỗng = ẩn ô đó trên card
        if (!empty($this->notification_types[$type]['default_stats'])) {
            $stats = [];
            foreach ((array)($settings['stats'] ?? []) as $stat) {
                $stats[] = [
                    'label' => sanitize_text_field($stat['label'] ?? ''),
                    'value' => sanitize_text_field($stat['value'] ?? ''),
                ];
            }
            $sanitized_settings['stats'] = $stats ?: $this->notification_types[$type]['default_stats'];
        }

        // Get current saved settings - ensure it's an array
        $all_settings = get_option('checkin_push_notification_settings', []);
        if (!is_array($all_settings)) {
            $all_settings = [];
        }

        // Update settings for this type
        $all_settings[$type] = $sanitized_settings;

        // Save to database
        update_option('checkin_push_notification_settings', $all_settings);

        // Cleanup legacy options (chỉ lần đầu)
        static $cleaned_up = false;
        if (!$cleaned_up) {
            $this->cleanup_legacy_options();
            $cleaned_up = true;
        }

        wp_send_json_success([
            'message'  => __('Đã lưu cài đặt', 'checkin-mkt192'),
            'settings' => $sanitized_settings
        ]);
    }

    /**
     * AJAX: Get notification settings
     */
    public function ajax_get_notification_settings() {
        // Verify nonce
        if (!check_ajax_referer('checkin-admin-nonce', 'nonce', false)) {
            wp_send_json_error(['message' => __('Lỗi bảo mật', 'checkin-mkt192')]);
        }

        // Check permission
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Không có quyền', 'checkin-mkt192')]);
        }

        $type = sanitize_text_field($_POST['notification_type'] ?? '');

        if (!empty($type) && isset($this->notification_types[$type])) {
            wp_send_json_success([
                'type'     => $type,
                'config'   => $this->notification_types[$type],
                'settings' => $this->get_notification_settings($type)
            ]);
        }

        // Return all
        wp_send_json_success([
            'types' => $this->get_all_notification_types(),
            'roles' => $this->available_roles
        ]);
    }

    /**
     * AJAX: Reset notification settings to default
     */
    public function ajax_reset_notification_settings() {
        // Verify nonce
        if (!check_ajax_referer('checkin-admin-nonce', 'nonce', false)) {
            wp_send_json_error(['message' => __('Lỗi bảo mật', 'checkin-mkt192')]);
        }

        // Check permission
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Không có quyền', 'checkin-mkt192')]);
        }

        $type = sanitize_text_field($_POST['notification_type'] ?? '');

        if (empty($type)) {
            // Reset all
            delete_option('checkin_push_notification_settings');
            wp_send_json_success(['message' => __('Đã khôi phục tất cả về mặc định', 'checkin-mkt192')]);
        }

        if (!isset($this->notification_types[$type])) {
            wp_send_json_error(['message' => __('Loại thông báo không hợp lệ', 'checkin-mkt192')]);
        }

        // Reset specific type
        $all_settings = get_option('checkin_push_notification_settings', []);
        unset($all_settings[$type]);
        update_option('checkin_push_notification_settings', $all_settings);

        wp_send_json_success([
            'message'  => __('Đã khôi phục về mặc định', 'checkin-mkt192'),
            'settings' => $this->get_default_settings($type)
        ]);
    }

    /**
     * AJAX: Send test notification
     */
    public function ajax_test_notification() {
        // Verify nonce
        if (!check_ajax_referer('checkin-admin-nonce', 'nonce', false)) {
            wp_send_json_error(['message' => __('Lỗi bảo mật', 'checkin-mkt192')]);
        }

        // Check permission
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Không có quyền', 'checkin-mkt192')]);
        }

        $type = sanitize_text_field($_POST['notification_type'] ?? '');

        if (empty($type) || !isset($this->notification_types[$type])) {
            wp_send_json_error(['message' => __('Loại thông báo không hợp lệ', 'checkin-mkt192')]);
        }

        // Get settings
        $settings = $this->get_notification_settings($type);
        $config   = $this->notification_types[$type];

        // Kiểm tra nếu không có roles nào được cấu hình
        if (empty($settings['roles'])) {
            wp_send_json_error([
                'message' => __('Không thể gửi test - chưa chọn vai trò nhận thông báo. Vui lòng chọn ít nhất 1 vai trò.', 'checkin-mkt192')
            ]);
        }

        // Replace variables with test data
        $test_data = $this->get_test_data($type);
        $title     = $this->replace_variables($settings['title'], $test_data);
        $body      = $this->replace_variables($settings['body'], $test_data);

        // Check if push function exists
        if (!function_exists('checkin_push_send_to_users')) {
            wp_send_json_error(['message' => __('Push notification API không khả dụng', 'checkin-mkt192')]);
        }

        // Send test to current user
        $user_id = get_current_user_id();
        $result  = checkin_push_send_to_users($user_id, [
            'title' => $title,
            'body'  => $body,
            'url'   => admin_url('admin.php?page=' . $this->page_slug),
            'data'  => [
                'type' => 'test_' . $type
            ]
        ]);

        if ($result) {
            wp_send_json_success(['message' => __('Đã gửi thông báo test', 'checkin-mkt192')]);
        } else {
            wp_send_json_error(['message' => __('Không thể gửi thông báo', 'checkin-mkt192')]);
        }
    }

    /**
     * Get test data for notification type
     *
     * @param string $type Notification type
     * @return array Test data
     */
    private function get_test_data($type) {
        $common = [
            'customer_name'    => 'Nguyễn Văn A',
            'staff_name'       => 'Trần Văn B',
            'branch_name'      => 'Chi nhánh Gò Vấp',
            'invoice_id'       => '12345',
            'booking_time'     => '10:00 ' . date('d/m/Y'),
            'total'            => '500,000',
            'surcharge_amount' => '50,000',
            'deleted_by'       => 'Admin',
            'rating_stars'     => '⭐⭐⭐⭐⭐',
            'request_type'     => 'nghỉ phép',
            'status_icon'      => '✅',
            'status_text'      => 'được duyệt',
            'month'            => date('m'),
            'year'             => date('Y'),
            'action_text'      => 'đã được tạo',
            'type_text'        => 'Nhập kho',
            'product_count'    => '5',
            'transaction_id'   => '999',
            'approved_by'      => 'Quản lý',
            'penalty_rule'     => '100% giá trị DV/HC',
            'late_count'       => '2',
            'late_total'       => '100.000',
            'no_checkin_count' => '1',
            'no_checkout_count' => '1',
            'on_duty_count'    => '5',
            'late_list'        => 'Thế Giáp, Nguyễn Phát',
            'date'             => date('d/m/Y'),
            'total_invoices'   => '38',
            'violations'       => '2',
            'staff_count'      => '2',
            'total_penalty'    => '180.000',
            'staff_list'       => 'Thế Giáp (1), Hoàng Huy (1)',
        ];

        return $common;
    }

    /**
     * AJAX handler: Export all push notification settings
     */
    public function ajax_export_settings() {
        check_ajax_referer('checkin-admin-nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Không có quyền thực hiện.', 'checkin-mkt192')]);
        }

        $export_data = [
            'version'       => '1.0',
            'exported_at'   => current_time('mysql'),
            'notifications' => [],
        ];

        // Export all notification settings (only title, body, enabled, roles - NOT OneSignal credentials)
        foreach ($this->notification_types as $type => $config) {
            $settings                            = $this->get_notification_settings($type);
            $export_data['notifications'][$type] = [
                'enabled' => $settings['enabled'] ?? true,
                'title'   => $settings['title']   ?? $config['default_title'],
                'body'    => $settings['body']    ?? $config['default_body'],
                'roles'   => $settings['roles']   ?? $config['default_roles'],
            ];
        }

        wp_send_json_success([
            'data'     => $export_data,
            'filename' => 'push-notifications-settings-' . date('Y-m-d') . '.json',
        ]);
    }

    /**
     * AJAX handler: Import push notification settings
     */
    public function ajax_import_settings() {
        check_ajax_referer('checkin-admin-nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Không có quyền thực hiện.', 'checkin-mkt192')]);
        }

        $import_data = isset($_POST['import_data']) ? $_POST['import_data'] : '';

        if (empty($import_data)) {
            wp_send_json_error(['message' => __('Không có dữ liệu để nhập', 'checkin-mkt192')]);
        }

        // Parse JSON - handle both string and array
        if (is_string($import_data)) {
            $data = json_decode(stripslashes($import_data), true);
        } else {
            $data = $import_data;
        }

        if (json_last_error() !== JSON_ERROR_NONE || !is_array($data)) {
            wp_send_json_error(['message' => __('Dữ liệu không hợp lệ', 'checkin-mkt192')]);
        }

        // Validate structure
        if (!isset($data['notifications']) || !is_array($data['notifications'])) {
            wp_send_json_error(['message' => __('Cấu trúc file không đúng', 'checkin-mkt192')]);
        }

        // Get current saved settings - ensure it's an array
        $all_settings = get_option('checkin_push_notification_settings', []);
        if (!is_array($all_settings)) {
            // If somehow stored as string or corrupted, reset to empty array
            $all_settings = [];
        }
        $imported_count = 0;

        // Import notification settings - save to same option as ajax_save_notification_settings
        foreach ($data['notifications'] as $type => $settings) {
            // Only import known notification types
            if (!isset($this->notification_types[$type])) {
                continue;
            }

            // Sanitize settings
            $sanitized = [
                'enabled' => !empty($settings['enabled']),
                'title'   => sanitize_text_field($settings['title'] ?? ''),
                'body'    => sanitize_textarea_field($settings['body'] ?? ''),
                'roles'   => array_map('sanitize_text_field', (array)($settings['roles'] ?? [])),
            ];

            // Update settings for this type
            $all_settings[$type] = $sanitized;
            $imported_count++;
        }

        // Save all settings to single option (same as ajax_save_notification_settings)
        update_option('checkin_push_notification_settings', $all_settings);

        // Cleanup legacy options (từ phiên bản cũ lưu mỗi type 1 option riêng)
        $this->cleanup_legacy_options();

        wp_send_json_success([
            'message' => sprintf(__('Đã nhập %d cài đặt thông báo thành công', 'checkin-mkt192'), $imported_count),
            'count'   => $imported_count,
        ]);
    }

    /**
     * Replace variables in template string
     *
     * @param string $template Template string with {variable} placeholders
     * @param array $data Data to replace
     * @return string Replaced string
     */
    private function replace_variables($template, $data) {
        foreach ($data as $key => $value) {
            $template = str_replace('{' . $key . '}', $value, $template);
        }
        return $template;
    }

    /**
     * Cleanup legacy options from old version
     * Old version stored each notification type as separate option: checkin_push_{type}
     * New version stores all in single option: checkin_push_notification_settings
     */
    private function cleanup_legacy_options() {
        $legacy_option_prefixes = [
            'checkin_push_booking',
            'checkin_push_booking_cancelled',
            'checkin_push_payment_success',
            'checkin_push_invoice_surcharge',
            'checkin_push_invoice_deleted',
            'checkin_push_review',
            'checkin_push_approval_request',
            'checkin_push_approval_result',
            'checkin_push_salary_slip',
            'checkin_push_salary_payment',
            'checkin_push_salary_batch',
            'checkin_push_inventory_pending',
            'checkin_push_inventory_approved',
        ];

        foreach ($legacy_option_prefixes as $option_name) {
            delete_option($option_name);
        }
    }

    /**
     * Render the page
     */
    public function render() {
        $push_enabled   = get_option('checkin_push_enabled', '0') === '1';
        $app_id         = get_option('checkin_onesignal_app_id', '');
        $api_key        = get_option('checkin_onesignal_api_key', '');
        $is_configured  = !empty($app_id) && !empty($api_key);
        $multi_branch   = get_option('checkin_branch_mode_enabled', '0') === '1';
        ?>
<div class="wrap checkin-admin-wrapper">
    <?php include CHECKIN_PLUGIN_DIR . 'admin/partials/global-header.php'; ?>
    <?php include CHECKIN_PLUGIN_DIR . 'admin/partials/admin-notices.php'; ?>
    <div class="checkin-admin-page">
        <?php $this->render_page_header(); ?>
        <?php $this->render_onesignal_card($push_enabled, $app_id, $api_key, $is_configured); ?>
        <?php if ($push_enabled && $is_configured) : ?>
        <?php $this->render_notification_grid(); ?>
        <?php endif; ?>
        <?php $this->render_modals(); ?>
    </div>
</div>
<script>
// Pass data to JavaScript
window.checkinPushNotifications = {
    types: <?php echo json_encode($this->get_all_notification_types(), JSON_UNESCAPED_UNICODE); ?>,
    roles: <?php echo json_encode($this->available_roles, JSON_UNESCAPED_UNICODE); ?>,
    nonce: '<?php echo wp_create_nonce('checkin-admin-nonce'); ?>',
    ajaxUrl: '<?php echo admin_url('admin-ajax.php'); ?>',
    multiBranch: <?php echo $multi_branch ? 'true' : 'false'; ?>,
    isConfigured: <?php echo $is_configured ? 'true' : 'false'; ?>,
    pushEnabled: <?php echo $push_enabled ? 'true' : 'false'; ?>
};
</script>
<?php
    }

    /**
     * Render OneSignal configuration card
     */
    private function render_onesignal_card($push_enabled, $app_id, $api_key, $is_configured) {
        $safari_web_id = get_option('checkin_onesignal_safari_web_id', '');
        ?>
<div class="checkin-settings-section">
    <div class="checkin-section-header">
        <span class="dashicons dashicons-admin-settings" style="color: #FF6B35;"></span>
        <h2 class="checkin-section-title">
            <?php _e('Cấu hình OneSignal', 'checkin-mkt192'); ?>
        </h2>
        <!-- Toggle và collapse kế bên tiêu đề -->
        <label class="checkin-toggle checkin-toggle-md" style="margin-left: 12px;">
            <input type="checkbox" id="push-enabled-toggle" name="checkin_push_enabled" value="1"
                <?php checked($push_enabled); ?>>
            <span class="checkin-toggle-slider"></span>
        </label>
        <button type="button" class="checkin-btn-collapse" id="toggle-onesignal-config"
            title="<?php _e('Ẩn/Hiện cấu hình', 'checkin-mkt192'); ?>"
            style="background: none; border: none; cursor: pointer; padding: 4px; display: flex; align-items: center;">
            <span class="dashicons dashicons-arrow-down-alt2" style="font-size: 20px; color: #666;"></span>
        </button>
        <!-- Badge và nút reset ở góc phải -->
        <div class="checkin-section-header-actions"
            style="margin-left: auto; display: flex; align-items: center; gap: 12px;">
            <?php if ($push_enabled && $is_configured) : ?>
            <button type="button"
                class="checkin-button checkin-button-secondary checkin-button-sm checkin-btn-reset-all"
                onclick="resetAllNotificationSettings()">
                <span class="dashicons dashicons-image-rotate"></span>
                <?php _e('Khôi phục mặc định', 'checkin-mkt192'); ?>
            </button>
            <?php endif; ?>
            <!-- Export/Import buttons -->
            <button type="button" class="checkin-button checkin-button-outline checkin-button-sm"
                id="btn-export-settings" title="<?php _e('Tải cài đặt về máy', 'checkin-mkt192'); ?>">
                <span class="dashicons dashicons-download"></span>
                <?php _e('Xuất', 'checkin-mkt192'); ?>
            </button>
            <button type="button" class="checkin-button checkin-button-outline checkin-button-sm"
                id="btn-import-settings" title="<?php _e('Nhập cài đặt từ file', 'checkin-mkt192'); ?>">
                <span class="dashicons dashicons-upload"></span>
                <?php _e('Nhập', 'checkin-mkt192'); ?>
            </button>
            <input type="file" id="import-settings-file" accept=".json" style="display: none;">
            <?php if ($push_enabled) : ?>
            <span class="checkin-badge checkin-badge-success">
                <span class="dashicons dashicons-yes-alt"></span>
                <?php _e('Đã kích hoạt', 'checkin-mkt192'); ?>
            </span>
            <?php else : ?>
            <span class="checkin-badge checkin-badge-gray">
                <?php _e('Chưa kích hoạt', 'checkin-mkt192'); ?>
            </span>
            <?php endif; ?>
        </div>
    </div>

    <form id="form-onesignal-config" class="checkin-onesignal-form" style="display: none;">
        <div class="push-settings-section">
            <!-- Info Box -->
            <div class="checkin-alert checkin-alert-info" style="margin-bottom: 20px;">
                <span class="checkin-alert-icon">ℹ️</span>
                <div class="checkin-alert-content">
                    <div class="checkin-alert-title" style="font-weight: 600; margin-bottom: 8px;">
                        <?php _e('Hướng dẫn cấu hình OneSignal', 'checkin-mkt192'); ?>
                    </div>
                    <div class="checkin-alert-message" style="font-size: 13px;">
                        <ol style="margin: 0; padding-left: 20px;">
                            <li><?php _e('Đăng ký tài khoản tại <a href="https://onesignal.com" target="_blank">onesignal.com</a>', 'checkin-mkt192'); ?>
                            </li>
                            <li><?php _e('Tạo App mới và chọn "Web Push"', 'checkin-mkt192'); ?>
                            </li>
                            <li><?php _e('Cấu hình Site URL: <code>' . esc_html(home_url()) . '</code>', 'checkin-mkt192'); ?>
                            </li>
                            <li><?php _e('Copy App ID và REST API Key', 'checkin-mkt192'); ?>
                            </li>
                        </ol>
                    </div>
                </div>
            </div>

            <div class="checkin-form-grid" style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px;">
                <!-- App ID -->
                <div class="checkin-form-group">
                    <label class="checkin-form-label required">
                        <?php _e('OneSignal App ID', 'checkin-mkt192'); ?>
                    </label>
                    <input type="text" id="onesignal-app-id" name="checkin_onesignal_app_id"
                        value="<?php echo esc_attr($app_id); ?>" class="checkin-form-input"
                        placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx">
                    <p class="checkin-form-description">
                        <?php _e('App ID từ Settings > Keys & IDs', 'checkin-mkt192'); ?>
                    </p>
                </div>

                <!-- REST API Key -->
                <div class="checkin-form-group">
                    <label class="checkin-form-label required">
                        <?php _e('REST API Key', 'checkin-mkt192'); ?>
                    </label>
                    <div class="checkin-input-wrapper" style="position: relative;">
                        <input type="password" id="onesignal-api-key" name="checkin_onesignal_api_key"
                            value="<?php echo esc_attr($api_key); ?>" class="checkin-form-input"
                            placeholder="••••••••••••••••••••••••••••••••">
                        <button type="button" class="button checkin-toggle-password" data-target="onesignal-api-key"
                            style="position: absolute; right: 5px; top: 50%; transform: translateY(-50%);">
                            <span class="dashicons dashicons-visibility"></span>
                        </button>
                    </div>
                    <p class="checkin-form-description">
                        <?php _e('REST API Key (KHÔNG phải User Auth Key)', 'checkin-mkt192'); ?>
                    </p>
                </div>
            </div>

            <!-- Safari Web ID (Optional) -->
            <div class="checkin-form-group" style="margin-top: 10px;">
                <label class="checkin-form-label">
                    <?php _e('Safari Web ID (Tùy chọn)', 'checkin-mkt192'); ?>
                </label>
                <input type="text" id="onesignal-safari-web-id" name="checkin_onesignal_safari_web_id"
                    value="<?php echo esc_attr($safari_web_id); ?>" class="checkin-form-input" style="max-width: 500px;"
                    placeholder="web.onesignal.auto.xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx">
                <p class="checkin-form-description">
                    <?php _e('Chỉ cần nếu muốn hỗ trợ Safari trên macOS', 'checkin-mkt192'); ?>
                </p>
            </div>

            <!-- Warning -->
            <div class="checkin-alert checkin-alert-warning" style="margin-top: 20px;">
                <span class="checkin-alert-icon">⚠️</span>
                <div class="checkin-alert-content">
                    <div class="checkin-alert-message">
                        <?php _e('REST API Key rất quan trọng, không chia sẻ với ai. Website phải có HTTPS để Push Notifications hoạt động.', 'checkin-mkt192'); ?>
                    </div>
                </div>
            </div>

            <!-- Save Button -->
            <div class="checkin-form-actions" style="margin-top: 24px; display: flex; gap: 12px; align-items: center;">
                <button type="submit" class="checkin-button checkin-button-primary checkin-btn-save-config">
                    <span class="dashicons dashicons-saved"></span>
                    <?php _e('Lưu cấu hình', 'checkin-mkt192'); ?>
                </button>
                <button type="button" id="test-push-connection" class="checkin-button checkin-button-secondary">
                    <span class="dashicons dashicons-yes-alt"></span>
                    <?php _e('Gửi thông báo thử', 'checkin-mkt192'); ?>
                </button>
            </div>
        </div>
    </form>
</div>
<?php
    }

    /**
     * Render page header
     */
    private function render_page_header() {
        $push_enabled  = get_option('checkin_push_enabled', '0') === '1';
        $app_id        = get_option('checkin_onesignal_app_id', '');
        $api_key       = get_option('checkin_onesignal_api_key', '');
        $is_configured = !empty($app_id) && !empty($api_key);
        ?>
<div class="checkin-page-header">
    <div>
        <h1 class="checkin-page-title">
            <span class="dashicons dashicons-megaphone"></span>
            <?php _e('Cài đặt Push Notifications', 'checkin-mkt192'); ?>
        </h1>
        <p class="checkin-page-description">
            <?php _e('Cấu hình nội dung và đối tượng nhận cho từng loại thông báo', 'checkin-mkt192'); ?>
        </p>
    </div>
</div>
<?php
    }

    /**
     * Render notification grid by category
     */
    private function render_notification_grid() {
        $categories = [
            'booking'   => [
                'title' => __('Lịch hẹn', 'checkin-mkt192'),
                'icon'  => 'dashicons-calendar-alt',
                'color' => '#3b82f6',
            ],
            'invoice'   => [
                'title' => __('Hóa đơn', 'checkin-mkt192'),
                'icon'  => 'dashicons-money-alt',
                'color' => '#10b981',
            ],
            'attendance' => [
                'title' => __('Chấm công', 'checkin-mkt192'),
                'icon'  => 'dashicons-clock',
                'color' => '#0ea5e9',
            ],
            'review'    => [
                'title' => __('Đánh giá', 'checkin-mkt192'),
                'icon'  => 'dashicons-star-filled',
                'color' => '#f59e0b',
            ],
            'approval'  => [
                'title' => __('Duyệt đơn', 'checkin-mkt192'),
                'icon'  => 'dashicons-yes-alt',
                'color' => '#8b5cf6',
            ],
            'salary'    => [
                'title' => __('Lương', 'checkin-mkt192'),
                'icon'  => 'dashicons-money',
                'color' => '#ec4899',
            ],
            'inventory' => [
                'title' => __('Kho hàng', 'checkin-mkt192'),
                'icon'  => 'dashicons-products',
                'color' => '#6366f1',
            ],
        ];

        foreach ($categories as $cat_key => $category) {
            $this->render_category_section($cat_key, $category);
        }
    }

    /**
     * Render a category section with its notification types
     *
     * @param string $cat_key Category key
     * @param array $category Category config
     */
    private function render_category_section($cat_key, $category) {
        // Get notification types for this category
        $types = array_filter($this->notification_types, function($config) use ($cat_key) {
            return ($config['category'] ?? '') === $cat_key;
        });

        if (empty($types)) return;
        ?>
<div class="checkin-settings-section">
    <div class="checkin-section-header">
        <span class="dashicons <?php echo esc_attr($category['icon']); ?>"
            style="color: <?php echo esc_attr($category['color']); ?>"></span>
        <h2 class="checkin-section-title">
            <?php echo esc_html($category['title']); ?>
        </h2>
    </div>
    <div class="checkin-notification-grid">
        <?php foreach ($types as $type_key => $type_config) :
            $settings = $this->get_notification_settings($type_key);
        ?>
        <div class="checkin-notification-card <?php echo $settings['enabled'] ? 'enabled' : 'disabled'; ?>"
            data-type="<?php echo esc_attr($type_key); ?>">
            <div class="checkin-notification-header">
                <div class="checkin-notification-icon">
                    <?php echo $type_config['icon']; ?>
                </div>
                <div class="checkin-notification-info">
                    <h3 class="checkin-notification-name">
                        <?php echo esc_html($type_config['name']); ?>
                    </h3>
                    <p class="checkin-notification-desc">
                        <?php echo esc_html($type_config['description']); ?>
                    </p>
                </div>
                <div class="checkin-notification-toggle">
                    <label class="checkin-toggle">
                        <input type="checkbox" class="notification-enabled-toggle"
                            data-type="<?php echo esc_attr($type_key); ?>" <?php checked($settings['enabled']); ?>>
                        <span class="checkin-toggle-slider"></span>
                    </label>
                </div>
            </div>
            <div class="checkin-notification-body">
                <div class="checkin-notification-preview">
                    <div class="checkin-preview-title">
                        <?php echo esc_html($settings['title']); ?>
                    </div>
                    <div class="checkin-preview-body">
                        <?php echo nl2br(esc_html($settings['body'])); ?>
                    </div>
                </div>
                <div class="checkin-notification-roles">
                    <?php foreach ($settings['roles'] as $role) :
                        if (!isset($this->available_roles[$role])) continue;
                        $role_config = $this->available_roles[$role];
                    ?>
                    <span class="checkin-role-badge"
                        style="background-color: <?php echo esc_attr($role_config['color']); ?>15; color: <?php echo esc_attr($role_config['color']); ?>">
                        <?php echo esc_html($role_config['label']); ?>
                    </span>
                    <?php endforeach; ?>
                </div>
            </div>
            <div class="checkin-notification-footer">
                <button type="button" class="checkin-button checkin-button-sm checkin-button-secondary"
                    onclick="openNotificationModal('<?php echo esc_js($type_key); ?>')">
                    <span class="dashicons dashicons-edit"></span>
                    <?php _e('Chỉnh sửa', 'checkin-mkt192'); ?>
                </button>
                <button type="button" class="checkin-button checkin-button-sm checkin-button-ghost checkin-btn-test"
                    data-type="<?php echo esc_attr($type_key); ?>"
                    onclick="testNotification('<?php echo esc_js($type_key); ?>')">
                    <span class="dashicons dashicons-bell"></span>
                    <?php _e('Test', 'checkin-mkt192'); ?>
                </button>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php
    }

    /**
     * Render modals
     */
    private function render_modals() {
        $this->render_edit_notification_modal();
    }

    /**
     * Render edit notification modal
     */
    private function render_edit_notification_modal() {
        ?>
<div id="modal-edit-notification" class="checkin-modal-backdrop" style="display: none;">
    <div class="checkin-modal" style="max-width: 700px;">
        <div class="checkin-modal-header">
            <h2 class="checkin-modal-title">
                <span class="dashicons dashicons-megaphone" style="color: #3b82f6;"></span>
                <span id="modal-notification-name"><?php _e('Chỉnh sửa thông báo', 'checkin-mkt192'); ?></span>
            </h2>
            <button type="button" class="checkin-modal-close" onclick="closeNotificationModal()">
                <span class="dashicons dashicons-no-alt"></span>
            </button>
        </div>
        <form id="form-edit-notification" class="checkin-notification-form">
            <input type="hidden" id="edit-notification-type" name="notification_type" value="">

            <div class="checkin-modal-body">
                <!-- Status, Branch toggles and Roles in same row -->
                <div class="checkin-status-branch-row"
                    style="display: flex; flex-wrap: wrap; align-items: flex-start; gap: 24px;">
                    <!-- Enable toggle -->
                    <div class="checkin-form-group" style="margin-bottom: 0;">
                        <label class="checkin-form-label">
                            <span class="dashicons dashicons-visibility"></span>
                            <?php _e('Trạng thái', 'checkin-mkt192'); ?>
                        </label>
                        <div class="checkin-toggle-row">
                            <label class="checkin-toggle checkin-toggle-lg">
                                <input type="checkbox" id="edit-notification-enabled" name="enabled" value="1">
                                <span class="checkin-toggle-slider"></span>
                            </label>
                            <span class="checkin-toggle-label" id="edit-notification-status-label">
                                <?php _e('Đang bật', 'checkin-mkt192'); ?>
                            </span>
                        </div>
                    </div>

                    <!-- Include branch (same row) -->
                    <div class="checkin-form-group" id="edit-notification-branch-group"
                        style="display: none; margin-bottom: 0;">
                        <label class="checkin-form-label">
                            <span class="dashicons dashicons-store"></span>
                            <?php _e('Hiển thị chi nhánh', 'checkin-mkt192'); ?>
                        </label>
                        <div class="checkin-toggle-row">
                            <label class="checkin-toggle checkin-toggle-lg">
                                <input type="checkbox" id="edit-notification-include-branch" name="include_branch"
                                    value="1">
                                <span class="checkin-toggle-slider"></span>
                            </label>
                            <span class="checkin-toggle-label">
                                <?php _e('Chỉ bật khi có đa chi nhánh', 'checkin-mkt192'); ?>
                            </span>
                        </div>
                    </div>

                    <!-- Roles - Right aligned -->
                    <div class="checkin-form-group" style="margin-bottom: 0; margin-left: auto;">
                        <label class="checkin-form-label">
                            <span class="dashicons dashicons-groups"></span>
                            <?php _e('Vai trò nhận thông báo', 'checkin-mkt192'); ?>
                        </label>
                        <div class="checkin-roles-checkbox-group">
                            <?php foreach ($this->available_roles as $role_key => $role_config) :
                                // Convert hex color to rgba for light background
                                $hex      = ltrim($role_config['color'], '#');
                                $r        = hexdec(substr($hex, 0, 2));
                                $g        = hexdec(substr($hex, 2, 2));
                                $b        = hexdec(substr($hex, 4, 2));
                                $bg_color = "rgba({$r}, {$g}, {$b}, 0.12)";
                            ?>
                            <label class="checkin-role-checkbox">
                                <input type="checkbox" name="roles[]" value="<?php echo esc_attr($role_key); ?>">
                                <span class="checkin-role-checkbox-label"
                                    style="--role-color: <?php echo esc_attr($role_config['color']); ?>; --role-bg-color: <?php echo esc_attr($bg_color); ?>">
                                    <span class="dashicons <?php echo esc_attr($role_config['icon']); ?>"
                                        style="color: <?php echo esc_attr($role_config['color']); ?>"></span>
                                    <?php echo esc_html($role_config['label']); ?>
                                </span>
                            </label>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>

                <div class="checkin-divider"></div>

                <!-- Title -->
                <div class="checkin-form-group">
                    <label class="checkin-form-label" for="edit-notification-title">
                        <span class="dashicons dashicons-editor-bold"></span>
                        <?php _e('Tiêu đề thông báo', 'checkin-mkt192'); ?>
                    </label>
                    <input type="text" id="edit-notification-title" name="title" class="checkin-form-input"
                        placeholder="<?php esc_attr_e('Nhập tiêu đề...', 'checkin-mkt192'); ?>">
                    <p class="checkin-form-hint" id="edit-notification-title-hint"></p>
                </div>

                <!-- Body -->
                <div class="checkin-form-group">
                    <label class="checkin-form-label" for="edit-notification-body">
                        <span class="dashicons dashicons-editor-paragraph"></span>
                        <?php _e('Nội dung thông báo', 'checkin-mkt192'); ?>
                    </label>
                    <textarea id="edit-notification-body" name="body" class="checkin-form-textarea" rows="3"
                        placeholder="<?php esc_attr_e('Nhập nội dung...', 'checkin-mkt192'); ?>"></textarea>
                    <p class="checkin-form-hint" id="edit-notification-body-hint"></p>
                </div>

                <!-- Giờ gửi (chỉ loại thông báo chạy theo lịch) -->
                <div class="checkin-form-group" id="edit-notification-schedule-group" style="display: none;">
                    <label class="checkin-form-label" for="edit-notification-schedule">
                        <span class="dashicons dashicons-clock"></span>
                        <?php _e('Giờ gửi hằng ngày', 'checkin-mkt192'); ?>
                    </label>
                    <input type="time" id="edit-notification-schedule" name="schedule" class="checkin-form-input"
                        style="max-width: 160px;">
                    <p class="checkin-form-hint" id="edit-notification-schedule-hint"></p>
                </div>

                <!-- Bảng chỉ số trên card Lark (chỉ loại thông báo có khai báo default_stats) -->
                <div class="checkin-form-group" id="edit-notification-stats-group" style="display: none;">
                    <label class="checkin-form-label">
                        <span class="dashicons dashicons-grid-view"></span>
                        <span id="edit-notification-stats-label"><?php _e('Bảng chỉ số', 'checkin-mkt192'); ?></span>
                    </label>
                    <div class="checkin-stats-grid" id="edit-notification-stats"></div>
                    <p class="checkin-form-hint">
                        <?php _e('Mỗi ô một chỉ số, xếp 2 cột trên card Lark. Nhãn để trống thì ẩn ô đó. Giá trị dùng được mọi biến bên dưới.', 'checkin-mkt192'); ?>
                    </p>
                </div>

                <!-- Variables -->
                <div class="checkin-form-group">
                    <label class="checkin-form-label">
                        <span class="dashicons dashicons-editor-code"></span>
                        <?php _e('Biến có thể sử dụng', 'checkin-mkt192'); ?>
                    </label>
                    <div class="checkin-variables-list" id="edit-notification-variables"></div>
                    <p class="checkin-form-description" style="font-size: 12px; color: #6b7280; margin-top: 8px;">
                        <?php _e('Click vào biến để chèn vào tiêu đề hoặc nội dung', 'checkin-mkt192'); ?>
                    </p>
                </div>

                <!-- Preview -->
                <div class="checkin-form-group">
                    <label class="checkin-form-label">
                        <span class="dashicons dashicons-smartphone"></span>
                        <?php _e('Xem trước thông báo', 'checkin-mkt192'); ?>
                    </label>
                    <div class="checkin-notification-preview-box" id="notification-preview">
                        <div class="checkin-preview-header">
                            <span class="checkin-preview-app-icon">🔔</span>
                            <span class="checkin-preview-app-name"><?php echo esc_html(get_bloginfo('name')); ?></span>
                            <span class="checkin-preview-time"><?php _e('ngay bây giờ', 'checkin-mkt192'); ?></span>
                        </div>
                        <div class="checkin-preview-content">
                            <div class="checkin-preview-title-text" id="preview-title"></div>
                            <div class="checkin-preview-body-text" id="preview-body"></div>
                        </div>
                    </div>
                </div>

            </div>

            <div class="checkin-modal-footer">
                <button type="button" class="checkin-button checkin-button-secondary checkin-btn-reset"
                    onclick="resetNotificationSettings()">
                    <span class="dashicons dashicons-image-rotate"></span>
                    <?php _e('Khôi phục mặc định', 'checkin-mkt192'); ?>
                </button>
                <button type="button" class="checkin-button checkin-button-secondary checkin-btn-cancel"
                    onclick="closeNotificationModal()">
                    <?php _e('Hủy', 'checkin-mkt192'); ?>
                </button>
                <button type="submit" class="checkin-button checkin-button-primary checkin-btn-submit">
                    <span class="dashicons dashicons-saved"></span>
                    <?php _e('Lưu thay đổi', 'checkin-mkt192'); ?>
                </button>
            </div>
        </form>
    </div>
</div>
<?php
    }
}

// Don't auto-initialize - let admin menu handle it
?>
