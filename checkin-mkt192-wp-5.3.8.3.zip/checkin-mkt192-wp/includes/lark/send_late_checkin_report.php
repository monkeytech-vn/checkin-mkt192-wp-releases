<?php

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

require_once __DIR__ . '/lark-utils.php';
require_once __DIR__ . '/report-schedule.php';

/**
 * Báo cáo chấm công cuối ngày qua Lark: thợ đi trễ phải nộp heo, thợ chưa chấm công vào,
 * thợ quên chấm công ra. Chủ VG yêu cầu 18/09/2026.
 *
 * Nguồn: bảng checkinlogs (cột status_late / late_minutes / penalty_amount do API chấm công ghi lúc Clock In).
 * Đơn "Đi trễ/Về sớm" được duyệt sẽ đưa penalty_amount về 0, nên chỉ cần lọc penalty_amount > 0 là ra
 * đúng danh sách phải nộp heo, không cần dò lại bảng đơn từ.
 */
class Checkin_MKT192_LateCheckinReport {
    const HOOK              = 'daily_late_checkin_report';
    const NOTIFICATION_TYPE = 'late_checkin_report';
    const DEFAULT_TIME      = '23:00';
    // Chưa gán bot cho loại mới thì dùng bot nhắc nhở, rồi bot feedback
    const FALLBACK_TYPES    = ['missing_image_reminder', 'feedback'];

    private static function write_log($message, $data = []) {
        $log_file  = __DIR__ . '/logs/send_late_checkin_report.log';
        $log_entry = '[' . current_time('Y-m-d H:i:s') . "] $message\n";
        if (!empty($data)) {
            $log_entry .= 'Data: ' . json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE) . "\n";
        }
        $log_entry .= "----------------------------------------\n";
        @file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);
    }

    /** Đặt lịch theo giờ chủ site chọn (mặc định 23:00 giờ Việt Nam). */
    public static function ensure_scheduled() {
        checkin_mkt192_report_ensure_schedule(self::HOOK, self::NOTIFICATION_TYPE, self::DEFAULT_TIME);
    }

    /** Template ở Push Notifications; thiếu thì dùng mặc định. */
    public static function template() {
        $default = [
            'enabled'  => true,
            'title'    => '⏰ Chấm công cuối ngày · {date}',
            'body'     => '{late_count} thợ đi trễ · nộp heo {late_total}đ · {no_checkin_count} chưa chấm vào · {no_checkout_count} quên chấm ra',
            'roles'    => ['administrator'],
            'schedule' => self::DEFAULT_TIME,
            'stats'    => [
                ['label' => '⏰ Thợ đi trễ', 'value' => '{late_count}'],
                ['label' => '🐷 Tiền nộp heo', 'value' => '{late_total}đ'],
                ['label' => '📵 Chưa chấm công vào', 'value' => '{no_checkin_count}'],
                ['label' => '🚪 Quên chấm công ra', 'value' => '{no_checkout_count}'],
            ],
        ];
        if (!function_exists('checkin_push_get_notification_settings')) {
            return $default;
        }
        $tpl = (array)checkin_push_get_notification_settings(self::NOTIFICATION_TYPE);
        if (empty($tpl['title']) || $tpl['title'] === 'Thông báo') {
            $tpl['title'] = $default['title'];
        }
        foreach (['roles', 'stats', 'schedule'] as $key) {
            if (empty($tpl[$key])) {
                $tpl[$key] = $default[$key];
            }
        }
        return $tpl;
    }

    /**
     * Gom dữ liệu chấm công của một ngày.
     *
     * @param string $date Y-m-d theo giờ WordPress.
     * @return array {date, late: [...], no_checkin: [...], no_checkout: [...], late_total, on_duty}
     */
    public static function collect($date) {
        global $wpdb;
        $p = $wpdb->prefix;

        // Chỉ nói về vai trò bị áp phạt đi trễ (Cài đặt phạt → "Áp dụng cho vai trò"); rỗng = mọi vai trò.
        // Nhờ vậy quản lý / thu ngân không bị nêu tên khi salon không bắt họ chấm công.
        if (!function_exists('checkin_mkt192_penalty_applies_to')) {
            require_once dirname(__DIR__) . '/rest-api/penalty-api.php';
        }
        $applies = function ($role) {
            return !function_exists('checkin_mkt192_penalty_applies_to')
                || checkin_mkt192_penalty_applies_to($role);
        };

        $logs = $wpdb->get_results($wpdb->prepare(
            "SELECT display_name, employee_id, checkin_time, checkout_time, shift, status_late, late_minutes, penalty_amount, approval_late, employee_role
             FROM {$p}checkin_mkt192_checkinlogs
             WHERE DATE(checkin_time) = %s
             ORDER BY checkin_time ASC",
            $date
        )) ?: [];

        $late        = [];
        $no_checkout = [];
        $checked_in  = [];
        $late_total  = 0;

        foreach ($logs as $log) {
            $name               = trim((string)$log->display_name);
            $checked_in[$name]  = true;

            if (!$applies($log->employee_role)) {
                continue;
            }

            // Đi trễ phải nộp heo: đơn xin đi trễ được duyệt đã đưa penalty_amount về 0
            $amount = (float)$log->penalty_amount;
            if ((int)$log->status_late === 1 && $amount > 0) {
                $late[] = [
                    'name'    => $name,
                    'time'    => date('H:i', strtotime((string)$log->checkin_time)),
                    'minutes' => (int)$log->late_minutes,
                    'amount'  => $amount,
                    'shift'   => (string)$log->shift,
                ];
                $late_total += $amount;
            }

            if (empty($log->checkout_time)) {
                $no_checkout[] = [
                    'name'  => $name,
                    'time'  => date('H:i', strtotime((string)$log->checkin_time)),
                    'shift' => (string)$log->shift,
                ];
            }
        }

        // Chưa chấm công vào: thợ đang làm, không có log hôm nay, không có đơn nghỉ đã duyệt phủ ngày này
        $staff = $wpdb->get_results(
            "SELECT display_name, ou_id, user_role FROM {$p}checkin_mkt192_staff WHERE status = 'ON'"
        ) ?: [];

        $on_leave = $wpdb->get_col($wpdb->prepare(
            "SELECT staff_name FROM {$p}checkin_mkt192_approval_requests
             WHERE request_type = 'leave' AND status = 'approved'
               AND leave_start_date <= %s AND leave_end_date >= %s",
            $date,
            $date
        )) ?: [];
        $on_leave = array_map(function ($n) { return mb_strtolower(trim((string)$n)); }, $on_leave);

        $no_checkin = [];
        $ou_map     = [];
        foreach ($staff as $s) {
            $name           = trim((string)$s->display_name);
            $ou_map[$name]  = $s->ou_id ?: null;
            if (isset($checked_in[$name]) || in_array(mb_strtolower($name), $on_leave, true) || !$applies($s->user_role)) {
                continue;
            }
            $no_checkin[] = ['name' => $name];
        }

        // Gắn ou_id để @mention
        $attach_ou = function (array $rows) use ($ou_map) {
            foreach ($rows as $i => $row) {
                $rows[$i]['ou_id'] = $ou_map[$row['name']] ?? null;
            }
            return $rows;
        };
        $late        = $attach_ou($late);
        $no_checkout = $attach_ou($no_checkout);
        $no_checkin  = $attach_ou($no_checkin);

        $penalty = $wpdb->get_row("SELECT * FROM {$p}checkin_mkt192_penalty_settings WHERE id = 1", ARRAY_A) ?: [];

        return [
            'date'        => $date,
            'roles'       => function_exists('checkin_mkt192_penalty_apply_roles') ? checkin_mkt192_penalty_apply_roles() : [],
            'late'        => $late,
            'late_total'  => $late_total,
            'no_checkin'  => $no_checkin,
            'no_checkout' => $no_checkout,
            'on_duty'     => count($checked_in),
            'penalty'     => $penalty,
        ];
    }

    /** Biến cho template. */
    public static function template_vars($data) {
        $names = array_map(function ($r) { return $r['name']; }, $data['late']);
        $rule  = empty($data['penalty']['penalty_enabled'])
            ? 'đang tắt'
            : (!empty($data['penalty']['fine_by_time'])
                ? 'theo số phút trễ'
                : number_format((float)($data['penalty']['fine_amount'] ?? 0), 0, ',', '.') . ' đ/lần');

        return [
            'date'               => date('d/m/Y', strtotime($data['date'])),
            'late_count'         => (string)count($data['late']),
            'late_total'         => number_format((float)$data['late_total'], 0, ',', '.'),
            'no_checkin_count'   => (string)count($data['no_checkin']),
            'no_checkout_count'  => (string)count($data['no_checkout']),
            'on_duty_count'      => (string)$data['on_duty'],
            'penalty_rule'       => $rule,
            'late_list'          => $names ? implode(', ', $names) : 'không có',
        ];
    }

    public static function fill($tpl, $vars) {
        foreach ($vars as $k => $v) {
            $tpl = str_replace('{' . $k . '}', $v, $tpl);
        }
        return $tpl;
    }

    /** Bảng chỉ số của template sau khi thay biến. */
    public static function stats_for_card($tpl, $vars) {
        $out = [];
        foreach ((array)($tpl['stats'] ?? []) as $stat) {
            $label = self::fill((string)($stat['label'] ?? ''), $vars);
            $value = self::fill((string)($stat['value'] ?? ''), $vars);
            if (trim($label) === '' || trim($value) === '') {
                continue;
            }
            $out[] = ['label' => $label, 'value' => $value];
        }
        return $out;
    }

    /**
     * Gửi báo cáo chấm công ngày $date (mặc định hôm nay). Ngày sạch vẫn gửi card xanh.
     *
     * @return array {success, message}
     */
    public static function send_report($date = null) {
        // Không truyền ngày = cron chạy: lấy ngày theo giờ đã đặt, phòng khi hook nổ trễ sang hôm sau
        $date = is_string($date) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)
            ? $date
            : checkin_mkt192_report_target_date(self::NOTIFICATION_TYPE, self::DEFAULT_TIME);
        self::write_log("Bắt đầu báo cáo chấm công ngày $date");

        $tpl = self::template();
        if (empty($tpl['enabled'])) {
            self::write_log('Template đang tắt, bỏ qua');
            return ['success' => false, 'message' => 'Báo cáo đang tắt (Push Notifications)'];
        }

        if (!is_lark_enabled()) {
            self::write_log('Lark chưa được kích hoạt');
            return ['success' => false, 'message' => 'Lark chưa được kích hoạt'];
        }

        require_once __DIR__ . '/class-checkin-mkt192-message-bot-manager.php';
        require_once __DIR__ . '/card-builder.php';
        $bot_manager = Checkin_MKT192_Message_Bot_Manager::get_instance();

        $type = null;
        $bot  = null;
        foreach (array_merge([self::NOTIFICATION_TYPE], self::FALLBACK_TYPES) as $candidate) {
            $bot = $bot_manager->get_bot_by_notification_type($candidate);
            if ($bot) {
                $type = $candidate;
                break;
            }
        }
        if (!$bot) {
            $msg = 'Không có bot Lark nào gán cho ' . self::NOTIFICATION_TYPE;
            self::write_log($msg);
            return ['success' => false, 'message' => $msg];
        }

        $data  = self::collect($date);
        $vars  = self::template_vars($data);
        $title = self::fill((string)$tpl['title'], $vars);
        $body  = self::fill((string)$tpl['body'], $vars);

        self::write_log('Dữ liệu báo cáo', [
            'bot'         => $bot->bot_name,
            'late'        => count($data['late']),
            'no_checkin'  => count($data['no_checkin']),
            'no_checkout' => count($data['no_checkout']),
        ]);

        $card = build_late_checkin_report_card($data, $bot->bot_type, [
            'title'   => $title,
            'summary' => $body,
            'stats'   => self::stats_for_card($tpl, $vars),
        ]);

        $result = $bot_manager->send_message($type, null, ['msg_type' => 'interactive', 'card' => $card]);

        if (!empty($tpl['roles']) && function_exists('checkin_push_is_enabled') && checkin_push_is_enabled()
            && function_exists('checkin_push_get_users_by_roles') && function_exists('checkin_push_send_to_users')) {
            $user_ids = checkin_push_get_users_by_roles((array)$tpl['roles']);
            if ($user_ids) {
                checkin_push_send_to_users($user_ids, [
                    'title' => $title,
                    'body'  => $body,
                    'url'   => home_url('/'),
                    'data'  => ['type' => self::NOTIFICATION_TYPE, 'date' => $date],
                ]);
            }
        }

        if (is_wp_error($result)) {
            self::write_log('Lỗi gửi: ' . $result->get_error_message());
            return ['success' => false, 'message' => $result->get_error_message()];
        }
        if (isset($result['code']) && (int)$result['code'] !== 0) {
            self::write_log('Lark trả lỗi', $result);
            return ['success' => false, 'message' => 'Lark API error: ' . ($result['msg'] ?? 'unknown')];
        }

        self::write_log('Đã gửi báo cáo chấm công');
        return ['success' => true, 'message' => 'Đã gửi báo cáo chấm công ngày ' . $date];
    }
}
