<?php
/**
 * MonkeyPay - kết nối trực tiếp bằng API key (không cần plugin MonkeyPay).
 *
 * - Chủ salon tạo dự án, cổng thanh toán (tài khoản ngân hàng), API key trên website MonkeyPay
 *   rồi dán API key vào Checkin. Tiền tố, cú pháp nội dung CK, số tài khoản... luôn đọc từ server,
 *   sửa trên website là Checkin theo ngay.
 * - Nội dung chuyển khoản do server sinh theo tiền tố của cổng, nên giao dịch nào cũng khớp được.
 * - Một hoặc nhiều tài khoản: mỗi tài khoản chọn ngày dùng trong tuần (vd tài khoản riêng cho T7, CN);
 *   bật "nhiều tài khoản cùng lúc" thì lúc thanh toán thu ngân chọn tài khoản trước khi hiện QR.
 * - Xác nhận thanh toán: webhook có chữ ký (tức thì) + app tự hỏi trạng thái (dự phòng).
 * - Biến động số dư bắn thẻ Lark qua bot có loại thông báo "bank_transaction".
 *
 * @package Checkin_MKT192_WP
 * @since   5.3.9.0
 */

if (!defined('ABSPATH')) {
    exit;
}

const CHECKIN_MP_DEFAULT_URL   = 'https://monkeypay.monkeytech.vn';
const CHECKIN_MP_GATEWAY_TTL   = 300; // giây - cache danh sách cổng
const CHECKIN_MP_WEBHOOK_ROUTE = 'monkeypay/webhook';

// ═══════════════════════════════════════════════════════════════
// CẤU HÌNH
// ═══════════════════════════════════════════════════════════════

function checkin_mkt192_mp_encryption() {
    require_once dirname(__DIR__) . '/class-encryption.php';
}

/** URL server MonkeyPay (mặc định monkeypay.monkeytech.vn). */
function checkin_mkt192_mp_api_url() {
    $url = trim((string) get_option('checkin_mp_api_url', ''));
    return rtrim($url !== '' ? $url : CHECKIN_MP_DEFAULT_URL, '/');
}

/**
 * API key đang dùng. Chưa kết nối theo kiểu mới thì dùng tạm key cũ của plugin MonkeyPay
 * (option monkeypay_api_key) để site đang chạy không gãy trong lúc chuyển.
 */
function checkin_mkt192_mp_api_key() {
    $enc = get_option('checkin_mp_api_key', '');
    if ($enc !== '') {
        checkin_mkt192_mp_encryption();
        $key = Checkin_Encryption::decrypt($enc);
        if (is_string($key) && $key !== '') {
            return $key;
        }
    }
    $legacy = (string) get_option('monkeypay_api_key', '');
    return strpos($legacy, 'mpk_') === 0 ? $legacy : '';
}

/** Đã kết nối theo kiểu mới (key lưu trong Checkin)? */
function checkin_mkt192_mp_is_connected() {
    return get_option('checkin_mp_api_key', '') !== '';
}

/** Che key để hiển thị: mpk_1c…1109 */
function checkin_mkt192_mp_mask_key($key) {
    $key = (string) $key;
    if (strlen($key) <= 12) {
        return $key === '' ? '' : substr($key, 0, 4) . '…';
    }
    return substr($key, 0, 6) . '…' . substr($key, -4);
}

/**
 * Gọi server MonkeyPay bằng API key.
 *
 * @return array|WP_Error Body JSON đã decode; lỗi HTTP trả WP_Error kèm status.
 */
function checkin_mkt192_mp_request($path, $method = 'GET', $body = null, $timeout = 15, $api_key = null) {
    $api_key = $api_key ?? checkin_mkt192_mp_api_key();
    if ($api_key === '') {
        return new WP_Error('mp_no_key', 'Chưa kết nối MonkeyPay (thiếu API key).', ['status' => 400]);
    }

    $args = [
        'method'  => $method,
        'timeout' => $timeout,
        'headers' => [
            'Content-Type' => 'application/json',
            'Accept'       => 'application/json',
            'X-Api-Key'    => $api_key,
        ],
    ];
    if ($body !== null && $method !== 'GET') {
        $args['body'] = wp_json_encode($body);
    }

    $response = wp_remote_request(checkin_mkt192_mp_api_url() . $path, $args);
    if (is_wp_error($response)) {
        checkin_mkt192_mbbank_log('MP_REQUEST_ERROR', ['path' => $path, 'error' => $response->get_error_message()]);
        return new WP_Error('mp_unreachable', 'Không kết nối được máy chủ MonkeyPay: ' . $response->get_error_message(), ['status' => 503]);
    }

    $code = (int) wp_remote_retrieve_response_code($response);
    $data = json_decode(wp_remote_retrieve_body($response), true);
    if ($code < 200 || $code >= 300) {
        $message = is_array($data) ? ($data['message'] ?? $data['error'] ?? '') : '';
        checkin_mkt192_mbbank_log('MP_API_ERROR', ['path' => $path, 'code' => $code, 'message' => $message]);
        return new WP_Error('mp_api_error', $message !== '' ? $message : "MonkeyPay trả lỗi HTTP {$code}", ['status' => $code]);
    }
    return is_array($data) ? $data : [];
}

// ═══════════════════════════════════════════════════════════════
// NGÂN HÀNG (mã VietQR)
// ═══════════════════════════════════════════════════════════════

/**
 * Thông tin ngân hàng theo bank_code của cổng (server dùng cả "mbbank" lẫn "MB").
 *
 * @return array { short, name, bin, logo }
 */
function checkin_mkt192_mp_bank_info($code) {
    static $banks = [
        'MB'    => ['MB Bank', '970422', ['mbbank', 'mb', 'militarybank']],
        'VCB'   => ['Vietcombank', '970436', ['vietcombank', 'vcb']],
        'TCB'   => ['Techcombank', '970407', ['techcombank', 'tcb']],
        'ICB'   => ['VietinBank', '970415', ['vietinbank', 'icb', 'ctg']],
        'BIDV'  => ['BIDV', '970418', ['bidv']],
        'TPB'   => ['TPBank', '970423', ['tpbank', 'tpb']],
        'ACB'   => ['ACB', '970416', ['acb']],
        'VPB'   => ['VPBank', '970432', ['vpbank', 'vpb']],
        'STB'   => ['Sacombank', '970403', ['sacombank', 'stb']],
        'HDB'   => ['HDBank', '970437', ['hdbank', 'hdb']],
        'VIB'   => ['VIB', '970441', ['vib']],
        'OCB'   => ['OCB', '970448', ['ocb']],
        'SHB'   => ['SHB', '970443', ['shb']],
        'MSB'   => ['MSB', '970426', ['msb', 'maritimebank']],
        'SEAB'  => ['SeABank', '970440', ['seabank', 'seab']],
        'VBA'   => ['Agribank', '970405', ['agribank', 'vba']],
        'LPB'   => ['LPBank', '970449', ['lpbank', 'lpb', 'lienvietpostbank']],
        'EIB'   => ['Eximbank', '970431', ['eximbank', 'eib']],
        'NAB'   => ['Nam A Bank', '970428', ['namabank', 'nab']],
        'KLB'   => ['KienlongBank', '970452', ['kienlongbank', 'klb']],
        'VCCB'  => ['BVBank', '970454', ['bvbank', 'vccb', 'vietcapitalbank']],
        'PVCB'  => ['PVcomBank', '970412', ['pvcombank', 'pvcb']],
        'ABB'   => ['ABBANK', '970425', ['abbank', 'abb']],
        'BAB'   => ['Bac A Bank', '970409', ['bacabank', 'bab']],
        'VAB'   => ['VietABank', '970427', ['vietabank', 'vab']],
        'SCB'   => ['SCB', '970429', ['scb']],
        'SGICB' => ['Saigonbank', '970400', ['saigonbank', 'sgicb']],
        'NCB'   => ['NCB', '970419', ['ncb']],
        'CAKE'  => ['CAKE', '546034', ['cake']],
        'UBANK' => ['Ubank', '546035', ['ubank']],
        'TIMO'  => ['Timo', '963388', ['timo']],
    ];
    $needle = strtolower(preg_replace('/[^a-z0-9]/i', '', (string) $code));
    foreach ($banks as $short => [$name, $bin, $aliases]) {
        if ($needle === strtolower($short) || in_array($needle, $aliases, true)) {
            return ['short' => $short, 'name' => $name, 'bin' => $bin, 'logo' => "https://api.vietqr.io/img/{$short}.png"];
        }
    }
    // Không nhận ra mã: giữ MB như server đang mặc định, nhưng ghi rõ tên gốc
    return ['short' => strtoupper((string) $code), 'name' => (string) $code, 'bin' => '970422', 'logo' => ''];
}

// ═══════════════════════════════════════════════════════════════
// CỔNG THANH TOÁN (tài khoản) + LỊCH DÙNG
// ═══════════════════════════════════════════════════════════════

/**
 * Danh sách cổng từ server (cache 5 phút). Lỗi mạng thì dùng cache cũ, thử lại sau 60 giây.
 *
 * @return array[] Mỗi cổng: id, project_id, bank_code, bank_name, account_number, account_name,
 *                 note_prefix, note_syntax, auto_amount, polling_interval, enabled, status, label
 */
function checkin_mkt192_mp_gateways($force = false) {
    $cache = get_option('checkin_mp_gateways', []);
    $list  = is_array($cache['list'] ?? null) ? $cache['list'] : [];
    $age   = time() - (int) ($cache['at'] ?? 0);

    if (!$force && $age < CHECKIN_MP_GATEWAY_TTL) {
        return $list;
    }
    if (checkin_mkt192_mp_api_key() === '') {
        return $list;
    }

    $project_id = (int) get_option('checkin_mp_project_id', 0);
    $result     = checkin_mkt192_mp_request('/api/gateways' . ($project_id ? '?project_id=' . $project_id : ''), 'GET', null, $force ? 15 : 5);
    if (is_wp_error($result)) {
        // Giữ cache cũ, lùi lịch thử lại 60 giây để trang không chờ server mỗi lần tải
        update_option('checkin_mp_gateways', ['list' => $list, 'at' => time() - CHECKIN_MP_GATEWAY_TTL + 60, 'error' => $result->get_error_message()], false);
        return $list;
    }

    $fresh = [];
    foreach ((array) ($result['gateways'] ?? []) as $gw) {
        if (($gw['status'] ?? 'active') === 'rejected') {
            continue;
        }
        $fresh[] = [
            'id'               => (int) $gw['id'],
            'project_id'       => (int) ($gw['project_id'] ?? 0),
            'project_name'     => (string) ($gw['project_name'] ?? ''),
            'bank_code'        => (string) ($gw['bank_code'] ?? ''),
            'bank_name'        => (string) ($gw['bank_name'] ?? ''),
            'account_number'   => (string) ($gw['account_number'] ?? ''),
            'account_name'     => (string) ($gw['account_name'] ?? ''),
            'note_prefix'      => (string) ($gw['note_prefix'] ?? ''),
            'note_syntax'      => (string) ($gw['note_syntax'] ?? ''),
            'auto_amount'      => !empty($gw['auto_amount']),
            'polling_interval' => max(2, (int) ($gw['polling_interval'] ?? 5)),
            'enabled'          => !empty($gw['enabled']),
            'status'           => (string) ($gw['status'] ?? 'active'),
            'label'            => (string) ($gw['label'] ?? ''),
        ];
    }
    update_option('checkin_mp_gateways', ['list' => $fresh, 'at' => time(), 'error' => ''], false);
    return $fresh;
}

/**
 * Cài đặt từng tài khoản trong Checkin: bật/tắt, ngày dùng (ISO 1=T2 … 7=CN), tài khoản mặc định.
 *
 * @return array gateway_id => ['enabled' => bool, 'days' => int[], 'is_default' => bool, 'auto_amount' => ?bool]
 *               auto_amount: QR điền sẵn số tiền (null/thiếu = theo cài đặt cổng trên MonkeyPay, 5.3.9.3).
 */
function checkin_mkt192_mp_account_settings() {
    $raw = get_option('checkin_mp_accounts', []);
    return is_array($raw) ? $raw : [];
}

/**
 * Tài khoản dùng được để thu tiền, đã gộp cấu hình server + cài đặt Checkin, mặc định đứng đầu.
 * Cổng chưa có cài đặt riêng: tự bật nếu chỉ có một cổng, hoặc nếu đó là cổng đã chọn ở bản cũ.
 */
function checkin_mkt192_mp_accounts() {
    $settings = checkin_mkt192_mp_account_settings();
    $legacy   = (int) get_option('checkin_selected_gateway_id', 0);
    $gateways = array_values(array_filter(checkin_mkt192_mp_gateways(), function ($gw) {
        return $gw['enabled'] && $gw['status'] === 'active';
    }));

    $accounts = [];
    foreach ($gateways as $gw) {
        $conf = $settings[$gw['id']] ?? null;
        if ($conf === null) {
            $conf = [
                'enabled'    => count($gateways) === 1 || $gw['id'] === $legacy,
                'days'       => [1, 2, 3, 4, 5, 6, 7],
                'is_default' => count($gateways) === 1 || $gw['id'] === $legacy,
            ];
        }
        if (empty($conf['enabled'])) {
            continue;
        }
        $bank = checkin_mkt192_mp_bank_info($gw['bank_code']);
        $days = array_values(array_unique(array_map('intval', (array) ($conf['days'] ?? []))));
        $accounts[] = [
            'gateway_id'       => $gw['id'],
            'label'            => $gw['label'] !== '' ? $gw['label'] : $bank['name'] . ' ' . substr($gw['account_number'], -4),
            'bank_code'        => $gw['bank_code'],
            'bank_short'       => $bank['short'],
            'bank_name'        => $bank['name'],
            'bank_bin'         => $bank['bin'],
            'bank_logo'        => $bank['logo'],
            'account_number'   => $gw['account_number'],
            'account_name'     => $gw['account_name'],
            'note_prefix'      => $gw['note_prefix'],
            'note_syntax'      => $gw['note_syntax'],
            'auto_amount'      => checkin_mkt192_mp_effective_auto_amount($gw, $conf),
            'polling_interval' => $gw['polling_interval'],
            'days'             => $days ?: [1, 2, 3, 4, 5, 6, 7],
            'is_default'       => !empty($conf['is_default']),
        ];
    }
    usort($accounts, function ($a, $b) {
        return (int) $b['is_default'] - (int) $a['is_default'];
    });
    return $accounts;
}

/**
 * QR có điền sẵn số tiền không (5.3.9.3). MonkeyPay không tự dùng cờ này: Checkin quyết định gắn số
 * tiền vào QR và tạo giao dịch kiểu 'auto' (khớp nội dung + đúng số tiền) hay 'manual' (khách tự nhập
 * số tiền, chỉ khớp nội dung). Cài trong Checkin thắng; chưa cài thì theo cổng trên MonkeyPay.
 */
function checkin_mkt192_mp_effective_auto_amount($gw, $conf) {
    if (is_array($conf) && array_key_exists('auto_amount', $conf) && $conf['auto_amount'] !== null) {
        return (bool) $conf['auto_amount'];
    }
    return !empty($gw['auto_amount']);
}

/** Bật chế độ cho chọn nhiều tài khoản lúc thanh toán? */
function checkin_mkt192_mp_multi_account() {
    return get_option('checkin_mp_multi_account', '0') === '1';
}

/**
 * Tài khoản dùng hôm nay (theo ngày dùng). Không tài khoản nào hợp ngày thì rơi về toàn bộ
 * tài khoản đang bật - thà hiện QR mặc định còn hơn không thu được tiền.
 */
function checkin_mkt192_mp_accounts_for_today() {
    $accounts = checkin_mkt192_mp_accounts();
    $today    = (int) current_time('N');
    $matched  = array_values(array_filter($accounts, function ($a) use ($today) {
        return in_array($today, $a['days'], true);
    }));
    return $matched ?: $accounts;
}

/** Tìm tài khoản theo gateway_id; không truyền thì lấy tài khoản ưu tiên của hôm nay. */
function checkin_mkt192_mp_resolve_account($gateway_id = 0) {
    $gateway_id = (int) $gateway_id;
    if ($gateway_id) {
        foreach (checkin_mkt192_mp_accounts() as $account) {
            if ($account['gateway_id'] === $gateway_id) {
                return $account;
            }
        }
        return null;
    }
    $today = checkin_mkt192_mp_accounts_for_today();
    return $today[0] ?? null;
}

// ═══════════════════════════════════════════════════════════════
// GIAO DỊCH CHO HOÁ ĐƠN
// ═══════════════════════════════════════════════════════════════

/**
 * Tạo giao dịch MonkeyPay cho hoá đơn trên đúng cổng. Nội dung CK do server sinh theo tiền tố của cổng.
 *
 * @return array|WP_Error { tx_id, payment_note, status, matched_bank_tx }
 */
function checkin_mkt192_mp_create_tx($invoice, $account, $amount) {
    $customer = (string) ($invoice['customer_name'] ?? '');
    $result   = checkin_mkt192_mp_request('/api/transactions', 'POST', [
        'amount'      => (float) $amount,
        'gateway_id'  => (int) $account['gateway_id'],
        // QR có sẵn số tiền thì server khớp cả số tiền; khách tự nhập thì chỉ khớp nội dung,
        // Checkin tự kiểm số tiền khi nhận kết quả.
        'mode'        => $account['auto_amount'] ? 'auto' : 'manual',
        'description' => 'HĐ ' . $invoice['invoice_id'] . ($customer !== '' ? ' - ' . $customer : ''),
    ]);
    if (is_wp_error($result)) {
        return $result;
    }
    if (empty($result['tx_id']) || empty($result['payment_note'])) {
        return new WP_Error('mp_bad_response', 'MonkeyPay không trả về mã giao dịch.', ['status' => 502]);
    }

    global $wpdb;
    $wpdb->update(
        $wpdb->prefix . 'checkin_mkt192_invoices_data',
        [
            'payment_tx_id'      => $result['tx_id'],
            'payment_note'       => $result['payment_note'],
            'payment_gateway_id' => (int) $account['gateway_id'],
        ],
        ['invoice_id' => $invoice['invoice_id']]
    );
    set_transient('mp_txamt_' . $result['tx_id'], (float) $amount, 2 * DAY_IN_SECONDS);

    checkin_mkt192_mbbank_log('MP_TX_CREATED', [
        'invoice_id'   => $invoice['invoice_id'],
        'tx_id'        => $result['tx_id'],
        'payment_note' => $result['payment_note'],
        'gateway_id'   => (int) $account['gateway_id'],
        'amount'       => (float) $amount,
    ]);

    return [
        'tx_id'           => $result['tx_id'],
        'payment_note'    => $result['payment_note'],
        'status'          => $result['status'] ?? 'pending',
        'matched_bank_tx' => $result['matched_bank_tx'] ?? null,
    ];
}

/** Số tiền khách đã chuyển từ matched_bank_tx (server trả chuỗi JSON hoặc mảng). */
function checkin_mkt192_mp_matched_amount($matched) {
    if (is_string($matched)) {
        $matched = json_decode($matched, true);
    }
    return is_array($matched) ? (float) ($matched['amount'] ?? 0) : 0.0;
}

/**
 * Đánh dấu hoá đơn đã thanh toán chuyển khoản. Gọi nhiều lần vẫn an toàn (chỉ ghi khi chưa paid).
 * Khách chuyển thiếu thì KHÔNG tự chốt, để thu ngân xử lý.
 *
 * @return string 'paid' | 'already_paid' | 'underpaid' | 'not_found'
 */
function checkin_mkt192_mp_mark_paid($invoice_id, $tx_id, $paid_amount, $source) {
    global $wpdb;
    $table   = $wpdb->prefix . 'checkin_mkt192_invoices_data';
    $invoice = $wpdb->get_row($wpdb->prepare("SELECT invoice_id, total, status FROM {$table} WHERE invoice_id = %s", $invoice_id), ARRAY_A);
    if (!$invoice) {
        return 'not_found';
    }
    if ($invoice['status'] === 'paid') {
        return 'already_paid';
    }

    $total = (float) $invoice['total'];
    if ($paid_amount > 0 && $paid_amount + 1 < $total) {
        checkin_mkt192_mbbank_log('MP_UNDERPAID', ['invoice_id' => $invoice_id, 'tx_id' => $tx_id, 'paid' => $paid_amount, 'total' => $total, 'source' => $source]);
        return 'underpaid';
    }

    $now     = current_time('mysql');
    $updated = $wpdb->query($wpdb->prepare(
        "UPDATE {$table} SET status = 'paid', payment_method = 'bank', paid_at = %s, updated_at = %s, payment_tx_id = %s
         WHERE invoice_id = %s AND status <> 'paid'",
        $now, $now, $tx_id, $invoice_id
    ));
    if (!$updated) {
        return 'already_paid';
    }

    checkin_mkt192_mbbank_log('PAYMENT_CONFIRMED', ['invoice_id' => $invoice_id, 'tx_id' => $tx_id, 'paid' => $paid_amount, 'source' => $source]);
    if (function_exists('checkin_mkt192_push_payment_success')) {
        checkin_mkt192_push_payment_success($invoice_id);
    }
    return 'paid';
}

// ═══════════════════════════════════════════════════════════════
// WEBHOOK (server → Checkin)
// ═══════════════════════════════════════════════════════════════

function checkin_mkt192_mp_webhook_url() {
    return rest_url('vg/v1/' . CHECKIN_MP_WEBHOOK_ROUTE);
}

function checkin_mkt192_mp_webhook_secret() {
    $hook = get_option('checkin_mp_webhook', []);
    if (empty($hook['secret'])) {
        return '';
    }
    checkin_mkt192_mp_encryption();
    $secret = Checkin_Encryption::decrypt($hook['secret']);
    return is_string($secret) ? $secret : '';
}

/**
 * Đăng ký điểm nhận webhook của site này trên server (xoá bản cũ cùng URL để lấy secret mới).
 *
 * @return array|WP_Error { id, url }
 */
function checkin_mkt192_mp_register_webhook() {
    $url  = checkin_mkt192_mp_webhook_url();
    $list = checkin_mkt192_mp_request('/api/webhooks');
    if (is_wp_error($list)) {
        return $list;
    }
    foreach ((array) ($list['webhooks'] ?? []) as $hook) {
        if (untrailingslashit((string) $hook['url']) === untrailingslashit($url)) {
            checkin_mkt192_mp_request('/api/webhooks/' . (int) $hook['id'], 'DELETE');
        }
    }

    $project_id = (int) get_option('checkin_mp_project_id', 0);
    $created    = checkin_mkt192_mp_request('/api/webhooks', 'POST', [
        'url'        => $url,
        'label'      => 'Checkin ' . wp_parse_url(home_url(), PHP_URL_HOST),
        'events'     => 'payment_completed,bank_transaction',
        'format'     => 'monkeypay',
        'project_id' => $project_id ?: null,
    ]);
    if (is_wp_error($created)) {
        return $created;
    }
    if (empty($created['id']) || empty($created['secret'])) {
        return new WP_Error('mp_webhook_bad', 'Server không trả secret webhook.', ['status' => 502]);
    }

    checkin_mkt192_mp_encryption();
    update_option('checkin_mp_webhook', [
        'id'         => (int) $created['id'],
        'url'        => $url,
        'secret'     => Checkin_Encryption::encrypt($created['secret']),
        'created_at' => current_time('mysql'),
    ], false);
    return ['id' => (int) $created['id'], 'url' => $url];
}

/** POST /vg/v1/monkeypay/webhook - server MonkeyPay gọi, xác thực bằng chữ ký HMAC-SHA256. */
function checkin_mkt192_mp_webhook_handler(WP_REST_Request $request) {
    $secret = checkin_mkt192_mp_webhook_secret();
    if ($secret === '') {
        // Không có secret thì không nhận gì cả: webhook không ký là ai cũng giả được "đã thanh toán"
        return new WP_REST_Response(['error' => 'Webhook chưa được cấu hình'], 503);
    }

    $raw       = $request->get_body();
    $signature = (string) $request->get_header('x_monkeypay_signature');
    if ($signature === '' || !hash_equals(hash_hmac('sha256', $raw, $secret), $signature)) {
        checkin_mkt192_mbbank_log('MP_WEBHOOK_BAD_SIGNATURE', ['ip' => $_SERVER['REMOTE_ADDR'] ?? '']);
        return new WP_REST_Response(['error' => 'Chữ ký không hợp lệ'], 401);
    }

    $data  = json_decode($raw, true);
    $data  = is_array($data) ? $data : [];
    $event = (string) ($request->get_header('x_monkeypay_event') ?: ($data['event'] ?? ''));

    if (!empty($data['test']) || !empty($data['is_test'])) {
        update_option('checkin_mp_webhook_last', ['at' => current_time('mysql'), 'event' => $event, 'test' => true], false);
        return new WP_REST_Response(['received' => true, 'test' => true], 200);
    }

    // Server thử lại khi lỗi mạng: chặn xử lý trùng theo bdsd_id
    $dedupe = !empty($data['bdsd_id']) ? 'mp_bdsd_' . (int) $data['bdsd_id'] . '_' . $event : '';
    if ($dedupe !== '' && get_transient($dedupe)) {
        return new WP_REST_Response(['received' => true, 'duplicate' => true], 200);
    }
    if ($dedupe !== '') {
        set_transient($dedupe, 1, DAY_IN_SECONDS);
    }

    $result  = ['received' => true];
    $invoice = null;
    if ($event === 'payment_completed' && !empty($data['tx_id'])) {
        global $wpdb;
        $table   = $wpdb->prefix . 'checkin_mkt192_invoices_data';
        $invoice = $wpdb->get_row($wpdb->prepare(
            "SELECT invoice_id, total, customer_name, status FROM {$table} WHERE payment_tx_id = %s LIMIT 1",
            $data['tx_id']
        ), ARRAY_A);
        if ($invoice) {
            $result['invoice'] = checkin_mkt192_mp_mark_paid($invoice['invoice_id'], $data['tx_id'], (float) ($data['amount'] ?? 0), 'webhook');
        } else {
            $result['invoice'] = 'not_found';
        }
    }

    if (in_array($event, ['payment_completed', 'bank_transaction'], true)) {
        checkin_mkt192_mp_notify_bank_transaction($event, $data, $invoice, $result['invoice'] ?? null);
    }

    update_option('checkin_mp_webhook_last', ['at' => current_time('mysql'), 'event' => $event, 'test' => false], false);
    return new WP_REST_Response($result, 200);
}

/**
 * Thẻ Lark biến động số dư (thay "Lúa về..." của plugin MonkeyPay). Gửi qua bot có loại
 * thông báo bank_transaction; không có bot thì bỏ qua.
 */
function checkin_mkt192_mp_notify_bank_transaction($event, $data, $invoice = null, $invoice_result = null) {
    if (!class_exists('Checkin_MKT192_Message_Bot_Manager') || !function_exists('build_bank_transaction_card')) {
        return;
    }
    $manager = Checkin_MKT192_Message_Bot_Manager::get_instance();
    if (!$manager->get_bot_by_notification_type('bank_transaction')) {
        return;
    }
    $is_credit = $event === 'payment_completed' ? true : !empty($data['is_credit']);
    $card      = build_bank_transaction_card([
        'is_credit'      => $is_credit,
        'amount'         => (float) ($data['amount'] ?? 0),
        'account_number' => (string) ($data['account_number'] ?? ''),
        'bank_name'      => (string) ($data['bank_name'] ?? ''),
        'description'    => (string) ($data['description'] ?? ''),
        'payment_note'   => (string) ($data['payment_note'] ?? ''),
        'time'           => (string) ($data['transaction_date'] ?? $data['completed_at'] ?? ''),
        'invoice_id'     => $invoice['invoice_id'] ?? '',
        'customer_name'  => $invoice['customer_name'] ?? '',
        'invoice_result' => $invoice_result,
    ]);
    $manager->send_message('bank_transaction', '', $card);
}

// ═══════════════════════════════════════════════════════════════
// KẾT NỐI / NGẮT / NHẬP CẤU HÌNH CŨ
// ═══════════════════════════════════════════════════════════════

/**
 * Kết nối bằng API key: kiểm key, lưu, tải dự án + cổng, đăng ký webhook.
 *
 * @return array|WP_Error Trạng thái sau khi kết nối
 */
function checkin_mkt192_mp_connect($api_key, $api_url = '') {
    $api_key = trim((string) $api_key);
    // Chỉ nhận khoá đơn mpk_; khoá cặp mpa_ cần thêm secret nên không dùng cho site WordPress
    if (!preg_match('/^mpk_[A-Za-z0-9]{16,}$/', $api_key)) {
        return new WP_Error('mp_bad_key', 'API key không đúng định dạng: cần khoá đơn bắt đầu bằng mpk_ (tạo ở MonkeyPay → API key).', ['status' => 400]);
    }
    if ($api_url !== '') {
        $api_url = esc_url_raw(trim($api_url));
        if (!preg_match('#^https://#', $api_url)) {
            return new WP_Error('mp_bad_url', 'Địa chỉ máy chủ phải là https://', ['status' => 400]);
        }
        update_option('checkin_mp_api_url', untrailingslashit($api_url), false);
    }

    $me = checkin_mkt192_mp_request('/api/me', 'GET', null, 15, $api_key);
    if (is_wp_error($me)) {
        return new WP_Error('mp_connect_failed', 'Không kết nối được bằng API key này: ' . $me->get_error_message(), ['status' => 400]);
    }

    checkin_mkt192_mp_encryption();
    update_option('checkin_mp_api_key', Checkin_Encryption::encrypt($api_key), false);
    update_option('checkin_mp_key_hint', checkin_mkt192_mp_mask_key($api_key), false);
    $merchant = $me['merchant'] ?? [];
    update_option('checkin_mp_merchant', [
        'name'  => (string) ($merchant['name'] ?? ''),
        'email' => (string) ($merchant['email'] ?? ''),
        'plan'  => (string) ($me['plan']['name'] ?? ''),
    ], false);

    // Khoá gắn dự án thì dùng luôn dự án đó; khoá toàn merchant có một dự án thì chọn dự án đó
    $scoped = (int) ($me['usage']['scoped_project_id'] ?? 0);
    if ($scoped) {
        update_option('checkin_mp_project_id', $scoped, false);
    } else {
        $projects = checkin_mkt192_mp_request('/api/projects');
        $list     = is_wp_error($projects) ? [] : (array) ($projects['projects'] ?? []);
        $current  = (int) get_option('checkin_mp_project_id', 0);
        $ids      = array_map(function ($p) { return (int) $p['id']; }, $list);
        if (count($list) === 1) {
            update_option('checkin_mp_project_id', (int) $list[0]['id'], false);
        } elseif (!in_array($current, $ids, true)) {
            update_option('checkin_mp_project_id', 0, false);
        }
    }

    checkin_mkt192_mp_gateways(true);
    $hook = checkin_mkt192_mp_register_webhook();
    update_option('checkin_bank_auto_mode', '1');
    update_option('checkin_use_bank_transfer', '1');

    $state = checkin_mkt192_mp_state();
    if (is_wp_error($hook)) {
        $state['webhook_error'] = $hook->get_error_message();
    }
    return $state;
}

/** Ngắt kết nối: gỡ webhook trên server, xoá key. Lịch sử giao dịch trong hoá đơn giữ nguyên. */
function checkin_mkt192_mp_disconnect() {
    $hook = get_option('checkin_mp_webhook', []);
    if (!empty($hook['id']) && checkin_mkt192_mp_api_key() !== '') {
        checkin_mkt192_mp_request('/api/webhooks/' . (int) $hook['id'], 'DELETE');
    }
    foreach (['checkin_mp_api_key', 'checkin_mp_key_hint', 'checkin_mp_webhook', 'checkin_mp_merchant', 'checkin_mp_gateways', 'checkin_mp_webhook_last'] as $option) {
        delete_option($option);
    }
    // Không rơi về key của plugin cũ sau khi chủ site đã chủ động ngắt
    update_option('checkin_bank_auto_mode', '0');
    return checkin_mkt192_mp_state();
}

/** Trạng thái đầy đủ cho trang cài đặt. */
function checkin_mkt192_mp_state() {
    $connected = checkin_mkt192_mp_is_connected();
    $legacy    = !$connected && checkin_mkt192_mp_api_key() !== '';
    $settings  = checkin_mkt192_mp_account_settings();
    $gateways  = ($connected || $legacy) ? checkin_mkt192_mp_gateways() : [];
    $cache     = get_option('checkin_mp_gateways', []);
    $hook      = get_option('checkin_mp_webhook', []);
    $accounts  = array_column(checkin_mkt192_mp_accounts(), null, 'gateway_id');

    $rows = [];
    foreach ($gateways as $gw) {
        $bank = checkin_mkt192_mp_bank_info($gw['bank_code']);
        $conf = $settings[$gw['id']] ?? null;
        $rows[] = array_merge($gw, [
            'bank_short' => $bank['short'],
            'bank_label' => $bank['name'],
            'bank_bin'   => $bank['bin'],
            'bank_logo'  => $bank['logo'],
            'use'        => isset($accounts[$gw['id']]),
            'days'       => isset($accounts[$gw['id']]) ? $accounts[$gw['id']]['days'] : array_map('intval', (array) ($conf['days'] ?? [1, 2, 3, 4, 5, 6, 7])),
            'is_default' => isset($accounts[$gw['id']]) && $accounts[$gw['id']]['is_default'],
            'usable'     => $gw['enabled'] && $gw['status'] === 'active',
            // auto_amount = giá trị đang áp dụng; auto_amount_server = cài trên MonkeyPay (mặc định)
            'auto_amount'        => checkin_mkt192_mp_effective_auto_amount($gw, $conf),
            'auto_amount_server' => !empty($gw['auto_amount']),
        ]);
    }

    $projects = [];
    if ($connected) {
        $res = checkin_mkt192_mp_request('/api/projects', 'GET', null, 8);
        if (!is_wp_error($res)) {
            foreach ((array) ($res['projects'] ?? []) as $p) {
                $projects[] = ['id' => (int) $p['id'], 'name' => (string) $p['name']];
            }
        }
    }

    return [
        'connected'      => $connected,
        'legacy'         => $legacy,
        'api_url'        => checkin_mkt192_mp_api_url(),
        'key_hint'       => $connected ? get_option('checkin_mp_key_hint', '') : ($legacy ? checkin_mkt192_mp_mask_key(checkin_mkt192_mp_api_key()) : ''),
        'merchant'       => get_option('checkin_mp_merchant', []),
        'projects'       => $projects,
        'project_id'     => (int) get_option('checkin_mp_project_id', 0),
        'gateways'       => $rows,
        'gateways_error' => (string) ($cache['error'] ?? ''),
        'multi_account'  => checkin_mkt192_mp_multi_account(),
        'webhook'        => [
            'registered' => !empty($hook['id']),
            'url'        => checkin_mkt192_mp_webhook_url(),
            'last'       => get_option('checkin_mp_webhook_last', null),
        ],
        'bank_bot'       => class_exists('Checkin_MKT192_Message_Bot_Manager')
            && (bool) Checkin_MKT192_Message_Bot_Manager::get_instance()->get_bot_by_notification_type('bank_transaction'),
        'legacy_plugin'  => defined('MONKEYPAY_VERSION') || class_exists('MonkeyPay_Settings'),
    ];
}

/**
 * Chuyển thẻ Lark "biến động số dư" từ plugin MonkeyPay sang bot của Checkin (chạy một lần).
 * Plugin cũ lưu trong option monkeypay_webhook_connections hoặc bảng {prefix}monkeypay_connections.
 *
 * @return int Số bot đã tạo
 */
function checkin_mkt192_mp_import_lark_connections() {
    if (!class_exists('Checkin_MKT192_Message_Bot_Manager')) {
        return 0;
    }
    global $wpdb;
    $conns = [];
    foreach ((array) get_option('monkeypay_webhook_connections', []) as $c) {
        $conns[] = (array) $c;
    }
    $table = $wpdb->prefix . 'monkeypay_connections';
    if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table)) === $table) {
        foreach ((array) $wpdb->get_results("SELECT * FROM {$table}", ARRAY_A) as $row) {
            $conns[] = $row;
        }
    }

    $manager  = Checkin_MKT192_Message_Bot_Manager::get_instance();
    $existing = array_map(function ($bot) { return untrailingslashit((string) $bot->webhook_url); }, $manager->get_all_bots());
    $created  = 0;
    foreach ($conns as $c) {
        $url = untrailingslashit((string) ($c['webhook_url'] ?? ''));
        if (($c['platform'] ?? '') !== 'lark' || $url === '' || in_array($url, $existing, true)) {
            continue;
        }
        if (isset($c['enabled']) && !$c['enabled']) {
            continue;
        }
        $id = $manager->create_bot([
            'bot_name'           => 'Biến động số dư - ' . ($c['name'] ?? 'MonkeyPay'),
            'bot_type'           => 'webhook',
            'notification_types' => ['bank_transaction'],
            'webhook_url'        => $url,
            'is_active'          => 1,
        ]);
        if (!is_wp_error($id)) {
            $existing[] = $url;
            $created++;
        }
    }
    return $created;
}

// ═══════════════════════════════════════════════════════════════
// REST ROUTES (trang cài đặt + webhook)
// ═══════════════════════════════════════════════════════════════

add_action('rest_api_init', function () {
    $admin = function () {
        return current_user_can('manage_options');
    };

    register_rest_route('vg/v1', '/monkeypay/state', [
        'methods'             => 'GET',
        'callback'            => function () {
            return new WP_REST_Response(['success' => true, 'data' => checkin_mkt192_mp_state()], 200);
        },
        'permission_callback' => $admin,
    ]);

    register_rest_route('vg/v1', '/monkeypay/connect', [
        'methods'             => 'POST',
        'callback'            => function (WP_REST_Request $request) {
            $result = checkin_mkt192_mp_connect((string) $request->get_param('api_key'), (string) $request->get_param('api_url'));
            if (is_wp_error($result)) {
                return new WP_REST_Response(['success' => false, 'message' => $result->get_error_message()], 400);
            }
            $imported = checkin_mkt192_mp_import_lark_connections();
            return new WP_REST_Response(['success' => true, 'data' => $result, 'imported_bots' => $imported], 200);
        },
        'permission_callback' => $admin,
    ]);

    register_rest_route('vg/v1', '/monkeypay/sync', [
        'methods'             => 'POST',
        'callback'            => function () {
            checkin_mkt192_mp_gateways(true);
            return new WP_REST_Response(['success' => true, 'data' => checkin_mkt192_mp_state()], 200);
        },
        'permission_callback' => $admin,
    ]);

    register_rest_route('vg/v1', '/monkeypay/settings', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_mp_save_settings',
        'permission_callback' => $admin,
    ]);

    register_rest_route('vg/v1', '/monkeypay/webhook-register', [
        'methods'             => 'POST',
        'callback'            => function () {
            $hook = checkin_mkt192_mp_register_webhook();
            if (is_wp_error($hook)) {
                return new WP_REST_Response(['success' => false, 'message' => $hook->get_error_message()], 400);
            }
            return new WP_REST_Response(['success' => true, 'data' => checkin_mkt192_mp_state()], 200);
        },
        'permission_callback' => $admin,
    ]);

    register_rest_route('vg/v1', '/monkeypay/webhook-test', [
        'methods'             => 'POST',
        'callback'            => function () {
            $hook = get_option('checkin_mp_webhook', []);
            if (empty($hook['id'])) {
                return new WP_REST_Response(['success' => false, 'message' => 'Chưa đăng ký webhook.'], 400);
            }
            $res = checkin_mkt192_mp_request('/api/webhooks/' . (int) $hook['id'] . '/test', 'POST', []);
            if (is_wp_error($res)) {
                return new WP_REST_Response(['success' => false, 'message' => $res->get_error_message()], 400);
            }
            $ok = !empty($res['success']);
            $message = $ok
                ? 'Máy chủ MonkeyPay đã gửi thử và site nhận được (' . (int) ($res['duration_ms'] ?? 0) . ' ms).'
                : 'Máy chủ gửi thử nhưng site chưa nhận được: HTTP ' . ($res['status_code'] ?? '?') . ' ' . ($res['error'] ?? '');
            return new WP_REST_Response(['success' => $ok, 'data' => $res, 'message' => $message], 200);
        },
        'permission_callback' => $admin,
    ]);

    register_rest_route('vg/v1', '/monkeypay/disconnect', [
        'methods'             => 'POST',
        'callback'            => function () {
            return new WP_REST_Response(['success' => true, 'data' => checkin_mkt192_mp_disconnect()], 200);
        },
        'permission_callback' => $admin,
    ]);

    register_rest_route('vg/v1', '/' . CHECKIN_MP_WEBHOOK_ROUTE, [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_mp_webhook_handler',
        'permission_callback' => '__return_true', // xác thực bằng chữ ký HMAC trong handler
    ]);
});

/** POST /vg/v1/monkeypay/settings { project_id, multi_account, accounts: [{gateway_id, use, days, is_default}] } */
function checkin_mkt192_mp_save_settings(WP_REST_Request $request) {
    $project_changed = false;
    if ($request->has_param('project_id')) {
        $project_id      = absint($request->get_param('project_id'));
        $project_changed = $project_id !== (int) get_option('checkin_mp_project_id', 0);
        update_option('checkin_mp_project_id', $project_id, false);
    }
    if ($request->has_param('multi_account')) {
        update_option('checkin_mp_multi_account', rest_sanitize_boolean($request->get_param('multi_account')) ? '1' : '0', false);
    }

    $accounts = $request->get_param('accounts');
    if (is_array($accounts)) {
        $settings    = [];
        $has_default = false;
        foreach ($accounts as $row) {
            $id = absint($row['gateway_id'] ?? 0);
            if (!$id) {
                continue;
            }
            $days = array_values(array_intersect([1, 2, 3, 4, 5, 6, 7], array_map('intval', (array) ($row['days'] ?? []))));
            $use  = rest_sanitize_boolean($row['use'] ?? false);
            $def  = $use && !$has_default && rest_sanitize_boolean($row['is_default'] ?? false);
            $has_default = $has_default || $def;
            $settings[$id] = ['enabled' => $use, 'days' => $days ?: [1, 2, 3, 4, 5, 6, 7], 'is_default' => $def];
            if (array_key_exists('auto_amount', (array) $row) && $row['auto_amount'] !== null) {
                $settings[$id]['auto_amount'] = rest_sanitize_boolean($row['auto_amount']);
            }
        }
        // Luôn có đúng một tài khoản mặc định trong các tài khoản đang dùng
        if (!$has_default) {
            foreach ($settings as $id => $conf) {
                if ($conf['enabled']) {
                    $settings[$id]['is_default'] = true;
                    break;
                }
            }
        }
        if (!array_filter($settings, function ($c) { return $c['enabled']; })) {
            return new WP_REST_Response(['success' => false, 'message' => 'Phải bật ít nhất một tài khoản nhận tiền.'], 400);
        }
        update_option('checkin_mp_accounts', $settings, false);
    }

    if ($project_changed) {
        checkin_mkt192_mp_gateways(true);
        if (checkin_mkt192_mp_is_connected()) {
            checkin_mkt192_mp_register_webhook();
        }
    }
    return new WP_REST_Response(['success' => true, 'data' => checkin_mkt192_mp_state()], 200);
}
