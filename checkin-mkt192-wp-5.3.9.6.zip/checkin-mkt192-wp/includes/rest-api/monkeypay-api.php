<?php
/**
 * MBBank API Integration
 *
 * Kết nối với MBBank Docker service để xác nhận thanh toán tự động.
 * - Kiểm tra trạng thái kết nối service
 * - Lấy lịch sử giao dịch và match với hóa đơn
 * - Cron job tự động polling
 *
 * @package    Checkin_MKT192_WP
 * @subpackage REST_API
 * @since      5.2.0
 */

// ═══════════════════════════════════════════════════════════════
// REST API ROUTES
// ═══════════════════════════════════════════════════════════════

add_action('rest_api_init', function () {

    // Kiểm tra trạng thái kết nối MBBank service
    register_rest_route('vg/v1', '/mbbank-status', [
        'methods'             => 'GET',
        'callback'            => 'checkin_mkt192_mbbank_status',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'payment.read']),
    ]);

    // Kiểm tra thanh toán cho 1 hóa đơn cụ thể
    // Ai thu tiền được hoá đơn (thu ngân, thợ) đều phải tạo được mã chuyển khoản. Trước 5.3.9.0 route này
    // chỉ nhận payment.process (vai Quản Lý) nên thu ngân/thợ bị 403, app tự sinh mã mà server không biết,
    // giao dịch không bao giờ khớp tự động.
    // Màn khách tại quầy (máy tính bảng) chạy KHÔNG đăng nhập: trước 5.3.9.2 nó bị 401, tự sinh mã
    // tại máy mà server không biết, nên khách quét xong vẫn phải bấm xác nhận tay (VG 16/10/2026).
    // Nay cho phép thêm đúng hoá đơn đang chờ ở quầy, xem checkin_mkt192_mp_kiosk_invoice_allowed().
    $staff_can_charge = checkin_mkt192_permission([
        'mode'  => 'login',
        'scope' => ['payment.process', 'invoice.add', 'invoice.edit'],
        'logic' => 'OR',
    ]);
    register_rest_route('vg/v1', '/mbbank-check-payment', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_mbbank_check_payment',
        'permission_callback' => function (WP_REST_Request $request) use ($staff_can_charge) {
            $staff = $staff_can_charge($request);
            if ($staff === true) return true;
            return checkin_mkt192_mp_kiosk_invoice_allowed($request) ? true : $staff;
        },
        'args'                => [
            'invoice_id' => [
                'required'          => true,
                'type'              => 'string',
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'gateway_id' => [
                'required'          => false,
                'type'              => 'integer',
                'sanitize_callback' => 'absint',
            ],
            // init: mở QR (tạo hoặc dùng lại giao dịch) · poll: chỉ hỏi trạng thái, không tạo mới
            'action'     => [
                'required'          => false,
                'type'              => 'string',
                'sanitize_callback' => 'sanitize_key',
            ],
        ],
    ]);

    // Lấy lịch sử giao dịch (proxy)
    register_rest_route('vg/v1', '/mbbank-transactions', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_mbbank_transactions',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'payment.read']),
    ]);

    // Test đăng nhập MB Bank (kiểm tra credentials)
    register_rest_route('vg/v1', '/mbbank-test-login', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_mbbank_test_login',
        'permission_callback' => function () {
            return current_user_can('manage_options');
        },
    ]);

    // ── MonkeyPay Registration / Login / Disconnect ──
    // Đã chuyển sang MonkeyPay plugin (SoC). Checkin chỉ đọc qua bridge REST.

    // Đối soát hóa đơn batch — MonkeyPay only
    register_rest_route('vg/v1', '/reconcile-invoices', [
        'methods'             => 'POST',
        'callback'            => 'checkin_mkt192_reconcile_invoices',
        'permission_callback' => checkin_mkt192_permission(['mode' => 'login', 'scope' => 'payment.process']),
        'args'                => [
            'from_date' => [
                'required'          => true,
                'type'              => 'string',
                'description'       => 'Ngày bắt đầu (YYYY-MM-DD)',
                'sanitize_callback' => 'sanitize_text_field',
            ],
            'to_date' => [
                'required'          => true,
                'type'              => 'string',
                'description'       => 'Ngày kết thúc (YYYY-MM-DD)',
                'sanitize_callback' => 'sanitize_text_field',
            ],
        ],
    ]);

});

// ═══════════════════════════════════════════════════════════════
// HELPER FUNCTIONS
// ═══════════════════════════════════════════════════════════════

/**
 * Lấy MB Bank credentials (giải mã)
 *
 * @return array { username, password, account_number }
 */
function checkin_mkt192_mbbank_get_credentials() {
    require_once plugin_dir_path( __FILE__ ) . '../class-encryption.php';

    $username_enc = get_option('checkin_mbbank_username', '');
    $password_enc = get_option('checkin_mbbank_password', '');
    $account_number = get_option('checkin_bank_account_number', '');

    return [
        'mb_username'       => ! empty( $username_enc ) ? Checkin_Encryption::decrypt( $username_enc ) : '',
        'mb_password'       => ! empty( $password_enc ) ? Checkin_Encryption::decrypt( $password_enc ) : '',
        'mb_account_number' => $account_number,
    ];
}

/**
 * Kiểm tra xem đang dùng MonkeyPay hay mbbank trực tiếp
 *
 * @return bool true nếu đang dùng MonkeyPay
 */
function checkin_mkt192_is_monkeypay_mode() {
    return checkin_mkt192_mp_api_key() !== '';
}

/**
 * Gọi API đến payment service (MonkeyPay hoặc MBBank trực tiếp)
 *
 * - Nếu có monkeypay_api_key → dùng MonkeyPay server (X-Api-Key header, KHÔNG inject MB credentials)
 * - Nếu không → fallback về MBBank Docker cũ (Bearer token + inject credentials)
 *
 * @param string $endpoint  Endpoint (VD: /api/health)
 * @param string $method    HTTP method
 * @param array  $body      Extra request body (for POST)
 * @return array|WP_Error
 */
function checkin_mkt192_mbbank_request($endpoint, $method = 'GET', $body = []) {
    $use_monkeypay = checkin_mkt192_is_monkeypay_mode();

    if ( $use_monkeypay ) {
        // ── MonkeyPay mode ──────────────────────────────
        $service_url = checkin_mkt192_mp_api_url();
        $api_key     = checkin_mkt192_mp_api_key();

        $url = rtrim($service_url, '/') . $endpoint;

        $args = [
            'method'  => $method,
            'timeout' => 30,
            'headers' => [
                'Content-Type' => 'application/json',
                'X-Api-Key'    => $api_key,
            ],
        ];

        // MonkeyPay quản lý session riêng — KHÔNG inject MB credentials
        if ($method === 'POST' && ! empty($body)) {
            $args['body'] = json_encode($body);
        }
    } else {
        // ── Legacy MBBank mode ──────────────────────────
        $service_url    = get_option('checkin_mbbank_service_url', 'http://mbbank:3456');
        $api_secret_enc = get_option('checkin_mbbank_api_secret', '');
        require_once plugin_dir_path( __FILE__ ) . '../class-encryption.php';
        $api_secret = ! empty( $api_secret_enc ) ? Checkin_Encryption::decrypt( $api_secret_enc ) : '';

        $url = rtrim($service_url, '/') . $endpoint;

        $args = [
            'method'  => $method,
            'timeout' => 30,
            'headers' => [
                'Content-Type'  => 'application/json',
                'Authorization' => 'Bearer ' . $api_secret,
            ],
        ];

        if ($method === 'POST') {
            // Inject MB credentials into body (legacy mode)
            $credentials = checkin_mkt192_mbbank_get_credentials();
            $body = array_merge($credentials, $body);
            $args['body'] = json_encode($body);
        }
    }

    $response = ($method === 'GET') ? wp_remote_get($url, $args) : wp_remote_post($url, $args);

    if (is_wp_error($response)) {
        checkin_mkt192_mbbank_log('REQUEST_ERROR', [
            'endpoint' => $endpoint,
            'mode'     => $use_monkeypay ? 'monkeypay' : 'mbbank',
            'error'    => $response->get_error_message(),
        ]);
        return $response;
    }

    $resp_body = json_decode(wp_remote_retrieve_body($response), true);
    $code      = wp_remote_retrieve_response_code($response);

    if ($code !== 200 && $code !== 201) {
        checkin_mkt192_mbbank_log('API_ERROR', [
            'endpoint' => $endpoint,
            'mode'     => $use_monkeypay ? 'monkeypay' : 'mbbank',
            'code'     => $code,
            'body'     => $resp_body,
        ]);
        return new WP_Error('mbbank_api_error', $resp_body['message'] ?? $resp_body['error'] ?? 'Lỗi không xác định', ['status' => $code]);
    }

    return $resp_body;
}

/**
 * Sinh mã ghi chú thanh toán theo cú pháp đã cấu hình
 *
 * @param int    $invoice_id     ID hóa đơn
 * @param string $customer_name  Tên khách hàng
 * @param string $invoice_date   Ngày hóa đơn (MySQL datetime)
 * @return string Mã ghi chú
 */
function checkin_mkt192_generate_payment_note($invoice_id, $customer_name = '', $invoice_date = '') {
    $prefix = get_option('checkin_monkeypay_note_prefix', get_option('checkin_mbbank_note_prefix', 'MKT'));
    $syntax = get_option('checkin_monkeypay_note_syntax', get_option('checkin_mbbank_note_syntax', '{invoice_id}'));
    // MonkeyPay: tiền tố và cú pháp lấy theo cổng mặc định trên server (chỉ dùng khi không gọi được server)
    if (checkin_mkt192_is_monkeypay_mode() && ($account = checkin_mkt192_mp_resolve_account())) {
        $prefix = $account['note_prefix'] !== '' ? $account['note_prefix'] : $prefix;
        $syntax = $account['note_syntax'] !== '' ? $account['note_syntax'] : $syntax;
    }

    // Xử lý ngày tháng
    $date_str = '';
    if (!empty($invoice_date)) {
        $timestamp = strtotime($invoice_date);
        $date_str  = date('dmy', $timestamp);
    } else {
        $date_str = current_time('dmy');
    }

    // Xử lý tên khách: bỏ dấu, viết hoa, bỏ khoảng trắng
    $customer_clean = '';
    if (!empty($customer_name)) {
        $customer_clean = checkin_mkt192_remove_accents($customer_name);
        $customer_clean = strtoupper(preg_replace('/[^A-Za-z0-9]/', '', $customer_clean));
    }

    // Thay thế biến
    $note = $syntax;
    $note = str_replace('{prefix}', $prefix, $note);
    $note = str_replace('{invoice_id}', $invoice_id, $note);
    $note = str_replace('{date}', $date_str, $note);
    $note = str_replace('{customer}', $customer_clean, $note);
    $note = str_replace('{timestamp}', (string) time(), $note);
    // {random:N} → N ký tự ngẫu nhiên
    $note = preg_replace_callback('/\{random:(\d+)\}/i', function ($m) {
        $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        $result = '';
        for ($i = 0; $i < intval($m[1]); $i++) {
            $result .= $chars[wp_rand(0, strlen($chars) - 1)];
        }
        return $result;
    }, $note);

    // Chỉ prepend prefix nếu syntax không chứa {prefix} placeholder
    if (stripos($syntax, '{prefix}') === false) {
        $note = $prefix . $note;
    }

    return strtoupper($note);
}

/**
 * Bỏ dấu tiếng Việt
 */
function checkin_mkt192_remove_accents($str) {
    $accents = [
        'à','á','ạ','ả','ã','â','ầ','ấ','ậ','ẩ','ẫ','ă','ằ','ắ','ặ','ẳ','ẵ',
        'è','é','ẹ','ẻ','ẽ','ê','ề','ế','ệ','ể','ễ',
        'ì','í','ị','ỉ','ĩ',
        'ò','ó','ọ','ỏ','õ','ô','ồ','ố','ộ','ổ','ỗ','ơ','ờ','ớ','ợ','ở','ỡ',
        'ù','ú','ụ','ủ','ũ','ư','ừ','ứ','ự','ử','ữ',
        'ỳ','ý','ỵ','ỷ','ỹ',
        'đ',
        'À','Á','Ạ','Ả','Ã','Â','Ầ','Ấ','Ậ','Ẩ','Ẫ','Ă','Ằ','Ắ','Ặ','Ẳ','Ẵ',
        'È','É','Ẹ','Ẻ','Ẽ','Ê','Ề','Ế','Ệ','Ể','Ễ',
        'Ì','Í','Ị','Ỉ','Ĩ',
        'Ò','Ó','Ọ','Ỏ','Õ','Ô','Ồ','Ố','Ộ','Ổ','Ỗ','Ơ','Ờ','Ớ','Ợ','Ở','Ỡ',
        'Ù','Ú','Ụ','Ủ','Ũ','Ư','Ừ','Ứ','Ự','Ử','Ữ',
        'Ỳ','Ý','Ỵ','Ỷ','Ỹ',
        'Đ',
    ];
    $no_accents = [
        'a','a','a','a','a','a','a','a','a','a','a','a','a','a','a','a','a',
        'e','e','e','e','e','e','e','e','e','e','e',
        'i','i','i','i','i',
        'o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o','o',
        'u','u','u','u','u','u','u','u','u','u','u',
        'y','y','y','y','y',
        'd',
        'A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A','A',
        'E','E','E','E','E','E','E','E','E','E','E',
        'I','I','I','I','I',
        'O','O','O','O','O','O','O','O','O','O','O','O','O','O','O','O','O',
        'U','U','U','U','U','U','U','U','U','U','U',
        'Y','Y','Y','Y','Y',
        'D',
    ];
    return str_replace($accents, $no_accents, $str);
}

/**
 * Ghi log MBBank
 */
/**
 * Màn khách tại quầy gọi mbbank-check-payment mà không đăng nhập (5.3.9.2).
 * Chỉ cho đúng hoá đơn thu ngân đã gửi sang máy tính bảng (bảng pending_reviews) trong 12 giờ gần đây,
 * và chỉ các thao tác init / poll / cancel. Đánh dấu "đã trả" vẫn chỉ xảy ra khi MonkeyPay xác nhận
 * tiền đã về (webhook hoặc poll hỏi server), nên người lạ gọi được cũng không tự chốt hoá đơn được.
 */
function checkin_mkt192_mp_kiosk_invoice_allowed(WP_REST_Request $request) {
    global $wpdb;
    $action = (string) $request->get_param('action');
    if (!in_array($action, ['init', 'poll', 'cancel'], true)) return false;
    $invoice_id = sanitize_text_field((string) $request->get_param('invoice_id'));
    if ($invoice_id === '') return false;
    $table = $wpdb->prefix . 'checkin_mkt192_pending_reviews';
    $since = wp_date('Y-m-d H:i:s', time() - 12 * HOUR_IN_SECONDS);
    $found = $wpdb->get_var($wpdb->prepare(
        "SELECT 1 FROM {$table} WHERE invoice_id = %s AND created_at >= %s LIMIT 1",
        $invoice_id,
        $since
    ));
    return (bool) $found;
}

function checkin_mkt192_mbbank_log($event, $data = []) {
    $log_dir = WP_CONTENT_DIR . '/checkin-logs';
    if (!file_exists($log_dir)) {
        wp_mkdir_p($log_dir);
    }

    $log_file = $log_dir . '/mbbank.log';
    $timestamp = current_time('Y-m-d H:i:s');
    $log_entry = "[{$timestamp}] {$event}: " . json_encode($data, JSON_UNESCAPED_UNICODE) . "\n";

    file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);
}

// ═══════════════════════════════════════════════════════════════
// REST API CALLBACKS
// ═══════════════════════════════════════════════════════════════

/**
 * GET /vg/v1/mbbank-status
 * Kiểm tra trạng thái kết nối MBBank service
 */
function checkin_mkt192_mbbank_status() {
    $result = checkin_mkt192_mbbank_request('/api/health');

    if (is_wp_error($result)) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Không thể kết nối đến MBBank service: ' . $result->get_error_message(),
        ], 503);
    }

    return new WP_REST_Response([
        'success' => true,
        'message' => 'Kết nối MBBank service thành công',
        'data'    => $result,
    ], 200);
}

/**
 * POST /vg/v1/mbbank-test-login
 * Test đăng nhập tài khoản MB Bank (admin only)
 * Giải mã credentials đã lưu và gọi Docker service /api/login
 */
function checkin_mkt192_mbbank_test_login() {
    $result = checkin_mkt192_mbbank_request('/api/login', 'POST');

    if (is_wp_error($result)) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Đăng nhập MB Bank thất bại: ' . $result->get_error_message(),
        ], 200); // Return 200 so JS success handler catches it
    }

    return new WP_REST_Response([
        'success' => $result['success'] ?? false,
        'message' => $result['message'] ?? 'Kết quả không xác định',
    ], 200);
}

/**
 * POST /vg/v1/mbbank-transactions
 * Proxy lấy lịch sử giao dịch (POST vì cần gửi credentials)
 */
function checkin_mkt192_mbbank_transactions(WP_REST_Request $request) {
    $from = $request->get_param('from') ?: current_time('d/m/Y');
    $to   = $request->get_param('to') ?: current_time('d/m/Y');

    $result = checkin_mkt192_mbbank_request('/api/transactions', 'POST', [
        'from' => $from,
        'to'   => $to,
    ]);

    if (is_wp_error($result)) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Lỗi khi lấy lịch sử giao dịch: ' . $result->get_error_message(),
        ], 500);
    }

    return new WP_REST_Response([
        'success' => true,
        'data'    => $result['data'] ?? [],
    ], 200);
}

/**
 * POST /vg/v1/mbbank-check-payment
 * Kiểm tra thanh toán cho 1 hóa đơn cụ thể
 *
 * Hỗ trợ 2 mode:
 * - MonkeyPay: Tạo transaction qua MonkeyPay API → poll status
 * - Legacy MBBank: Fetch bank history → match thủ công
 */
function checkin_mkt192_mbbank_check_payment(WP_REST_Request $request) {
    global $wpdb;

    $invoice_id = sanitize_text_field($request->get_param('invoice_id'));
    $table_name = $wpdb->prefix . 'checkin_mkt192_invoices_data';

    // Lấy thông tin hóa đơn - PK là invoice_id (varchar)
    $invoice = $wpdb->get_row(
        $wpdb->prepare("SELECT * FROM {$table_name} WHERE invoice_id = %s", $invoice_id),
        ARRAY_A
    );

    if (!$invoice) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Không tìm thấy hóa đơn',
        ], 404);
    }

    if ($invoice['status'] === 'paid') {
        return new WP_REST_Response([
            'success' => true,
            'message' => 'Hóa đơn đã được thanh toán trước đó',
            'data'    => ['already_paid' => true],
        ], 200);
    }

    // Thu ngân bấm "Huỷ": bỏ liên kết mã đang chờ để lần mở sau tạo mã mới. Giữ payment_note
    // (đối soát vẫn tra được nếu khách lỡ chuyển theo mã cũ); mã cũ trên server tự hết hạn.
    if ($request->get_param('action') === 'cancel') {
        if (!empty($invoice['payment_tx_id'])) {
            $wpdb->update($table_name, ['payment_tx_id' => null, 'payment_gateway_id' => null], ['invoice_id' => $invoice_id]);
            checkin_mkt192_mbbank_log('MP_TX_CANCELLED', ['invoice_id' => $invoice_id, 'tx_id' => $invoice['payment_tx_id']]);
        }
        return new WP_REST_Response(['success' => false, 'message' => 'Đã huỷ mã chuyển khoản', 'data' => ['status' => 'cancelled']], 200);
    }

    $amount = floatval($invoice['total'] ?? 0);

    // ── Chọn flow theo mode ──────────────────────────
    if ( checkin_mkt192_is_monkeypay_mode() ) {
        return checkin_mkt192_check_payment_monkeypay(
            $invoice,
            $amount,
            (int) $request->get_param('gateway_id'),
            (string) $request->get_param('action')
        );
    } else {
        return checkin_mkt192_check_payment_legacy($invoice_id, $invoice, $amount);
    }
}

/**
 * MonkeyPay: tạo/dùng lại giao dịch trên đúng tài khoản rồi hỏi trạng thái.
 *
 * Giao dịch lưu ngay trong hoá đơn (payment_tx_id/payment_note/payment_gateway_id) nên webhook,
 * app và đối soát cùng đọc một chỗ. Tạo giao dịch mới khi: chưa có, đổi tài khoản, đổi số tiền,
 * hoặc giao dịch cũ đã hết hạn (chỉ khi mở QR, không tạo mới lúc đang hỏi trạng thái).
 *
 * @param array  $invoice    Dòng hoá đơn
 * @param float  $amount     Tổng tiền
 * @param int    $gateway_id Tài khoản thu ngân chọn (0 = tài khoản ưu tiên hôm nay)
 * @param string $action     'init' | 'poll' | '' (cũ: tự đoán)
 */
function checkin_mkt192_check_payment_monkeypay($invoice, $amount, $gateway_id = 0, $action = '') {
    $invoice_id = $invoice['invoice_id'];
    $tx_id      = (string) ($invoice['payment_tx_id'] ?? '');
    $stored_gw  = (int) ($invoice['payment_gateway_id'] ?? 0);

    $account = checkin_mkt192_mp_resolve_account($gateway_id ?: ($action === 'poll' ? $stored_gw : 0));
    if (!$account) {
        return new WP_REST_Response([
            'success' => false,
            'message' => $gateway_id ? 'Tài khoản nhận tiền này không còn được bật.' : 'Chưa bật tài khoản nhận tiền nào trong MonkeyPay.',
        ], 503);
    }

    $reply = function ($tx_id, $note, $status, $extra = []) use ($account, $amount, $invoice_id) {
        return new WP_REST_Response([
            'success' => false,
            'message' => $status === 'expired' ? 'Mã chuyển khoản đã hết hạn.' : 'Đang chờ thanh toán...',
            'data'    => array_merge([
                'invoice_id'      => $invoice_id,
                'tx_id'           => $tx_id,
                'payment_note'    => $note,
                'status'          => $status,
                'expected_amount' => $amount,
                'account'         => $account,
            ], $extra),
        ], 200);
    };
    $confirmed = function ($tx_id, $result) use ($invoice_id) {
        if ($result === 'underpaid') {
            return new WP_REST_Response([
                'success' => false,
                'message' => 'Khách đã chuyển khoản nhưng THIẾU tiền so với hoá đơn. Kiểm tra lại rồi xác nhận thủ công.',
                'data'    => ['status' => 'underpaid', 'tx_id' => $tx_id],
            ], 200);
        }
        return new WP_REST_Response([
            'success' => true,
            'message' => 'Xác nhận thanh toán thành công',
            'data'    => ['invoice_id' => $invoice_id, 'tx_id' => $tx_id, 'already_paid' => $result === 'already_paid'],
        ], 200);
    };

    // ── Đã có giao dịch: hỏi trạng thái ─────────────────────
    $reusable = $tx_id !== '' && $stored_gw === (int) $account['gateway_id'];
    if ($reusable) {
        $result = checkin_mkt192_mp_request('/api/transactions/' . rawurlencode($tx_id), 'GET', null, 10);
        if (is_wp_error($result)) {
            return new WP_REST_Response(['success' => false, 'message' => 'Lỗi khi kiểm tra giao dịch: ' . $result->get_error_message()], 503);
        }
        $result = isset($result['data']['tx_id']) ? $result['data'] : $result;
        $status = (string) ($result['status'] ?? 'pending');
        $note   = (string) ($result['payment_note'] ?? $invoice['payment_note'] ?? '');

        if ($status === 'completed') {
            $paid = checkin_mkt192_mp_matched_amount($result['matched_bank_tx'] ?? null);
            return $confirmed($tx_id, checkin_mkt192_mp_mark_paid($invoice_id, $tx_id, $paid, 'poll'));
        }

        // Số tiền hoá đơn đổi (thêm/bớt dịch vụ) thì mã cũ khớp sai tiền: tạo mã mới khi mở lại QR
        $created_for = get_transient('mp_txamt_' . $tx_id);
        $amount_changed = $created_for !== false && abs((float) $created_for - $amount) > 1;

        if ($status === 'pending' && !$amount_changed) {
            return $reply($tx_id, $note, 'pending');
        }
        if ($action === 'poll') {
            // Đang hiện QR cũ trên màn hình: báo để app hiện lại mã mới, không tự tạo ngầm
            return $reply($tx_id, $note, $amount_changed ? 'amount_changed' : 'expired');
        }
    } elseif ($action === 'poll') {
        return $reply($tx_id, (string) ($invoice['payment_note'] ?? ''), 'no_tx');
    }

    // ── Tạo giao dịch mới ───────────────────────────────────
    $created = checkin_mkt192_mp_create_tx($invoice, $account, $amount);
    if (is_wp_error($created)) {
        $code = (int) ($created->get_error_data()['status'] ?? 500);
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Không tạo được mã chuyển khoản MonkeyPay: ' . $created->get_error_message(),
        ], $code === 429 ? 429 : 503);
    }

    // Server tìm thấy tiền về trước khi tạo mã (khách chuyển sớm) → chốt luôn
    if ($created['status'] === 'completed') {
        $paid = checkin_mkt192_mp_matched_amount($created['matched_bank_tx']);
        return $confirmed($created['tx_id'], checkin_mkt192_mp_mark_paid($invoice_id, $created['tx_id'], $paid, 'retroactive'));
    }
    return $reply($created['tx_id'], $created['payment_note'], 'pending', ['created' => true]);
}

/**
 * Legacy MBBank mode: Fetch bank history → match thủ công
 */
function checkin_mkt192_check_payment_legacy($invoice_id, $invoice, $amount) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'checkin_mkt192_invoices_data';

    // Sinh mã ghi chú
    $customer_name = $invoice['customer_name'] ?? '';
    $invoice_date  = $invoice['created_at'] ?? '';
    $payment_note  = checkin_mkt192_generate_payment_note($invoice_id, $customer_name, $invoice_date);

    // Lấy giao dịch hôm nay
    $today = current_time('d/m/Y');
    $result = checkin_mkt192_mbbank_request('/api/transactions', 'POST', [
        'from'    => $today,
        'to'      => $today,
        'nocache' => true,
    ]);

    if (is_wp_error($result)) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Lỗi khi kiểm tra giao dịch: ' . $result->get_error_message(),
        ], 500);
    }

    $transactions = $result['data'] ?? [];
    $matched = checkin_mkt192_match_transaction($transactions, $payment_note, $amount);

    if ($matched) {
        $wpdb->update(
            $table_name,
            [
                'status'         => 'paid',
                'payment_method' => 'bank',
                'paid_at'        => current_time('mysql'),
                'updated_at'     => current_time('mysql'),
            ],
            ['invoice_id' => $invoice_id],
            ['%s', '%s', '%s', '%s'],
            ['%s']
        );

        checkin_mkt192_mbbank_log('PAYMENT_CONFIRMED', [
            'invoice_id'   => $invoice_id,
            'amount'       => $amount,
            'payment_note' => $payment_note,
            'transaction'  => $matched,
            'mode'         => 'legacy',
        ]);

        if (function_exists('checkin_mkt192_push_payment_success')) {
            checkin_mkt192_push_payment_success($invoice_id);
        }



        return new WP_REST_Response([
            'success' => true,
            'message' => 'Xác nhận thanh toán thành công',
            'data'    => [
                'invoice_id'          => $invoice_id,
                'payment_note'        => $payment_note,
                'matched_transaction' => $matched,
            ],
        ], 200);
    }

    return new WP_REST_Response([
        'success' => false,
        'message' => 'Chưa tìm thấy giao dịch khớp',
        'data'    => [
            'payment_note'         => $payment_note,
            'expected_amount'      => $amount,
            'transactions_checked' => count($transactions),
        ],
    ], 200);
}

/**
 * Match giao dịch với mã ghi chú + số tiền
 *
 * @param array  $transactions  Danh sách giao dịch từ MBBank
 * @param string $payment_note  Mã ghi chú cần tìm
 * @param float  $amount        Số tiền cần match
 * @return array|false          Giao dịch matched hoặc false
 */
function checkin_mkt192_match_transaction($transactions, $payment_note, $amount) {
    if (empty($transactions) || empty($payment_note)) {
        return false;
    }

    $payment_note_upper = strtoupper($payment_note);

    foreach ($transactions as $tx) {
        // Chỉ xét giao dịch nhận tiền (credit)
        $credit = floatval($tx['creditAmount'] ?? 0);
        if ($credit <= 0) {
            continue;
        }

        // Match số tiền (cho phép sai lệch 1đ do làm tròn)
        if (abs($credit - $amount) > 1) {
            continue;
        }

        // Match mã ghi chú trong description
        $desc = strtoupper($tx['transactionDesc'] ?? '');
        if (strpos($desc, $payment_note_upper) !== false) {
            return $tx;
        }
    }

    return false;
}

// ═══════════════════════════════════════════════════════════════
// WP CRON - AUTO CHECK PAYMENTS
// ═══════════════════════════════════════════════════════════════

/**
 * Đăng ký custom cron interval
 */
add_filter('cron_schedules', function ($schedules) {
    $interval = intval(get_option('checkin_monkeypay_polling_interval', get_option('checkin_mbbank_polling_interval', 2)));
    $schedules['checkin_mbbank_interval'] = [
        'interval' => $interval * 60,
        'display'  => "Mỗi {$interval} phút (MBBank)",
    ];
    return $schedules;
});

/**
 * Kích hoạt cron khi bật auto mode
 */
function checkin_mkt192_mbbank_schedule_cron() {
    $auto_mode = get_option('checkin_bank_auto_mode', '0');
    $enabled   = get_option('checkin_use_bank_transfer', '0');

    // MonkeyPay tự khớp trên server + webhook, cron dò lịch sử ngân hàng chỉ dành cho chế độ MBBank cũ.
    // (Trước đây cron đặt lại mỗi request rồi plugin MonkeyPay gỡ ra, ghi log CRON_SCHEDULED liên tục.)
    if ($auto_mode === '1' && $enabled === '1' && !checkin_mkt192_is_monkeypay_mode()) {
        if (!wp_next_scheduled('checkin_mbbank_auto_check')) {
            wp_schedule_event(time(), 'checkin_mbbank_interval', 'checkin_mbbank_auto_check');
        }
    } else {
        $timestamp = wp_next_scheduled('checkin_mbbank_auto_check');
        if ($timestamp) {
            wp_unschedule_event($timestamp, 'checkin_mbbank_auto_check');
        }
    }
}
add_action('update_option_checkin_bank_auto_mode', 'checkin_mkt192_mbbank_schedule_cron');
add_action('update_option_checkin_use_bank_transfer', 'checkin_mkt192_mbbank_schedule_cron');
add_action('init', 'checkin_mkt192_mbbank_schedule_cron');

/**
 * Cron handler: Kiểm tra tự động các hóa đơn pending
 */
add_action('checkin_mbbank_auto_check', function () {
    global $wpdb;

    $auto_mode = get_option('checkin_bank_auto_mode', '0');
    if ($auto_mode !== '1' || checkin_mkt192_is_monkeypay_mode()) {
        return;
    }

    $table_name = $wpdb->prefix . 'checkin_mkt192_invoices_data';

    // Lấy các hóa đơn pending chuyển khoản (trong 24h gần nhất)
    $pending_invoices = $wpdb->get_results(
        "SELECT invoice_id, total, customer_name, created_at
         FROM {$table_name}
         WHERE status = 'pending'
           AND payment_method IN ('bank', 'bank_transfer')
           AND created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
         ORDER BY created_at DESC
         LIMIT 50",
        ARRAY_A
    );

    if (empty($pending_invoices)) {
        return;
    }

    checkin_mkt192_mbbank_log('CRON_START', ['pending_count' => count($pending_invoices)]);

    // Lấy giao dịch hôm nay và hôm qua
    $today     = current_time('d/m/Y');
    $yesterday = wp_date('d/m/Y', strtotime('-1 day', current_time('timestamp')));
    $result    = checkin_mkt192_mbbank_request('/api/transactions', 'POST', [
        'from' => $yesterday,
        'to'   => $today,
    ]);

    if (is_wp_error($result)) {
        checkin_mkt192_mbbank_log('CRON_ERROR', ['error' => $result->get_error_message()]);
        return;
    }

    $transactions = $result['data'] ?? [];
    if (empty($transactions)) {
        checkin_mkt192_mbbank_log('CRON_NO_TRANSACTIONS');
        return;
    }

    $matched_count = 0;

    foreach ($pending_invoices as $invoice) {
        $payment_note = checkin_mkt192_generate_payment_note(
            $invoice['invoice_id'],
            $invoice['customer_name'] ?? '',
            $invoice['created_at'] ?? ''
        );
        $amount = floatval($invoice['total']);

        $matched = checkin_mkt192_match_transaction($transactions, $payment_note, $amount);

        if ($matched) {
            $wpdb->update(
                $table_name,
                [
                    'status'         => 'paid',
                    'payment_method' => 'bank',
                    'paid_at'        => current_time('mysql'),
                    'updated_at'     => current_time('mysql'),
                ],
                ['invoice_id' => $invoice['invoice_id']],
                ['%s', '%s', '%s', '%s'],
                ['%s']
            );

            $matched_count++;

            checkin_mkt192_mbbank_log('CRON_MATCHED', [
                'invoice_id'   => $invoice['invoice_id'],
                'amount'       => $amount,
                'payment_note' => $payment_note,
            ]);

            // Gửi push notification
            if (function_exists('checkin_mkt192_push_payment_success')) {
                checkin_mkt192_push_payment_success($invoice['invoice_id']);
            }


        }
    }

    checkin_mkt192_mbbank_log('CRON_COMPLETE', [
        'checked'  => count($pending_invoices),
        'matched'  => $matched_count,
        'tx_count' => count($transactions),
    ]);
});

// ═══════════════════════════════════════════════════════════════
// MONKEYPAY SERVER URL (kept for checkin_mkt192_mbbank_request)
// Registration/Login/Disconnect đã chuyển sang MonkeyPay plugin.
// ═══════════════════════════════════════════════════════════════

// ═══════════════════════════════════════════════════════════════
// RECONCILIATION (Đối soát hóa đơn)
// ═══════════════════════════════════════════════════════════════

/**
 * Đối soát batch: so khớp hóa đơn với giao dịch ngân hàng
 *
 * Flow:
 * 1. Lấy invoice paid bằng bank trong ngày
 * 2. Gọi MonkeyPay lấy bank transactions
 * 3. Match: invoice.total === bank_tx.creditAmount
 * 4. Update reconcile_status + reconcile_tx_ref
 *
 * @param WP_REST_Request $request { date: 'YYYY-MM-DD' }
 * @return WP_REST_Response
 */
function checkin_mkt192_reconcile_invoices($request) {
    global $wpdb;
    $table_name = $wpdb->prefix . 'checkin_mkt192_invoices_data';

    // Check MonkeyPay mode
    if ( ! checkin_mkt192_is_monkeypay_mode() ) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Chức năng đối soát chỉ khả dụng khi sử dụng MonkeyPay.',
        ], 400);
    }

    $from_date = sanitize_text_field($request->get_param('from_date'));
    $to_date   = sanitize_text_field($request->get_param('to_date'));

    // Validate date format
    if ( ! preg_match('/^\d{4}-\d{2}-\d{2}$/', $from_date) ||
         ! preg_match('/^\d{4}-\d{2}-\d{2}$/', $to_date) ) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Định dạng ngày không hợp lệ. Sử dụng YYYY-MM-DD.',
        ], 400);
    }

    // Clamp range to max 31 days to prevent abuse
    $start_ts = strtotime($from_date);
    $end_ts   = strtotime($to_date);
    if ( $end_ts < $start_ts ) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'to_date phải >= from_date.',
        ], 400);
    }
    if ( ($end_ts - $start_ts) > 31 * 86400 ) {
        return new WP_REST_Response([
            'success' => false,
            'message' => 'Khoảng thời gian tối đa 31 ngày.',
        ], 400);
    }

    // 1. Lấy invoices paid bằng bank trong khoảng ngày
    $invoices = $wpdb->get_results($wpdb->prepare(
        "SELECT invoice_id, total, customer_name, created_at, paid_at, reconcile_status, reconcile_tx_ref, payment_note
         FROM $table_name
         WHERE status = 'paid'
           AND payment_method = 'bank'
           AND DATE(created_at) >= %s
           AND DATE(created_at) <= %s
         ORDER BY created_at ASC",
        $from_date, $to_date
    ), ARRAY_A);

    if ( empty($invoices) ) {
        return new WP_REST_Response([
            'success' => true,
            'message' => 'Không có hóa đơn bank nào từ ' . $from_date . ' đến ' . $to_date,
            'data'    => [
                'from_date' => $from_date,
                'to_date'   => $to_date,
                'total'     => 0,
                'matched'   => 0,
                'unmatched' => 0,
                'skipped'   => 0,
                'invoices'  => [],
            ],
        ], 200);
    }

    // 2. Fetch bank transactions from MonkeyPay /api/bank/history (GET)
    $all_credit_txs = [];
    $from_api = date('d/m/Y', $start_ts);
    $to_api   = date('d/m/Y', $end_ts);

    $bank_result = checkin_mkt192_mbbank_request(
        '/api/bank/history?from=' . urlencode($from_api) . '&to=' . urlencode($to_api),
        'GET'
    );

    if ( ! is_wp_error($bank_result) ) {
        $bank_transactions = [];
        if (isset($bank_result['transactions'])) {
            $bank_transactions = $bank_result['transactions'];
        } elseif (isset($bank_result['data']['transactions'])) {
            $bank_transactions = $bank_result['data']['transactions'];
        } elseif (isset($bank_result['data']) && is_array($bank_result['data']) && isset($bank_result['data'][0]['creditAmount'])) {
            $bank_transactions = $bank_result['data'];
        } elseif (is_array($bank_result) && isset($bank_result[0]['creditAmount'])) {
            $bank_transactions = $bank_result;
        }

        // Filter credit-only (tiền vào)
        foreach ($bank_transactions as $tx) {
            if ( floatval($tx['creditAmount'] ?? 0) > 0 ) {
                $all_credit_txs[] = $tx;
            }
        }
    } else {
        checkin_mkt192_mbbank_log('RECONCILE_BANK_ERROR', [
            'error' => $bank_result->get_error_message(),
            'from'  => $from_api,
            'to'    => $to_api,
        ]);
    }

    // ═══════════════════════════════════════════════════════════════
    // 3. SMART MATCH — 3-tier matching logic
    // ═══════════════════════════════════════════════════════════════
    // Tier 1: Exact match by payment_note in bank tx description
    // Tier 2: Greedy nearest-time match by amount (for static QR / no note)
    // Tier 3: Unmatched
    // ═══════════════════════════════════════════════════════════════

    $now = current_time('mysql');
    $matched_count   = 0;
    $unmatched_count = 0;
    $skipped_count   = 0;
    $results         = [];

    // Track which bank txs have been consumed (by array index)
    $used_tx_indices = [];

    // Pre-compute: parse bank tx timestamps for tier-2 time matching
    // Format: 'DD/MM/YYYY HH:MM:SS' or 'YYYY-MM-DD HH:MM:SS'
    foreach ($all_credit_txs as $i => &$tx) {
        $raw_date = $tx['transactionDate'] ?? $tx['postDate'] ?? $tx['date'] ?? '';
        $ts = false;
        if (!empty($raw_date)) {
            // Try DD/MM/YYYY HH:MM:SS
            if (preg_match('#^(\d{2})/(\d{2})/(\d{4})\s+(\d{2}:\d{2}:\d{2})$#', $raw_date, $m)) {
                $ts = strtotime("{$m[3]}-{$m[2]}-{$m[1]} {$m[4]}");
            } else {
                $ts = strtotime($raw_date);
            }
        }
        $tx['_parsed_ts'] = $ts ?: 0;
    }
    unset($tx); // break reference

    // ── TIER 0: Skip already-matched invoices ──
    $pending_invoices = []; // invoices that need matching
    foreach ($invoices as $inv) {
        if ($inv['reconcile_status'] === 'matched') {
            $skipped_count++;
            $results[] = [
                'invoice_id'       => $inv['invoice_id'],
                'total'            => intval($inv['total']),
                'reconcile_status' => 'matched',
                'reconcile_tx_ref' => $inv['reconcile_tx_ref'],
                'match_method'     => 'previous',
                'action'           => 'skipped',
            ];
        } else {
            $pending_invoices[] = $inv;
        }
    }

    // ── TIER 1: Exact match by ACTUAL payment_note from monkeypay_transactions ──
    // (NOT re-generated — generate_payment_note uses {random:6} which produces
    //  different results each call. We use the STORED payment_note instead.)
    // Từ 5.3.9.0 nội dung CK lưu ngay trong hoá đơn (payment_note); hoá đơn cũ thì tra bảng của plugin MonkeyPay nếu còn
    $mp_table  = $wpdb->prefix . 'monkeypay_transactions';
    $has_mp_tb = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $mp_table)) === $mp_table;
    $still_pending = [];
    foreach ($pending_invoices as $inv) {
        $invoice_id = $inv['invoice_id'];
        $inv_total  = intval($inv['total']);

        // Look up the ACTUAL payment_note that was used when creating this payment
        $stored_note = (string) ($inv['payment_note'] ?? '');
        if ($stored_note === '' && $has_mp_tb) {
            $stored_note = $wpdb->get_var($wpdb->prepare(
                "SELECT payment_note FROM $mp_table
                 WHERE reference_type = 'checkin_invoice'
                   AND reference_id = %s
                   AND payment_note IS NOT NULL
                   AND payment_note != ''
                 ORDER BY id DESC LIMIT 1",
                $invoice_id
            ));
        }

        $note_upper = $stored_note ? strtoupper($stored_note) : '';

        $found_idx = null;
        if (!empty($note_upper)) {
            foreach ($all_credit_txs as $i => $tx) {
                if (isset($used_tx_indices[$i])) continue;

                $credit = intval(floatval($tx['creditAmount'] ?? 0));
                if ($credit <= 0) continue;

                // Amount must match (±1 rounding tolerance)
                if (abs($credit - $inv_total) > 1) continue;

                // Check if payment_note exists in bank description
                $desc = strtoupper($tx['transactionDesc'] ?? $tx['description'] ?? '');
                if (strpos($desc, $note_upper) !== false) {
                    $found_idx = $i;
                    break;
                }
            }
        }

        if ($found_idx !== null) {
            $used_tx_indices[$found_idx] = true;
            $found_tx = $all_credit_txs[$found_idx];
            $tx_ref = $found_tx['refNo'] ?? $found_tx['transactionID'] ?? $found_tx['description'] ?? '';

            $wpdb->update(
                $table_name,
                [
                    'reconcile_status' => 'matched',
                    'reconcile_at'     => $now,
                    'reconcile_tx_ref' => $tx_ref,
                ],
                ['invoice_id' => $invoice_id],
                ['%s', '%s', '%s'],
                ['%s']
            );
            $matched_count++;
            $results[] = [
                'invoice_id'       => $invoice_id,
                'total'            => $inv_total,
                'reconcile_status' => 'matched',
                'reconcile_tx_ref' => $tx_ref,
                'match_method'     => 'exact_note',
                'action'           => 'updated',
            ];
        } else {
            $still_pending[] = $inv;
        }
    }

    // ── TIER 2: Greedy nearest-time match by amount ──
    // For invoices without matching payment_note (static QR, manual transfer)
    // Group remaining bank txs by amount, then pair with closest invoice by time
    if (!empty($still_pending)) {
        // Build pool of unused bank txs indexed by amount
        $unused_pool = []; // amount => [ [idx, tx], ... ]
        foreach ($all_credit_txs as $i => $tx) {
            if (isset($used_tx_indices[$i])) continue;
            $credit = intval(floatval($tx['creditAmount'] ?? 0));
            if ($credit <= 0) continue;
            $unused_pool[$credit][] = ['idx' => $i, 'tx' => $tx];
        }

        // Parse invoice timestamps — prefer paid_at over created_at
        // (paid_at is much closer to the actual BDSD transaction time)
        foreach ($still_pending as &$inv_ref) {
            $ts = 0;
            if (!empty($inv_ref['paid_at'])) {
                $ts = strtotime($inv_ref['paid_at']);
            }
            if (!$ts && !empty($inv_ref['created_at'])) {
                $ts = strtotime($inv_ref['created_at']);
            }
            $inv_ref['_inv_ts'] = $ts ?: 0;
        }
        unset($inv_ref);

        // Sort pending invoices by timestamp ASC (process oldest first)
        usort($still_pending, function($a, $b) {
            return $a['_inv_ts'] - $b['_inv_ts'];
        });

        $final_unmatched = [];
        foreach ($still_pending as $inv) {
            $invoice_id = $inv['invoice_id'];
            $inv_total  = intval($inv['total']);
            $inv_ts     = $inv['_inv_ts'];

            // Find same-amount bank txs
            if (!isset($unused_pool[$inv_total]) || empty($unused_pool[$inv_total])) {
                $final_unmatched[] = $inv;
                continue;
            }

            // Find the bank tx with closest time to this invoice
            $best_idx_in_pool = null;
            $best_time_diff   = PHP_INT_MAX;
            foreach ($unused_pool[$inv_total] as $pool_key => $entry) {
                $tx_ts = $entry['tx']['_parsed_ts'] ?? 0;
                $diff  = ($inv_ts > 0 && $tx_ts > 0) ? abs($tx_ts - $inv_ts) : PHP_INT_MAX;
                if ($diff < $best_time_diff) {
                    $best_time_diff   = $diff;
                    $best_idx_in_pool = $pool_key;
                }
            }

            if ($best_idx_in_pool !== null) {
                $entry    = $unused_pool[$inv_total][$best_idx_in_pool];
                $found_tx = $entry['tx'];
                $used_tx_indices[$entry['idx']] = true;

                // Remove from pool
                array_splice($unused_pool[$inv_total], $best_idx_in_pool, 1);
                if (empty($unused_pool[$inv_total])) {
                    unset($unused_pool[$inv_total]);
                }

                $tx_ref = $found_tx['refNo'] ?? $found_tx['transactionID'] ?? $found_tx['description'] ?? '';

                // Determine match confidence
                $hours_diff    = $best_time_diff / 3600;
                $match_method  = ($hours_diff <= 2) ? 'time_close' : 'amount_only';

                $wpdb->update(
                    $table_name,
                    [
                        'reconcile_status' => 'matched',
                        'reconcile_at'     => $now,
                        'reconcile_tx_ref' => $tx_ref,
                    ],
                    ['invoice_id' => $invoice_id],
                    ['%s', '%s', '%s'],
                    ['%s']
                );
                $matched_count++;
                $results[] = [
                    'invoice_id'       => $invoice_id,
                    'total'            => $inv_total,
                    'reconcile_status' => 'matched',
                    'reconcile_tx_ref' => $tx_ref,
                    'match_method'     => $match_method,
                    'action'           => 'updated',
                ];
            } else {
                $final_unmatched[] = $inv;
            }
        }

        // ── TIER 3: Mark remaining as unmatched ──
        foreach ($final_unmatched as $inv) {
            $invoice_id = $inv['invoice_id'];
            $inv_total  = intval($inv['total']);

            $wpdb->update(
                $table_name,
                [
                    'reconcile_status' => 'unmatched',
                    'reconcile_at'     => $now,
                    'reconcile_tx_ref' => null,
                ],
                ['invoice_id' => $invoice_id],
                ['%s', '%s', '%s'],
                ['%s']
            );
            $unmatched_count++;
            $results[] = [
                'invoice_id'       => $invoice_id,
                'total'            => $inv_total,
                'reconcile_status' => 'unmatched',
                'reconcile_tx_ref' => null,
                'match_method'     => null,
                'action'           => 'updated',
            ];
        }
    }

    // Count match methods for summary
    $method_counts = ['exact_note' => 0, 'time_close' => 0, 'amount_only' => 0];
    foreach ($results as $r) {
        if (isset($r['match_method']) && isset($method_counts[$r['match_method']])) {
            $method_counts[$r['match_method']]++;
        }
    }

    checkin_mkt192_mbbank_log('RECONCILE_BATCH', [
        'from_date'      => $from_date,
        'to_date'        => $to_date,
        'total'          => count($invoices),
        'matched'        => $matched_count,
        'unmatched'      => $unmatched_count,
        'skipped'        => $skipped_count,
        'match_methods'  => $method_counts,
    ]);

    return new WP_REST_Response([
        'success' => true,
        'message' => sprintf(
            'Đối soát %s → %s: %d khớp, %d chưa khớp, %d đã xử lý trước đó',
            $from_date, $to_date, $matched_count, $unmatched_count, $skipped_count
        ),
        'data' => [
            'from_date'      => $from_date,
            'to_date'        => $to_date,
            'total'          => count($invoices),
            'matched'        => $matched_count,
            'unmatched'      => $unmatched_count,
            'skipped'        => $skipped_count,
            'match_methods'  => $method_counts,
            'invoices'       => $results,
        ],
    ], 200);
}

/**
 * URL máy chủ MonkeyPay. Từ 5.3.9.0 Checkin tự giữ cấu hình, không đọc từ plugin MonkeyPay nữa.
 */
function checkin_mkt192_get_monkeypay_url() {
    return checkin_mkt192_mp_api_url();
}
