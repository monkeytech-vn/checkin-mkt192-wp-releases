<?php
/**
 * Dòng bản quyền và ghi công ở footer các trang công khai (5.3.9.4).
 *
 * Năm bản quyền lấy từ "Năm bắt đầu hoạt động" (Cài đặt thương hiệu > Thông tin, option
 * checkin_founded_year). Để trống thì dùng năm hiện tại như trước. Plugin chạy cho nhiều tiệm
 * nên không ghi cứng năm của tiệm nào.
 */
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Năm hiện trong "© <năm> <tên tiệm>": khoảng "2016 - 2026" từ năm bắt đầu hoạt động tới năm
 * hiện tại (5.3.9.5); chưa điền hoặc trùng năm hiện tại thì chỉ một năm.
 */
function checkin_mkt192_copyright_year() {
    $current = (int) wp_date('Y');
    $founded = (int) get_option('checkin_founded_year', 0);
    if ($founded >= 1900 && $founded < $current) {
        return $founded . ' - ' . $current;
    }
    return (string) $current;
}

/** Ghi công đơn vị phát triển, đặt cùng dòng với bản quyền. */
function checkin_mkt192_footer_credit_html() {
    return '<span class="footer-credit-dev">Thiết kế và phát triển bởi '
        . '<a href="https://monkeytech.vn" target="_blank" rel="noopener">monkeytech.vn</a></span>';
}
