/**
 * Thanh toán → Chuyển khoản → MonkeyPay: kết nối bằng API key, chọn tài khoản nhận tiền,
 * lịch ngày dùng, chế độ nhiều tài khoản, webhook, thông báo biến động số dư.
 * Mọi thay đổi lưu ngay qua REST vg/v1/monkeypay/* (không qua nút "Lưu thay đổi" của modal).
 */
(function () {
  'use strict';

  const root = () => document.getElementById('mp-connect');
  const api = (path, method = 'GET', body) =>
    fetch(`${window.checkinAdmin.restUrl}vg/v1/monkeypay/${path}`, {
      method,
      headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': window.checkinAdmin.restNonce },
      body: body ? JSON.stringify(body) : undefined,
    }).then(async (res) => {
      const data = await res.json().catch(() => ({}));
      if (!res.ok || data.success === false) throw new Error(data.message || `Lỗi HTTP ${res.status}`);
      return data;
    });

  const esc = (v) =>
    String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const DAYS = [
    [1, 'T2'],
    [2, 'T3'],
    [3, 'T4'],
    [4, 'T5'],
    [5, 'T6'],
    [6, 'T7'],
    [7, 'CN'],
  ];
  const SITE = 'https://monkeypay.monkeytech.vn';

  let state = null;
  let draft = null; // { multi, accounts: {id: {use, days, is_default, auto_amount}} }
  let dirty = false;

  function toast(msg, type = 'success') {
    const el = document.createElement('div');
    el.className = `mp-toast mp-toast--${type}`;
    el.textContent = msg;
    document.body.appendChild(el);
    setTimeout(() => el.classList.add('is-in'), 10);
    setTimeout(() => {
      el.classList.remove('is-in');
      setTimeout(() => el.remove(), 250);
    }, 3200);
  }

  function busy(btn, on, label) {
    if (!btn) return;
    if (on) {
      btn.dataset.label = btn.innerHTML;
      btn.disabled = true;
      btn.innerHTML = `<span class="dashicons dashicons-update spin"></span> ${esc(label || 'Đang xử lý...')}`;
    } else {
      btn.disabled = false;
      if (btn.dataset.label) btn.innerHTML = btn.dataset.label;
    }
  }

  function makeDraft() {
    draft = { multi: !!state.multi_account, accounts: {} };
    state.gateways.forEach((g) => {
      draft.accounts[g.id] = { use: !!g.use, days: (g.days || []).map(Number), is_default: !!g.is_default, auto_amount: !!g.auto_amount };
    });
    dirty = false;
  }

  // ─── Khối 1: kết nối ────────────────────────────────────────────
  function connectForm() {
    const legacy = state.legacy
      ? `<div class="mp-note mp-note--warn">
           <span class="dashicons dashicons-info-outline"></span>
           <div>Đang chạy tạm bằng khoá của plugin MonkeyPay (<code>${esc(state.key_hint)}</code>).
           Dán API key tạo trên website MonkeyPay để Checkin tự kết nối, sau đó có thể tắt plugin MonkeyPay.</div>
         </div>`
      : '';
    return `
      <section class="mp-card">
        <header class="mp-card-head">
          <div class="mp-card-title"><span class="dashicons dashicons-admin-network"></span> Kết nối MonkeyPay</div>
          <span class="mp-badge mp-badge--off">Chưa kết nối</span>
        </header>
        ${legacy}
        <ol class="mp-steps">
          <li>Đăng nhập <a href="${SITE}" target="_blank" rel="noopener">monkeypay.monkeytech.vn</a>, tạo dự án và cổng thanh toán (tài khoản ngân hàng nhận tiền).</li>
          <li>Vào <strong>API key</strong>, tạo khoá đơn (bắt đầu bằng <code>mpk_</code>) rồi dán vào đây.</li>
        </ol>
        <label class="mp-label" for="mp-key">API key</label>
        <div class="mp-key-row">
          <input id="mp-key" type="password" class="checkin-form-control" placeholder="mpk_..." autocomplete="off" spellcheck="false">
          <button type="button" class="checkin-btn checkin-btn-secondary mp-eye" aria-label="Hiện/ẩn API key"><span class="dashicons dashicons-visibility"></span></button>
        </div>
        <details class="mp-adv">
          <summary>Máy chủ khác (nâng cao)</summary>
          <input id="mp-url" type="url" class="checkin-form-control" value="${esc(state.api_url)}" placeholder="${SITE}">
        </details>
        <div class="mp-actions">
          <button type="button" class="checkin-btn checkin-btn-primary" data-act="connect"><span class="dashicons dashicons-admin-links"></span> Kết nối</button>
        </div>
      </section>`;
  }

  function connectedCard() {
    const m = state.merchant || {};
    const projects =
      state.projects.length > 1
        ? `<label class="mp-label" for="mp-project">Dự án dùng cho site này</label>
           <select id="mp-project" class="checkin-form-control">
             <option value="0">Chọn dự án...</option>
             ${state.projects.map((p) => `<option value="${p.id}" ${p.id === state.project_id ? 'selected' : ''}>${esc(p.name)}</option>`).join('')}
           </select>`
        : '';
    return `
      <section class="mp-card">
        <header class="mp-card-head">
          <div class="mp-card-title"><span class="dashicons dashicons-admin-network"></span> Kết nối MonkeyPay</div>
          <span class="mp-badge mp-badge--on"><span class="mp-dot"></span> Đã kết nối</span>
        </header>
        <dl class="mp-kv">
          <dt>Tài khoản</dt><dd><strong>${esc(m.name || '-')}</strong>${m.email ? ` · ${esc(m.email)}` : ''}</dd>
          <dt>Gói</dt><dd>${esc(m.plan || '-')}</dd>
          <dt>API key</dt><dd><code>${esc(state.key_hint)}</code></dd>
        </dl>
        ${projects}
        <div class="mp-actions">
          <button type="button" class="checkin-btn checkin-btn-secondary" data-act="sync"><span class="dashicons dashicons-update"></span> Đồng bộ từ MonkeyPay</button>
          <a class="checkin-btn checkin-btn-secondary" href="${SITE}" target="_blank" rel="noopener"><span class="dashicons dashicons-external"></span> Mở MonkeyPay</a>
          <button type="button" class="checkin-btn mp-btn-danger" data-act="disconnect"><span class="dashicons dashicons-dismiss"></span> Ngắt kết nối</button>
        </div>
        ${
          state.legacy_plugin
            ? `<div class="mp-note mp-note--ok"><span class="dashicons dashicons-yes-alt"></span><div>Checkin đã tự kết nối MonkeyPay. Plugin MonkeyPay không còn cần cho thanh toán của Checkin, có thể tắt.</div></div>`
            : ''
        }
      </section>`;
  }

  // ─── Khối 2: tài khoản nhận tiền ────────────────────────────────
  function accountRow(g) {
    const d = draft.accounts[g.id];
    const usable = g.usable;
    const status = !usable
      ? `<span class="mp-badge mp-badge--warn">${g.status === 'pending' ? 'Chờ duyệt trên MonkeyPay' : 'Đang tắt trên MonkeyPay'}</span>`
      : '';
    const logo = g.bank_logo
      ? `<img src="${esc(g.bank_logo)}" alt="${esc(g.bank_label)}" loading="lazy">`
      : `<span>${esc(g.bank_short)}</span>`;
    return `
      <div class="mp-acc ${d.use && usable ? 'is-on' : ''} ${usable ? '' : 'is-disabled'}" data-id="${g.id}">
        <label class="checkin-toggle mp-acc-toggle" title="Dùng tài khoản này">
          <input type="checkbox" data-field="use" ${d.use && usable ? 'checked' : ''} ${usable ? '' : 'disabled'}>
          <span class="checkin-toggle-slider"></span>
        </label>
        <div class="mp-acc-logo">${logo}</div>
        <div class="mp-acc-main">
          <div class="mp-acc-name">${esc(g.label || g.bank_label)} ${status}</div>
          <div class="mp-acc-meta">${esc(g.bank_label)} · <span class="mp-mono">${esc(g.account_number)}</span> · ${esc(g.account_name)}</div>
          <div class="mp-acc-chips">
            <span class="mp-chip" title="Nội dung chuyển khoản bắt đầu bằng tiền tố này, sửa trên MonkeyPay">Tiền tố <b class="mp-mono">${esc(g.note_prefix || '-')}</b></span>
            ${g.project_name ? `<span class="mp-chip">Dự án ${esc(g.project_name)}</span>` : ''}
          </div>
          <label class="mp-amount ${d.use && usable ? '' : 'is-disabled'}">
            <span class="checkin-toggle mp-amount-toggle">
              <input type="checkbox" data-field="auto_amount" ${d.auto_amount ? 'checked' : ''} ${d.use && usable ? '' : 'disabled'}>
              <span class="checkin-toggle-slider"></span>
            </span>
            <span class="mp-amount-text">
              <b>QR có sẵn số tiền</b>
              <small>${d.auto_amount
                ? 'Khách quét là có số tiền, chỉ tự xác nhận khi chuyển đúng số tiền.'
                : 'Khách tự nhập số tiền, tự xác nhận theo nội dung chuyển khoản.'}${d.auto_amount !== !!g.auto_amount_server ? ' Khác cài đặt trên MonkeyPay.' : ''}</small>
            </span>
          </label>
          <div class="mp-days" role="group" aria-label="Ngày dùng">
            <span class="mp-days-label">Ngày dùng</span>
            ${DAYS.map(([n, t]) => `<button type="button" class="mp-day ${d.days.includes(n) ? 'is-on' : ''}" data-day="${n}" ${d.use && usable ? '' : 'disabled'}>${t}</button>`).join('')}
          </div>
        </div>
        <label class="mp-default" title="Tài khoản ưu tiên khi nhiều tài khoản cùng hợp ngày">
          <input type="radio" name="mp-default" data-field="default" ${d.is_default && d.use ? 'checked' : ''} ${d.use && usable ? '' : 'disabled'}>
          <span>Mặc định</span>
        </label>
      </div>`;
  }

  function accountsCard() {
    if (!state.gateways.length) {
      return `
        <section class="mp-card">
          <header class="mp-card-head"><div class="mp-card-title"><span class="dashicons dashicons-bank"></span> Tài khoản nhận tiền</div></header>
          <div class="mp-note mp-note--warn"><span class="dashicons dashicons-warning"></span>
            <div>${state.gateways_error ? `Không tải được danh sách cổng: ${esc(state.gateways_error)}` : 'Dự án chưa có cổng thanh toán nào.'}
            Tạo cổng trên <a href="${SITE}" target="_blank" rel="noopener">MonkeyPay</a> rồi bấm <b>Đồng bộ</b>.</div></div>
        </section>`;
    }
    return `
      <section class="mp-card">
        <header class="mp-card-head">
          <div class="mp-card-title"><span class="dashicons dashicons-bank"></span> Tài khoản nhận tiền</div>
          <a class="mp-link" href="${SITE}" target="_blank" rel="noopener">Thêm tài khoản trên MonkeyPay <span class="dashicons dashicons-external"></span></a>
        </header>
        <div class="mp-multi">
          <label class="checkin-toggle">
            <input type="checkbox" id="mp-multi" ${draft.multi ? 'checked' : ''}>
            <span class="checkin-toggle-slider"></span>
          </label>
          <div>
            <div class="mp-multi-title">Dùng nhiều tài khoản cùng lúc</div>
            <div class="mp-help">${
              draft.multi
                ? 'Đang bật: khi khách chọn Chuyển khoản, thu ngân chọn tài khoản nhận tiền trước khi hiện QR (chỉ hiện các tài khoản hợp ngày hôm nay).'
                : 'Đang tắt: mỗi ngày chỉ dùng một tài khoản. Hệ thống tự lấy tài khoản hợp ngày dùng, trùng ngày thì lấy tài khoản mặc định.'
            }</div>
          </div>
        </div>
        <div class="mp-accs">${state.gateways.map(accountRow).join('')}</div>
        <p class="mp-help mp-help--tip"><span class="dashicons dashicons-lightbulb"></span>
          Ví dụ: tài khoản chính chọn T2 - T6, tài khoản cuối tuần chọn T7, CN. Tắt "nhiều tài khoản" thì hệ thống tự đổi theo ngày; bật thì thu ngân được chọn.</p>
        <div class="mp-actions mp-actions--save">
          <span class="mp-dirty ${dirty ? 'is-on' : ''}">Có thay đổi chưa lưu</span>
          <button type="button" class="checkin-btn checkin-btn-primary" data-act="save" ${dirty ? '' : 'disabled'}><span class="dashicons dashicons-saved"></span> Lưu tài khoản</button>
        </div>
      </section>`;
  }

  // ─── Khối 3: xác nhận tự động + thông báo ───────────────────────
  function automationCard() {
    const hook = state.webhook || {};
    const last = hook.last
      ? `Lần nhận gần nhất: ${esc(hook.last.at)}${hook.last.test ? ' (gửi thử)' : ''}`
      : 'Chưa nhận sự kiện nào.';
    return `
      <section class="mp-card">
        <header class="mp-card-head"><div class="mp-card-title"><span class="dashicons dashicons-controls-repeat"></span> Xác nhận tự động</div></header>
        <div class="mp-row">
          <span class="mp-badge ${hook.registered ? 'mp-badge--on' : 'mp-badge--warn'}">${hook.registered ? 'Webhook đang bật' : 'Chưa đăng ký webhook'}</span>
          <span class="mp-help">${hook.registered ? last : 'Chưa có webhook thì vẫn tự xác nhận nhờ app hỏi trạng thái, chỉ chậm hơn vài giây.'}</span>
        </div>
        <code class="mp-url">${esc(hook.url || '')}</code>
        <div class="mp-actions">
          ${hook.registered ? '<button type="button" class="checkin-btn checkin-btn-secondary" data-act="test"><span class="dashicons dashicons-yes"></span> Gửi thử</button>' : ''}
          <button type="button" class="checkin-btn checkin-btn-secondary" data-act="webhook"><span class="dashicons dashicons-update"></span> ${hook.registered ? 'Đăng ký lại' : 'Đăng ký webhook'}</button>
        </div>
        <div class="mp-sep"></div>
        <div class="mp-row">
          <span class="mp-badge ${state.bank_bot ? 'mp-badge--on' : 'mp-badge--off'}">${state.bank_bot ? 'Đang gửi Lark' : 'Chưa gửi Lark'}</span>
          <span class="mp-help">Thẻ <b>biến động số dư</b> (tiền vào/ra, hoá đơn đã khớp) gửi qua bot Lark có loại thông báo
            <b>"Biến động số dư"</b> (trang <a href="${window.checkinAdmin.adminUrl}admin.php?page=checkin-mkt192-connections">Connections</a>, mục Lark bot).</span>
        </div>
      </section>`;
  }

  function render() {
    const el = root();
    if (!el || !state) return;
    if (!state.connected) {
      el.innerHTML = connectForm() + (state.legacy && draft ? accountsCard() : '');
    } else {
      el.innerHTML = connectedCard() + accountsCard() + automationCard();
    }
  }

  // ─── Sự kiện ────────────────────────────────────────────────────
  function markDirty() {
    dirty = true;
    const el = root();
    el?.querySelector('.mp-dirty')?.classList.add('is-on');
    const save = el?.querySelector('[data-act="save"]');
    if (save) save.disabled = false;
  }

  async function onClick(e) {
    const btn = e.target.closest('button, .mp-eye');
    if (!btn || !root().contains(btn)) return;

    if (btn.classList.contains('mp-eye')) {
      const input = document.getElementById('mp-key');
      input.type = input.type === 'password' ? 'text' : 'password';
      return;
    }

    const day = btn.dataset.day;
    if (day) {
      const id = btn.closest('.mp-acc').dataset.id;
      const days = draft.accounts[id].days;
      const n = Number(day);
      if (days.includes(n)) {
        if (days.length === 1) return toast('Mỗi tài khoản phải có ít nhất một ngày dùng.', 'warn');
        days.splice(days.indexOf(n), 1);
      } else {
        days.push(n);
      }
      btn.classList.toggle('is-on');
      return markDirty();
    }

    const act = btn.dataset.act;
    if (!act) return;
    try {
      if (act === 'connect') {
        const key = document.getElementById('mp-key').value.trim();
        if (!key) return toast('Dán API key trước khi kết nối.', 'warn');
        busy(btn, true, 'Đang kết nối...');
        const res = await api('connect', 'POST', { api_key: key, api_url: document.getElementById('mp-url')?.value.trim() || '' });
        state = res.data;
        makeDraft();
        render();
        let msg = 'Đã kết nối MonkeyPay.';
        if (res.imported_bots) msg += ` Đã chuyển ${res.imported_bots} kênh Lark "biến động số dư" từ plugin MonkeyPay.`;
        if (state.webhook_error) msg += ` Webhook chưa đăng ký được: ${state.webhook_error}`;
        toast(msg, state.webhook_error ? 'warn' : 'success');
      } else if (act === 'sync') {
        busy(btn, true, 'Đang đồng bộ...');
        state = (await api('sync', 'POST')).data;
        makeDraft();
        render();
        toast('Đã đồng bộ cổng thanh toán từ MonkeyPay.');
      } else if (act === 'disconnect') {
        if (!window.confirm('Ngắt kết nối MonkeyPay? Hoá đơn sẽ không tự xác nhận chuyển khoản nữa cho tới khi kết nối lại.')) return;
        busy(btn, true, 'Đang ngắt...');
        state = (await api('disconnect', 'POST')).data;
        makeDraft();
        render();
        toast('Đã ngắt kết nối MonkeyPay.');
      } else if (act === 'save') {
        busy(btn, true, 'Đang lưu...');
        const accounts = Object.entries(draft.accounts).map(([id, a]) => ({
          gateway_id: Number(id),
          use: a.use,
          days: a.days,
          is_default: a.is_default,
          auto_amount: a.auto_amount,
        }));
        state = (await api('settings', 'POST', { multi_account: draft.multi, accounts })).data;
        makeDraft();
        render();
        toast('Đã lưu tài khoản nhận tiền. App thợ áp dụng khi tải lại trang.');
      } else if (act === 'webhook') {
        busy(btn, true, 'Đang đăng ký...');
        state = (await api('webhook-register', 'POST')).data;
        render();
        toast('Đã đăng ký webhook với MonkeyPay.');
      } else if (act === 'test') {
        busy(btn, true, 'Đang gửi thử...');
        const res = await api('webhook-test', 'POST');
        toast(res.message, res.success ? 'success' : 'warn');
        state = (await api('state')).data;
        render();
      }
    } catch (err) {
      toast(err.message, 'error');
    } finally {
      if (btn.isConnected) busy(btn, false);
    }
  }

  async function onChange(e) {
    const t = e.target;
    if (t.id === 'mp-multi') {
      draft.multi = t.checked;
      render();
      markDirty();
      return;
    }
    if (t.id === 'mp-project') {
      try {
        state = (await api('settings', 'POST', { project_id: Number(t.value) })).data;
        makeDraft();
        render();
        toast('Đã đổi dự án, danh sách tài khoản và webhook đã cập nhật.');
      } catch (err) {
        toast(err.message, 'error');
      }
      return;
    }
    const row = t.closest('.mp-acc');
    if (!row) return;
    const a = draft.accounts[row.dataset.id];
    if (t.dataset.field === 'use') {
      a.use = t.checked;
      if (!t.checked) a.is_default = false;
      if (t.checked && !Object.values(draft.accounts).some((x) => x.is_default && x.use)) a.is_default = true;
      render();
      markDirty();
    } else if (t.dataset.field === 'auto_amount') {
      a.auto_amount = t.checked;
      render();
      markDirty();
    } else if (t.dataset.field === 'default') {
      Object.values(draft.accounts).forEach((x) => (x.is_default = false));
      a.is_default = true;
      markDirty();
    }
  }

  async function load() {
    const el = root();
    if (!el) return;
    try {
      state = (await api('state')).data;
      makeDraft();
      render();
    } catch (err) {
      el.innerHTML = `<div class="mp-note mp-note--warn"><span class="dashicons dashicons-warning"></span><div>Không tải được cấu hình MonkeyPay: ${esc(err.message)}</div></div>`;
    }
  }

  document.addEventListener('DOMContentLoaded', () => {
    const el = root();
    if (!el) return;
    el.addEventListener('click', onClick);
    el.addEventListener('change', onChange);
    load();
  });

  window.checkinMonkeyPay = { load };
})();
