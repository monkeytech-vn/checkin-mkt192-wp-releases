/**
 * Payments Page JavaScript
 * Handles modal interactions, toggle validation, and AJAX saving
 * Version: 2.0.0 - Added manual/automatic mode support
 */

jQuery(document).ready(function ($) {
  'use strict';

  // Get saved payment settings from page
  const savedSettings = getSavedSettings();

  /**
   * Toggle automatic mode sections
   */
  function toggleAutomaticSection(payment, isAutomatic) {
    const modal = $(`#modal-${payment}`);
    const manualSection = $(`#${payment}-manual-section`);
    const autoSection = $(`#${payment}-auto-section`);
    const modeText = modal.find('.checkin-payment-mode-text');
    const hiddenInput = modal.find(`input[name="${payment}_auto_mode"]`);

    if (isAutomatic) {
      // Disable validation on manual fields
      manualSection
        .find('input[required], textarea[required], select[required]')
        .prop('required', false);
      // Enable validation on auto fields
      autoSection
        .find('input[data-required], textarea[data-required], select[data-required]')
        .prop('required', true);

      manualSection.slideUp(300);
      autoSection.slideDown(300);
      modeText.text('Thanh toán tự động - Xác nhận qua API');
      hiddenInput.val('1');
    } else {
      // Enable validation on manual fields
      manualSection
        .find('input[data-required], textarea[data-required], select[data-required]')
        .prop('required', true);
      // Disable validation on auto fields
      autoSection
        .find('input[required], textarea[required], select[required]')
        .prop('required', false);

      autoSection.slideUp(300);
      manualSection.slideDown(300);
      modeText.text('Thanh toán thủ công - Dùng hình ảnh mã Qr được tải lên');
      hiddenInput.val('0');
    }
  }

  // Auto mode toggle handlers
  $('#bank-auto-toggle, #momo-auto-toggle, #zalopay-auto-toggle').on('change', function () {
    const payment = $(this).attr('id').replace('-auto-toggle', '');
    const isChecked = $(this).is(':checked');
    toggleAutomaticSection(payment, isChecked);

    // Khối MonkeyPay (monkeypay-connect.js) tự tải trạng thái khi hiện ra
    if (payment === 'bank' && isChecked && window.checkinMonkeyPay) {
      window.checkinMonkeyPay.load();
    }
  });

  // Auto amount sub-toggle handler (inside auto mode section)
  $('#bank-auto-amount-toggle').on('change', function () {
    const isChecked = $(this).is(':checked');
    const labelText = isChecked
      ? 'Số tiền tự động — QR có sẵn số tiền, khớp ghi chú + số tiền'
      : 'Số tiền thủ công — QR không có số tiền, khách nhập tự do, chỉ khớp ghi chú';
    $('#bank-auto-amount-text').text(labelText);
  });

  /**
   * Toggle multi-branch QR section
   */
  function toggleMultiBranchQR(payment, isEnabled) {
    const singleSection = $(`#${payment}-single-qr-section`);
    const multiSection = $(`#${payment}-multi-qr-section`);
    const modeText = $(`#${payment}-qr-branch-mode-text`);

    if (isEnabled) {
      singleSection.slideUp(300);
      multiSection.slideDown(300);
      modeText.text('Mỗi chi nhánh có mã QR riêng');
    } else {
      multiSection.slideUp(300);
      singleSection.slideDown(300);
      modeText.text('Dùng chung 1 mã QR cho tất cả chi nhánh');
    }
  }

  // Multi-branch QR toggle handlers
  $('#bank-qr-per-branch-toggle, #momo-qr-per-branch-toggle, #zalopay-qr-per-branch-toggle').on(
    'change',
    function () {
      const payment = $(this).attr('id').replace('-qr-per-branch-toggle', '');
      const isChecked = $(this).is(':checked');
      toggleMultiBranchQR(payment, isChecked);
    }
  );

  /**
   * Edit payment info (show form to edit)
   */
  window.editPaymentInfo = function (payment) {
    $(`.checkin-saved-info-card`).slideUp(300);
    $(`#${payment}-manual-form`).slideDown(300);
  };

  /**
   * Delete payment info
   */
  window.deletePaymentInfo = function (payment) {
    if (!confirm('Bạn có chắc chắn muốn xóa thông tin này?')) {
      return;
    }

    showPageLoading();

    $.ajax({
      url: checkinAdmin.ajaxurl,
      type: 'POST',
      data: {
        action: 'checkin_delete_payment_info',
        nonce: checkinAdmin.nonce,
        payment_type: payment,
      },
      success: function (response) {
        hidePageLoading();
        if (response.success) {
          showNotification('Thông tin đã được xóa!', 'success');

          // Close modal
          closePaymentModal(payment);

          // Disable toggle
          const card = $(`.checkin-payment-card[data-payment="${payment}"]`);
          const toggle = card.find('.checkin-payment-toggle');
          toggle.prop('checked', false);

          // Update card state to not-configured
          card.removeClass('configured').addClass('not-configured');
          card
            .find('.checkin-payment-status')
            .removeClass('configured')
            .addClass('not-configured')
            .text('Chưa cấu hình');
          card.find('.checkin-payment-toggle-text').text('Đang tắt');

          // Clear modal form data and images
          const modal = $(`#modal-${payment}`);
          modal.find('input[type="text"], input[type="url"], textarea').val('');
          modal.find('.checkin-saved-info-card').remove();
          modal.find('.checkin-qr-preview').remove();
          modal.find(`#${payment}-manual-form`).show();
        } else {
          showNotification(response.data.message || 'Có lỗi xảy ra!', 'error');
        }
      },
      error: function () {
        hidePageLoading();
        showNotification('Không thể kết nối đến máy chủ!', 'error');
      },
    });
  };

  /**
   * Extract saved settings from rendered page
   */
  function getSavedSettings() {
    const settings = {};

    // Extract from each card's data and form values
    $('.checkin-payment-card').each(function () {
      const paymentType = $(this).data('payment');
      const isConfigured = $(this).hasClass('configured');
      const isEnabled = $(this).find('.checkin-payment-toggle').is(':checked');

      settings[paymentType] = {
        configured: isConfigured,
        enabled: isEnabled,
      };
    });

    return settings;
  }

  /**
   * Open payment modal
   */
  window.openPaymentModal = function (payment) {
    $('#modal-' + payment).fadeIn(200);
    $('body').css('overflow', 'hidden');
  };

  /**
   * Close payment modal
   */
  window.closePaymentModal = function (payment) {
    const modal = $('#modal-' + payment);
    modal.fadeOut(200);
    $('body').css('overflow', '');

    // If modal closed without data and toggle is on, turn it off
    const toggle = $(`.checkin-payment-toggle[data-payment="${payment}"]`);
    if (toggle.is(':checked') && !hasRequiredData(payment)) {
      toggle.prop('checked', false);
      updateCardState(payment, false);
      saveToggleState(payment, false);
    }

    // Preserve current auto mode toggle state - do NOT reset it.
    // The toggle was already set correctly by PHP on page load
    // or by user interaction during this session.
  };

  /**
   * Check if payment has required configuration
   * Check by card state class set by PHP
   */
  function hasRequiredData(payment) {
    const card = $(`.checkin-payment-card[data-payment="${payment}"]`);
    return card.hasClass('configured');
  }

  /**
   * Check if manual mode has saved data
   */
  function hasManualData(payment) {
    const modal = $(`#modal-${payment}`);
    const savedCard = modal.find(`#${payment}-manual-section .checkin-saved-info-card`);
    return savedCard.length > 0;
  }

  /**
   * Check if automatic mode has saved data
   */
  function hasAutomaticData(payment) {
    const modal = $(`#modal-${payment}`);
    const autoSection = modal.find(`#${payment}-auto-section`);

    // Check if any API field has value
    let hasData = false;
    autoSection.find('input[data-required="true"]').each(function () {
      if ($(this).val().trim() !== '') {
        hasData = true;
        return false; // break loop
      }
    });

    return hasData;
  }

  /**
   * Update card visual state
   */
  function updateCardState(payment, isEnabled) {
    const card = $(`.checkin-payment-card[data-payment="${payment}"]`);
    const toggleText = card.find('.checkin-payment-toggle-text');

    if (isEnabled) {
      toggleText.text('Đang bật');
    } else {
      toggleText.text('Đang tắt');
    }

    // Update configured state if has data
    if (hasRequiredData(payment)) {
      card.removeClass('not-configured').addClass('configured');
      card
        .find('.checkin-payment-status')
        .removeClass('not-configured')
        .addClass('configured')
        .text('Đã cấu hình');
    } else {
      card.removeClass('configured').addClass('not-configured');
      card
        .find('.checkin-payment-status')
        .removeClass('configured')
        .addClass('not-configured')
        .text('Chưa cấu hình');
    }
  }

  /**
   * Settings button click - open modal
   */
  $('.checkin-btn-payment-settings').on('click', function () {
    const payment = $(this).data('payment');
    openPaymentModal(payment);
  });

  /**
   * Modal close button click
   */
  $('.checkin-modal-close').on('click', function () {
    const payment = $(this).data('payment');
    closePaymentModal(payment);
  });

  /**
   * Click outside modal to close
   */
  $('.checkin-modal-backdrop').on('click', function (e) {
    if ($(e.target).hasClass('checkin-modal-backdrop')) {
      const modalId = $(this).attr('id');
      const payment = modalId.replace('modal-', '');
      closePaymentModal(payment);
    }
  });

  /**
   * Toggle change event
   */
  $('.checkin-payment-toggle').on('change', function () {
    const payment = $(this).data('payment');
    const isChecked = $(this).is(':checked');

    // If turning on but no required data, open modal
    if (isChecked && !hasRequiredData(payment)) {
      openPaymentModal(payment);
      showNotification('Vui lòng nhập thông tin cấu hình!', 'info');
      return; // Don't save toggle state yet
    }

    // If turning off, just save the state
    if (!isChecked) {
      saveToggleState(payment, isChecked);
      updateCardState(payment, isChecked);
      return;
    }

    // If turning on and has data, save toggle state
    saveToggleState(payment, isChecked);
    updateCardState(payment, isChecked);
  });

  /**
   * Save toggle state via AJAX
   */
  function saveToggleState(payment, enabled) {
    $.ajax({
      url: checkinAdmin.ajaxurl,
      type: 'POST',
      data: {
        action: 'checkin_save_payment',
        nonce: checkinAdmin.nonce,
        payment_type: payment,
        enabled: enabled,
      },
      success: function (response) {
        if (response.success) {
          showNotification(
            enabled ? 'Phương thức thanh toán đã được bật.' : 'Phương thức thanh toán đã được tắt.',
            'success'
          );
        } else {
          showNotification(response.data.message || 'Có lỗi xảy ra!', 'error');
        }
      },
      error: function () {
        showNotification('Không thể kết nối đến máy chủ!', 'error');
      },
    });
  }

  /**
   * Form submission handlers
   */
  $('.checkin-payment-form').on('submit', function (e) {
    e.preventDefault();

    const form = $(this);
    const formId = form.attr('id');
    const payment = formId.replace('form-', '');
    const submitBtn = form.closest('.checkin-modal').find('.checkin-btn-primary');

    // Validate required fields (only visible ones)
    let isValid = true;
    form.find('[required]').each(function () {
      const field = $(this);

      // Skip validation if field is in a hidden section
      if (
        field.closest('#' + payment + '-manual-section').length > 0 &&
        $('#' + payment + '-manual-section').is(':hidden')
      ) {
        return true; // continue to next field
      }
      if (
        field.closest('#' + payment + '-auto-section').length > 0 &&
        $('#' + payment + '-auto-section').is(':hidden')
      ) {
        return true; // continue to next field
      }

      const value = field.val();
      if (!value || value.trim() === '') {
        isValid = false;
        field.addClass('checkin-input-error');
      } else {
        field.removeClass('checkin-input-error');
      }
    });

    if (!isValid) {
      showNotification('Vui lòng điền đầy đủ các trường bắt buộc!', 'error');
      submitBtn.removeClass('checkin-btn-loading').prop('disabled', false);
      return;
    }

    // Show loading state
    submitBtn.addClass('checkin-btn-loading').prop('disabled', true);

    // Prepare form data
    const formData = {
      action: 'checkin_save_payment',
      nonce: checkinAdmin.nonce,
      payment_type: payment,
    };

    // Add form fields to data
    form.serializeArray().forEach(function (field) {
      formData[field.name] = field.value;
    });

    // Add checkbox for auto mode (checkboxes not included in serializeArray if unchecked)
    const autoToggle = form.find(`#${payment}-auto-toggle`);
    if (autoToggle.length > 0) {
      formData[`${payment}_auto_mode`] = autoToggle.is(':checked') ? '1' : '0';
    }

    // Add checkbox for auto amount sub-toggle
    const autoAmountToggle = form.find('#bank-auto-amount-toggle');
    if (payment === 'bank' && autoAmountToggle.length > 0) {
      formData['bank_auto_amount'] = autoAmountToggle.is(':checked') ? '1' : '0';
    }

    // Get toggle state
    const toggle = $(`.checkin-payment-toggle[data-payment="${payment}"]`);
    formData.enabled = toggle.is(':checked');

    // Send AJAX request
    $.ajax({
      url: checkinAdmin.ajaxurl,
      type: 'POST',
      data: formData,
      success: function (response) {
        submitBtn.removeClass('checkin-btn-loading').prop('disabled', false);

        if (response.success) {
          showNotification(response.data.message, 'success');

          // Update card state to configured
          const card = $(`.checkin-payment-card[data-payment="${payment}"]`);
          card.removeClass('not-configured').addClass('configured');
          card
            .find('.checkin-payment-status')
            .removeClass('not-configured')
            .addClass('configured')
            .text('Đã cấu hình');

          // Enable toggle if not already
          const cardToggle = card.find('.checkin-payment-toggle');
          if (!cardToggle.is(':checked')) {
            cardToggle.prop('checked', true);
            card.find('.checkin-payment-toggle-text').text('Đang bật');
          }

          // Update modal to show saved info
          updateModalWithSavedData(payment, formData);

          // Don't close modal - keep it open to show saved info
        } else {
          showNotification(response.data.message || 'Có lỗi xảy ra!', 'error');
        }
      },
      error: function (xhr, status, error) {
        submitBtn.removeClass('checkin-btn-loading').prop('disabled', false);

        // Try to parse error response
        let errorMessage = 'Không thể kết nối đến máy chủ!';
        if (xhr.responseText) {
          try {
            const errorData = JSON.parse(xhr.responseText);
            errorMessage = errorData.data?.message || errorData.message || errorMessage;
          } catch (e) {
            errorMessage = xhr.responseText.substring(0, 200);
          }
        }
        showNotification(errorMessage, 'error');
      },
    });
  });

  /**
   * Remove input error class on focus
   */
  $('.checkin-form-control').on('focus', function () {
    $(this).removeClass('checkin-input-error');
  });

  // Note: showNotification() is now defined in common.js
  /**
   * ESC key to close modal
   */
  $(document).on('keydown', function (e) {
    if (e.key === 'Escape') {
      $('.checkin-modal-backdrop:visible').each(function () {
        const modalId = $(this).attr('id');
        const payment = modalId.replace('modal-', '');
        closePaymentModal(payment);
      });
    }
  });

  // Initialize card states on load
  $('.checkin-payment-card').each(function () {
    const payment = $(this).data('payment');
    const toggle = $(this).find('.checkin-payment-toggle');
    updateCardState(payment, toggle.is(':checked'));
  });

  /**
   * Update modal with saved data after successful save
   */
  function updateModalWithSavedData(payment, formData) {
    const modal = $(`#modal-${payment}`);
    const manualSection = modal.find(`#${payment}-manual-section`);
    const manualForm = modal.find(`#${payment}-manual-form`);

    // Check if in manual mode
    const isManualMode = formData[`${payment}_auto_mode`] !== '1';

    if (isManualMode) {
      // Hide form, show saved info card
      manualForm.hide();

      // Remove existing saved info card if any
      manualSection.find('.checkin-saved-info-card').remove();

      // Create saved info card
      let savedInfoHtml = '<div class="checkin-saved-info-card">';
      savedInfoHtml += '<div class="checkin-saved-info-header">';
      savedInfoHtml += '<span class="dashicons dashicons-yes-alt"></span>';
      savedInfoHtml += '<strong>Thông tin đã lưu</strong>';
      savedInfoHtml += '</div>';
      savedInfoHtml += '<div class="checkin-saved-info-body">';

      // Account number
      if (formData[`${payment}_account`]) {
        savedInfoHtml += '<div class="checkin-info-row">';
        savedInfoHtml += '<span class="checkin-info-label">Số tài khoản:</span>';
        savedInfoHtml += `<span class="checkin-info-value">${formData[`${payment}_account`]
          }</span>`;
        savedInfoHtml += '</div>';
      }

      // QR Code
      if (formData[`${payment}_qr_url`]) {
        savedInfoHtml += '<div class="checkin-info-row">';
        savedInfoHtml += '<span class="checkin-info-label">Mã QR:</span>';
        savedInfoHtml += '<div class="checkin-qr-preview">';
        savedInfoHtml += `<img src="${formData[`${payment}_qr_url`]}" alt="QR Code" />`;
        savedInfoHtml += '</div>';
        savedInfoHtml += '</div>';
        savedInfoHtml += '<div class="checkin-info-row">';
        savedInfoHtml += '<span class="checkin-info-label">URL:</span>';
        savedInfoHtml += `<span class="checkin-info-value">${formData[`${payment}_qr_url`]}</span>`;
        savedInfoHtml += '</div>';
      }

      savedInfoHtml += '</div>';
      savedInfoHtml += '<div class="checkin-saved-info-actions">';
      savedInfoHtml += `<button type="button" class="checkin-btn checkin-btn-sm checkin-btn-secondary" onclick="editPaymentInfo('${payment}')">`;
      savedInfoHtml += '<span class="dashicons dashicons-edit"></span> Sửa';
      savedInfoHtml += '</button>';
      savedInfoHtml += `<button type="button" class="checkin-btn checkin-btn-sm checkin-btn-danger" onclick="deletePaymentInfo('${payment}')">`;
      savedInfoHtml += '<span class="dashicons dashicons-trash"></span> Xóa';
      savedInfoHtml += '</button>';
      savedInfoHtml += '</div>';
      savedInfoHtml += '</div>';

      // Insert saved info card before the form
      manualForm.before(savedInfoHtml);
    }
  }

  /**
   * Open WordPress Media Uploader
   */
  window.openMediaUploader = function (fieldId, payment) {
    // Create media uploader if not exists
    if (typeof wp !== 'undefined' && wp.media) {
      const mediaUploader = wp.media({
        title: 'Chọn hoặc tải lên hình ảnh QR',
        button: {
          text: 'Sử dụng hình ảnh này',
        },
        multiple: false,
        library: {
          type: 'image',
        },
      });

      // When image is selected
      mediaUploader.on('select', function () {
        const attachment = mediaUploader.state().get('selection').first().toJSON();
        const imageUrl = attachment.url;

        // Set URL to input field
        $('#' + fieldId).val(imageUrl);

        // Show preview
        const previewId = payment + '_qr_preview';
        let previewContainer = $('#' + previewId);

        if (previewContainer.length === 0) {
          // Create preview container if not exists
          $('#' + fieldId)
            .parent()
            .after(
              '<div class="checkin-qr-preview" id="' +
              previewId +
              '" style="margin-bottom: 8px;"><img src="' +
              imageUrl +
              '" alt="QR Preview" style="max-width: 200px; border-radius: 4px; border: 1px solid #ddd;"></div>'
            );
        } else {
          // Update existing preview
          previewContainer.find('img').attr('src', imageUrl);
          previewContainer.show();
        }
      });

      // Open uploader
      mediaUploader.open();
    } else {
      alert('Media uploader không khả dụng. Vui lòng nhập URL thủ công.');
    }
  };

  // MonkeyPay (kết nối, tài khoản, webhook) chuyển sang admin/assets/js/pages/monkeypay-connect.js từ 5.3.9.0

  /**
   * MBBank (chế độ cũ): thử đăng nhập
   */
  $('#btn-test-mb-login').on('click', function () {
    const $btn = $(this);
    const $result = $('#mb-login-result');
    const originalText = $btn.html();

    $btn.prop('disabled', true).html(
      '<span class="dashicons dashicons-update spin"></span> Đang kiểm tra đăng nhập...'
    );
    $result.show().html(
      '<span style="color: #6b7280;">⏳ Đang kết nối đến MB Bank, vui lòng chờ...</span>'
    );

    $.ajax({
      url: checkinAdmin.restUrl + 'vg/v1/mbbank-test-login',
      method: 'POST',
      timeout: 30000,
      headers: { 'X-WP-Nonce': checkinAdmin.restNonce },
      contentType: 'application/json',
      data: JSON.stringify({}),
      success: function (response) {
        if (response && response.success) {
          $result.html(
            '<span style="color: #16a34a; font-weight: 600;">✅ ' +
            (response.message || 'Đăng nhập MB Bank thành công!') +
            '</span>'
          );
        } else {
          $result.html(
            '<span style="color: #dc2626; font-weight: 600;">❌ ' +
            (response.message || 'Đăng nhập thất bại. Kiểm tra lại username/password.') +
            '</span>'
          );
        }
      },
      error: function (xhr) {
        let msg = 'Không thể kết nối. Kiểm tra Service URL và API Secret.';
        if (xhr.responseJSON && xhr.responseJSON.message) {
          msg = xhr.responseJSON.message;
        }
        $result.html(
          '<span style="color: #dc2626; font-weight: 600;">❌ ' + msg + '</span>'
        );
      },
      complete: function () {
        $btn.prop('disabled', false).html(originalText);
      },
    });
  });

});
