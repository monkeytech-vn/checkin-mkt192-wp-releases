/**
 * Chọn tài khoản nhận tiền MonkeyPay (dùng chung app thợ + màn khách).
 *
 * window.mkBankAccounts:
 *   forToday(bankData)            → tài khoản dùng hôm nay (theo ngày dùng trong tuần)
 *   pick(accounts, { amount })    → Promise<account|null>, hiện bảng chọn; null = huỷ
 *   qrUrl(account, note, amount)  → ảnh VietQR đúng ngân hàng của tài khoản
 *   renderStrip(el, account, opts)→ dải "đang nhận vào tài khoản ..." trên QR, có nút Đổi
 */
(function () {
  'use strict';

  const esc = (v) =>
    String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const money = (v) => `${Math.round(Number(v) || 0).toLocaleString('vi-VN')} đ`;
  const tail = (num) => (num ? `••••\u00a0${String(num).slice(-4)}` : '');
  const DAY = { 1: 'T2', 2: 'T3', 3: 'T4', 4: 'T5', 5: 'T6', 6: 'T7', 7: 'CN' };

  function isoToday() {
    const d = new Date().getDay();
    return d === 0 ? 7 : d;
  }

  function daysText(days) {
    const list = (days || []).map(Number).sort((a, b) => a - b);
    if (!list.length || list.length === 7) return 'Mọi ngày';
    if (list.join(',') === '1,2,3,4,5') return 'T2 - T6';
    if (list.join(',') === '6,7') return 'T7, CN';
    return list.map((d) => DAY[d]).join(', ');
  }

  /** Tài khoản hợp ngày hôm nay; không cái nào hợp thì trả tất cả (vẫn thu được tiền). */
  function forToday(bankData) {
    const accounts = Array.isArray(bankData?.accounts) ? bankData.accounts : [];
    const today = isoToday();
    const matched = accounts.filter((a) => (a.days || []).map(Number).includes(today));
    return matched.length ? matched : accounts;
  }

  function logo(account, size) {
    const initials = esc(String(account.bank_short || account.bank_name || '?').slice(0, 3));
    if (!account.bank_logo) return `<span class="mkbap-logo mkbap-logo--text" style="--s:${size}px">${initials}</span>`;
    return `<span class="mkbap-logo" style="--s:${size}px"><img src="${esc(account.bank_logo)}" alt="${esc(account.bank_name)}" loading="lazy" onerror="this.parentNode.classList.add('mkbap-logo--text');this.parentNode.textContent='${initials}'"></span>`;
  }

  function qrUrl(account, note, amount) {
    let url =
      `https://img.vietqr.io/image/${encodeURIComponent(account.bank_bin)}-${encodeURIComponent(account.account_number)}-compact2.png` +
      `?addInfo=${encodeURIComponent(note || '')}` +
      `&accountName=${encodeURIComponent(account.account_name || '')}`;
    if (account.auto_amount && amount) url += `&amount=${Math.round(amount)}`;
    return url;
  }

  let openSheet = null;

  function pick(accounts, { amount, title } = {}) {
    if (openSheet) openSheet.close(null);
    return new Promise((resolve) => {
      const today = isoToday();
      const overlay = document.createElement('div');
      overlay.className = 'mkbap-overlay';
      overlay.innerHTML = `
        <div class="mkbap-sheet" role="dialog" aria-modal="true" aria-labelledby="mkbap-title">
          <div class="mkbap-head">
            <div>
              <h3 id="mkbap-title">${esc(title || 'Chọn tài khoản nhận tiền')}</h3>
              ${amount ? `<p class="mkbap-amount">Số tiền <strong>${money(amount)}</strong></p>` : ''}
            </div>
            <button type="button" class="mkbap-close" aria-label="Đóng">&times;</button>
          </div>
          <div class="mkbap-list">
            ${accounts
              .map(
                (a, i) => `
              <button type="button" class="mkbap-option" data-i="${i}">
                ${logo(a, 44)}
                <span class="mkbap-info">
                  <span class="mkbap-name">${esc(a.label || a.bank_name)}</span>
                  <span class="mkbap-meta">${esc(a.bank_name)} · <span class="mkbap-nowrap">${esc(tail(a.account_number))}</span></span>
                  <span class="mkbap-owner">${esc(a.account_name)}</span>
                </span>
                <span class="mkbap-tags">
                  ${a.is_default ? '<span class="mkbap-tag mkbap-tag--main">Mặc định</span>' : ''}
                  <span class="mkbap-tag${(a.days || []).map(Number).includes(today) ? ' mkbap-tag--today' : ''}">${esc(daysText(a.days))}</span>
                </span>
                <i class="fas fa-chevron-right mkbap-arrow" aria-hidden="true"></i>
              </button>`
              )
              .join('')}
          </div>
          <button type="button" class="mkbap-cancel">Huỷ</button>
        </div>`;

      const close = (value) => {
        if (!overlay.isConnected) return;
        overlay.classList.remove('is-open');
        document.removeEventListener('keydown', onKey, true);
        setTimeout(() => overlay.remove(), 180);
        openSheet = null;
        resolve(value);
      };
      const onKey = (e) => {
        if (e.key === 'Escape') {
          e.stopPropagation();
          close(null);
        }
      };

      overlay.addEventListener('click', (e) => {
        if (e.target === overlay || e.target.closest('.mkbap-close, .mkbap-cancel')) return close(null);
        const opt = e.target.closest('.mkbap-option');
        if (opt) close(accounts[Number(opt.dataset.i)]);
      });
      document.addEventListener('keydown', onKey, true);
      document.body.appendChild(overlay);
      overlay.getBoundingClientRect();
      overlay.classList.add('is-open');
      overlay.querySelector('.mkbap-option')?.focus();
      openSheet = { close };
    });
  }

  /** Dải tài khoản đang nhận tiền phía trên QR. opts.onChange có thì hiện nút "Đổi". */
  function renderStrip(el, account, { onChange } = {}) {
    if (!el) return;
    if (!account) {
      el.classList.add('hidden');
      el.innerHTML = '';
      return;
    }
    el.innerHTML = `
      ${logo(account, 34)}
      <span class="mkbap-strip-info">
        <span class="mkbap-strip-bank">${esc(account.bank_name)} · ${esc(tail(account.account_number))}</span>
        <span class="mkbap-strip-owner">${esc(account.account_name)}</span>
      </span>
      ${onChange ? '<button type="button" class="mkbap-strip-change"><i class="fas fa-exchange-alt"></i> Đổi</button>' : ''}`;
    el.classList.remove('hidden');
    if (onChange) el.querySelector('.mkbap-strip-change').addEventListener('click', onChange);
  }

  window.mkBankAccounts = { forToday, pick, qrUrl, renderStrip, isoToday, daysText };
})();
