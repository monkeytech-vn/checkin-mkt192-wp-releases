<?php

// Silence Is Golden.